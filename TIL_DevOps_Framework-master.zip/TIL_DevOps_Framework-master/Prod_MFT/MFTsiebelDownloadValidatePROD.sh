#!/bin/bash
cd $2/IndirectPartner_Onboarding/Prod_MFT

#sleep
echo "sleeping for five minutes"

flag=0
count=0
# Run download file
mkdir siebel
while [ $flag -ne 1 ] && [ $count -lt 2 ]
do

                sleep 300
               
# Edit the port username and IP Address with Production MFT details
       # sftp  -oport=8022 -b ./fileDownload.txt x_uktilahr@195.233.199.174
        sftp -b ./fileDownload.txt x_uk2731yr@mft-is.uk.vodafone.com

        if [ -f $2/IndirectPartner_Onboarding/Prod_MFT/siebel/IndirectPartnerDealerAutoSetup_Output.csv ]
        then
                echo File downloaded
                flag=1
        else
                echo File Not Downloaded;
# The path of the email body and email receivers needs to be changed to the prod server path and prod contacts
mailx -s "Partner $1 onboarding -PROD  Response file not found" -r "IndirectPartner_Onboarding@vodafone.com" -c " swapnil.dubale@vodafone.com" "devops-vfuk-integration@vodafone.com,DL-TSSC-CCS-CRM_L2_Team@vodafone.com,DL-TSSC-AO2-UK-Integration_FileTransfer_L2@vodafone.com,sudhir.saini@vodafone.com,debraj.chatterjee@vodafone.com,sureshbabu.pydikondala1@vodafone.com,dl-techvi-ito-ao-deaas-uk-til@vodafone.com,DL-TSSC-AO2-UK-Integration_TIL-RIG_L2@vodafone.com" < $2/IndirectPartner_Onboarding/Prod_MFT/FileNotFoundEmail.txt

                                if [ $count -eq 1 ]
                                then
# The path of the email body and email receivers needs to be changed to the prod server path and prod contacts

mailx -s "Partner $1 onboarding - PROD Response File Download Failed" -r "IndirectPartner_Onboarding@vodafone.com" -c " swapnil.dubale@vodafone.com" "devops-vfuk-integration@vodafone.com,DL-TSSC-CCS-CRM_L2_Team@vodafone.com,DL-TSSC-AO2-UK-Integration_FileTransfer_L2@vodafone.com,sudhir.saini@vodafone.com,debraj.chatterjee@vodafone.com,sureshbabu.pydikondala1@vodafone.com,dl-techvi-ito-ao-deaas-uk-til@vodafone.com,DL-TSSC-AO2-UK-Integration_TIL-RIG_L2@vodafone.com" < $2/IndirectPartner_Onboarding/Prod_MFT/downloadFailEmail.txt
                                fi

                                count=$((count+1))

                echo "sleeping for five minutes"

        fi
done

if [ $flag -eq 1 ]
then
        echo " Validating CSV "

        truncate -s 0 output.txt
        awk -F',' 'NR > 1 {print $21}' $2/IndirectPartner_Onboarding/Prod_MFT/siebel/IndirectPartnerDealerAutoSetup_Output.csv > output.txt

        flag=0
        while read line
        do
        text=`echo $line`
        if [ -z $text ] || [ $text != "Success" ]
        then
                flag=1
        fi

        done < output.txt

        if [ $flag -eq 1 ]
                then
                        echo "Not Success" > TransferStatus.txt

# The path of the email body and email receivers needs to be changed to the prod server path and prod contacts

                mailx -s "Partner $1 onboarding - Response File Validation Failed" -a "$2/IndirectPartner_Onboarding/Prod_MFT/siebel/IndirectPartnerDealerAutoSetup_Output.csv" -r "IndirectPartner_Onboarding@vodafone.com" -c " swapnil.dubale@vodafone.com" "devops-vfuk-integration@vodafone.com,DL-TSSC-CCS-CRM_L2_Team@vodafone.com,sudhir.saini@vodafone.com,debraj.chatterjee@vodafone.com,sureshbabu.pydikondala1@vodafone.com,DL-TSSC-AO2-UK-Integration_TIL-RIG_L2@vodafone.com,dl-techvi-ito-ao-deaas-uk-til@vodafone.com,DL-TSSC-AO2-UK-Integration_FileTransfer_L2@vodafone.com,maya.nair@vodafone.com,gaurav.khutwad@vodafone.com"  < $2/IndirectPartner_Onboarding/Prod_MFT/ResponseFailureEmail.txt

                else
                        echo "Success" > TransferStatus.txt

# The path of the email body and email receivers needs to be changed to the prod server path and prod contacts

                        mailx -s "Partner $1 onboarding - Response File Validation Success" -a "$2/IndirectPartner_Onboarding/Prod_MFT/siebel/IndirectPartnerDealerAutoSetup_Output.csv" -r "IndirectPartner_Onboarding@vodafone.com" -c "swapnil.dubale@vodafone.com" "devops-vfuk-integration@vodafone.com,DL-TSSC-CCS-CRM_L2_Team@vodafone.com,sudhir.saini@vodafone.com,debraj.chatterjee@vodafone.com,sureshbabu.pydikondala1@vodafone.com,DL-TSSC-AO2-UK-Integration_TIL-RIG_L2@vodafone.com,dl-techvi-ito-ao-deaas-uk-til@vodafone.com,DL-TSSC-AO2-UK-Integration_FileTransfer_L2@vodafone.com,maya.nair@vodafone.com,gaurav.khutwad@vodafone.com"  < $2/IndirectPartner_Onboarding/Prod_MFT/ResponseValidationSuccessEmail.txt
        fi

fi
