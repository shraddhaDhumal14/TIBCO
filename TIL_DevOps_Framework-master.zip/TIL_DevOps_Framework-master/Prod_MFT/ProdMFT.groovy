import java.util.Date
import java.text.SimpleDateFormat

def input_Filename = "IndirectPartnerDealerAutoSetup"
def output_Filename = "IndirectPartnerDealerAutoSetup_Output"
Date CurrentDate = new Date()
SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd-HH:mm:ss")
String Formatted_Date = formatter.format(CurrentDate)

input_Filename = "$input_Filename" +"-"+ "$Formatted_Date" + ".csv"
output_Filename = "$output_Filename" +"-"+ "$Formatted_Date" + ".csv"

NEXUS_REPO = "http://195.233.197.150:8081/repository/TEST_AUTOMATION_REPO/"
NEXUS_USER = "admin"
NEXUS_PASS = "admin123"
def checkout_git_repositories() {
                             
        checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'IndirectPartner_Onboarding']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_DevOps_Framework.git']]])   
}

pipeline {
	agent any
	stages {
		
		stage('Preparation'){
			steps{
				script{
					cleanWs()
					//sh "git clone https://github.vodafone.com/VFUK-INTEGRATION/TIL_DevOps_Framework.git"
					checkout_git_repositories()
				}
			}
		}
		stage('Download input CSV from Nexus'){
			steps{
				script{	
					
					//input 'Proceed with  Nexus Download ?'
					println("Downloading Siebel input file from nexus ");
					sh "set +x ; wget --http-user ${NEXUS_USER} --http-password=${NEXUS_PASS} http://195.233.197.150:8081/repository/TEST_AUTOMATION_REPO/${params.NEW_PARTNER}/IndirectPartnerDealerAutoSetup.csv ; set -x"		
				}
			}
		}
		stage('MFT upload') {
			steps {
				script {
					//input 'Proceed with  MFT Upload ?'
					sh "set +x ; echo 'not uploaded' > ${WORKSPACE}/IndirectPartner_Onboarding/Prod_MFT/uploadStatus.txt ; set -x"
				def uploadStatus = sh(returnStdout: true, script: 'cat ${WORKSPACE}/IndirectPartner_Onboarding/Prod_MFT/uploadStatus.txt').trim()
						
					uploadStatus = sh(returnStdout: true, script: 'cat ${WORKSPACE}/IndirectPartner_Onboarding/Prod_MFT/uploadStatus.txt').trim()
						
					while (uploadStatus != "uploaded" ){
					sh "chmod +x ${WORKSPACE}/IndirectPartner_Onboarding/Prod_MFT/MFTSiebelUploadPROD.sh"
					sh "${WORKSPACE}/IndirectPartner_Onboarding/Prod_MFT/MFTSiebelUploadPROD.sh ${params.NEW_PARTNER} ${WORKSPACE}"
					
					uploadStatus = sh(returnStdout: true, script: 'cat ${WORKSPACE}/IndirectPartner_Onboarding/Prod_MFT/uploadStatus.txt').trim()
					
					if (uploadStatus != "uploaded"){
								sh 'truncate -s 0 ${WORKSPACE}/IndirectPartner_Onboarding/Prod_MFT/uploadStatus.txt'
								
								def userInput = input(
								id: 'userInput', message: 'File not uploaded . Please resolve issues and proceed further accordingly'	
								)
							}
					}
					println("Keeping Backup of Input CSV File in Nexus ")
										
					sh "set +x ; curl -v -u ${NEXUS_USER}:${NEXUS_PASS} --upload-file ${WORKSPACE}/IndirectPartnerDealerAutoSetup.csv ${NEXUS_REPO}/InputCsv_Backup/${input_Filename} ; set -x"
				}
			}
		}
		stage('MFT Download And Validation') {
			steps {
				script {
					
					//input 'Proceed with  MFT Download and validation ?'
					 
					sh "set +x ; echo 'failed' > ${WORKSPACE}/IndirectPartner_Onboarding/Prod_MFT/TransferStatus.txt ; set -x "
					
					def MFTStatus = sh(returnStdout: true, script: 'cat ${WORKSPACE}/IndirectPartner_Onboarding/Prod_MFT/TransferStatus.txt').trim()
						
						MFTStatus = sh(returnStdout: true, script: 'cat ${WORKSPACE}/IndirectPartner_Onboarding/Prod_MFT/TransferStatus.txt').trim()
						
						
						
						while ( MFTStatus != "Success"){
					
							sh 'truncate -s 0 ${WORKSPACE}/IndirectPartner_Onboarding/Prod_MFT/TransferStatus.txt'
							sh 'truncate -s 0 ${WORKSPACE}/IndirectPartner_Onboarding/Prod_MFT/output.txt'
							
							sh "chmod +x ${WORKSPACE}/IndirectPartner_Onboarding/Prod_MFT/MFTsiebelDownloadValidatePROD.sh"
							sh "${WORKSPACE}/IndirectPartner_Onboarding/Prod_MFT/MFTsiebelDownloadValidatePROD.sh ${params.NEW_PARTNER} ${WORKSPACE}"
							
							MFTStatus = sh(returnStdout: true, script: 'cat ${WORKSPACE}/IndirectPartner_Onboarding/Prod_MFT/TransferStatus.txt').trim()
							
							if (MFTStatus != "Success"){
								
								def userInput = input(
								id: 'userInput', message: 'Please check for response csv file or csv errors. Please resolve csv issues and proceed further accordingly'	
								)
							}
						}
						
					println("Keeping Backup of Response file in Nexus .")
						
					sh " set +x ; curl -v -u ${NEXUS_USER}:${NEXUS_PASS} --upload-file ${WORKSPACE}/IndirectPartner_Onboarding/Prod_MFT/siebel/IndirectPartnerDealerAutoSetup_Output.csv ${NEXUS_REPO}/OutputCsv_Backup/${output_Filename} ; set -x"
						
					println("MFT Response Status: ${MFTStatus}")
					println("MFT Stage Completed Successfully")				
				}
			}
		}  
		stage('Delete input and output csv'){
			steps{
				script{
					println("Deleting input and output csv from MFT and Nexus . . .")
					
					sh "chmod +x ${WORKSPACE}/IndirectPartner_Onboarding/Prod_MFT/InputOutputDelete.sh"
					sh "${WORKSPACE}/IndirectPartner_Onboarding/Prod_MFT/InputOutputDelete.sh"
					sh "set +x ; curl -v -u ${NEXUS_USER}:${NEXUS_PASS} --request DELETE ${NEXUS_REPO}/${params.NEW_PARTNER}/IndirectPartnerDealerAutoSetup.csv ; set -x"
				}
			}
		}
	}
}
