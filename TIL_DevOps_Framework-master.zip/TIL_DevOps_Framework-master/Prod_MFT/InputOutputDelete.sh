#!/bin/bash
cd ${WORKSPACE}/IndirectPartner_Onboarding/Prod_MFT
sftp -b ./deleteFiles.txt x_uk2731yr@mft-is.uk.vodafone.com
