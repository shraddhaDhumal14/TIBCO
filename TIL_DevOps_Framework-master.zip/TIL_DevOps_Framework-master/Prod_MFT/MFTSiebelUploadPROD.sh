#!/bin/bash
# Change the dir to PROD Env dir
cd ${WORKSPACE}/IndirectPartner_Onboarding/Prod_MFT
# Update the Port, Username and IP Address for PROD MFT
#ftp -oport=8022 -b ./fileUpload.txt x_uktilahr@195.233.199.174
sftp -b ./fileUpload.txt x_uk2731yr@mft-is.uk.vodafone.com

UPLOAD_FILES=$(sftp x_uk2731yr@mft-is.uk.vodafone.com << EOF
cd xfer02169
ls 
EOF
)

if echo "$UPLOAD_FILES" | grep -q "IndirectPartnerDealerAutoSetup.csv"; then
	echo " File Uploaded"
	echo "uploaded" > uploadStatus.txt
	mailx -s "Partner $1 onboarding -File uploaded successfully" -r "IndirectPartner_Onboarding@vodafone.com" -c " swapnil.dubale@vodafone.com" "devops-vfuk-integration@vodafone.com,DL-TSSC-CCS-CRM_L2_Team@vodafone.com,DL-TSSC-AO2-UK-Integration_FileTransfer_L2@vodafone.com,DL-TSSC-AO2-UK-Integration_TIL-RIG_L2@vodafone.com,dl-techvi-ito-ao-deaas-uk-til@vodafone.com,sudhir.saini@vodafone.com,debraj.chatterjee@vodafone.com,sureshbabu.pydikondala1@vodafone.com,maya.nair@vodafone.com,gaurav.khutwad@vodafone.com" < $2/IndirectPartner_Onboarding/Prod_MFT/uploadsuccessEmail.txt
	#mailx -s "Partner $1 onboarding -File uploaded successfully" -r "IndirectPartner_Onboarding@vodafone.com" -c " swapnil.dubale@vodafone.com" "devops-vfuk-integration@vodafone.com" < $2/IndirectPartner_Onboarding/Prod_MFT/uploadsuccessEmail.txt
else
	echo "File Not Uploaded"
	echo "not uploaded" > uploadStatus.txt
	mailx -s "Partner $1 onboarding -File upload failed" -r "IndirectPartner_Onboarding@vodafone.com" -c " swapnil.dubale@vodafone.com" "devops-vfuk-integration@vodafone.com,DL-TSSC-CCS-CRM_L2_Team@vodafone.com,DL-TSSC-AO2-UK-Integration_FileTransfer_L2@vodafone.com,DL-TSSC-AO2-UK-Integration_TIL-RIG_L2@vodafone.com,dl-techvi-ito-ao-deaas-uk-til@vodafone.com,sudhir.saini@vodafone.com,debraj.chatterjee@vodafone.com,sureshbabu.pydikondala1@vodafone.com,maya.nair@vodafone.com,gaurav.khutwad@vodafone.com" < $2/IndirectPartner_Onboarding/Prod_MFT/uploadfailEmail.txt
	#mailx -s "Partner $1 onboarding -File upload failed" -r "IndirectPartner_Onboarding@vodafone.com" -c " swapnil.dubale@vodafone.com" "devops-vfuk-integration@vodafone.com" < $2/IndirectPartner_Onboarding/Prod_MFT/uploadfailEmail.txt
fi
