// Global Parameters to use in the stages.
date_now = new Date().format( 'dd-MM-yyyy' )

// Mail recipents for the individual stages.
def dev_mailRecipients = "nani.ponnada@vodafone.com, ${BUILD_REQUESTER}"


// SonarQube Execution and Properties file Modification.
def Sonar_exe() {
	
	sh "cp -r ./TIL_Automation/SonarQube/sonar-project.properties ./TIL_SOURCE"
	sh "mkdir ./Reports"
	sh "sed -i 's#sonar.report.path=.*#sonar.report.path=${WORKSPACE}/Reports#' ./TIL_SOURCE/sonar-project.properties"
	sh "sed -i 's#sonar.projectKey=.*#sonar.projectKey=${TIL_TYPE}_${ENGINE_NAME}#' ./TIL_SOURCE/sonar-project.properties"
	sh "sed -i 's#sonar.projectName=.*#sonar.projectName=${TIL_TYPE}_${ENGINE_NAME}#' ./TIL_SOURCE/sonar-project.properties"
	
	if (FEATURE_BRANCH.length() !=0) {
		sh "sed -i 's#sonar.branch.target.name=.*#sonar.branch.target.name= ${FEATURE_BRANCH}#' ./TIL_SOURCE/sonar-project.properties"
	}else {
		sh "sed -i 's#sonar.branch.target.name=.*#sonar.branch.target.name= ${RELEASE}#' ./TIL_SOURCE/sonar-project.properties"
	}
	
	if (Rules_Excluded.length() !=0) {
		sh "sed -i 's#sonar.exclusions.rules=.*#sonar.exclusions.rules=${Rules_Excluded}#' ./TIL_SOURCE/sonar-project.properties"
	}
	
	if (Exclude_Directories_or_Files.length() !=0) {
		sh "sed -i 's#sonar.exclusions=.*#sonar.exclusions=**/Interface/*,**/Interface/**/*,**/defaultVars/defaultVars.substvar,${Exclude_Directories_or_Files}#' ./TIL_SOURCE/sonar-project.properties"
	}
	
	
	sh "sed -i 's#sonar.bw5.overriderules.file =.*#sonar.bw5.overriderules.file = ${WORKSPACE}/TIL_Automation/SonarQube/OverrideRules.xml#' ${SonarQube_Home}/conf/sonar.properties"
	
	sh "export SONAR_HOME=${SonarQube_Home} && ${SonarScanner_Home}/bin/sonar-scanner -D'sonar.log.console=true' -D'sonar.projectBaseDir=./TIL_SOURCE' > ./Sonar_Exe.out"
	sh "cp -r ./Reports/${TIL_TYPE}_${ENGINE_NAME}*.xlsx ./"
	sh "cat ./Sonar_Exe.out"

}



// Email Body Generation with Result_Status 		
def get_body_build_summary(){
		date_now = new Date().format( 'dd-MM-yyyy' )
		
	
		def body_build_summary = """
				<style type="text/css">
				.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
				.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
				.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
				.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
				.tg .tg-2wig{font-weight:bold;text-align:center;vertical-align:top}
				.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
				.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
				.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
				.tg .tg-0lax{text-align:left;vertical-align:top}
				</style>
				</style>
				<table class="tg" style="undefined;table-layout: fixed; width: 100%">
				<colgroup>
				<col style="width: 90px">
				<col style="width: 90px">
				<col style="width: 90px">
				<col style="width: 90px">
				</colgroup>
				  <tr>
					<th class="tg-amwm" colspan="6">SonarQube Execution Status</th>
				  </tr>
				  <tr>
					<td class="tg-1wig" colspan="2">Date</td>
					<td class="tg-0lax" colspan="4">${date_now}</td>
				  </tr>
				  <tr>
					<td class="tg-1wig" colspan="2">Submitted By</td>
					<td class="tg-0lax" colspan="4">${currentBuild.getRawBuild().getCauses()[0].getUserId()}</td>
				  </tr>
				  <tr>	
					<td class="tg-1wig" colspan="2">Engine_Name</td>
					<td class="tg-0lax" colspan="4">${ENGINE_NAME}</td>
				  </tr>
				  <tr>	
					<td class="tg-1wig" colspan="2">RELEASE</td>
					<td class="tg-0lax" colspan="4">${RELEASE}</td>
				  </tr>
				  <tr>	
					<td class="tg-1wig" colspan="2">FEATURE_BRANCH</td>
					<td class="tg-0lax" colspan="4">${FEATURE}</td>
				  </tr>
				  <tr>	
					<td class="tg-1wig" colspan="2">Status</td>
					<td class="tg-0lax" colspan="4">${Status}</td>
				  </tr>
				  <tr>
					<td class="tg-1wig" colspan="2">BUILD_URL</td>
					<td class="tg-0lax" colspan="4">${BUILD_URL}</td>
				  </tr>
				 </table>
				
				<br><br><br>
		"""
		emailBody = body_build_summary
		return body_build_summary
}


pipeline {
	agent any
	environment {
		FEATURE = ""
		TIL_TYPE="TIL"
		Status = "Failed"
		SonarQube_Home = "/opt/tibco/devops/sonarqube/sonarqube-8.6.1.40680"
		SonarScanner_Home = "/opt/tibco/devops/sonarqube/sonar-scanner-4.5.0.2216-linux"
	}
	
	stages {
		stage('Preparation') {
			steps {
                script {
						
					
					currentBuild.displayName = "SonarQube_${params.RELEASE}_${BUILD_NUMBER}" 
						
                    cleanWs disableDeferredWipeout: true, deleteDirs: true
					// checking out framework automation scripts
					checkout([$class: 'GitSCM', doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: './TIL_Automation']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]])
                        
                    // This function is to checkout all the required GIT repositories.
					checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'JENKINS_FILE']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_DevOps_Framework.git']]])
					
					// checking out Release Branch for project .
					checkout([$class: 'GitSCM', branches: [[name: "${params.RELEASE}"]], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: './TIL_SOURCE']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: "https://github.vodafone.com/VFUK-INTEGRATION/${env.TIL_TYPE}_${ENGINE_NAME}.git"]]])    
                   	
					// checking out Feature Branch for project only if some value is present.
					if (FEATURE_BRANCH != "") {
						checkout([$class: 'GitSCM', branches: [[name: "${params.FEATURE_BRANCH}"]], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: './TIL_SCRUM']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: "https://github.vodafone.com/VFUK-INTEGRATION/${env.TIL_TYPE}_${ENGINE_NAME}.git"]]])

						FEATURE = "${FEATURE_BRANCH}"
					} else {
						FEATURE = "--- None ---"
					}
					
					sh '''						
						
						if [ -d "${WORKSPACE}/TIL_SCRUM" ]; then
							cd ./TIL_SCRUM
							rm -rf `find . -name CVS`
							# Copy all the modified / added files to Main module from Scrum Module.
							if [ ! -z "${MODIFIED_FILES}" ];then 
								echo "${MODIFIED_FILES}" | while IFS= read -r line
								do
									[[ -f "${line}" ]] && cp --parents --remove-destination "${line}" ${WORKSPACE}/TIL_SOURCE/ || { echo "ERROR: ${line} does not exist in Feature Branch. Please check."; exit 1; }
								done
							fi

							# Change the direcory to TIL_SOURCE before deleting files.
							cd "${WORKSPACE}/TIL_SOURCE"

							# Remove all the deleted files from Main module.
							if [ ! -z "${DELETED_FILES}" ];then 
								echo "${DELETED_FILES}" | while IFS= read -r line
								do
									[[ -f "${line}" ]] && rm  "${WORKSPACE}/TIL_SOURCE/${line}" || { echo "ERROR: ${line} does not exist in TIL MAIN Module. Please check."; exit 1; }
								done
							fi
						fi

						cd ${WORKSPACE}
						
					'''	
						
					
				
				}
			}
		}
		
   		stage('SonarQube Execution') {
			steps {				
				script{
											
					Sonar_exe()
					 
					//echo "Sonar Execution Completed"
					if(fileExists("${WORKSPACE}/Sonar_Exe.out")) {
						//def statusFile = new File("${WORKSPACE}/Sonar_Exe.out")
						//def statusContent = statusFile.readLines()
						def Content = sh "grep 'EXECUTION' Sonar_Exe.out"
												
							if(Content.equals("INFO: EXECUTION FAILURE")) {
							
								Status = "Failed"
							}else {
								Status = "Success"
							}
							//echo "${Status}"
							
							def emailBody = "${get_body_build_summary()}"
							emailext  mimeType: 'text/html', attachmentsPattern: 'TIL_${ENGINE_NAME}*.xlsx',
							subject: "[Jenkins]:SonarQube Reports",
							from:"SonarQube_Execution@vodafone.com",
							to: "${dev_mailRecipients}",
							body: 	 "${emailBody}" 
							
				    }               
				}						
			}
		}  
	
	}	
	post {
		success {
			echo "SonarQube Execution Success"
		}
		failure{
			//def Status = "Failed"
			echo "SonarQube Execution Failed"
			//def emailBody = "${get_body_build_summary()}"
							emailext  mimeType: 'text/html', attachmentsPattern: 'TIL_${ENGINE_NAME}*.xlsx',
							subject: "[Jenkins]:SonarQube Reports",
							from:"SonarQube_Execution@vodafone.com",
							to: "${dev_mailRecipients}",
							body: 	 "${get_body_build_summary()}"
		}
	}
}
