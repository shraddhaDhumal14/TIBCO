//src/pipeline/stage/preparation.groovy
package pipeline.stages;
@Library('myLibrary@master') _
	def prepCommonSQL(prepParams) {
		
		// This stage is to construct map and update values with the build input parameters
		
			validateInputParams RELEASE: prepParams.RELEASE, CRQ: prepParams.CRQ, DESCRIPTION: prepParams.DESCRIPTION, BUILD_REQUESTER: prepParams.BUILD_REQUESTER, ENGINE_NAME: prepParams.ENGINE_NAME
			
			// Checkout required GIT repositories.
			checkOutGitRepos use_tag: "NO"
			
			//Load all functions files from GIT. point to exact source file
			load_groovy_files()		
			
			def bw_release_num = deployParams.RELEASE.replace(".","_")

			def majorVersion = prepParams.RELEASE.split('CCS')[1].split('\\.')[0]
			def minorVersion = prepParams.RELEASE.split('CCS')[1].split('\\.')[1]	
		
			displayName = "${prepParams.RELEASE}_${prepParams.ENGINE_NAME}_${BUILD_NUMBER}"
			currentBuild.displayName = "${displayName}"
}

return this;
