
import java.text.*

import groovy.time.*

 

 

def elapsedTime(Closure closure){

    def timeStart = new Date()

    closure()

    def timeStop = new Date()

    return TimeCategory.minus(timeStop, timeStart).toMilliseconds()

              }

 

def Git_Checkout (){

 

                                           //Checkout Ansible Scripts for Job

                                           checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Ansible"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]

 

                                           //Checkout Scripts for Job

                                         

                                           checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "catalogue"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_ServiceCatalogue_Report.git']]]

}

 

 

 

def Preparation () {

             

                             date_now = new Date().format("dd_MM_YYYY")

                             displayName = "SERVICE_CATALOGUE_${date_now}_${BUILD_NUMBER}"

                             currentBuild.displayName = "${displayName}"

                           

                             sh '''

                                           cp -r ${WORKSPACE}/Ansible/SERVICE_CATALOGUE_Scripts ${WORKSPACE}/SERVICE_CATALOGUE_Scripts

                                           rm -R  ${WORKSPACE}/Ansible

                                           chmod -R 766 ${WORKSPACE}/catalogue/* ${WORKSPACE}/SERVICE_CATALOGUE_Scripts/*

                             '''

}

              // Email Body Generation with Result_Status                    

def get_body_build_summary(){

                             def date = new Date();

                             def sdf = new SimpleDateFormat("dd/MM/yyyy  HH:mm");

                             def date_time = sdf.format(date)

                           

             

                             def body_build_summary = """

                                                          <style type="text/css">

                                                          .tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}

                                                          .tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}

                                                          .tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#fff;background-color:#409cff;}

                                                          .tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}

                                                          .tg .tg-2wig{font-weight:bold;text-align:center;vertical-align:top}

                                                          .tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}

                                                          .tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}

                                                          .tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}

                                                          .tg .tg-0lax{text-align:left;vertical-align:top}

                                                          </style>

                                                          </style>

                                                          <table class="tg" style="undefined;table-layout: fixed; width: 100%">

                                                          <colgroup>

                                                          <col style="width: 90px">

                                                          <col style="width: 90px">

                                                          <col style="width: 90px">

                                                          <col style="width: 90px">

                                                          </colgroup>

                                                            <tr>

                                                                        <th class="tg-amwm" colspan="6">SERVICE_CATALOGUE_REPORT</th>

                                                            </tr>

                                                            <tr>

                                                                        <td class="tg-1wig" colspan="2">Date</td>

                                                                        <td class="tg-0lax" colspan="4">${date_time}</td>

                                                            </tr>

                                                            <tr>    

                                                                        <td class="tg-1wig" colspan="2">Status</td>

                                                                        <td class="tg-0lax" colspan="4">${Status}</td>

                                                            </tr>

                                                            <tr>    

                                                                        <td class="tg-1wig" colspan="2">BUILD_URL</td>

                                                                        <td class="tg-0lax" colspan="4">${BUILD_URL}</td>

                                                            </tr>

                                                            <tr>    

                                                                        <th class="tg-2wig" colspan="2">TYPE</th>

                                                                        <th class="tg-2wig" colspan="2">STATUS</th>

                                                                        <th class="tg-2wig" colspan="2">DURATION</th>

                                                            </tr>

                                                            <tr>

                                                                        <td class="tg-1wig" colspan="2">RIG2_Conf</td>

                                                                        <td class="tg-0lax" colspan="2">${rig2_conf}</td>

                                                                        <td class="tg-0lax" colspan="2">${RIG2_Duration} Seconds</td>

                                                            </tr>

                                                            <tr>

                                                                        <td class="tg-1wig" colspan="2">GW_CONF</td>

                                                                        <td class="tg-0lax" colspan="2">${gw_conf}</td>

                                                                        <td class="tg-0lax" colspan="2">${GW_Duration} Seconds</td>

                                                            </tr>

                                                            <tr>

                                                                        <td class="tg-1wig" colspan="2">CATALOGUE_CAP_TIL</td>

                                                                        <td class="tg-0lax" colspan="2">${catalogue_cap_TIL}</td>

                                                                        <td class="tg-0lax" colspan="2">${TIL_Duration} Seconds</td>

                                                            </tr>

                                                          </table>

                                                         

                                                          <br><br><br>

                             """

                             emailBody = body_build_summary

                             return body_build_summary

}

 

 

def dev_mailRecipients = "bhargav.sutapalli2@vodafone.com, bronwyn.davies@vodafone.com, raj.kandakatla1@vodafone.com, j.raghavendra@vodafone.com"

def ENV = "Prod"

 

pipeline{

              agent any

              environment {

                             TIL_Duration = ""          

                             RIG2_Duration = ""

                             GW_Duration = ""

                             Status = ""

                             rig2_conf = ""

                             catalogue_cap_TIL = ""

                             gw_conf = ""


              }

             

              stages{

                             stage ('Service Catalogue Generation') {

                                           steps {

                                                          script {

                                                                                                   

                                                                        cleanWs()

                                                                        Git_Checkout ()

                                                                        Preparation ()

                                                                       

                                                          // Ansible Playbook for Rig2_conf.sh Execution            

                                                                                     

                                                          RIG2_Duration = elapsedTime {

                                                                        ansiColor('xterm') {

                                                                                      ansiblePlaybook(playbook: "${WORKSPACE}/SERVICE_CATALOGUE_Scripts/Service_Catalogue_RIG2.yml", colorized: true, extras:'-v', extraVars: [host: "SCG_RIG2", WORKSPACE: "${WORKSPACE}", env: "${ENV}"])

                                                                        }

                                                          }

                                                                        RIG2_Duration = RIG2_Duration*0.001

                                                                        println("RIG2 Duration in Sec: " + RIG2_Duration)

 

                                                          // Ansible Playbook for Gw_conf.sh Execution                                                                                                    

                                                                                   

                                                          GW_Duration = elapsedTime {

                                                                        ansiColor('xterm') {

                                                                                      ansiblePlaybook(playbook: "${WORKSPACE}/SERVICE_CATALOGUE_Scripts/Service_Catalogue_GW.yml", colorized: true, extras:'-v', extraVars: [host: "SCG_GW", WORKSPACE: "${WORKSPACE}", env: "${ENV}"])

                                                                        }

                                                          }

                                                                        GW_Duration = GW_Duration*0.001

                                                                        println("RIG2 Duration in Sec: " + GW_Duration)

                                                         

                                                          // Ansible Playbook for catalogue_cap_TIL.sh Execution                                                                                                

                                                                                                                 

                                                          TIL_Duration = elapsedTime {

                                                                        ansiColor('xterm') {

                                                                                      ansiblePlaybook(playbook: "${WORKSPACE}/SERVICE_CATALOGUE_Scripts/Service_Catalogue_TIL.yml", colorized: true, extras:'-v', extraVars: [host1: "SCG_EMS1", host2: "SCG_EMS2", host3: "SCG_BWA", host4: "SCG_BW2", host5: "SCG_BW1", WORKSPACE: "${WORKSPACE}", env: "${ENV}"])

                                                                        }

                                                          }

                                                                        TIL_Duration = TIL_Duration*0.001

                                                                        println("RIG2 Duration in Sec: " + TIL_Duration)

                                                                                                                 

                                                                       

                           

                             if(fileExists("${WORKSPACE}/gw_conf_error.log")) {

                                           def statusFile1 = new File("${WORKSPACE}/gw_conf_error.log")

                                           def statusContent1 = statusFile1.readLines()

                           

                                           if (statusContent1.size() != 0 ) {

                                                          if(statusContent1[-1].contains('warning') || statusContent1[-1].contains('Broken') || statusContent1[-1].contains('security policy violations')) {

                                                                        gw_conf = "SUCCESS"

                                                                        Status = "SUCCESS"

                                                                        //new File('${WORKSPACE}/gw_conf_error.log').delete()

                                                                        sh 'mv ${WORKSPACE}/gw_conf_error.log ${WORKSPACE}/catalogue/gw_conf_error.log'

                                                          } else {

                                                                        gw_conf = "FAILED"

                                                                        Status = "FAILED"

                                                          }

                                           } else {

                                                          gw_conf = "SUCCESS"

                                                          Status = "SUCCESS"

                                                          sh 'mv ${WORKSPACE}/gw_conf_error.log ${WORKSPACE}/catalogue/gw_conf_error.log'

                                                          }

                             }

                           

                             if(fileExists("${WORKSPACE}/rig2_conf_error.log")) {

                                           def statusFile2 = new File("${WORKSPACE}/rig2_conf_error.log")

                                           def statusContent2 = statusFile2.readLines()

                                       

                                           if ( statusContent2.size() != 0 ) {

                                                          if(statusContent2[-1].contains('warning') || statusContent2[-1].contains('Broken') || statusContent2[-1].contains('security policy violations')) {

                                                                        rig2_conf = "SUCCESS"

                                                                        Status = "SUCCESS"

                                                                        sh 'mv ${WORKSPACE}/rig2_conf_error.log ${WORKSPACE}/catalogue/rig2_conf_error.log'                            

                                                          } else {

                                                                        rig2_conf = "FAILED"

                                                                        Status = "FAILED"

                                                          }

                                           } else {

                                                          rig2_conf = "SUCCESS"

                                                          Status = "SUCCESS"

                                                          sh 'mv ${WORKSPACE}/rig2_conf_error.log ${WORKSPACE}/catalogue/rig2_conf_error.log'

                                                          }

                             }

                                                                       

                             if(fileExists("${WORKSPACE}/catalogue_cap_TIL_error.log")) {

                                           def statusFile = new File("${WORKSPACE}/catalogue_cap_TIL_error.log")

                                           def statusContent = statusFile.readLines()

                           

           if (statusContent.size() != 0 ) {

                                                          if(statusContent[-1].contains('warning') || statusContent[-1].contains('Broken') || statusContent[-1].contains('security policy violations')) {

                                                                        catalogue_cap_TIL = "SUCCESS"

                                                                        Status = "SUCCESS"

                                                                        sh 'mv ${WORKSPACE}/catalogue_cap_TIL_error.log ${WORKSPACE}/catalogue/catalogue_cap_TIL_error.log'                                                        

                                                          } else {

                                                                        catalogue_cap_TIL = "FAILED"

                                                                        Status = "FAILED"

                                                          }

                                           } else {

                                                          catalogue_cap_TIL = "SUCCESS"

                                                          Status = "SUCCESS"

                                                          sh 'mv ${WORKSPACE}/catalogue_cap_TIL_error.log ${WORKSPACE}/catalogue/catalogue_cap_TIL_error.log'

                                           }

                             }

                                 

 

 

                                           // Email for Failed all Execution              

                                           if( "${gw_conf}" == "FAILED" || "${catalogue_cap_TIL}" == "FAILED" || "${rig2_conf}" == "FAILED" ) {

                           

                                                          def promotion_email_body = " Script Execution Failed and for log Check Jenkins Console Output "

                                                          def emailBody = "${get_body_build_summary()}"

                                                          emailext  mimeType: 'text/html', attachmentsPattern: 'rig2_conf_error.log,catalogue_cap_TIL_error.log,gw_conf_error.log,Catalogue_IS-TS-RIG2-GW_*.csv,til_ifc.csv,envurl.csv,procurl.csv,gw.csv,rig.csv,til_ifc_TS.csv,dep_mode.csv,final_b.csv,final.csv,backend.out,refdb.out,reftb.out,intrnl.out,cnfg.out,sOAP.out,cdm.out,sb_q.out,cb1.out,HLR.out',

                                                          subject: "[Jenkins]:Service Catalogue Report - ${Status}",

                                                          from:"Service_Catalogue_Generation@vodafone.com",

                                                          to: "${dev_mailRecipients}",
														  attachLog: true,

                                                          body:     "${emailBody}"              

                                                         

                                                          error ("Job Failed Due to Execution Failed")

                                                         

                             }

                                                         

                                                          // Email for Sucess all Execution              

                                         

                                                          def emailBody = "${get_body_build_summary()}"

                                                          emailext  mimeType: 'text/html', attachmentsPattern: 'Catalogue_IS-TS-RIG2-GW_*.csv,til_ifc.csv,envurl.csv,procurl.csv,gw.csv,rig.csv,til_ifc_TS.csv,dep_mode.csv,final_b.csv,final.csv,backend.out,refdb.out,reftb.out,intrnl.out,cnfg.out,sOAP.out,cdm.out,sb_q.out,cb1.out,HLR.out',

                                                          subject: "[Jenkins]:Service Catalogue Report - ${Status}",

                                                          from:"Service_Catalogue_Generation@vodafone.com",

                                                          to: "${dev_mailRecipients}",
														  attachLog: true,

                                                          body:     "${emailBody}"

                                                                       

                                                         

                                                          }

                                         

                                           }

                             }

              }

}
