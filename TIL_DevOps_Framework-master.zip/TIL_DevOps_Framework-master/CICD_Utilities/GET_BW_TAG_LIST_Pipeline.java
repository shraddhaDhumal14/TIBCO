def checkout_git_repositories() {
	// Checkout BW Configuration Repository
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "APPLICATION"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_BW_Application_Configuration.git']]]	
}

pipeline{
	agent any
	stages {
		stage('SetUp'){
			steps {
				script {
					// Checkout GIT repository.
					deleteDir()
					checkout_git_repositories()
					
					try {
						def tag_list = sh(script: "cd APPLICATION; git tag --list | grep ${ENGINE_NAME}_*",returnStdout: true).trim()
						println("GIT TAG's for the engine:" + ENGINE_NAME)
						println(tag_list)
					} catch (err) {
						echo err.getMessage()
						echo "No Tags created for the given engine: ${ENGINE_NAME}"
					}					
				}
			}
		}
	}
}