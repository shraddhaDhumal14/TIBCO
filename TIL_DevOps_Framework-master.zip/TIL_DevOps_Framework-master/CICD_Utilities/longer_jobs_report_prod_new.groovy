def getBuildUserID(){
    if(currentBuild.getBuildCauses('hudson.triggers.TimerTrigger$TimerTriggerCause'))
            return "time_triggered"
    else if(currentBuild.getBuildCauses('hudson.model.Cause$UpstreamCause'))
    {
           def upstreamCause = currentBuild.rawBuild.getCause(Cause.UpstreamCause)
           def upstreamJob = Jenkins.getInstance().getItemByFullName(upstreamCause.getUpstreamProject(), hudson.model.Job.class)
           if (upstreamJob) {
                    def upstreamBuild = upstreamJob.getBuildByNumber(upstreamCause.getUpstreamBuild())
                    if (upstreamBuild) {
                            def realUpstreamCause = upstreamBuild.getCause(Cause.UserIdCause)
                            if (realUpstreamCause) {
                                    return realUpstreamCause.getUserId()
                            }
                    }
            }
            return "Upstream Triggered"
     }
    else
            return currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId()
}

@NonCPS
def checkExecutors()
{
      final jenkins = Jenkins.instance
def jobMap = [:]
for (def computer in jenkins.computers)
{
               for (def exec in computer.executors)
         {
           if(exec.isBusy())
              {  
                if (exec.getTimestampString().contains("days"))
                {
                      days = exec.getTimestampString().split(" ")[0] as int
                      if(days > 7)
                      {
                        jobMap.put(exec.executable.getDisplayName(), exec.getTimestampString(), exec.executable.getBuildUserID())
                      }
                }                
              }
         }
}
println(jobMap)
jobMap = jobMap.sort {a, b, c -> b.value <=> a.value, c.value}
emailBody = ""
println(jobMap)
jobMap.each { key, value -> 
                   emailBody += "<tr>"
                   emailBody += "<td>" + value + " days" + "</td>"
                   try
                   {
                       row = ""
                       row += "<td colspan='8'>" + key.toString().split("CCS")[0].split('»') + "</td>"
                       row += "<td colspan='8'>" + "CCS" + key.toString().split("CCS")[1] + "</td>"
                       emailBody += row
                   }
                   catch(Exception ex)
                   {
                      emailBody += "<td colspan='16'>" + key.toString() +"</td>"
                   }
				   emailBody += "<td>" + value + " Started By" + "</td>"
                   emailBody += "</tr>"
                   //println value + "days##" + key.toString().split("CCS")[0].split('»') + "##CCS" + key.toString().split("CCS")[1]
                }
if(emailBody != "")
{
     emailHead = """
                            <style type="text/css">
                                .tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
                                .tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;width:150px;word-break:break-all;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
                                .tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:break-all;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
                                .tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
                                .tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
                                .tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
                                .tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
                                .tg .tg-0lax{text-align:left;vertical-align:top}
                                .tg .tg-pass{background-color:lightgreen;text-align:left;vertical-align:top}
                                .tg .tg-fail{background-color:red;text-align:left;vertical-align:top}
                                .tg .tg-notstarted{background-color:lightgrey;text-align:left;vertical-align:top}
                                .tg .tg-notrequired{background-color:#E1E0A2;text-align:left;vertical-align:top}
                            </style>
                         """
    emailBody = "<table class='tg' style='undefined;table-layout: fixed; width:100%'><tr><th>Days</th><th colspan='16'>Job Name</th><th>Started By</th></tr>" + emailBody + "</table>"
            emailBody = emailHead +  emailBody
            
    emailext mimeType: 'text/html',
         subject: "[Jenkins]:Longer Job Report",
         from:"Jenkins_Automation@vodafone.com",
         to: "${mailRecipients}",
         body: 	"${emailBody}" + "<br>" + 
                "<br><br><p><b><font size='5' color='Black'>Longer Jobs Report  <a href='${BUILD_URL}input'>${currentBuild.displayName}</a></font></b></p>" 
}
}

mailRecipients = "sweety.kumari@vodafone.com"

pipeline{
agent any
	stages {
		stage ('Longer Jobs') {
			steps {
				script {
                    checkExecutors()
                }
			}
		}
     }
}
