
// CICD-1424: Restrict promotion activity to only tech leads.
def get_approvers_list(String str){
	outlist = sh (script: """cat /opt/tibco/.jenkins/config.xml | sed -n \'/role name=\"${str}\"/,\$p\' | sed \'/role>/q\' | grep "sid" | cut -d \'>\' -f 2 | cut -d \'<\' -f 1 | paste -s -d, -""",
			returnStdout: true).trim()
	return """${outlist}"""
}


pipeline {
    agent any
    environment {
		REPO_URL = "http://195.233.197.150:8081/repository"
		NEXUS_URL = "http://195.233.197.150:8081"
		NEXUS_USER = "admin"
		NEXUS_PASSWD = "admin123"
		BW_GROUPID = "TIL_BW"
		EMS_GROUPID = "TIL_EMS"
		SQL_GROUPID="TIL_SQL"
		GATEWAY_GROUPID="GATEWAY"
    }
    stages {
		stage('PROMOTE_ARTEFACTS') {
			steps {
				script{
					// CICD-1424: Restrict promotion activity to only tech leads.
					LinkTestBWApprovers = get_approvers_list('LinkTestBWApprovers')
					user = currentBuild.rawBuild.causes[0].userId
					if(LinkTestBWApprovers.contains(user)){
					
						if(GATEWAY_PROMOTE_ARTEFACTS.length() != 0){
								GATEWAY_PROMOTE_ARTEFACTS.split(';').each { GATEWAY_ENTRY ->
									gateway_type = GATEWAY_ENTRY.split(':')[0]
									gateway_ver = GATEWAY_ENTRY.split(':')[1]
									
									artifactPromotion artifactId: gateway_type, classifier: '', debug: true, extension: 'tar.gz', groupId: "${env.GATEWAY_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.TARGET_REPO}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.SOURCE_REPO}", stagingUser: "${env.NEXUS_USER}", version: gateway_ver
									artifactPromotion artifactId: gateway_type, classifier: '', debug: true, extension: 'Readme', groupId: "${env.GATEWAY_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.TARGET_REPO}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.SOURCE_REPO}", stagingUser: "${env.NEXUS_USER}", version: gateway_ver
							}
						}					
						if(BW_PROMOTE_ARTEFACTS.length() != 0){
								BW_PROMOTE_ARTEFACTS.split(';').each { BW_ENTRY ->
									bw_eng = BW_ENTRY.split(':')[0]
									bw_ver = BW_ENTRY.split(':')[1]
									
									artifactPromotion artifactId: bw_eng, classifier: '', debug: true, extension: 'ear', groupId: "${env.BW_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.TARGET_REPO}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.SOURCE_REPO}", stagingUser: "${env.NEXUS_USER}", version: bw_ver
									artifactPromotion artifactId: bw_eng, classifier: '', debug: true, extension: 'appconf', groupId: "${env.BW_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.TARGET_REPO}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.SOURCE_REPO}", stagingUser: "${env.NEXUS_USER}", version: bw_ver
									artifactPromotion artifactId: bw_eng, classifier: '', debug: true, extension: 'html', groupId: "${env.BW_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.TARGET_REPO}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.SOURCE_REPO}", stagingUser: "${env.NEXUS_USER}", version: bw_ver
									artifactPromotion artifactId: bw_eng, classifier: '', debug: true, extension: 'proddiff', groupId: "${env.BW_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.TARGET_REPO}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.SOURCE_REPO}", stagingUser: "${env.NEXUS_USER}", version: bw_ver
									artifactPromotion artifactId: bw_eng, classifier: '', debug: true, extension: 'txt', groupId: "${env.BW_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.TARGET_REPO}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.SOURCE_REPO}", stagingUser: "${env.NEXUS_USER}", version: bw_ver
							}
						}
						if(EMS_PROMOTE_ARTEFACTS.length() != 0){
								EMS_PROMOTE_ARTEFACTS.split(';').each { EMS_ENTRY ->
									ems_eng = EMS_ENTRY.split(':')[0]
									ems_ver = EMS_ENTRY.split(':')[1]
									
									artifactPromotion artifactId: ems_eng, classifier: '', debug: true, extension: 'tar.gz', groupId: "${env.EMS_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.TARGET_REPO}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.SOURCE_REPO}", stagingUser: "${env.NEXUS_USER}", version: ems_ver
									artifactPromotion artifactId: ems_eng, classifier: '', debug: true, extension: 'txt', groupId: "${env.EMS_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.TARGET_REPO}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.SOURCE_REPO}", stagingUser: "${env.NEXUS_USER}", version: ems_ver
							}
						}
						if(SQL_PROMOTE_ARTEFACTS.length() != 0){
								SQL_PROMOTE_ARTEFACTS.split(';').each { SQL_ENTRY ->
									sql_eng = SQL_ENTRY.split(':')[0]
									sql_ver = SQL_ENTRY.split(':')[1]
									
									artifactPromotion artifactId: sql_eng, classifier: '', debug: true, extension: 'tar.gz', groupId: "${env.SQL_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.TARGET_REPO}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.SOURCE_REPO}", stagingUser: "${env.NEXUS_USER}", version: sql_ver
									artifactPromotion artifactId: sql_eng, classifier: '', debug: true, extension: 'txt', groupId: "${env.SQL_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.TARGET_REPO}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.SOURCE_REPO}", stagingUser: "${env.NEXUS_USER}", version: sql_ver
							}
						}
					} else {
						println("DEBUG: Current user is not authorized to promote artefacts. Users allowed to promote are: " + LinkTestBWApprovers)
						error("ERROR: Current user is not authorized to promote artefacts")
					}
				}
			}
		}
	}
}


