def get_approvers_list(String str){
	outlist = sh (script: """cat /opt/tibco/.jenkins/config.xml | sed -n \'/role name=\"${str}\"/,\$p\' | sed \'/role>/q\' | grep "sid" | cut -d \'>\' -f 2 | cut -d \'<\' -f 1 | paste -s -d, -""",
			returnStdout: true).trim()
	return """${outlist}"""
}


def checkout_git_repositories() {
	// Checkout Automation Framework repo from GITHUB
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "AUTOMATION"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
}
user = ""
//def ENV = ""
pipeline{
	agent any
	environment {
		ENV = ""
	}
	stages {
		 
		stage('REMOVE_FACTS'){
			steps{
				script{
					// Set up Workspace.
					deleteDir()
					checkout_git_repositories()		
					if ( "${params.FACT_TYPE}" == "bw"){
						ENV = "${params.ENVIRONMENT}_BW"
					//	println "${ENV}"
					}else {
						ENV = "${params.ENVIRONMENT}"
					}
					
					//Run ansible play book to remove facts from facts file.
					StagingUser = get_approvers_list('Staging')
					println("DEBUG: Staging admin users are: " + StagingUser)
					user = currentBuild.rawBuild.causes[0].userId
					if(StagingUser.contains(user)){
						ansiColor('xterm') {
							ansiblePlaybook(playbook: "./AUTOMATION/Utils/remove_facts/removeEngineFromFactsFile.yml", colorized: true, extras:'', extraVars: [env_type: "${ENV}", remove_engines: "${params.ENGINE_NAME}", release: "${params.RELEASE}", facts_type: "${params.FACT_TYPE}"])
						}
					} else {
						println("DEBUG: Current user is not authorized to delete facts. Users allowed to delete are: " + StagingUser)
						error("Current user is not authorized to delete facts")
					}
				}
			}
		}
	}
}
