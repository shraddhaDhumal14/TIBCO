def load_groovy_files() {
	// This function is to load all groovy files, where in common functions will be kept.
	nexusFunc = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/nexusFunctions.groovy"
}

def checkout_git_repositories() {
	// This function is to checkout all the required GIT repositories.
	checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'JENKINS_FILE']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_DevOps_Framework.git']]])

	// Checkout Automation files from GITHUB repository.
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "AUTOMATION"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]	
}

majorVersion = ""
minorVersion = ""
UPLIFTMENT_REF_REPO = "PROD_REPO"
BW_ENV_REPO = "TIL_BW_Application_Configuration"
release_tags = ""
pipeline{
	agent any
	environment {
			REPO_URL = "http://195.233.197.150:8081/repository"
			NEXUS_URL = "http://195.233.197.150:8081"
			NEXUS_USER = "admin"
			NEXUS_PASSWD = "admin123"
			BW_GROUPID = "TIL_BW"
	}	
	stages{
		stage('DELETE_TAGS') {
			steps{
				script {
					
					deleteDir()
					
					// Checkout required GIT repositories.
					checkout_git_repositories()
		
					//Load all functions files from GIT. point to exact source file
					load_groovy_files()
					
					
					// Checkout BW_Applications repository for getting the tags for the given release.
					checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'TAGS_REPO']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: "https://github.vodafone.com/VFUK-INTEGRATION/${BW_ENV_REPO}.git"]]])
					
					// Get major version and minor version from RELEASE parameter. 
					majorVersion = RELEASE.split('CCS')[1].split('\\.')[0]
					minorVersion = RELEASE.split('CCS')[1].split('\\.')[1]
					
					// Get BW Tags created for the given release from the repository.
					release_tags = sh(returnStdout: true, script: "set +e; cd ./TAGS_REPO; git tag --list | grep \".*_${majorVersion}_${minorVersion}_[[:digit:]]\\{1,\\}\"; set -e")
					if(release_tags.length() != 0) {
						release_tags = release_tags.trim().readLines().join(';') + ';'
						println("DEBUG: Release tags are: " + release_tags)
						
						// Get production version for each of the engine and delete the corresponding tag from tag deletion.
						def BW_Versions = nexusFunc.get_engines_from_nexus target_repo: "${UPLIFTMENT_REF_REPO}", REPO_URL: "${env.NEXUS_URL}", GROUPID: "${env.BW_GROUPID}", version: "${majorVersion}_${minorVersion}", extn: "ear"
						println("BW Versions from nexus are: " + BW_Versions)
						
						if(BW_Versions.length() != 0) {
							String[] tags = BW_Versions.split(";");
							for (String git_tag : tags) {
								println("DEBUG: remove tag: " + git_tag.replaceAll(":","_"))
								release_tags = release_tags.minus(git_tag.replaceAll(":","_") + ';')
							}
						}
						final_delete_tags = release_tags.substring(0, release_tags.length() - 1)
						println("Final tags to delete are: " + final_delete_tags)
						
						// Call ansible job to delete all the tags from repository.
						if(final_delete_tags.length() != 0) {
							ansiColor('xterm') {
								ansiblePlaybook(playbook: "./AUTOMATION/Utils/DELETE_TAGS/git_delete_tags.yml", colorized: true, extras:'', extraVars: [tags_list: final_delete_tags.replaceAll(";"," "), EnvironmentRepository: "${BW_ENV_REPO}"])
							}
						}
					} else {
						println("DEBUG: No tags present in repository for ${RELEASE}")
					}
					echo "END OF THE PIPELINE"
				}
			}
		}
	}
}