import java.text.*
import groovy.time.*

date = new Date();
sdf = new SimpleDateFormat("yyyyMMddHHmmss");
date_time = sdf.format(date)
date_now = new Date().format( 'dd-MM-yyyy' )

def elapsedTime(Closure closure){
    def timeStart = new Date()
    closure()
    def timeStop = new Date()
    return TimeCategory.minus(timeStop, timeStart).toMilliseconds()
}
                
def get_env_details (){
    
      checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false,extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "AUTOMATION"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
      
      checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false,extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "EnvConfig"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_TestEnv_Configurations.git']]]
      
      DEPLOY_FILE = "${WORKSPACE}/EnvConfig/BW_Configuration/${ENV}/Deployment.properties"
      sh "dos2unix ${WORKSPACE}/AUTOMATION/BW_Soap_Log/*.sh"
      sh "cp ${WORKSPACE}/AUTOMATION/BW_Soap_Log/*.sh ${WORKSPACE}/"
      Domain = sh(script: "sh ${WORKSPACE}/getDeployConfig.sh ${DEPLOY_FILE} Domain", returnStdout: true)
      TRA_HOME = sh(script: "dirname \$(sh ${WORKSPACE}/getDeployConfig.sh ${DEPLOY_FILE} TRA_HOME)", returnStdout: true)
      ENGINE_HOME = "${TRA_HOME}/domain/${Domain}/application/${ENGINE_NAME}"
      echo "ENGINE_HOME ==> ${ENGINE_HOME}"
      ENGINE_HOME = ENGINE_HOME.replaceAll("\n","")
      echo "ENGINE_HOME ==> ${ENGINE_HOME}"
                         
      
    }

def  Preparation (){

    displayName = "${BUILD_NUMBER}_${CRQ}"
    currentBuild.displayName = "${displayName}"
    get_env_details()
    
    writeFile file: "ADDL_CONFIG.tra", text: "${ADDL_CONFIG}"
    sh "echo '' >> ADDL_CONFIG.tra"
    sh "dos2unix ADDL_CONFIG.tra"
    sh "mv ${WORKSPACE}/ADDL_CONFIG.tra  ${WORKSPACE}/AUTOMATION/BW_Soap_Log/ADDL_CONFIG.tra"   

     ansiColor('xterm') 
     {
           ansiblePlaybook (playbook: "${WORKSPACE}/AUTOMATION/BW_Soap_Log/BW_Log_Preparation.yml", colorized: true, extras: '', extraVars: [host: "${ENV}_BW", date_time: "${date_time}", engine: "${ENGINE_NAME}", crq_num: "${CRQ}", engine_home: "${ENGINE_HOME}"])
     } 
     
     sh "cat ${WORKSPACE}/AUTOMATION/BW_Soap_Log/tra_files"
     tra_files_list = sh(script: "cat ${WORKSPACE}/AUTOMATION/BW_Soap_Log/tra_files", returnStdout: true)
      def userInput = input(
                    id:'userInput',message:"Select the tra file to Proceed",
                parameters: [                
                [$class: 'ChoiceParameterDefinition',choices:"${tra_files_list}",description:"Select the tra file to Proceed",name: 'TRA_FILE']                              
                    ])
      println(userInput)
     TRA_FILE = userInput

}

def updateTraFile()
{
    ansiColor('xterm') 
     {
           ansiblePlaybook (playbook: "${WORKSPACE}/AUTOMATION/BW_Soap_Log/BW_Log_UpdateTRA.yml", colorized: true, extras: '', extraVars: [host: "${ENV}_BW", date_time: "${date_time}", engine: "${ENGINE_NAME}", crq_num: "${CRQ}", engine_home: "${ENGINE_HOME}", TRA_FILE: "${TRA_FILE}"])
     } 
}

def rollbackTraFile()
{
    ansiColor('xterm') 
     {
           ansiblePlaybook (playbook: "${WORKSPACE}/AUTOMATION/BW_Soap_Log/BW_Log_RollbackTRA.yml", colorized: true, extras: '', extraVars: [host: "${ENV}_BW", date_time: "${date_time}", engine: "${ENGINE_NAME}", crq_num: "${CRQ}", engine_home: "${ENGINE_HOME}", TRA_FILE: "${TRA_FILE}"])
     } 
}


def get_conf_files_restart(deployParams) {
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}_Conf"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_BW_Application_Configuration.git']]]
    // make a directory with conf
	sh "mkdir -p ./${deployParams.Host}_Conf/conf"
    echo "${deployParams.engines}"
	echo "${deployParams.folderName}"
    def engine_list = deployParams.engines.split(',')
		for (txt in engine_list) {
			echo "${txt}"
			def eng_conf = txt
			echo eng_conf
			// check if engine input has folder name associated 
			if(eng_conf.contains('/')){
				def engine_params = eng_conf.split('/')
				def folderName = engine_params[0]
				def engine_name = engine_params[1]
				// copy appconf file from master repository
				sh "cp ./${deployParams.Host}_Conf/Restart_Configurations/Restart_Template.appconf ./${deployParams.Host}_Conf/conf/${engine_name}.appconf"
			
				// update values of appconf with Folder name provided during deployment
				sh  "sed -i '/FolderName=/ s/=.*/=${folderName}/'  ./${deployParams.Host}_Conf/conf/${engine_name}.appconf"
		  
				
			}
			else{

			sh "cp ./${deployParams.Host}_Conf/Restart_Configurations/Restart_Template.appconf ./${deployParams.Host}_Conf/conf/${eng_conf}.appconf"
			sh  "sed -i '/FolderName=/ s/=.*/=${deployParams.folderName}/'  ./${deployParams.Host}_Conf/conf/${engine_name}.appconf"
			}	

	   }
}




def deploy_restart_bw(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
			
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "RESTART_ENV"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_TestEnv_Configurations.git']]]
			
            
			// create directory with name conf to copy config files
			sh "mkdir -p ./${deployParams.Host}/BW_Deployment/conf"
			
			// Copy deployment conf files  to conf directory in deployment script 
			
			sh "cp -r ./${deployParams.Host}_Conf/conf/* ./${deployParams.Host}/BW_Deployment/conf"
       
           	sh "mkdir -p ./${deployParams.Host}/BW_Deployment/host_vars/${deployParams.Host}_BW"

			// Copy Environment specififc files to Ansible Host Vars 
			sh "cp -r ./RESTART_ENV/BW_Configuration/${deployParams.Host}/* ./${deployParams.Host}/BW_Deployment/host_vars/${deployParams.Host}_BW"
			
			
		
			//Run ansible playbook to deploy artefacts into environment
			 ansiColor('xterm') {
    	     ansiblePlaybook(playbook: "./${deployParams.Host}/BW_Deployment/restartBW.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Host}_BW", engines: "${deployParams.engines}", datetime: "${deployParams.datetime}", crq_num: "${deployParams.crq_no}", bwDeployment: "${deployParams.bwDeployment}", bwRestart: "${deployParams.bwRestart}"])
	
		    }
    }
}

TRA_HOME=""
TRA_FILE=""
domain=""

pipeline {
    agent any
    environment {
            def Engine_List = "$ENGINE_NAME"
            dev_mailRecipients = "devops-vfuk-integration@vodafone.com"
    }
    
    stages {
        
        stage ('Preparation') {
            steps {
                script {
                  cleanWs()  
                  Preparation ()                    
                }
            }
        }
        
        
        stage ('Update TRA File') {
            steps {
                script {
                   echo "Update TRA file"
                   updateTraFile()
               }
            }
        }        
        
        
        stage ('Restart BW') {
            steps {
                script {
                              									
                    echo "Engines to restart are: ${Engine_List}"
                    input 'Proceed with  Engine Restart?'
                    get_conf_files_restart engines:"${Engine_List}", Host:"${ENV}", folderName:"${FOLDER_NAME}"
                    deploy_restart_bw Host:"${ENV}", crq_no:"${CRQ}", engines:"${Engine_List}", datetime:"${date_now}"
                     }
             }
        }
        
        stage ('Rollback TRA File') {
            steps {
                script {
                   input 'Proceed with  Rollback TRA?'
                   rollbackTraFile()
               }
            }
        } 

        stage ('Rollback - Restart BW') {
            steps {
                script {
                              									
                    echo "Engines to restart are: ${Engine_List}"
                    input 'Proceed with  Engine Restart?'
                    deploy_restart_bw Host:"${ENV}", crq_no:"${CRQ}", engines:"${Engine_List}", datetime:"${date_now}"
					                                            
                     }
             }
        }
   
                
    }
}
