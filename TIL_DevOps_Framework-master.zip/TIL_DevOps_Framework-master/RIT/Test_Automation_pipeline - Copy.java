import java.text.*
import groovy.time.*

//  Testing Related Email Body Preparation
  		
def get_body_build_summary(){
			def date = new Date();
            def sdf = new SimpleDateFormat("dd-MM-yyyy");
            def date_time = sdf.format(date)
			def statusFile = new File("${WORKSPACE}/Status.txt")
			def statusContent = statusFile.readLines() 
		
            if(statusContent[-1].contains('failed')){
               Status = "FAILED"
            }
			else if(statusContent[-1].contains(' 0 tests exe')){
                    Status = "FAILED"
            }					  
			else {
               Status = "SUCCESS"
                }
					
				//	 println Status
					
 def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
		.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		</style>
		</style>
		<table class="tg" style="undefined;table-layout: fixed; width: 1000px">
		<colgroup>
		<col style="width: 100px">
		<col style="width: 500px">
		<col style="width: 100px">
		<col style="width: 500px">
		</colgroup>
		  <tr>
			<th class="tg-amwm" colspan="2">TEST_AUTOMATION_SUMMARY</th>
		  </tr>
		  <tr>
			<td class="tg-1wig">Submitted By</td>
			<td class="tg-0lax">${currentBuild.getRawBuild().getCauses()[0].getUserId()}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">Date</td>
			<td class="tg-0lax">${date_time}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">Engine</td>
			<td class="tg-0lax">${ENGINE_NAME}</td>
		  </tr>
		  <tr>
		  <td class="tg-1wig">Operations</td>
			<td class="tg-0lax">${OPERATION_NAME}</td>
		  </tr>
		  <tr>
		  <td class="tg-1wig">Type</td>
			<td class="tg-0lax">${Test_Type}</td>
		  </tr>
		  <tr>	
			<td class="tg-1wig">Test_Result</td>
			<td class="tg-0lax">${bal}</td>
		  </tr>	
         <tr>	
		   <td class="tg-1wig">Status</td>
		   <td class="tg-0lax">${Status}</td>
		 </tr>
		</table>
		
		<br><br><br>
	"""
	emailBody = body_build_summary
	return body_build_summary
}

def Test_Suite_Exe(){

	displayName = "RIT_TestAutomation_${BUILD_NUMBER}"
	currentBuild.displayName = "${displayName}"
		
	def date = new Date();
	def sdf = new SimpleDateFormat("yyyyMMddHHmmss");
	def date_time = sdf.format(date)
	def Ant_File

	def file
	//def mailRecipients = "${Email}"
	def Status = ""
	//def userInput
	//def Input
	//def Input1
	//def Input2
	//def Input3
	//def Inputs
	def Pro = ""
	def Reg = ""
	def Pronot = ""
	def Regnot = ""
	def Eng = ""
	def Engnot = ""
	def Pro1 = ""
	def Pro2 = ""
	bal = ""
	def Reg1 = ""
	def Reg2 = ""
	Type = ""

	// Bulid Naming

	// displayName = "Test_Automation_${BUILD_NUMBER}"
	currentBuild.displayName = "Test_Automation_${BUILD_NUMBER}"

	  
	// cleaning workspace in Jenkins box
	cleanWs()

	//Checkout Rit Project
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/${GIT_BRANCH}']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Project"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/RIT_${ENGINE_NAME}.git']]]
	
	//Checkout Ansible Scripts			
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Script"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]

		
	def fil = "${WORKSPACE}" + "/" + "Project" + "/" + "${ENGINE_NAME}"
	//println "${fil}"
	// If Project present with Select Engine Request 
			
	if (fileExists(fil)) {	
					  
	 	sh '''
			cp -r ${WORKSPACE}/Project/${ENGINE_NAME}  ${WORKSPACE}/${ENGINE_NAME}_RIT
			cp -r ${WORKSPACE}/Script/Test_Automation_Scripts ${WORKSPACE}/Test_Automation_Scripts
			cd ${WORKSPACE}
			chmod 766 ${WORKSPACE}/${ENGINE_NAME}_RIT
		'''
			
			
	// If Operations Fien for Testing 
 
	if (OPERATION_NAME.length() != 0){
		def Ops = "${OPERATION_NAME}".split(',')
		if (Test_Type == "Progression") {
			for (Oper in Ops) {
  
				Ant_File = "${ENGINE_NAME}" + "_" + "${Oper}" + "_" + "Progression" + "." + "xml"	
				file = "${WORKSPACE}" + "/" + "${ENGINE_NAME}_RIT" + "/" + "Logical" + "/" + "AntScripts" + "/" + "${Ant_File}"	
	

				if (fileExists(file)) {
					println "${Ant_File} --->> Found"
					if (Pro.length() != 0){
			
						Pro = "${Pro}" + "," + "${Ant_File}"
						Pro1 = "${Pro1}" + "," + "${Oper}"
					}else {
			
						Pro = "${Ant_File}"
						Pro1 = "${Oper}"
			 
					}
				}else {
					println "${Ant_File} ---->> File not Found"
					if (Pronot.length() != 0){
			
						Pronot = "${Pronot}" + "," + "${Ant_File}"
					}else {
			
						Pronot = "${Ant_File}"
					}
				}			
			}
		}
		
		if (Test_Type == "Regression") {
			for (Oper in Ops) {
	  
				Ant_File = "${ENGINE_NAME}" + "_" + "${Oper}" + "_" + "Regression" + "." + "xml"	
				file = "${WORKSPACE}" + "/" + "${ENGINE_NAME}_RIT" + "/" + "Logical" + "/" + "AntScripts" + "/" + "${Ant_File}"	
		

				if (fileExists(file)) {
					println "${Ant_File} --->> Found"
					if (Reg.length() != 0){
			
						Reg = "${Reg}" + "," + "${Ant_File}"
						Reg1 = "${Reg1}" + "," + "${Oper}"
					
					}else {
			
						Reg = "${Ant_File}"
						Reg1 = "${Oper}"
					
					}
				}else {
					println "${Ant_File} ---->> File not Found"
					if (Regnot.length() != 0){
			
						Regnot = "${Regnot}" + "," + "${Ant_File}"
					}else {
				
						Regnot = "${Ant_File}"
					}
				}			
			}
		}
	}else {
		Ant_File = "${ENGINE_NAME}" + "_" + "Regression" + "." + "xml"
		file = "${WORKSPACE}" + "/" + "${ENGINE_NAME}_RIT" + "/" + "Logical" + "/" + "AntScripts" + "/" + "${Ant_File}"	
	

		if (fileExists(file)) {
			println "${Ant_File} ---->> File Found"
			Eng = "${Ant_File}"
		}else {
			println "${Ant_File} ---->> File not Found"
			Engnot = "${Ant_File}"
		}
	}
	if (Pronot.length() != 0 | Regnot.length() != 0 | Engnot.length() != 0) {

		// println "qwertyuioplkjbvcdrtyujmnbvftyuikmnbvgtyujkmnbvghjnb1234567890dsfghjkl=================="
		promotion_email_body = "ANT Files in the Project : ${Pro}${Reg} ${Eng}" + "<br>" + "<br>" + " ANT Files not found in the Project : ${Pronot}${Regnot}${Engnot}"

		emailext mimeType: 'text/html',
		subject: "[Jenkins]:${currentBuild.fullDisplayName}:Approval email for Continou the Testing or Skip ?",
		from:"TEST_AUTOMATION@vodafone.com",
		to: "${Email}",
		body: 	"${promotion_email_body}" + "<br>" + 
			"<br><br><p><b><font size='2' color='Black'>Click on below link for input to proceed for Test Continou: <a href='${BUILD_URL}input'>${BUILD_URL}</a></font></b></p>"

	
		error 'ANT files not found'
	}
	 //println "Process Going ON"
	
	
	sh '''
		file1="${WORKSPACE}/${ENGINE_NAME}_RIT/Logical/AntScripts/*.xml"
			
		# Replaces the windows parameters Values to RTCP Box Values in Ant Files   
			   
		sed -i 's#name="install.dir" value=.*/>#name="install.dir" value="/opt/SP/tibco/IBM/RationalIntegrationTester"/>#g' ${file1}
 		sed -i 's#environment=.* project#environment="'${Environments}'" project#g' ${file1}
		sed -i 's#basedir=.* default#basedir="./../.." default#g' ${file1}
			
		cd ${WORKSPACE}
		# Coverting the Total Project into tar file
		tar -czvf ${ENGINE_NAME}_RIT.tar.gz ${ENGINE_NAME}_RIT
			
	''' 
	// Executing Ansible Scripts for RIT Project Deployment Preparation in RTCP Box

	ansiColor('xterm') {
		ansiblePlaybook (playbook: "${WORKSPACE}/Test_Automation_Scripts/Preparation.yml", colorized: true, extras: '', extraVars: [host: "RIT_TEST", Engine_Name: "${ENGINE_NAME}_RIT", date_time: "${date_time}", Workspace: "${WORKSPACE}"])
	}
	
	// Ant File Execution for all OPerations Progression

	if (Pro.length() != 0)	{
		def Ops = "${Pro}".split(',')
			
		Pro2 = "${Pro1}".split(',')
		def i = 0
		for (Oper in Ops){	 
				
			// Executing Ansible Scripts for RIT Project Deploying in RTCP Box

			ansiColor('xterm') {
				ansiblePlaybook (playbook: "${WORKSPACE}/Test_Automation_Scripts/Test_Execution.yml", colorized: true, extras:'-v', extraVars: [host: "RIT_TEST", Ant_File: "${Oper}", Engine_Name: "${ENGINE_NAME}_RIT", date_time: "${date_time}", Workspace: "${WORKSPACE}", Log_File: "Pro_Result.log", file: "Pro_Status.txt"])
			}
				
		//	ansiColor('xterm') {
		//		ansiblePlaybook (playbook: "${WORKSPACE}/Test_Automation_Scripts/Cleanup.yml", colorized: true, extras:'', extraVars: [host: "RIT_TEST"])
		//	}
				
			def vesr = readFile "${WORKSPACE}/Pro_Status.txt"
			println vesr
			String[] str;
            str = vesr.split(']');
            // println str[4]
            def lol = str.length
            //  println lol
            lol = lol-1
                
			if (bal.length() !=0) {
				bal = "${bal}" + "," + Pro2[i] + " --->> " + str[lol] 
			}else {
				bal = Pro2[i] + " --->> " + str[lol]
			}
			println bal
			i = i+1
		}
			
		
		Type = "Progression"

		// finding the Log Results to Verify Whether All Test cases are Success/Failed	in Operation_Progression
				 
												
		def statusFile = new File("${WORKSPACE}/Pro_Status.txt")
        def statusContent = statusFile.readLines()
        if(statusContent[-1].contains('failed') || statusContent[-1].contains(' 0 tests exe')){
			Status = "FAILED"
		}else {
			Status = "SUCCESS"
        }
	
		//  println "${Status}"
		   
		// Approval mail send to TL if any one test cases failed in Operation_Progression 
		   
	    if (Status == "FAILED") {
		   
			def promotion_email_body = " Some Test cases are Failed in Operation_Proression Testing "	
			def emailBody = "${get_body_build_summary()}"
			emailext  mimeType: 'text/html', attachmentsPattern: 'Test_Result.log',
			subject: "[Jenkins]:System_Testing for Progression",
			from:"Test_Automation@vodafone.com",
			to: "${Email}",
			body: 	"${promotion_email_body}" + "<br>" + "${emailBody}" + "<br>" + 
			"<br><br><p><b><font size='2' color='Black'>TEST_AUTOMATION_BUILDURL: <a href='${BUILD_URL}input'>${BUILD_URL}</a></font></b></p>"	
			
			//println "Progression Testcases Failed"
			
			error 'Progression Testcases Failed'
			
		}

		if (Status == "SUCCESS") {
		 
			def promotion_email_body = " Operation_Proression Testing are Success"	
			def emailBody = "${get_body_build_summary()}"
			emailext  mimeType: 'text/html', attachmentsPattern: 'Test_Result.log',
			subject: "[Jenkins]:System_Testing for Progression",
			from:"Test_Automation@vodafone.com",
			to: "${Email}",
			body: 	"${promotion_email_body}" + "<br>" + "${emailBody}" + "<br>" + 
					"<br><br><p><b><font size='2' color='Black'>TEST_AUTOMATION_BUILDURL: <a href='${BUILD_URL}input'>${BUILD_URL}</a></font></b></p>"	
					
			return
		}
	}
		
	// Ant File Execution for all OPerations Regression	

	if (Reg.length() != 0) {
		def Ops = "${Reg}".split(',')
		Reg2 = "${Reg1}".split(',')
		bal = ""
		def i = 0
		for (Oper in Ops){	 
				
			// Executing Ansible Scripts for RIT Project Deploying in RTCP Box

			ansiColor('xterm') {
				ansiblePlaybook (playbook: "${WORKSPACE}/Test_Automation_Scripts/Test_Execution.yml", colorized: true, extras:'-v', extraVars: [host: "RIT_TEST", Ant_File: "${Oper}", Engine_Name: "${ENGINE_NAME}_RIT", date_time: "${date_time}", Workspace: "${WORKSPACE}", Log_File: "Reg_Result.log", file: "Reg_Status.txt"])
			}
				
	//		ansiColor('xterm') {
	//			ansiblePlaybook (playbook: "${WORKSPACE}/Test_Automation_Scripts/Cleanup.yml", colorized: true, extras:'', extraVars: [host: "RIT_TEST"])
	//		}
			
			def vesr = readFile "${WORKSPACE}/Reg_Status.txt"
			println vesr
			String[] str;
            str = vesr.split(']');
            // println str[4]
            def lol = str.length
            //  println lol
            lol = lol-1
                
			if (bal.length() !=0) {
				bal = "${bal}" + "," + Reg2[i] + " --->> " + str[lol] 
			}else {
				bal = Reg2[i] + " --->> " + str[lol]
			}
			// println bal
			i = i+1
		}
			
		Type = "Regression"

		// finding the Log Results to Verify Whether All Test cases are Success/Failed	in Operation_Regression
				 
												
		statusFile = new File("${WORKSPACE}/Reg_Status.txt")
		statusContent = statusFile.readLines()
        if(statusContent[-1].contains('failed') || statusContent[-1].contains(' 0 tests exe')){
            Status = "FAILED"
		}else {
			Status = "SUCCESS"
		}
		println "${Status}"
		   
		// Approval mail send to TL if any one test cases failed in Operation_Regression 
		   
	    if (Status == "FAILED") {
			    
			def promotion_email_body = " Some Test cases are Failed in Operation_Regression Testing "
			def emailBody = "${get_body_build_summary()}"
			emailext  mimeType: 'text/html', attachmentsPattern: 'Test_Result.log',
			subject: "[Jenkins]:System_Testing for Regression  ",
			from:"Test_Automation@vodafone.com",
			to: "${Email}",
			body: 	"${promotion_email_body}" + "<br>" + "${emailBody}" + "<br>" + 
				"<br><br><p><b><font size='2' color='Black'>TEST_AUTOMATION_BUILDURL: <a href='${BUILD_URL}input'>${BUILD_URL}</a></font></b></p>"	
				
		
			//println "Regression Testcases Failed"
			error 'Regression Testcases Failed'
		}
  
		if (Status == "SUCCESS") {

			def promotion_email_body = " Test cases Results in Operation_Regression Testing "	
			def emailBody = "${get_body_build_summary()}"
			emailext  mimeType: 'text/html', attachmentsPattern: 'Test_Result.log',
			subject: "[Jenkins]:System_Testing for Regression",
			from:"Test_Automation@vodafone.com",
			to: "${Email}",
			body: 	"${promotion_email_body}" + "<br>" + "${emailBody}" + "<br>" + 
				"<br><br><p><b><font size='2' color='Black'>TEST_AUTOMATION_BUILDURL: <a href='${BUILD_URL}input'>${BUILD_URL}</a></font></b></p>"
		
			return			
		}
	}
	
	if (Eng.length() != 0)  {
		bal = ""
			
		// Executing Ansible Scripts for RIT Project Deploying in RTCP Box
		
		ansiColor('xterm') {
			ansiblePlaybook (playbook: "${WORKSPACE}/Test_Automation_Scripts/Test_Execution.yml", colorized: true, extras:'-v', extraVars: [host: "RIT_TEST", Ant_File: "${Eng}", Engine_Name: "${ENGINE_NAME}_RIT", date_time: "${date_time}", Workspace: "${WORKSPACE}", Log_File: "Engine_Result.log", file: "Engine_Status.txt"])
		}
				
//		ansiColor('xterm') {
//			ansiblePlaybook (playbook: "${WORKSPACE}/Test_Automation_Scripts/Cleanup.yml", colorized: true, extras:'', extraVars: [host: "RIT_TEST"])
//		}
				
		def vesr = readFile "${WORKSPACE}/Engine_Status.txt"
		println vesr
		String[] str;
        str = vesr.split(']');
                   
        def lol = str.length
		//  println lol
        lol = lol-1
        bal =  "${ENGINE_NAME}" + " --->> " + str[lol] 
										
		statusFile = new File("${WORKSPACE}/Engine_Status.txt")
		statusContent = statusFile.readLines()
        if(statusContent[-1].contains('failed') || statusContent[-1].contains(' 0 tests exe')){
			Status = "FAILED"
		}else {
			Status = "SUCCESS"
		}
	
		println "${Status}"
		   
		// Approval mail send to TL if any one test cases failed in Operation_Regression 
		   
	    if (Status == "FAILED") {
			    
			def promotion_email_body = " Some Test cases are Failed in Engine_Regression Testing "
			def emailBody = "${get_body_build_summary()}"
			emailext  mimeType: 'text/html', attachmentsPattern: 'Test_Result.log',
			subject: "[Jenkins]:System_Testing for Regression  ",
			from:"Test_Automation@vodafone.com",
			to: "${Email}",
			body: 	"${promotion_email_body}" + "<br>" + "${emailBody}" + "<br>" + 
				"<br><br><p><b><font size='2' color='Black'>TEST_AUTOMATION_BUILDURL: <a href='${BUILD_URL}input'>${BUILD_URL}</a></font></b></p>"	
				
			//println "Regression Testcases Failed"
			error 'Engine Testcases Failed'
		}
	  
		if (Status == "SUCCESS") {
	 
			def promotion_email_body = " Test cases Results in Engine_Regression Testing "	
			def emailBody = "${get_body_build_summary()}"
			emailext  mimeType: 'text/html', attachmentsPattern: 'Test_Result.log',
			subject: "[Jenkins]:System_Testing for Regression",
			from:"Test_Automation@vodafone.com",
			to: "${Email}",
			body: 	"${promotion_email_body}" + "<br>" + "${emailBody}" + "<br>" + 
				"<br><br><p><b><font size='2' color='Black'>TEST_AUTOMATION_BUILDURL: <a href='${BUILD_URL}input'>${BUILD_URL}</a></font></b></p>"
		
		   return 
		  
		}	
	}
}

// If Engine Name Directory Not Present in Project
	else {
		println "Engine = ${ENGINE_NAME}  ------> Directory Not found in the GITHUB "
		  
		def promotion_email_body = "Artefacts Not found in the  GITHUB "
	
		emailext mimeType: 'text/html',
		subject: "[Jenkins]:${currentBuild.fullDisplayName}:Approval email for promote to Next Stage",
		from:"TEST_AUTOMATION@vodafone.com",
		to: "${Email}",
		body: "${promotion_email_body}" + "<br>" + 
		"<br><br><p><b><font size='2' color='Black'>Proceed to Next Stage Click on Promote: <a href='${BUILD_URL}input'>${BUILD_URL}</a></font></b></p>"

		error 'Project Not found in the GITHUB'
	}
	println "System Testing Success"
		  
}


def bal
def Type
//def Email = "nani.ponnada@vodafone.com"

pipeline {
	agent any
	
	stages {
		stage('System Testing') {
		//	when {
		//	expression { ENGINE_MAP[ENGINE_NAME]['BW_Restart'] == "PASSED" }
		//	}
			steps {
                script {
					
					Test_Suite_Exe ()
			
					
					println " ======>> Stage is Executed <<======"

				}
			}
		}
	}
}
