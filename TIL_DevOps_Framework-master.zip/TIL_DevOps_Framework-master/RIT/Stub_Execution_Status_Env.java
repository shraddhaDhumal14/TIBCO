import java.text.*
import groovy.time.*

def date = new Date();
def sdf = new SimpleDateFormat("yyyyMMddHHmmss");
date_time = sdf.format(date)

def Prepartion () {		
	
	// cleaning workspace in Jenkins WorkSpace
	cleanWs()

	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Automation"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
    
    checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "SV"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: "https://github.vodafone.com/VFUK-INTEGRATION/SV_Automation"]]]
    
    for(def Counter=0; Counter < envDetails.size(); Counter++)
    {
        row = envDetails[Counter];
        env_list = row['env_list'];
        for(envCounter=0; envCounter<env_list.size(); envCounter++)
          {
            env = env_list[envCounter];
            sh "echo ${env} >> envlist.txt"                                
          }
    }

	sh 'mkdir SV_Project && chmod 766 SV_Project'
    sh "sleep 5"
    sh "dos2unix ./Automation/SV_Automation/*.sh"
    sh "cp envlist.txt ./SV/AutomationSuite/Logical/AntScripts/"
    //deleteing existing reports before running reports
    sh "rm ./SV/AutomationSuite/Logical/Stub_Status_Logs/*.html"
    sh "cp ./Automation/SV_Automation/*.sh ./SV/AutomationSuite/Logical/AntScripts/"
    sh "chmod 777 SV"
    sh 'cp -rf ./SV/* ./SV_Project/'
    sh 'tar -czf SV_Project.tar.gz ./SV_Project*'
    base_dir="/home/tibco/SV_Automation/SV_${date_time}/SV_Project/AutomationSuite"
	
    ansiColor('xterm') {
			ansiblePlaybook (playbook: "${WORKSPACE}/Automation/SV_Automation/Preparation.yml", colorized: true, extras: '', extraVars: [host: "SV_Backend_TEST", date_time: "${date_time}", Workspace: "${WORKSPACE}"])
        }       
}

def Get_Report () {	
    ansiColor('xterm') {
			ansiblePlaybook (playbook: "${WORKSPACE}/Automation/SV_Automation/Stub_Status_Report.yml", colorized: true, extras: '', extraVars: [host: "SV_Backend_TEST", date_time: "${date_time}", base_dir: "${base_dir}", Ant_Path: "${Ant_Path}"])
        }   
}


def Mail_Report()  {	
    ansiColor('xterm') {
			ansiblePlaybook (playbook: "${WORKSPACE}/Automation/SV_Automation/Stub_Report_And_Cleanup.yml", colorized: true, extras: '', extraVars: [host: "SV_Backend_TEST", date_time: "${date_time}", Workspace: "${WORKSPACE}"])
        }
    sh "cp ./Automation/SV_Automation/stub_report_by_env.sh ./"
    sh "chmod 777 stub_report_by_env.sh"
    emailBody = ""
    for(def Counter=0; Counter < envDetails.size(); Counter++)
    {
      row = envDetails[Counter];
      domain = row['DomainName']
      mail_Receipts = row['EMail']
      sh "sh stub_report_by_env.sh ${domain}"
      emailBody = sh(script:"cat ./${domain}.html || exit 0", returnStdout: true).trim()
      emailext  mimeType: 'text/html', //attachmentsPattern: '${domain}.html',
					subject: "[Jenkins]:Service Virtualization – Stub Status Report – ${domain} Domain",
					from:"SV_Automation@vodafone.com",
					to: "${mail_Receipts},${ccmail_recepients}",
					body: 	"${emailBody}" + 
					"<p><b><font size='2' color='Black'>TEST_AUTOMATION_BUILDURL: <a href='${BUILD_URL}input'>${BUILD_URL}</a></font></b></p>"
    }
               
}

envDetails = [ ['DomainName' : 'TIL_APPLICATIONDELIVERY', 'env_list' : ['LNKTEST14','LNKTEST15','LNKTEST16','LNKTEST17'], 'EMail' : 'santhosh.mallini@vodafone.com, bhushan.vasantkhurge@vodafone.com, ranjith.sivapuram@vodafone.com, j.raghavendra@vodafone.com'],
               ['DomainName' : 'TIL_MULTIPLEXER', 'env_list' : ['T1','T3','T4','T8','SIT04','T7'], 'EMail' : 'DL-VESTibcoSupport@vodafone.com']
             ]

base_dir = ""
Ant_Path="/home/tibco/apache-ant/apache-ant-1.10.8/bin"
ccmail_recepients="cc:showmi.ravi@vodafone.com,cc:padmaja.balamurugan@vodafone.com, cc:prasanth.kathiresan@vodafone.com,cc:sathish.kumar3@vodafone.com,cc:suba.masanamuthu@vodafone.com,cc:anushiya.kumar@vodafone.com,cc:prabhakaran.sundararajan@vodafone.com,cc:abhijeet.karmalkar@vodafone.com"

pipeline{
	agent any
	options {
        	preserveStashes(buildCount: 1)
   	}

	stages {
		stage ('Prepartion') {
			steps {
				script {
					currentBuild.displayName = "SV_Report_${BUILD_NUMBER}"
                    Prepartion ()
				}
			}
		}
		
        
		stage ('Get Report') {
			steps {
				script {
                        Get_Report()
				}
			}
		}
        
        stage ('Send Mail') {
			steps {
				script {                        
                        Mail_Report()
				}
			}
		}


	}
}

