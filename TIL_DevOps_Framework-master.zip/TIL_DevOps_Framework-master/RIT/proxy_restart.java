import java.text.*
import groovy.time.*

import hudson.tasks.Mailer;
import hudson.model.User;


def getUserEmail(String id=null) {
    User user = User.getById(id ?: currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId(), false)
    user?.getProperty(Mailer.UserProperty.class).getAddress()
}

def getBuildUserID(){
    if(currentBuild.getBuildCauses('hudson.triggers.TimerTrigger$TimerTriggerCause'))
            return ""
    else
            return currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId()
}

def date = new Date();
def sdf = new SimpleDateFormat("yyyyMMddHHmmss");
date_time = sdf.format(date)
sdf = new SimpleDateFormat("MMM_dd");
DATE = sdf.format(date)

def get_body_build_summary(){
			def date1 = new Date();
            def sdf1 = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
            def Date_Time = sdf1.format(date1)
			
					
 def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
		.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		</style>
		</style>
		<table class="tg" style="undefined;table-layout: fixed; width: 1000px">
		<colgroup>
		<col style="width: 100px">
		<col style="width: 500px">
		<col style="width: 100px">
		<col style="width: 500px">
		</colgroup>
		  <tr>
			<th class="tg-amwm" colspan="2">PROXY Restart Summary</th>
		  </tr>
		  <tr>
			<td class="tg-1wig">Submitted By</td>
			<td class="tg-0lax">${getBuildUserID()}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">Date</td>
			<td class="tg-0lax">${Date_Time}</td>
		  </tr>
          <tr>	
			<td class="tg-1wig">Proxy Restart Summary</td>
			<td class="tg-0lax">${Proxy_restart_summary}</td>
		  </tr>         
        </table>
		
		<br><br><br>
	"""
	emailBody = body_build_summary
	return body_build_summary
}

def Prepartion () {	

	cleanWs()

	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Automation"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]

    checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "SV"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: "https://github.vodafone.com/VFUK-INTEGRATION/SV_Automation"]]]
            
    sh 'mkdir SV_Project && chmod 766 SV_Project'
    sh "sleep 5"
    sh "dos2unix ./Automation/SV_Automation/*.sh"
    sh "cp ./Automation/SV_Automation/*.sh ./SV_Project/"
    sh "cp ./SV/AutomationSuite/Logical/Registration_File/registration.xml ./SV_Project/"
    sh "sleep 2"
    sh "chmod 777 SV_Project"
        
    
    sh 'tar -czf SV_Project.tar.gz ./SV_Project*'
		
	ansiColor('xterm') {
		ansiblePlaybook (playbook: "${WORKSPACE}/Automation/SV_Automation/Preparation.yml", colorized: true, extras: '', extraVars: [host: "SV_Backend_TEST", date_time: "${date_time}", Workspace: "${WORKSPACE}"])
    } 
}


mailRecipients = (getBuildUserID() == "") ? "" : getUserEmail(getBuildUserID())
def ccmail_recepients="cc:prasanth.kathiresan@vodafone.com, cc:sathish.kumar3@vodafone.com"
//def ccmail_recepients="cc:showmi.ravi@vodafone.com,cc:padmaja.balamurugan@vodafone.com, cc:prasanth.kathiresan@vodafone.com,sathish.kumar3@vodafone.com,cc:suba.masanamuthu@vodafone.com"

xmlcopy=""
restart=""
Proxy_restart_summary=""
Status=""

pipeline{
	agent any
	options {
        	preserveStashes(buildCount: 1)
   	}
	environment {
		
		date_time = ""
        DATE = ""
	}
	stages {
		stage ('Prepartion') {
			steps {
				script {
					if(params.XML_COPY)
                        xmlcopy="yes"
                    if(params.RESTART_NOW)
                        restart="yes"
                    if(params.XML_COPY == false && params.RESTART_NOW == false)
                    {
                           error 'Select atleast one option. Either Copy or Restart'
                    }
         			currentBuild.displayName = "PROXY_${DATE}_${BUILD_NUMBER}"
					Prepartion ()
                    echo "Prepartion Completed"
				}
			}
		}
	
       
       stage ('Copy & Restart Proxy') {
			steps {
				script {
				    input 'Proceed with  Proxy Restart?'
                     ansiColor('xterm') {
                    ansiblePlaybook (playbook: "${WORKSPACE}/Automation/SV_Automation/Restart_Proxy.yml", colorized: true, extras: '', extraVars: [host: "SV_Backend_TEST", date_time: "${date_time}", xmlcopy:"${xmlcopy}", restart:"${restart}"])
                    } 
                    Proxy_restart_summary = sh(script:"cat ${WORKSPACE}/Automation/SV_Automation/proxy_restart_summary.txt || exit 0", returnStdout: true).trim()
                    println(Proxy_restart_summary)
                    Proxy_restart_summary = Proxy_restart_summary.replaceAll("\n","<BR/>")
                    if(Proxy_restart_summary.contains("Proxy was started successfully and it is running…"))
                        Status = "Success"
                    if(Proxy_restart_summary.contains("Proxy is not running, Please validate the registration.xml file for correctness and restart manually"))
                        Status = "Failure"
                  
			}
		}
       }
        
       
       stage ('Send Email') {
			steps {
				script {
                    
                    echo "Send Email"
					
					emailBody = "${get_body_build_summary()}"
					emailext  mimeType: 'text/html', attachmentsPattern: '*.log',
					subject: "[Jenkins]:SV_Testing:Email for Proxy Restart - ${Status}",
					from:"SV_Automation@vodafone.com",
					to: "${mailRecipients},${ccmail_recepients}",
					body: 	"${emailBody}" + 
					"<p><b><font size='2' color='Black'>Proxy Restart: <a href='${BUILD_URL}input'>${BUILD_URL}</a></font></b></p>"
				    
				
				}
			}
		}
        
	}
}