import java.text.*
import groovy.time.*

import hudson.tasks.Mailer;
import hudson.model.User;


def getUserEmail(String id=null) {
    User user = User.getById(id ?: currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId(), false)
    user?.getProperty(Mailer.UserProperty.class).getAddress()
}

def getBuildUserID(){
    if(currentBuild.getBuildCauses('hudson.triggers.TimerTrigger$TimerTriggerCause'))
            return ""
    else
            return currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId()
}

def date = new Date();
def sdf = new SimpleDateFormat("yyyyMMddHHmmss");
date_time = sdf.format(date)

def Prepartion () {	

	// cleaning workspace in Jenkins WorkSpace
	cleanWs()

	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Automation"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
}

mailRecipients = (getBuildUserID() == "") ? "" : getUserEmail(getBuildUserID())
def ccmail_recepients="Sandhata-VFengagement@vodafone.onmicrosoft.com, cc:devops-vfuk-integration@vodafone.com"

pipeline{
	agent any
	options {
        	preserveStashes(buildCount: 1)
   	}
	
	stages {
		stage ('Prepartion') {
			steps {
				script {
					
					currentBuild.displayName = "LicenseUsage_${BUILD_NUMBER}"
					Prepartion ()
					 echo "Prepartion Completed"
				}
			}
		}
		
        stage ('Getting LicenseUsage ') {
			steps {
				script {
                    
                    ansiColor('xterm') {
		                ansiblePlaybook (playbook: "${WORKSPACE}/Automation/SV_Automation/checkLicense.yml", colorized: true, extras:'', extraVars: [host: "RIT_TEST", date_time: "${date_time}"])
					}
				}
		    }
		}
        
        stage ('Send Email') {
			steps {
				script {
					emailBody = sh(script:"cat ${WORKSPACE}/Automation/SV_Automation/LicenseUsage_Output.txt || exit 0", returnStdout: true).trim()
					emailBody = emailBody.replaceAll("\n","<BR/>")
					emailext  mimeType: 'text/html', 
					subject: "[Jenkins]:Rational Integration Tester-LicenseUsage-Report",
					from:"SV_Automation@vodafone.com",
					to: "${mailRecipients},${ccmail_recepients}",
					body: 	"${emailBody}" + 
					"<p><b><font size='2' color='Black'>LicenseUsage_AUTOMATION_BUILDURL: <a href='${BUILD_URL}input'>${BUILD_URL}</a></font></b></p>"
				    
				
				}
			}
		}
	}
}
