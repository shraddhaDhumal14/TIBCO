import java.text.*
import groovy.time.*

import hudson.tasks.Mailer;
import hudson.model.User;


def getUserEmail(String id=null) {
    User user = User.getById(id ?: currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId(), false)
    user?.getProperty(Mailer.UserProperty.class).getAddress()
}

def getBuildUserID(){
    return currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId()
}

def date = new Date();
def sdf = new SimpleDateFormat("yyyyMMddHHmmss");
date_time = sdf.format(date)

def get_body_build_summary(){
			def date1 = new Date();
            def sdf1 = new SimpleDateFormat("dd-MM-yyyy");
            def Date_Time = sdf1.format(date1)
			
					
 def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
		.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		</style>
		</style>
		<table class="tg" style="undefined;table-layout: fixed; width: 1000px">
		<colgroup>
		<col style="width: 100px">
		<col style="width: 500px">
		<col style="width: 100px">
		<col style="width: 500px">
		</colgroup>
		  <tr>
			<th class="tg-amwm" colspan="2">SV_AUTOMATION_SUMMARY</th>
		  </tr>
		  <tr>
			<td class="tg-1wig">Submitted By</td>
			<td class="tg-0lax">${currentBuild.getRawBuild().getCauses()[0].getUserId()}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">Date</td>
			<td class="tg-0lax">${Date_Time}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">Backends</td>
			<td class="tg-0lax">${params.Backends}</td>
		  </tr>
		  <tr>	
			<td class="tg-1wig">Domain</td>
			<td class="tg-0lax">${params.Domain}</td>
		  </tr>
		  <td class="tg-1wig">Environment</td>
			<td class="tg-0lax">${params.Environment}</td>
		  </tr>
		  <tr>	
			<td class="tg-1wig">Comments</td>
			<td class="tg-0lax">${params.Comments}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">Publishing Successful</td>
			<td class="tg-0lax">${Status_pass}</td>
		  </tr>
		  <tr>	
			<td class="tg-1wig">Publishing Failed</td>
			<td class="tg-0lax">${Status_fail}</td>
		  </tr>	
          <tr>
			<td class="tg-1wig">TestSuite Successful</td>
			<td class="tg-0lax">${TS_Status_pass}</td>
		  </tr>
		  <tr>	
			<td class="tg-1wig">TestSuite Failed</td>
			<td class="tg-0lax">${TS_Status_fail}</td>
		  </tr>	 	
          <tr>	
			<td class="tg-1wig">Test Execution Summary</td>
			<td class="tg-0lax">${TS_Test_Summary}</td>
		  </tr>         
        </table>
		
		<br><br><br>
	"""
	emailBody = body_build_summary
	return body_build_summary
}

def Prepartion () {	

	
	
	// cleaning workspace in Jenkins WorkSpace
	cleanWs()

	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Automation"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]

	// Backend_Stub = sh(script:"cat ./Automation/SV_Automation/Backend_Stub_List.txt || exit 0", returnStdout: true).trim()
	sh 'mkdir SV_Project && chmod 766 SV_Project'
	//if (Backend_Stub != null && !Backend_Stub.isEmpty()) { length() != 0
	
	if (Backends.length() != 0) {
		
		Backend_Stub = "${params.Backends}".split(",")		
		//echo "${Backend_Stub}"
		
		if(Test_Suite)
        {

            checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "SV"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: "https://github.vodafone.com/VFUK-INTEGRATION/SV_Automation"]]]
            
            
            sh "sleep 5"
            sh "pwd"
            sh "dos2unix ./Automation/SV_Automation/*.sh"
            sh "cp ./Automation/SV_Automation/*.sh ./SV/AutomationSuite/Logical/AntScripts/"
            sh "sleep 5"
            sh "chmod 777 SV"
            base_dir="/home/tibco/SV_Automation/SV_${date_time}/SV_Project/AutomationSuite"
            dir("SV/AutomationSuite/Logical/AntScripts")
            {
                sh "sh updateAntScript.sh '${base_dir}' ${env.Environment}"
            }
            
            sh "cd ${workspace}"
            sh "sleep 2"
            sh 'cp -rf ./SV/* ./SV_Project/'
            
        }
        
        for ( stub in Backend_Stub ) {
			//echo "each : ${stub}"
			// Git checout for each backend
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "SV"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: "https://github.vodafone.com/VFUK-INTEGRATION/SV_${stub}"]]]
			
			sh 'cp -rf ./SV/* ./SV_Project/'
		}
        sh 'tar -czf SV_Project.tar.gz ./SV_Project*'
		
		// Executing Ansible Scripts for SV Project Deployment Preparation in RTCP Box
		ansiColor('xterm') {
			ansiblePlaybook (playbook: "${WORKSPACE}/Automation/SV_Automation/Preparation.yml", colorized: true, extras: '', extraVars: [host: "SV_Backend_TEST", date_time: "${date_time}", Workspace: "${WORKSPACE}"])
        }       
		
	} else {
		
		echo "DEBUG: Backends not select from Inputs"
	}
}

def TestSuite_Exection () {
    Backend_Stub = "${params.Backends}".split(",")
    for ( stub in Backend_Stub ) {
            ansiColor('xterm') {
			ansiblePlaybook (playbook: "${WORKSPACE}/Automation/SV_Automation/Test_Suite.yml", colorized: true, extras:'', extraVars: [host: "SV_Backend_TEST", Backend: "${stub}", date_time: "${date_time}", Workspace: "${WORKSPACE}", Ant_Path: "/home/tibco/apache-ant/apache-ant-1.10.8/bin"])
		}
	}
    
}

def SV_Exection () {
	//Backend_Stub = sh(script:"cat ./Automation/SV_Automation/Backend_Stub_List.txt || exit 0", returnStdout: true).trim()
	Backend_Stub = "${params.Backends}".split(",")
	//Content = new File("${WORKSPACE}/Automation/SV_Automation/Backend_Stub_List.txt").readLines()
	//echo "${Content}"
	for ( stub in Backend_Stub ) {
		
		// SV Backend Execution
		ansiColor('xterm') {
			ansiblePlaybook (playbook: "${WORKSPACE}/Automation/SV_Automation/SV_Execution.yml", colorized: true, extras:'', extraVars: [host: "SV_Backend_TEST", Domain: "${params.Domain}", Backend: "${stub}", date_time: "${date_time}", Workspace: "${WORKSPACE}", Env: "${params.Environment}", RIT_Path: "/home/tibco/IBM/RationalIntegrationTester/IntegrationTesterCmd"])
		}
	}

}

def Report() {
    
    ansiColor('xterm') {
		ansiblePlaybook (playbook: "${WORKSPACE}/Automation/SV_Automation/Reportin_And_Cleanup.yml", colorized: true, extras:'', extraVars: [host: "SV_Backend_TEST", date_time: "${date_time}", Workspace: "${WORKSPACE}"])
	}
	Status_pass = sh(script:"cat ./Pass_Result.txt || exit 0", returnStdout: true).trim()
	if (Status_pass != null && !Status_pass.isEmpty()) {
		Status_pass = "${Status_pass}".split("\n")
		Status_pass1 = ("${Status_pass}".split("\\["))[1].split("\\]")
		Status_pass = Status_pass1[0]		
	} else {
		Status_pass = "All Backends Execution failed"
	}
	
	Status_fail = sh(script:"cat ./Fail_Result.txt || exit 0", returnStdout: true).trim()
	if (Status_fail != null && !Status_fail.isEmpty()) {
		Status_fail = "${Status_fail}".split("\n")
		Status_fail1 = ("${Status_fail}".split("\\["))[1].split("\\]")
		Status_fail = Status_fail1[0]
	} else {
		Status_fail = "All Backends Execution Success"
	}
    
    if(Test_Suite)
    {
    TS_Status_pass = sh(script:"cat ./TestSuite_Pass.txt || exit 0", returnStdout: true).trim()
	if (TS_Status_pass != null && !TS_Status_pass.isEmpty()) {
		TS_Status_pass = "${TS_Status_pass}".split("\n")
		TS_Status_pass1 = ("${TS_Status_pass}".split("\\["))[1].split("\\]")
		TS_Status_pass = TS_Status_pass1[0]		
	} else {
		TS_Status_pass = "All Backends Execution failed"
	}
	

	TS_Status_fail = sh(script:"cat ./TestSuite_Fail.txt || exit 0", returnStdout: true).trim()
	if (TS_Status_fail != null && !TS_Status_fail.isEmpty()) {
		TS_Status_fail = "${TS_Status_fail}".split("\n")
		TS_Status_fail1 = ("${TS_Status_fail}".split("\\["))[1].split("\\]")
		TS_Status_fail = TS_Status_fail1[0]
	} else {
		TS_Status_fail = "All Backends Execution Success"
	}
    
    //TS_Test_Summary = sh(script:"grep 'tests executed' TestSuite_Result.log | cut -f3 -d\"]\" || exit 0", returnStdout: true).trim()
    //TS_Test_Summary += sh(script:"grep 'Buildfile:.*does not exist!' TestSuite_Result.log || exit 0", returnStdout: true).trim()
    TS_Test_Summary = sh(script:"cat ./TestSuite_Summary.log || exit 0", returnStdout: true).trim()
    }
    else
    {
        TS_Status_pass = TS_Status_fail = TS_Test_Summary = "NA"
    }
    TS_Test_Summary = TS_Test_Summary.replaceAll("\n","<BR/>")
    
}



def mailRecipients = getUserEmail(getBuildUserID())
def ccmail_recepients="cc:showmi.ravi@vodafone.com,cc:padmaja.balamurugan@vodafone.com, cc:prasanth.kathiresan@vodafone.com,cc:sathish.kumar3@vodafone.com"
base_dir="/home/tibco/SV_Automation/AutomationSuite"



pipeline{
	agent any
	options {
        	preserveStashes(buildCount: 1)
   	}
	environment {
		
		SV_TYPE = "SV"
		Backend_Stub = ""
		date_time = ""
		Status_pass = ""
		Status_fail = ""
        TS_Status_pass = ""
		TS_Status_fail = ""
        TS_Test_Summary = ""
	}
	stages {
		stage ('Prepartion') {
			steps {
				script {
					
					if ( Domain.length() == 0) {
						error 'Domain and Environment not Selected from the List'
					}
					if ( Backends.length() == 0) {
						error 'Backends not Selected from the List'
					}
					if ( Comments.length() == 0) {
						error 'Comments Should enter'
					}
					currentBuild.displayName = "SV_Automation_${BUILD_NUMBER}"
					Prepartion ()
					 echo "Prepartion Completed"
				}
			}
		}
		
		stage ('Publish SV Stubs') {
			steps {
				script {
                    echo "Publish SV Stubs"
					SV_Exection ()
				}
			}
		}
        
       stage ('Publish Test Suite') {
			steps {
				script {
                    
                    if(Test_Suite)
                    {
                        echo "Publish Test Suite"
                        TestSuite_Exection ()
                    }
                    else
                    {
                          echo "Test Suite Not selected"
                    }
			
				}
			}
		}
        
       stage ('Send Email') {
			steps {
				script {
                    
                    Report()
                    echo "Send Email"
					
					emailBody = "${get_body_build_summary()}"
					emailext  mimeType: 'text/html', attachmentsPattern: '*.log',
					subject: "[Jenkins]:SV_Testing:Email for SV Automation Report",
					from:"SV_Automation@vodafone.com",
					to: "${mailRecipients},${ccmail_recepients}",
					body: 	"${emailBody}" + 
					"<p><b><font size='2' color='Black'>TEST_AUTOMATION_BUILDURL: <a href='${BUILD_URL}input'>${BUILD_URL}</a></font></b></p>"
				    
				
				}
			}
		}
	}
}

