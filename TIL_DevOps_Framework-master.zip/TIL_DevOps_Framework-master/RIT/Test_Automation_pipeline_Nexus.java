import java.text.*
import groovy.time.*

//  Testing Related Email Body Preparation
  		
def get_body_build_summary(){
			def date = new Date();
            def sdf = new SimpleDateFormat("dd-MM-yyyy");
            def date_time = sdf.format(date)
			
					
 def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
		.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		</style>
		</style>
		<table class="tg" style="undefined;table-layout: fixed; width: 1000px">
		<colgroup>
		<col style="width: 100px">
		<col style="width: 500px">
		<col style="width: 100px">
		<col style="width: 500px">
		</colgroup>
		  <tr>
			<th class="tg-amwm" colspan="2">TEST_AUTOMATION_SUMMARY</th>
		  </tr>
		  <tr>
			<td class="tg-1wig">Submitted By</td>
			<td class="tg-0lax">${currentBuild.getRawBuild().getCauses()[0].getUserId()}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">Date</td>
			<td class="tg-0lax">${date_time}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">Engine</td>
			<td class="tg-0lax">${ENGINE_NAME}</td>
		  </tr>
		  <tr>
		  <td class="tg-1wig">Operations</td>
			<td class="tg-0lax">${OPERATION_NAME}</td>
		  </tr>
		  <tr>
		  <td class="tg-1wig">Type</td>
			<td class="tg-0lax">${Test_Type}</td>
		  </tr>
		  <tr>	
			<td class="tg-1wig">Test_Result</td>
			<td class="tg-0lax">${TestCase_result}</td>
		  </tr>	
         <tr>	
		   <td class="tg-1wig">Status</td>
		   <td class="tg-0lax">${Status}</td>
		 </tr>
		 <tr>	
		   <td class="tg-1wig">Nexus Repo</td>
		   <td class="tg-0lax">${Nexus_Report}</td>
		 </tr>
		</table>
		
		<br>
	"""
	emailBody = body_build_summary
	return body_build_summary
}

def Test_Suite_Exe(){

	
		
	def date = new Date();
	def sdf = new SimpleDateFormat("yyyyMMddHHmmss");
	date_time = sdf.format(date)
	
	def Ant_File
	def file
	def Pro = ""
	def Reg = ""
	def Pronot = ""
	def Regnot = ""
	def Eng = ""
	def Engnot = ""
	def Pro1 = ""
	TestCase_result = ""
	def Reg1 = ""
	Type = ""

	// Bulid Naming

	// displayName = "Test_Automation_${BUILD_NUMBER}"
	currentBuild.displayName = "Test_Automation_${Test_Type}_${BUILD_NUMBER}"

	  
	// cleaning workspace in Jenkins box
	cleanWs()

	//Checkout Rit Project
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/${GIT_BRANCH}']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Project"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/RIT_${ENGINE_NAME}.git']]]
	
	//Checkout Ansible Scripts			
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Script"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]

		
	def fil = "${WORKSPACE}" + "/" + "Project" + "/" + "${ENGINE_NAME}"
	//println "${fil}"
	// If Project present with Select Engine Request 
			
	if (fileExists(fil)) {	
					  
	 	sh '''
			cp -r ${WORKSPACE}/Project/${ENGINE_NAME}  ${WORKSPACE}/${ENGINE_NAME}_RIT
			cp -r ${WORKSPACE}/Script/Test_Automation_Scripts ${WORKSPACE}/Test_Automation_Scripts
			cd ${WORKSPACE}
			chmod 766 ${WORKSPACE}/${ENGINE_NAME}_RIT
		'''
			
			
	// If Operations Fien for Testing 
 
		if (OPERATION_NAME.length() != 0){
			def Ops = "${OPERATION_NAME}".split(',')
			if (Test_Type == "Progression") {
				for (Oper in Ops) {
	  
					Ant_File = "${ENGINE_NAME}" + "_" + "${Oper}" + "_" + "Progression" + "." + "xml"	
					file = "${WORKSPACE}" + "/" + "${ENGINE_NAME}_RIT" + "/" + "Logical" + "/" + "AntScripts" + "/" + "${Ant_File}"	
		

					if (fileExists(file)) {
						println "${Ant_File} --->> Found"
						if (Pro.length() != 0){
							Pro = "${Pro}" + "," + "${Ant_File}"
						}else {				
							Pro = "${Ant_File}"				 
						}
					}else {
						println "${Ant_File} ---->> File not Found"
						if (Pronot.length() != 0){
							Pronot = "${Pronot}" + "," + "${Ant_File}"
						}else {
							Pronot = "${Ant_File}"
						}
					}			
				}
			}
			
			if (Test_Type == "Regression") {
				for (Oper in Ops) {
	  
					Ant_File = "${ENGINE_NAME}" + "_" + "${Oper}" + "_" + "Regression" + "." + "xml"	
					file = "${WORKSPACE}" + "/" + "${ENGINE_NAME}_RIT" + "/" + "Logical" + "/" + "AntScripts" + "/" + "${Ant_File}"	

					if (fileExists(file)) {
						println "${Ant_File} --->> Found"
						if (Reg.length() != 0){
							Reg = "${Reg}" + "," + "${Ant_File}"
						}else {
							Reg = "${Ant_File}"
						}
					}else {
						println "${Ant_File} ---->> File not Found"
						if (Regnot.length() != 0){
							Regnot = "${Regnot}" + "," + "${Ant_File}"
						}else {
							Regnot = "${Ant_File}"
						}
					}			
				}
			}
		}else {
			Ant_File = "${ENGINE_NAME}" + "_" + "Regression" + "." + "xml"
			file = "${WORKSPACE}" + "/" + "${ENGINE_NAME}_RIT" + "/" + "Logical" + "/" + "AntScripts" + "/" + "${Ant_File}"	
		

			if (fileExists(file)) {
				println "${Ant_File} ---->> File Found"
				Eng = "${Ant_File}"
			}else {
				println "${Ant_File} ---->> File not Found"
				Engnot = "${Ant_File}"
			}
		}
		if (Pronot.length() != 0 | Regnot.length() != 0 | Engnot.length() != 0) {

			promotion_email_body = "ANT Files in the Project : ${Pro}${Reg} ${Eng}" + "<br>" + "<br>" + " ANT Files not found in the Project : ${Pronot}${Regnot}${Engnot}"

			emailext mimeType: 'text/html',
			subject: "[Jenkins]:${currentBuild.fullDisplayName}:Approval email for Continou the Testing or Skip ?",
			from:"TEST_AUTOMATION@vodafone.com",
			to: "${Email}",
			body: 	"${promotion_email_body}" + "<br>" + 
				"<br><br><p><b><font size='2' color='Black'>Click on below link for input to proceed for Test Continou: <a href='${BUILD_URL}input'>${BUILD_URL}</a></font></b></p>"
		
			error 'ANT files not found'
		}
		
		sh '''
			file1="${WORKSPACE}/${ENGINE_NAME}_RIT/Logical/AntScripts/*.xml"
				
			# Replaces the windows parameters Values to RTCP Box Values in Ant Files   
				   
			sed -i 's#name="install.dir" value=.*/>#name="install.dir" value="/opt/SP/tibco/IBM/RationalIntegrationTester"/>#g' ${file1}
			sed -i 's#environment=.* project#environment="'${Environments}'" project#g' ${file1}
			sed -i 's#basedir=.* default#basedir="./../.." default#g' ${file1}
			sed -i 's#ghp"#ghp" securityToken="P:8647bc48-c250-4168-9855-b8379b057d1a"#g' ${file1}
				
			cd ${WORKSPACE}
			# Coverting the Total Project into tar file
			tar -czvf ${ENGINE_NAME}_RIT.tar.gz ${ENGINE_NAME}_RIT
				
		''' 
		// Executing Ansible Scripts for RIT Project Deployment Preparation in RTCP Box

		ansiColor('xterm') {
			ansiblePlaybook (playbook: "${WORKSPACE}/Test_Automation_Scripts/Preparation.yml", colorized: true, extras: '', extraVars: [host: "RIT_TEST", Engine_Name: "${ENGINE_NAME}_RIT", date_time: "${date_time}", Workspace: "${WORKSPACE}"])
		}
		
		// Ant File Execution for all OPerations Progression

		if (Pro.length() != 0)	{
			def Ops = "${Pro}".split(',')
				
			Pro1 = "${OPERATION_NAME}".split(',')
			def i = 0
			for (Oper in Ops){	 
					
				// Executing Ansible Scripts for RIT Project Deploying in RTCP Box

				ansiColor('xterm') {
					ansiblePlaybook (playbook: "${WORKSPACE}/Test_Automation_Scripts/Test_Execution.yml", colorized: true, extras:'-v', extraVars: [host: "RIT_TEST", Ant_File: "${Oper}", Engine_Name: "${ENGINE_NAME}_RIT", date_time: "${date_time}", Workspace: "${WORKSPACE}", Log_File: "Pro_Result.log", file: "Pro_Status.txt"])
				}
				
				def vesr = readFile "${WORKSPACE}/Pro_Status.txt"
				println vesr
				String[] str;
				str = vesr.split(']');
				// println str[4]
				def lol = str.length
				//  println lol
				lol = lol-1
					
				if (TestCase_result.length() !=0) {
					TestCase_result = "${TestCase_result}" + "," + Pro1[i] + "_Progression" + " --->> " + str[lol] 
				}else {
					TestCase_result = Pro1[i] + "_Progression" + " --->> " + str[lol]
				}
				println TestCase_result
				i = i+1
			}
		
			Type = "Operation_Progression"
			return
		}
			
		// Ant File Execution for all OPerations Regression	

		if (Reg.length() != 0) {
			def Ops = "${Reg}".split(',')
			Reg1 = "${OPERATION_NAME}".split(',')
			TestCase_result = ""
			def i = 0
			for (Oper in Ops){	 
					
				// Executing Ansible Scripts for RIT Project Deploying in RTCP Box

				ansiColor('xterm') {
					ansiblePlaybook (playbook: "${WORKSPACE}/Test_Automation_Scripts/Test_Execution.yml", colorized: true, extras:'-v', extraVars: [host: "RIT_TEST", Ant_File: "${Oper}", Engine_Name: "${ENGINE_NAME}_RIT", date_time: "${date_time}", Workspace: "${WORKSPACE}", Log_File: "Reg_Result.log", file: "Reg_Status.txt"])
				}
					

				
				def vesr = readFile "${WORKSPACE}/Reg_Status.txt"
				println vesr
				String[] str;
				str = vesr.split(']');
				// println str[4]
				def lol = str.length
				//  println lol
				lol = lol-1
					
				if (TestCase_result.length() !=0) {
					TestCase_result = "${TestCase_result}" + "," + Reg1[i] + "_Regression" + " --->> " + str[lol] 
				}else {
					TestCase_result = Reg1[i] + "_Regression" + " --->> " + str[lol]
				}
				// println TestCase_result
				i = i+1
			}
				
			Type = "Operation_Regression"
			return

			// finding the Log Results to Verify Whether All Test cases are Success/Failed	in Operation_Regression
					 
	

		}
		
		if (Eng.length() != 0)  {
			TestCase_result = ""
				
			// Executing Ansible Scripts for RIT Project Deploying in RTCP Box
			
			ansiColor('xterm') {
				ansiblePlaybook (playbook: "${WORKSPACE}/Test_Automation_Scripts/Test_Execution.yml", colorized: true, extras:'-v', extraVars: [host: "RIT_TEST", Ant_File: "${Eng}", Engine_Name: "${ENGINE_NAME}_RIT", date_time: "${date_time}", Workspace: "${WORKSPACE}", Log_File: "Engine_Result.log", file: "Engine_Status.txt"])
			}
					

					
			def vesr = readFile "${WORKSPACE}/Engine_Status.txt"
			println vesr
			String[] str;
			str = vesr.split(']');
					   
			def lol = str.length
			//  println lol
			lol = lol-1
			TestCase_result =  "${ENGINE_NAME}" + " --->> " + str[lol] 
			
			Type = "${ENGINE_NAME}_Regression"
			return
		
		}
	}

	// If Engine Name Directory Not Present in Project
	else {
		println "Engine = ${ENGINE_NAME}  ------> Directory Not found in the GITHUB "
		  
		def promotion_email_body = "Artefacts Not found in the  GITHUB "
	
		emailext mimeType: 'text/html',
		subject: "[Jenkins]:${currentBuild.fullDisplayName}:Approval email for promote to Next Stage",
		from:"TEST_AUTOMATION@vodafone.com",
		to: "${Email}",
		body: "${promotion_email_body}" + "<br>" + 
		"<br><br><p><b><font size='2' color='Black'>Proceed to Next Stage Click on Promote: <a href='${BUILD_URL}input'>${BUILD_URL}</a></font></b></p>"

		error 'Project Not found in the GITHUB'
	}
	println "System Testing Success"
		  
}

// Reports and Cleaning the Workspace
def Reporting_CleanUp () {
	
	def date = new Date();
	def sdf = new SimpleDateFormat("yyyy-MM-dd-HH:mm");
	Date_Time = sdf.format(date)
	
	ansiColor('xterm') {
			ansiblePlaybook (playbook: "${WORKSPACE}/Test_Automation_Scripts/Reportin_And_Cleanup.yml", colorized: true, extras:'-v', extraVars: [host: "RIT_TEST", Engine_Name: "${ENGINE_NAME}_RIT", date_time: "${date_time}", Workspace: "${WORKSPACE}", Engine: "${ENGINE_NAME}", Workspace: "${WORKSPACE}"])
			
			// Uploading RTCP Reports in to NExuxs
			nexusArtifactUploader artifacts: [[artifactId: "${ENGINE_NAME}", classifier: '', file: "${WORKSPACE}/${ENGINE_NAME}.zip", type: 'zip']], credentialsId: '74edde97-94e0-403c-93f6-cad6c46c45f8', groupId: "RTCP_Reports", nexusUrl: "${NEXUS_URL}", nexusVersion: "${NEXUS_VERSION}", protocol: 'http', repository: "${RTCP_REPO}", version: "${Date_Time}"
	}
	
}


def TestCase_result
//def Type
def date_time
def Date_Time


pipeline {
	agent any
	environment {
		
		NEXUS_URL="195.233.197.150:8081"
		RTCP_REPO="TEST_AUTOMATION_REPO"
				
		NEXUS_VERSION="nexus3"
		Nexus_Report = "http://195.233.197.150:8081/#browse/browse:TEST_AUTOMATION_REPO:RTCP_Reports%2F${ENGINE_NAME}"
		Status = ""
		Type = ""
		
	}
	
	stages {
		stage('RIT Testing') {
		//	when {
		//	expression { ENGINE_MAP[ENGINE_NAME]['BW_Restart'] == "PASSED" }
		//	}
			steps {
                script {
					
					Test_Suite_Exe ()
			
					
					println " ======>> Stage is Executed <<======"

				}
			}
		}
		
		stage('Reporting & CleanUp') {
			
			steps {
                script {
					
					Reporting_CleanUp ()
					
					println " ======>> Report and Cleanup Done <<======"
					statusFile = new File("${WORKSPACE}/Result_Log.txt")
					statusContent = statusFile.readLines()
												
					if (statusContent[-1].contains(' RunTests execution ended with code: 0')) {
						Status = "SUCCESS"
					}else {
						Status = "FAILED"
					} 
									
					if (Status == "FAILED") {
					   
						def promotion_email_body = " Test cases are Failed in ${Type} Testing "	
						def emailBody = "${get_body_build_summary()}"
						emailext  mimeType: 'text/html', attachmentsPattern: 'Test_Result.log',
						subject: "[Jenkins]:System_Testing",
						from:"Test_Automation@vodafone.com",
						to: "${Email}",
						body: 	"${promotion_email_body}" + "<br>" + "${emailBody}" + 
								"<br><p><b><font size='2' color='Black'>TEST_AUTOMATION_BUILDURL: <a href='${BUILD_URL}input'>${BUILD_URL}</a></font></b></p>"	
						
						
						
						error 'Testing Failed'
						
					}

					if (Status == "SUCCESS") {
					 
						def promotion_email_body = " ${Type} Testing Success"	
						def emailBody = "${get_body_build_summary()}"
						emailext  mimeType: 'text/html', attachmentsPattern: 'Test_Result.log',
						subject: "[Jenkins]:System_Testing",
						from:"Test_Automation@vodafone.com",
						to: "${Email}",
						body: 	"${promotion_email_body}" + "<br>" + "${emailBody}" + 
								"<br><p><b><font size='2' color='Black'>TEST_AUTOMATION_BUILDURL: <a href='${BUILD_URL}input'>${BUILD_URL}</a></font></b></p>"	
								
						
					}
				}	
				
			}
		}
	}
}