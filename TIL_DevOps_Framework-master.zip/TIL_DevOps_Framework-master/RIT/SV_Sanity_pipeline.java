import java.text.*
import groovy.time.*

//  Testing Related Email Body Preparation
  		
def get_body_build_summary(){
			date_now = new Date().format( 'dd-MM-yyyy' )
					
 def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
		.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		</style>
		</style>
		<table class="tg" style="undefined;table-layout: fixed; width: 1000px">
		<colgroup>
		<col style="width: 100px">
		<col style="width: 500px">
		<col style="width: 100px">
		<col style="width: 500px">
		</colgroup>
		  <tr>
			<th class="tg-amwm" colspan="2">SV_SANITY_SUMMARY</th>
		  </tr>
		  <tr>
			<td class="tg-1wig">Submitted By</td>
			<td class="tg-0lax">${currentBuild.getRawBuild().getCauses()[0].getUserId()}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">Date</td>
			<td class="tg-0lax">${date_now}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">Backend_NAME</td>
			<td class="tg-0lax">${Backend_NAME}</td>
		  </tr>
		  <tr>	
		   <td class="tg-1wig">SV_Status</td>
		   <td class="tg-0lax">${Status}</td>
		 </tr>
		</table>
		
		<br><br><br>
	"""
	emailBody = body_build_summary
	return body_build_summary
}

def Test_Suite_Exe(){

	
	def date = new Date();
	def sdf = new SimpleDateFormat("yyyyMMddHHmmss");
	def date_time = sdf.format(date)
	def Ant_File

	def file
	
	
	

	// Bulid Naming

	
	currentBuild.displayName = "SV_SanityTest_${BUILD_NUMBER}"

	  
	// cleaning workspace in Jenkins box
	cleanWs()

	//Checkout Rit Project
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Project"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/SV_${Backend_NAME}.git']]]
	
	//Checkout Ansible Scripts			
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Script"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]

		
	def fil = "${WORKSPACE}" + "/" + "Project" + "/" + "${Backend_NAME}"
	//println "${fil}"
	// If Project present with Select Engine Request 
			
	if (fileExists(fil)) {	
					  
	 	sh '''
			cp -r ${WORKSPACE}/Project/${Backend_NAME}  ${WORKSPACE}/${Backend_NAME}_SV
			cp -r ${WORKSPACE}/Script/Test_Automation_Scripts ${WORKSPACE}/Test_Automation_Scripts
			cd ${WORKSPACE}
			chmod 766 ${WORKSPACE}/${Backend_NAME}_SV
			#cp -f ${WORKSPACE}/${Backend_NAME}_SV/Logical/AntScripts/Siebel_Direct_E2E_TestSuite.xml ${WORKSPACE}/${Backend_NAME}_SV/${Backend_NAME}/Logical/AntScripts/${Backend_NAME}.xml
		'''
	  
		Ant_File =  "${Backend_NAME}" + "_" + "E2E_TestSuite" + "." + "xml"	
		file = "${WORKSPACE}" + "/" + "${Backend_NAME}_SV" + "/" + "Logical" + "/" + "AntScripts" + "/" + "${Ant_File}"	
	

		if (fileExists(file)) {
			println "${Ant_File} --->> Found"
				
			sh '''
				file1="${WORKSPACE}/${Backend_NAME}_SV/Logical/AntScripts/*.xml"
					
				# Replaces the windows parameters Values to RTCP Box Values in Ant Files   
					   
				sed -i 's#name="install.dir" value=.*/>#name="install.dir" value="/opt/SP/tibco/IBM/RationalIntegrationTester"/>#g' ${file1}
				sed -i 's#environment=.* project#environment="'${Environment}'" project#g' ${file1}
				sed -i 's#basedir=.* default#basedir="./../.." default#g' ${file1}
				sed -i 's#ghp"#ghp" securityToken="P:8647bc48-c250-4168-9855-b8379b057d1a"#g' ${file1}
		
					
				cd ${WORKSPACE}
				# Coverting the Total Project into tar file
				tar -czvf ${Backend_NAME}_SV.tar.gz ${Backend_NAME}_SV
					
			''' 
			// Executing Ansible Scripts for SV Project Deployment Preparation in RTCP Box
			ansiColor('xterm') {
				ansiblePlaybook (playbook: "${WORKSPACE}/Test_Automation_Scripts/Preparation.yml", colorized: true, extras: '', extraVars: [host: "SV_TEST", Engine_Name: "${Backend_NAME}_SV", date_time: "${date_time}", Workspace: "${WORKSPACE}"])
			}
						
			// Executing Ansible Scripts for SV Project Deploying in RTCP Box

			ansiColor('xterm') {
				ansiblePlaybook (playbook: "${WORKSPACE}/Test_Automation_Scripts/Test_Execution.yml", colorized: true, extras:'-v', extraVars: [host: "SV_TEST", Ant_File: "${Ant_File}", Engine_Name: "${Backend_NAME}_SV", date_time: "${date_time}", Workspace: "${WORKSPACE}", Log_File: "Result.log", file: "Status.txt"])
			}
			ansiColor('xterm') {
				ansiblePlaybook (playbook: "${WORKSPACE}/Test_Automation_Scripts/Cleanup.yml", colorized: true, extras:'', extraVars: [host: "SV_TEST"])
			}
		
		if (fileExists("${WORKSPACE}/Result.log")) {
			
			def statusFile = new File("${WORKSPACE}/Result.log")
			def statusContent = statusFile.readLines()
			 
			
			if(statusContent[-2].contains('BUILD SUCCESSFUL')) {
				Status = "Success"
			}else {
				Status = "Failed"
			}
			
			
			def emailBody = "${get_body_build_summary()}"
			emailext  mimeType: 'text/html', attachmentsPattern: 'Test_Result.log',
			subject: "[Jenkins]:_SV Sanity Testing",
			from:"SV_Sanity_Testing@vodafone.com",
			to: "${mailRecipients}",
			body: 	"<br>" + "${emailBody}" + "<br>" + 
					"<br><br><p><b><font size='2' color='Black'>SV_SANITY_BUILDURL: <a href='${BUILD_URL}input'>${BUILD_URL}</a></font></b></p>"
		}


		
	}
		
		else {
			promotion_email_body = "ANT Files are not present Project"

			emailext mimeType: 'text/html',
			subject: "[Jenkins]:${currentBuild.fullDisplayName}:Approval email for Continou the Testing or Skip ?",
			from:"SV_Sanity_Testing@vodafone.com",
			to: "${mailRecipients}",
			body: 	"${promotion_email_body}" + "<br>" + 
				"<br><br><p><b><font size='2' color='Black'>Click on below link for input to proceed for Test Continou: <a href='${BUILD_URL}input'>${BUILD_URL}</a></font></b></p>"

			error 'ANT files not found'
		}

	}	
}			


pipeline {
	agent any
	environment {
		
		Status = ""
		mailRecipients = "${BUILD_REQUESTER}"
	}
	
	stages {
		stage('Sanity Testing') {
		
			steps {
                script {
					
					Test_Suite_Exe ()
			
					
					println " ======>> Stage is Executed <<======"

				}
			}
		}
	}
}