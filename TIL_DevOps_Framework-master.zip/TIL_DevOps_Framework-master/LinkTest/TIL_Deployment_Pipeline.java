// Calling global functions from shared libraries.
//@Library('myLibrary@master') _


//[CICD-476] Fix: import this package as part of the fix
import groovy.time.*

//[CICD-539] Insert Deployment metadata to release notes DB.
import groovy.json.JsonOutput
import groovy.sql.*
import java.sql.Driver

//[CICD-476] Fix: function to get elapsed time duration 
def elapsedTime(Closure closure){
    def timeStart = new Date()
    closure()
    def timeStop = new Date()
    return TimeCategory.minus(timeStop, timeStart).toMilliseconds()
}

def trigger_results_email(deployParams){
	// This function is to trigger an email for the provided map.
	emailext mimeType: 'text/html',
	subject: "[Jenkins]: ${currentBuild.fullDisplayName}  - " + "Deployment Results Summary",
	from:"TIL_LINKTEST_DEPLOYMENT@vodafone.com",
	to: "${dev_mailRecipients}",
	body: 	"${emailFunctions.get_lt_results_summary map: deployParams.map, REPORT_STAGE: deployParams.REPORT_STAGE, crq_num: deployParams.crq_num, release: deployParams.release}" 
}

def trigger_versions_email(deployParams){
	// This function is to trigger an email for the provided map.
	emailext mimeType: 'text/html',
	 subject: "[Jenkins]: Deployment Version Summary",
	 from:"TIL_LINKTEST_DEPLOYMENT@vodafone.com",
	 to: "${dev_mailRecipients}",
	 body: 	"${emailFunctions.get_engine_versions_summary map: deployParams.map, REPORT_STAGE: deployParams.REPORT_STAGE, Target_Env: TARGET_Env}" 
}

// Funcation to Get Email List
def get_approvers_list(String str){
	outlist = sh (script: """cat /opt/tibco/.jenkins/config.xml | sed -n \'/role name=\"${str}\"/,\$p\' | sed \'/role>/q\' | grep "sid" | cut -d \'>\' -f 2 | cut -d \'<\' -f 1 | paste -s -d, -""",
			returnStdout: true).trim()
	return """${outlist}"""
}

def email_gv_diff_report(deployParams) {
	// This function is to send GV diff report through an email.
	//[CICD-1112] : Attaching gv diff report as an html format in the same email.

	def gv_file_dir = "${WORKSPACE}/${deployParams.env}/BW_Deployment/GV_DIFF_SUMMARY"
	if(fileExists(gv_file_dir)){
		def gv_diff_path = new File("${WORKSPACE}/${deployParams.env}/BW_Deployment/GV_DIFF_SUMMARY")
		gv_diff_path.traverse{
			def eng_name = it.toString().split('/')[-1].split('_GV_DIFF.html')[0]
			def file_name = it.text
			emailext mimeType: 'text/html',
				subject: "[Jenkins]:${currentBuild.fullDisplayName}: GV DIFF REPORT for ${eng_name}",
				from:"TIL_DEPLOYMENTS@vodafone.com",
				to: "${dev_mailRecipients}",
				body: "${file_name}",
				attachmentsPattern: "**/${deployParams.env}/BW_Deployment/GV_DIFF_SUMMARY/*.html"
		}
	}	
}

def run_sql_generate_stage_function(){
		// SQL Build and generate stage function.
		println("DEBUG: Starting SQL BUILD")
		
		// Get statshed values up to this stage.
		//get_stash_list emsStash:0, sqlStash:1
		 
        // commonFunctions.checkAnsibleConnection host_list:"${TARGET_Env}_SQL", automation_dir:"AUTOMATION"
         
		//calling build SQL Job.
		def sql_version = SQL_Functions.build_sql RELEASE: "${params.RELEASE}", NEXUS_URL: "${env.NEXUS_URL}",  NEXUS_REPO: "${env.NEXUS_REPO}",  SQL_GROUPID: "${env.SQL_GROUPID}", NEXUS_USER: "${env.NEXUS_USER}",  NEXUS_PASSWD: "${env.NEXUS_PASSWD}", engine: "${ENGINE_NAME}", Environment: "${TARGET_Env}", Description: "${params.DESCRIPTION}", NEXUS_VERSION: "${env.NEXUS_VERSION}"
		
		println("DEBUG: SQL Version is: " + sql_version)
		
		// Update maps with SQL Version created in this step.
		ENGINE_MAP[ENGINE_NAME]['SQL_VERSION'] = sql_version
		 
		// Run SQL generate function to create workspace required for SQL Deployment.
		SQL_Functions.sql_generate_lower_env Environment:"${TARGET_Env}", nexus_group_id:"${env.SQL_GROUPID}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.NEXUS_REPO}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CHANGE_REF_ID}", repo_artifact_ids:"${ENGINE_NAME}:${sql_version}", datetime:"${date_now}", release:"${params.RELEASE}" 
}


def run_ems_generate_stage_function(){
		// EMS Build and generate stage function.
		println("DEBUG: Starting EMS BUILD")
		
        //commonFunctions.checkAnsibleConnection host_list:"${TARGET_Env}_EMS", automation_dir:"AUTOMATION"
		//calling build EMS Job.
		def ems_version = EMS_Functions.build_ems RELEASE: "${params.RELEASE}", NEXUS_URL: "${env.NEXUS_URL}",  NEXUS_REPO: "${env.NEXUS_REPO}",  EMS_GROUPID: "${env.EMS_GROUPID}", NEXUS_USER: "${env.NEXUS_USER}",  NEXUS_PASSWD: "${env.NEXUS_PASSWD}", engine: "${ENGINE_NAME}", Environment: "${TARGET_Env}", Description: "${params.DESCRIPTION}", NEXUS_VERSION: "${env.NEXUS_VERSION}"
		
		println("DEBUG: EMS Version is: " + ems_version)
	
		// Update maps with EMS Version created in this step.
		ENGINE_MAP[ENGINE_NAME]['EMS_VERSION'] = ems_version
		 
		trigger_versions_email map: ENGINE_MAP, REPORT_STAGE: "EMS_BUILD"
		 
		//Run EMS generate function to create workspace required for EMS Deployment.
		
		EMS_Functions.ems_generate_lower_env Environment:"${TARGET_Env}", nexus_group_id:"${env.EMS_GROUPID}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.NEXUS_REPO}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CHANGE_REF_ID}", repo_artifact_ids:"${ENGINE_NAME}:${ems_version}", datetime:"${date_now}", release:"${params.RELEASE}", emsIgnore:"${env.emsIgnore}" 
}



def load_groovy_files() {
	// This function is to load all groovy files, where in common functions will be kept.
	emailFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/emailFunctions.groovy"
	mapFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/mapFunctions.groovy"
	nexusFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/nexusFunctions.groovy"
	gitFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/gitFunctions.groovy"
	EMS_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/EMSFunctions.groovy"
	SQL_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/SQLFunctions.groovy"
	BW_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/BWFunctions.groovy"
	FILE_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/FileFunctions.groovy"
	commonFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/commonFunctions.groovy"
	
	//[CICD-539] Insert Deployment metadata to release notes DB.
	DB_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/dbFunctions.groovy"
}
def checkout_git_repositories() {
	// This function is to checkout all the required GIT repositories.
	// Checkout Environment configurations.
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "ENV"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: "https://github.vodafone.com/VFUK-INTEGRATION/${env.EnvironmentRepository}.git"]]]
	
	// Checkout Automation files from GITHUB repository.
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "AUTOMATION"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
	
	
	checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'JENKINS_FILE']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_DevOps_Framework.git']]])

	// Checkout BW Configuration Repository
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "APPLICATION"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_BW_Application_Configuration.git']]]	
}

def run_sql_deploy_stage_function(){
	// This function is for SQL deployment.
	// Call sql deploy function by providing environment Details and engines
	println("DEBUG: SQL VERSION IS: " + ENGINE_MAP[ENGINE_NAME]['SQL_VERSION'])
	
	SQL_Functions.sql_deploy_lower_env Environment:"${TARGET_Env}", nexus_group_id:"${env.SQL_GROUPID}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.NEXUS_REPO}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CHANGE_REF_ID}", repo_artifact_ids: ENGINE_NAME + ':' + ENGINE_MAP[ENGINE_NAME]['SQL_VERSION'], datetime:"${date_now}", release:"${params.RELEASE}"
	
	def sql_deployment_success_file = "${WORKSPACE}/AUTOMATION/SQL_Deployment/sqlDeploy_success.txt"
	if(fileExists(sql_deployment_success_file)) {
		def sql_deployment_success_ouput = readFile("${WORKSPACE}/AUTOMATION/SQL_Deployment/sqlDeploy_success.txt")
		if (sql_deployment_success_ouput.size() != 0) {
			
			ENGINE_MAP[ENGINE_NAME]['SQL_Deployment'] = "PASSED"
		}
	}

	def sql_deployment_failed_file = "${WORKSPACE}/AUTOMATION/SQL_Deployment/sqlDeploy_failed.txt"
	if(fileExists(sql_deployment_failed_file)) {
		def sql_deployment_failed_ouput = readFile("${WORKSPACE}/AUTOMATION/SQL_Deployment/sqlDeploy_failed.txt")
		if (sql_deployment_failed_ouput.size() != 0) {
			ENGINE_MAP[ENGINE_NAME]['SQL_Deployment'] = "FAILED"
			ENGINE_MAP[ENGINE_NAME]['RESULT'] = "FAILED"
			
		}
	}		
	echo "SQL_DEPLOYMENT stage completed"
	
}


def run_sql_rollback_function(){
	// This function runs the rollback for SQL.
	SQL_Functions.sql_explicit_rollback_lower_env Environment:"${TARGET_Env}", crq_no:"${params.CHANGE_REF_ID}", repo_artifact_ids: ENGINE_NAME + ':' + ENGINE_MAP[ENGINE_NAME]['SQL_VERSION'], datetime:"${date_now}", release:"${params.RELEASE}"
	echo "SQL Roll Back Completed"
}

def run_ems_deploy_stage_function(){
	// This function is for EMS deployment.
	
	// Call ems deploy function by providing Environment Details and engines
	EMS_Functions.ems_deployment_lower_env Environment:"${TARGET_Env}", crq_no:"${params.CHANGE_REF_ID}", ems_engines:ENGINE_NAME + ':' + ENGINE_MAP[ENGINE_NAME]['EMS_VERSION'], datetime:"${date_now}", release:"${params.RELEASE}", emsIgnore:"${env.emsIgnore}", rollbackBackup:false
	
	// Update Maps with Successful engines
	def ems_deployment_success_file = "${WORKSPACE}/AUTOMATION/EMS_Deployment/deploy_failure.txt"
	if(fileExists(ems_deployment_success_file)) {
		def ems_deployment_success_ouput = readFile("${WORKSPACE}/AUTOMATION/EMS_Deployment/deploy_failure.txt")
		if (ems_deployment_success_ouput.size() != 0) {
			
			ENGINE_MAP[ENGINE_NAME]['EMS_Deployment'] = "FAILED"
			ENGINE_MAP[ENGINE_NAME]['RESULT'] = "FAILED"
			
		}
	}
	// Update Maps with failed engines
	def ems_deployment_failed_file = "${WORKSPACE}/AUTOMATION/EMS_Deployment/deploy_success.txt"
	if(fileExists(ems_deployment_failed_file)) {
		def ems_deployment_failed_ouput = readFile("${WORKSPACE}/AUTOMATION/EMS_Deployment/deploy_success.txt")
		if (ems_deployment_failed_ouput.size() != 0) {
			ENGINE_MAP[ENGINE_NAME]['EMS_Deployment'] = "PASSED"
		}
	}
	
		
}


def run_file_generate_stage_function(){
		
        //commonFunctions.checkAnsibleConnection host_list:"${TARGET_Env}_File", automation_dir:"AUTOMATION"
		// This function is to validate files for deployment and also to copy the files to workspace.
		//[CICD-1820]: Fix for the regression issue caused due to CICD-1783 changes.
		if(ENGINE_MAP[ENGINE_NAME]['XML_FILES'] != 'NA' && ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"){
			chk = FILE_Functions.validate_files_lt_env Host: "${TARGET_Env}", Deployment_Type: "XML_Files", engine_files: ENGINE_MAP[ENGINE_NAME]['XML_FILES'], RELEASE: "${params.RELEASE}", engine_name: ENGINE_NAME
			if(chk == "FAIL"){
				ENGINE_MAP[ENGINE_NAME]['XML_Deployment'] = "FAILED"
				ENGINE_MAP[ENGINE_NAME]['RESULT'] = "FAILED"
			}
		}

		if(ENGINE_MAP[ENGINE_NAME]['JAR_FILES'] != 'NA' && ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"){
			chk = FILE_Functions.validate_files_lt_env Host: "${TARGET_Env}", Deployment_Type: "JAR_Files", engine_files: ENGINE_MAP[ENGINE_NAME]['JAR_FILES'], RELEASE: "${params.RELEASE}", engine_name: ENGINE_NAME
			if(chk == "FAIL"){
				ENGINE_MAP[ENGINE_NAME]['JAR_Deployment'] = "FAILED"
				ENGINE_MAP[ENGINE_NAME]['RESULT'] = "FAILED"
			}
		}
		if(ENGINE_MAP[ENGINE_NAME]['EMAIL_FILES'] != 'NA' && ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"){
			chk = FILE_Functions.validate_files_lt_env Host: "${TARGET_Env}", Deployment_Type: "Email_Template", engine_files: ENGINE_MAP[ENGINE_NAME]['EMAIL_FILES'], RELEASE: "${params.RELEASE}", engine_name: ENGINE_NAME
			if(chk == "FAIL"){
				ENGINE_MAP[ENGINE_NAME]['EMAIL_Deployment'] = "FAILED"
				ENGINE_MAP[ENGINE_NAME]['RESULT'] = "FAILED"
			}
		}	
}

def run_file_deploy_stage_function() {
	// This function is to deploy files into LinkTest Environment.
		// This function is to validate files for deployment and also to copy the files to workspace.
		if(ENGINE_MAP[ENGINE_NAME]['XML_FILES'] != 'NA' && ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"){
			FILE_Functions.deploy_files_lower_env Host:"${TARGET_Env}", Deployment_Type: "XML_Files", engine_files: ENGINE_NAME + ':' + ENGINE_MAP[ENGINE_NAME]['XML_FILES'], crq_no:"${params.CHANGE_REF_ID}", datetime:"${date_now}" 
			ENGINE_MAP[ENGINE_NAME]['XML_Deployment'] = "PASSED"
		}
		
		if(ENGINE_MAP[ENGINE_NAME]['JAR_FILES'] != 'NA' && ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"){
			FILE_Functions.deploy_files_lower_env Host:"${TARGET_Env}", Deployment_Type: "JAR_Files", engine_files: ENGINE_NAME + ':' + ENGINE_MAP[ENGINE_NAME]['JAR_FILES'], crq_no:"${params.CHANGE_REF_ID}", datetime:"${date_now}"
			ENGINE_MAP[ENGINE_NAME]['JAR_Deployment'] = "PASSED"			
		}

		if(ENGINE_MAP[ENGINE_NAME]['EMAIL_FILES'] != 'NA' && ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"){
			FILE_Functions.deploy_files_lower_env Host:"${TARGET_Env}", Deployment_Type: "EMAIL_Files", engine_files: ENGINE_NAME + ':' + ENGINE_MAP[ENGINE_NAME]['EMAIL_FILES'], crq_no:"${params.CHANGE_REF_ID}", datetime:"${date_now}" 
			ENGINE_MAP[ENGINE_NAME]['EMAIL_Deployment'] = "PASSED"
		}		
}

def preparation_function() {
	
	// This stage is to construct map and update values with the build input parameters
		date_now = new Date().format("YYYYMMddHHmmss")
		//[CICD-1524]: getting user here to use across the pipeline.
		user = currentBuild.rawBuild.causes[0].userId
		
/* 		properties([parameters([
			string(defaultValue: 'CCS20.5', description: 'Please enter Release', name: 'RELEASE', trim: false), 
			string(defaultValue: 'Test', description: 'Please enter CRQ Number', name: 'CHANGE_REF_ID', trim: false), 
			choice(choices: ['LinkTest'], description: 'Please select environment', name: 'ENVIRONMENT'), 
			string(defaultValue: 'test', description: 'Please enter description', name: 'DESCRIPTION', trim: false)
		])]) */
		
		// Checkout required GIT repositories.
		checkout_git_repositories()

		//Load all functions files from GIT. point to exact source file
		load_groovy_files()
		
        commonFunctions.validate_input_parameters RELEASE: params.RELEASE, CRQ: params.CHANGE_REF_ID, DESCRIPTION: params.Description, BUILD_REQUESTER: params.EMAIL_REQUESTER, OPERATION_NAME: params.OPERATION_NAME, SPECIAL_INSTRUCTIONS: params.SPECIAL_INSTRUCTIONS, FILE_DEPLOYMENT: params.FILE_DEPLOYMENT, DEPLOYMENT_FILES: params.DEPLOYMENT_FILES, ONLY_GV: params.ONLY_GV, MASTER_GV_UPDATE: params.MASTER_GV_UPDATE, PROCESS_GV_UPDATE: params.PROCESS_GV_UPDATE
        
		if(params.BW_VERSION){
			commonFunctions.validate_input_parameters RELEASE: params.RELEASE, BW_VERSION: params.BW_VERSION 
		} 
		
		//[CICD-321]: Automate Applications.txt file to get engines list from domain itself..
		//Disabling getting appslist from admin.
		//BW_Functions.get_domainAppsList Host: "${TARGET_Env}", environment: "${TARGET_Env}", datetime:"${date_now}" 
		
		bw_release_num = RELEASE.replace(".","_")

		majorVersion = RELEASE.split('CCS')[1].split('\\.')[0]
		minorVersion = RELEASE.split('CCS')[1].split('\\.')[1]	
	
		displayName = "${params.RELEASE}_${params.ENGINE_NAME}_${BUILD_NUMBER}"
		currentBuild.displayName = "${displayName}"		
	
		if ("${TARGET_Env}" == "T1" || "${TARGET_Env}" == "T3" || "${TARGET_Env}" == "T4" || "${TARGET_Env}" == "T7"){
			println("Setting value to Env Prefix to SIT")
			Env_Prefix = "SIT" 
		} else {
			println("Setting value to Env Prefix to Environment") 
			Env_Prefix = "${TARGET_Env}"
		}
		//[CICD-476] && [CICD-374] Fix: Added BW, EMS and SQL Duration fields to the map.
		if(ENGINE_NAME != " "){
			ENGINE_MAP[ENGINE_NAME] = ['BW_VERSION':'NA', 'BW_FOLDER_NAME':'NA', 'BW_ENGINE_TYPE':'NA', 'EMS_VERSION':'NA', 'SQL_VERSION':'NA', 'XML_FILES':'NA', 'JAR_FILES':'NA', 'EMAIL_FILES':'NA', 'RESULT':'NA', 'BW_Generation':'NOT_REQUIRED', 'SQL_Deployment':'NOT_REQUIRED', 'EMS_Deployment':'NOT_REQUIRED', 'XML_Deployment':'NOT_REQUIRED', 'JAR_Deployment':'NOT_REQUIRED', 'EMAIL_Deployment':'NOT_REQUIRED', 'BW_Deployment':'NOT_REQUIRED',  'BW_Restart':'NOT_REQUIRED', 'EMS_DURATION':'0', 'SQL_DURATION':'0', 'BW_DURATION':'0', 'FILE_DURATION':'0']
		}
		
        // CICD 1872 check all BW, SQL, File server ansible connectivity
        ansible_hosts=""
		// I fonly GV change required, then set the type as ONLY_GV.
		if(params.BW_VERSION) {
            ansible_hosts+= " " + "${TARGET_Env}_BW"
			//BW deployment required with given version. First validate this version is available in Nexus.
			version_check = nexusFunctions.validate_nexus_version REPO_URL: "${env.REPO_URL}", target_repo: "${env.NEXUS_REPO}", GROUPID: "${env.BW_GROUPID}", engine: ENGINE_NAME, version: params.BW_VERSION, extn: "ear"
			if(version_check.toInteger() != 0) {
				error("Given BW_VERSION is not exisis in NEXUS. Please Verify the version again.")
			}
			
			// Get the BW version for the engine given.
			bw_folder = gitFunctions.get_engine_bw_folder_name_from_gvconf engine: ENGINE_NAME
			if(bw_folder){
				ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME'] =  bw_folder
			} else {
				error("Check the engine name and Folder name in GV conf for proper format")
			}
			
			// get engine type from environment appconf file.
			def type_string = nexusFunctions.get_bw_deployment_type engines: ENGINE_NAME, target_env: "${TARGET_Env}"
			if(type_string){
				ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE'] =  type_string.split(':')[1]
			}

			ENGINE_MAP[ENGINE_NAME]['BW_VERSION'] =  "${params.BW_VERSION}"
			ENGINE_MAP[ENGINE_NAME]['BW_Generation'] =  'NOT_STARTED'
			ENGINE_MAP[ENGINE_NAME]['BW_Deployment'] =  'NOT_STARTED'
			ENGINE_MAP[ENGINE_NAME]['BW_Restart'] =  'NOT_STARTED'
			
		} else if (params.ONLY_GV){
			ansible_hosts+= " " + "${TARGET_Env}_BW"
			// Get the BW Folder name for the engine given.
			bw_folder = gitFunctions.get_engine_bw_folder_name_from_gvconf engine: ENGINE_NAME
			if(bw_folder){
				ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME'] =  bw_folder
			} else {
				error("Check the engine name and Folder name in GV conf for proper format")
			}
			
			ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE'] =  "OnlyGV"
			ENGINE_MAP[ENGINE_NAME]['BW_Generation'] =  'NOT_STARTED'
			ENGINE_MAP[ENGINE_NAME]['BW_Deployment'] =  'NOT_STARTED'
			ENGINE_MAP[ENGINE_NAME]['BW_Restart'] =  'NOT_STARTED'
			ENGINE_MAP[ENGINE_NAME]['BW_VERSION'] =  '0'
			
		} else {
			echo "DEBUG: NO BW Deployment selected."
		}
		
		if(params.EMS_DEPLOYMENT) {
                ansible_hosts+= " " + "${TARGET_Env}_EMS"
				ENGINE_MAP[ENGINE_NAME]['EMS_Deployment'] =  'NOT_STARTED'
		}		
		if(params.SQL_DEPLOYMENT) {
                ansible_hosts+= " " + "${TARGET_Env}_SQL"
                // BW added since after file deployment BW has to be restarted
                ansible_hosts+= " " + "${TARGET_Env}_BW"
				ENGINE_MAP[ENGINE_NAME]['SQL_Deployment'] =  'NOT_STARTED'
				if(ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE'] == 'NA') {
					ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE'] = 'RESTART'
					ENGINE_MAP[ENGINE_NAME]['BW_Restart'] =  'NOT_STARTED'
					ENGINE_MAP[ENGINE_NAME]['BW_VERSION'] =  '1'
					// Get the BW Folder name for the engine given.
					bw_folder = gitFunctions.get_engine_bw_folder_name_from_gvconf engine: ENGINE_NAME
					if(bw_folder){
						ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME'] =  bw_folder
					} else {
						error("Check the engine name and Folder name in GV conf for proper format")
					}
				}
		}
		if(params.FILE_DEPLOYMENT) {
			
			
			ansible_hosts+= " " + "${TARGET_Env}_File"
            // BW added since after file deployment BW has to be restarted
            ansible_hosts+= " " + "${TARGET_Env}_BW"
			// Set BW_ENGINE TYPE As RESTART only when any of the file deployment is selected.
			if(ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE'] == 'NA') {
					ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE'] = 'RESTART'
					ENGINE_MAP[ENGINE_NAME]['BW_Restart'] =  'NOT_STARTED'
					ENGINE_MAP[ENGINE_NAME]['BW_VERSION'] =  '1'
					// Get the BW Folder name for the engine given.
					bw_folder = gitFunctions.get_engine_bw_folder_name_from_gvconf engine: ENGINE_NAME
					if(bw_folder){
						ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME'] =  bw_folder
					} else {
						error("Check the engine name and Folder name in GV conf for proper format")
					}
			}
			FILE_DEPLOYMENT.split(',').each { type ->
			
				//[CICD-1820]: Fix for the regression issue caused due to CICD-1783 changes.
				if(type == "XML"){
					def XML_Files = gitFunctions.getEngineFiles_lt engines: ENGINE_NAME, type: "XML", env: "${TARGET_Env}", RELEASE: "${params.RELEASE}"
					if(XML_Files){
						echo "DEBUG: XML_Files are: ${XML_Files}"
						ENGINE_MAP[ENGINE_NAME]['XML_FILES'] =  XML_Files.split(':')[1]
						ENGINE_MAP[ENGINE_NAME]['XML_Deployment'] =  'NOT_STARTED'
					}
				}
				if(type == "JAR"){
					def JAR_Files = gitFunctions.getEngineFiles_lt engines: ENGINE_NAME, type: "Jar", env: "${TARGET_Env}", RELEASE: "${params.RELEASE}"
					if(JAR_Files){
						echo "DEBUG: JAR_Files are: ${JAR_Files}"
						ENGINE_MAP[ENGINE_NAME]['JAR_FILES'] =  JAR_Files.split(':')[1]
						ENGINE_MAP[ENGINE_NAME]['JAR_Deployment'] =  'NOT_STARTED'
					}
				}
				if(type == "EMAIL"){
					def Email_Files = gitFunctions.getEngineFiles_lt engines: ENGINE_NAME, type: "Email", env: "${TARGET_Env}", RELEASE: "${params.RELEASE}"
					if(Email_Files){
						ENGINE_MAP[ENGINE_NAME]['EMAIL_FILES'] =  Email_Files.split(':')[1]
						ENGINE_MAP[ENGINE_NAME]['EMAIL_Deployment'] =  'NOT_STARTED'
					}
				}				
			}
			
	}
    
    //commonFunctions.checkAnsibleConnection host_list:"${ansible_hosts}", automation_dir:"AUTOMATION"
    
    // Change the folder names for testing.
	
/* 	
	if(ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME'] == "SB01"){
			ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME'] = "ServiceBus1"
		}
	if(ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME'] == "SB02"){
			ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME'] = "ServiceBus2"
		} */	
}


def bw_generate_stage(){
	
	// Construct Description for engine
	
	//[CICD-539] Insert Deployment metadata to release notes DB. Changing user as global variable.
//[CICD-1524]: Commenting user assignment here, as it is populating only when BW_Generation is done. Moving to preparation function.
	
	//user = currentBuild.rawBuild.causes[0].userId
	//println(user);
	//def desc = "${params.DESCRIPTION}".trim() + "|" + "${user}"
	//[CICD-519]: Fix to handle special characters in DESCRIPTION part
    //ADO 630550 Single quotes issues when inserting into DB or unix script
	String desc = "${params.DESCRIPTION}".replaceAll("'","").replaceAll(/(!|"|'|@|#|\$|%|&|\\/|\(|\)|=|\?)/, /\\$0/)
	desc = desc + "|" + "${user}"	
	
	
		
		
			BW_type = ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE']
			echo "DEBUG: BW_type is: ${BW_type}"
			BW_Folder = ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME']
			echo "DEBUG: BW_Foldername is: ${BW_Folder}"
			group_id = 1
			patteren_string = BW_type+"_"+BW_Folder+"_"+group_id
			echo "DEBUG: Pattern string is: ${patteren_string}"
			
			def engines_versions = "${params.ENGINE_NAME}"+":"+"${params.BW_VERSION}"
			echo "DEBUG: Engine Name is: ${engines_versions}"
			
			def engines_list = "${params.ENGINE_NAME}"
			
		
        //commonFunctions.checkAnsibleConnection host_list:"${TARGET_Env}_BW", automation_dir:"AUTOMATION"
		
		if(BW_type == "Existing"){
			
			println("DEBUG:" + group_id + "Generate conf file for type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list + " and engine version string is: " + engines_versions)
			
			BW_Functions.generate_conf_files_existing_engines engines:engines_versions, Host:"${TARGET_Env}", ReleaseNumber:"${params.RELEASE}", folderName:BW_Folder, description:"${desc}", use_tag: "no"
			
			BW_Functions.generate_bw_deployment Host:"${TARGET_Env}", nexus_group_id:"${env.BW_GROUPID}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.NEXUS_REPO}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CHANGE_REF_ID}", engines:engines_versions, datetime:"${date_now}", engines_list:engines_list, EnvPrefix:"${Env_Prefix}", deployment_type:"EXISTING", release:"${params.RELEASE}", onlyGVChange:false, folderName:BW_Folder, bw_folder_release:bw_release_num, engine_group:patteren_string
		} else if(BW_type == "New") {
			
			println("DEBUG:" + group_id + "Generate conf file for type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list + " and engine version string is: " + engines_versions)
			BW_Functions.generate_conf_files_new_engines engines:engines_versions, Host:"${TARGET_Env}", ReleaseNumber:"${params.RELEASE}", folderName:BW_Folder, description:"${desc}", instanceCount:"${env.BW_InstanceCount}", use_tag: "no"
			// Call generate function by passing details
			
			BW_Functions.generate_bw_deployment Host:"${TARGET_Env}", nexus_group_id:"${env.BW_GROUPID}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.NEXUS_REPO}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CHANGE_REF_ID}", engines:engines_versions, datetime:"${date_now}", engines_list:engines_list, EnvPrefix:"${Env_Prefix}", deployment_type:"NEW", release:"${params.RELEASE}", onlyGVChange:false, folderName:BW_Folder, bw_folder_release:bw_release_num, engine_group:patteren_string
		} else if (BW_type == "OnlyGV") {
			
			println("DEBUG:" + group_id + "Generate conf file for type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list + " and engine version string is: " + engines_versions)
			BW_Functions.generate_conf_files_gv_change engines:engines_versions, Host:"${TARGET_Env}", ReleaseNumber:"${params.RELEASE}", folderName:BW_Folder, description:"${desc}", use_tag: "no"
			
			// Call generate function by passing details
			BW_Functions.generate_bw_deployment Host:"${TARGET_Env}", nexus_group_id:"${env.BW_GROUPID}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.NEXUS_REPO}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CHANGE_REF_ID}", engines:engines_versions, datetime:"${date_now}", engines_list:engines_list, EnvPrefix:"${Env_Prefix}", deployment_type:"EXISTING", release:"${params.RELEASE}", onlyGVChange:true, folderName:BW_Folder, bw_folder_release:bw_release_num, engine_group:patteren_string
			
		} 
		else if (BW_type == "RESTART") {
			
			println("DEBUG:" + group_id + "Generate conf file for type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list)
			BW_Functions.generate_conf_files_restart engines:engines_versions, Host:"${TARGET_Env}", ReleaseNumber:"${params.RELEASE}", folderName:BW_Folder, description:"${desc}"
			
			// Call generate function by passing details
			BW_Functions.generate_bw_restart Host:"${TARGET_Env}", crq_no:"${params.CHANGE_REF_ID}", datetime:"${date_now}", engines_list:engines_list, deployment_type:"EXISTING", folderName:BW_Folder, bw_folder_release:bw_release_num, engine_group:patteren_string
			
		}
		else {
			println("DEBUG: Invalid Deployment type Identified. Please fix this issue")
		}
	
	
	// Update maps with failed engines from BW Generate
	def bw_generate_failed_file = "${WORKSPACE}/${TARGET_Env}/BW_Deployment/generate_failure.txt"
	if(fileExists(bw_generate_failed_file)) {
		def bw_generate_failed_ouput = readFile("${WORKSPACE}/${TARGET_Env}/BW_Deployment/generate_failure.txt")
		if (bw_generate_failed_ouput.size() != 0) {
			def failed_file = new File("${WORKSPACE}/${TARGET_Env}/BW_Deployment/generate_failure.txt")
			def failed_engines_list = failed_file.readLines().join(';')
			ENGINE_MAP[ENGINE_NAME]['BW_Generation'] = "FAILED"
			ENGINE_MAP[ENGINE_NAME]['RESULT'] = "FAILED"
			
		}
	} 

	// Update maps with success engines from BW Generate
	def bw_generate_success_file = "${WORKSPACE}/${TARGET_Env}/BW_Deployment/generate_success.txt"
	if(fileExists(bw_generate_success_file)) {
		def bw_generate_success_ouput = readFile("${WORKSPACE}/${TARGET_Env}/BW_Deployment/generate_success.txt")
		if (bw_generate_success_ouput.size() != 0) {
			def success_file = new File("${WORKSPACE}/${TARGET_Env}/BW_Deployment/generate_success.txt")
			def success_engines_list = success_file.readLines().join(';')
			ENGINE_MAP[ENGINE_NAME]['BW_Generation'] = "PASSED"
		}
	}

}


// Function for BW Deployment
def bw_deployment_stage(){ 

			BW_type = ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE']
			echo "DEBUG: BW_type is: ${BW_type}"
			BW_Folder = ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME']
			echo "DEBUG: BW_Foldername is: ${BW_Folder}"
			group_id = 1
			patteren_string = BW_type+"_"+BW_Folder+"_"+group_id
			echo "DEBUG: Pattern string is: ${patteren_string}"
			
			def engines_versions = "${params.ENGINE_NAME}"+":"+"${params.BW_VERSION}"
			echo "DEBUG: Engine Name is: ${engines_versions}"
			
			def engines_list = "${params.ENGINE_NAME}"
		
        //[CICD-1760] Ability to ping the array of validate ssh connectivity to all bw engine machines from BW Admin before running BW deployment xxx
        if(BW_type == "Existing" ||  BW_type == "New" || BW_type == "OnlyGV" || BW_type == "RESTART"){
                //commonFunctions.checkAllSSHConnection Host:"${TARGET_Env}",  bw_folder_release:bw_release_num, crq_num:"${params.CHANGE_REF_ID}", datetime:"${date_now}", automation_dir:"AUTOMATION"
        }
        
        if(BW_type == "Existing"){
						
			println("DEBUG:" + group_id + "Deploy engines of type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list + " and engine version string is: " + engines_versions)
						
			// Run BW deploy function
			 BW_Functions.bw_deploy Host:"${TARGET_Env}", crq_no:"${params.CHANGE_REF_ID}", engines:engines_versions, datetime:"${date_now}", engines_list:engines_list, appDynamics:false, FolderName:BW_Folder, release:"${params.RELEASE}", onlyGVChange:false, deployment_type:"ExistingEngines", bw_folder_release:bw_release_num, engine_group:patteren_string, EnvironmentRepository: "${env.EnvironmentRepository}"
			
		} else if(BW_type == "New") {
			println("DEBUG:" + group_id + "Deploy engines of type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list + " and engine version string is: " + engines_versions)
						
			// Run BW deploy function
			BW_Functions.bw_deploy Host:"${TARGET_Env}", crq_no:"${params.CHANGE_REF_ID}", engines:engines_versions, datetime:"${date_now}", engines_list:engines_list, appDynamics:false, FolderName:BW_Folder, release:"${params.RELEASE}", onlyGVChange:false, deployment_type:"NewEngines", bw_folder_release:bw_release_num, engine_group:patteren_string, EnvironmentRepository: "${env.EnvironmentRepository}"
			
		
		} else if (BW_type == "OnlyGV") {
			println("DEBUG:" + group_id + "Deploy engines of type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list + " and engine version string is: " + engines_versions)
						
			// Run BW deploy function
			BW_Functions.bw_deploy Host:"${TARGET_Env}", crq_no:"${params.CHANGE_REF_ID}", engines:engines_versions, datetime:"${date_now}", engines_list:engines_list, appDynamics:false, FolderName:BW_Folder, release:"${params.RELEASE}", onlyGVChange:true, deployment_type:"ExistingEngines", bw_folder_release:bw_release_num, engine_group:patteren_string, EnvironmentRepository: "${env.EnvironmentRepository}"
			
						
		} else {
			println("DEBUG: Invalid Deployment type Identified. Nothing to deploy")
		}
	

	// Updating maps for failed engines
	
	def bw_deployment_failed_file = "${WORKSPACE}/${TARGET_Env}/BW_Deployment/deployment_failure.txt"
	if(fileExists(bw_deployment_failed_file)) {
		def bw_deployment_failed_ouput = readFile("${WORKSPACE}/${TARGET_Env}/BW_Deployment/deployment_failure.txt")
		if (bw_deployment_failed_ouput.size() != 0) {
			def failed_file = new File("${WORKSPACE}/${TARGET_Env}/BW_Deployment/deployment_failure.txt")
			ENGINE_MAP[ENGINE_NAME]['BW_Deployment'] = "FAILED"
			ENGINE_MAP[ENGINE_NAME]['RESULT'] = "FAILED"
			
		}
	}

 // Updating maps for engine engines

	def bw_deployment_success_file = "${WORKSPACE}/${TARGET_Env}/BW_Deployment/deployment_success.txt"
	if(fileExists(bw_deployment_success_file)) {
		def bw_deployment_success_ouput = readFile("${WORKSPACE}/${TARGET_Env}/BW_Deployment/deployment_success.txt")
		if (bw_deployment_success_ouput.size() != 0) {
			def success_file = new File("${WORKSPACE}/${TARGET_Env}/BW_Deployment/deployment_success.txt")
			ENGINE_MAP[ENGINE_NAME]['BW_Deployment'] = "PASSED"
		}
		
	// Sharing GV diff Report when deployement is successful
    
	email_gv_diff_report env: "${TARGET_Env}"
    // Calling Dashboard Publish job
	//[CICD-476] & [CICD-374] commenting following as we are calling common function to update dashboard and stats file.
	//build job: '/TIL_PIPELINES/Common_Jobs/Dashboard_Publish', parameters: [string(name: 'Environment', value: 'LinkTest'), string(name: 'Component', value: "${params.ENGINE_NAME}"), string(name: 'ArtefactVersion', value: "${params.BW_VERSION}"), string(name: 'Pipeline', value: 'TIL_BW_EMS_SQL_Pipeline'), string(name: 'Description', value: '')]	
	}
	// Trigger Result Email
	//trigger_results_email map: ENGINE_MAP, REPORT_STAGE: "BW_Deployment"

}


// Function for BW Restart

def bw_restart_stage(){ 
			
	BW_type = ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE']
	echo "DEBUG: BW_type is: ${BW_type}"
	BW_Folder = ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME']
	echo "DEBUG: BW_Foldername is: ${BW_Folder}"
	group_id = 1
	patteren_string = BW_type+"_"+BW_Folder+"_"+group_id
	def engines_list = "${params.ENGINE_NAME}"
	echo "DEBUG: Pattern string is: ${patteren_string}"
	// Calling Restart Function
	BW_Functions.bw_restart Host:"${TARGET_Env}", crq_no:"${params.CHANGE_REF_ID}", datetime:"${date_now}", bw_folder_release:bw_release_num, engine_group:patteren_string, folderName:BW_Folder, engines_list_restart:engines_list	
		
	  
	// Check if BW Restart file exists for Failures
	def bw_restart_failed_file = "${WORKSPACE}/${TARGET_Env}/BW_Deployment/restart_failure.txt"
	if(fileExists(bw_restart_failed_file)) {
		def bw_restart_failed_ouput = readFile("${WORKSPACE}/${TARGET_Env}/BW_Deployment/restart_failure.txt")
		if (bw_restart_failed_ouput.size() != 0) {
		    // Reading Restart Failure
			def failed_file = new File("${WORKSPACE}/${TARGET_Env}/BW_Deployment/restart_failure.txt")
			ENGINE_MAP[ENGINE_NAME]['BW_Restart'] = "FAILED"
			ENGINE_MAP[ENGINE_NAME]['RESULT'] = "FAILED"
			
			
		}							
	}
	else{
		
		// Reading restart successful engines file 
		def bw_restart_success_file = "${WORKSPACE}/${TARGET_Env}/BW_Deployment/restart_success.txt"
	    if(fileExists(bw_restart_success_file)) {
			  def bw_restart_success_ouput = readFile("${WORKSPACE}/${TARGET_Env}/BW_Deployment/restart_success.txt")
			  def success_file = new File("${WORKSPACE}/${TARGET_Env}/BW_Deployment/restart_success.txt")
			  ENGINE_MAP[ENGINE_NAME]['BW_Restart'] = "PASSED"
			  ENGINE_MAP[ENGINE_NAME]['RESULT'] = "PASSED"
		}
	}
	
	
}

def artefact_promotion_stage(){
	
	// Artefact promotion
	
	//[CICD-1536]: commenting promotion activity from LT pipeline. All artefact promotions should happen from standalone utility going forward.
	
/* 	println("Artefact Promotion")
	LinkTestBWApprovers = get_approvers_list('LinkTestBWApprovers')
	
	def promotion_email_body = "${emailFunctions.get_lt_results_summary map: ENGINE_MAP, REPORT_STAGE: 'PROMOTE_ARTEFACTS', crq_num: params.CHANGE_REF_ID, release: params.RELEASE}"
	
	emailext mimeType: 'text/html',
	subject: "[Jenkins]:${currentBuild.fullDisplayName}:Approval email for promote Artefact to SIT",
	from:"TIL_DEPLOYMENTS@vodafone.com",
	to: "${dev_mailRecipients}",
	body: 	"${promotion_email_body}" + "<br>" + 
		"<br><br><p><b><font size='4' color='Black'>Signoff LinkTest Changes for deploying into SIT: <a href='${BUILD_URL}input'>${currentBuild.displayName}</a></font></b></p>"

	//[CICD-346]: enhanced script to give option to proceed with promotion or skip.
	def userInput = input( id: 'userInput', message: 'Do you want to promote Artefact to SIT?',
				parameters: [[$class: 'ChoiceParameterDefinition', defaultValue: 'SKIP_PROMOTION', 
					description:'describing choices', name:'nameChoice', choices: "SKIP_PROMOTION\nPROCEED_PROMOTION"]
					],
				submitterParameter: 'submitter',
				submitter: "${LinkTestBWApprovers}"
	)

	println("DEBUG: Choice selected is: " + userInput.nameChoice)
	if(userInput.nameChoice == "PROCEED_PROMOTION"){	
			if(ENGINE_MAP[ENGINE_NAME]['RESULT'] == "PASSED" && ENGINE_MAP[ENGINE_NAME]['EMS_VERSION'] != "NA") {
				
				// Call artefacts promotion function with these details.
				artifactPromotion artifactId: ENGINE_NAME, classifier: '', debug: true, extension: 'tar.gz', groupId: "${env.EMS_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.Promotion_Repo}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.NEXUS_REPO}", stagingUser: "${env.NEXUS_USER}", version: ENGINE_MAP[ENGINE_NAME]['EMS_VERSION']

				artifactPromotion artifactId: ENGINE_NAME, classifier: '', debug: true, extension: 'txt', groupId: "${env.EMS_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.Promotion_Repo}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.NEXUS_REPO}", stagingUser: "${env.NEXUS_USER}", version: ENGINE_MAP[ENGINE_NAME]['EMS_VERSION']
			}
			 
			if(ENGINE_MAP[ENGINE_NAME]['RESULT'] == "PASSED" && ENGINE_MAP[ENGINE_NAME]['SQL_VERSION'] != "NA") {
				
				
				// Call artefacts promotion function with these details.
				artifactPromotion artifactId: ENGINE_NAME, classifier: '', debug: true, extension: 'tar.gz', groupId: "${env.SQL_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.Promotion_Repo}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.NEXUS_REPO}", stagingUser: "${env.NEXUS_USER}", version: ENGINE_MAP[ENGINE_NAME]['SQL_VERSION']

				artifactPromotion artifactId: ENGINE_NAME, classifier: '', debug: true, extension: 'txt', groupId: "${env.SQL_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.Promotion_Repo}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.NEXUS_REPO}", stagingUser: "${env.NEXUS_USER}", version: ENGINE_MAP[ENGINE_NAME]['SQL_VERSION']
			}
			  //CICD-343 Fix. Modifiied the if condition and to compare integer values.
			if(ENGINE_MAP[ENGINE_NAME]['RESULT'] == "PASSED" && ENGINE_MAP[ENGINE_NAME]['BW_VERSION'] != "NA" && ENGINE_MAP[ENGINE_NAME]['BW_VERSION'] != "0" && ENGINE_MAP[ENGINE_NAME]['BW_VERSION'] != "1") {
					// Call artefacts promotion function with these details.
					artifactPromotion artifactId: ENGINE_NAME, classifier: '', debug: true, extension: 'ear', groupId: "${env.BW_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.Promotion_Repo}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.NEXUS_REPO}", stagingUser: "${env.NEXUS_USER}", version: ENGINE_MAP[ENGINE_NAME]['BW_VERSION']

					artifactPromotion artifactId: ENGINE_NAME, classifier: '', debug: true, extension: 'appconf', groupId: "${env.BW_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.Promotion_Repo}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.NEXUS_REPO}", stagingUser: "${env.NEXUS_USER}", version: ENGINE_MAP[ENGINE_NAME]['BW_VERSION']

					artifactPromotion artifactId: ENGINE_NAME, classifier: '', debug: true, extension: 'html', groupId: "${env.BW_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.Promotion_Repo}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.NEXUS_REPO}", stagingUser: "${env.NEXUS_USER}", version: ENGINE_MAP[ENGINE_NAME]['BW_VERSION']

					artifactPromotion artifactId: ENGINE_NAME, classifier: '', debug: true, extension: 'proddiff', groupId: "${env.BW_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.Promotion_Repo}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.NEXUS_REPO}", stagingUser: "${env.NEXUS_USER}", version: ENGINE_MAP[ENGINE_NAME]['BW_VERSION']

					artifactPromotion artifactId: ENGINE_NAME, classifier: '', debug: true, extension: 'txt', groupId: "${env.BW_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.Promotion_Repo}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.NEXUS_REPO}", stagingUser: "${env.NEXUS_USER}", version: ENGINE_MAP[ENGINE_NAME]['BW_VERSION']
			}
			
			//[CICD-437]: Fix to generate SIT release notes after promotion activity.
			
			def emailContent = 	emailFunctions.get_release_notes_bw_sit map: ENGINE_MAP, ENGINE_NAME: ENGINE_NAME, RELEASE: "${params.RELEASE}", CRQ: "${params.CHANGE_REF_ID}", Description: "${params.DESCRIPTION}", operationName: OPERATION_NAME.replaceAll("[\\t\\n\\r]+","<br>"), projectName: PROJECT_NAME.replaceAll("[\\t\\n\\r]+","<br>"), buildRequester: "${params.EMAIL_REQUESTER}", fileChanges: DEPLOYMENT_FILES.replaceAll("[\\t\\n\\r]+","<br>"), masterGV: MASTER_GV_UPDATE.replaceAll("[\\t\\n\\r]+","<br>"), processGV: PROCESS_GV_UPDATE.replaceAll("[\\t\\n\\r]+","<br>"), engineTemplate: NEW_ENGINE_TEMPLATE.replaceAll("[\\t\\n\\r]+","<br>"), append_prepend: APPEND_PREPEND_PATHS.replaceAll("[\\t\\n\\r]+","<br>"), manualChanges: POST_MANUAL_CHANGES.replaceAll("[\\t\\n\\r]+","<br>"), knownErrors: KNOWN_ERRORS_UPDATE.replaceAll("[\\t\\n\\r]+","<br>"), certChanges: CERTIFICATE_UPDATE.replaceAll("[\\t\\n\\r]+","<br>"), specialInst: SPECIAL_INSTRUCTIONS.replaceAll("[\\t\\n\\r]+","<br>")
			
			emailext mimeType: 'text/html',
				subject: "[Jenkins]:${currentBuild.fullDisplayName}:SIT RELEASE NOTES FOR ${ENGINE_NAME} for ${params.RELEASE}",
				from:"TIL_SIT_RELEASENOTES@vodafone.com",
				to: "${dev_mailRecipients}",
				body: "${emailContent}"			
			
	} else {
		println("DEBUG: Skipping promotion activity")
	} */
	
	
	
	//[CICD-437]: Fix to generate SIT release notes after promotion activity.
			
	def emailContent = 	emailFunctions.get_release_notes_bw_sit map: ENGINE_MAP, ENGINE_NAME: ENGINE_NAME, RELEASE: "${params.RELEASE}", CRQ: "${params.CHANGE_REF_ID}", Description: "${params.DESCRIPTION}", operationName: OPERATION_NAME.replaceAll("[\\t\\n\\r]+","<br>"), projectName: PROJECT_NAME.replaceAll("[\\t\\n\\r]+","<br>"), buildRequester: "${params.EMAIL_REQUESTER}", fileChanges: DEPLOYMENT_FILES.replaceAll("[\\t\\n\\r]+","<br>"), masterGV: MASTER_GV_UPDATE.replaceAll("[\\t\\n\\r]+","<br>"), processGV: PROCESS_GV_UPDATE.replaceAll("[\\t\\n\\r]+","<br>"), engineTemplate: NEW_ENGINE_TEMPLATE.replaceAll("[\\t\\n\\r]+","<br>"), append_prepend: APPEND_PREPEND_PATHS.replaceAll("[\\t\\n\\r]+","<br>"), manualChanges: POST_MANUAL_CHANGES.replaceAll("[\\t\\n\\r]+","<br>"), knownErrors: KNOWN_ERRORS_UPDATE.replaceAll("[\\t\\n\\r]+","<br>"), certChanges: CERTIFICATE_UPDATE.replaceAll("[\\t\\n\\r]+","<br>"), specialInst: SPECIAL_INSTRUCTIONS.replaceAll("[\\t\\n\\r]+","<br>")
	
	emailext mimeType: 'text/html',
		subject: "[Jenkins]:${currentBuild.fullDisplayName}:SIT RELEASE NOTES FOR ${ENGINE_NAME} for ${params.RELEASE}",
		from:"TIL_SIT_RELEASENOTES@vodafone.com",
		to: "${dev_mailRecipients}",
		body: "${emailContent}"
	
	
	//[CICD-1536]: commenting promotion activity from LT pipeline. All artefact promotions should happen from standalone utility going forward. ---- Changes ends here
	
	//[CICD-539] Insert Deployment metadata to release notes DB.
	def deployment_time = ENGINE_MAP[ENGINE_NAME]['SQL_DURATION'] + ENGINE_MAP[ENGINE_NAME]['EMS_DURATION'] + ENGINE_MAP[ENGINE_NAME]['BW_DURATION']
	println("DEBUG: Total Deployment duration is: " + deployment_time)
	
	//[CICD-1443] Adding ENGINE_TYPE parameter 
	// Insert data into CICD_RELEASE_SUMMARY Table.
	//[CICD-1761]: Fix to insert BUILD_ID and BUILD_URL into the database"
	//ADO 551314 Single quotes issues when inserting into DB
   str_DESCRIPTION = "${params.DESCRIPTION}".replaceAll("'","''")
   str_PROCESS_GV_UPDATE = "${params.PROCESS_GV_UPDATE}".replaceAll("'","''")
   str_MASTER_GV_UPDATE = "${params.MASTER_GV_UPDATE}".replaceAll("'","''")
   str_KNOWN_ERRORS_UPDATE = "${params.KNOWN_ERRORS_UPDATE}".replaceAll("'","''")
   str_POST_MANUAL_CHANGES = "${params.POST_MANUAL_CHANGES}".replaceAll("'","''")
   str_SPECIAL_INSTRUCTIONS = "${params.SPECIAL_INSTRUCTIONS}".replaceAll("'","''")
    
   def release_ins_query = """Insert into CICD_RELEASE_SUMMARY (RELEASE_NO,PROJECT_NAME,JIRA_NO,CHANGE_DESCRIPTION,ENGINE_NAME,OPERATION,EAR_VERSION,EMS_VERSION,SQL_VERSION,COMPONENT_TYPE,STATUS,MASTER_GV,PROCESS_GV,ENGINE_TEMPLATE,APPEND_PREPEND,KNOWN_ERROR_INCLUSION,POST_MANUAL_CHANGES,PARTNER_DATA,GATEWAY_TOKEN,SPECIAL_INSTRUCTIONS,LINKTEST_RESULTS,CREATED_ON,GATEWAY_VERSION,GATEWAY_TYPE,CREATED_BY,FILE_CHANGES,APPROVAL,ENGINE_TYPE,BUILD_ID,BUILD_URL) values ('${params.RELEASE}','${params.PROJECT_NAME}','${params.CHANGE_REF_ID}','${str_DESCRIPTION}','${params.ENGINE_NAME}','${params.OPERATION_NAME}','${ENGINE_MAP[ENGINE_NAME]['BW_VERSION']}','${ENGINE_MAP[ENGINE_NAME]['EMS_VERSION']}','${ENGINE_MAP[ENGINE_NAME]['SQL_VERSION']}','ISTIL','Active','${str_MASTER_GV_UPDATE}','${str_PROCESS_GV_UPDATE}','${params.NEW_ENGINE_TEMPLATE}','${params.APPEND_PREPEND_PATHS}','${str_KNOWN_ERRORS_UPDATE}','${str_POST_MANUAL_CHANGES}',null,null,'${str_SPECIAL_INSTRUCTIONS}','${ENGINE_MAP[ENGINE_NAME]['RESULT']}',sysdate,null,null,'${user}','${params.DEPLOYMENT_FILES}','null','${params.ENGINE_TYPE}','${BUILD_ID}','${BUILD_URL}')"""	
	
	println("DEBUG: release notes Insert query is: " + release_ins_query)
	DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: release_ins_query 	
}

def run_ems_rollback_function(){
	
	
	

    // Call rollback function by providing environment Details and engines
	EMS_Functions.ems_rollback_lower_env Environment:"${TARGET_Env}", crq_no:"${params.CHANGE_REF_ID}", ems_engines:"${ENGINE_NAME}", datetime:"${date_now}", release:"${params.RELEASE}", emsIgnore:"${env.emsIgnore}", rollbackBackup:false
}

def run_bw_rollback_function(){
	
	BW_type = ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE']
	echo "DEBUG: BW_type is: ${BW_type}"
	BW_Folder = ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME']
	echo "DEBUG: BW_Foldername is: ${BW_Folder}"
	group_id = 1
	patteren_string = BW_type+"_"+BW_Folder+"_"+group_id
	echo "DEBUG: Pattern string is: ${patteren_string}"
	
	def engines_versions = "${params.ENGINE_NAME}"+":"+"${params.BW_VERSION}"
	echo "DEBUG: Engine Name is: ${engines_versions}"
	
	def engines_list = "${params.ENGINE_NAME}"	
	// Run BW RB Rollback function
	
	 BW_Functions.bw_rollback_RB Host:"${TARGET_Env}", crq_no:"${params.CHANGE_REF_ID}", datetime:"${date_now}", bw_folder_release:bw_release_num, engine_group:patteren_string, folderName:BW_Folder, EnvironmentRepository: "${env.EnvironmentRepository}", engines_list:engines_list

}

	
	

ENGINE_MAP = [:]
version_check = ""
ReleaseApprovers = ""
date_now = " "
emailBody = " "
displayName = ""
bw_release_num = ""
Env_Prefix = ""
bw_folder = ""
//[CICD-539] Insert Deployment metadata to release notes DB.
def BWConfigTag = ""
user = ""

// Pipeline parameters.
BW_Deployment_Required = ""
SQL_Deployment_Required = ""
EMS_Deployment_Required = ""
File_Deployment_Required = ""
BW_Deployment_Type = ""
BW_Engines = ""
FolderName = ""
AppDynamics_Update = ""
nexusFunc = ""
emailFunc = ""
mapFunc = ""
TARGET_Env = ""
Env_Prefix = ""
dev_mailRecipients = "tssiukintegrationdevleads@vodafone.com, ${params.EMAIL_REQUESTER}, santosh.kumarjha@vodafone.com, devops-vfuk-integration@vodafone.com, musa.shaik2@vodafone.com"


//ADO 623654 Add timeout to the pipeline 

pipeline {
    agent any
	options {
        preserveStashes(buildCount: 49)
        timeout(time: 10, unit: 'DAYS')
    }

    environment {
		REPO_URL = "http://195.233.197.150:8081/repository"
		NEXUS_URL = "195.233.197.150:8081"
		NEXUS_USER = "admin"
		NEXUS_PASSWD = "admin123"
		Promotion_Repo = "SIT_REPO"
		BW_GROUPID = "TIL_BW"
		EMS_GROUPID = "TIL_EMS"
		SQL_GROUPID="TIL_SQL"
		emsIgnore = "true"
		NEXUS_REPO = "LINKTEST_REPO"
		NEXUS_VERSION="nexus3"
		BW_InstanceCount = 2
		EnvironmentRepository = "TIL_TestEnv_Configurations"
		//[CICD-539] Insert Deployment metadata to release notes DB.
		dbURL = 'jdbc:oracle:thin:@195.233.199.13:33000:TIBTST1'
		dbUserName = 'CICD_OWN_DB01'
		dbPassword = 'TIL_CICD_DB'
		dbDriver = 'oracle.jdbc.driver.OracleDriver'
    }
    stages {
		stage('Preparation') {
			steps {
				script{
					deleteDir()
					
					// ALL ENV SHOULD FOLLOW SAME NAMING Like LNKTest16,LNKTest17 etc.,			
					if ("${params.ENVIRONMENT}" == "LNKTest16"){
						TARGET_Env = "LinkTest" 
					} else if ("${params.ENVIRONMENT}" == "LNKTest17"){
						TARGET_Env = "LNKTst17"
					} else {
						
						TARGET_Env = "${params.ENVIRONMENT}"
					}
					//Call the preparation function.
					preparation_function()
					echo "Preparation is done"
                }				
			}			
		}
		
		stage('SQL Build and Generate') {
			when {
				expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"  && ENGINE_MAP[ENGINE_NAME]['SQL_Deployment'] == "NOT_STARTED" }
			}			
			steps {
				script{
					// Generate SQL Build and push the artefact to Nexus. And get SQL VERSION as return output.
					run_sql_generate_stage_function()
					echo "SQL Build is done"
                }				
			}			
		}
		
		stage('EMS Build and Generate') {
			when {
				expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"  && ENGINE_MAP[ENGINE_NAME]['EMS_Deployment'] == "NOT_STARTED" }
			}			
			steps {
				script{
					// Generate SQL Build and push the artefact to Nexus. And get SQL VERSION as return output.
					run_ems_generate_stage_function()
					echo "EMS Build is done"
                }				
			}			
		}
		stage('FILE Generate') {
			when {
				expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"  && params.FILE_DEPLOYMENT.length() != 0 }
			}			
			steps {
				script{
					run_file_generate_stage_function()
                }				
			}			
		}

		stage('BW Generate') {
		    when {
			     expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"  && ENGINE_MAP[ENGINE_NAME]['BW_VERSION'] != "NA" }
			    }
			steps {
				script {
					//Calling BW  Generate Function	
					bw_generate_stage()
                    trigger_versions_email map: ENGINE_MAP, REPORT_STAGE: "BW_Generate"					
				}
			}
		}		
		
		stage('SQL Deployment') {
			when {
				expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"  && ENGINE_MAP[ENGINE_NAME]['SQL_VERSION'] != "NA" }
			}			
			steps {
				script{
					
					//[CICD-476] Fix: function to get elapsed time duration 
					sqlDuration = elapsedTime {
						run_sql_deploy_stage_function()
					}
					if(sqlDuration){
						ENGINE_MAP[ENGINE_NAME]['SQL_DURATION'] = sqlDuration
					}					
					//trigger_results_email map: ENGINE_MAP, REPORT_STAGE: "SQL Deployment", crq_num: params.CHANGE_REF_ID, release: params.RELEASE
					echo "SQL Deployment is done"
                }				
			}			
		}
		stage('EMS Deployment') {
			when {
				expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"  && ENGINE_MAP[ENGINE_NAME]['EMS_VERSION'] != "NA" }
			}			
			steps {
				script{
					
					//[CICD-476] Fix: function to get elapsed time duration 
					emsDuration = elapsedTime {
						run_ems_deploy_stage_function()
					}
					
					if(emsDuration){
						ENGINE_MAP[ENGINE_NAME]['EMS_DURATION'] = emsDuration
					}					
					//trigger_results_email map: ENGINE_MAP, REPORT_STAGE: "EMS Deployment", crq_num: params.CHANGE_REF_ID, release: params.RELEASE
					echo "EMS Deployment is done"
                }				
			}			
		}
		stage('FILE Deployment') {
			when {
				expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"  && params.FILE_DEPLOYMENT.length() != 0 }
			}			
			steps {
				script{
					
					//[CICD-476] Fix: function to get elapsed time duration 
					fileDuration = elapsedTime {
						run_file_deploy_stage_function()
					}
					if(fileDuration){
						ENGINE_MAP[ENGINE_NAME]['FILE_DURATION'] = fileDuration
					}
					//trigger_results_email map: ENGINE_MAP, REPORT_STAGE: "FILE Deployment", crq_num: params.CHANGE_REF_ID, release: params.RELEASE
					echo "FILE Deployment is done"
                }				
			}			
		}
		
		stage('BW Deployment') {
		    when {
			     expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"  && ENGINE_MAP[ENGINE_NAME]['BW_VERSION'] != "NA" }
			    }
			steps {
				script {
					//[CICD-476] Fix: function to get elapsed time duration 
					bwDuration = elapsedTime {					
						bw_deployment_stage()
					}
					if(bwDuration){
						ENGINE_MAP[ENGINE_NAME]['BW_DURATION'] = "${bwDuration}"
					}
				}
			}
		}
		
		stage('BW Restart') {
		    when {
			     expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"  && ENGINE_MAP[ENGINE_NAME]['BW_VERSION'] != "NA" }
			    }
			steps {
				script {
					input 'Proceed with BW Engine restart ?'
					//Calling BW Restart
					bw_restart_stage()
                    //trigger_versions_email map: ENGINE_MAP, REPORT_STAGE: "BW_Restart"
					if(ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED") {
						if(params.FILE_DEPLOYMENT || ENGINE_MAP[ENGINE_NAME]['BW_Deployment'] == "PASSED"){
							def file_status = ""
							if(params.FILE_DEPLOYMENT){
								file_status = "true"
							} else {
								file_status = "false"
							}
							echo "DEBUG: file status is: ${file_status}"
							// Once BW restart is done successfully, start applying GIT tag to BW Configurations repository with the tag constructed in preparation stage.
							//[CICD-539]: Insert Deployment metadata to release notes DB. Get BW TAG created.
							BWConfigTag = BW_Functions.create_tag ENGINE_NAME: ENGINE_NAME, RELEASE: params.RELEASE, ENGINE_TYPE: ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE'], BW_VERSION: params.BW_VERSION, FILE_DEPLOYMENT: file_status, REPO_NAME: "TIL_BW_Application_Configuration"
						}
					}
				}
			}
		}
		
		stage('Rollback EMS/File/SQL') {
		    steps {
				script {
					trigger_results_email map: ENGINE_MAP, REPORT_STAGE: "Deployment Status", crq_num: params.CHANGE_REF_ID, release: params.RELEASE
					// This section contains rollback functions for all the passed stages if any of the above stage fails.
					if(ENGINE_MAP[ENGINE_NAME]['RESULT'] == "FAILED" && ENGINE_MAP[ENGINE_NAME]['BW_Deployment'] == "PASSED") {
						run_bw_rollback_function()
					}			
					if(ENGINE_MAP[ENGINE_NAME]['RESULT'] == "FAILED" && ENGINE_MAP[ENGINE_NAME]['SQL_Deployment'] == "PASSED") {
						// RUN SQL Rollback function.
						run_sql_rollback_function()
					}
					if(ENGINE_MAP[ENGINE_NAME]['RESULT'] == "FAILED" && ENGINE_MAP[ENGINE_NAME]['EMS_Deployment'] == "PASSED") {
						// RUN EMS Rollback function.
						run_ems_rollback_function()
					}
					if(ENGINE_MAP[ENGINE_NAME]['RESULT'] == "FAILED" && ENGINE_MAP[ENGINE_NAME]['XML_Deployment'] == "PASSED") {
						// RUN XML Rollback function.
						FILE_Functions.rollback_files_lower_env Host:"${TARGET_Env}", Deployment_Type: "XML_Files", engine_files: ENGINE_NAME + ':' + ENGINE_MAP[ENGINE_NAME]['XML_FILES'], crq_no:"${params.CHANGE_REF_ID}", datetime:"${date_now}" 
					}
					if(ENGINE_MAP[ENGINE_NAME]['RESULT'] == "FAILED" && ENGINE_MAP[ENGINE_NAME]['JAR_Deployment'] == "PASSED") {
						// RUN JAR Rollback function.
						FILE_Functions.rollback_files_lower_env Host:"${TARGET_Env}", Deployment_Type: "JAR_Files", engine_files: ENGINE_NAME + ':' + ENGINE_MAP[ENGINE_NAME]['JAR_FILES'], crq_no:"${params.CHANGE_REF_ID}", datetime:"${date_now}" 
					}
					if(ENGINE_MAP[ENGINE_NAME]['RESULT'] == "FAILED" && ENGINE_MAP[ENGINE_NAME]['EMAIL_Deployment'] == "PASSED") {
						// RUN EMAIL Rollback function.
						FILE_Functions.rollback_files_lower_env Host:"${TARGET_Env}", Deployment_Type: "EMAIL_Files", engine_files: ENGINE_NAME + ':' + ENGINE_MAP[ENGINE_NAME]['EMAIL_FILES'], crq_no:"${params.CHANGE_REF_ID}", datetime:"${date_now}" 
					}
					if(ENGINE_MAP[ENGINE_NAME]['RESULT'] == "FAILED") {
						// Fail the pipeline
						 currentBuild.result = 'FAILURE'
					}
					else {
						ENGINE_MAP[ENGINE_NAME]['RESULT'] = "PASSED"
					}
					
					//[CICD-476] Fix: call update function to populate stats into a file.
					//[CICD-374] Fix: Update dash board as well along with stats file.
					commonFunctions.update_report_stats map: ENGINE_MAP, Release: "${params.RELEASE}", environment: "${TARGET_Env}", statsFile: "/opt/tibco/DevOps_Reporting/Report/DevOps_report.txt", pipeline_name: 'TIL_BW_EMS_SQL_Pipeline'					
                    //[CICD-539] Insert Deployment metadata to release notes DB.
					def deployment_time = ENGINE_MAP[ENGINE_NAME]['SQL_DURATION'] + ENGINE_MAP[ENGINE_NAME]['EMS_DURATION'] + ENGINE_MAP[ENGINE_NAME]['BW_DURATION']
					println("DEBUG: Total Deployment duration is: " + deployment_time)
					
					//[CICD-1761]: Fix to insert BUILD_ID and BUILD_URL into the database"
 					// ADO 630550 Single quotes issues when inserting into DB
					str_DESCRIPTION = "${params.DESCRIPTION}".replaceAll("'","''")
 					
					def insert_query = """Insert into CICD_DEPLOYMENT_HISTORY ("Release","DateTime","CRQ","ComponentType","Environment","EngineName","BwVersion","EmsVersion","SqlVersion","GatewayVersion","BwDeploymentType","DeploymentStatus","DeploymentTime","XmlFiles","JarFiles","EmailFiles","RF1Status","RBStatus","RF2Status","DVTStatus","BWConfigTag","ChangeDescription","User","FailureReason","updatedTimestamp","BUILD_ID","BUILD_URL") values ('${params.RELEASE}', sysdate,'${params.CHANGE_REF_ID}','BW','${TARGET_Env}','${ENGINE_NAME}','${ENGINE_MAP[ENGINE_NAME]['BW_VERSION']}','${ENGINE_MAP[ENGINE_NAME]['EMS_VERSION']}','${ENGINE_MAP[ENGINE_NAME]['SQL_VERSION']}','','${ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE']}','Active','${deployment_time}','${ENGINE_MAP[ENGINE_NAME]['XML_FILES']}','${ENGINE_MAP[ENGINE_NAME]['JAR_FILES']}','${ENGINE_MAP[ENGINE_NAME]['EMAIL_FILES']}','','','','','${BWConfigTag}','${str_DESCRIPTION}','${user}','${ENGINE_MAP[ENGINE_NAME]['RESULT']}',sysdate,'${BUILD_ID}','${BUILD_URL}')"""
		
					println("DEBUG: Insert query is: " + insert_query)
		
					DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: insert_query 					
				}
			}
		}
		
		stage('LinkTest Signoff'){
		when {
			expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] == "PASSED" }
			}
		steps {
			script {
				
				// Calling BW Restart Stage function
				artefact_promotion_stage()
				                                
			}
		}
      }
	}	
}	
