
//[CICD-739] Insert Deployment metadata to release notes DB.
import groovy.time.*

import groovy.json.JsonOutput
import groovy.sql.*
import java.sql.Driver
import com.cwctravel.hudson.plugins.extended_choice_parameter.ExtendedChoiceParameterDefinition
import hudson.tasks.Mailer
import hudson.model.User

def elapsedTime(Closure closure){
    def timeStart = new Date()
    closure()
    def timeStop = new Date()
    return TimeCategory.minus(timeStop, timeStart).toMilliseconds()
}

def load_groovy_files() {
	//[CICD-739] Insert Deployment metadata to release notes DB.
	DB_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/dbFunctions.groovy"
	emailFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/UserFunctions.groovy"
}


// Global Parameters to use in the stages.
date_now = new Date().format( 'dd-MM-yyyy' )

// Mail recipents for the individual stages.
//def dev_mailRecipients = "tssiukintegrationdevleads@vodafone.com, ${params.BUILD_REQUESTER}, devops-vfuk-integration@vodafone.com, santosh.kumarjha@vodafone.com"

// Funcation to Get Email List
def get_approvers_list(String str){
	outlist = sh (script: """cat /opt/tibco/.jenkins/config.xml | sed -n \'/role name=\"${str}\"/,\$p\' | sed \'/role>/q\' | grep "sid" | cut -d \'>\' -f 2 | cut -d \'<\' -f 1 | paste -s -d, -""",
			returnStdout: true).trim()
	return """${outlist}"""
}


def sql_deploy(deployParams) {
	script{
			
			// Checkout Automation files from GITHUB repository.
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Environment}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
			
			//Checkout Environment specic configurations (tokens, properties files)
			//checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "RESTART_ENV"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_TestEnv_Configurations.git']]]
			
			
			// Delete all unwanted folders from ${deployParams.Environment} folder.
			sh "ls | grep -v ./${deployParams.Environment}/SQL* | xargs rm -rf"
			
			//Checkout Environment specic configurations (tokens, properties files)
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "SQL_COMMON_CONFIG"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_TestEnv_Configurations.git']]]
			
			// Copy SQL Common configuration folder to ${deployParams.Environment} folder.
			sh "cp -r ./SQL_COMMON_CONFIG/SQL_Common_Configuration ./${deployParams.Environment}/"
			
			// Remove SQL_COMMON_CONFIG directory from the current directory
			sh "rm -rf ./SQL_COMMON_CONFIG"

			// Copy LinkTest.properties files based on environment.
			sh "mkdir -p ./${deployParams.Environment}/SQL_Deployment/conf_properties"
			sh "cp -r ./${deployParams.Environment}/SQL_Common_Configuration/${deployParams.Environment}/${deployParams.Environment}_*.properties ./${deployParams.Environment}/SQL_Deployment/conf_properties"
						
			//Copy host_vars file to target location.
			sh "cp -r ./${deployParams.Environment}/SQL_Common_Configuration/${deployParams.Environment} ./${deployParams.Environment}/SQL_Deployment/host_vars"
			
			//Run ansible playbook to deploy artefacts into environment
  		    ansiColor('xterm') {
				
				// Need to delete this as part of syncing up with main BW pipeline.
				//ansiblePlaybook(playbook: "./${deployParams.Environment}/SQL_Deployment/site.yml", inventory: "./${deployParams.Environment}/SQL_Deployment/hosts", colorized: true, extras:'-v', extraVars: [host: "${deployParams.Environment}", repo_group_id: "${deployParams.repo_group_id}", repo_artifact_id:"${deployParams.engName}", repo_user:"${deployParams.repo_user}", repo_pw:"${deployParams.repo_pw}", repo_repo_id:"${deployParams.repo_repo_id}", version:"${deployParams.build_version}", repo_url:"${deployParams.repo_url}", Release:"${deployParams.Release}", Environment:"${deployParams.Environment}", CRQ_Num:"${deployParams.CRQ_Num}", engName:"${deployParams.engName}"])
				
				ansiblePlaybook(playbook: "./${deployParams.Environment}/SQL_Deployment/deploy_Engies_SQL.yml", colorized: true, extras:'-v', extraVars: [host: "${deployParams.Environment}", repo_group_id: "${deployParams.nexus_group_id}", repo_artifact_ids:"${deployParams.repo_artifact_ids}", repo_user:"${deployParams.nexus_user}", repo_pw:"${deployParams.nexus_passwd}", repo_repo_id:"${deployParams.nexus_repo_id}", repo_url:"${deployParams.nexus_url}", Release:"${deployParams.Release}", Environment:"${deployParams.Environment}", datetime: "${deployParams.datetime}", backupTables: "${deployParams.backupTables}",  CRQ_Num:"${deployParams.crq_no}"])
	
		    }
    }
}

// Get Configuration files required for Engine Restart

def get_conf_files_restart(deployParams) {
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}_Conf"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_BW_Application_Configuration.git']]]
    // make a directory with conf
	sh "mkdir -p ./${deployParams.Host}_Conf/conf"
    echo "${deployParams.engines}"
	echo "${deployParams.folderName}"
    def engine_list = deployParams.engines.split(';')
		for (txt in engine_list) {
			echo "${txt}"
			def eng_conf = txt
			echo eng_conf
			// check if engine input has folder name associated 
			if(eng_conf.contains('/')){
				def engine_params = eng_conf.split('/')
				def folderName = engine_params[0]
				def engine_name = engine_params[1]
				// copy appconf file from master repository
				sh "cp ./${deployParams.Host}_Conf/Restart_Configurations/Restart_Template.appconf ./${deployParams.Host}_Conf/conf/${engine_name}.appconf"
			
				// update values of appconf with Folder name provided during deployment
				sh  "sed -i '/FolderName=/ s/=.*/=${folderName}/'  ./${deployParams.Host}_Conf/conf/${engine_name}.appconf"

			}
			else{
				// copy appconf file from master repository
				sh "cp ./${deployParams.Host}_Conf/Restart_Configurations/Restart_Template.appconf ./${deployParams.Host}_Conf/conf/${eng_conf}.appconf"
			}	
	   }
}



def deploy_restart_bw(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
			
			//Checkout Environment specic configurations (tokens, properties files)
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "RESTART_ENV"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_TestEnv_Configurations.git']]]
			
			
			// create directory with name conf to copy config files
			sh "mkdir ./${deployParams.Host}/BW_Deployment/conf"
			
			// Copy deployment conf files  to conf directory in deployment script 
			
			sh "cp -r ./${deployParams.Host}_Conf/conf/* ./${deployParams.Host}/BW_Deployment/conf"
       
           	sh "mkdir ./${deployParams.Host}/BW_Deployment/host_vars/${deployParams.Host}"

			// Copy Environment specififc files to Ansible Host Vars 
			sh "cp -r ./RESTART_ENV/BW_Configuration/${deployParams.Host}/* ./${deployParams.Host}/BW_Deployment/host_vars/${deployParams.Host}"
			
			
		
			//Run ansible playbook to deploy artefacts into environment
			 ansiColor('xterm') {
    	     ansiblePlaybook(playbook: "./${deployParams.Host}/BW_Deployment/restartBW.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Host}", engines: "${deployParams.engines}", datetime: "${deployParams.datetime}", crq_num: "${deployParams.crq_no}", bwDeployment: "${deployParams.bwDeployment}", bwRestart: "${deployParams.bwRestart}"])
	
		    }
    }
}


// This function is to print the build summary in email Body
def print_buildSummary() {
		
		def buildSummary = readFile "./../TIL_BUILD/DEV_${RELEASE}_${DEV_TAG}"
		buildSummary = buildSummary.replaceAll("\r\n|\n\r|\n|\r","<br/>")
		return buildSummary
}

def print_diff_url() {
		def urlString = earDiff_url.join("<br>")
		return urlString
}

def print_prod_diff_url() {
		def prod_urlString = prod_earDiff_url.join("<br>")
		return prod_urlString
}

def get_build_num(){
	//This method returns the build number based on the previous build number for corresponding release.
	//String jobName = System.getenv('JOB_NAME')
	println (job_name)
	def seq_no
	def job = jenkins.model.Jenkins.instance.getItemByFullName(job_name)
	for (def build : job.builds){
		if (build.displayName.contains("${params.RELEASE}")){
			//println build.properties.environment.BUILD_NUMBER.toString()
			if (build.displayName.contains('_')){
				seq_no = build.displayName.split('_')[1]
				if(seq_no.isInteger()){
				    seq_no = seq_no.toInteger() + 1
					//seq_no += 1
					return seq_no
					break;
				}
			}
		}	
	}
	if (seq_no == null || !seq_no.isInteger()){
		seq_no = 1
		return seq_no
	}
}

def getChangeString() {
	MAX_MSG_LEN = 100
	def changeString = ""

	echo "Gathering SCM changes"
	def changeLogSets = currentBuild.changeSets
	for (int i = 0; i < changeLogSets.size(); i++) {
		def entries = changeLogSets[i].items
		for (int j = 0; j < entries.length; j++) {
			def entry = entries[j]
			truncated_msg = entry.msg.take(MAX_MSG_LEN)
			changeString += "<br><br>${entry.commitId}      by    ${entry.author}    on    ${new Date(entry.timestamp)}:" + "<br>" + "${truncated_msg}" + "<br><br>" 
			def files = new ArrayList(entry.affectedFiles)
			for (int k = 0; k < files.size(); k++) {
				def file = files[k]
				if (file.path.contains("${params.RELEASE}/Common_SQL_Changes")  || file.path.contains("SQL_Deployment/")) {
					changeString += "${file.editType.name} : ${file.path}" + "<br>"
				}
			}
		}
	}
	if (!changeString) {
		changeString = " - No new changes"
	}
	return changeString
}



def get_body_build_summary(){
	
	def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
		.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		</style>
		<table class="tg" style="undefined;table-layout: fixed; width: 1200px">
		<colgroup>
		<col style="width: 100px">
		<col style="width: 500px">
		<col style="width: 100px">
		<col style="width: 500px">
		</colgroup>
		  <tr>
			<th class="tg-amwm" colspan="4">SQL BUILD SUMMARY</th>
		  </tr>
		  <tr>
			<td class="tg-1wig">Submitted By</td>
			<td class="tg-0lax">${currentBuild.getRawBuild().getCauses()[0].getUserId()}</td>
			<td class="tg-1wig">Date</td>
			<td class="tg-0lax">${date_now}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">RELEASE NUMBER</td>
			<td class="tg-0lax">${params.RELEASE}</td>
			<td class="tg-1wig">CRQ NUMBER</td>
			<td class="tg-0lax">${params.CRQ_NUMBER}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">BUILD_VERSION</td>
			<td class="tg-0lax">${SQL_VERSION}</td>
			<td class="tg-1wig"></td>
			<td class="tg-0lax"></td>
		  </tr>
		  <tr>
			<td class="tg-1wig">BUILD_URL</td>
			<td class="tg-0lax" colspan="3">${BUILD_URL}</td>
		  </tr>
		  <tr>
		</table>
		<br><br><br>
		<table class="tg" style="undefined;table-layout: fixed; width: 1200px">
		<colgroup>
		<col style="width: 100px">
		<col style="width: 500px">
		<col style="width: 100px">
		<col style="width: 500px">
		</colgroup>
		  <tr>
			<td class="tg-1wig">SQL BUILD SUMMARY</td>
			<td class="tg-0lax" colspan="3">${CHANGE_STRING}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">LOG_URL</td>
			<td class="tg-0lax" colspan="3">${BUILD_URL}/console</td>
		  </tr> 
		</table>
	"""
	return body_build_summary
} 

DEV_TAG = " "
SQL_VERSION = " "
CHANGE_STRING = " "
date_now = " "
emailBody = " "
bw_mailRecipients=""
pipeline {
	agent any
	environment {
		NEXUS_URL="195.233.197.150:8081"
		REPO_URL = "http://195.233.197.150:8081/repository"
		LT_REPO="LINKTEST_REPO"
		SIT_REPO="SIT_REPO"
		PROD_REPO="PROD_REPO"
		SQL_GROUPID="TIL_SQL"
		NEXUS_USERNAME="admin"
		NEXUS_PASSWORD="admin123"
		NEXUS_VERSION="nexus3"
		ENGINE_NAME="Common_SQL_Changes"
		//[CICD-739] Insert Deployment metadata to release notes DB.
		dbURL = 'jdbc:oracle:thin:@195.233.199.13:33000:TIBTST1'
		dbUserName = 'CICD_OWN_DB01'
		dbPassword = 'TIL_CICD_DB'
		dbDriver = 'oracle.jdbc.driver.OracleDriver'		
	}
	stages {
		stage('Preparation') {
			steps {
                script {
						cleanWs disableDeferredWipeout: true, deleteDirs: true
						String regex = /(^CCS\d+\.\d+_[a-zA-Z0-9]+$)|(^CCS\d+\.\d+$)/
						if(RELEASE == ""){
							currentBuild.result = 'ABORTED'
							error('RELEASE is mandatory for Gateway Pipeline')
						} else if(RELEASE.indexOf(' ') != -1){
							currentBuild.result = 'ABORTED'
							error('RELEASE parameter should not contain spaces in between')
						} else if (!(RELEASE ==~ regex)){
							currentBuild.result = 'ABORTED'
							error('RELEASE parameter is not in standard format. Please input either in CCS20.12 or CCS20.12_x format')
						}
						if (CRQ_NUMBER.indexOf(' ') != -1){
						    currentBuild.result = 'ABORTED'
                            error('Parameter validation failed.CRQ_NUMBER should not contain space in between.')
						}						
						DEV_TAG = "${params.RELEASE}_${get_build_num()}"
						currentBuild.displayName = "${DEV_TAG}"
						
						//Creating date time
						date_now = new Date().format("YYYYMMddHHmmss")
						
						//checkout gateway build code to show commit message info
						//checkout([$class: 'GitSCM', branches: [[name: "${params.RELEASE}"]], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: './TIL_SQL']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_SQL.git']]])
						
						//[CICD-739]: Fix to send deployment information to release notes DB.
						checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'JENKINS_FILE']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_DevOps_Framework.git']]])						

						
						//CHANGE_STRING = getChangeString()

						// checking out framework automation scripts
						checkout([$class: 'GitSCM', doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: './TIL_AUTOMATION']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]])
						
						//[CICD-739]: Load all functions files from GIT. point to exact source file
						load_groovy_files()	
							
					buildRequestorMail = emailFunctions.getUserEmail(emailFunctions.getBuildUserID())
					DevopsUsers = emailFunctions.get_approvers_list('DevOpsUsers')
                    			bw_mailRecipients = emailFunctions.get_approvers_email_list(DevopsUsers); 
					DEVLeads = emailFunctions.get_approvers_list('DEVLeads')
					bw_mailRecipients += "," + emailFunctions.get_approvers_email_list(DEVLeads) + "," + buildRequestorMail;
                }

			}
		}
		stage('SQL Build') {
			steps {
				script {
				// Build stage for SQL Build.
					if (CRQ_NUMBER == ""){
						currentBuild.result = 'ABORTED'
						error('CRQ NUMBER should be specified ')
					}
					sh label: '', script: 'chmod 755 ./TIL_AUTOMATION/SQL_Build/set_sqlVersion.sh'
					def sql_version = sh(script:"./TIL_AUTOMATION/SQL_Build/set_sqlVersion.sh ${params.RELEASE} ${env.NEXUS_URL} ${env.LT_REPO} ${env.SQL_GROUPID} ${env.NEXUS_USERNAME} ${env.NEXUS_PASSWORD} ${env.ENGINE_NAME}", returnStdout: true).trim()
					echo "PIPELINE OUTPUT: SQL Version: ${sql_version}"
					SQL_VERSION = "${sql_version}"
					
					checkout([$class: 'GitSCM', doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "./TIL_SQL"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_SQL.git']]])
					
					CHANGE_STRING = getChangeString()

					checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "TIL_CONFIG"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_TestEnv_Configurations.git']]]
					
					// Copy sql files to workspace.
					sh "cp ./TIL_SQL/${params.RELEASE}/${ENGINE_NAME}/*.sql ./"
					
				    //do dos2unix for all the sql files
					//sh "dos2unix ./TIL_SQL/${params.RELEASE}/${ENGINE_NAME}/*.sql"
					
					// Remove TIL_SQL folder which is not required as we have already copied required files..
					sh "rm -rf ./TIL_SQL"					
					
					// Copy SQL Automation scripts to Workspace
					sh "cp ./TIL_AUTOMATION/SQL_Build/* ${WORKSPACE}/"
					
					// Change permissions for validate sql script.
					sh "chmod 755 ./validate_sql.sh"

					// Run SQL Validation script to validate SQL files for any special symbols.
					sh label: '', script: "./validate_sql.sh ${params.Environment} || { echo 'ERROR: SQL File validation Failed. Please check logs' ; exit 1; }"
					
					// Validate DB names with SQL Files.
					// sh "cp ./TIL_AUTOMATION/SQL_Deployment/script/validate_sql_db.sh ./"
					// sh "chmod 755 ./validate_sql_db.sh"
					// sh "./validate_sql_db.sh"
					
					// Build tar file for all sql rollforward and rollback files.
					sh "tar -zcvf ${env.ENGINE_NAME}_${sql_version}.tar.gz ./*.sql"
					
					// Create pom file to push to nexus.
					sh "touch ${env.ENGINE_NAME}_${sql_version}.pom"
					
					// Generate Readme file
					sh "echo \"${params.CRQ_NUMBER}\"> ${env.ENGINE_NAME}_${sql_version}_Readme.txt"
					sh "echo \"${params.Engines_List}\">> ${env.ENGINE_NAME}_${sql_version}_Readme.txt"
			
					// Push Build and pom file to nexus repository
					nexusArtifactUploader artifacts: [[artifactId: "${env.ENGINE_NAME}", classifier: '', file: "${ENGINE_NAME}_${sql_version}.tar.gz", type: 'tar.gz']], credentialsId: '74edde97-94e0-403c-93f6-cad6c46c45f8', groupId: "${env.SQL_GROUPID}", nexusUrl: "${env.NEXUS_URL}", nexusVersion: "${env.NEXUS_VERSION}", protocol: 'http', repository: "${env.LT_REPO}", version: "${sql_version}"
					
					nexusArtifactUploader artifacts: [[artifactId: "${env.ENGINE_NAME}", classifier: '', file: "${ENGINE_NAME}_${sql_version}.pom", type: 'pom']], credentialsId: '74edde97-94e0-403c-93f6-cad6c46c45f8', groupId: "${env.SQL_GROUPID}", nexusUrl: "${env.NEXUS_URL}", nexusVersion: "${env.NEXUS_VERSION}", protocol: 'http', repository: "${env.LT_REPO}", version: "${sql_version}"
					
					nexusArtifactUploader artifacts: [[artifactId: "${env.ENGINE_NAME}", classifier: '', file: "${ENGINE_NAME}_${sql_version}_Readme.txt", type: 'txt']], credentialsId: '74edde97-94e0-403c-93f6-cad6c46c45f8', groupId: "${env.SQL_GROUPID}", nexusUrl: "${env.NEXUS_URL}", nexusVersion: "${env.NEXUS_VERSION}", protocol: 'http', repository: "${env.LT_REPO}", version: "${sql_version}"
					
					echo "SQL Buid completed"
				}
 				sleep 5
/* 				script{
							// This is to compose an email to send the Build Summary.
							emailext mimeType: 'text/html',
								subject: "[Jenkins]: ${currentBuild.fullDisplayName}  - " + "Build CHANGE LOG SUMMARY",
								from:"TIL_SQL_DEPLOYMENTS@vodafone.com",
								to: "${dev_mailRecipients}",
								body: "${get_body_build_summary()}" 
				} */
			}
		}
		stage('SQL Deployment') {
			steps {
				script {
					
					// Call deploy function by providing LinkTest Details and engines
					sql_deploy Environment:"${params.Environment}", Release: "${params.RELEASE}", nexus_group_id: "${env.SQL_GROUPID}", nexus_url: "${env.REPO_URL}", nexus_repo_id: "${env.LT_REPO}", nexus_user: "${env.NEXUS_USERNAME}", build_version: "${SQL_VERSION}", nexus_passwd: "${env.NEXUS_PASSWORD}", crq_no: "${params.CRQ_NUMBER}", repo_artifact_ids: "${env.ENGINE_NAME}:${SQL_VERSION}", datetime: "${date_now}", backupTables: "${params.BACKUP_TABLES}" 
					
					echo "SQL Deployment completed"
				}
				sleep 5
/* 				script{
							// This is to compose an email to send the deployment Summary.
							emailext mimeType: 'text/html',
								subject: "[Jenkins]: ${currentBuild.fullDisplayName}  - " + "Build CHANGE LOG SUMMARY",
								from:"TIL_SQL_DEPLOYMENTS@vodafone.com",
								to: "${dev_mailRecipients}",
								body: "${get_body_build_summary()}" 
				}
				sleep 5 */
			}
		}
		stage('Engine Restart') {
			steps {
				script{
					// Get BW engines with SQL changes listed in CRQ Number. These need to be restarted once after SQL deployment is successful.
					//sh label: '', script: 'ansible-playbook ./TIL_AUTOMATION/SQL_Deployment/get_BW_EngineList.yml -i ./TIL_AUTOMATION/SQL_Deployment/hosts -f 5 -e host=${params.Environment} -e CRQ_Num="${params.CRQ_NUMBER}" -e WORKSPACE="${WORKSPACE}" -v'
                    get_conf_files_restart engines:"${params.Engines_List}", Host:"${params.Environment}"
					           					
					echo "Engines to restart are: ${params.Engines_List}"
					deploy_restart_bw Host:"${params.Environment}", crq_no:"${params.CRQ_NUMBER}", engines:"${params.Engines_List}", datetime:"${date_now}"
				}
			}
		}
		stage('Signoff LinkTest') {
			steps {
				script{
					
					//[CICD-572] Fix: Update Jenkins SQLDash board with the artefact version for successful deployment.
					echo "Updating SQL Jenkins dashboard with engine name as: Common_SQL_Changes and version as: ${SQL_VERSION}"  
					build job: '/TIL_PIPELINES/Common_Jobs/Dashboard_Publish', parameters: [string(name: 'Environment', value: "${params.Environment}_SQL"), string(name: 'Component', value: "Common_SQL_Changes"), string(name: 'ArtefactVersion', value: "${SQL_VERSION}"), string(name: 'Pipeline', value: 'TIL_PIPELINES/LinkTest/TIL_SQL_Pipeline'), string(name: 'Description', value: '')]
					
					echo "Signoff ${params.Environment}"

					// Send Approval Email and wait for Signoff   
					
					LinkTestBWApprovers = get_approvers_list('LinkTestBWApprovers')
					echo "LinkTestBWApprovers are: ${LinkTestBWApprovers}"
					//LinkTestApprovers = "tssiukintegrationdevleads@vodafone.com, ${params.BUILD_REQUESTER}"
					
					if (emailBody == " ") {
						emailBody = "${get_body_build_summary()}"
					}										
					emailext mimeType: 'text/html',
					 subject: "[Jenkins]:${currentBuild.fullDisplayName}:Approval email for promote Artefact to SIT",
					 from:"TIL_SQL_DEPLOYMENTS@vodafone.com",
					 to: "${bw_mailRecipients}",
					 body: 	"${emailBody}" + "<br>" + 
							"<br><br><p><b><font size='5' color='Black'>Signoff LinkTest Changes for deploying into SIT: <a href='${BUILD_URL}input'>${currentBuild.displayName}</a></font></b></p>"
					
					//def testOptions = 'YES\nNO'
					def userInput = input(
					   id: 'userInput', 
					   message: 'Do you want to promote Artefact to SIT?',
					   //parameters: [
						//	[$class: 'ChoiceParameterDefinition', choices: testOptions, description: 'Select Promote Artefact', name: 'promoteArtefact']
					   //],
					   submitterParameter: 'submitter',
					   submitter: "${LinkTestBWApprovers}"
					)

					echo "Promoting SQL Artefact version: ${SQL_VERSION}"
					
					// Call Promote artefact step to promote by providing source and target repo details along with engine & Version
					artifactPromotion artifactId: "${env.ENGINE_NAME}", classifier: '', debug: true, extension: 'tar.gz', groupId: "${env.SQL_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWORD}", releaseRepository: "${env.REPO_URL}/${env.SIT_REPO}", releaseUser: "${env.NEXUS_USERNAME}", stagingPW: "${env.NEXUS_PASSWORD}", stagingRepository: "${env.REPO_URL}/${env.LT_REPO}", stagingUser: "${env.NEXUS_USERNAME}", version: "${SQL_VERSION}"
					
					artifactPromotion artifactId: "${env.ENGINE_NAME}", classifier: '', debug: true, extension: 'txt', groupId: "${env.SQL_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWORD}", releaseRepository: "${env.REPO_URL}/${env.SIT_REPO}", releaseUser: "${env.NEXUS_USERNAME}", stagingPW: "${env.NEXUS_PASSWORD}", stagingRepository: "${env.REPO_URL}/${env.LT_REPO}", stagingUser: "${env.NEXUS_USERNAME}", version: "${SQL_VERSION}"
					
					// Insert data into CICD_RELEASE_SUMMARY Table.
					
					def user = currentBuild.getRawBuild().getCauses()[0].getUserId()
					println("DEBUG:" + user)
					
					def release_ins_query = """Insert into CICD_RELEASE_SUMMARY (RELEASE_NO,PROJECT_NAME,JIRA_NO,CHANGE_DESCRIPTION,ENGINE_NAME,OPERATION,EAR_VERSION,EMS_VERSION,SQL_VERSION,COMPONENT_TYPE,STATUS,MASTER_GV,PROCESS_GV,ENGINE_TEMPLATE,APPEND_PREPEND,KNOWN_ERROR_INCLUSION,POST_MANUAL_CHANGES,PARTNER_DATA,GATEWAY_TOKEN,SPECIAL_INSTRUCTIONS,LINKTEST_RESULTS,CREATED_ON,GATEWAY_VERSION,GATEWAY_TYPE,CREATED_BY,FILE_CHANGES,APPROVAL,RESTART_ENGINES) values ('${params.RELEASE}','','${params.CRQ_NUMBER}','${params.Description}','Common_SQL_Changes','','','','${SQL_VERSION}','ISTIL','Active','','','','','','','','','','PASSED',sysdate,'','','${user}','','${userInput}','${params.Engines_List}')"""
					
					println("DEBUG: release notes Insert query is: " + release_ins_query)
					DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: release_ins_query 						
					
				}					
			}
		}
		
	}

}
