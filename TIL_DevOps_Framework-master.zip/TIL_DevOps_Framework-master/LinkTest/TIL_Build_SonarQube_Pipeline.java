// Global Parameters to use in the stages.
date_now = new Date().format( 'dd-MM-yyyy' )

//[CICD-507] Insert Deployment metadata to TIL_BUILD_HISTORY DB.
import groovy.json.JsonOutput
import groovy.sql.*
import java.sql.Driver

// Mail recipents for the individual stages.
def bw_mailRecipients = "tssiukintegrationdevleads@vodafone.com, integrationad_buildteam@vodafone.com, ${params.BUILD_REQUESTER}, pratibha.bhimraoalande@vodafone.com, devops-vfuk-integration@vodafone.com"




// SonarQube Execution and Properties file Modification.
def Sonar_exe() {

	sh '''			
		mkdir ${WORKSPACE}/TIL_SOURCE_SonarQube
		cp -r ${WORKSPACE}/TIL_SOURCE/* ${WORKSPACE}/TIL_SOURCE_SonarQube/	
		
		if [ -d "${WORKSPACE}/TIL_SCRUM" ]; then
			cd ./TIL_SCRUM
			rm -rf `find . -name CVS`
			
			# Copy all the modified / added files to Main module from Scrum Module.
			if [ ! -z "${MODIFIED_FILES}" ];then 
				echo "${MODIFIED_FILES}" | while IFS= read -r line
				do
					[[ -f "${line}" ]] && cp --parents --remove-destination "${line}" ${WORKSPACE}/TIL_SOURCE_SonarQube/ || { echo "ERROR: ${line} does not exist in Feature Branch. Please check."; exit 1; }
				done
			fi
			
			# Change the direcory to TIL_SOURCE_SonarQube before deleting files.
			cd "${WORKSPACE}/TIL_SOURCE_SonarQube"

			# Remove all the deleted files from Main module.
			if [ ! -z "${DELETED_FILES}" ];then 
				echo "${DELETED_FILES}" | while IFS= read -r line
				do
					[[ -f "${line}" ]] && rm  "${WORKSPACE}/TIL_SOURCE_SonarQube/${line}" || { echo "ERROR: ${line} does not exist in TIL MAIN Module. Please check."; exit 1; }
				done
			fi
		fi

		cd ${WORKSPACE}
	'''
	
	sh "cp -r ./TIL_Automation/SonarQube/sonar-project.properties ./TIL_SOURCE_SonarQube"
	sh "mkdir ./Reports"
	sh "sed -i 's#sonar.report.path=.*#sonar.report.path=${WORKSPACE}/Reports#' ./TIL_SOURCE_SonarQube/sonar-project.properties"
	sh "sed -i 's#sonar.projectKey=.*#sonar.projectKey=${TIL_TYPE}_${TIL_MODULENAME}#' ./TIL_SOURCE_SonarQube/sonar-project.properties"
	sh "sed -i 's#sonar.projectName=.*#sonar.projectName=${TIL_TYPE}_${TIL_MODULENAME}#' ./TIL_SOURCE_SonarQube/sonar-project.properties"
	
	if (FEATURE_BRANCH.length() !=0) {
		sh "sed -i 's#sonar.branch.target.name=.*#sonar.branch.target.name= ${FEATURE_BRANCH}#' ./TIL_SOURCE_SonarQube/sonar-project.properties"
	}else {
		sh "sed -i 's#sonar.branch.target.name=.*#sonar.branch.target.name= ${RELEASE}#' ./TIL_SOURCE_SonarQube/sonar-project.properties"
	}
	
	if (Rules_Excluded.length() !=0) {
		sh "sed -i 's#sonar.exclusions.rules=.*#sonar.exclusions.rules=${Rules_Excluded}#' ./TIL_SOURCE_SonarQube/sonar-project.properties"
	}
	
	if (Exclude_Directories_or_Files.length() !=0) {
		sh "sed -i 's#sonar.exclusions=.*#sonar.exclusions=**/Interface/*,**/Interface/**/*,**/defaultVars/defaultVars.substvar,${Exclude_Directories_or_Files}#' ./TIL_SOURCE_SonarQube/sonar-project.properties"
	}
	
	
	sh "sed -i 's#sonar.bw5.overriderules.file =.*#sonar.bw5.overriderules.file = ${WORKSPACE}/TIL_Automation/SonarQube/OverrideRules.xml#' ${SonarQube_Home}/conf/sonar.properties"
	
	sh "export SONAR_HOME=${SonarQube_Home} && ${SonarScanner_Home}/bin/sonar-scanner -D'sonar.log.console=true' -D'sonar.projectBaseDir=./TIL_SOURCE_SonarQube' > ./Sonar_Exe.out"
	sh "cp -r ./Reports/${TIL_TYPE}_${TIL_MODULENAME}*.xlsx ${WORKSPACE}/${TIL_TYPE}_${TIL_MODULENAME}.xlsx"
	sh "cat ./Sonar_Exe.out"

}



// This function is to print the build summary in email Body
def print_buildSummary() {
		
		def buildSummary = readFile "${BUILD_HISTORY_PATH}/${DEV_TAG}/DEV_${DEV_TAG}"
		buildSummary = buildSummary.replaceAll("\r\n|\n\r|\n|\r","<br/>")
		return buildSummary
}

def print_diff_url() {
		def urlString = earDiff_url.join("<br>")
		return urlString
}

def print_prod_diff_url() {
		def prod_urlString = prod_earDiff_url.join("<br>")
		return prod_urlString
}
def get_build_num(){
	//This method returns the build number based on the previous build number for corresponding release.
	//String jobName = System.getenv('JOB_NAME')
	println (job_name)
	def seq_no
	def max_search_builds=500
	def count=0	
	def job = jenkins.model.Jenkins.instance.getItemByFullName(job_name)
	for (def build : job.builds){
		count = count.toInteger() + 1
		if(count.toInteger() >= max_search_builds.toInteger()) {
			break;
		}		
		if (build.displayName.contains("${params.RELEASE}".split('CCS')[1].trim())){
			//println build.properties.environment.BUILD_NUMBER.toString()
			if (build.displayName.contains('_')){
				if(build.displayName.split('_')[1].isInteger()) { 
					seq_no = build.displayName.split('_')[1]
				} else {
					seq_no = build.displayName.split('_')[2]
				}
				if(seq_no.isInteger()){
				    seq_no = seq_no.toInteger() + 1
					//seq_no += 1
					return seq_no
					break;
				}
			}
		}	
	}
	if (seq_no == null || !seq_no.isInteger()){
		seq_no = 1
		return seq_no
	}
}
def get_body_build_summary(){
	
	def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
		.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		</style>
		<table class="tg" style="undefined;table-layout: fixed; width: 1200px">
		<colgroup>
		<col style="width: 100px">
		<col style="width: 500px">
		<col style="width: 100px">
		<col style="width: 500px">
		</colgroup>
		  <tr>
			<th class="tg-amwm" colspan="4">TIL BUILD SUMMARY</th>
		  </tr>
		  <tr>
			<td class="tg-1wig">Submitted By</td>
			<td class="tg-0lax">${currentBuild.getRawBuild().getCauses()[0].getUserId()}</td>
			<td class="tg-1wig">Date</td>
			<td class="tg-0lax">${date_now}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">RELEASE NUMBER</td>
			<td class="tg-0lax">${env.RELEASE}</td>
			<td class="tg-1wig">IRIS NUMBER</td>
			<td class="tg-0lax">${env.JIRA_NUMBER}</td>
		  </tr>
		  <tr>	
			<td class="tg-1wig">SonarQube_Result</td>
			<td class="tg-0lax" colspan="3">${Status}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">BUILD_URL</td>
			<td class="tg-0lax" colspan="3">${BUILD_URL}</td>
		  </tr>
		  <tr>
		</table>
		<br><br><br>
		<table class="tg" style="undefined;table-layout: fixed; width: 1200px">
		<colgroup>
		<col style="width: 100px">
		<col style="width: 500px">
		<col style="width: 100px">
		<col style="width: 500px">
		</colgroup>
		  <tr>
			<td class="tg-1wig">BW BUILD SUMMARY</td>
			<td class="tg-0lax" colspan="3">${print_buildSummary()}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">LOG_URL</td>
			<td class="tg-0lax" colspan="3">${BUILD_URL}/console</td>
		  </tr> 
		  <tr>
			<td class="tg-1wig">EAR_DIFF_URL's</td>
			<td class="tg-0lax" colspan="3">${print_diff_url()}</td>
		  </tr> 
		  <tr>
			<td class="tg-1wig">PROD_EAR_DIFF_URL's</td>
			<td class="tg-0lax" colspan="3">${print_prod_diff_url()}</td>
		  </tr>		  
		</table>
	"""
	return body_build_summary
}
DEV_TAG = " "
FINAL_VERSION = " "
CHANGE_STRING= " "
String[] COMMON_ENGINES_LIST = []
REPORT_PATH="/opt/tibco/DevOps_Reporting/Report/DevOps_report.txt"
//[CICD-507] Insert Deployment metadata to TIL_BUILD_HISTORY DB.
user = ""
til_build_status = ""

pipeline {
	agent any
	environment {
		BUILD_HISTORY_PATH = "${WORKSPACE}/../BUILD_HISTORY"
		ENG_VERSIONS = " "
		NEXUS_URL="195.233.197.150:8081"
		LT_REPO="LINKTEST_REPO"
		SIT_REPO="SIT_REPO"
		PROD_REPO="PROD_REPO"
		TIL_GROUPID="TIL_BW"
		EMS_GROUPID="TIL_EMS_SQL"
		EMS_ARTIFACTID="EMS"		
		NEXUS_VERSION="nexus3"
		NEXUS_USERNAME="admin"
		NEXUS_PASSWORD="admin123"
		TIL_TYPE="TIL"
		
		// Sonarqube
		Status = "Failed"
		SonarQube_Home = "/opt/tibco/devops/sonarqube/sonarqube-8.6.1.40680"
		SonarScanner_Home = "/opt/tibco/devops/sonarqube/sonar-scanner-4.5.0.2216-linux"
		        
        //[CICD-507] Insert Deployment metadata to TIL_BUILD_HISTORY DB.
        dbURL = 'jdbc:oracle:thin:@195.233.199.13:33000:TIBTST1'
		dbUserName = 'CICD_OWN_DB01'
		dbPassword = 'TIL_CICD_DB'
		dbDriver = 'oracle.jdbc.driver.OracleDriver'
	}
	stages {
		stage('Preparation') {
			steps {
                script {
						
						String regex = /(^CCS\d+\.\d+_[a-zA-Z0-9]+$)|(^CCS\d+\.\d+$)/
						if(RELEASE == ""){
							currentBuild.result = 'ABORTED'
							error('RELEASE is mandatory for Gateway Pipeline')
						} else if(RELEASE.indexOf(' ') != -1){
							currentBuild.result = 'ABORTED'
							error('RELEASE parameter should not contain spaces in between')
						} else if (!(RELEASE ==~ regex)){
							currentBuild.result = 'ABORTED'
							error('RELEASE parameter is not in standard format. Please input either in CCS20.12 or CCS20.12_x format')
						}
						if (JIRA_NUMBER.indexOf(' ') != -1){
						    currentBuild.result = 'ABORTED'
                            error('Parameter validation failed.JIRA_NUMBER should not contain space in between.')
						}						
						DEV_TAG = RELEASE.split('CCS')[1] + '_' + "${get_build_num()}"
						currentBuild.displayName = "${DEV_TAG}"
						
                        cleanWs disableDeferredWipeout: true, deleteDirs: true
						// checking out framework automation scripts
						checkout([$class: 'GitSCM', doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: './TIL_AUTOMATION']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]])
                        
                        //[CICD-507] Insert Deployment metadata to TIL_BUILD_HISTORY DB.
                        // This function is to checkout all the required GIT repositories.
						user = currentBuild.rawBuild.causes[0].userId
                        checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'JENKINS_FILE']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_DevOps_Framework.git']]])
    
                        DB_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/dbFunctions.groovy"  
						
						// checking out Feature Branch for project only if some value is present.
						if (FEATURE_BRANCH != "") {
							checkout([$class: 'GitSCM', branches: [[name: "${params.FEATURE_BRANCH}"]], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: './TIL_SCRUM']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: "https://github.vodafone.com/VFUK-INTEGRATION/${env.TIL_TYPE}_${TIL_MODULENAME}.git"]]])	
						}	

						//CHANGE_STRING = sh(script:"git --git-dir=./TIL_SCRUM/.git/ log -1 --name-status --pretty=format:\"author: %cn; date: %ci; subject:%s; %h\"", returnStdout: true).trim()
						//echo "Change String is:${CHANGE_STRING}"
						
                }

			}
		}
		stage('SonarQube Execution') {
			steps {				
				script{
											
					Sonar_exe()
					 
					//echo "Sonar Execution Completed"
					if(fileExists("${WORKSPACE}/Sonar_Exe.out")) {
						//def statusFile = new File("${WORKSPACE}/Sonar_Exe.out")
						//def statusContent = statusFile.readLines()
						def Content = sh "grep 'EXECUTION' Sonar_Exe.out"
												
							if(Content.equals("INFO: EXECUTION FAILURE")) {
							
								Status = "Failed"
							}else {
								Status = "Success"
							}
												
				    }               
				}						
			}
		}
		
   		stage('BW_Build') {
			steps {
				//build job: 'TIL/BW/BW_Build'
				script{
					if (TIL_ARCHIVEFILES == ""){
						   currentBuild.result = 'ABORTED'
						   error('TIL_ARCHIVEFILES need to be specified for the build')
						}
					if (TIL_MODULENAME == ""){
						   currentBuild.result = 'ABORTED'
						   error('TIL_MODULENAME should be specified for the build')
						}
 					if (! BUILD_REQUESTER.matches('^[a-zA-Z0-9._%+-]+@vodafone.com$')){
						   currentBuild.result = 'ABORTED'
						   error('Please enter Valid email ID for Build Requester')
						}
					if (JIRA_DESCRIPTION == ""){
						   currentBuild.result = 'ABORTED'
						   error('JIRA_DESCRIPTION should be specified ')
						}						
					def comEngines = sh(script:"cat ./TIL_AUTOMATION/TIL_Build/Common_Engines_List | grep ${TIL_ARCHIVEFILES} || exit 0", returnStdout: true).trim()
					echo "DEBUG: comEngines value is: ${comEngines}"
					if (comEngines != null && !comEngines.isEmpty()) {
						// Get the related engines list if it matches .
						COMMON_ENGINES_LIST = "${comEngines}".split("\n");
					} else {
						//
						COMMON_ENGINES_LIST = "${TIL_ARCHIVEFILES}".split(";");
					}
					
					// exceptions in the common engines list are hard coded as below , since there is no specific format to get.
					
					if(TIL_ARCHIVEFILES == "ServiceExposure-Scheduled" || TIL_ARCHIVEFILES == "ServiceExposure-NonScheduled" ) {
						COMMON_ENGINES_LIST = "ServiceExposure-NonScheduled, ServiceExposure-Scheduled".split(", "); 
					}
					
					if(TIL_ARCHIVEFILES == "ProvisioningAndFulfilment-MNP-FT-MVNO-TALKMOBILE" || TIL_ARCHIVEFILES == "ProvisioningAndFulfilment-MNP-FT-Postpay-VF-CONSUMER-1" || TIL_ARCHIVEFILES == "ProvisioningAndFulfilment-MNP-FT-Postpay-VF-Corp" ) {
						COMMON_ENGINES_LIST = "ProvisioningAndFulfilment-MNP-FT-MVNO-TALKMOBILE, ProvisioningAndFulfilment-MNP-FT-Postpay-VF-CONSUMER-1, ProvisioningAndFulfilment-MNP-FT-Postpay-VF-Corp".split(", ");
					}
					
					echo "common engines list: ${COMMON_ENGINES_LIST}"
					COMMON_ENGINES_STRING = COMMON_ENGINES_LIST.join(", ")
					
					// calling BW_Build job - output will be copying ear, diff files and changelog  files to common location 
					 build job: 'TIL_PIPELINES/LinkTest/BW/BW_BUILD', parameters: [string(name: 'TIL_TYPE', value: "${env.TIL_TYPE}"), string(name: 'PROJECTNAME', value: "${params.PROJECTNAME}"), string(name: 'TIL_ARCHIVEFILE', value: "${params.TIL_ARCHIVEFILES}"), string(name: 'TIL_TRAVERSION', value: "${params.TIL_TRAVERSION}"), string(name: 'DEV_TAG', value: "${DEV_TAG}"), string(name: 'BUILD_REQUESTER', value: "${params.BUILD_REQUESTER}"), string(name: 'RELEASE', value: "${params.RELEASE}"), string(name: 'NEXUS_URL', value: "${env.NEXUS_URL}"), string(name: 'LT_REPO', value: "${env.LT_REPO}"), string(name: 'SIT_REPO', value: "${env.SIT_REPO}"), string(name: 'TIL_GROUPID', value: "${env.TIL_GROUPID}"), string(name: 'NEXUS_VERSION', value: "${env.NEXUS_VERSION}"), string(name: 'NEXUS_USERNAME', value: "${env.NEXUS_USERNAME}"), string(name: 'BW_VERSION', value: "${params.BW_VERSION}"), string(name: 'NEXUS_PASSWORD', value: "${env.NEXUS_PASSWORD}"), string(name: 'IRIS_NUMBER', value: "${params.JIRA_NUMBER}"), string(name: 'IRIS_DESCRIPTION', value: "${params.JIRA_DESCRIPTION}"), string(name: 'MODIFIED_FILES', value: "${params.MODIFIED_FILES}"), string(name: 'DELETED_FILES', value: "${params.DELETED_FILES}"), string(name: 'DEFECT_NUMBER', value: "${params.DEFECT_NUMBER}"), string(name: 'TIL_MODULE', value: "${params.TIL_MODULENAME}"), string(name: 'COMMON_ENGINES', value: "${COMMON_ENGINES_STRING}"), string(name: 'PIPELINE_WORKSPACE', value: "${env.WORKSPACE}")]
					
					
					 
					//pushing new version ears from common location to Nexus Repository
					script{
							String[] engineNames = "${TIL_ARCHIVEFILES}".split(";");
							earDiff_url = []
							prod_earDiff_url = []
							engine = "${TIL_ARCHIVEFILES}"
							for (String engine_common: COMMON_ENGINES_LIST) {
								echo "engine name is: ${engine_common}"
								//sh label: '', script: 'cat ${BUILD_HISTORY_PATH}/BUILD_${JIRA_NUMBER}_PROPERTIES | grep "til.${engine}.nextver" | cut -d \' \' -f 2 | tr -d \' \''
								def cv = sh(script:"cat ${BUILD_HISTORY_PATH}/${DEV_TAG}/BUILD_${DEV_TAG}_PROPERTIES | grep til.${engine}.nextver | cut -d \' \' -f 2 | tr -d \' \'", returnStdout: true).trim()
								echo "CV value is:${cv}"
								FINAL_VERSION = "${cv}"
								ENG_VERSIONS = ENG_VERSIONS.trim().concat("${engine}:${cv};")
								nexusArtifactUploader artifacts: [[artifactId: "${engine_common}", classifier: '', file: "${BUILD_HISTORY_PATH}/${DEV_TAG}/${engine}-${cv}.ear", type: 'ear']], credentialsId: '74edde97-94e0-403c-93f6-cad6c46c45f8', groupId: "${TIL_GROUPID}", nexusUrl: "${NEXUS_URL}", nexusVersion: "${NEXUS_VERSION}", protocol: 'http', repository: "${LT_REPO}", version: "${cv}"
								nexusArtifactUploader artifacts: [[artifactId: "${engine_common}", classifier: '', file: "${BUILD_HISTORY_PATH}/${DEV_TAG}/${engine}-${cv}_diff", type: 'html']], credentialsId: '74edde97-94e0-403c-93f6-cad6c46c45f8', groupId: "${TIL_GROUPID}", nexusUrl: "${NEXUS_URL}", nexusVersion: "${NEXUS_VERSION}", protocol: 'http', repository: "${LT_REPO}", version: "${cv}"
								
								nexusArtifactUploader artifacts: [[artifactId: "${engine_common}", classifier: '', file: "${BUILD_HISTORY_PATH}/${DEV_TAG}/DEV_${DEV_TAG}", type: 'txt']], credentialsId: '74edde97-94e0-403c-93f6-cad6c46c45f8', groupId: "${TIL_GROUPID}", nexusUrl: "${NEXUS_URL}", nexusVersion: "${NEXUS_VERSION}", protocol: 'http', repository: "${LT_REPO}", version: "${cv}"

								nexusArtifactUploader artifacts: [[artifactId: "${engine_common}", classifier: '', file: "${BUILD_HISTORY_PATH}/${DEV_TAG}/${engine}-${cv}-PROD_diff", type: 'proddiff']], credentialsId: '74edde97-94e0-403c-93f6-cad6c46c45f8', groupId: "${TIL_GROUPID}", nexusUrl: "${NEXUS_URL}", nexusVersion: "${NEXUS_VERSION}", protocol: 'http', repository: "${LT_REPO}", version: "${cv}"
								
								// upload pom file for each of the engine.
								nexusArtifactUploader artifacts: [[artifactId: "${engine_common}", classifier: '', file: "${BUILD_HISTORY_PATH}/${DEV_TAG}/${engine}.pom", type: 'pom']], credentialsId: '74edde97-94e0-403c-93f6-cad6c46c45f8', groupId: "${TIL_GROUPID}", nexusUrl: "${NEXUS_URL}", nexusVersion: "${NEXUS_VERSION}", protocol: 'http', repository: "${LT_REPO}", version: "${cv}"
																						
								// upload validation EAR Validation log file for each of the engine.
								nexusArtifactUploader artifacts: [[artifactId: "${engine_common}", classifier: '', file: "${BUILD_HISTORY_PATH}/${DEV_TAG}/Validation.log", type: 'ear_validation_log']], credentialsId: '74edde97-94e0-403c-93f6-cad6c46c45f8', groupId: "${TIL_GROUPID}", nexusUrl: "${NEXUS_URL}", nexusVersion: "${NEXUS_VERSION}", protocol: 'http', repository: "${LT_REPO}", version: "${cv}"								
								
								// Upload appconf file to Nexus for each engine.
								nexusArtifactUploader artifacts: [[artifactId: "${engine_common}", classifier: '', file: "${BUILD_HISTORY_PATH}/${DEV_TAG}/${engine_common}.appconf", type: 'appconf']], credentialsId: '74edde97-94e0-403c-93f6-cad6c46c45f8', groupId: "${TIL_GROUPID}", nexusUrl: "${NEXUS_URL}", nexusVersion: "${NEXUS_VERSION}", protocol: 'http', repository: "${LT_REPO}", version: "${cv}"
								
								// upload Sonarqube Report file for each of the engine.
								nexusArtifactUploader artifacts: [[artifactId: "${engine_common}", classifier: '', file: "${WORKSPACE}/${TIL_TYPE}_${engine}.xlsx", type: 'xlsx']], credentialsId: '74edde97-94e0-403c-93f6-cad6c46c45f8', groupId: "${TIL_GROUPID}", nexusUrl: "${NEXUS_URL}", nexusVersion: "${NEXUS_VERSION}", protocol: 'http', repository: "${LT_REPO}", version: "${cv}"
								
								// get the ear diff urls in nexus repository
								diff_url = "http://${NEXUS_URL}/repository/${LT_REPO}/${TIL_GROUPID}/${engine_common}/${cv}/${engine_common}-${cv}.html"
								earDiff_url.push("${diff_url}")
								prod_diff_url = "http://${NEXUS_URL}/repository/${LT_REPO}/${TIL_GROUPID}/${engine_common}/${cv}/${engine_common}-${cv}.proddiff"
								prod_earDiff_url.push("${prod_diff_url}")
							}
							nexusArtifactUploader artifacts: [[artifactId: "BUILD_HISTORY", classifier: '', file: "${BUILD_HISTORY_PATH}/${DEV_TAG}/DEV_${DEV_TAG}", type: 'txt']], credentialsId: '74edde97-94e0-403c-93f6-cad6c46c45f8', groupId: "${TIL_GROUPID}", nexusUrl: "${NEXUS_URL}", nexusVersion: "${NEXUS_VERSION}", protocol: 'http', repository: "${LT_REPO}", version: "${DEV_TAG}_${date_now}"
							echo "Engine version variable is: ${ENG_VERSIONS}"
						}
				
				}
				sleep 5
				script{
					// This is to compose an email to send the Build Summary along with EAR DIFF.
					emailext mimeType: 'text/html',
						subject: "[Jenkins]: ${currentBuild.fullDisplayName}  - " + "Build CHANGE LOG SUMMARY",
						from:"TIL_BUILDS@vodafone.com",
						to: "${bw_mailRecipients}",
						body: "${get_body_build_summary()}" 
						
					sh label: '', script: 'rm -r ${BUILD_HISTORY_PATH}/${DEV_TAG}'
                    
				}						
			}
		}  
	}
	post {
        always {
				script {
					def date_print = new Date().format( 'yyyy/MM/dd hh:mm:ss' )
					def version_print = ""
					if ( "${currentBuild.currentResult}" == "SUCCESS" ) {
						version_print="${FINAL_VERSION}"
						til_build_status = "PASS"
					} else {
						version_print="0"
						til_build_status = "FAIL"
					} 
					//sh label: '', script: "echo ${date_print},${params.RELEASE},BWBuild,${params.TIL_ARCHIVEFILES},Build,${currentBuild.currentResult},${currentBuild.duration},${version_print}>> ${REPORT_PATH}"
					statsFile = new File(REPORT_PATH)
					statsFile.append('\n' + date_print + ',' + params.RELEASE + ',' + "BWBuild" + ',' + params.TIL_ARCHIVEFILES + ',' + "Build" + ',' + currentBuild.currentResult + ',' + currentBuild.duration + ',' + version_print)
                    
                    //[CICD-507] Insert Deployment metadata to TIL_BUILD_HISTORY DB.
                    def insert_query = """
                    Insert into CICD_TIL_BUILD_HISTORY (TIL_MODULENAME, TIL_ARCHIVEFILES, PROJECT_NAME, BUILD_REQUESTER, RELEASE_NO, JIRA_NUMBER, 
                    DEFECT_NUMBER, JIRA_DESCRIPTION, BW_VERSION, STATUS, CREATED_ON, CREATED_BY) 
                    values 
                    ('${params.TIL_MODULENAME}', '${params.TIL_ARCHIVEFILES}', '${params.PROJECTNAME}', '${params.BUILD_REQUESTER}', '${params.RELEASE}', '${params.JIRA_NUMBER}', '${params.DEFECT_NUMBER}', '${params.JIRA_DESCRIPTION}', '${version_print}', '${til_build_status}', sysdate, '${user}')
                    """
		
                    println("DEBUG: Insert query is: " + insert_query)
                    DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: insert_query
				}
		}
    }
}
