
import groovy.time.*

def trigger_results_email(deployParams){
	// This function is to trigger an email for the provided map.
	emailext mimeType: 'text/html',
	subject: "[Jenkins]: ${currentBuild.fullDisplayName}  - " + "Upliftment Results Summary",
	from:"CICD_ISTILDeploymentStatus@vodafone.com",
	to: "${mailRecipients}",
	body: 	"${emailFunc.get_results_email_summary map: deployParams.map, REPORT_STAGE: deployParams.REPORT_STAGE}" 
}

//[CICD-476] Fix: function to get elapsed time duration 
def elapsedTime(Closure closure){
    def timeStart = new Date()
    closure()
    def timeStop = new Date()
    return TimeCategory.minus(timeStop, timeStart).toMilliseconds()
}

def get_approvers_list(String str){
	outlist = sh (script: """cat /opt/tibco/.jenkins/config.xml | sed -n \'/role name=\"${str}\"/,\$p\' | sed \'/role>/q\' | grep "sid" | cut -d \'>\' -f 2 | cut -d \'<\' -f 1 | paste -s -d, -""",
			returnStdout: true).trim()
	return """${outlist}"""
}


def load_groovy_files() {
	// This function is to load all groovy files, where in common functions will be kept.
	emailFunc = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/emailFunctions.groovy"
	mapFunc = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/mapFunctions.groovy"
	gitFunc = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/gitFunctions.groovy"
	BW_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/BWFunctions.groovy"
	commonFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/commonFunctions.groovy"
}



def checkout_git_repositories() {
	// This function is to checkout all the required GIT repositories.
	// Checkout Environment configurations.
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "ENV"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Production_Configuration.git']]]
	
	// Checkout Automation files from GITHUB repository.
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "automation"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
	
	
	checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'JENKINS_FILE']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_DevOps_Framework.git']]])	
}




def preparation_function(){
		
		date_now = new Date().format("YYYYMMddHHmmss")
		// Release number as per BW deployment tool standard
		bw_release_num = RELEASE.replace(".","_")
		println(bw_release_num)

		majorVersion = RELEASE.split('CCS')[1].split('\\.')[0]
		minorVersion = RELEASE.split('CCS')[1].split('\\.')[1]
		
		// Get staging approver details.
		ReleaseApprovers = get_approvers_list('Staging')
		//[CICD-539] Making user parameter as global parameter to use across the pipeline.
		user = currentBuild.rawBuild.causes[0].userId
		println("DEBUG: User name is: " + user)
		
		displayName = "${params.RELEASE}_${params.CRQ}_${BUILD_NUMBER}"
		currentBuild.displayName = "${displayName}"	
		
		// Checkout required GIT repositories.
		checkout_git_repositories()

		//Load all functions files from GIT. point to exact source file
		load_groovy_files()
		
		commonFunctions.validate_input_parameters RELEASE: params.RELEASE, CRQ: params.CRQ, DESCRIPTION: params.Description		

		// Construct VERSION_MAP and RESULTS_MAP with all the engines from NEXUS.
		construct_maps()
		
		
		// Grouping BW engines for deployment based on engine type and folder name.
		def group_engine_type_maps = VERSIONS_MAP.findAll { it.value['BW_VERSION'] != "NA" }.groupBy({ engine -> engine.value['BW_ENGINE_TYPE'] })
		group_engine_type_maps.each { g_type_key, g_type_value ->
				def group_engine_type_folder_maps = g_type_value.groupBy({ engine -> engine.value['BW_FOLDER_NAME'] })
				group_engine_type_folder_maps.each{ g_type_folder_key, g_type_folder_value ->
					def counter = 1
					def gID = 1
					g_type_folder_value.each { g_type_folder_value_key, g_type_folder_value_value ->
						VERSIONS_MAP[g_type_folder_value_key]['GROUP_ID'] = g_type_key + '_' + g_type_folder_key + '_' + gID
						if(counter < 5){
							counter++
						} else {
							counter = 0
							gID++ 
						}
					}
				}
		}
		print "VERSIONS_MAP after preparation step: " + VERSIONS_MAP
		//trigger_versions_email map: VERSIONS_MAP, REPORT_STAGE: "VERSIONS AFTER IGNORE"
	
}	


def construct_maps() {
	if(Restart_Engines.length() != 0){
		def Restart_Versions = ""
		Restart_Engines.split(';').each { engine ->
			 Restart_Versions = Restart_Versions + engine + ':' + "1" + ';'
		}
		mapFunc.generate_map inputString:Restart_Versions, map:Restart_Engine_Snap
	}

	Engines_Map = Restart_Engine_Snap


	Engines_Map.each { key, value ->
		VERSIONS_MAP[key] = ['BW_VERSION':'NA', 'BW_FOLDER_NAME':'NA', 'BW_ENGINE_TYPE':'NA', 'EMS_VERSION':'NA', 'SQL_VERSION':'NA', 'XML_FILES':'NA', 'JAR_FILES':'NA', 'EMAIL_FILES':'NA', 'RESULT':'NA', 'RF1_RESULT':'NA', 'RF2_RESULT':'NA', 'RB_RESULT':'NA', 'BW_Generation':'NOT_REQUIRED', 'SQL_Deployment':'NOT_REQUIRED', 'EMS_Deployment':'NOT_REQUIRED', 'XML_Deployment':'NOT_REQUIRED', 'JAR_Deployment':'NOT_REQUIRED', 'EMAIL_Deployment':'NOT_REQUIRED', 'BW_Deployment':'NOT_REQUIRED',  'BW_Restart':'NOT_STARTED', 'EMS_DURATION':'0', 'SQL_DURATION':'0', 'BW_DURATION':'0', 'FILE_DURATION':'0', 'DB_ROW_ID':'0']
	}

	if(Restart_Engine_Snap.size() != 0){
		Restart_Engine_Snap.keySet().each { engine ->
			bw_folder = gitFunc.get_engine_bw_folder_name_from_gvconf engine: engine
			if(bw_folder){
				VERSIONS_MAP[engine]['BW_FOLDER_NAME'] =  bw_folder
			} else {
				error("Check the engine name and Folder name in GV conf for proper format")
			}
			VERSIONS_MAP[engine]['BW_VERSION'] = "1"
			VERSIONS_MAP[engine]['BW_ENGINE_TYPE'] = "RESTART"
			VERSIONS_MAP[engine]['BW_Restart'] = "NOT_STARTED"
		}
	}
	if ("${params.Target_Env}" == "Staging" || "${params.Target_Env}" == "Production") {
		VERSIONS_MAP.each { pl_engine, pl_version ->
			if(VERSIONS_MAP[pl_engine]['BW_FOLDER_NAME'] == "SB01"){
				VERSIONS_MAP[pl_engine]['BW_FOLDER_NAME'] = "ServiceBus1"
			}
			if(VERSIONS_MAP[pl_engine]['BW_FOLDER_NAME'] == "SB02") {
				VERSIONS_MAP[pl_engine]['BW_FOLDER_NAME'] = "ServiceBus2"
			}
		}
	
	}
}


def bw_generate_stage(){
	
//Checkout Environment Configurations
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "ENV"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Production_Configuration.git']]]
	
	// checkout Release templates repository
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Release_Repo"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Production_Configuration.git']]]
	
	// Construct Description for engine
	//def user = currentBuild.rawBuild.causes[0].userId
	//println(user);
	
	//[CICD-519]: Fix to handle special characters in Description part
	String desc = "${params.Description}".replaceAll(/(!|"|@|#|\$|%|&|\\/|\(|\)|=|\?)/, /\\$0/)
	desc = desc + "|" + "${user}"		
	
	//def desc = "${params.Description}".trim() + "|" + "${user}"
	//println(desc); 
	//Group versios map with groupid and generate bw configuration in target host 
	def BW_Deploy_group_maps = VERSIONS_MAP.groupBy({ engine -> engine.value['GROUP_ID'] })

	BW_Deploy_group_maps.each { patteren_string, BW_Deploy_group ->
		eng_ver_map = BW_Deploy_group.collectEntries {bw_engine, bw_version -> [bw_engine, bw_version['BW_VERSION']]}
		String engines_versions = mapFunc.convert_map_to_string engine_map:eng_ver_map
		println("DEBUG:" + engines_versions)
		String engines_list = "${eng_ver_map.keySet().join(';')}"
		println("DEBUG:" + engines_list)
		
		echo "DEBUG: pattern string is: ${patteren_string}"
		if(patteren_string.toString() != "null") {
			BW_type = patteren_string.split('_')[0]
			echo "DEBUG: BW_type is: ${BW_type}"
			BW_Folder = patteren_string.split('_')[1]
			group_id = patteren_string.split('_')[2]
		} else {
			BW_type = "None"
		}

		if (BW_type == "RESTART") {
			
			println("DEBUG:" + group_id + "Generate conf file for type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list)
			BW_Functions.generate_conf_files_restart engines:engines_versions, Host:"${params.Target_Env}", ReleaseNumber:"${params.RELEASE}", folderName:BW_Folder, description:"${desc}"
			
			// Call generate function by passing details
			BW_Functions.generate_bw_restart Host:"${params.Target_Env}", crq_no:"${params.CRQ}", datetime:"${date_now}", engines_list:engines_list, deployment_type:"EXISTING", folderName:BW_Folder, bw_folder_release:bw_release_num, engine_group:patteren_string
			
		}else {
			println("DEBUG: Invalid Deployment type Identified. Please fix this issue")
		}
	}
	
	// Update maps with failed engines from BW Generate
	def bw_generate_failed_file = "${WORKSPACE}/${params.Target_Env}/BW_Deployment/generate_failure.txt"
	if(fileExists(bw_generate_failed_file)) {
		def bw_generate_failed_ouput = readFile("${WORKSPACE}/${params.Target_Env}/BW_Deployment/generate_failure.txt")
		if (bw_generate_failed_ouput.size() != 0) {
			def failed_file = new File("${WORKSPACE}/${params.Target_Env}/BW_Deployment/generate_failure.txt")
			def failed_engines_list = failed_file.readLines().join(';')
			mapFunc.update_version_map_result map: VERSIONS_MAP, engines: failed_engines_list, stage: "BW_Generation", status:"FAILED"
		}
	} 

	// Update maps with success engines from BW Generate
	def bw_generate_success_file = "${WORKSPACE}/${params.Target_Env}/BW_Deployment/generate_success.txt"
	if(fileExists(bw_generate_success_file)) {
		def bw_generate_success_ouput = readFile("${WORKSPACE}/${params.Target_Env}/BW_Deployment/generate_success.txt")
		if (bw_generate_success_ouput.size() != 0) {
			def success_file = new File("${WORKSPACE}/${params.Target_Env}/BW_Deployment/generate_success.txt")
			def success_engines_list = success_file.readLines().join(';')
			mapFunc.update_version_map_result map: VERSIONS_MAP, engines: success_engines_list, stage: "BW_Generation", status:"PASSED"
		}
	}
	
	// Trigger Result Email
	//trigger_results_email map: VERSIONS_MAP, REPORT_STAGE: "BW_Generate"
	
}	


// Function for BW Restart

def bw_restart_stage(){ 
              
				 
	//Group versios map with groupid and run deploy step in target host 
	def BW_Deploy_group_maps = VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['BW_VERSION'] != "NA" }.groupBy({ engine -> engine.value['GROUP_ID'] })
	BW_Deploy_group_maps.each { patteren_string, BW_Deploy_group ->
		eng_ver_map = BW_Deploy_group.collectEntries {bw_engine, bw_version -> [bw_engine, bw_version['BW_VERSION']]}
		String engines_versions = mapFunc.convert_map_to_string engine_map:eng_ver_map
		println("DEBUG:" + engines_versions)
		String engines_list = "${eng_ver_map.keySet().join(';')}"
		println("DEBUG:" + engines_list)
		
		echo "DEBUG: pattern string is: ${patteren_string}"
		if(patteren_string.toString() != "null") {
			BW_type = patteren_string.split('_')[0]
			echo "DEBUG: BW_type is: ${BW_type}"
			BW_Folder = patteren_string.split('_')[1]
			group_id = patteren_string.split('_')[2]
			// Calling Restart Function
			BW_Functions.bw_restart Host:"${params.Target_Env}", crq_no:"${params.CRQ}", datetime:"${date_now}", bw_folder_release:bw_release_num, engine_group:patteren_string, folderName:BW_Folder, engines_list_restart:engines_list
		} 
	  }
	// Check if BW Restart file exists for Failures
	def bw_restart_failed_file = "${WORKSPACE}/${params.Target_Env}/BW_Deployment/restart_failure.txt"
	if(fileExists(bw_restart_failed_file)) {
		def bw_restart_failed_ouput = readFile("${WORKSPACE}/${params.Target_Env}/BW_Deployment/restart_failure.txt")
		if (bw_restart_failed_ouput.size() != 0) {
		    // Reading Restart Failure
			def failed_file = new File("${WORKSPACE}/${params.Target_Env}/BW_Deployment/restart_failure.txt")
			def failed_engines_list = failed_file.readLines().join(';')
			  
			failed_engines_list.split(';').each { bw_engine ->
				if(VERSIONS_MAP.containsKey(bw_engine)) {
					// CICD1684 - removing updating Result Map with Failed status
					//VERSIONS_MAP[bw_engine]['RESULT'] = "FAILED"
					VERSIONS_MAP[bw_engine]['BW_Restart'] = "FAILED"
					print "ERROR: Failure in restart for the engine: ${failed_engines_list}"
					error "ERROR: Restarts failed for some of the engines. Please check the summary"
				}
			}
			
			// Email Restart Faileed Engines
			//trigger_results_email map: VERSIONS_MAP, REPORT_STAGE: "BW_Restart"
			
		}							
	}
		
		// Reading restart successful engines file 
		def bw_restart_success_file = "${WORKSPACE}/${params.Target_Env}/BW_Deployment/restart_success.txt"
	    if(fileExists(bw_restart_success_file)) {
			  def bw_restart_success_ouput = readFile("${WORKSPACE}/${params.Target_Env}/BW_Deployment/restart_success.txt")
			  def success_file = new File("${WORKSPACE}/${params.Target_Env}/BW_Deployment/restart_success.txt")
			  def success_engines_list = success_file.readLines().join(';')
			  success_engines_list.split(';').each { bw_engine ->
					if(VERSIONS_MAP.containsKey(bw_engine)) {
						VERSIONS_MAP[bw_engine]['BW_Restart'] = "PASSED"
					}
			   }
		}
		
		
		
}



ReleaseApprovers = ""
date_now = " "
displayName = ""
bw_release_num = ""
BW_Folder_Snap = [:]
Restart_Engine_Snap = [:]
Env_Prefix = ""
Engines_Map = [:]
VERSIONS_MAP = [:]
BW_Type_Snap = [:]

// Pipeline parameters.
FolderName = ""
nexusFunc = ""
emailFunc = ""
mapFunc = ""
Env_Prefix = ""
maps_list = []
BW_type = ""
BW_Folder = ""
group_id = ""



user = ""


import groovy.json.JsonOutput

pipeline {
    agent any
	options {
        preserveStashes(buildCount: 49)
    }

    environment {
		REPO_URL = "http://195.233.197.150:8081/repository"
		NEXUS_URL = "http://195.233.197.150:8081"
		NEXUS_USER = "admin"
		NEXUS_PASSWD = "admin123"
		Promotion_Repo = "PROD_REPO"
		BW_GROUPID = "TIL_BW"
		EMS_GROUPID = "TIL_EMS"
		SQL_GROUPID="TIL_SQL"
		emsIgnore = "false"
		UPLIFTMENT_REF_REPO = "STAGING_REPO"
		BW_InstanceCount = 2
		EnvironmentRepository = "TIL_Production_Configuration"
		//[CICD-539] Insert Deployment metadata to release notes DB.
		dbURL = 'jdbc:oracle:thin:@195.233.199.13:33000:TIBTST1'
		dbUserName = 'CICD_OWN_DB01'
		dbPassword = 'TIL_CICD_DB'
		dbDriver = 'oracle.jdbc.driver.OracleDriver'		
    }

    stages {
		stage('ReleasePreparation') {
			steps {
				script{
					deleteDir()
					preparation_function()
                }
			}
		}
		
		stage('BW Generate') {
		    when {
			     expression { VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" } }
			    }
			steps {
				script {
					//Calling BW  Generate Function	
					bw_generate_stage()	
				}
			}
		}
		
		stage('BW Restart') {
		    when {
			     expression { VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" } }
			    }
			steps {
				echo "BW Restart"
				script{
					// Calling BW Restart Stage function
				 	bw_restart_stage()
					

					trigger_results_email map: VERSIONS_MAP, REPORT_STAGE: "BW-RESTART"
				} 
			}
		}	
	}
}