import java.text.*
import groovy.time.*

def date = new Date();
def sdf = new SimpleDateFormat("yyyyMMddHHmmss");
def date_time = sdf.format(date)


def elapsedTime(Closure closure){
    def timeStart = new Date()
    closure()
    def timeStop = new Date()
    return TimeCategory.minus(timeStop, timeStart).toMilliseconds()
}
	
def Git_Checkout (){

//Checkout Ansible Scripts for Job
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Scripts"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]

//Checkout Scripts for Job
			
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Certificates"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Production_Configuration.git']]]
}

def get_body_build_summary(){
		def date = new Date();
		def sdf = new SimpleDateFormat("dd/MM/yyyy  HH:mm");
		def date_time = sdf.format(date)
		
	
		def body_build_summary = """
				<style type="text/css">
				.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
				.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
				.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
				.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
				.tg .tg-2wig{font-weight:bold;text-align:center;vertical-align:top}
				.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
				.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
				.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
				.tg .tg-0lax{text-align:left;vertical-align:top}
				</style>
				</style>
				<table class="tg" style="undefined;table-layout: fixed; width: 100%">
				<colgroup>
				<col style="width: 90px">
				<col style="width: 90px">
				<col style="width: 90px">
				<col style="width: 90px">
				</colgroup>
				  <tr>
					<th class="tg-amwm" colspan="6">Certificate Deployment</th>
				  </tr>
				  <tr>
					<td class="tg-1wig" colspan="2">Submitted By</td>
					<td class="tg-0lax" colspan="4">${currentBuild.getRawBuild().getCauses()[0].getUserId()}</td>
				  </tr>
				  <tr>
					<td class="tg-1wig" colspan="2">Date</td>
					<td class="tg-0lax" colspan="4">${date_time}</td>
				  </tr>
				  <tr>	
					<td class="tg-1wig" colspan="2">Environment</td>
					<td class="tg-0lax" colspan="4">${ENV}</td>
				  </tr>
				  <tr>	
					<td class="tg-1wig" colspan="2">CRQ_Number</td>
					<td class="tg-0lax" colspan="4">${CRQ}</td>
				  </tr>
				  <tr>	
					<td class="tg-1wig" colspan="2">Client_Name</td>
					<td class="tg-0lax" colspan="4">${Client_Name}</td>
				  </tr>
				  <tr>	
					<td class="tg-1wig" colspan="2">Certificate_Type</td>
					<td class="tg-0lax" colspan="4">${Certificate_Type}</td>
				  </tr>
				  <tr>	
					<td class="tg-1wig" colspan="2">Engine_List</td>
					<td class="tg-0lax" colspan="4">${Engine_List}</td>
				  </tr>
				  <tr>	
					<td class="tg-1wig" colspan="2">Certificates_List</td>
					<td class="tg-0lax" colspan="4">${Files}</td>
				  </tr>
				</table>
				
				<br><br><br>
		"""
		emailBody = body_build_summary
		return body_build_summary
}


def  Preparation ()	{
	
	
	displayName = "Cert_Deploy_${CRQ}_${BUILD_NUMBER}"
	currentBuild.displayName = "${displayName}"
	
	Git_Checkout ()
	
	sh '''
	
		cp -rf ${WORKSPACE}/Certificates/Certificate_Configuration ${WORKSPACE}/Certificate_Configuration
		cp -rf ${WORKSPACE}/Scripts/Certificate_Deployment ${WORKSPACE}/Certificate_Deployment
		rm -R ${WORKSPACE}/Certificates ${WORKSPACE}/Scripts
		
		
	'''
	
	if(fileExists("${WORKSPACE}/Certificate_Configuration/${Server_Type}/${ENV}/${Server_Type}_Certificateconfig.txt")) {		
		
		sh '''		 
			cat ${WORKSPACE}/Certificate_Configuration/${Server_Type}/${ENV}/${Server_Type}_Certificateconfig.txt | grep ${Client_Name} | grep ${Certificate_Type} >> ${WORKSPACE}/data.txt

		'''	
		def File = "${WORKSPACE}/data.txt"
		def readFile = new File("${File}")
		def FileContent = readFile.readLines()
		Content = "${FileContent}".split('\\|')
		Engine_List = Content[1]
			
	}
	
	sh '''
	cd ${WORKSPACE}/Certificate_Configuration/${Server_Type}/${ENV}/Certs/${Client_Name}/${Certificate_Type}
	ls * > ${WORKSPACE}/FileList.txt
	'''
	cert_snap= ""
	def File1 = "${WORKSPACE}/FileList.txt"
	def readFile1 = new File("${File1}")
	def FileContent1 = readFile1.readLines()
	def Path = "${FileContent1}".split('\\[')
	def Path1 = Path[1].split('\\]')
	FileList = Path1[0].split(', ')
	path_list = Content[3].split(',')
	//echo "${path_list}"	
	for (List in FileList) {
		for (List_path in path_list) {
			if (cert_snap.length() != 0) {
				cert_snap = "${cert_snap}" + "," + List_path + List			
			}else {
				// def first = List.split('\\[')
				cert_snap = "${Client_Name}" + ":" + List_path + List
			}
		}
	}
	//cert_snap = "${File_list}".split('\\]')
	println "${cert_snap}"
	def emailBody = "${get_body_build_summary()}"
		emailext  mimeType: 'text/html', 
		subject: "[Jenkins]:Certificate Deployment",
		from:"${Server_Type}_Certificate_Deploy",
		to: "${dev_mailRecipients}",
		body:"${emailBody}" + 
				"<br><p><b><font size='2' color='Black'>${Server_Type}_Certificate_Deploy_BUILDURL: <a href='${BUILD_URL}input'>${BUILD_URL}</a></font></b></p>"	
		input 'Proceed with  Cert Deploy?'
	/*	def Input = input( id: 'userInput', message: 'Do you want to Proceed the Deployment or Not ?',
				parameters: [[$class: 'ChoiceParameterDefinition', defaultValue: 'Proceed', 
					description:'describing choices', name:'nameChoice', choices: "Proceed"]
					],
				submitterParameter: 'submitter',
				submitter: "${dev_mailRecipients}"
				) 
				println("DEBUG: Choice selected is: " + Input.nameChoice)
	*/
}


def Rollback_Input = ""


pipeline {
    agent any
	environment {
		Content = ""
		cert_snap = ""
		FileList= ""
		File_list = ""
		Src_Path = "${WORKSPACE}/Certificate_Configuration/${Server_Type}/${ENV}/Certs/${Client_Name}/${Certificate_Type}"
		Engine_List = ""
		dev_mailRecipients = "devops-vfuk-integration@vodafone.com,DL-TSSC-AO2-UK-Integration_TIL-RIG_L2@vodafone.com"
		Files = ""
		Status = ""
		Signoff_Input = ""
		BW_Input = ""
		
	}
    stages {
        stage ('Preparation') {
            steps {
                script {
                  cleanWs()  
                  Preparation ()
                    
                }
            }
        }
        stage ('Cert_Deploy For auktltnr') {
            steps {
                script {
                  
					Deploy_Duration = elapsedTime {
						ansiColor('xterm') {
							ansiblePlaybook (playbook: "${WORKSPACE}/Certificate_Deployment/certsDeploy.yml", colorized: true, extras: '', extraVars: [host: "Staging_CertBW1", cert_snap: "${cert_snap}", datetime: "${date_time}", crq_num: "${CRQ}", Src_Path: "${Src_Path}"])
						}
					}
					Deploy_Duration = Deploy_Duration*0.001
					println("Deploy Duration in Sec: " + Deploy_Duration)
					println "Certificates Deployment Completed"
                }
            }
        }        
    
		stage ('Restart For auktltnr applications') {
            steps {
                script {
					def BW1_Input = input( id: 'userInput', message: 'Do you want to Proceed for Manual or Automating Restart ?',
					parameters: [[$class: 'ChoiceParameterDefinition', defaultValue: 'Manual', 
					description:'describing choices', name:'nameChoice', choices: "Manual"]
					],
					submitterParameter: 'submitter',
					submitter: "${dev_mailRecipients}"
					)
					println("DEBUG: Choice selected is: " + BW1_Input.nameChoice)
					println "Restarting"
					Status = "Success"
					
				BW_Input = input( id: 'userInput', message: 'Do you want to Proceed for Next Deploy Stage or Rollback the Certificates ?',
					parameters: [[$class: 'ChoiceParameterDefinition', defaultValue: 'Continue', 
					description:'describing choices', name:'nameChoice', choices: "Continue\nRollback"]
					],
					submitterParameter: 'submitter',
					submitter: "${dev_mailRecipients}"
					)
					println("DEBUG: Choice selected is: " + BW_Input.nameChoice)
					
					if ( BW_Input.nameChoice == "Rollback" ) {
						
						Signoff_Input = "Continue"
						
					}
				
				}
			}
		}
	
		stage ('Cert_Deploy For auktltpr') {
            when {
			     expression { BW_Input.nameChoice == "Continue" }
			}
			steps {
			    script {
					
                    //println "Deploy"
					Deploy_Duration = elapsedTime {
						ansiColor('xterm') {
							ansiblePlaybook (playbook: "${WORKSPACE}/Certificate_Deployment/certsDeploy.yml", colorized: true, extras: '', extraVars: [host: "Staging_CertBW2", cert_snap: "${cert_snap}", datetime: "${date_time}", crq_num: "${CRQ}", Src_Path: "${Src_Path}"])
						}
					}
					Deploy_Duration = Deploy_Duration*0.001
					println("Deploy Duration in Sec: " + Deploy_Duration)
					println "Certificates Deployment Completed"
                }
            }
        }        
    
		stage ('Restart For auktltpr applications') {
            when {
			     expression { BW_Input.nameChoice == "Continue" }
			}
			steps {
				script {
					def BW2_Input = input( id: 'userInput', message: 'Do you want to Proceed for Manual or Automating Restart ?',
					parameters: [[$class: 'ChoiceParameterDefinition', defaultValue: 'Manual', 
					description:'describing choices', name:'nameChoice', choices: "Manual"]
					],
					submitterParameter: 'submitter',
					submitter: "${dev_mailRecipients}"
					)
					println("DEBUG: Choice selected is: " + BW2_Input.nameChoice)
					println "Restarting"
					
					Signoff_Input = input( id: 'userInput', message: 'Do you want to Proceed for SignOff or Rollbach the Certificates ?',
					parameters: [[$class: 'ChoiceParameterDefinition', defaultValue: 'Signoff', 
					description:'describing choices', name:'nameChoice', choices: "Signoff\nRollback"]
					],
					submitterParameter: 'submitter',
					submitter: "${dev_mailRecipients}"
					)
					println("DEBUG: Choice selected is: " + Signoff_Input.nameChoice)
					
					if ( Signoff_Input.nameChoice == "Rollback" ) {
						
						Rollback_Input = "Rollback"
						println "123"
					
					}
					println "${Rollback_Input}"
				
				}
			}
		}
		
		
		stage ('Rollback ') {
			when {
			     expression { BW_Input.nameChoice == "Rollback" || Signoff_Input.nameChoice == "Rollback" }
			}
            steps {
                script {
					
					if ( BW_Input.nameChoice == "Rollback" ) {
						Rollback_Duration = elapsedTime {
							ansiColor('xterm') {
								ansiblePlaybook (playbook: "${WORKSPACE}/Certificate_Deployment/certsRollBack.yml", colorized: true, extras: '', extraVars: [host: "Staging_CertBW1", cert_snap: "${cert_snap}", datetime: "${date_time}", crq_num: "${CRQ}"])
							}
						}
						Rollback_Duration = Rollback_Duration*0.001
						println("Rollback Duration in Sec: " + Rollback_Duration)
						println "Rollback Completed"
						
					}
					
					if ( Rollback_Input == "Rollback" ) {
						Rollback_Duration = elapsedTime {
						
							ansiColor('xterm') {
								ansiblePlaybook (playbook: "${WORKSPACE}/Certificate_Deployment/certsRollBack.yml", colorized: true, extras: '', extraVars: [host: "Staging_CertBW1", cert_snap: "${cert_snap}", datetime: "${date_time}", crq_num: "${CRQ}"])
							}
							
							ansiColor('xterm') {
								ansiblePlaybook (playbook: "${WORKSPACE}/Certificate_Deployment/certsRollBack.yml", colorized: true, extras: '', extraVars: [host: "Staging_CertBW2", cert_snap: "${cert_snap}", datetime: "${date_time}", crq_num: "${CRQ}"])
							}
						}
						Rollback_Duration = Rollback_Duration*0.001
						println("Rollback Duration in Sec: " + Rollback_Duration)
						println "Rollback Completed"
						
					}
					
					}
				}
			}
			
						
			stage ('Sign Off') {
			
            steps {
                script {
					input 'Proceed with  Signoff ?'						
						println "Signoff Completed"
						
					
					}
				}
			}
		
	
	
	}
}
