
//import this package as part of the fix
import groovy.time.*

//[CICD-1530] Insert Deployment metadata to release notes DB.
import groovy.json.JsonOutput
import groovy.sql.*
import java.sql.Driver


def get_body_build_summary(deployParams){
	def date_format_report = new Date().format("dd/MM/yyy HH:mm")
	def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
		.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		</style>
		<table class="tg" style="undefined;table-layout: fixed; width: 900px">
		<colgroup>
		<col style="width: 100px">
		<col style="width: 350px">
		<col style="width: 100px">
		<col style="width: 350px">
		</colgroup>
		  <tr>
			<td>
			<table width="50%"><tr><td><img width="150" src="https://www.vodafone.co.uk/cs/groups/public/documents/webcontent/1287x929_vodafone_logo.jpg" alt="ITEAMS" style="text-align: right; width: 207px; border: 0; text-decoration:none; vertical-align: baseline;"></td></tr></table>
            <div style="display:none">
			</div>
			</td>
			<th class="tg-amwm" colspan="3">CCS Integration Staging Deployment Summary ${params.ReleaseNumber}</th>
		  </tr>
		  <tr>
			<td class="tg-1wig">Submitted By</td>
			<td class="tg-0lax">${currentBuild.getRawBuild().getCauses()[0].getUserId()}</td>
			<td class="tg-1wig">Date</td>
			<td class="tg-0lax">${date_format_report}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">RELEASE NUMBER</td>
			<td class="tg-0lax">${params.ReleaseNumber}</td>
			<td class="tg-1wig">Gateway</td>
			<td class="tg-0lax">${env.GatewayType}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">Deployment Type</td>
			<td class="tg-0lax">${deployParams.DeploymentType}</td>
			<td class="tg-1wig">Status</td>
			<td class="tg-0lax">${deployParams.Status}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">PID before restart</td>
			<td class="tg-0lax">${deployParams.beforeRestart}</td>
			<td class="tg-1wig">PID after restart</td>
			<td class="tg-0lax">${deployParams.afterRestart}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">Before ExternalApache Restart PID</td>
			<td class="tg-0lax">${deployParams.beforeExternalApacheRestart}</td>
			<td class="tg-1wig">After ExternalApache Restart PID</td>
			<td class="tg-0lax">${deployParams.afterExternalApacheRestart}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">Before InternalApache Restart PID</td>
			<td class="tg-0lax">${deployParams.beforeInternalApacheRestart}</td>
			<td class="tg-1wig">After InernalApache Restart PID</td>
			<td class="tg-0lax">${deployParams.afterInternalApacheRestart}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">LOG_URL</td>
			<td class="tg-0lax" colspan="3">${BUILD_URL}/console</td>
		  </tr>		  
		</table>
		<br><br><br>
	"""
	emailBody = body_build_summary
	writeFile file: "${WORKSPACE}/Reports/${deployParams.DeploymentType}_Report.html", text: emailBody 
	writeFile file: "/opt/tibco/.jenkins/userContent/Gateway/${env.GatewayType}/${params.ReleaseNumber}/${params.GatewayVersion}/${deployParams.DeploymentType}_Report.html", text: emailBody
	return body_build_summary
}


def Restart_Stage_Rollforward (thestage) {

	stage (thestage + ' Rollforward Restart') {

		// If the following values are blank, it means we are starting from stage and need to retrive the values from stash.
		unstash "stashProperties"
		if (date_now == " ") {
			date_now = sh(script:"cat ./DIR_STASH/propfile | grep -e date | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
			echo "Date after stage restart is:${date_now}"
		}
		if (displayName == " ") {
			displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
			currentBuild.displayName = "${displayName}_restart"
			echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
		}

		// get Gateway PID by calling ansible gateway_pid function
        GatewayFunction.GatewayFunction.gateway_pid Host:"${thestage}", GatewayType:"${env.GatewayType}"
		before_restart_pid = readFile "${thestage}/Gateway_Deployment/${thestage}_pid.txt"
		echo "Gateway PID is:${before_restart_pid}"
					
		// Check status of gateway and ask for user input if gateway in stopped state
		// get Gateway status by calling ansible gateway_status function
        GatewayFunction.gateway_status Host:"${thestage}", GatewayType:"${env.GatewayType}"
		def gatewayStatus = readFile "${thestage}/Gateway_Deployment/${thestage}_status.txt"
		echo "Gateway Status is:${gatewayStatus}"
		
		if (gatewayStatus == "0"){
			echo "gateway is running hence restarting"
			GatewayFunction.gateway_restart Host:"${thestage}", GatewayType:"${env.GatewayType}", internalApache:"${internalApache}", externalApache:"${externalApache}", gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
			
		}
		else {
			echo "gateway is not running"
			gateway_not_running Host:"${thestage}", GatewayType:"${env.GatewayType}", internalApache:"${internalApache}", externalApache:"${externalApache}", gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
	    }
		// get Gateway PID by calling ansible gateway_pid function
        GatewayFunction.gateway_pid Host:"${thestage}", GatewayType:"${env.GatewayType}"
		after_restart_pid = readFile "${thestage}/Gateway_Deployment/${thestage}_pid.txt"
		echo "Gateway PID is:${after_restart_pid}"	
					
		// CICD-1520 Capturing apache PID 
		if ( fileExists("${WORKSPACE}/${thestage}/Gateway_Deployment/Before_External.txt")) {			
			before_externalApache_restart_pid = readFile "./${thestage}/Gateway_Deployment/Before_External.txt"
			echo "Before_ExternalApache_Restart : ${before_externalApache_restart_pid}"
		}else {
			before_externalApache_restart_pid = "No ExternalApache For ${env.GatewayType}"
		}
		
		if ( fileExists("${WORKSPACE}/${thestage}/Gateway_Deployment/Before_Internal.txt")) {	  
			before_InternalApache_restart_pid = readFile "./${thestage}/Gateway_Deployment/Before_Internal.txt"
			echo "Before_InternalApache_Restart : ${before_InternalApache_restart_pid}"
		}else {
			before_InternalApache_restart_pid = "No InternalApache For ${env.GatewayType}"
		}
		
		if ( fileExists("${WORKSPACE}/${thestage}/Gateway_Deployment/After_External.txt")) {		
			after_externalApache_restart_pid = readFile "./${thestage}/Gateway_Deployment/After_External.txt"
			echo "After_ExternalApache_Restart : ${after_externalApache_restart_pid}"
		}else {
			after_externalApache_restart_pid = "No ExternalApache For ${env.GatewayType}"
		}
		
		if ( fileExists("${WORKSPACE}/${thestage}/Gateway_Deployment/After_Internal.txt")) {	  
			after_InternalApache_restart_pid = readFile "./${thestage}/Gateway_Deployment/After_Internal.txt"
			echo "After_InternalApache_Restart : ${after_InternalApache_restart_pid}"
		}else {
			after_InternalApache_restart_pid = "No InternalApache For ${env.GatewayType}"
		}
		
        // Notify team with status email
		emailext mimeType: 'text/html',
			subject: "[Jenkins]:${currentBuild.fullDisplayName}:Staging Deployment",
			from:"CICD_GatewayDeploymentStatus@vodafone.com",
			to: "${ops_mailRecipients}",
			body: 	"${get_body_build_summary(DeploymentType:'RF2', Status:'Success', beforeRestart:before_restart_pid, afterRestart:after_restart_pid, beforeExternalApacheRestart:before_externalApache_restart_pid, afterExternalApacheRestart:after_externalApache_restart_pid, beforeInternalApacheRestart:before_InternalApache_restart_pid, afterInternalApacheRestart:after_InternalApache_restart_pid)}"
					
	}
}	

def Rollforward_Stage (thestage) {

	stage (thestage + ' Rollforward') {

		// If the following values are blank, it means we are starting from stage and need to retrive the values from stash.
		unstash "stashProperties"
		if (date_now == " ") {
			date_now = sh(script:"cat ./DIR_STASH/propfile | grep -e date | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
			echo "Date after stage restart is:${date_now}"
		}
		if (displayName == " ") {
			displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
			currentBuild.displayName = "${displayName}_restart"
			echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
		}
		echo "Date without stage restart is:${date_now}"
		// Call deploy function by providing LinkTest Details.
		GatewayFunction.deploy_artefact Host:"${thestage}", nexus_group_id:"${env.GROUPID}", nexus_artifact_id:"${env.GatewayType}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.STAGING_REPO}", nexus_ArtefactVersion:"${params.GatewayVersion}", GatewayType:"${env.GatewayType}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CRQ}", datetime:"${date_now}", gatewayRestart:false, gatewayEnvironment:"${env.GatewayEnvironment}", deployType:"RF2"
				

	}
}	

def Restart_Stage_RollBack (thestage) {

	stage (thestage + ' RollBack Changes') {
		// If the following values are blank, it means we are starting from stage and need to retrive the values from stash.
		unstash "stashProperties"
		if (date_now == " ") {
			date_now = sh(script:"cat ./DIR_STASH/propfile | grep -e date | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
			echo "Date after stage restart is:${date_now}"
		}
		if (displayName == " ") {
			displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
			currentBuild.displayName = "${displayName}_restart"
			echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
		}
					
		// get Gateway PID by calling ansible gateway_pid function
        GatewayFunction.gateway_pid Host:"${thestage}", GatewayType:"${env.GatewayType}"
		before_restart_pid = readFile "${thestage}/Gateway_Deployment/${thestage}_pid.txt"
		echo "Gateway PID is:${before_restart_pid}"
		
		// Check status of gateway and ask for user input if gateway in stopped state
		// get Gateway status by calling ansible gateway_status function
        GatewayFunction.gateway_status Host:"${thestage}", GatewayType:"${env.GatewayType}"
		def gatewayStatus = readFile "${thestage}/Gateway_Deployment/${thestage}_status.txt"
		echo "Gateway Status is:${gatewayStatus}"
		
		if (gatewayStatus == "0"){
				 
			echo "gateway is running hence restarting"
			GatewayFunction.gateway_restart Host:"${thestage}", GatewayType:"${env.GatewayType}", internalApache:"${internalApache}", externalApache:"${externalApache}", gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
			
		}
		else {
			echo "gateway is not running"
			gateway_not_running Host:"${thestage}", GatewayType:"${env.GatewayType}", internalApache:"${internalApache}", externalApache:"${externalApache}", gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
					     
		}
		// get Gateway PID by calling ansible gateway_pid function
		GatewayFunction.gateway_pid Host:"${thestage}", GatewayType:"${env.GatewayType}"
		after_restart_pid = readFile "${thestage}/Gateway_Deployment/${thestage}_pid.txt"
		echo "Gateway PID is:${after_restart_pid}"	
					
		// CICD-1520 Capturing apache PID 
		if ( fileExists("${WORKSPACE}/${thestage}/Gateway_Deployment/Before_External.txt") ) {			
			before_externalApache_restart_pid = readFile "./${thestage}/Gateway_Deployment/Before_External.txt"
			echo "Before_ExternalApache_Restart : ${before_externalApache_restart_pid}"
		}else {
			before_externalApache_restart_pid = "No ExternalApache For ${env.GatewayType}"
		}
		
		if ( fileExists("${WORKSPACE}/${thestage}/Gateway_Deployment/Before_Internal.txt") ) {	  
			before_InternalApache_restart_pid = readFile "./${thestage}/Gateway_Deployment/Before_Internal.txt"
			echo "Before_InternalApache_Restart : ${before_InternalApache_restart_pid}"
		}else {
			before_InternalApache_restart_pid = "No InternalApache For ${env.GatewayType}"
		}
		
		if ( fileExists("${WORKSPACE}/${thestage}/Gateway_Deployment/After_External.txt") ) {		
			after_externalApache_restart_pid = readFile "./${thestage}/Gateway_Deployment/After_External.txt"
			echo "After_ExternalApache_Restart : ${after_externalApache_restart_pid}"
		}else {
			after_externalApache_restart_pid = "No ExternalApache For ${env.GatewayType}"
		}
		
		if ( fileExists("${WORKSPACE}/${thestage}/Gateway_Deployment/After_Internal.txt") ) {	  
			after_InternalApache_restart_pid = readFile "./${thestage}/Gateway_Deployment/After_Internal.txt"
			echo "After_InternalApache_Restart : ${after_InternalApache_restart_pid}"
		}else {
			after_InternalApache_restart_pid  = "No InternalApache For ${env.GatewayType}"
		}
		
        // Notify team with status email
		emailext mimeType: 'text/html',
		subject: "[Jenkins]:${currentBuild.fullDisplayName}:Staging Deployment",
			from:"CICD_GatewayDeploymentStatus@vodafone.com",
			to: "${ops_mailRecipients}",
			body: 	"${get_body_build_summary(DeploymentType:'RB', Status:'Success', beforeRestart:before_restart_pid, afterRestart:after_restart_pid, beforeExternalApacheRestart:before_externalApache_restart_pid, afterExternalApacheRestart:after_externalApache_restart_pid, beforeInternalApacheRestart:before_InternalApache_restart_pid, afterInternalApacheRestart:after_InternalApache_restart_pid)}"
						
	}
}	

def RollBack_Changes(thestage) {

	stage (thestage + ' RollBack Changes') {
	
		// If the following values are blank, it means we are starting from stage and need to retrive the values from stash.
		unstash "stashProperties"
		if (date_now == " ") {
			date_now = sh(script:"cat ./DIR_STASH/propfile | grep -e date | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
			echo "Date after stage restart is:${date_now}"
		}
		if (displayName == " ") {
			displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
			currentBuild.displayName = "${displayName}_restart"
			echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
		}
		// Call rollback function by providing LinkTest Details.
		GatewayFunction.rollback_artefact Host:"${thestage}", GatewayType:"${env.GatewayType}", crq_no:"${params.CRQ}", datetime:"${date_now}", internalApache:"${internalApache}", externalApache:"${externalApache}", gatewayEnvironment:"${env.GatewayEnvironment}"
			   
	}
}	

def Restart_Stage(thestage) {

	stage (thestage + ' RESTART') {
		
		// If the following values are blank, it means we are starting from stage and need to retrive the values from stash.
		unstash "stashProperties"
		if (date_now == " ") {
			date_now = sh(script:"cat ./DIR_STASH/propfile | grep -e date | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
			echo "Date after stage restart is:${date_now}"
		}
		if (displayName == " ") {
			displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
			currentBuild.displayName = "${displayName}_restart"
			echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
		}
			
		// get Gateway PID by calling ansible gateway_pid function
        GatewayFunction.gateway_pid Host:"${thestage}", GatewayType:"${env.GatewayType}"
					
		before_restart_pid = readFile "${thestage}/Gateway_Deployment/${thestage}_pid.txt"
					
		echo "Gateway PID is:${before_restart_pid}"
					
					
		// Check status of gateway and ask for user input if gateway in stopped state
		// get Gateway status by calling ansible gateway_status function
        GatewayFunction.gateway_status Host:"${thestage}", GatewayType:"${env.GatewayType}"
					
		def gatewayStatus = readFile "${thestage}/Gateway_Deployment/${thestage}_status.txt"
					
		echo "Gateway Status is:${gatewayStatus}"
					
		if (gatewayStatus == "0"){
					 
			echo "gateway is running hence restarting"
			GatewayFunction.gateway_restart Host:"${thestage}", GatewayType:"${env.GatewayType}", internalApache:"${internalApache}", externalApache:"${externalApache}", gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
			
		}
		else {
            echo "gateway is not running"
			gateway_not_running Host:"${thestage}", GatewayType:"${env.GatewayType}", internalApache:"${internalApache}", externalApache:"${externalApache}", gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
		}					
						 
		// get Gateway PID by calling ansible gateway_pid function
		GatewayFunction.gateway_pid Host:"${thestage}", GatewayType:"${env.GatewayType}"
					
		after_restart_pid = readFile "${thestage}/Gateway_Deployment/${thestage}_pid.txt"
					
		echo "Gateway PID is:${after_restart_pid}"	
					
		// CICD-1520 Capturing apache PID 
		if ( fileExists("${WORKSPACE}/${thestage}/Gateway_Deployment/Before_External.txt")) {			
			before_externalApache_restart_pid = readFile "./${thestage}/Gateway_Deployment/Before_External.txt"
			echo "Before_ExternalApache_Restart : ${before_externalApache_restart_pid}"
		}else {
			before_externalApache_restart_pid = "No ExternalApache For ${env.GatewayType}"
		}
		
		if ( fileExists("${WORKSPACE}/${thestage}/Gateway_Deployment/Before_Internal.txt")) {	  
			before_InternalApache_restart_pid = readFile "./${thestage}/Gateway_Deployment/Before_Internal.txt"
			echo "Before_InternalApache_Restart : ${before_InternalApache_restart_pid}"
		}else {
			before_InternalApache_restart_pid = "No InternalApache For ${env.GatewayType}"
		}
		
		if ( fileExists("${WORKSPACE}/${thestage}/Gateway_Deployment/After_External.txt")) {		
			after_externalApache_restart_pid = readFile "./${thestage}/Gateway_Deployment/After_External.txt"
			echo "After_ExternalApache_Restart : ${after_externalApache_restart_pid}"
		}else {
			after_externalApache_restart_pid = "No ExternalApache For ${env.GatewayType}"
		}
		
		if ( fileExists("${WORKSPACE}/${thestage}/Gateway_Deployment/After_Internal.txt")) {	  
			after_InternalApache_restart_pid = readFile "./${thestage}/Gateway_Deployment/After_Internal.txt"
			echo "After_InternalApache_Restart : ${after_InternalApache_restart_pid}"
		}else {
			after_InternalApache_restart_pid = "No InternalApache For ${env.GatewayType}"
		}

        // Notify team with status email
		emailext mimeType: 'text/html',
			subject: "[Jenkins]:${currentBuild.fullDisplayName}:Staging Deployment",
			from:"CICD_GatewayDeploymentStatus@vodafone.com",
			to: "${ops_mailRecipients}",
			body: 	"${get_body_build_summary(DeploymentType:'RF1', Status:'Success', beforeRestart:before_restart_pid, afterRestart:after_restart_pid, beforeExternalApacheRestart:before_externalApache_restart_pid, afterExternalApacheRestart:after_externalApache_restart_pid, beforeInternalApacheRestart:before_InternalApache_restart_pid, afterInternalApacheRestart:after_InternalApache_restart_pid)}"
					
	}
}

def Deploy_Stage(thestage) {

	stage( thestage + ' DEPLOYMENT') {
		
		//Checkout Environment Configurations
		git credentialsId: 'GITHUBKEY', poll: false, url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Production_Configuration.git'
				 
		// If the following values are blank, it means we are starting from stage and need to retrive the values from stash.
		unstash "stashProperties"
		if (date_now == " ") {
			date_now = sh(script:"cat ./DIR_STASH/propfile | grep -e date | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
			echo "Date after stage restart is:${date_now}"
		}
		if (displayName == " ") {
			displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
			currentBuild.displayName = "${displayName}_restart"
			echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
		}
		echo "Date without stage restart is:${date_now}"
		// Call deploy function by providing LinkTest Details.
		GatewayFunction.deploy_artefact Host:"${thestage}", nexus_group_id:"${env.GROUPID}", nexus_artifact_id:"${env.GatewayType}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.STAGING_REPO}", nexus_ArtefactVersion:"${params.GatewayVersion}", GatewayType:"${env.GatewayType}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CRQ}", datetime:"${date_now}", gatewayRestart:false, gatewayEnvironment:"${env.GatewayEnvironment}", deployType:"RF1"
			
	}


}

// Funcation to Get jenkins users from the given role
def get_approvers_list(String str){
	outlist = sh (script: """cat /opt/tibco/.jenkins/config.xml | sed -n \'/role name=\"${str}\"/,\$p\' | sed \'/role>/q\' | grep "sid" | cut -d \'>\' -f 2 | cut -d \'<\' -f 1 | paste -s -d, -""",
			returnStdout: true).trim()
	return """${outlist}"""
}

def gateway_not_running(deployParams) {
	script{
	        def USER_INPUT = input(
                              message: 'EGW Gateway Instance is not running. Select restart/skip to proceed with gateway restart ?',
                               parameters: [
                                 [$class: 'ChoiceParameterDefinition',
									choices: ['Restart','Skip'].join('\n'),
									name: 'input',
									description: 'Choose Restart or Skip']
									])
					      
						  if (USER_INPUT == "Restart")
					           {
						       GatewayFunction.gateway_restart Host:"${deployParams.Host}", GatewayType:"${deployParams.GatewayType}", internalApache:"${deployParams.internalApache}", externalApache:"${deployParams.externalApache}", gatewayRestart:"${deployParams.gatewayRestart}", gatewayEnvironment:"${deployParams.gatewayEnvironment}"
			
                                }
	}
}

def load_groovy_files() {
	
	// This function is to checkout all the required GIT repositories.
	checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'JENKINS_FILE']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_DevOps_Framework.git']]])
	
	//This function is to load groovy files, where in common functions will be kept
	GatewayFunction = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/GatewayFunctions.groovy"
	
	// Insert Deployment metadata to release notes DB.
	DB_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/dbFunctions.groovy"	
}

// Global Parameters to use in the stages.

//date_format_report = new Date().format("dd/MM/yyy HH:mm")
date_now = " "
displayName = " "
emailBody = " "
before_restart_pid = ""
after_restart_6180_pid = ""
Exceptional_Scenario_Approval = false
Exceptional_Scenario = false
stagingSkipApprovers = ""
def file = ""


// CICD-1520 Capturing apache PID 
def before_externalApache_restart_pid = ""
def before_InternalApache_restart_pid = ""
def after_externalApache_restart_pid = ""
def after_InternalApache_restart_pid = ""

internalApache = ""
externalApache = ""

// [CICD-1530]: Push all the deployment details to Release notes DB. 
user = ""

//def ops_mailRecipients = "nani.ponnada@vodafone.com, anilreddy.kolli@vodafone.com"

pipeline {
    agent any
	options {
        preserveStashes(buildCount: 49)
    }

    environment {
		GROUPID = "GATEWAY"
		GatewayType = "${params.Gateway_Type}"
		GatewayEnvironment = "${params.Environment}"
		REPO_URL = "http://195.233.197.150:8081"
		STAGING_REPO = "STAGING_REPO"
		PROD_REPO = "PROD_REPO"
		NEXUS_USER = "admin"
		NEXUS_PASSWD = "admin123"
		ops_mailRecipients = "DL-TSSC-AO2-UK-Integration_TIL-RIG_L2@vodafone.com, devops-vfuk-integration@vodafone.com, ankit.bhartiya1@vodafone.com, veera.venkatalsknuni@vodafone.com"
		

			
		//[CICD-1530] Insert Deployment metadata to release notes DB.
		dbURL = 'jdbc:oracle:thin:@195.233.199.13:33000:TIBTST1'
		dbUserName = 'CICD_OWN_DB01'
		dbPassword = 'TIL_CICD_DB'
		dbDriver = 'oracle.jdbc.driver.OracleDriver'

    }

    stages {
		stage('Preparation') {
			steps {
			    deleteDir()
				//Checkout Environment Configurations
				git credentialsId: 'GITHUBKEY', poll: false, url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Production_Configuration.git'
				
				echo "Gateway Type selected is:${GatewayType}"
				echo "Release number selected is: ${params.ReleaseNumber}"
				script{
				    	if (CRQ.indexOf(' ') != -1){
						         currentBuild.result = 'ABORTED'
                                 error('CR Number / IRIS Number should not contain spaces in between')
						       }
					file = "${WORKSPACE}/Gateway_Configuration/${env.GatewayType}/${env.GatewayEnvironment}/Instances.txt"		   
				    date_now = new Date().format("YYYYMMddHHmmss")
					displayName = "${params.ReleaseNumber}_${params.CRQ}"
					currentBuild.displayName = "${displayName}"
					
					//println "Debug: ${env.GatewayEnvironment}"
					
					if( "${env.GatewayType}" == "EGW" || "${env.GatewayType}" == "IGW01" ) {
						internalApache = "true"
						externalApache = "true"
					}else if( "${env.GatewayType}" == "GGW01" || "${env.GatewayType}" == "IGW02" ) {
						internalApache = "false"
						externalApache = "true"
					}else  {
						internalApache = "false"
						externalApache = "false"
					}
					println "${externalApache}"
					
					// Load all functions files from GIT. point to exact source file
					load_groovy_files()
					
					//Stash the important values so that these can be retrieved for stage restart.
					sh "mkdir -p DIR_STASH"
					sh "echo date:${date_now} >DIR_STASH/propfile"
					sh "echo displayName:${displayName} >>DIR_STASH/propfile"
					stash includes: 'DIR_STASH/propfile', name: 'stashProperties'
					
					// Gateway Deployment Dynamic Stages
					def Instance = new File("${file}").readLines()
					
					for (inst in Instance) {
					    //println "${inst}"
						Deploy_Stage(inst)   // Dynamic Deploy Stage  
					}
					
				}
				echo "date:${date_now}"

						
			}			
		}

	

	
		stage("Gateway Restart Approval") {
			steps {
				script {
					input 'Proceed with gateway restarts ?'
						 
					// Gateway Restart Dynamic Stages
					def Instance = new File("${file}").readLines()
					for (inst in Instance) {
						//println "${inst}"
						Restart_Stage(inst)   // Dynamic RESTART Stage  
					}	 
				}
			}
		}
	
		
		 stage("Gateways Exceptional Scenario") {		 
			steps { 
				script {
					
					    // stagingSkipApprovers = get_approvers_list('Staging_Admin')
							stagingSkipApprovers = get_approvers_list('Staging')
				     	    def SKIP_INPUT = input(
                              message: 'Choose No to continue with RB and RF2 ?',
                               parameters: [
                                 [$class: 'ChoiceParameterDefinition',
									choices: ['No','yes'].join('\n'),
									name: 'input',
									description: 'Choose Yes or No']
									])
							if (SKIP_INPUT == "Yes"){
							    def Approve_Exception = input(
                                  message: 'Approve skipping RB and RF2 for this deployment?',
                                  parameters: [
                                   [$class: 'ChoiceParameterDefinition',
										choices: ['Approve','Reject'].join('\n'),
										name: 'input',
										description: 'Choose Approve or Reject']
										])
										
								if (Approve_Exception == "Approve"){
								   Exceptional_Scenario_Approval = true
								   Exceptional_Scenario = true
                                }								
                             }							
				
						echo "Exceptional Scenario Approval ${Exceptional_Scenario_Approval}"	
                        echo "Exceptional Scenario ${Exceptional_Scenario}"						
					}
			}
		}		

	
		stage("Gateways Rollback Approval") {
		    when { 
			      allOf{
				     not { 
					    expression { return Exceptional_Scenario }
                        } 
				     not { 
					    expression { return Exceptional_Scenario_Approval }
                        } 					 
					 }
				}
			steps {
				script {
					  	 input 'Proceed with gateway rollbacks ?'
						 
						 def Instance = new File("${file}").readLines()
					//def loop = Instance.split("\n")
					//println "${loop}"
					for (inst in Instance) {
					    //println "${inst}"
						RollBack_Changes(inst)   // Dynamic Deploy Stage  
					}
				}
			}
		}
		
		stage("Gateway Rollback Restart Approval") {
		    when { 
			      allOf{
				     not { 
					    expression { return Exceptional_Scenario }
                        } 
				     not { 
					    expression { return Exceptional_Scenario_Approval }
                        } 					 
					 }
				}
			steps {
				script {
					input 'Proceed with gateway restarts ?'
					// Gateway Restart Dynamic Stages
					def Instance = new File("${file}").readLines()
					for (inst in Instance) {
						//println "${inst}"
						Restart_Stage_RollBack(inst)   // Dynamic RESTART Stage  
					}
					
					}
			}
		}
		
		
		stage("Gateways Rollforward Approval") {
		    when { 
			      allOf{
				     not { 
					    expression { return Exceptional_Scenario }
                        } 
				     not { 
					    expression { return Exceptional_Scenario_Approval }
                        } 					 
					 }
				}		
			steps {
				script {
					input 'Proceed with gateway rollforward ?'
					
					// Gateway Rollforward Dynamic Stages
					def Instance = new File("${file}").readLines()
					for (inst in Instance) {
						//println "${inst}"
						Rollforward_Stage(inst)   // Dynamic RESTART Stage  
					}
				}
			}
		}

		stage("Gateway Rollforward Restart Approval") {
		    when { 
			      allOf{
				     not { 
					    expression { return Exceptional_Scenario }
                        } 
				     not { 
					    expression { return Exceptional_Scenario_Approval }
                        } 					 
					 }
				}
			steps {
				script {
					input 'Proceed with gateway restarts ?'
					// Gateway Restart Dynamic Stages
					def Instance = new File("${file}").readLines()
					for (inst in Instance) {
						//println "${inst}"
						Restart_Stage_Rollforward(inst)   // Dynamic RESTART Stage  
					}
				}
			}
		}
	

		stage("Signoff Staging") {
			steps{
				script{
				        echo "DEBUG: ArtefactVersion to deploy: ${params.GatewayVersion}"
                        //Promote Artifact to Production Repository.
				        build job: 'Gateway/GatewayJobs/Gateway_Artefact_Promotion', parameters: [string(name: 'GroupId', value: "${env.GROUPID}"), string(name: 'ArtifactId', value: "${env.GatewayType}"), string(name: 'VersionNo', value: "${params.GatewayVersion}"), string(name: 'SourceRepo', value: "${env.STAGING_REPO}"), string(name: 'DestinationRepo', value: "${env.PROD_REPO}")]					
				
						
						//[CICD-1530]: Push all the deployment details to Release notes DB.
						
						
					
						user = currentBuild.rawBuild.causes[0].userId
				
						def release_ins_query = """Insert into CICD_RELEASE_SUMMARY (RELEASE_NO,PROJECT_NAME,JIRA_NO,CHANGE_DESCRIPTION,ENGINE_NAME,OPERATION,EAR_VERSION,EMS_VERSION,SQL_VERSION,COMPONENT_TYPE,STATUS,MASTER_GV,PROCESS_GV,ENGINE_TEMPLATE,APPEND_PREPEND,KNOWN_ERROR_INCLUSION,POST_MANUAL_CHANGES,PARTNER_DATA,GATEWAY_TOKEN,SPECIAL_INSTRUCTIONS,LINKTEST_RESULTS,CREATED_ON,GATEWAY_VERSION,GATEWAY_TYPE,CREATED_BY,FILE_CHANGES,APPROVAL,MODIFIED_ON,MODIFIED_BY,RESTART_ENGINES) values ('${params.ReleaseNumber}','','${params.CRQ}','','','','','','','GATEWAY','Active','','','','','','','','','','PASSED',sysdate,'${params.GatewayVersion}','${env.GatewayType}','${user}','','','','','')"""
	
						println("DEBUG: release notes Insert query is: " + release_ins_query)

						DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${env.dbUserName}", dbPassword: "${env.dbPassword}", dbDriver: "${env.dbDriver}", insertQuery: release_ins_query
					
						//[CICD-1530] Insert Deployment metadata to deploment history database DB.
 					
						def insert_query = """Insert into CICD_DEPLOYMENT_HISTORY ("Release","DateTime","CRQ","ComponentType","Environment","EngineName","BwVersion","EmsVersion","SqlVersion","GatewayVersion","BwDeploymentType","DeploymentStatus","DeploymentTime","XmlFiles","JarFiles","EmailFiles","RF1Status","RBStatus","RF2Status","DVTStatus","BWConfigTag","ChangeDescription","User","FailureReason","updatedTimestamp") values ('${params.ReleaseNumber}',sysdate,'${params.CRQ}','GATEWAY','${env.GatewayEnvironment}','${env.GatewayType}','','','','${params.GatewayVersion}','','Active','','','','','','','','','','','${user}','PASSED',sysdate)"""
		
						println("DEBUG: Insert query is: " + insert_query)
		
						DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${env.dbUserName}", dbPassword: "${env.dbPassword}", dbDriver: "${env.dbDriver}", insertQuery: insert_query
				
				
				
				}				
			}
		}

    }
}		
