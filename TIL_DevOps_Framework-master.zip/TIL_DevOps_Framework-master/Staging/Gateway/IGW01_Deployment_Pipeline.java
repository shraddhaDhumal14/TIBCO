//import this package as part of the fix
import groovy.time.*

//[CICD-1530] Insert Deployment metadata to release notes DB.
import groovy.json.JsonOutput
import groovy.sql.*
import java.sql.Driver

def ops_mailRecipients = "DL-TSSC-AO2-UK-Integration_TIL-RIG_L2@vodafone.com, devops-vfuk-integration@vodafone.com, ankit.bhartiya1@vodafone.com, veera.venkatalsknuni@vodafone.com"

def get_body_build_summary(deployParams){

    def date_format_report = new Date().format("dd/MM/yyy HH:mm")	
	def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
		.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		</style>
		<table class="tg" style="undefined;table-layout: fixed; width: 900px">
		<colgroup>
		<col style="width: 100px">
		<col style="width: 350px">
		<col style="width: 100px">
		<col style="width: 350px">
		</colgroup>
		  <tr>
			<td><table width="50%"><tr><td><img width="150" src="https://www.vodafone.co.uk/cs/groups/public/documents/webcontent/1287x929_vodafone_logo.jpg" alt="ITEAMS" style="text-align: right; width: 207px; border: 0; text-decoration:none; vertical-align: baseline;"></td></tr></table>
          <div style="display:none">
			</div>
			</td>
			<th class="tg-amwm" colspan="3">CCS Integration Staging Deployment Summary ${params.ReleaseNumber}</th>
		  </tr>
		  <tr>
			<td class="tg-1wig">Submitted By</td>
			<td class="tg-0lax">${currentBuild.getRawBuild().getCauses()[0].getUserId()}</td>
			<td class="tg-1wig">Date</td>
			<td class="tg-0lax">${date_format_report}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">RELEASE NUMBER & VERSION </td>
			<td class="tg-0lax">${params.ReleaseNumber} & ${params.GatewayVersion}</td>
			<td class="tg-1wig">Gateway</td>
			<td class="tg-0lax">${env.GatewayType}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">Deployment Type</td>
			<td class="tg-0lax">${deployParams.DeploymentType}</td>
			<td class="tg-1wig">Status</td>
			<td class="tg-0lax">${deployParams.Status}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">6313 PID before restart</td>
			<td class="tg-0lax">${deployParams.beforeRestart}</td>
			<td class="tg-1wig">6313 PID after restart</td>
			<td class="tg-0lax">${deployParams.afterRestart}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">Before ExternalApache Restart PID</td>
			<td class="tg-0lax">${deployParams.beforeExternalApacheRestart}</td>
			<td class="tg-1wig">After ExternalApache Restart PID</td>
			<td class="tg-0lax">${deployParams.afterExternalApacheRestart}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">Before InternalApache Restart PID</td>
			<td class="tg-0lax">${deployParams.beforeInternalApacheRestart}</td>
			<td class="tg-1wig">After InernalApache Restart PID</td>
			<td class="tg-0lax">${deployParams.afterInternalApacheRestart}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">LOG_URL</td>
			<td class="tg-0lax" colspan="3">${BUILD_URL}/console</td>
		  </tr>		  
		</table>
		<br><br><br>
	"""
	emailBody = body_build_summary
	
	writeFile file: "${WORKSPACE}/Reports/${deployParams.DeploymentType}_Report.html", text: emailBody 
	writeFile file: "/opt/tibco/.jenkins/userContent/Gateway/${env.GatewayType}/${params.ReleaseNumber}/${params.GatewayVersion}/${deployParams.DeploymentType}_Report.html", text: emailBody
	return body_build_summary
}

// Funcation to Get jenkins users from the given role
def get_approvers_list(String str){
	outlist = sh (script: """cat /opt/tibco/.jenkins/config.xml | sed -n \'/role name=\"${str}\"/,\$p\' | sed \'/role>/q\' | grep "sid" | cut -d \'>\' -f 2 | cut -d \'<\' -f 1 | paste -s -d, -""",
			returnStdout: true).trim()
	return """${outlist}"""
}



def deploy_artefact(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
			
			// Copy host configutaion files to Ansible deployment script location
			sh "cp -r ./Gateway_Configuration/${deployParams.GatewayType}/${deployParams.gatewayEnvironment}/* ./${deployParams.Host}/Gateway_Deployment/"
			// copy host variables from configuration to ansible host vars folder
			sh "cp ./${deployParams.Host}/Gateway_Deployment/${deployParams.GatewayType}_${deployParams.Host} ./${deployParams.Host}/Gateway_Deployment/host_vars/"
			// Generate host vars file for external apache
			sh "cp ./${deployParams.Host}/Gateway_Deployment/${deployParams.GatewayType}_${deployParams.Host} ./${deployParams.Host}/Gateway_Deployment/host_vars/${deployParams.GatewayType}_${deployParams.Host}_ExternalApache"
			// Generate host vars file for internal apache
			sh "cp ./${deployParams.Host}/Gateway_Deployment/${deployParams.GatewayType}_${deployParams.Host} ./${deployParams.Host}/Gateway_Deployment/host_vars/${deployParams.GatewayType}_${deployParams.Host}_InternalApache"
            // rename tokens file to instance specific
			sh "cp ./${deployParams.Host}/Gateway_Deployment/Tokens/${deployParams.GatewayType}_${deployParams.gatewayEnvironment} ./${deployParams.Host}/Gateway_Deployment/Tokens/${deployParams.GatewayType}_${deployParams.Host}"
            
			//sh "cp ./${deployParams.Host}/Gateway_Deployment/${deployParams.GatewayType}_${deployParams.Host}_* ./${deployParams.Host}/Gateway_Deployment/host_vars/"
			echo "DEBUG: nexus_ArtefactVersion is: ${deployParams.nexus_ArtefactVersion}"
		
			//Run ansible playbook to deploy artefacts into environment
			 ansiColor('xterm') {
    	    ansiblePlaybook(playbook: "./${deployParams.Host}/Gateway_Deployment/Ops_Deploy.yml", colorized: true, extras:'-v', extraVars: [host: "${deployParams.GatewayType}_${deployParams.Host}", repo_group_id: "${deployParams.nexus_group_id}", repo_artifact_id: "${deployParams.nexus_artifact_id}", repo_user: "${deployParams.nexus_user}", repo_pw: "${deployParams.nexus_passwd}", repo_repo_id: "${deployParams.nexus_repo_id}", repo_version: "${deployParams.nexus_ArtefactVersion}", repo_url: "${deployParams.nexus_url}", datetime: "${deployParams.datetime}", crq_no: "${deployParams.crq_no}", gatewayRestart: "${deployParams.gatewayRestart}", deployType: "${deployParams.deployType}"])
	
			}
    }
}

def gateway_restart(deployParams) {
	script{
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
			//Run ansible playbook to restart gateway instances
			 ansiColor('xterm') {
    	    //ansiblePlaybook(playbook: "./${deployParams.Host}/Gateway_Deployment/Ops_Restart.yml", colorized: true, extras:'-v', extraVars: [host: "${deployParams.GatewayType}_${deployParams.Host}", repo_group_id: "${deployParams.nexus_group_id}", repo_artifact_id: "${deployParams.nexus_artifact_id}", repo_user: "${deployParams.nexus_user}", repo_pw: "${deployParams.nexus_passwd}", repo_repo_id: "${deployParams.nexus_repo_id}", repo_version: "${deployParams.nexus_ArtefactVersion}", repo_url: "${deployParams.nexus_url}", datetime: "${deployParams.datetime}", crq_no: "${deployParams.crq_no}", externalApache: "${deployParams.externalApache}", internalApache: "${deployParams.internalApache}", gatewayRestart: "${deployParams.gatewayRestart}"])
	        ansiblePlaybook(playbook: "./${deployParams.Host}/Gateway_Deployment/Ops_Restart.yml", colorized: true, extras:'-v', extraVars: [host: "${deployParams.GatewayType}_${deployParams.Host}", externalApache: "${deployParams.externalApache}", internalApache: "${deployParams.internalApache}", gatewayRestart: "${deployParams.gatewayRestart}"])

		  }
    }
}

def rollback_artefact(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{
			ansiColor('xterm') {		
			 //Run ansible playbook to rollback deployed changes
			 ansiblePlaybook(playbook: "./${deployParams.Host}/Gateway_Deployment/rollback.yml", colorized: true, extras:'-v', extraVars: [host: "${deployParams.GatewayType}_${deployParams.Host}", datetime: "${deployParams.datetime}", crq_no: "${deployParams.crq_no}", externalApache: "${deployParams.externalApache}", internalApache: "${deployParams.internalApache}"])
	         }
	}
}

def gateway_status(deployParams) {
	script{
			//Run ansible playbook to get gateway status
			 ansiColor('xterm') {
    	    ansiblePlaybook(playbook: "./${deployParams.Host}/Gateway_Deployment/gatewayStatus.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.GatewayType}_${deployParams.Host}"])

		  }
    }
}

def gateway_pid(deployParams) {
	script{
			//Run ansible playbook to get gateway status
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
			 ansiColor('xterm') {
    	    ansiblePlaybook(playbook: "./${deployParams.Host}/Gateway_Deployment/gatewayPID.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.GatewayType}_${deployParams.Host}"])

		  }
    }
}

def gateway_not_running(deployParams) {
	script{
	        def USER_INPUT = input(
                              message: 'IGW01 Gateway Instance is not running. Select restart/skip to proceed with gateway restart ?',
                               parameters: [
                                 [$class: 'ChoiceParameterDefinition',
									choices: ['Restart','Skip'].join('\n'),
									name: 'input',
									description: 'Choose Restart or Skip']
									])
					      
						  if (USER_INPUT == "Restart")
					           {
						       gateway_restart Host:"${deployParams.Host}", GatewayType:"${deployParams.GatewayType}", internalApache:"${deployParams.internalApache}", externalApache:"${deployParams.externalApache}", gatewayRestart:"${deployParams.gatewayRestart}", gatewayEnvironment:"${deployParams.gatewayEnvironment}"
			
                                }
	}
}

def load_groovy_files() {
	
	// This function is to checkout all the required GIT repositories.
	checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'JENKINS_FILE']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_DevOps_Framework.git']]])
	
	
	// Insert Deployment metadata to release notes DB.
	DB_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/dbFunctions.groovy"	
}


// Global Parameters to use in the stages.
//date_format_report = new Date().format("dd/MM/yyy HH:mm")
//date_now = new Date().format("YYYYMMddHHmmss")
date_now = " "
displayName = " "
emailBody = " "
before_restart_6313_pid = ""
after_restart_6313_pid = ""
before_restart_6680_pid = ""
after_restart_6680_pid = ""
Exceptional_Scenario_Approval = false
Exceptional_Scenario = false
skipOptions = 'Restart\nSkip'
stagingSkipApprovers = ""

// CICD-1520 Capturing apache PID 
def before_externalApache_restart_pid = ""
def before_InternalApache_restart_pid = ""
def after_externalApache_restart_pid = ""
def after_InternalApache_restart_pid = ""

// [CICD-1530]: Push all the deployment details to Release notes DB. 
user = ""

pipeline {
    agent any
	options {
        preserveStashes(buildCount: 49)
    }

    environment {
		GROUPID = "GATEWAY"
		GatewayType = "IGW01"
		GatewayEnvironment = "Staging"
		REPO_URL = "http://195.233.197.150:8081"
		STAGING_REPO = "STAGING_REPO"
		PROD_REPO = "PROD_REPO"
		NEXUS_USER = "admin"
		NEXUS_PASSWD = "admin123"
		
		//[CICD-1530] Insert Deployment metadata to release notes DB.
		dbURL = 'jdbc:oracle:thin:@195.233.199.13:33000:TIBTST1'
		dbUserName = 'CICD_OWN_DB01'
		dbPassword = 'TIL_CICD_DB'
		dbDriver = 'oracle.jdbc.driver.OracleDriver'

    }

    stages {
		stage('Preparation') {
			steps {
			    deleteDir()
				//Checkout Environment Configurations
				git credentialsId: 'GITHUBKEY', poll: false, url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Production_Configuration.git'
				
				echo "Gateway Type selected is:${GatewayType}"
				echo "Release number selected is: ${params.ReleaseNumber}"
				script{
				    if (CRQ.indexOf(' ') != -1){
						  currentBuild.result = 'ABORTED'
                          error('CR Number / IRIS Number should not contain spaces in between')
						 }
					if (CRQ == ""){
						           currentBuild.result = 'ABORTED'
                                   error('CR Number Number should be specified for the Deployment')
						        }	
					if (ReleaseNumber == ""){
					    currentBuild.result = 'ABORTED'
                        error('Release Number is mandatory for Staging Deployment')
						}
				    if (GatewayVersion == ""){
					    currentBuild.result = 'ABORTED'
                        error('GatewayVersion is mandatory for Staging Deployment')
					}
					if (CRQ.indexOf(' ') != -1){
					    currentBuild.result = 'ABORTED'
                         error('CR Number / IRIS Number should not contain spaces in between')
					    }
					
				    date_now = new Date().format("YYYYMMddHHmmss")
					displayName = "${params.ReleaseNumber}_${params.CRQ}"
					currentBuild.displayName = "${displayName}"
					//Stash the important values so that these can be retrieved for stage restart.
					sh "mkdir -p DIR_STASH"
					sh "echo date:${date_now} >DIR_STASH/propfile"
					sh "echo displayName:${displayName} >>DIR_STASH/propfile"
					stash includes: 'DIR_STASH/propfile', name: 'stashProperties'
				}
				echo "date:${date_now}"

						
			}			
		}

	stage("IGW01 6313 Deployment") {
			steps {
				// This stage is for deployment.
				script {
				 //Checkout Environment Configurations
				git credentialsId: 'GITHUBKEY', poll: false, url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Production_Configuration.git'
				
				    // If the following values are blank, it means we are starting from stage and need to retrive the values from stash.
					unstash "stashProperties"
					if (date_now == " ") {
						date_now = sh(script:"cat ./DIR_STASH/propfile | grep -e date | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						echo "Date after stage restart is:${date_now}"
					}
					if (displayName == " ") {
						displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						currentBuild.displayName = "${displayName}_restart"
						echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
					}
					echo "Date without stage restart is:${date_now}"
					// Call deploy function by providing LinkTest Details.
					deploy_artefact Host:'Staging_6313', nexus_group_id:"${env.GROUPID}", nexus_artifact_id:"${env.GatewayType}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.STAGING_REPO}", nexus_ArtefactVersion:"${params.GatewayVersion}", GatewayType:"${env.GatewayType}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CRQ}", datetime:"${date_now}", gatewayRestart:false, gatewayEnvironment:"${env.GatewayEnvironment}", deployType:"RF1"
				}
			}
		}
		
		
	
		stage("Gateway Restart Approval") {
			steps {
				script {
					  	 input 'Proceed with gateway restarts ?'
					}
			}
		}
	
		stage("Restart IGW01 6313 Gateway") {
			steps {
				script {
					// If the following values are blank, it means we are starting from stage and need to retrive the values from stash.
					unstash "stashProperties"
					if (date_now == " ") {
						date_now = sh(script:"cat ./DIR_STASH/propfile | grep -e date | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						echo "Date after stage restart is:${date_now}"
					}
					if (displayName == " ") {
						displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						currentBuild.displayName = "${displayName}_restart"
						echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
					}
					// get Gateway PID by calling ansible gateway_pid function
                    gateway_pid Host:'Staging_6313', GatewayType:"${env.GatewayType}"
					
					before_restart_6313_pid = readFile 'Staging_6313/Gateway_Deployment/IGW01_Staging_6313_pid.txt'
					
					echo "Gateway PID is:${before_restart_6313_pid}"
					
					// Check status of gateway and ask for user input if gateway in stopped state
					// get Gateway status by calling ansible gateway_status function
                    gateway_status Host:'Staging_6313', GatewayType:"${env.GatewayType}"
					
					def gatewayStatus = readFile 'Staging_6313/Gateway_Deployment/IGW01_Staging_6313_status.txt'
					
					echo "Gateway Status is:${gatewayStatus}"
					
					if (gatewayStatus == "0"){
					 
					     echo "gateway is running hence restarting"
					     gateway_restart Host:'Staging_6313', GatewayType:"${env.GatewayType}", internalApache:true, externalApache:true, gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
						
					  }
					 else {
						       gateway_not_running Host:'Staging_6313', GatewayType:"${env.GatewayType}", internalApache:true, externalApache:true, gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
					   
                         }
					// get Gateway PID by calling ansible gateway_pid function
                    gateway_pid Host:'Staging_6313', GatewayType:"${env.GatewayType}"
					
					after_restart_6313_pid = readFile 'Staging_6313/Gateway_Deployment/IGW01_Staging_6313_pid.txt'
					
					echo "Gateway PID is:${after_restart_6313_pid}"	
					
					// CICD-1520 Capturing apache PID
					before_externalApache_restart_pid = readFile './Staging_6313/Gateway_Deployment/Before_External.txt'
					echo "Before_ExternalApache_Restart : ${before_externalApache_restart_pid}"
					
					before_InternalApache_restart_pid = readFile './Staging_6313/Gateway_Deployment/Before_Internal.txt'
					echo "Before_InternalApache_Restart : ${before_InternalApache_restart_pid}"
					
					after_externalApache_restart_pid = readFile './Staging_6313/Gateway_Deployment/After_External.txt'
					echo "After_ExternalApache_Restart : ${after_externalApache_restart_pid}"
					
					after_InternalApache_restart_pid = readFile './Staging_6313/Gateway_Deployment/After_Internal.txt'
					echo "After_InternalApache_Restart : ${after_InternalApache_restart_pid}"

					// Notify team with status email
					emailext mimeType: 'text/html',
						 subject: "[Jenkins]:${currentBuild.fullDisplayName}:Staging Deployment",
						 from:"CICD_GatewayDeploymentStatus@vodafone.com",
						 to: "${ops_mailRecipients}",
                         body: 	"${get_body_build_summary(DeploymentType:'RF1', Status:'Success', beforeRestart:before_restart_6313_pid, afterRestart:after_restart_6313_pid, beforeExternalApacheRestart:before_externalApache_restart_pid, afterExternalApacheRestart:after_externalApache_restart_pid, beforeInternalApacheRestart:before_InternalApache_restart_pid, afterInternalApacheRestart:after_InternalApache_restart_pid)}"
		 


				}
			}
		}
	
	    
		 stage("Gateways Exceptional Scenario") {		 
			steps { 
				script {
				         stagingSkipApprovers = get_approvers_list('Staging_Admin')
				     	    def SKIP_INPUT = input(
                              message: 'Choose No to continue with RB and RF2 ?',
                               parameters: [
                                 [$class: 'ChoiceParameterDefinition',
									choices: ['No','Yes'].join('\n'),
									name: 'input',
									description: 'Choose No or Yes']
									])
							if (SKIP_INPUT == "Yes"){
							    def Approve_Exception = input(
                                  message: 'Approve skipping RB and RF2 for this deployment?',
                                  parameters: [
                                   [$class: 'ChoiceParameterDefinition',
										choices: ['Approve','Reject'].join('\n'),
										name: 'input',
										description: 'Choose Approve or Reject']
										])
										
								if (Approve_Exception == "Approve"){
								   Exceptional_Scenario_Approval = true
								   Exceptional_Scenario = true
                                }								
                             }							
				
						echo "Exceptional Scenario Approval ${Exceptional_Scenario_Approval}"	
                        echo "Exceptional Scenario ${Exceptional_Scenario}"						
					}
			}
		}		
	
		stage("Gateways Rollback Approval") {
		    when { 
			      allOf{
				     not { 
					    expression { return Exceptional_Scenario }
                        } 
				     not { 
					    expression { return Exceptional_Scenario_Approval }
                        } 					 
					 }
				}		
			steps {
				script {
					  	 input 'Proceed with gateway rollbacks ?'
					}
			}
		}
		stage("RollBack IGW01 6313 changes") {
		    when { 
			      allOf{
				     not { 
					    expression { return Exceptional_Scenario }
                        } 
				     not { 
					    expression { return Exceptional_Scenario_Approval }
                        } 					 
					 }
				}		
			steps {
				script {
					
					// If the following values are blank, it means we are starting from stage and need to retrive the values from stash.
					unstash "stashProperties"
					if (date_now == " ") {
						date_now = sh(script:"cat ./DIR_STASH/propfile | grep -e date | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						echo "Date after stage restart is:${date_now}"
					}
					if (displayName == " ") {
						displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						currentBuild.displayName = "${displayName}_restart"
						echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
					}
					// Call rollback function by providing LinkTest Details.
					rollback_artefact Host:'Staging_6313', GatewayType:"${env.GatewayType}", crq_no:"${params.CRQ}", datetime:"${date_now}", internalApache:true, externalApache:true, gatewayEnvironment:"${env.GatewayEnvironment}"
			   }
			}
		}
		
		
		stage("Gateway Rollback Restart Approval") {
		    when { 
			      allOf{
				     not { 
					    expression { return Exceptional_Scenario }
                        } 
				     not { 
					    expression { return Exceptional_Scenario_Approval }
                        } 					 
					 }
				}		
			steps {
				script {
					  	 input 'Proceed with gateway restarts ?'
					}
			}
		}
		
		stage("Rollback Restart IGW01 6313 Gateway") {
		    when { 
			      allOf{
				     not { 
					    expression { return Exceptional_Scenario }
                        } 
				     not { 
					    expression { return Exceptional_Scenario_Approval }
                        } 					 
					 }
				}		
			steps {
				script {
					// If the following values are blank, it means we are starting from stage and need to retrive the values from stash.
					unstash "stashProperties"
					if (date_now == " ") {
						date_now = sh(script:"cat ./DIR_STASH/propfile | grep -e date | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						echo "Date after stage restart is:${date_now}"
					}
					if (displayName == " ") {
						displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						currentBuild.displayName = "${displayName}_restart"
						echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
					}
					// get Gateway PID by calling ansible gateway_pid function
                    gateway_pid Host:'Staging_6313', GatewayType:"${env.GatewayType}"
					
					before_restart_6313_pid = readFile 'Staging_6313/Gateway_Deployment/IGW01_Staging_6313_pid.txt'
					
					echo "Gateway PID is:${before_restart_6313_pid}"
					
					
					// Check status of gateway and ask for user input if gateway in stopped state
					// get Gateway status by calling ansible gateway_status function
                    gateway_status Host:'Staging_6313', GatewayType:"${env.GatewayType}"
					
					def gatewayStatus = readFile 'Staging_6313/Gateway_Deployment/IGW01_Staging_6313_status.txt'
					
					echo "Gateway Status is:${gatewayStatus}"
					
					if (gatewayStatus == "0"){
					 
					     echo "gateway is running hence restarting"
					     gateway_restart Host:'Staging_6313', GatewayType:"${env.GatewayType}", internalApache:true, externalApache:true, gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
						
					  }
					 else {
                        echo "gateway is not running"
						gateway_not_running Host:'Staging_6313', GatewayType:"${env.GatewayType}", internalApache:true, externalApache:true, gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
						 	     
                         }					
					// get Gateway PID by calling ansible gateway_pid function
                    gateway_pid Host:'Staging_6313', GatewayType:"${env.GatewayType}"
					
					after_restart_6313_pid = readFile 'Staging_6313/Gateway_Deployment/IGW01_Staging_6313_pid.txt'
					
					echo "Gateway PID is:${after_restart_6313_pid}"	
					
					// CICD-1520 Capturing apache PID
					before_externalApache_restart_pid = readFile './Staging_6313/Gateway_Deployment/Before_External.txt'
					echo "Before_ExternalApache_Restart : ${before_externalApache_restart_pid}"
					
					before_InternalApache_restart_pid = readFile './Staging_6313/Gateway_Deployment/Before_Internal.txt'
					echo "Before_InternalApache_Restart : ${before_InternalApache_restart_pid}"
					
					after_externalApache_restart_pid = readFile './Staging_6313/Gateway_Deployment/After_External.txt'
					echo "After_ExternalApache_Restart : ${after_externalApache_restart_pid}"
					
					after_InternalApache_restart_pid = readFile './Staging_6313/Gateway_Deployment/After_Internal.txt'
					echo "After_InternalApache_Restart : ${after_InternalApache_restart_pid}"
					
					// Notify team with status email
					emailext mimeType: 'text/html',
						 subject: "[Jenkins]:${currentBuild.fullDisplayName}:Staging Deployment",
						 from:"CICD_GatewayDeploymentStatus@vodafone.com",
						 to: "${ops_mailRecipients}",
                         body: 	"${get_body_build_summary(DeploymentType:'RB', Status:'Success', beforeRestart:before_restart_6313_pid, afterRestart:after_restart_6313_pid, beforeExternalApacheRestart:before_externalApache_restart_pid, afterExternalApacheRestart:after_externalApache_restart_pid, beforeInternalApacheRestart:before_InternalApache_restart_pid, afterInternalApacheRestart:after_InternalApache_restart_pid)}"
						
				
			
				}
			}
		}
	
	    
		
		stage("Gateways Rollforward Approval") {
		    when { 
			      allOf{
				     not { 
					    expression { return Exceptional_Scenario }
                        } 
				     not { 
					    expression { return Exceptional_Scenario_Approval }
                        } 					 
					 }
				}		
			steps {
				script {
					  	 input 'Proceed with gateway rollforward ?'
					}
			}
		}

	stage("Rollforward IGW01 6313") {
		    when { 
			      allOf{
				     not { 
					    expression { return Exceptional_Scenario }
                        } 
				     not { 
					    expression { return Exceptional_Scenario_Approval }
                        } 					 
					 }
				}	
			steps {
				// This stage is for deployment.
				script {
				 
				    // If the following values are blank, it means we are starting from stage and need to retrive the values from stash.
					unstash "stashProperties"
					if (date_now == " ") {
						date_now = sh(script:"cat ./DIR_STASH/propfile | grep -e date | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						echo "Date after stage restart is:${date_now}"
					}
					if (displayName == " ") {
						displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						currentBuild.displayName = "${displayName}_restart"
						echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
					}
					echo "Date without stage restart is:${date_now}"
					// Call deploy function by providing LinkTest Details.
					deploy_artefact Host:'Staging_6313', nexus_group_id:"${env.GROUPID}", nexus_artifact_id:"${env.GatewayType}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.STAGING_REPO}", nexus_ArtefactVersion:"${params.GatewayVersion}", GatewayType:"${env.GatewayType}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CRQ}", datetime:"${date_now}", gatewayRestart:false, gatewayEnvironment:"${env.GatewayEnvironment}", deployType:"RF2"
				}
			}
		}
		
		

		stage("Gateway Rollforward Restart Approval") {
		    when { 
			      allOf{
				     not { 
					    expression { return Exceptional_Scenario }
                        } 
				     not { 
					    expression { return Exceptional_Scenario_Approval }
                        } 					 
					 }
				}		
			steps {
				script {
					  	 input 'Proceed with gateway restarts ?'
					}
			}
		}
	
		stage("Rollforward Restart IGW01 6313 Gateway") {
		    when { 
			      allOf{
				     not { 
					    expression { return Exceptional_Scenario }
                        } 
				     not { 
					    expression { return Exceptional_Scenario_Approval }
                        } 					 
					 }
				}		
			steps {
				script {
					// If the following values are blank, it means we are starting from stage and need to retrive the values from stash.
					unstash "stashProperties"
					if (date_now == " ") {
						date_now = sh(script:"cat ./DIR_STASH/propfile | grep -e date | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						echo "Date after stage restart is:${date_now}"
					}
					if (displayName == " ") {
						displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						currentBuild.displayName = "${displayName}_restart"
						echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
					}
					// get Gateway PID by calling ansible gateway_pid function
                    gateway_pid Host:'Staging_6313', GatewayType:"${env.GatewayType}"
					
					before_restart_6313_pid = readFile 'Staging_6313/Gateway_Deployment/IGW01_Staging_6313_pid.txt'
					
					echo "Gateway PID is:${before_restart_6313_pid}"
					
					
					// Check status of gateway and ask for user input if gateway in stopped state
					// get Gateway status by calling ansible gateway_status function
                    gateway_status Host:'Staging_6313', GatewayType:"${env.GatewayType}"
					
					def gatewayStatus = readFile 'Staging_6313/Gateway_Deployment/IGW01_Staging_6313_status.txt'
					
					echo "Gateway Status is:${gatewayStatus}"
					
					if (gatewayStatus == "0"){
					 
					     echo "gateway is running hence restarting"
					     gateway_restart Host:'Staging_6313', GatewayType:"${env.GatewayType}", internalApache:true, externalApache:true, gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
						
					  }
					 else {
                        echo "gateway is not running"
						gateway_not_running Host:'Staging_6313', GatewayType:"${env.GatewayType}", internalApache:true, externalApache:true, gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"

					   }
					// get Gateway PID by calling ansible gateway_pid function
                    gateway_pid Host:'Staging_6313', GatewayType:"${env.GatewayType}"
					
					after_restart_6313_pid = readFile 'Staging_6313/Gateway_Deployment/IGW01_Staging_6313_pid.txt'
					
					echo "Gateway PID is:${after_restart_6313_pid}"	
					
					
					// CICD-1520 Capturing apache PID
					before_externalApache_restart_pid = readFile './Staging_6313/Gateway_Deployment/Before_External.txt'
					echo "Before_ExternalApache_Restart : ${before_externalApache_restart_pid}"
					
					before_InternalApache_restart_pid = readFile './Staging_6313/Gateway_Deployment/Before_Internal.txt'
					echo "Before_InternalApache_Restart : ${before_InternalApache_restart_pid}"
					
					after_externalApache_restart_pid = readFile './Staging_6313/Gateway_Deployment/After_External.txt'
					echo "After_ExternalApache_Restart : ${after_externalApache_restart_pid}"
					
					after_InternalApache_restart_pid = readFile './Staging_6313/Gateway_Deployment/After_Internal.txt'
					echo "After_InternalApache_Restart : ${after_InternalApache_restart_pid}"
					
                 // Notify team with status email
					emailext mimeType: 'text/html',
						 subject: "[Jenkins]:${currentBuild.fullDisplayName}:Staging Deployment",
						 from:"CICD_GatewayDeploymentStatus@vodafone.com",
						 to: "${ops_mailRecipients}",
                         body: 	"${get_body_build_summary(DeploymentType:'RF2', Status:'Success', beforeRestart:before_restart_6313_pid, afterRestart:after_restart_6313_pid, beforeExternalApacheRestart:before_externalApache_restart_pid, afterExternalApacheRestart:after_externalApache_restart_pid, beforeInternalApacheRestart:before_InternalApache_restart_pid, afterInternalApacheRestart:after_InternalApache_restart_pid)}"
					
			
				}
			}
		}
	
	    

		stage("Signoff Staging") {
			steps{
				script{
				        echo "DEBUG: ArtefactVersion to deploy: ${params.GatewayVersion}"
                        
				}				
			}
		}
				//ADO-753185 - Swindon auto trigger and db update
		stage('Swindon Auto Trigger') 
		{
                steps 
			{
				script 
				{
					unstash "stashProperties"
					if (date_now == " ") {
						date_now = sh(script:"cat ./DIR_STASH/propfile | grep -e date | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						echo "Date after stage restart is:${date_now}"
					}
					if (displayName == " ") {
						displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						currentBuild.displayName = "${displayName}_restart"
						echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
					}
                                       def Swindon_inp = input(message: 'Proceed with Swindon Deployment?',
                                        parameters: [
                                        [$class: 'ChoiceParameterDefinition',
                                        choices: ['Yes','No'].join('\n'),
                                        name: 'input',
                                        description: 'Choose Yes if Swindon Deployment required']])
					if(Swindon_inp == "Yes")
					{
					 	
			               build job: "TILSTG01/pipelines/Deployment_pipelines/Gateway_Test/Swindon", 
                                       parameters: [string(name: 'ReleaseNumber', value: "${params.ReleaseNumber}"), 
                                                    string(name: 'GatewayVersion', value:  "${params.GatewayVersion}"), 
                                        	    string(name: 'CRQ', value: "${params.CRQ}"), 
                                        	    string(name: 'Environment', value: "${env.GatewayEnvironment}"), 
                                        	    string(name: 'Gateway_Type', value: "${env.GatewayType}")], wait: false
					}						
				}
			}
		}
        
		stage("DB Update") {
			steps{
				script{
				        unstash "stashProperties"
                        if (date_now == " ") {
                            date_now = sh(script:"cat ./DIR_STASH/propfile | grep -e date | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
                            echo "Date after stage restart is:${date_now}"
                        }
                        if (displayName == " ") {
                            displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
                            currentBuild.displayName = "${displayName}_restart"
                            echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
                        }
                        def insert_query = ""
                        load_groovy_files()
                        
                        user = currentBuild.rawBuild.causes[0].userId
                        if(Exceptional_Scenario)
                        {
                            //[CICD-1530] Insert Deployment metadata to deploment history database DB.
                        
                            insert_query = """Insert into CICD_DEPLOYMENT_HISTORY ("Release","DateTime","CRQ","ComponentType","Environment","EngineName","BwVersion","EmsVersion","SqlVersion","GatewayVersion","BwDeploymentType","DeploymentStatus","DeploymentTime","XmlFiles","JarFiles","EmailFiles","RF1Status","RBStatus","RF2Status","DVTStatus","BWConfigTag","ChangeDescription","User","FailureReason","updatedTimestamp") values ('${params.ReleaseNumber}',sysdate,'${params.CRQ}','GATEWAY','${env.GatewayEnvironment}','${env.GatewayType}','','','','${params.GatewayVersion}','','Active','','','','','','','','','','','${user}','Rollback Requested',sysdate)"""
                        }
                        else
                        {                   
                            insert_query = """Insert into CICD_DEPLOYMENT_HISTORY ("Release","DateTime","CRQ","ComponentType","Environment","EngineName","BwVersion","EmsVersion","SqlVersion","GatewayVersion","BwDeploymentType","DeploymentStatus","DeploymentTime","XmlFiles","JarFiles","EmailFiles","RF1Status","RBStatus","RF2Status","DVTStatus","BWConfigTag","ChangeDescription","User","FailureReason","updatedTimestamp") values ('${params.ReleaseNumber}',sysdate,'${params.CRQ}','GATEWAY','${env.GatewayEnvironment}','${env.GatewayType}','','','','${params.GatewayVersion}','','Active','','','','','','','','','','','${user}','PASSED',sysdate)"""
                        }
						println("DEBUG: Insert query is: " + insert_query)
		
                        try
                        {
                            DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${env.dbUserName}", dbPassword: "${env.dbPassword}", dbDriver: "${env.dbDriver}", insertQuery: insert_query
                        }
                        catch(Exception ex)
                        {
                             //Error handle in case of DB Insert Failure
							 echo "DB insertion failure. Query ${insert_query}"
                        }
                }
            }
        }//DB update stage end
		
		
    }
}	