import java.text.*
import groovy.time.*

def date = new Date();
def sdf = new SimpleDateFormat("yyyyMMddHHmmss");
def date_time = sdf.format(date)

def trigger_results_email(deployParams){
	// This function is to trigger an email for the provided map.
	emailext mimeType: 'text/html',
	subject: "[Jenkins]: ${currentBuild.fullDisplayName}  - " + "Upliftment Results Summary",
	from:"CICD_ISTILCertDeploymentStatus@vodafone.com",
	to: "${dev_mailRecipients}",
	body: 	"${emailFunc.get_prod_results_email_summary map: deployParams.map, REPORT_STAGE: deployParams.REPORT_STAGE}" 
}

def load_groovy_files() {
	// This function is to load all groovy files, where in common functions will be kept.
	emailFunc = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/emailFunctions.groovy"
	mapFunc = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/mapFunctions.groovy"
	gitFunc = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/gitFunctions.groovy"
	BW_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/BWFunctions.groovy"
	commonFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/commonFunctions.groovy"
}

def elapsedTime(Closure closure){
    def timeStart = new Date()
    closure()
    def timeStop = new Date()
    return TimeCategory.minus(timeStop, timeStart).toMilliseconds()
}
	
def Git_Checkout (){

			
			
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "ENV"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Production_Configuration.git']]]
	
		// Checkout Automation files from GITHUB repository.
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "automation"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
	
	
			checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'JENKINS_FILE']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_DevOps_Framework.git']]])	
}


def get_body_build_summary(){
		def date = new Date();
		def sdf = new SimpleDateFormat("dd/MM/yyyy  HH:mm");
		def date_time = sdf.format(date)
		
	
		def body_build_summary = """
				<style type="text/css">
				.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
				.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
				.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
				.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
				.tg .tg-2wig{font-weight:bold;text-align:center;vertical-align:top}
				.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
				.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
				.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
				.tg .tg-0lax{text-align:left;vertical-align:top}
				</style>
				</style>
				<table class="tg" style="undefined;table-layout: fixed; width: 100%">
				<colgroup>
				<col style="width: 90px">
				<col style="width: 90px">
				<col style="width: 90px">
				<col style="width: 90px">
				</colgroup>
				  <tr>
					<th class="tg-amwm" colspan="6">Certificate Deployment Preparation Report</th>
				  </tr>
				  <tr>
					<td class="tg-1wig" colspan="2">Submitted By</td>
					<td class="tg-0lax" colspan="4">${currentBuild.getRawBuild().getCauses()[0].getUserId()}</td>
				  </tr>
				  <tr>
					<td class="tg-1wig" colspan="2">Date</td>
					<td class="tg-0lax" colspan="4">${date_time}</td>
				  </tr>
				  <tr>	
					<td class="tg-1wig" colspan="2">Environment</td>
					<td class="tg-0lax" colspan="4">${Target_Env}</td>
				  </tr>
				  <tr>	
					<td class="tg-1wig" colspan="2">CRQ_Number</td>
					<td class="tg-0lax" colspan="4">${CRQ}</td>
				  </tr>
				  <tr>	
					<td class="tg-1wig" colspan="2">Client_Name</td>
					<td class="tg-0lax" colspan="4">${Client_Name}</td>
				  </tr>
				  <tr>	
					<td class="tg-1wig" colspan="2">Certificate_Type</td>
					<td class="tg-0lax" colspan="4">${Certificate_Type}</td>
				  </tr>
				  <tr>	
					<td class="tg-1wig" colspan="2">Engine_List</td>
					<td class="tg-0lax" colspan="4">${Engine_List}</td>
				  </tr>
				  <tr>	
					<td class="tg-1wig" colspan="2">Certificates_List</td>
					<td class="tg-0lax" colspan="4">${Files}</td>
				  </tr>
				</table>
				
				<br><br><br>
		"""
		emailBody = body_build_summary
		return body_build_summary
}

def get_approvers_list(String str){
    outlist = sh (script: """cat /opt/SP/tibco/.jenkins/config.xml | sed -n \'/role name=\"${str}\"/,\$p\' | sed \'/role>/q\' | grep "sid" | cut -d \'>\' -f 2 | cut -d \'<\' -f 1 | paste -s -d, -""",
            returnStdout: true).trim()
    return """${outlist}"""
}

def  Preparation ()	{
	
	RELEASE = "CCS21.5"
	displayName = "Cert_Deploy_${CRQ}_${BUILD_NUMBER}"
	currentBuild.displayName = "${displayName}"
	date_now = new Date().format("YYYYMMddHHmmss")
	
	
	
	Git_Checkout ()
	
	sh '''
	
		cp -rf ${WORKSPACE}/ENV/Certificate_Configuration ${WORKSPACE}/Certificate_Configuration
		cp -rf ${WORKSPACE}/automation/Certificate_Deployment ${WORKSPACE}/Certificate_Deployment
		
		
	'''
	
	if(fileExists("${WORKSPACE}/Certificate_Configuration/${Server_Type}/${Target_Env}/${Server_Type}_Certificateconfig.txt")) {		
		
		sh '''		 
			cat ${WORKSPACE}/Certificate_Configuration/${Server_Type}/${Target_Env}/${Server_Type}_Certificateconfig.txt | grep ${Client_Name} | grep ${Certificate_Type} >> ${WORKSPACE}/data.txt
		'''	
		def File = "${WORKSPACE}/data.txt"
		def readFile = new File("${File}")
		def FileContent = readFile.readLines()
		Content = "${FileContent}".split('\\|')
		Engine_List = Content[1]
		Restart_Engines = Engine_List.replaceAll(",", ";")
			
	}
	
	sh '''
	cd ${WORKSPACE}/Certificate_Configuration/${Server_Type}/${Target_Env}/Certs/${Client_Name}/${Certificate_Type}
	ls * > ${WORKSPACE}/FileList.txt
	'''
	cert_snap= ""
	def File1 = "${WORKSPACE}/FileList.txt"
	def readFile1 = new File("${File1}")
	def FileContent1 = readFile1.readLines()
	def Path = "${FileContent1}".split('\\[')
	def Path1 = Path[1].split('\\]')
	FileList = Path1[0].split(', ')
	path_list = Content[3].split(',')
	//echo "${path_list}"	
	for (List in FileList) {
		for (List_path in path_list) {
			if (cert_snap.length() != 0) {
				cert_snap = "${cert_snap}" + "," + List_path + List			
			}else {
				// def first = List.split('\\[')
				cert_snap = "${Client_Name}" + ":" + List_path + List
			}
		}
	}
	//cert_snap = "${File_list}".split('\\]')
	println "${cert_snap}"
	def emailBody = "${get_body_build_summary()}"
		emailext  mimeType: 'text/html', 
		subject: "[Jenkins]:Certificate Deployment Preparation Report",
		from:"${Server_Type}_Certificate_Deployment@vodafone.com",
		to: "${dev_mailRecipients}",
		body:"${emailBody}" + 
				"<br><p><b><font size='2' color='Black'>${Server_Type}_Certificate_Deploy_BUILDURL: <a href='${BUILD_URL}input'>${BUILD_URL}</a></font></b></p>"	
		input 'Please verify the email.Do you want to Proceed with  Certificate Deployment'
	/*	def Input = input( id: 'userInput', message: 'Do you want to Proceed the Deployment or Not ?',
				parameters: [[$class: 'ChoiceParameterDefinition', defaultValue: 'Proceed', 
					description:'describing choices', name:'nameChoice', choices: "Proceed"]
					],
				submitterParameter: 'submitter',
				submitter: "${dev_mailRecipients}"
				) 
				println("DEBUG: Choice selected is: " + Input.nameChoice)
	*/
	
	bw_release_num = RELEASE.replace(".","_")
		println(bw_release_num)

		majorVersion = RELEASE.split('CCS')[1].split('\\.')[0]
		minorVersion = RELEASE.split('CCS')[1].split('\\.')[1]
		
		// Get staging approver details.
		//ReleaseApprovers = get_approvers_list('Ops-User')
		//[CICD-539] Making user parameter as global parameter to use across the pipeline.
		user = currentBuild.rawBuild.causes[0].userId
		println("DEBUG: User name is: " + user)
		
		//Load all functions files from GIT. point to exact source file
		load_groovy_files()
		
		commonFunctions.validate_input_parameters RELEASE: RELEASE, CRQ: params.CRQ, DESCRIPTION: params.Description		

		// Construct VERSION_MAP and RESULTS_MAP with all the engines from NEXUS.
		construct_maps()
		
		
		// Grouping BW engines for deployment based on engine type and folder name.
		def group_engine_type_maps = VERSIONS_MAP.findAll { it.value['BW_VERSION'] != "NA" }.groupBy({ engine -> engine.value['BW_ENGINE_TYPE'] })
		group_engine_type_maps.each { g_type_key, g_type_value ->
				def group_engine_type_folder_maps = g_type_value.groupBy({ engine -> engine.value['BW_FOLDER_NAME'] })
				group_engine_type_folder_maps.each{ g_type_folder_key, g_type_folder_value ->
					def counter = 1
					def gID = 1
					g_type_folder_value.each { g_type_folder_value_key, g_type_folder_value_value ->
						VERSIONS_MAP[g_type_folder_value_key]['GROUP_ID'] = g_type_key + '_' + g_type_folder_key + '_' + gID
						if(counter < 5){
							counter++
						} else {
							counter = 0
							gID++ 
						}
					}
				}
		}
		print "VERSIONS_MAP after preparation step: " + VERSIONS_MAP
		//trigger_versions_email map: VERSIONS_MAP, REPORT_STAGE: "VERSIONS AFTER IGNORE"
	
}
def construct_maps() {
	if(Restart_Engines.length() != 0){
		def Restart_Versions = ""
		Restart_Engines.split(';').each { engine ->
			 Restart_Versions = Restart_Versions + engine + ':' + "1" + ';'
		}
		mapFunc.generate_map inputString:Restart_Versions, map:Restart_Engine_Snap
	}

	Engines_Map = Restart_Engine_Snap


	Engines_Map.each { key, value ->
		VERSIONS_MAP[key] = ['BW_VERSION':'NA', 'BW_FOLDER_NAME':'NA', 'BW_ENGINE_TYPE':'NA', 'EMS_VERSION':'NA', 'SQL_VERSION':'NA', 'XML_FILES':'NA', 'JAR_FILES':'NA', 'EMAIL_FILES':'NA', 'RESULT':'NA', 'RF1_RESULT':'NA', 'RF2_RESULT':'NA', 'RB_RESULT':'NA', 'BW_Generation':'NOT_REQUIRED', 'SQL_Deployment':'NOT_REQUIRED', 'EMS_Deployment':'NOT_REQUIRED', 'XML_Deployment':'NOT_REQUIRED', 'JAR_Deployment':'NOT_REQUIRED', 'EMAIL_Deployment':'NOT_REQUIRED', 'BW_Deployment':'NOT_REQUIRED',  'BW_Restart':'NOT_STARTED', 'EMS_DURATION':'0', 'SQL_DURATION':'0', 'BW_DURATION':'0', 'FILE_DURATION':'0', 'DB_ROW_ID':'0']
	}

	if(Restart_Engine_Snap.size() != 0){
		Restart_Engine_Snap.keySet().each { engine ->
			bw_folder = gitFunc.get_engine_bw_folder_name_from_gvconf engine: engine
			if(bw_folder){
				VERSIONS_MAP[engine]['BW_FOLDER_NAME'] =  bw_folder
			} else {
				error("Check the engine name and Folder name in GV conf for proper format")
			}
			VERSIONS_MAP[engine]['BW_VERSION'] = "1"
			VERSIONS_MAP[engine]['BW_ENGINE_TYPE'] = "RESTART"
			VERSIONS_MAP[engine]['BW_Restart'] = "NOT_STARTED"
		}
	}
	if ("${params.Target_Env}" == "Staging" || "${params.Target_Env}" == "Production" || "${params.Target_Env}" == "Production_ISTIL_Dublin" || "${params.Target_Env}" == "Production_ISTIL_Swindon") {
		VERSIONS_MAP.each { pl_engine, pl_version ->
			if(VERSIONS_MAP[pl_engine]['BW_FOLDER_NAME'] == "SB01"){
				VERSIONS_MAP[pl_engine]['BW_FOLDER_NAME'] = "ServiceBus1"
			}
			if(VERSIONS_MAP[pl_engine]['BW_FOLDER_NAME'] == "SB02") {
				VERSIONS_MAP[pl_engine]['BW_FOLDER_NAME'] = "ServiceBus2"
			}
			if(VERSIONS_MAP[pl_engine]['BW_FOLDER_NAME'] == "SB03") {
				VERSIONS_MAP[pl_engine]['BW_FOLDER_NAME'] = "ServiceBus3"
			}	   
		}
	
	}
}


def bw_generate_stage(){
	
//Checkout Environment Configurations
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "ENV"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Production_Configuration.git']]]
	
	// checkout Release templates repository
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Release_Repo"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Production_Configuration.git']]]
	
	// Construct Description for engine
	//def user = currentBuild.rawBuild.causes[0].userId
	//println(user);
	
	//[CICD-519]: Fix to handle special characters in Description part
	String desc = "${params.Description}".replaceAll(/(!|"|@|#|\$|%|&|\\/|\(|\)|=|\?)/, /\\$0/)
	desc = desc + "|" + "${user}"		
	
	//def desc = "${params.Description}".trim() + "|" + "${user}"
	//println(desc); 
	//Group versios map with groupid and generate bw configuration in target host 
	def BW_Deploy_group_maps = VERSIONS_MAP.groupBy({ engine -> engine.value['GROUP_ID'] })
	BW_Deploy_group_maps.each { patteren_string, BW_Deploy_group ->
		eng_ver_map = BW_Deploy_group.collectEntries {bw_engine, bw_version -> [bw_engine, bw_version['BW_VERSION']]}
		String engines_versions = mapFunc.convert_map_to_string engine_map:eng_ver_map
		println("DEBUG:" + engines_versions)
		String engines_list = "${eng_ver_map.keySet().join(';')}"
		println("DEBUG:" + engines_list)
		
		echo "DEBUG: pattern string is: ${patteren_string}"
		if(patteren_string.toString() != "null") {
			BW_type = patteren_string.split('_')[0]
			echo "DEBUG: BW_type is: ${BW_type}"
			BW_Folder = patteren_string.split('_')[1]
			group_id = patteren_string.split('_')[2]
		} else {
			BW_type = "None"
		}
		if (BW_type == "RESTART") {
			
			println("DEBUG:" + group_id + "Generate conf file for type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list)
			BW_Functions.generate_conf_files_restart engines:engines_versions, Host:"${params.Target_Env}", ReleaseNumber:"${RELEASE}", folderName:BW_Folder, description:"${desc}"
			
			// Call generate function by passing details
			BW_Functions.generate_bw_restart Host:"${params.Target_Env}", crq_no:"${params.CRQ}", datetime:"${date_now}", engines_list:engines_list, deployment_type:"EXISTING", folderName:BW_Folder, bw_folder_release:bw_release_num, engine_group:patteren_string
			
		}else {
			println("DEBUG: Invalid Deployment type Identified. Please fix this issue")
		}
	}
	
	// Update maps with failed engines from BW Generate
	def bw_generate_failed_file = "${WORKSPACE}/${params.Target_Env}/BW_Deployment/generate_failure.txt"
	if(fileExists(bw_generate_failed_file)) {
		def bw_generate_failed_ouput = readFile("${WORKSPACE}/${params.Target_Env}/BW_Deployment/generate_failure.txt")
		if (bw_generate_failed_ouput.size() != 0) {
			def failed_file = new File("${WORKSPACE}/${params.Target_Env}/BW_Deployment/generate_failure.txt")
			def failed_engines_list = failed_file.readLines().join(';')
			mapFunc.update_version_map_result map: VERSIONS_MAP, engines: failed_engines_list, stage: "BW_Generation", status:"FAILED"
		}
	} 
	// Update maps with success engines from BW Generate
	def bw_generate_success_file = "${WORKSPACE}/${params.Target_Env}/BW_Deployment/generate_success.txt"
	if(fileExists(bw_generate_success_file)) {
		def bw_generate_success_ouput = readFile("${WORKSPACE}/${params.Target_Env}/BW_Deployment/generate_success.txt")
		if (bw_generate_success_ouput.size() != 0) {
			def success_file = new File("${WORKSPACE}/${params.Target_Env}/BW_Deployment/generate_success.txt")
			def success_engines_list = success_file.readLines().join(';')
			mapFunc.update_version_map_result map: VERSIONS_MAP, engines: success_engines_list, stage: "BW_Generation", status:"PASSED"
		}
	}
	
	// Trigger Result Email
	//trigger_results_email map: VERSIONS_MAP, REPORT_STAGE: "BW_Generate"
	
}	
// Function for BW Restart
def bw_restart_stage(){ 
              
				 
	//Group versios map with groupid and run deploy step in target host 
	def BW_Deploy_group_maps = VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['BW_VERSION'] != "NA" }.groupBy({ engine -> engine.value['GROUP_ID'] })
	BW_Deploy_group_maps.each { patteren_string, BW_Deploy_group ->
		eng_ver_map = BW_Deploy_group.collectEntries {bw_engine, bw_version -> [bw_engine, bw_version['BW_VERSION']]}
		String engines_versions = mapFunc.convert_map_to_string engine_map:eng_ver_map
		println("DEBUG:" + engines_versions)
		String engines_list = "${eng_ver_map.keySet().join(';')}"
		println("DEBUG:" + engines_list)
		
		echo "DEBUG: pattern string is: ${patteren_string}"
		// CICD-1828 Ansible for Instance file modifing 
		ansiColor('xterm') {
			ansiblePlaybook (playbook: "${WORKSPACE}/Certificate_Deployment/Instance.yml", colorized: true, extras: '', extraVars: [host: "${params.Target_Env}_BW", datetime: "${date_now}", crq_num: "${params.CRQ}", folderName: "${BW_Folder}", bw_folder_release: "${bw_release_num}", engine_group: "${patteren_string}", engines_list: "${engines_list}", Server1: "${params.Instance1}", Server2: "${params.Instance2}"])
		}
		
		
		if(patteren_string.toString() != "null") {
			BW_type = patteren_string.split('_')[0]
			echo "DEBUG: BW_type is: ${BW_type}"
			BW_Folder = patteren_string.split('_')[1]
			group_id = patteren_string.split('_')[2]
			// Calling Restart Function
			BW_Functions.bw_restart Host:"${params.Target_Env}", crq_no:"${params.CRQ}", datetime:"${date_now}", bw_folder_release:bw_release_num, engine_group:patteren_string, folderName:BW_Folder, engines_list_restart:engines_list
		} 
	  }
	// Check if BW Restart file exists for Failures
	def bw_restart_failed_file = "${WORKSPACE}/${params.Target_Env}/BW_Deployment/restart_failure.txt"
	if(fileExists(bw_restart_failed_file)) {
		def bw_restart_failed_ouput = readFile("${WORKSPACE}/${params.Target_Env}/BW_Deployment/restart_failure.txt")
		if (bw_restart_failed_ouput.size() != 0) {
		    // Reading Restart Failure
			def failed_file = new File("${WORKSPACE}/${params.Target_Env}/BW_Deployment/restart_failure.txt")
			def failed_engines_list = failed_file.readLines().join(';')
			  
			failed_engines_list.split(';').each { bw_engine ->
				if(VERSIONS_MAP.containsKey(bw_engine)) {
					// CICD1684 - removing updating Result Map with Failed status
					//VERSIONS_MAP[bw_engine]['RESULT'] = "FAILED"
					VERSIONS_MAP[bw_engine]['BW_Restart'] = "FAILED"
					print "ERROR: Failure in restart for the engine: ${failed_engines_list}"
					//error "ERROR: Restarts failed for some of the engines. Please check the summary"
				}
			}
			
			// Email Restart Faileed Engines
			//trigger_results_email map: VERSIONS_MAP, REPORT_STAGE: "BW_Restart"
			
		}							
	}
		
		// Reading restart successful engines file 
		def bw_restart_success_file = "${WORKSPACE}/${params.Target_Env}/BW_Deployment/restart_success.txt"
	    if(fileExists(bw_restart_success_file)) {
			  def bw_restart_success_ouput = readFile("${WORKSPACE}/${params.Target_Env}/BW_Deployment/restart_success.txt")
			  def success_file = new File("${WORKSPACE}/${params.Target_Env}/BW_Deployment/restart_success.txt")
			  def success_engines_list = success_file.readLines().join(';')
			  success_engines_list.split(';').each { bw_engine ->
					if(VERSIONS_MAP.containsKey(bw_engine)) {
						VERSIONS_MAP[bw_engine]['BW_Restart'] = "PASSED"
					}
			   }
		}
		
		
		
}
def Rollback_Input = ""
def RELEASE = ""
def Signoff_Input = ""
ReleaseApprovers = ""
date_now = " "
displayName = ""
bw_release_num = ""
BW_Folder_Snap = [:]
Restart_Engine_Snap = [:]
Env_Prefix = ""
Engines_Map = [:]
VERSIONS_MAP = [:]
BW_Type_Snap = [:]
def BW_Input = ""
// Pipeline parameters.
BW_Deployment_Required = ""
SQL_Deployment_Required = ""
EMS_Deployment_Required = ""
File_Deployment_Required = ""
BW_Deployment_Type = ""
BW_Engines = ""
FolderName = ""
SQL_Versions = ""
SQL_BACKUP_TABLES = ""
EMS_Versions = ""
File_Deployment_Engines = ""
AppDynamics_Update = ""
nexusFunc = ""
emailFunc = ""
mapFunc = ""
Env_Prefix = ""
maps_list = []
BW_type = ""
BW_Folder = ""
group_id = ""
user = ""
pipeline {
    agent any
	environment {
		Content = ""
		cert_snap = ""
		FileList= ""
		File_list = ""
		Src_Path = "${WORKSPACE}/Certificate_Configuration/${Server_Type}/${Target_Env}/Certs/${Client_Name}/${Certificate_Type}"
		Engine_List = ""
		Restart_Engines = ""
		dev_mailRecipients = "devops-vfuk-integration@vodafone.com, DL-TSSC-AO2-UK-Integration_TIL-RIG_L2@vodafone.com"
		Files = ""
		Status = ""
		//BW_Input = ""
		REPO_URL = "http://195.233.197.150:8081/repository"
		NEXUS_URL = "http://195.233.197.150:8081"
		NEXUS_USER = "admin"
		NEXUS_PASSWD = "admin123"
		Promotion_Repo = "PROD_REPO"
		BW_GROUPID = "TIL_BW"
		EMS_GROUPID = "TIL_EMS"
		SQL_GROUPID="TIL_SQL"
		emsIgnore = "false"
		//UPLIFTMENT_REF_REPO = "STAGING_REPO"
		BW_InstanceCount = 2
		EnvironmentRepository = "TIL_Production_Configuration"
		//RELEASE = "CCS21_5"
		
	}
    stages {
        stage ('Preparation Report') {
            steps {
                script {
                  cleanWs()  
                  Preparation ()
                    
                }
            }
        }
		stage('Artifacts Generate') {
		    when {
			     expression { VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" } }
			    }
			steps {
				script {
					//Calling BW  Generate Function	
					bw_generate_stage()	
				}
			}
		}		
        stage ('Cert_Deploy For uk2752yr') {      
            steps {
                script {
                  
					Deploy_Duration = elapsedTime {
						ansiColor('xterm') {
							ansiblePlaybook (playbook: "${WORKSPACE}/Certificate_Deployment/certsDeploy.yml", colorized: true, extras: '', extraVars: [host: "Production_ISTIL_Swindon_CertBW1", cert_snap: "${cert_snap}", datetime: "${date_time}", crq_num: "${CRQ}", Src_Path: "${Src_Path}"])
						}
					}
					Deploy_Duration = Deploy_Duration*0.001
					println("Deploy Duration in Sec: " + Deploy_Duration)
					println "Certificates Deployment Completed"
                }
            }
        }      
		
		stage ('Restart For uk2752yr applications') {
			when {
			     expression { VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" } }
			    }
            steps {
                script {
					def BW1_Input = input(
						   message: 'Choose BW Restart Mode',
						   parameters: [
							 [$class: 'ChoiceParameterDefinition',
							  choices: ['Manual','Automatic'].join('\n'),
							  name: 'input',
							  description: 'Select Restart Mode']
							])
					println("DEBUG: Choice selected is: " + BW1_Input)
					println "Restarting"
					//Status = "Success"
						if ( "$BW1_Input" == "Automatic" ) {
						
							// Calling BW Restart Stage function
							bw_restart_stage()
					

							trigger_results_email map: VERSIONS_MAP, REPORT_STAGE: "BW-RESTART"
						}
					
				 BW_Input = input(
					   message: 'Do you want to proceed with remaining instances?',
					   parameters: [
						 [$class: 'ChoiceParameterDefinition',
						  choices: ['Continue','Rollback'].join('\n'),
						  name: 'input',
						  description: 'Select Restart Mode']
						])
					println("DEBUG: Choice selected is: " + BW_Input)
					
					if ( "$BW_Input" == "Rollback" ) {
						
						Signoff_Input = "Continue"
						
					}
				
				}
			}
		}
	
		stage ('Cert_Deploy For uk2753yr,uk2754yr & uk2755yr') {
            when {
			     expression { "${BW_Input}" == "Continue" }
			}
			steps {
			    script {
					
                    //println "Deploy"
					Deploy_Duration = elapsedTime {
						ansiColor('xterm') {
							ansiblePlaybook (playbook: "${WORKSPACE}/Certificate_Deployment/certsDeploy.yml", colorized: true, extras: '', extraVars: [host: "SwindonCertgroup", cert_snap: "${cert_snap}", datetime: "${date_time}", crq_num: "${CRQ}", Src_Path: "${Src_Path}"])
						}
					}
					Deploy_Duration = Deploy_Duration*0.001
					println("Deploy Duration in Sec: " + Deploy_Duration)
					println "Certificates Deployment Completed"
                }
            }
        }                
    
		stage ('Restart For uk2753yr,uk2754yr & uk2755yr applications') {
            when {
			     expression { "${BW_Input}" == "Continue" }
			}
			steps {
				script {
					def BW1_Input = input(
						   message: 'Choose BW Restart Mode',
						   parameters: [
							 [$class: 'ChoiceParameterDefinition',
							  choices: ['Manual','Automatic'].join('\n'),
							  name: 'input',
							  description: 'Select Restart Mode']
							])
					println("DEBUG: Choice selected is: " + BW1_Input)
					println "Restarting"
					//Status = "Success"
						if ( "$BW1_Input" == "Automatic" ) {
						
							// Calling BW Restart Stage function
							bw_restart_stage()
					

							trigger_results_email map: VERSIONS_MAP, REPORT_STAGE: "BW-RESTART"
						}
					
					
					 Signoff_Input = input(
						   message: 'Do you want to proceed with rollback?',
						   parameters: [
							 [$class: 'ChoiceParameterDefinition',
							  choices: ['Signoff','Rollback'].join('\n'),
							  name: 'input',
							  description: 'please select rollback if change is failed']
							])
					println("DEBUG: Choice selected is: " + Signoff_Input)
					
					if ( "$Signoff_Input" == "Rollback" ) {
						
						Rollback_Input = "Rollback"
						//println "123"
					
					}
					println "${Rollback_Input}"
				
				}
			}
		}
		
		stage ('Rollback ') {
			when {
			     expression { "${BW_Input}" == "Rollback" || "${Signoff_Input}" == "Rollback" }
			}
            steps {
                script {
					
					if ( "$BW_Input" == "Rollback" ) {
						Rollback_Duration = elapsedTime {
							ansiColor('xterm') {
								ansiblePlaybook (playbook: "${WORKSPACE}/Certificate_Deployment/certsRollBack.yml", colorized: true, extras: '', extraVars: [host: "Production_ISTIL_Swindon_CertBW1", cert_snap: "${cert_snap}", datetime: "${date_time}", crq_num: "${CRQ}"])
							}
						}
						Rollback_Duration = Rollback_Duration*0.001
						println("Rollback Duration in Sec: " + Rollback_Duration)
						println "Rollback Completed"
						
					}
					
					if ( Rollback_Input == "Rollback" ) {
						Rollback_Duration = elapsedTime {
						
							ansiColor('xterm') {
								ansiblePlaybook (playbook: "${WORKSPACE}/Certificate_Deployment/certsRollBack.yml", colorized: true, extras: '', extraVars: [host: "Production_ISTIL_Swindon_CertBW1", cert_snap: "${cert_snap}", datetime: "${date_time}", crq_num: "${CRQ}"])
							}
							
							ansiColor('xterm') {
								ansiblePlaybook (playbook: "${WORKSPACE}/Certificate_Deployment/certsRollBack.yml", colorized: true, extras: '', extraVars: [host: "SwindonCertgroup", cert_snap: "${cert_snap}", datetime: "${date_time}", crq_num: "${CRQ}"])
							}
						}
						Rollback_Duration = Rollback_Duration*0.001
						println("Rollback Duration in Sec: " + Rollback_Duration)
						println "Rollback Completed"
						
					}
					
				}
			}
		}
		stage ('Restart of Instances in BW servers') {
			when {
				expression { "${BW_Input}" == "Rollback" || "${Signoff_Input}" == "Rollback" }
			}
			steps {
				script {
					def BW2_Input = input(
						   message: 'Choose BW Restart Mode',
						   parameters: [
							 [$class: 'ChoiceParameterDefinition',
							  choices: ['Manual','Automatic'].join('\n'),
							  name: 'input',
							  description: 'Select Restart Mode']
							])
					println("DEBUG: Choice selected is: " + BW2_Input)
					println "Restarting"
					
					if ( "$BW2_Input" == "Automatic" ){					
						// Calling BW Restart Stage function
						bw_restart_stage()
					
						trigger_results_email map: VERSIONS_MAP, REPORT_STAGE: "BW-RESTART"
					}	
					
				}
			}
		}
					
		stage ('Sign Off') {
		
			steps {
				script {
					//input 'Proceed with  Signoff ?'						
						println "Signoff Completed"
						
					
					}
			}
		}
			
	}
}
