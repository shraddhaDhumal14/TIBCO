
//import this package as part of the fix
import groovy.time.*

//[CICD-1530] Insert Deployment metadata to release notes DB.
import groovy.json.JsonOutput
import groovy.sql.*
import java.sql.Driver

def get_gatewaybody_build_summary(deployParams){
	def date_format_report = new Date().format("dd/MM/yyy HH:mm")
	def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
		.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		</style>
		<table class="tg" style="undefined;table-layout: fixed; width: 900px">
		<colgroup>
		<col style="width: 100px">
		<col style="width: 350px">
		<col style="width: 100px">
		<col style="width: 350px">
		</colgroup>
		  <tr>
			<td>
			<table width="50%"><tr><td><img width="150" src="https://www.vodafone.co.uk/cs/groups/public/documents/webcontent/1287x929_vodafone_logo.jpg" alt="ITEAMS" style="text-align: right; width: 207px; border: 0; text-decoration:none; vertical-align: baseline;"></td></tr></table>
            <div style="display:none">
			</div>
			</td>
			<th class="tg-amwm" colspan="3">CCS Integration ${env.GatewayEnvironment} Deployment Summary ${params.ReleaseNumber}</th>
		  </tr>
		  <tr>
			<td class="tg-1wig">Submitted By</td>
			<td class="tg-0lax">${user}</td>
			<td class="tg-1wig">Date</td>
			<td class="tg-0lax">${date_format_report}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">RELEASE NUMBER & Version</td>
			<td class="tg-0lax">${params.ReleaseNumber} and ${params.GatewayVersion}</td>
			<td class="tg-1wig">Gateway</td>
			<td class="tg-0lax">${env.GatewayType}</td>
		  </tr>
          <tr>
			<td class="tg-1wig">Instance</td>
			<td class="tg-0lax">${(deployParams.Host).split('_')[2]} </td>
			<td class="tg-1wig">Port</td>
			<td class="tg-0lax">${(deployParams.Host).split('_')[3]}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">Deployment Type</td>
			<td class="tg-0lax">${deployParams.DeploymentType}</td>
			<td class="tg-1wig">Status</td>
			<td class="tg-0lax">${deployParams.Status}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">PID before restart</td>
			<td class="tg-0lax">${deployParams.beforeRestart}</td>
			<td class="tg-1wig">PID after restart</td>
			<td class="tg-0lax">${deployParams.afterRestart}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">Before ExternalApache Restart PID</td>
			<td class="tg-0lax">${deployParams.beforeExternalApacheRestart}</td>
			<td class="tg-1wig">After ExternalApache Restart PID</td>
			<td class="tg-0lax">${deployParams.afterExternalApacheRestart}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">Before InternalApache Restart PID</td>
			<td class="tg-0lax">${deployParams.beforeInternalApacheRestart}</td>
			<td class="tg-1wig">After InernalApache Restart PID</td>
			<td class="tg-0lax">${deployParams.afterInternalApacheRestart}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">LOG_URL</td>
			<td class="tg-0lax" colspan="3">${BUILD_URL}/console</td>
		  </tr>		  
		</table>
		<br><br><br>
	"""
	emailBody = body_build_summary
	writeFile file: "${WORKSPACE}/Reports/${deployParams.DeploymentType}_Report.html", text: emailBody 
	writeFile file: "/opt/SP/tibco/.jenkins/userContent/Gateway/${env.GatewayType}/${params.ReleaseNumber}/${params.GatewayVersion}/${deployParams.DeploymentType}_Report.html", text: emailBody
	return body_build_summary
}

def stash_function() {
    script{
	
	      unstash "stashProperties"
		  if (date_now == " ") {
				date_now = sh(script:"cat ./DIR_STASH/propfile | grep -e date | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
				echo "Date after stage restart is:${date_now}"
			}
		  if (displayName == " ") {
				displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
				currentBuild.displayName = "${displayName}_restart"
				echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
                load_groovy_files()  
                if( "${env.GatewayType}" == "IGW01" ) {
                    internalApache = "true"
                    externalApache = "true"
                }else if( "${env.GatewayType}" == "GGW01" || "${env.GatewayType}" == "IGW02" || "${env.GatewayType}" == "EGW" ) {
                    internalApache = "false"
                    externalApache = "true"
                }else  {
                    internalApache = "false"
                    externalApache = "false"
                }                 
			}
	
	}
}

def validate_parameter() {
        def validationCheck = ""
        echo "Release number selected is: ${params.ReleaseNumber}"
        
		//1. Validate RELEASE parameter
        String regex = /(^CCS\d+\.\d+_[A-Z0-9]+$)|(^CCS\d+\.\d+$)/
        if(ReleaseNumber == ""){
            println("Release is mandatory for Gateway Pipeline")
            validationCheck = "F"
        }
        if (ReleaseNumber.indexOf(' ') != -1){
            println('RELEASE parameter should not contain spaces in between')
            validationCheck = "F"
        }
        /*
        if (!(ReleaseNumber ==~ regex)){
            println('RELEASE parameter is not in standard format. Please input either in CCS20.12 or CCS20.12_xx format')
            validationCheck = "F"
        }   

        //2. Validate GATEWAY VERSION belongs to RELEASE or not.
        if (ReleaseNumber.split('CCS')[1].split('_').join(".") != GatewayVersion.split('_').init().join(".")){
            println("GATEWAY_VERSION should belong to Release Number provided")
            validationCheck = "F"
        }        
        */
        //3. Validate CRQ number
        if(CRQ == ""){
            println("CRQ Number should be specified for the Deployment")
            validationCheck = "F"
        }
        if (CRQ.indexOf(' ') != -1){
            println('CRQ parameter should not contain spaces in between')
            validationCheck = "F"
        }

        if(validationCheck == "F"){
			error("Pipeline Input parameter validation failed. Please check the errors in Console log.")
			currentBuild.result = 'ABORTED'
		}        

}

def initialize_variables()
{
        date_now = new Date().format("YYYYMMddHHmmss")
        displayName = "${params.ReleaseNumber}_${params.CRQ}"
        currentBuild.displayName = "${displayName}"        
        
        if( "${env.GatewayType}" == "IGW01" ) {
            internalApache = "true"
            externalApache = "true"
        }else if( "${env.GatewayType}" == "GGW01" || "${env.GatewayType}" == "IGW02" || "${env.GatewayType}" == "EGW" ) {
            internalApache = "false"
            externalApache = "true"
        }else  {
            internalApache = "false"
            externalApache = "false"
        }
        
        println "Apache Details --> ${env.GatewayType},internalApache:${internalApache},externalApache:${externalApache}"
        
        
        //Stash the important values so that these can be retrieved for stage restart.
        sh "mkdir -p DIR_STASH"
        sh "echo date:${date_now} >DIR_STASH/propfile"
        sh "echo displayName:${displayName} >>DIR_STASH/propfile"
        stash includes: 'DIR_STASH/propfile', name: 'stashProperties'
}

def download_git_repo() {
    //Checkout Environment Configurations
    checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'PROD_Conf']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Production_Configuration.git']]])
    //Checkout for Common Functions
    checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'JENKINS_FILE']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_DevOps_Framework.git']]])
    //Checkout for Gateway Deployment. Will be downloaded while deployment stage for each host
    //checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'Gateway']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]])
    load_groovy_files()
    for(counter=1 ; counter<GatewayInstances.size(); counter++)
    {     
        checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${GatewayInstances[counter]}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]])
        GatewayFunction.gateway_code Host:"${GatewayInstances[counter]}", GatewayType:"${env.GatewayType}", gatewayEnvironment:"${env.GatewayEnvironment}"
    }
    sh "cp -r ./PROD_Conf/Gateway_Configuration ./"      
}

def load_groovy_files() {    
    GatewayFunction = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/GatewayFunctions.groovy"
    DB_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/dbFunctions.groovy"
    commonFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/commonFunctions.groovy"
    
    GatewayUsers = commonFunctions.get_approvers_list_upper('${Gateway_Approvers}')
    user = currentBuild.rawBuild.causes[0].userId
}

def gatewayRollforward(deployParams) {
	stash_function()
    ansiColor('xterm') {                
        GatewayFunction.deploy_artefact Host:"${deployParams.Host}", nexus_group_id:"${env.GROUPID}", nexus_artifact_id:"${env.GatewayType}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.PROD_REPO}", nexus_ArtefactVersion:"${params.GatewayVersion}", GatewayType:"${env.GatewayType}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CRQ}", datetime:"${date_now}", gatewayRestart:false, gatewayEnvironment:"${env.GatewayEnvironment}", deployType:"${deployParams.deployType}"
	}    
}

def gatewayRestart(deployParams) {
    stash_function()
    HostName = deployParams.Host
    deployType = deployParams.deployType
    GatewayFunction.gateway_pid Host:"${HostName}", GatewayType:"${env.GatewayType}"
    before_restart_pid = readFile "${HostName}/Gateway_Deployment/${HostName}_pid.txt"
    echo "Gateway PID is:${before_restart_pid}"
                
    // Check status of gateway and ask for user input if gateway in stopped state
    // get Gateway status by calling ansible gateway_status function
    GatewayFunction.gateway_status Host:"${HostName}", GatewayType:"${env.GatewayType}"
    def gatewayStatus = readFile "${HostName}/Gateway_Deployment/${HostName}_status.txt"
    echo "Gateway Status is:${gatewayStatus}"

    if (gatewayStatus == "0"){
        echo "gateway is running hence restarting"
        GatewayFunction.gateway_restart Host:"${HostName}", GatewayType:"${env.GatewayType}", internalApache:"${internalApache}", externalApache:"${externalApache}", gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
        
    }
    else {
        echo "gateway is not running"
        gateway_not_running Host:"${HostName}", GatewayType:"${env.GatewayType}", internalApache:"${internalApache}", externalApache:"${externalApache}", gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
    }
    // get Gateway PID by calling ansible gateway_pid function
    GatewayFunction.gateway_pid Host:"${HostName}", GatewayType:"${env.GatewayType}"
    after_restart_pid = readFile "${HostName}/Gateway_Deployment/${HostName}_pid.txt"
    echo "Gateway PID is:${after_restart_pid}"	
                
    // CICD-1520 Capturing apache PID 
    if(externalApache == "false")
    {
        before_externalApache_restart_pid = "No ExternalApache For ${env.GatewayType}"
    }
    else if ( fileExists("${WORKSPACE}/${HostName}/Gateway_Deployment/Before_External.txt")) {			
        before_externalApache_restart_pid = readFile "./${HostName}/Gateway_Deployment/Before_External.txt"
        echo "Before_ExternalApache_Restart : ${before_externalApache_restart_pid}"
    }else {
        before_externalApache_restart_pid = "PID not captured"
    }

    if(internalApache == "false")
    {
        before_InternalApache_restart_pid = "No InternalApache For ${env.GatewayType}"
    }
    else if ( fileExists("${WORKSPACE}/${HostName}/Gateway_Deployment/Before_Internal.txt")) {	  
        before_InternalApache_restart_pid = readFile "./${HostName}/Gateway_Deployment/Before_Internal.txt"
        echo "Before_InternalApache_Restart : ${before_InternalApache_restart_pid}"
    }else {
        before_InternalApache_restart_pid = "PID not captured"
    }

    if(externalApache == "false")
    {
        after_externalApache_restart_pid = "No ExternalApache For ${env.GatewayType}"
    }
    else if ( fileExists("${WORKSPACE}/${HostName}/Gateway_Deployment/After_External.txt")) {		
        after_externalApache_restart_pid = readFile "./${HostName}/Gateway_Deployment/After_External.txt"
        echo "After_ExternalApache_Restart : ${after_externalApache_restart_pid}"
    }else {
        after_externalApache_restart_pid = "PID not captured"
    }

    if(internalApache == "false")
    {
        after_InternalApache_restart_pid = "No InternalApache For ${env.GatewayType}"
    }
    if ( fileExists("${WORKSPACE}/${HostName}/Gateway_Deployment/After_Internal.txt")) {	  
        after_InternalApache_restart_pid = readFile "./${HostName}/Gateway_Deployment/After_Internal.txt"
        echo "After_InternalApache_Restart : ${after_InternalApache_restart_pid}"
    }else {
        after_InternalApache_restart_pid = "PID not captured"
    }

    // Notify team with status email
    emailext mimeType: 'text/html',
        subject: "[Jenkins]:${currentBuild.fullDisplayName}:${env.GatewayEnvironment} Deployment",
        from:"CICD_GatewayDeploymentStatus@vodafone.com",
        to: "${ops_mailRecipients}",
        body: 	"${get_gatewaybody_build_summary(Host:HostName, DeploymentType:deployType, Status:'Success',  beforeRestart:before_restart_pid, afterRestart:after_restart_pid, beforeExternalApacheRestart:before_externalApache_restart_pid, afterExternalApacheRestart:after_externalApache_restart_pid, beforeInternalApacheRestart:before_InternalApache_restart_pid, afterInternalApacheRestart:after_InternalApache_restart_pid)}"
					
}

def gateway_not_running(deployParams) {
	script{
	        def USER_INPUT = input(
                             message: "${deployParams.GatewayType} Gateway Instance is not running. Select restart/skip to Proceed with Gateway restart ?",
                             parameters: [
                             [$class: 'ChoiceParameterDefinition',
							 choices: ['Restart','Skip'].join('\n'),
							 name: 'input',
							 description: 'Choose Restart or Skip']
							 ])
					      
            if (USER_INPUT == "Restart")
               {
               GatewayFunction.gateway_restart Host:"${deployParams.Host}", GatewayType:"${deployParams.GatewayType}", internalApache:"${deployParams.internalApache}", externalApache:"${deployParams.externalApache}", gatewayRestart:"${deployParams.gatewayRestart}", gatewayEnvironment:"${deployParams.gatewayEnvironment}"

                }
	}
}

def gateway_rollback(deployParams) {
	stash_function()
    ansiColor('xterm') {                
        GatewayFunction.rollback_artefact Host:"${deployParams.Host}", GatewayType:"${env.GatewayType}", crq_no:"${params.CRQ}", datetime:"${date_now}", internalApache:"${internalApache}", externalApache:"${externalApache}", gatewayEnvironment:"${env.GatewayEnvironment}"
	}    
}

def gateway_Precutover(deployParams) {
	stash_function()
    script{		   
		   //Run ansible playbook to disable the crontab entries gateway instances
			ansiColor('xterm') {
	        ansiblePlaybook(playbook: "./${deployParams.Host}/Gateway_Restarts/gateway_Precutover.yml", colorized: true, extras:'-v', extraVars: [host: "${deployParams.Host}", externalApachePrecutover: "${deployParams.externalApachePrecutover}", PrecutoverGateway: "${deployParams.PrecutoverGateway}",GatewayType: "${deployParams.GatewayType}",GatewayEnvironment: "${deployParams.gatewayEnvironment}"])
		  }
    }
}

def gateway_Cutover(deployParams) {
	stash_function()
    script{
		   //Run ansible playbook to disable the crontab entries gateway instances			           
			 ansiColor('xterm') {
	        ansiblePlaybook(playbook: "./${deployParams.Host}/Gateway_Restarts/gateway_Cutover.yml", colorized: true, extras:'-v', extraVars: [host: "${deployParams.Host}", externalApacheCutover: "${deployParams.externalApacheCutover}", CutoverGateway: "${deployParams.CutoverGateway}",GatewayType: "${deployParams.GatewayType}",GatewayEnvironment: "${deployParams.gatewayEnvironment}"])
		  }
    }
}

//date_format_report = new Date().format("dd/MM/yyy HH:mm")
date_now = " "
displayName = " "
emailBody = " "
before_restart_pid = ""

isRBApproved = true


// CICD-1520 Capturing apache PID 
def before_externalApache_restart_pid = ""
def before_InternalApache_restart_pid = ""
def after_externalApache_restart_pid = ""
def after_InternalApache_restart_pid = ""

internalApache = ""
externalApache = ""

user = ""

ops_mailRecipients = "devops-vfuk-integration@vodafone.com, DL-TSSC-AO2-UK-Integration_TIL-RIG_L2@vodafone.com, dl-techvi-ito-ao-deaas-uk-til@vodafone.com"
GatewayInstances = ["Dummy","IGW01_Dublin_5122_6313","IGW01_Dublin_5123_6313","IGW01_Dublin_5124_6313","IGW01_Dublin_5125_6313"]
pipeline {
    agent any
	options {
        preserveStashes(buildCount: 49)
    }

    environment {
		GROUPID = "GATEWAY"
		GatewayType = "IGW01"
		GatewayEnvironment = "Production"
		REPO_URL = "http://195.233.197.150:8081"
		PROD_REPO = "PROD_REPO"
		NEXUS_USER = "admin"
		NEXUS_PASSWD = "admin123"
        Gateway_Approvers = "Ops-User"
        boolean isDisableEnableAlerts = 'true'
        SwindonPipelineJob = "Dummy"
			
		//[CICD-1530] Insert Deployment metadata to release notes DB.
		dbURL = 'jdbc:oracle:thin:@ukorpa1-scan.dc-dublin.de:33000/TIBCPDB_TAF.prod.uk'
		dbUserName = 'CICD_OWN_DB01'
		dbPassword = 'Voda#1010'
		dbDriver = 'oracle.jdbc.driver.OracleDriver'

    }

    stages {
		
        stage("Preparation") {
			steps {
			    deleteDir()
				validate_parameter()
                download_git_repo()
                load_groovy_files()
                initialize_variables()
			}			
		} //end of preparation
        
        stage("Disabling Alerts-RF")
        {
           when { expression { isDisableEnableAlerts == 'true' } }	
           steps
               {
                 script
                   {			    
                         echo "Disabling in GatewayHealthcheck script in All Gateway servers crontab"                         
                         for(counter=1 ; counter<GatewayInstances.size(); counter++)
                         {
                         gateway_Precutover Host: "${GatewayInstances[counter]}", GatewayType:"${env.GatewayType}", externalApachePrecutover:true, PrecutoverGateway:true, gatewayEnvironment:"${env.GatewayEnvironment}"
                         } 
                    }
                }   
        } //Disable Alerts stage ends

        stage("uk5122yr RF1") {
			steps {				
				script {	
                    gatewayRollforward Host: "Dublin_5122_6313", deployType:"RF1"
				}
			}
		}

        stage("uk5123yr RF1") {
			steps {				
				script {	
                    gatewayRollforward Host: "Dublin_5123_6313", deployType:"RF1"
				}
			}
		}
     
        stage("uk5124yr RF1") {
			steps {				
				script {	
                    gatewayRollforward Host: "Dublin_5124_6313", deployType:"RF1"
				}
			}
		}
        
        stage("uk5125yr RF1") {
			steps {				
				script {	
                    gatewayRollforward Host: "Dublin_5125_6313", deployType:"RF1"
				}
			}
		}
      
        stage("Gateway Restart Approval RF1") {
			steps {
				script {
					  	 input message: 'Proceed with Gateway restarts RF1 ?', submitterParameter: 'submitter', submitter: "${GatewayUsers}"
					}
			}
		}
        
        stage("uk5122yr (P)6313 RF1 Restart") {
			steps {
				script {
                     gatewayRestart Host: "IGW01_Dublin_5122_6313", deployType:"RF1"
				}
			}
		}
              
        stage("uk5123yr (P)6313 RF1 Restart") {
			steps {
				script {
                     gatewayRestart Host: "IGW01_Dublin_5123_6313", deployType:"RF1"
				}
			}
		}
                
        stage("uk5124yr (P)6313 RF1 Restart") {
			steps {
				script {
                     gatewayRestart Host: "IGW01_Dublin_5124_6313", deployType:"RF1"
				}
			}
		}
               
        stage("uk5125yr (P)6313 RF1 Restart") {
			steps {
				script {
                     gatewayRestart Host: "IGW01_Dublin_5125_6313", deployType:"RF1"
				}
			}
		}
               
        stage("Enabling Alerts-RF")
        {
           when { expression { isDisableEnableAlerts == 'true' } }	
           steps
               {
                 script
                   {			    
                         echo "Enabling in GatewayHealthcheck script in All Gateway servers crontab"
                         for(counter=1 ; counter<GatewayInstances.size(); counter++)
                         {
                         gateway_Cutover Host: "${GatewayInstances[counter]}", GatewayType:"${env.GatewayType}", externalApacheCutover:true, CutoverGateway:true, gatewayEnvironment:"${env.GatewayEnvironment}"
                         }                         
                    }
                }   
        } //Enabling Alerts stage ends
         
        stage("Gateways Exceptional Scenario") {		 
			steps { 
				script {
					def input_SKIP = input(message: 'Choose Yes to skip with RB ?',
                                     parameters: [[$class: 'ChoiceParameterDefinition', choices: ['No','Yes'].join('\n'),
									 name: 'input',description: 'Choose Yes or No']],
                                     submitterParameter: 'submitter',
                                     submitter: "${GatewayUsers}")
                    echo "input_SKIP ---> ${input_SKIP}"
                    echo "input_SKIP.input ---> ${input_SKIP.input}"
				    if (input_SKIP.input == "Yes"){
					     def inputExceptionApproval = input(message: 'Approve skipping RB for this deployment?',
                                        parameters: [[$class: 'ChoiceParameterDefinition', choices: ['Reject','Approve'].join('\n'),
										name: 'input', description: 'Choose Approve or Reject']],
                                        submitterParameter: 'submitter',
                                        submitter: "${GatewayUsers}")	
                         echo "inputExceptionApproval ---> ${inputExceptionApproval}" 
                        echo "inputExceptionApproval.input ---> ${inputExceptionApproval.input}"                          
                        if (inputExceptionApproval.input == "Approve"){
                                       isRBApproved = false
                        }								                            						
                    }
                    echo "Exceptional Scenario (RB Execute) : ${isRBApproved}"
				}
			}
		} //Gateways Exceptional Scenario stage ends	

        stage("Disabling Alerts-RB")
        {
           when { expression { isDisableEnableAlerts == 'true' &&  isRBApproved == true } }	
           steps
               {
                 script
                   {			    
                         echo "Disabling in GatewayHealthcheck script in All Gateway servers crontab"                         
                         for(counter=1 ; counter<GatewayInstances.size(); counter++)
                         {
                         gateway_Precutover Host: "${GatewayInstances[counter]}", GatewayType:"${env.GatewayType}", externalApachePrecutover:true, PrecutoverGateway:true, gatewayEnvironment:"${env.GatewayEnvironment}"
                         }                         
                    }
                }   
        } //Disable Alerts stage ends

        stage("RB Approval") {
            when { expression {  isRBApproved == true } }
            steps {
                script {
                     input message: 'Proceed with Gateway Rollback ?', submitterParameter: 'submitter', submitter: "${GatewayUsers}"
                }
            }
        } //RB Approval stage ends

        //  Disabling Alerts

        stage("uk5122yr RB") {
            when { expression {  isRBApproved == true } }		
            steps {				
                script {				 
                    gateway_rollback Host: "Dublin_5122_6313", deployType:"RB"                    
                }
            }
                    
        }

        stage("uk5123yr RB") {
            when { expression {  isRBApproved == true } }		
            steps {				
                script {				 
                    gateway_rollback Host: "Dublin_5123_6313", deployType:"RB"                    
                }
            }
                    
        }
        
        stage("uk5124yr RB") {
            when { expression {  isRBApproved == true } }		
            steps {				
                script {				 
                    gateway_rollback Host: "Dublin_5124_6313", deployType:"RB"                    
                }
            }
                    
        }

        stage("uk5125yr RB") {
            when { expression {  isRBApproved == true } }		
            steps {				
                script {				 
                    gateway_rollback Host: "Dublin_5125_6313", deployType:"RB"                    
                }
            }
                    
        }

        stage("Gateway Restart Approval RB") {
            when { expression {  isRBApproved == true } }
            steps {
                script {
                     input message: 'Proceed with Gateway RB Restart ?', submitterParameter: 'submitter', submitter: "${GatewayUsers}"
                }
            }
        } //Gateway Rollback Restart Approval stage ends

        stage("uk5122yr (P)6313 RB Restart") {
            when { expression {  isRBApproved == true } }		
            steps {				
                script {
                    gatewayRestart Host: "IGW01_Dublin_5122_6313", deployType:"RB"                    
                }
            }
                    
        }// RB Restart stage ends

        stage("uk5123yr (P)6313 RB Restart") {
            when { expression {  isRBApproved == true } }		
            steps {				
                script {
                    gatewayRestart Host: "IGW01_Dublin_5123_6313", deployType:"RB"                    
                }
            }
                    
        }// RB Restart stage ends
      
        stage("uk5124yr (P)6313 RB Restart") {
            when { expression {  isRBApproved == true } }		
            steps {				
                script {
                    gatewayRestart Host: "IGW01_Dublin_5124_6313", deployType:"RB"                    
                }
            }
                    
        }// RB Restart stage ends

        stage("uk5125yr (P)6313 RB Restart") {
            when { expression {  isRBApproved == true } }		
            steps {				
                script {
                    gatewayRestart Host: "IGW01_Dublin_5125_6313", deployType:"RB"                    
                }
            }
                    
        }// RB Restart stage ends

        stage("Enabling Alerts-RB")
        {
           when { expression { isDisableEnableAlerts == 'true' &&  isRBApproved == true } }	
           steps
               {
                 script
                   {			    
                         echo "Enabling in GatewayHealthcheck script in All Gateway servers crontab"
                         for(counter=1 ; counter<GatewayInstances.size(); counter++)
                         {
                         gateway_Cutover Host: "${GatewayInstances[counter]}", GatewayType:"${env.GatewayType}", externalApacheCutover:true, CutoverGateway:true, gatewayEnvironment:"${env.GatewayEnvironment}"
                         }                         
                    }
                }   
        } //Enabling Alerts stage ends

        //ADO-753185 - Swindon auto trigger and db update
       
        stage('Swindon Auto Trigger') 
        {
            //when { expression {  isRBApproved == false } }
            steps 
            {
                script 
                {
                    stash_function()
                    def Swindon_inp = input(message: 'Proceed with Swindon Deployment?',
                                        parameters: [
                                        [$class: 'ChoiceParameterDefinition',
                                        choices: ['Yes','No'].join('\n'),
                                        name: 'input',
                                        description: 'Choose Yes if Swindon Deployment required']])
                    if(	Swindon_inp == "Yes")
                    {
                        echo "DEBUG: ArtefactVersion to deploy: ${params.GatewayVersion}"
                        echo "DEBUG: Swindon Trigger mode: YES"
                                        
                        build job: 'Gateway/Swindon/IGW01_Deployment_Pipeline', 
                            parameters: [string(name: 'ReleaseNumber', value: "${params.ReleaseNumber}"), 
                                         string(name: 'GatewayVersion', value:  "${params.GatewayVersion}"), 
                                         string(name: 'CRQ', value: "${params.CRQ}")], wait: false 
                    }						
                }
            }
        }
       
        
        stage("DB Update") {
			steps{
				script{
				  def user = currentBuild.rawBuild.causes[0].userId
				        stash_function()
                        def insert_query = """Insert into CICD_DEPLOYMENT_HISTORY ("Release","DateTime","CRQ","ComponentType","Environment","EngineName","BwVersion","EmsVersion","SqlVersion","GatewayVersion","BwDeploymentType","DeploymentStatus","DeploymentTime","XmlFiles","JarFiles","EmailFiles","RF1Status","RBStatus","RF2Status","DVTStatus","BWConfigTag","ChangeDescription","User","FailureReason","updatedTimestamp","BUILD_ID","BUILD_URL") values ('${params.ReleaseNumber}',sysdate,'${params.CRQ}','GATEWAY','${env.GatewayEnvironment}_Dublin','${env.GatewayType}','','','','${params.GatewayVersion}','','Active','','','','','','','','','','','${user}','PASSED',sysdate, '${BUILD_ID}','${BUILD_URL}')"""		
					
					println("DEBUG: Insert query is: " + insert_query)		
					
					//DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${env.dbUserName}", dbPassword: "${env.dbPassword}", dbDriver: "${env.dbDriver}", insertQuery: insert_query	
                }
            }
        }//Sign off stage Ends
    
    }//stages end
}//pipeline ends 
