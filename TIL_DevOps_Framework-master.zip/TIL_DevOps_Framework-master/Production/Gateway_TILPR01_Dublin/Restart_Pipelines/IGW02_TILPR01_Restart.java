
//import this package as part of the fix
import groovy.time.*

//[CICD-1530] Insert Deployment metadata to release notes DB.
import groovy.json.JsonOutput
import groovy.sql.*
import java.sql.Driver

def get_gatewaybody_build_summary(deployParams){
	def date_format_report = new Date().format("dd/MM/yyy HH:mm")
	def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
		.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		</style>
		<table class="tg" style="undefined;table-layout: fixed; width: 900px">
		<colgroup>
		<col style="width: 100px">
		<col style="width: 350px">
		<col style="width: 100px">
		<col style="width: 350px">
		</colgroup>
		  <tr>
			<td>
			<table width="50%"><tr><td><img width="150" src="https://www.vodafone.co.uk/cs/groups/public/documents/webcontent/1287x929_vodafone_logo.jpg" alt="ITEAMS" style="text-align: right; width: 207px; border: 0; text-decoration:none; vertical-align: baseline;"></td></tr></table>
            <div style="display:none">
			</div>
			</td>
			<th class="tg-amwm" colspan="3">CCS Integration ${env.GatewayEnvironment} Deployment Summary - Restart Pipeline</th>
		  </tr>
		  <tr>
			<td class="tg-1wig">Submitted By</td>
			<td class="tg-0lax">${user}</td>
			<td class="tg-1wig">Date</td>
			<td class="tg-0lax">${date_format_report}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">RELEASE NUMBER & Version</td>
			<td class="tg-0lax"> Restart pipeline </td>
			<td class="tg-1wig">Gateway</td>
			<td class="tg-0lax">${env.GatewayType}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">Deployment Type</td>
			<td class="tg-0lax">${deployParams.DeploymentType}</td>
			<td class="tg-1wig">Status</td>
			<td class="tg-0lax">${deployParams.Status}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">PID before restart</td>
			<td class="tg-0lax">${deployParams.beforeRestart}</td>
			<td class="tg-1wig">PID after restart</td>
			<td class="tg-0lax">${deployParams.afterRestart}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">Before ExternalApache Restart PID</td>
			<td class="tg-0lax">${deployParams.beforeExternalApacheRestart}</td>
			<td class="tg-1wig">After ExternalApache Restart PID</td>
			<td class="tg-0lax">${deployParams.afterExternalApacheRestart}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">Before InternalApache Restart PID</td>
			<td class="tg-0lax">${deployParams.beforeInternalApacheRestart}</td>
			<td class="tg-1wig">After InernalApache Restart PID</td>
			<td class="tg-0lax">${deployParams.afterInternalApacheRestart}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">LOG_URL</td>
			<td class="tg-0lax" colspan="3">${BUILD_URL}/console</td>
		  </tr>		  
		</table>
		<br><br><br>
	"""
	emailBody = body_build_summary
	return body_build_summary
}

def stash_function() {
    script{
	
	      unstash "stashProperties"
		  if (date_now == " ") {
				date_now = sh(script:"cat ./DIR_STASH/propfile | grep -e date | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
				echo "Date after stage restart is:${date_now}"
			}
		  if (displayName == " ") {
				displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
				currentBuild.displayName = "${displayName}_restart"
				echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
                load_groovy_files() 
                if( "${env.GatewayType}" == "IGW01" ) {
                            internalApache = "true"
                            externalApache = "true"
                }else if( "${env.GatewayType}" == "GGW01" || "${env.GatewayType}" == "IGW02" || "${env.GatewayType}" == "EGW" ) {
                    internalApache = "false"
                    externalApache = "true"
                }else  {
                    internalApache = "false"
                    externalApache = "false"
                }                
			}
	
	}
}

def validate_parameter() {
        def validationCheck = ""
        
        //3. Validate CRQ number
        if(CRQ == ""){
            println("CRQ Number should be specified for the Deployment")
            validationCheck = "F"
        }
        if (CRQ.indexOf(' ') != -1){
            println('CRQ parameter should not contain spaces in between')
            validationCheck = "F"
        }

        if(validationCheck == "F"){
			error("Pipeline Input parameter validation failed. Please check the errors in Console log.")
			currentBuild.result = 'ABORTED'
		}        

}

def initialize_variables()
{
        date_now = new Date().format("YYYYMMddHHmmss")
        displayName = "${params.CRQ}"
        currentBuild.displayName = "${displayName}"        
        
        if( "${env.GatewayType}" == "IGW01" ) {
            internalApache = "true"
            externalApache = "true"
        }else if( "${env.GatewayType}" == "GGW01" || "${env.GatewayType}" == "IGW02" || "${env.GatewayType}" == "EGW" ) {
            internalApache = "false"
            externalApache = "true"
        }else  {
            internalApache = "false"
            externalApache = "false"
        }
        
        println "Apache Details --> ${env.GatewayType},internalApache:${internalApache},externalApache:${externalApache}"
        
        
        //Stash the important values so that these can be retrieved for stage restart.
        sh "mkdir -p DIR_STASH"
        sh "echo date:${date_now} >DIR_STASH/propfile"
        sh "echo displayName:${displayName} >>DIR_STASH/propfile"
        stash includes: 'DIR_STASH/propfile', name: 'stashProperties'
}

def download_git_repo() {
    //Checkout Environment Configurations
    checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'PROD_Conf']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Production_Configuration.git']]])
    //Checkout for Common Functions
    checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'JENKINS_FILE']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_DevOps_Framework.git']]])
    //Checkout for Gateway Deployment. Will be downloaded while deployment stage for each host
    //checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'Gateway']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]])
    load_groovy_files()
    for(counter=1 ; counter<GatewayInstances.size(); counter++)
    {     
        checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${GatewayInstances[counter]}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]])
        GatewayFunction.gateway_code Host:"${GatewayInstances[counter]}", GatewayType:"${env.GatewayType}", gatewayEnvironment:"${env.GatewayEnvironment}"
    }
    sh "cp -r ./PROD_Conf/Gateway_Configuration ./"
}

def load_groovy_files() {    
    GatewayFunction = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/GatewayFunctions.groovy"
    DB_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/dbFunctions.groovy"
    commonFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/commonFunctions.groovy"
    
    GatewayUsers = commonFunctions.get_approvers_list('${Gateway_Approvers}')
    user = currentBuild.rawBuild.causes[0].userId
}

def gatewayRestart(deployParams) {
    stash_function()
    HostName = deployParams.Host
    deployType = deployParams.deployType
    GatewayFunction.gateway_pid Host:"${HostName}", GatewayType:"${env.GatewayType}"
    before_restart_pid = readFile "${HostName}/Gateway_Deployment/${HostName}_pid.txt"
    echo "Gateway PID is:${before_restart_pid}"
                
    // Check status of gateway and ask for user input if gateway in stopped state
    // get Gateway status by calling ansible gateway_status function
    GatewayFunction.gateway_status Host:"${HostName}", GatewayType:"${env.GatewayType}"
    def gatewayStatus = readFile "${HostName}/Gateway_Deployment/${HostName}_status.txt"
    echo "Gateway Status is:${gatewayStatus}"

    if (gatewayStatus == "0"){
        echo "gateway is running hence restarting"
        GatewayFunction.gateway_restart Host:"${HostName}", GatewayType:"${env.GatewayType}", internalApache:"${internalApache}", externalApache:"${externalApache}", gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
        
    }
    else {
        echo "gateway is not running"
        gateway_not_running Host:"${HostName}", GatewayType:"${env.GatewayType}", internalApache:"${internalApache}", externalApache:"${externalApache}", gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
    }
    // get Gateway PID by calling ansible gateway_pid function
    GatewayFunction.gateway_pid Host:"${HostName}", GatewayType:"${env.GatewayType}"
    after_restart_pid = readFile "${HostName}/Gateway_Deployment/${HostName}_pid.txt"
    echo "Gateway PID is:${after_restart_pid}"	
                
    // CICD-1520 Capturing apache PID 
    if ( fileExists("${WORKSPACE}/${HostName}/Gateway_Deployment/Before_External.txt")) {			
        before_externalApache_restart_pid = readFile "./${HostName}/Gateway_Deployment/Before_External.txt"
        echo "Before_ExternalApache_Restart : ${before_externalApache_restart_pid}"
    }else {
        before_externalApache_restart_pid = "No ExternalApache For ${env.GatewayType}"
    }

    if ( fileExists("${WORKSPACE}/${HostName}/Gateway_Deployment/Before_Internal.txt")) {	  
        before_InternalApache_restart_pid = readFile "./${HostName}/Gateway_Deployment/Before_Internal.txt"
        echo "Before_InternalApache_Restart : ${before_InternalApache_restart_pid}"
    }else {
        before_InternalApache_restart_pid = "No InternalApache For ${env.GatewayType}"
    }

    if ( fileExists("${WORKSPACE}/${HostName}/Gateway_Deployment/After_External.txt")) {		
        after_externalApache_restart_pid = readFile "./${HostName}/Gateway_Deployment/After_External.txt"
        echo "After_ExternalApache_Restart : ${after_externalApache_restart_pid}"
    }else {
        after_externalApache_restart_pid = "No ExternalApache For ${env.GatewayType}"
    }

    if ( fileExists("${WORKSPACE}/${HostName}/Gateway_Deployment/After_Internal.txt")) {	  
        after_InternalApache_restart_pid = readFile "./${HostName}/Gateway_Deployment/After_Internal.txt"
        echo "After_InternalApache_Restart : ${after_InternalApache_restart_pid}"
    }else {
        after_InternalApache_restart_pid = "No InternalApache For ${env.GatewayType}"
    }

    // Notify team with status email
    emailext mimeType: 'text/html',
        subject: "[Jenkins]:${currentBuild.fullDisplayName}:${env.GatewayEnvironment} Deployment",
        from:"CICD_GatewayDeploymentStatus@vodafone.com",
        to: "${ops_mailRecipients}",
        body: 	"${get_gatewaybody_build_summary(DeploymentType:deployType, Status:'Success',  beforeRestart:before_restart_pid, afterRestart:after_restart_pid, beforeExternalApacheRestart:before_externalApache_restart_pid, afterExternalApacheRestart:after_externalApache_restart_pid, beforeInternalApacheRestart:before_InternalApache_restart_pid, afterInternalApacheRestart:after_InternalApache_restart_pid)}"
					
}

def gateway_not_running(deployParams) {
	script{
	        def USER_INPUT = input(
                             message: "${deployParams.GatewayType} Gateway Instance is not running. Select restart/skip to Proceed with Gateway restart ?",
                             parameters: [
                             [$class: 'ChoiceParameterDefinition',
							 choices: ['Restart','Skip'].join('\n'),
							 name: 'input',
							 description: 'Choose Restart or Skip']
							 ])
					      
            if (USER_INPUT == "Restart")
               {
               GatewayFunction.gateway_restart Host:"${deployParams.Host}", GatewayType:"${deployParams.GatewayType}", internalApache:"${deployParams.internalApache}", externalApache:"${deployParams.externalApache}", gatewayRestart:"${deployParams.gatewayRestart}", gatewayEnvironment:"${deployParams.gatewayEnvironment}"

                }
	}
}

def gateway_Precutover(deployParams) {
	stash_function()
    script{		   
		   //Run ansible playbook to disable the crontab entries gateway instances
			ansiColor('xterm') {
	        ansiblePlaybook(playbook: "./${deployParams.Host}/Gateway_Restarts/gateway_Precutover.yml", colorized: true, extras:'-v', extraVars: [host: "${deployParams.Host}", externalApachePrecutover: "${deployParams.externalApachePrecutover}", PrecutoverGateway: "${deployParams.PrecutoverGateway}",GatewayType: "${deployParams.GatewayType}",GatewayEnvironment: "${deployParams.gatewayEnvironment}"])
		  }
    }
}

def gateway_Cutover(deployParams) {
	stash_function()
    script{
		   //Run ansible playbook to disable the crontab entries gateway instances			           
			 ansiColor('xterm') {
	        ansiblePlaybook(playbook: "./${deployParams.Host}/Gateway_Restarts/gateway_Cutover.yml", colorized: true, extras:'-v', extraVars: [host: "${deployParams.Host}", externalApacheCutover: "${deployParams.externalApacheCutover}", CutoverGateway: "${deployParams.CutoverGateway}",GatewayType: "${deployParams.GatewayType}",GatewayEnvironment: "${deployParams.gatewayEnvironment}"])
		  }
    }
}

//date_format_report = new Date().format("dd/MM/yyy HH:mm")
date_now = " "
displayName = " "
emailBody = " "
before_restart_pid = ""

isRBApproved = true
stagingSkipApprovers = ""


// CICD-1520 Capturing apache PID 
def before_externalApache_restart_pid = ""
def before_InternalApache_restart_pid = ""
def after_externalApache_restart_pid = ""
def after_InternalApache_restart_pid = ""

internalApache = ""
externalApache = ""

// [CICD-1530]: Push all the deployment details to Release notes DB. 
user = ""

//ops_mailRecipients = "devops-vfuk-integration@vodafone.com;sweety.kumari@vodafone.com;shivam.pandey2@vodafone.com"
ops_mailRecipients = "DL-TSSC-AO2-UK-Integration_TIL-RIG_L2@vodafone.com, devops-vfuk-integration@vodafone.com, dl-techvi-ito-ao-deaas-uk-til@vodafone.com"
GatewayInstances = ["Dummy","IGW02_Dublin_5122_6413","IGW02_Dublin_5122_6423","IGW02_Dublin_5123_6413","IGW02_Dublin_5123_6423","IGW02_Dublin_5124_6413","IGW02_Dublin_5124_6423","IGW02_Dublin_5125_6413","IGW02_Dublin_5125_6423"]

pipeline {
    agent any
	options {
        preserveStashes(buildCount: 49)
    }

    environment {
		GROUPID = "GATEWAY"
		GatewayType = "IGW02"
		//GatewayEnvironment = "TILPR01"
		GatewayEnvironment = "Production"
		REPO_URL = "http://195.233.197.150:8081"
		//STAGING_REPO = "STAGING_REPO"
		PROD_REPO = "PROD_REPO"
		NEXUS_USER = "admin"
		NEXUS_PASSWD = "admin123"
        Gateway_Approvers = "GatewayUsers"
        boolean isDisableEnableAlerts = 'true'
        //SwindonPipelineJob = "TILSTG01/Gateway_pipelines/Deployment_pipelines/Swindon"
			
		//[CICD-1530] Insert Deployment metadata to release notes DB.
		dbURL = 'jdbc:oracle:thin:@195.233.199.13:33000:TIBTST1'
		dbUserName = 'CICD_OWN_DB01'
		dbPassword = 'TIL_CICD_DB'
		dbDriver = 'oracle.jdbc.driver.OracleDriver'

    }

    stages {
		
        stage("Preparation") {
			steps {
			    deleteDir()
				validate_parameter()
                download_git_repo()
                load_groovy_files()
                initialize_variables()
			}			
		} //end of preparation
        
        stage("Disabling Alerts")
        {
           when { expression { isDisableEnableAlerts == 'true' } }	
           steps
               {
                 script
                   {			    
                         echo "Disabling in GatewayHealthcheck script in All Gateway servers crontab"                         
                         for(counter=1 ; counter<GatewayInstances.size(); counter++)
                         {
                         gateway_Precutover Host: "${GatewayInstances[counter]}", GatewayType:"${env.GatewayType}", externalApachePrecutover:"${externalApache}", PrecutoverGateway:true, gatewayEnvironment:"${env.GatewayEnvironment}"
                         }                         
                    }
                }   
        } //Disable Alerts stage ends

        stage("uk5122yr (P)6413 Restart") {
			steps {
				script {
                     gatewayRestart Host: "${GatewayInstances[1]}", deployType:"Restart"
				}
			}
		}
        
        stage("uk5122yr (P)6423 Restart") {
			steps {
				script {
                     gatewayRestart Host: "${GatewayInstances[2]}", deployType:"Restart"
				}
			}
		}
        
        stage("uk5123yr (P)6413 Restart") {
			steps {
				script {
                     gatewayRestart Host: "${GatewayInstances[3]}", deployType:"Restart"
				}
			}
		}
        
        stage("uk5123yr (P)6423 Restart") {
			steps {
				script {
                     gatewayRestart Host: "${GatewayInstances[4]}", deployType:"Restart"
				}
			}
		}       
		stage("uk5124yr (P)6413 Restart") {
			steps {
				script {
                     gatewayRestart Host: "${GatewayInstances[5]}", deployType:"Restart"
				}
			}
		}
		stage("uk5124yr (P)6423 Restart") {
			steps {
				script {
                     gatewayRestart Host: "${GatewayInstances[6]}", deployType:"Restart"
				}
			}
		}
		stage("uk5125yr (P)6413 Restart") {
			steps {
				script {
                     gatewayRestart Host: "${GatewayInstances[7]}", deployType:"Restart"
				}
			}
		}
		stage("uk5125yr (P)6423 Restart") {
			steps {
				script {
                     gatewayRestart Host: "${GatewayInstances[8]}", deployType:"Restart"
				}
			}
		}
        
                stage("Enabling Alerts")
        {
           when { expression { isDisableEnableAlerts == 'true' } }	
           steps
               {
                 script
                   {			    
                         echo "Enabling in GatewayHealthcheck script in All Gateway servers crontab"
                         for(counter=1 ; counter<GatewayInstances.size(); counter++)
                         {
                         gateway_Cutover Host: "${GatewayInstances[counter]}", GatewayType:"${env.GatewayType}", externalApacheCutover:"${externalApache}", CutoverGateway:true, gatewayEnvironment:"${env.GatewayEnvironment}"
                         }                             
                    }
                }   
        } //Enabling Alerts stage ends
        
    }//stages end
}//pipeline ends 
