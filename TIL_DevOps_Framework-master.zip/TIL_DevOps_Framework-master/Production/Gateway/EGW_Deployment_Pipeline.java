//import this package as part of the creating github code and swindon autotrigger
import groovy.time.*
import groovy.json.JsonOutput
import groovy.sql.*
import java.sql.Driver

ops_mailRecipients = "devops-vfuk-integration@vodafone.com, DL-TSSC-AO2-UK-Integration_TIL-RIG_L2@vodafone.com"

// Funcation to Get jenkins users from the given role
def get_approvers_list(String str){
	outlist = sh (script: """cat /opt/SP/tibco/.jenkins/config.xml | sed -n \'/role name=\"${str}\"/,\$p\' | sed \'/role>/q\' | grep "sid" | cut -d \'>\' -f 2 | cut -d \'<\' -f 1 | paste -s -d, -""",
			returnStdout: true).trim()
	return """${outlist}"""
}

def get_body_build_summary(deployParams){
	def date_format_report = new Date().format("dd/MM/yyy HH:mm")
	def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
		.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		</style>
		<table class="tg" style="undefined;table-layout: fixed; width: 900px">
		<colgroup>
		<col style="width: 100px">
		<col style="width: 350px">
		<col style="width: 100px">
		<col style="width: 350px">
		</colgroup>
		  <tr>
			<td>
			<table width="50%"><tr><td><img width="150" src="https://www.vodafone.co.uk/cs/groups/public/documents/webcontent/1287x929_vodafone_logo.jpg" alt="ITEAMS" style="text-align: right; width: 207px; border: 0; text-decoration:none; vertical-align: baseline;"></td></tr></table>
          <div style="display:none">
			</div>
			</td>
			<th class="tg-amwm" colspan="3">CCS Integration Production Deployment Summary ${params.ReleaseNumber}</th>
		  </tr>
		  <tr>
			<td class="tg-1wig">Submitted By</td>
			<td class="tg-0lax">${currentBuild.getRawBuild().getCauses()[0].getUserId()}</td>
			<td class="tg-1wig">Date</td>
			<td class="tg-0lax">${date_format_report}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">RELEASE NUMBER & VERSION </td>
			<td class="tg-0lax">${params.ReleaseNumber} & ${params.GatewayVersion}</td>
			<td class="tg-1wig">Gateway</td>
			<td class="tg-0lax">${env.GatewayType}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">Deployment Type</td>
			<td class="tg-0lax">${deployParams.DeploymentType}</td>
			<td class="tg-1wig">Status</td>
			<td class="tg-0lax">${deployParams.Status}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">uktlpehr_6180 PID before restart</td>
			<td class="tg-0lax">${deployParams.beforeRestart}</td>
			<td class="tg-1wig">uktlpehr_6180 PID after restart</td>
			<td class="tg-0lax">${deployParams.afterRestart}</td>
		  </tr>	
		  <tr>
			<td class="tg-1wig">uktlpfhr_6180 PID before restart</td>
			<td class="tg-0lax">${deployParams.beforeRestart1}</td>
			<td class="tg-1wig">uktlpfhr_6180 PID after restart</td>
			<td class="tg-0lax">${deployParams.afterRestart1}</td>
		  </tr>	
		  <tr>
			<td class="tg-1wig">Before ExternalApache Restart for ukwspavr 9180</td>
			<td class="tg-0lax">${deployParams.beforeExtApacheRestart1}</td>
			<td class="tg-1wig">After ExternalApache Restart for ukwspavr 9180</td>
			<td class="tg-0lax">${deployParams.afterExtApacheRestart1}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">Before ExternalApache Restart for ukwspbvr 9180</td>
			<td class="tg-0lax">${deployParams.beforeExtApacheRestart2}</td>
			<td class="tg-1wig">After ExternalApache Restart for ukwspbvr 180</td>
			<td class="tg-0lax">${deployParams.beforeExtApacheRestart2}</td>
		  </tr>			  
		  <tr>
			<td class="tg-1wig">LOG_URL</td>
			<td class="tg-0lax" colspan="3">${BUILD_URL}/console</td>
		  </tr>		  
		</table>
		<br><br><br>
	"""
	emailBody = body_build_summary
	writeFile file: "${WORKSPACE}/Reports/${deployParams.DeploymentType}_Report.html", text: emailBody 
	writeFile file: "/opt/SP/tibco/.jenkins/userContent/Gateway/${env.GatewayType}/${params.ReleaseNumber}/${params.GatewayVersion}/${deployParams.DeploymentType}_Report.html", text: emailBody 
	
	return body_build_summary
}

def stash_function() {
    script{
	
	      unstash "stashProperties"
		  if (date_now == " ") {
				date_now = sh(script:"cat ./DIR_STASH/propfile | grep -e date | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
				echo "Date after stage restart is:${date_now}"
			}
		  if (displayName == " ") {
				displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
				currentBuild.displayName = "${displayName}_restart"
				echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
                load_groovy_files()                
			}
	
	}
}

def load_groovy_files() 
{
    //Checkout Environment Configurations
    git credentialsId: 'GITHUBKEY', poll: false, url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Production_Configuration.git'
    //Checkout for Common Functions
    checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'JENKINS_FILE']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_DevOps_Framework.git']]])
    //Checkout Ops Automation Repo. Only For Production
    //checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Ops_Automation_Framework.git']]]        
    
	GatewayFunction = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/GatewayFunctions.groovy"
    DB_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/dbFunctions.groovy"
    commonFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/commonFunctions.groovy"
    
    GatewayUsers = commonFunctions.get_approvers_list('${Gateway_Approvers}')
    user = currentBuild.rawBuild.causes[0].userId
}


def deploy_artefact(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
			
			// Copy host configutaion files to Ansible deployment script location
			//sh "cp -r ./${deployParams.Host}/Gateway_Configuration/${deployParams.GatewayType}/${deployParams.gatewayEnvironment}/* ./${deployParams.Host}/Gateway_Deployment/"
			sh "cp -r ./Gateway_Configuration/${deployParams.GatewayType}/${deployParams.gatewayEnvironment}/* ./${deployParams.Host}/Gateway_Deployment/"
			
			// copy host variables from configuration to ansible host vars folder
			sh "cp ./${deployParams.Host}/Gateway_Deployment/${deployParams.GatewayType}_${deployParams.Host} ./${deployParams.Host}/Gateway_Deployment/host_vars/"
			// Generate host vars file for external apache
			sh "cp ./${deployParams.Host}/Gateway_Deployment/${deployParams.GatewayType}_${deployParams.Host} ./${deployParams.Host}/Gateway_Deployment/host_vars/${deployParams.GatewayType}_${deployParams.Host}_ExternalApache"
			// Generate host vars file for internal apache
			sh "cp ./${deployParams.Host}/Gateway_Deployment/${deployParams.GatewayType}_${deployParams.Host} ./${deployParams.Host}/Gateway_Deployment/host_vars/${deployParams.GatewayType}_${deployParams.Host}_InternalApache"
            // rename tokens file to instance specific
			sh "cp ./${deployParams.Host}/Gateway_Deployment/Tokens/${deployParams.GatewayType}_${deployParams.gatewayEnvironment} ./${deployParams.Host}/Gateway_Deployment/Tokens/${deployParams.GatewayType}_${deployParams.Host}"
            
			//sh "cp ./${deployParams.Host}/Gateway_Deployment/${deployParams.GatewayType}_${deployParams.Host}_* ./${deployParams.Host}/Gateway_Deployment/host_vars/"
			echo "DEBUG: nexus_ArtefactVersion is: ${deployParams.nexus_ArtefactVersion}"
		
			//Run ansible playbook to deploy artefacts into environment
			 ansiColor('xterm') {
    	    ansiblePlaybook(playbook: "./${deployParams.Host}/Gateway_Deployment/Ops_Deploy.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.GatewayType}_${deployParams.Host}", repo_group_id: "${deployParams.nexus_group_id}", repo_artifact_id: "${deployParams.nexus_artifact_id}", repo_user: "${deployParams.nexus_user}", repo_pw: "${deployParams.nexus_passwd}", repo_repo_id: "${deployParams.nexus_repo_id}", repo_version: "${deployParams.nexus_ArtefactVersion}", repo_url: "${deployParams.nexus_url}", datetime: "${deployParams.datetime}", crq_no: "${deployParams.crq_no}", gatewayRestart: "${deployParams.gatewayRestart}", deployType: "${deployParams.deployType}"])
	
			}
    }
}
def gateway_restart(deployParams) {
	script{
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
			//Run ansible playbook to restart gateway instances
			 ansiColor('xterm') {
    	    ansiblePlaybook(playbook: "./${deployParams.Host}/Gateway_Deployment/Ops_Restart.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.GatewayType}_${deployParams.Host}", externalApache: "${deployParams.externalApache}", internalApache: "${deployParams.internalApache}", gatewayRestart: "${deployParams.gatewayRestart}"])

		  }
    }
}

def rollback_artefact(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{
		   checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
			ansiColor('xterm') {		
			 //Run ansible playbook to rollback deployed changes
			 ansiblePlaybook(playbook: "./${deployParams.Host}/Gateway_Deployment/rollback.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.GatewayType}_${deployParams.Host}", datetime: "${deployParams.datetime}", crq_no: "${deployParams.crq_no}", externalApache: "${deployParams.externalApache}", internalApache: "${deployParams.internalApache}"])
	         }
	}
}

def gateway_status(deployParams) {
	script{
			//Run ansible playbook to get gateway status
			 ansiColor('xterm') {
    	    ansiblePlaybook(playbook: "./${deployParams.Host}/Gateway_Deployment/gatewayStatus.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.GatewayType}_${deployParams.Host}"])

		  }
    }
}

def gateway_pid(deployParams) {
	script{
			//Run ansible playbook to get gateway status
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
			 ansiColor('xterm') {
    	    ansiblePlaybook(playbook: "./${deployParams.Host}/Gateway_Deployment/gatewayPID.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.GatewayType}_${deployParams.Host}"])

		  }
    }
}

def gateway_not_running(deployParams) {
	script{
	        def USER_INPUT = input(
                              message: 'EGW Gateway Instance is not running. Select restart/skip to proceed with gateway restart ?',
                               parameters: [
                                 [$class: 'ChoiceParameterDefinition',
									choices: ['Restart','Skip'].join('\n'),
									name: 'input',
									description: 'Choose Restart or Skip']
									])
					      
						  if (USER_INPUT == "Restart")
					           {
						       gateway_restart Host:"${deployParams.Host}", GatewayType:"${deployParams.GatewayType}", internalApache:"${deployParams.internalApache}", externalApache:"${deployParams.externalApache}", gatewayRestart:"${deployParams.gatewayRestart}", gatewayEnvironment:"${deployParams.gatewayEnvironment}"
			
                                }
	}
}

def gateway_Precutover(deployParams) {
	script{
		   
		   checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}_Ops"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Ops_Automation_Framework.git']]]
			//Run ansible playbook to disable the crontab entries gateway instances
			 ansiColor('xterm') {
	        ansiblePlaybook(playbook: "./${deployParams.Host}_Ops/Gateway_Restarts/gateway_Precutover.yml", colorized: true, extras:'-v', extraVars: [host: "${deployParams.GatewayType}_${deployParams.Host}", externalApachePrecutover: "${deployParams.externalApachePrecutover}", PrecutoverGateway: "${deployParams.PrecutoverGateway}",GatewayType: "${deployParams.GatewayType}",GatewayEnvironment: "${deployParams.gatewayEnvironment}"])
		  }
    }
}

def gateway_Cutover(deployParams) {
	script{
		   checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}_Ops"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Ops_Automation_Framework.git']]]		    
			//Run ansible playbook to disable the crontab entries gateway instances
			 ansiColor('xterm') {
	        ansiblePlaybook(playbook: "./${deployParams.Host}_Ops/Gateway_Restarts/gateway_Cutover.yml", colorized: true, extras:'-v', extraVars: [host: "${deployParams.GatewayType}_${deployParams.Host}", externalApacheCutover: "${deployParams.externalApacheCutover}", CutoverGateway: "${deployParams.CutoverGateway}",GatewayType: "${deployParams.GatewayType}",GatewayEnvironment: "${deployParams.gatewayEnvironment}"])
		  }
    }
}

// Global Parameters to use in the stages.

date_now = " "
displayName = " "
emailBody = " "
Rollback_Approval = true
Rollback_Scenario = true
before_restart_240_6180_pid = ""
after_restart_240_6180_pid = ""
before_restart_241_6180_pid = ""
after_restart_241_6180_pid = ""
prodRollbackApprovers = ""

before_extApache_restart_240_6180_pid = ""
after_extApache_restart_240_6180_pid = ""
before_extApache_restart_241_6180_pid = ""
after_extApache_restart_241_6180_pid = ""
before_IntApache_restart_240_6180_pid = ""
before_IntApache_restart_240_6180_pid = ""
before_IntApache_restart_241_6180_pid = ""
after_IntApache_restart_241_6180_pid = ""

pipeline {
    agent any
	options {
        preserveStashes(buildCount: 49)
    }

    environment {
		GROUPID = "GATEWAY"
		GatewayType = "EGW"
		GatewayEnvironment = "Production"
		REPO_URL = "http://195.233.197.150:8081"
		PROD_REPO = "PROD_REPO"
		NEXUS_USER = "admin"
		NEXUS_PASSWD = "admin123"
		dbURL = 'jdbc:oracle:thin:@ukorpa1-scan.dc-dublin.de:33000/TIBCPDB_TAF.prod.uk'
		dbUserName = 'CICD_OWN_DB01'
		dbPassword = 'Voda#1010'
		dbDriver = 'oracle.jdbc.driver.OracleDriver'

    }

    stages {
		stage('Preparation') {
			steps {
			    deleteDir()
				//Checkout Environment Configurations
				git credentialsId: 'GITHUBKEY', poll: false, url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Production_Configuration.git'
				
				echo "Gateway Type selected is:${GatewayType}"
				echo "Release number selected is: ${params.ReleaseNumber}"
				script{
				    	if (CRQ.indexOf(' ') != -1){
						         currentBuild.result = 'ABORTED'
                                 error('CR Number / IRIS Number should not contain spaces in between')
						       }
				    date_now = new Date().format("YYYYMMddHHmmss")
					displayName = "${params.ReleaseNumber}_${params.CRQ}"
					currentBuild.displayName = "${displayName}"
					//Stash the important values so that these can be retrieved for stage restart.
					sh "mkdir -p DIR_STASH"
					sh "echo date:${date_now} >DIR_STASH/propfile"
					sh "echo displayName:${displayName} >>DIR_STASH/propfile"
					stash includes: 'DIR_STASH/propfile', name: 'stashProperties'
				}
				echo "date:${date_now}"

						
			}			
		}

	stage("Disabling Alerts-RF")
	{
	   steps
	       {
			 script
			   {			    
				     echo "Disabling in GatewayHealthcheck script in All Gateway servers crontab"
				     echo "Disabling in GatewayHealthcheck script in uktlpehr Gateway server crontab"
					 gateway_Precutover Host:'Production_240_6180', GatewayType:"${env.GatewayType}", externalApachePrecutover:true, PrecutoverGateway:true, gatewayEnvironment:"${env.GatewayEnvironment}"
                     echo "Disabling in GatewayHealthcheck script in uktlpfhr Gateway server crontab"						
				     gateway_Precutover Host:'Production_241_6180', GatewayType:"${env.GatewayType}", externalApachePrecutover:true, PrecutoverGateway:true, gatewayEnvironment:"${env.GatewayEnvironment}"								  
			}
		}
	}
	
	stage("EGW uktlpehr Deployment") {
			steps {
				// This stage is for deployment.
				script {
				 
				    // If the following values are blank, it means we are starting from stage and need to retrive the values from stash.
					unstash "stashProperties"
					if (date_now == " ") {
						date_now = sh(script:"cat ./DIR_STASH/propfile | grep -e date | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						echo "Date after stage restart is:${date_now}"
					}
					if (displayName == " ") {
						displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						currentBuild.displayName = "${displayName}_restart"
						echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
					}
					echo "Date without stage restart is:${date_now}"
					// Call deploy function by providing Prod Details.
					// commenting for test
					deploy_artefact Host:'Production_240_6180', nexus_group_id:"${env.GROUPID}", nexus_artifact_id:"${env.GatewayType}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.PROD_REPO}", nexus_ArtefactVersion:"${params.GatewayVersion}", GatewayType:"${env.GatewayType}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CRQ}", datetime:"${date_now}", gatewayRestart:false, gatewayEnvironment:"${env.GatewayEnvironment}", deployType:"RF1"
				}
			}
		}
		
	stage("EGW uktlpfhr Deployment") {
			steps {
				// This stage is for deployment.
				script {
				 
				    // If the following values are blank, it means we are starting from stage and need to retrive the values from stash.
					unstash "stashProperties"
					if (date_now == " ") {
						date_now = sh(script:"cat ./DIR_STASH/propfile | grep -e date | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						echo "Date after stage restart is:${date_now}"
					}
					if (displayName == " ") {
						displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						currentBuild.displayName = "${displayName}_restart"
						echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
					}
					echo "Date without stage restart is:${date_now}"
					// Call deploy function by providing Production Details.
					deploy_artefact Host:'Production_241_6180', nexus_group_id:"${env.GROUPID}", nexus_artifact_id:"${env.GatewayType}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.PROD_REPO}", nexus_ArtefactVersion:"${params.GatewayVersion}", GatewayType:"${env.GatewayType}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CRQ}", datetime:"${date_now}", gatewayRestart:false, gatewayEnvironment:"${env.GatewayEnvironment}", deployType:"RF1"
				}
			}
		}

	

	
		stage("Gateway Restart Approval") {
			steps {
				script {
					  	 input 'Proceed with gateway restarts ?'
					}
			}
		}
	
		stage("Restart EGW uktlpehr_6180 Gateway") {
			steps {
				script {
					// If the following values are blank, it means we are starting from stage and need to retrive the values from stash.
					unstash "stashProperties"
					if (date_now == " ") {
						date_now = sh(script:"cat ./DIR_STASH/propfile | grep -e date | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						echo "Date after stage restart is:${date_now}"
					}
					if (displayName == " ") {
						displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						currentBuild.displayName = "${displayName}_restart"
						echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
					}
					
					// get Gateway PID by calling ansible gateway_pid function
                    gateway_pid Host:'Production_240_6180', GatewayType:"${env.GatewayType}"
					
					before_restart_240_6180_pid = readFile 'Production_240_6180/Gateway_Deployment/EGW_Production_240_6180_pid.txt'
					
					echo "Gateway PID is:${before_restart_240_6180_pid}"
					
					// Check status of gateway and ask for user input if gateway in stopped state
					// get Gateway status by calling ansible gateway_status function
                    gateway_status Host:'Production_240_6180', GatewayType:"${env.GatewayType}"
					
					def gatewayStatus = readFile 'Production_240_6180/Gateway_Deployment/EGW_Production_240_6180_status.txt'
					
					echo "Gateway Status is:${gatewayStatus}"
					
					if (gatewayStatus == "0"){
					 
					     echo "gateway is running hence restarting"
						 gateway_restart Host:'Production_240_6180', GatewayType:"${env.GatewayType}", internalApache:true, externalApache:true, gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
			
					  }
					 else {
                        echo "gateway is not running"
						gateway_not_running Host:'Production_240_6180', GatewayType:"${env.GatewayType}", internalApache:true, externalApache:true, gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
					         									
                         }
					// get Gateway PID by calling ansible gateway_pid function
                    gateway_pid Host:'Production_240_6180', GatewayType:"${env.GatewayType}"
					
					after_restart_240_6180_pid = readFile 'Production_240_6180/Gateway_Deployment/EGW_Production_240_6180_pid.txt'
					
					echo "Gateway PID is:${after_restart_240_6180_pid}"	 
				}
			}
		}
		
		
		stage("Restart EGW uktlpfhr_6180 Gateway") {
			steps {
				script {
					// If the following values are blank, it means we are starting from stage and need to retrive the values from stash.
					unstash "stashProperties"
					if (date_now == " ") {
						date_now = sh(script:"cat ./DIR_STASH/propfile | grep -e date | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						echo "Date after stage restart is:${date_now}"
					}
					if (displayName == " ") {
						displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						currentBuild.displayName = "${displayName}_restart"
						echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
					}
					
					// get Gateway PID by calling ansible gateway_pid function
                    gateway_pid Host:'Production_241_6180', GatewayType:"${env.GatewayType}"
					
					before_restart_241_6180_pid = readFile 'Production_241_6180/Gateway_Deployment/EGW_Production_241_6180_pid.txt'
					
					echo "Gateway PID is:${before_restart_241_6180_pid}"
					
					// Check status of gateway and ask for user input if gateway in stopped state
					// get Gateway status by calling ansible gateway_status function
                    gateway_status Host:'Production_241_6180', GatewayType:"${env.GatewayType}"
					
					def gatewayStatus = readFile 'Production_241_6180/Gateway_Deployment/EGW_Production_241_6180_status.txt'
					
					echo "Gateway Status is:${gatewayStatus}"
					
					if (gatewayStatus == "0"){
					 
					     echo "gateway is running hence restarting"
						 gateway_restart Host:'Production_241_6180', GatewayType:"${env.GatewayType}", internalApache:true, externalApache:true, gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
			
					  }
					 else {
                        echo "gateway is not running"
						gateway_not_running Host:'Production_241_6180', GatewayType:"${env.GatewayType}", internalApache:true, externalApache:true, gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
					     
                         }
					// get Gateway PID by calling ansible gateway_pid function
                    gateway_pid Host:'Production_241_6180', GatewayType:"${env.GatewayType}"
					
					after_restart_241_6180_pid = readFile 'Production_241_6180/Gateway_Deployment/EGW_Production_241_6180_pid.txt'
					
					echo "Gateway PID is:${after_restart_241_6180_pid}"	

                     // Notify team with status email
					emailext mimeType: 'text/html',
						 subject: "[Jenkins]:${currentBuild.fullDisplayName}:Production Deployment:${params.ReleaseNumber}",
						 from:"CICD_GatewayDeploymentStatus@vodafone.com",
						 to: "${ops_mailRecipients}",
                         body: 	"${get_body_build_summary(DeploymentType:'RollForward', Status:'Success', beforeRestart:before_restart_240_6180_pid,afterRestart:after_restart_240_6180_pid,beforeRestart1:before_restart_241_6180_pid,afterRestart1:after_restart_241_6180_pid,beforeExtApacheRestart1:before_extApache_restart_240_6180_pid,afterExtApacheRestart1:after_extApache_restart_240_6180_pid,beforeExtApacheRestart2:before_extApache_restart_241_6180_pid,afterExtApacheRestart2:after_extApache_restart_241_6180_pid)}"
					
					echo "Deployment Summary : https://198.18.76.204:9080/jenkins/userContent/Gateway/${env.GatewayType}/${params.ReleaseNumber}/${params.GatewayVersion}/RollForward_Report.html"				
                    
				}
			}
		}
	stage("Enabling Alerts-RF")
	{
	   steps
	       {
			 script
			   {	
		    
				     echo "Enabling in GatewayHealthcheck script in All Gateway servers crontab"
				     echo "Enabling in GatewayHealthcheck script in uktlpehr Gateway server crontab"
					 gateway_Cutover Host:'Production_240_6180', GatewayType:"${env.GatewayType}", externalApacheCutover:true, CutoverGateway:true, gatewayEnvironment:"${env.GatewayEnvironment}"
                     echo "Disabling in GatewayHealthcheck script in uktlpfhr Gateway server crontab"						
				     gateway_Cutover Host:'Production_241_6180', GatewayType:"${env.GatewayType}", externalApacheCutover:true, CutoverGateway:true, gatewayEnvironment:"${env.GatewayEnvironment}"								  
			}
		}
	}

		 stage("Gateways Rollback Approval") {			 
			steps { 
				script {
				
						  try {
							          prodRollbackApprovers = get_approvers_list('Ops-User')
						              Rollback_Approval = false
									  Rollback_Scenario = false
									  def userInput = input(
					                       id: 'userInput', message: 'Proceed Rolling back changes deployed ?',
					                       submitterParameter: 'submitter',
					                       submitter: "${prodRollbackApprovers}"
					                    )
                                      
									  
                                      
                                     } 
							     catch (error) {
                                         echo "Ignoring Rollback"
										 Rollback_Approval = true
										 Rollback_Scenario = true
										 
									}
						echo "Rollback Scenario Approval ${Rollback_Approval}"	
                        echo "Exceptional Scenario ${Rollback_Scenario}"						
					}
			}
		}
	

		stage("RollBack EGW uktlpehr changes") {
		    when { 
			      allOf{
				     not { 
					    expression { return Rollback_Approval }
                        } 
				     not { 
					    expression { return Rollback_Scenario }
                        } 					 
					 }
				}		
			steps {
				script {
					
					// If the following values are blank, it means we are starting from stage and need to retrive the values from stash.
					unstash "stashProperties"
					if (date_now == " ") {
						date_now = sh(script:"cat ./DIR_STASH/propfile | grep -e date | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						echo "Date after stage restart is:${date_now}"
					}
					if (displayName == " ") {
						displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						currentBuild.displayName = "${displayName}_restart"
						echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
					}
					// Call rollback function by providing Details.
					rollback_artefact Host:'Production_240_6180', GatewayType:"${env.GatewayType}", crq_no:"${params.CRQ}", datetime:"${date_now}", internalApache:true, externalApache:true, gatewayEnvironment:"${env.GatewayEnvironment}"
			   }
			}
		}


	stage("Disabling Alerts-RB")
	{
		    when { 
			      allOf{
				     not { 
					    expression { return Rollback_Approval }
                        } 
				     not { 
					    expression { return Rollback_Scenario }
                        } 					 
					 }
				}			
	   steps
	       {
			 script
			   {	
			    
				     echo "Disabling in GatewayHealthcheck script in All Gateway servers crontab"
				     echo "Disabling in GatewayHealthcheck script in uktlpehr Gateway server crontab"
					 gateway_Precutover Host:'Production_240_6180', GatewayType:"${env.GatewayType}", externalApachePrecutover:true, PrecutoverGateway:true, gatewayEnvironment:"${env.GatewayEnvironment}"
                     echo "Disabling in GatewayHealthcheck script in uktlpfhr Gateway server crontab"						
				     gateway_Precutover Host:'Production_241_6180', GatewayType:"${env.GatewayType}", externalApachePrecutover:true, PrecutoverGateway:true, gatewayEnvironment:"${env.GatewayEnvironment}"								  
			}
		}
	}		
		stage("RollBack EGW uktlpfhr changes") {
		    when { 
			      allOf{
				     not { 
					    expression { return Rollback_Approval }
                        } 
				     not { 
					    expression { return Rollback_Scenario }
                        } 					 
					 }
				}		
			steps {
				script {
					
					// If the following values are blank, it means we are starting from stage and need to retrive the values from stash.
					unstash "stashProperties"
					if (date_now == " ") {
						date_now = sh(script:"cat ./DIR_STASH/propfile | grep -e date | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						echo "Date after stage restart is:${date_now}"
					}
					if (displayName == " ") {
						displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						currentBuild.displayName = "${displayName}_restart"
						echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
					}
					// Call rollback function by providing Details.
					rollback_artefact Host:'Production_241_6180', GatewayType:"${env.GatewayType}", crq_no:"${params.CRQ}", datetime:"${date_now}", internalApache:true, externalApache:true, gatewayEnvironment:"${env.GatewayEnvironment}"
			   }
			}
		}
		
		stage("Gateway Rollback Restart Approval") {
		    when { 
			      allOf{
				     not { 
					    expression { return Rollback_Approval }
                        } 
				     not { 
					    expression { return Rollback_Scenario }
                        } 					 
					 }
				}
			steps {
				script {
					  	 input 'Proceed with gateway restarts ?'
					}
			}
		}
		
		stage("Rollback Restart EGW uktlpehr_6180 Gateway") {
		    when { 
			      allOf{
				     not { 
					    expression { return Rollback_Approval }
                        } 
				     not { 
					    expression { return Rollback_Scenario }
                        } 					 
					 }
				}		
			steps {
				script {
					// If the following values are blank, it means we are starting from stage and need to retrive the values from stash.
					unstash "stashProperties"
					if (date_now == " ") {
						date_now = sh(script:"cat ./DIR_STASH/propfile | grep -e date | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						echo "Date after stage restart is:${date_now}"
					}
					if (displayName == " ") {
						displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						currentBuild.displayName = "${displayName}_restart"
						echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
					}
					
					// get Gateway PID by calling ansible gateway_pid function
                    gateway_pid Host:'Production_240_6180', GatewayType:"${env.GatewayType}"
					
					before_restart_240_6180_pid = readFile 'Production_240_6180/Gateway_Deployment/EGW_Production_240_6180_pid.txt'
					
					echo "Gateway PID is:${before_restart_240_6180_pid}"
					
					// Check status of gateway and ask for user input if gateway in stopped state
					// get Gateway status by calling ansible gateway_status function
                    gateway_status Host:'Production_240_6180', GatewayType:"${env.GatewayType}"
					
					def gatewayStatus = readFile 'Production_240_6180/Gateway_Deployment/EGW_Production_240_6180_status.txt'
					
					echo "Gateway Status is:${gatewayStatus}"
					
					if (gatewayStatus == "0"){
					 
					     echo "gateway is running hence restarting"
						 gateway_restart Host:'Production_240_6180', GatewayType:"${env.GatewayType}", internalApache:true, externalApache:true, gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
			
					  }
					 else {
                        echo "gateway is not running"
						gateway_not_running Host:'Production_240_6180', GatewayType:"${env.GatewayType}", internalApache:true, externalApache:true, gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
				 
                         }
                    // get Gateway PID by calling ansible gateway_pid function
                    gateway_pid Host:'Production_240_6180', GatewayType:"${env.GatewayType}"
					
					after_restart_240_6180_pid = readFile 'Production_240_6180/Gateway_Deployment/EGW_Production_240_6180_pid.txt'
					
					echo "Gateway PID is:${after_restart_240_6180_pid}"						 
					
				}
			}
		}
		
		stage("Rollback Restart EGW uktlpfhr_6180 Gateway") {
		    when { 
			      allOf{
				     not { 
					    expression { return Rollback_Approval }
                        } 
				     not { 
					    expression { return Rollback_Scenario }
                        } 					 
					 }
				}		
			steps {
				script {
					// If the following values are blank, it means we are starting from stage and need to retrive the values from stash.
					unstash "stashProperties"
					if (date_now == " ") {
						date_now = sh(script:"cat ./DIR_STASH/propfile | grep -e date | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						echo "Date after stage restart is:${date_now}"
					}
					if (displayName == " ") {
						displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						currentBuild.displayName = "${displayName}_restart"
						echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
					}
					
					// get Gateway PID by calling ansible gateway_pid function
                    gateway_pid Host:'Production_241_6180', GatewayType:"${env.GatewayType}"
					
					before_restart_241_6180_pid = readFile 'Production_241_6180/Gateway_Deployment/EGW_Production_241_6180_pid.txt'
					
					echo "Gateway PID is:${before_restart_241_6180_pid}"
					
					
					// Check status of gateway and ask for user input if gateway in stopped state
					// get Gateway status by calling ansible gateway_status function
                    gateway_status Host:'Production_241_6180', GatewayType:"${env.GatewayType}"
					
					def gatewayStatus = readFile 'Production_241_6180/Gateway_Deployment/EGW_Production_241_6180_status.txt'
					
					echo "Gateway Status is:${gatewayStatus}"
					
					if (gatewayStatus == "0"){
					 
					     echo "gateway is running hence restarting"
						 gateway_restart Host:'Production_241_6180', GatewayType:"${env.GatewayType}", internalApache:true, externalApache:true, gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
			
					  }
					 else {
                        echo "gateway is not running"
						gateway_not_running Host:'Production_241_6180', GatewayType:"${env.GatewayType}", internalApache:true, externalApache:true, gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
					      
                         }
                     // get Gateway PID by calling ansible gateway_pid function
                    gateway_pid Host:'Production_241_6180', GatewayType:"${env.GatewayType}"
					
					after_restart_241_6180_pid = readFile 'Production_241_6180/Gateway_Deployment/EGW_Production_241_6180_pid.txt'
					
					echo "Gateway PID is:${after_restart_241_6180_pid}"	

                     // Notify team with status email
					emailext mimeType: 'text/html',
						 subject: "[Jenkins]:${currentBuild.fullDisplayName}:Production Deployment:${params.ReleaseNumber}",
						 from:"CICD_GatewayDeploymentStatus@vodafone.com",
						 to: "${ops_mailRecipients}",
                         body: 	"${get_body_build_summary(DeploymentType:'RollBack', Status:'Success', beforeRestart:before_restart_240_6180_pid,afterRestart:after_restart_240_6180_pid,beforeRestart1:before_restart_241_6180_pid,afterRestart1:after_restart_241_6180_pid,beforeExtApacheRestart1:before_extApache_restart_240_6180_pid,afterExtApacheRestart1:after_extApache_restart_240_6180_pid,beforeExtApacheRestart2:before_extApache_restart_241_6180_pid,afterExtApacheRestart2:after_extApache_restart_241_6180_pid)}"
					
					echo "Deployment Summary : https://198.18.76.204:9080/jenkins/userContent/Gateway/${env.GatewayType}/${params.ReleaseNumber}/${params.GatewayVersion}/RollBack_Report.html"				
                    
				}
			}
		}
		

	stage("Enabling Alerts-RB")
	{
		    when { 
			      allOf{
				     not { 
					    expression { return Rollback_Approval }
                        } 
				     not { 
					    expression { return Rollback_Scenario }
                        } 					 
					 }
				}			
	   steps
	       {
			 script
			   {				    
				     echo "Enabling in GatewayHealthcheck script in All Gateway servers crontab"
				     echo "Enabling in GatewayHealthcheck script in uktlpehr Gateway server crontab"
					 gateway_Cutover Host:'Production_240_6180', GatewayType:"${env.GatewayType}", externalApacheCutover:true, CutoverGateway:true, gatewayEnvironment:"${env.GatewayEnvironment}"
                     echo "Disabling in GatewayHealthcheck script in uktlpfhr Gateway server crontab"						
				     gateway_Cutover Host:'Production_241_6180', GatewayType:"${env.GatewayType}", externalApacheCutover:true, CutoverGateway:true, gatewayEnvironment:"${env.GatewayEnvironment}"								  
			}
		}
	}
	
	
	stage("Signoff Production")
		{
			steps{
				script{
				        echo "DEBUG: Artefact Version deployed: ${params.GatewayVersion}"
                        
				}				
			}
		}
		
		//ADO-753185 - Swindon auto trigger and db update
		stage('Swindon Auto Trigger') 
		{
			steps 
			{
				script 
				{
					stash_function()
					def Swindon_inp = input(message: 'Proceed with Swindon Deployment?', parameters: [[$class:'ChoiceParameterDefinition', choices: ['YES','NO'].join('\n'),name: 'input', description: 'Choose yes if Swindon Deployment required']])
					if(	Swindon_inp == "YES")
					{
						echo "DEBUG: ArtefactVersion to deploy: ${params.GatewayVersion}"
						echo "DEBUG: Swindon Trigger mode: YES"
										
						build job: 'Gateway/Swindon/EGW_Deployment_Pipeline', parameters: [string(name: 'Release', value: "${params.ReleaseNumber}"), string(name: 'GatewayVersion', value:  "${params.GatewayVersion}"), string(name: 'CRQ', value: "${params.CRQ}")], wait: false
					}						
				}
			}
		}
		
		stage("DB update") 
		{
			steps
			{
				script
				{
					def user = currentBuild.rawBuild.causes[0].userId						
					stash_function()
					
					def insert_query = """Insert into CICD_DEPLOYMENT_HISTORY ("Release","DateTime","CRQ","ComponentType","Environment","EngineName","BwVersion","EmsVersion","SqlVersion","GatewayVersion","BwDeploymentType","DeploymentStatus","DeploymentTime","XmlFiles","JarFiles","EmailFiles","RF1Status","RBStatus","RF2Status","DVTStatus","BWConfigTag","ChangeDescription","User","FailureReason","updatedTimestamp","BUILD_ID","BUILD_URL") values ('${params.ReleaseNumber}',sysdate,'${params.CRQ}','GATEWAY','${env.GatewayEnvironment}_Dublin','${env.GatewayType}','','','','${params.GatewayVersion}','','Active','','','','','','','','','','','${user}','PASSED',sysdate, '${BUILD_ID}','${BUILD_URL}')"""
			
					println("DEBUG: Insert query is: " + insert_query)
			
					//DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${env.dbUserName}", dbPassword: "${env.dbPassword}", dbDriver: "${env.dbDriver}", insertQuery: insert_query
				}				
			}
		}

    }		
}
