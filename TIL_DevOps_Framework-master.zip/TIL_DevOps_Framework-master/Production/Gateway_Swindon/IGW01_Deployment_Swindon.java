//import this package as part of the creating github code and swindon autotrigger
import groovy.time.*

//[CICD-1530] Insert Deployment metadata to release notes DB.
import groovy.json.JsonOutput
import groovy.sql.*
import java.sql.Driver

def ops_mailRecipients = "devops-vfuk-integration@vodafone.com, veera.venkatalsknuni@vodafone.com, DL-TSSC-AO2-UK-Integration_TIL-RIG_L2@vodafone.com"

def get_body_build_summary(deployParams){
	def date_format_report = new Date().format("dd/MM/yyy HH:mm")
	def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
		.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		</style>
		<table class="tg" style="undefined;table-layout: fixed; width: 900px">
		<colgroup>
		<col style="width: 100px">
		<col style="width: 350px">
		<col style="width: 100px">
		<col style="width: 350px">
		</colgroup>
		  <tr>
			<td>
			<table width="50%"><tr><td><img width="150" src="https://www.vodafone.co.uk/cs/groups/public/documents/webcontent/1287x929_vodafone_logo.jpg" alt="ITEAMS" style="text-align: right; width: 207px; border: 0; text-decoration:none; vertical-align: baseline;"></td></tr></table>
          <div style="display:none">
			</div>
			</td>
			<th class="tg-amwm" colspan="3">CCS Integration Swindon-Production Deployment Summary ${params.ReleaseNumber}</th>
		  </tr>
		  <tr>
			<td class="tg-1wig">Submitted By</td>
			<td class="tg-0lax">${currentBuild.getRawBuild().getCauses()[0].getUserId()}</td>
			<td class="tg-1wig">Date</td>
			<td class="tg-0lax">${date_format_report}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">RELEASE NUMBER & VERSION </td>
			<td class="tg-0lax">${params.ReleaseNumber} & ${params.GatewayVersion}</td>
			<td class="tg-1wig">Gateway</td>
			<td class="tg-0lax">${env.GatewayType}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">Deployment Type</td>
			<td class="tg-0lax">${deployParams.DeploymentType}</td>
			<td class="tg-1wig">Status</td>
			<td class="tg-0lax">${deployParams.Status}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">uk2769yr_6313 PID before restart</td>
			<td class="tg-0lax">${deployParams.beforeRestart}</td>
			<td class="tg-1wig">uk2769yr_6313 PID after restart</td>
			<td class="tg-0lax">${deployParams.afterRestart}</td>
		  </tr>	
		  <tr>
			<td class="tg-1wig">uk2770yr_6313 PID before restart</td>
			<td class="tg-0lax">${deployParams.beforeRestart1}</td>
			<td class="tg-1wig">uk2769yr_6313 PID after restart</td>
			<td class="tg-0lax">${deployParams.afterRestart1}</td>
		  </tr>	
          <tr>
			<td class="tg-1wig">uk2771yr_6313 PID before restart</td>
			<td class="tg-0lax">${deployParams.beforeRestart2}</td>
			<td class="tg-1wig">uk2769yr_6313 PID after restart</td>
			<td class="tg-0lax">${deployParams.afterRestart2}</td>
		  </tr>	
          <tr>
			<td class="tg-1wig">uk2772yr_6313 PID before restart</td>
			<td class="tg-0lax">${deployParams.beforeRestart3}</td>
			<td class="tg-1wig">uk2769yr_6313 PID after restart</td>
			<td class="tg-0lax">${deployParams.afterRestart3}</td>
		  </tr>
          <tr>
			<td class="tg-1wig">LOG_URL</td>
			<td class="tg-0lax" colspan="3">${BUILD_URL}/console</td>
		  </tr>		  
		</table>
		<br><br><br>
	"""
	emailBody = body_build_summary
	writeFile file: "${WORKSPACE}/Reports/${deployParams.DeploymentType}_Report.html", text: emailBody
    writeFile file: "/opt/SP/tibco/.jenkins/userContent/Gateway/${env.GatewayType}/${params.ReleaseNumber}/${params.GatewayVersion}/${deployParams.DeploymentType}_Report.html", text: emailBody 
		
	return body_build_summary
}


//ADO - 735185 - Swindon auto trigger pipeline and db update, we need to move this to common functionality as next change
//cccc

def stash_function() {
    script{
	
	      unstash "stashProperties"
		  if (date_now == " ") {
				date_now = sh(script:"cat ./DIR_STASH/propfile | grep -e date | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
				echo "Date after stage restart is:${date_now}"
			}
		  if (displayName == " ") {
				displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
				currentBuild.displayName = "${displayName}_restart"
				echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
                load_groovy_files()                
			}
	
	}
}

def load_groovy_files() 
{
    //Checkout Environment Configurations
    git credentialsId: 'GITHUBKEY', poll: false, url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Production_Configuration.git'
    //Checkout for Common Functions
    checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'JENKINS_FILE']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_DevOps_Framework.git']]])
    //Checkout Ops Automation Repo. Only For Production
    //checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Ops_Automation_Framework.git']]]        
    
	GatewayFunction = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/GatewayFunctions.groovy"
    DB_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/dbFunctions.groovy"
    commonFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/commonFunctions.groovy"
    
    GatewayUsers = commonFunctions.get_approvers_list('${Gateway_Approvers}')
    user = currentBuild.rawBuild.causes[0].userId
}

def getBuildUserID()
{
    if(currentBuild.getBuildCauses('hudson.triggers.TimerTrigger$TimerTriggerCause'))
        return "time_triggered"
    else if(currentBuild.getBuildCauses('hudson.model.Cause$UpstreamCause'))
    {
        def upstreamCause = currentBuild.rawBuild.getCause(Cause.UpstreamCause)
        def upstreamJob = Jenkins.getInstance().getItemByFullName(upstreamCause.getUpstreamProject(), hudson.model.Job.class)
        if (upstreamJob) 
		{
            def upstreamBuild = upstreamJob.getBuildByNumber(upstreamCause.getUpstreamBuild())
            if (upstreamBuild)
			{
                def realUpstreamCause = upstreamBuild.getCause(Cause.UserIdCause)
                if (realUpstreamCause) {
                return realUpstreamCause.getUserId()
            }
        }
    }
    return "Upstream Triggered"
}
else
    return currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId()
}

///cccc

// Funcation to Get jenkins users from the given role
def get_approvers_list(String str){
	outlist = sh (script: """cat /opt/SP/tibco/.jenkins/config.xml | sed -n \'/role name=\"${str}\"/,\$p\' | sed \'/role>/q\' | grep "sid" | cut -d \'>\' -f 2 | cut -d \'<\' -f 1 | paste -s -d, -""",
			returnStdout: true).trim()
	return """${outlist}"""
}


def deploy_artefact(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{
	        //Checkout Environment Configurations
				git credentialsId: 'GITHUBKEY', poll: false, url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Production_Configuration.git'
				
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
			
			// Copy host configutaion files to Ansible deployment script location
			//sh "cp -r ./${deployParams.Host}/Gateway_Configuration/${deployParams.GatewayType}/${deployParams.gatewayEnvironment}/* ./${deployParams.Host}/Gateway_Deployment/"
			sh "cp -r ./Gateway_Configuration/${deployParams.GatewayType}/${deployParams.gatewayEnvironment}/* ./${deployParams.Host}/Gateway_Deployment/"
			
			// copy host variables from configuration to ansible host vars folder
			sh "cp ./${deployParams.Host}/Gateway_Deployment/${deployParams.GatewayType}_${deployParams.Host} ./${deployParams.Host}/Gateway_Deployment/host_vars/"
			// Generate host vars file for external apache
			sh "cp ./${deployParams.Host}/Gateway_Deployment/${deployParams.GatewayType}_${deployParams.Host} ./${deployParams.Host}/Gateway_Deployment/host_vars/${deployParams.GatewayType}_${deployParams.Host}_ExternalApache"
			// Generate host vars file for internal apache
			sh "cp ./${deployParams.Host}/Gateway_Deployment/${deployParams.GatewayType}_${deployParams.Host} ./${deployParams.Host}/Gateway_Deployment/host_vars/${deployParams.GatewayType}_${deployParams.Host}_InternalApache"
            // rename tokens file to instance specific
			sh "cp ./${deployParams.Host}/Gateway_Deployment/Tokens/${deployParams.GatewayType}_${deployParams.gatewayEnvironment} ./${deployParams.Host}/Gateway_Deployment/Tokens/${deployParams.GatewayType}_${deployParams.Host}"
            
			//sh "cp ./${deployParams.Host}/Gateway_Deployment/${deployParams.GatewayType}_${deployParams.Host}_* ./${deployParams.Host}/Gateway_Deployment/host_vars/"
			echo "DEBUG: nexus_ArtefactVersion is: ${deployParams.nexus_ArtefactVersion}"
		
			//Run ansible playbook to deploy artefacts into environment
			 ansiColor('xterm') {
    	    ansiblePlaybook(playbook: "./${deployParams.Host}/Gateway_Deployment/Ops_Deploy.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.GatewayType}_${deployParams.Host}", repo_group_id: "${deployParams.nexus_group_id}", repo_artifact_id: "${deployParams.nexus_artifact_id}", repo_user: "${deployParams.nexus_user}", repo_pw: "${deployParams.nexus_passwd}", repo_repo_id: "${deployParams.nexus_repo_id}", repo_version: "${deployParams.nexus_ArtefactVersion}", repo_url: "${deployParams.nexus_url}", datetime: "${deployParams.datetime}", crq_no: "${deployParams.crq_no}", gatewayRestart: "${deployParams.gatewayRestart}", deployType: "${deployParams.deployType}"])
	
			}
    }
}

def gateway_restart(deployParams) {
	script{
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
			//Run ansible playbook to restart gateway instances
			 ansiColor('xterm') {
    	    ansiblePlaybook(playbook: "./${deployParams.Host}/Gateway_Deployment/Ops_Restart.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.GatewayType}_${deployParams.Host}", externalApache: "${deployParams.externalApache}", internalApache: "${deployParams.internalApache}", gatewayRestart: "${deployParams.gatewayRestart}"])

		  }
    }
}

def rollback_artefact(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{
			ansiColor('xterm') {		
			 //Run ansible playbook to rollback deployed changes
			 ansiblePlaybook(playbook: "./${deployParams.Host}/Gateway_Deployment/rollback.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.GatewayType}_${deployParams.Host}", datetime: "${deployParams.datetime}", crq_no: "${deployParams.crq_no}", externalApache: "${deployParams.externalApache}", internalApache: "${deployParams.internalApache}"])
	         }
	}
}

def gateway_status(deployParams) {
	script{
			//Run ansible playbook to get gateway status
			 ansiColor('xterm') {
    	    ansiblePlaybook(playbook: "./${deployParams.Host}/Gateway_Deployment/gatewayStatus.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.GatewayType}_${deployParams.Host}"])

		  }
    }
}

def gateway_pid(deployParams) {
	script{
			//Run ansible playbook to get gateway status
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
			 ansiColor('xterm') {
    	    ansiblePlaybook(playbook: "./${deployParams.Host}/Gateway_Deployment/gatewayPID.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.GatewayType}_${deployParams.Host}"])

		  }
    }
}

def gateway_not_running(deployParams) {
	script{
	        def USER_INPUT = input(
                              message: 'IGW01 Gateway Instance is not running. Select restart/skip to proceed with gateway restart ?',
                               parameters: [
                                 [$class: 'ChoiceParameterDefinition',
									choices: ['Restart','Skip'].join('\n'),
									name: 'input',
									description: 'Choose Restart or Skip']
									])
					      
						  if (USER_INPUT == "Restart")
					           {
						       gateway_restart Host:"${deployParams.Host}", GatewayType:"${deployParams.GatewayType}", internalApache:"${deployParams.internalApache}", externalApache:"${deployParams.externalApache}", gatewayRestart:"${deployParams.gatewayRestart}", gatewayEnvironment:"${deployParams.gatewayEnvironment}"
			
                                }
	}
}



// Global Parameters to use in the stages.

date_now = " "
displayName = " "
emailBody = " "
before_restart_186_6313_pid = ""
after_restart_186_6313_pid = ""
before_restart_187_6313_pid = ""
after_restart_187_6313_pid = ""
before_restart_188_6313_pid = ""
after_restart_188_6313_pid = ""
before_restart_189_6313_pid = ""
after_restart_187_6313_pid = ""

Rollback_Approval = true
Rollback_Scenario = true
prodRollbackApprovers = ""
pipeline {
    agent any
	options {
        preserveStashes(buildCount: 49)
    }

    environment {
		GROUPID = "GATEWAY"
		GatewayType = "IGW01"
		GatewayEnvironment = "Production"
		REPO_URL = "http://195.233.197.150:8081"
		PROD_REPO = "PROD_REPO"
		NEXUS_USER = "admin"
		NEXUS_PASSWD = "admin123"
		dbURL = 'jdbc:oracle:thin:@ukorpa1-scan.dc-dublin.de:33000/TIBCPDB_TAF.prod.uk'
		dbUserName = 'CICD_OWN_DB01'
		dbPassword = 'Voda#1010'
		dbDriver = 'oracle.jdbc.driver.OracleDriver'

    }

    stages {
		stage('Preparation') {
			steps {
			    deleteDir()
				//Checkout Environment Configurations
				git credentialsId: 'GITHUBKEY', poll: false, url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Production_Configuration.git'
				
				echo "Gateway Type selected is:${GatewayType}"
				echo "Release number selected is: ${params.ReleaseNumber}"
				def user = getBuildUserID()
				script{
				    	if (CRQ.indexOf(' ') != -1){
						         currentBuild.result = 'ABORTED'
                                 error('CR Number / IRIS Number should not contain spaces in between')
						       }
				    date_now = new Date().format("YYYYMMddHHmmss")
					displayName = "${params.ReleaseNumber}_${params.CRQ}"
					currentBuild.displayName = "${displayName}"
					//Stash the important values so that these can be retrieved for stage restart.
					sh "mkdir -p DIR_STASH"
					sh "echo date:${date_now} >DIR_STASH/propfile"
					sh "echo displayName:${displayName} >>DIR_STASH/propfile"
					stash includes: 'DIR_STASH/propfile', name: 'stashProperties'
				}
				echo "date:${date_now}"

						
			}			
		}

	stage("IGW01 uk2769yr Deployment") {
			steps {
				// This stage is for deployment.
				script {
				 
				    stash_function()
					// Call deploy function by providing LinkTest Details.
					deploy_artefact Host:'Production_186_6313', nexus_group_id:"${env.GROUPID}", nexus_artifact_id:"${env.GatewayType}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.PROD_REPO}", nexus_ArtefactVersion:"${params.GatewayVersion}", GatewayType:"${env.GatewayType}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CRQ}", datetime:"${date_now}", gatewayRestart:false, gatewayEnvironment:"${env.GatewayEnvironment}", deployType:"RF1"
				}
			}
		}
		
	stage("IGW01 uk2770yr Deployment") {
			steps {
				// This stage is for deployment.
				script {
				 
				    stash_function()
					// Call deploy function by providing LinkTest Details.
					deploy_artefact Host:'Production_187_6313', nexus_group_id:"${env.GROUPID}", nexus_artifact_id:"${env.GatewayType}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.PROD_REPO}", nexus_ArtefactVersion:"${params.GatewayVersion}", GatewayType:"${env.GatewayType}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CRQ}", datetime:"${date_now}", gatewayRestart:false, gatewayEnvironment:"${env.GatewayEnvironment}", deployType:"RF1"
				}
			}
		}

	stage("IGW01 uk2771yr Deployment") {
			steps {
				// This stage is for deployment.
				script {
				 
				    stash_function()
					// Call deploy function by providing LinkTest Details.
					deploy_artefact Host:'Production_188_6313', nexus_group_id:"${env.GROUPID}", nexus_artifact_id:"${env.GatewayType}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.PROD_REPO}", nexus_ArtefactVersion:"${params.GatewayVersion}", GatewayType:"${env.GatewayType}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CRQ}", datetime:"${date_now}", gatewayRestart:false, gatewayEnvironment:"${env.GatewayEnvironment}", deployType:"RF1"
				}
			}
		}
		
	stage("IGW01 uk2772yr Deployment") {
			steps {
				// This stage is for deployment.
				script {
				 
				    stash_function()
					// Call deploy function by providing LinkTest Details.
					deploy_artefact Host:'Production_189_6313', nexus_group_id:"${env.GROUPID}", nexus_artifact_id:"${env.GatewayType}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.PROD_REPO}", nexus_ArtefactVersion:"${params.GatewayVersion}", GatewayType:"${env.GatewayType}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CRQ}", datetime:"${date_now}", gatewayRestart:false, gatewayEnvironment:"${env.GatewayEnvironment}", deployType:"RF1"
				}
			}
		}

	    stage("Gateway Restart Approval") {
			steps {
				script {
					  	 input 'Proceed with gateway restarts ?'
					}
			}
		}
	
		stage("Restart IGW01 uk2769yr_6313 Gateway") {
			steps {
				script {
					
					stash_function()
					// get Gateway PID by calling ansible gateway_pid function
                    gateway_pid Host:'Production_186_6313', GatewayType:"${env.GatewayType}"
					
					before_restart_186_6313_pid = readFile 'Production_186_6313/Gateway_Deployment/IGW01_Production_186_6313_pid.txt'
					
					echo "Gateway PID is:${before_restart_186_6313_pid}"
					
					// Check status of gateway and ask for user input if gateway in stopped state
					// get Gateway status by calling ansible gateway_status function
                    gateway_status Host:'Production_186_6313', GatewayType:"${env.GatewayType}"
					
					def gatewayStatus = readFile 'Production_186_6313/Gateway_Deployment/IGW01_Production_186_6313_status.txt'
					
					echo "Gateway Status is:${gatewayStatus}"
					
					if (gatewayStatus == "0"){
					 
					     echo "gateway is running hence restarting"
						 gateway_restart Host:'Production_186_6313', GatewayType:"${env.GatewayType}", internalApache:true, externalApache:true, gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
			
					  }
					 else {
					   echo "gateway is not running"
						gateway_not_running Host:'Production_186_6313', GatewayType:"${env.GatewayType}", internalApache:true, externalApache:true, gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
					     }
                    // get Gateway PID by calling ansible gateway_pid function
                    gateway_pid Host:'Production_186_6313', GatewayType:"${env.GatewayType}"
					
					after_restart_186_6313_pid = readFile 'Production_186_6313/Gateway_Deployment/IGW01_Production_186_6313_pid.txt'
					
					echo "Gateway PID is:${after_restart_186_6313_pid}"						 
					
				
				}
			}
		}
		
		stage("Restart IGW01 uk2770yr_6313 Gateway") {
			steps {
				script {
					stash_function()
					// get Gateway PID by calling ansible gateway_pid function
                    gateway_pid Host:'Production_187_6313', GatewayType:"${env.GatewayType}"
					
					before_restart_187_6313_pid = readFile 'Production_187_6313/Gateway_Deployment/IGW01_Production_187_6313_pid.txt'
					
					echo "Gateway PID is:${before_restart_187_6313_pid}"
					
					
					// Check status of gateway and ask for user input if gateway in stopped state
					// get Gateway status by calling ansible gateway_status function
                    gateway_status Host:'Production_187_6313', GatewayType:"${env.GatewayType}"
					
					def gatewayStatus = readFile 'Production_187_6313/Gateway_Deployment/IGW01_Production_187_6313_status.txt'
					
					echo "Gateway Status is:${gatewayStatus}"
					
					if (gatewayStatus == "0"){
					 
					     echo "gateway is running hence restarting"
						 gateway_restart Host:'Production_187_6313', GatewayType:"${env.GatewayType}", internalApache:true, externalApache:true, gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
			
					  }
					 else {
					   echo "gateway is not running"
						gateway_not_running Host:'Production_187_6313', GatewayType:"${env.GatewayType}", internalApache:true, externalApache:true, gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
					  }
                     // get Gateway PID by calling ansible gateway_pid function
                    gateway_pid Host:'Production_187_6313', GatewayType:"${env.GatewayType}"
					
					after_restart_187_6313_pid = readFile 'Production_187_6313/Gateway_Deployment/IGW01_Production_187_6313_pid.txt'
					
					echo "Gateway PID is:${after_restart_187_6313_pid}"						 
					
				}
			}
		}
		
		stage("Restart IGW01 uk2771yr_6313 Gateway") {
			steps {
				script {
					stash_function()
					// get Gateway PID by calling ansible gateway_pid function
                    gateway_pid Host:'Production_188_6313', GatewayType:"${env.GatewayType}"
					
					before_restart_188_6313_pid = readFile 'Production_188_6313/Gateway_Deployment/IGW01_Production_188_6313_pid.txt'
					
					echo "Gateway PID is:${before_restart_188_6313_pid}"
					
					
					// Check status of gateway and ask for user input if gateway in stopped state
					// get Gateway status by calling ansible gateway_status function
                    gateway_status Host:'Production_188_6313', GatewayType:"${env.GatewayType}"
					
					def gatewayStatus = readFile 'Production_188_6313/Gateway_Deployment/IGW01_Production_188_6313_status.txt'
					
					echo "Gateway Status is:${gatewayStatus}"
					
					if (gatewayStatus == "0"){
					 
					     echo "gateway is running hence restarting"
						 gateway_restart Host:'Production_188_6313', GatewayType:"${env.GatewayType}", internalApache:true, externalApache:false, gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
			
					  }
					 else {
					  echo "gateway is not running"
						gateway_not_running Host:'Production_188_6313', GatewayType:"${env.GatewayType}", internalApache:true, externalApache:false, gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
					   }
					   
					  // get Gateway PID by calling ansible gateway_pid function
                    gateway_pid Host:'Production_188_6313', GatewayType:"${env.GatewayType}"
					
					after_restart_188_6313_pid = readFile 'Production_188_6313/Gateway_Deployment/IGW01_Production_188_6313_pid.txt'
					
					echo "Gateway PID is:${after_restart_188_6313_pid}"	   
                
				}
			}
		}
		
		stage("Restart IGW01 uk2772yr_6313 Gateway") {
			steps {
				script {
					stash_function()
					// get Gateway PID by calling ansible gateway_pid function
                    gateway_pid Host:'Production_189_6313', GatewayType:"${env.GatewayType}"
					
					before_restart_189_6313_pid = readFile 'Production_189_6313/Gateway_Deployment/IGW01_Production_189_6313_pid.txt'
					
					echo "Gateway PID is:${before_restart_189_6313_pid}"
					
					// Check status of gateway and ask for user input if gateway in stopped state
					// get Gateway status by calling ansible gateway_status function
                    gateway_status Host:'Production_189_6313', GatewayType:"${env.GatewayType}"
					
					def gatewayStatus = readFile 'Production_189_6313/Gateway_Deployment/IGW01_Production_189_6313_status.txt'
					
					echo "Gateway Status is:${gatewayStatus}"
					
					if (gatewayStatus == "0"){
					 
					     echo "gateway is running hence restarting"
						 gateway_restart Host:'Production_189_6313', GatewayType:"${env.GatewayType}", internalApache:true, externalApache:false, gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
			
					  }
					 else {
                        echo "gateway is not running"
						gateway_not_running Host:'Production_189_6313', GatewayType:"${env.GatewayType}", internalApache:true, externalApache:false, gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
					    
                         }
					// get Gateway PID by calling ansible gateway_pid function
                    gateway_pid Host:'Production_189_6313', GatewayType:"${env.GatewayType}"
					
					after_restart_189_6313_pid = readFile 'Production_189_6313/Gateway_Deployment/IGW01_Production_189_6313_pid.txt'
					
					echo "Gateway PID is:${after_restart_189_6313_pid}"		

                       // Notify team with status email
					emailext mimeType: 'text/html',
						 subject: "[Jenkins]:${currentBuild.fullDisplayName}:Production Deployment:${params.ReleaseNumber}",
						 from:"CICD_GatewayDeploymentStatus@vodafone.com",
						 to: "${ops_mailRecipients}",
                         body: 	"${get_body_build_summary(DeploymentType:'RollForward', Status:'Success', beforeRestart:before_restart_186_6313_pid, afterRestart:after_restart_186_6313_pid, beforeRestart1:before_restart_187_6313_pid, afterRestart1:after_restart_187_6313_pid, beforeRestart2:before_restart_188_6313_pid, afterRestart2:after_restart_188_6313_pid, beforeRestart3:before_restart_189_6313_pid, afterRestart3:after_restart_189_6313_pid)}"
					 
                     echo "Deployment Summary : https://198.18.76.204:9080/jenkins/userContent/Gateway/${env.GatewayType}/${params.ReleaseNumber}/${params.GatewayVersion}/RollForward_Report.html"				
                    					 
				
				}
			}
		}
				

		 stage("Gateways Rollback Approval") {			 
			steps { 
				script {
				
						  try {
							          prodRollbackApprovers = get_approvers_list('Ops-User')
						              Rollback_Approval = false
									  Rollback_Scenario = false
									  def userInput = input(
					                       id: 'userInput', message: 'Proceed Rolling back changes deployed ?',
					                       submitterParameter: 'submitter',
					                       submitter: "${prodRollbackApprovers}"
					                    )
                                      
									  
                                      
                                     } 
							     catch (error) {
                                         echo "Ignoring Rollback"
										 Rollback_Approval = true
										 Rollback_Scenario = true
										 
									}
						echo "Rollback Scenario Approval ${Rollback_Approval}"	
                        echo "Exceptional Scenario ${Rollback_Scenario}"						
					}
			}
		}
	

		stage("RollBack IGW01 uk2769yr_6313 changes") {
		    when { 
			      allOf{
				     not { 
					    expression { return Rollback_Approval }
                        } 
				     not { 
					    expression { return Rollback_Scenario }
                        } 					 
					 }
				}		
			steps {
				script {
					
					stash_function()
					// Call rollback function by providing LinkTest Details.
					rollback_artefact Host:'Production_186_6313', GatewayType:"${env.GatewayType}", crq_no:"${params.CRQ}", datetime:"${date_now}", internalApache:true, externalApache:true, gatewayEnvironment:"${env.GatewayEnvironment}"
			   }
			}
		}
		
		stage("RollBack IGW01 uk2770yr_6313 changes") {
		    when { 
			      allOf{
				     not { 
					    expression { return Rollback_Approval }
                        } 
				     not { 
					    expression { return Rollback_Scenario }
                        } 					 
					 }
				}		
			steps {
				script {
					
					stash_function()
					// Call rollback function by providing LinkTest Details.
					rollback_artefact Host:'Production_187_6313', GatewayType:"${env.GatewayType}", crq_no:"${params.CRQ}", datetime:"${date_now}", internalApache:true, externalApache:false, gatewayEnvironment:"${env.GatewayEnvironment}"
			   }
			}
		}

		stage("RollBack IGW01 uk2771yr_6313 changes") {
		    when { 
			      allOf{
				     not { 
					    expression { return Rollback_Approval }
                        } 
				     not { 
					    expression { return Rollback_Scenario }
                        } 					 
					 }
				}		
			steps {
				script {
					
					stash_function()
					// Call rollback function by providing LinkTest Details.
					rollback_artefact Host:'Production_188_6313', GatewayType:"${env.GatewayType}", crq_no:"${params.CRQ}", datetime:"${date_now}", internalApache:true, externalApache:true, gatewayEnvironment:"${env.GatewayEnvironment}"
			   }
			}
		}
		

		stage("RollBack IGW01 uk2772yr_6313 changes") {
		    when { 
			      allOf{
				     not { 
					    expression { return Rollback_Approval }
                        } 
				     not { 
					    expression { return Rollback_Scenario }
                        } 					 
					 }
				}		
			steps {
				script {
					stash_function()
					// Call rollback function by providing LinkTest Details.
					rollback_artefact Host:'Production_189_6313', GatewayType:"${env.GatewayType}", crq_no:"${params.CRQ}", datetime:"${date_now}", internalApache:true, externalApache:false, gatewayEnvironment:"${env.GatewayEnvironment}"
			   }
			}
		}
		
		stage("Gateway Rollback Restart Approval") {
		    when { 
			      allOf{
				     not { 
					    expression { return Rollback_Approval }
                        } 
				     not { 
					    expression { return Rollback_Scenario }
                        } 					 
					 }
				}
			steps {
				script {
					  	 input 'Proceed with gateway restarts ?'
					}
			}
		}
		
		stage("Rollback Restart IGW01 uk2769yr_6313 Gateway") {
		    when { 
			      allOf{
				     not { 
					    expression { return Rollback_Approval }
                        } 
				     not { 
					    expression { return Rollback_Scenario }
                        } 					 
					 }
				}		
			steps {
				script {
					stash_function()
					// get Gateway PID by calling ansible gateway_pid function
                    gateway_pid Host:'Production_186_6313', GatewayType:"${env.GatewayType}"
					
					before_restart_186_6313_pid = readFile 'Production_186_6313/Gateway_Deployment/IGW01_Production_186_6313_pid.txt'
					
					echo "Gateway PID is:${before_restart_186_6313_pid}"
					
					// Check status of gateway and ask for user input if gateway in stopped state
					// get Gateway status by calling ansible gateway_status function
                    gateway_status Host:'Production_186_6313', GatewayType:"${env.GatewayType}"
					
					def gatewayStatus = readFile 'Production_186_6313/Gateway_Deployment/IGW01_Production_186_6313_status.txt'
					
					echo "Gateway Status is:${gatewayStatus}"
					
					if (gatewayStatus == "0"){
					 
					     echo "gateway is running hence restarting"
						 gateway_restart Host:'Production_186_6313', GatewayType:"${env.GatewayType}", internalApache:true, externalApache:true, gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
			
					  }
					 else {
					   echo "gateway is not running"
						gateway_not_running Host:'Production_186_6313', GatewayType:"${env.GatewayType}", internalApache:true, externalApache:true, gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
					     }
                    // get Gateway PID by calling ansible gateway_pid function
                    gateway_pid Host:'Production_186_6313', GatewayType:"${env.GatewayType}"
					
					after_restart_186_6313_pid = readFile 'Production_186_6313/Gateway_Deployment/IGW01_Production_186_6313_pid.txt'
					
					echo "Gateway PID is:${after_restart_186_6313_pid}"						 
						
				
				}
			}
		}
		
		stage("Rollback Restart IGW01 uk2770yr_6313 Gateway") {
		    when { 
			      allOf{
				     not { 
					    expression { return Rollback_Approval }
                        } 
				     not { 
					    expression { return Rollback_Scenario }
                        } 					 
					 }
				}		
			steps {
				script {
                     stash_function()					
					// get Gateway PID by calling ansible gateway_pid function
                    gateway_pid Host:'Production_187_6313', GatewayType:"${env.GatewayType}"
					
					before_restart_187_6313_pid = readFile 'Production_187_6313/Gateway_Deployment/IGW01_Production_187_6313_pid.txt'
					
					echo "Gateway PID is:${before_restart_187_6313_pid}"
					
					
					// Check status of gateway and ask for user input if gateway in stopped state
					// get Gateway status by calling ansible gateway_status function
                    gateway_status Host:'Production_187_6313', GatewayType:"${env.GatewayType}"
					
					def gatewayStatus = readFile 'Production_187_6313/Gateway_Deployment/IGW01_Production_187_6313_status.txt'
					
					echo "Gateway Status is:${gatewayStatus}"
					
					if (gatewayStatus == "0"){
					 
					     echo "gateway is running hence restarting"
						 gateway_restart Host:'Production_187_6313', GatewayType:"${env.GatewayType}", internalApache:true, externalApache:true, gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
			
					  }
					 else {
					   echo "gateway is not running"
						gateway_not_running Host:'Production_187_6313', GatewayType:"${env.GatewayType}", internalApache:true, externalApache:true, gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
					  }
                     // get Gateway PID by calling ansible gateway_pid function
                    gateway_pid Host:'Production_187_6313', GatewayType:"${env.GatewayType}"
					
					after_restart_187_6313_pid = readFile 'Production_187_6313/Gateway_Deployment/IGW01_Production_187_6313_pid.txt'
					
					echo "Gateway PID is:${after_restart_187_6313_pid}"						 
										
				}
			}
		}
		
		stage("Rollback Restart IGW01 uk2771yr_6313 Gateway") {
		    when { 
			      allOf{
				     not { 
					    expression { return Rollback_Approval }
                        } 
				     not { 
					    expression { return Rollback_Scenario }
                        } 					 
					 }
				}		
			steps {
				script {
					stash_function()
					// get Gateway PID by calling ansible gateway_pid function
                    gateway_pid Host:'Production_188_6313', GatewayType:"${env.GatewayType}"
					
					before_restart_188_6313_pid = readFile 'Production_188_6313/Gateway_Deployment/IGW01_Production_188_6313_pid.txt'
					
					echo "Gateway PID is:${before_restart_188_6313_pid}"
					
					
					// Check status of gateway and ask for user input if gateway in stopped state
					// get Gateway status by calling ansible gateway_status function
                    gateway_status Host:'Production_188_6313', GatewayType:"${env.GatewayType}"
					
					def gatewayStatus = readFile 'Production_188_6313/Gateway_Deployment/IGW01_Production_188_6313_status.txt'
					
					echo "Gateway Status is:${gatewayStatus}"
					
					if (gatewayStatus == "0"){
					 
					     echo "gateway is running hence restarting"
						 gateway_restart Host:'Production_188_6313', GatewayType:"${env.GatewayType}", internalApache:true, externalApache:false, gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
			
					  }
					 else {
					  echo "gateway is not running"
						gateway_not_running Host:'Production_188_6313', GatewayType:"${env.GatewayType}", internalApache:true, externalApache:false, gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
					   }
					   
					  // get Gateway PID by calling ansible gateway_pid function
                    gateway_pid Host:'Production_188_6313', GatewayType:"${env.GatewayType}"
					
					after_restart_188_6313_pid = readFile 'Production_188_6313/Gateway_Deployment/IGW01_Production_188_6313_pid.txt'
					
					echo "Gateway PID is:${after_restart_188_6313_pid}"
				
				}
			}
		}
		
		stage("Rollback Restart IGW01 uk2772yr_6313 Gateway") {
		    when { 
			      allOf{
				     not { 
					    expression { return Rollback_Approval }
                        } 
				     not { 
					    expression { return Rollback_Scenario }
                        } 					 
					 }
				}		
			steps {
				script {
					stash_function()
					// get Gateway PID by calling ansible gateway_pid function
                    gateway_pid Host:'Production_189_6313', GatewayType:"${env.GatewayType}"
					
					before_restart_189_6313_pid = readFile 'Production_189_6313/Gateway_Deployment/IGW01_Production_189_6313_pid.txt'
					
					echo "Gateway PID is:${before_restart_189_6313_pid}"
					
					// Check status of gateway and ask for user input if gateway in stopped state
					// get Gateway status by calling ansible gateway_status function
                    gateway_status Host:'Production_189_6313', GatewayType:"${env.GatewayType}"
					
					def gatewayStatus = readFile 'Production_189_6313/Gateway_Deployment/IGW01_Production_189_6313_status.txt'
					
					echo "Gateway Status is:${gatewayStatus}"
					
					if (gatewayStatus == "0"){
					 
					     echo "gateway is running hence restarting"
						 gateway_restart Host:'Production_189_6313', GatewayType:"${env.GatewayType}", internalApache:true, externalApache:false, gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
			
					  }
					 else {
                        echo "gateway is not running"
						gateway_not_running Host:'Production_189_6313', GatewayType:"${env.GatewayType}", internalApache:true, externalApache:false, gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
					    
                         }
					// get Gateway PID by calling ansible gateway_pid function
                    gateway_pid Host:'Production_189_6313', GatewayType:"${env.GatewayType}"
					
					after_restart_189_6313_pid = readFile 'Production_189_6313/Gateway_Deployment/IGW01_Production_189_6313_pid.txt'
					
					echo "Gateway PID is:${after_restart_189_6313_pid}"	
                   // Notify team with status email
					emailext mimeType: 'text/html',
						 subject: "[Jenkins]:${currentBuild.fullDisplayName}:Production Deployment:${params.ReleaseNumber}",
						 from:"CICD_GatewayDeploymentStatus@vodafone.com",
						 to: "${ops_mailRecipients}",
                         body: 	"${get_body_build_summary(DeploymentType:'RollBack', Status:'Success', beforeRestart:before_restart_186_6313_pid, afterRestart:after_restart_186_6313_pid, beforeRestart1:before_restart_187_6313_pid, afterRestart1:after_restart_187_6313_pid, beforeRestart2:before_restart_188_6313_pid, afterRestart2:after_restart_188_6313_pid, beforeRestart3:before_restart_189_6313_pid, afterRestart3:after_restart_189_6313_pid)}"
					
                     echo "Deployment Summary : https://198.18.76.204:9080/jenkins/userContent/Gateway/${env.GatewayType}/${params.ReleaseNumber}/${params.GatewayVersion}/RollBack_Report.html"				
                    					
									
				}
			}
		}			
	
		stage("Signoff Production") {
			steps{
				script{
				        echo "DEBUG: Artefact Version Deployed: ${params.GatewayVersion}"
                        
				}				
			}
		}
		
		/ADO-753185 - Swindon db update
		stage("Swindon DB update")
		{
			steps
			{
				script
				{
					def user = getBuildUserID()
					echo "DB insertion is initiated for Swindon in CDCD Deployment history"
								
					stash_function()			
					def insert_query = """Insert into CICD_DEPLOYMENT_HISTORY ("Release","DateTime","CRQ","ComponentType","Environment","EngineName","BwVersion","EmsVersion","SqlVersion","GatewayVersion","BwDeploymentType","DeploymentStatus","DeploymentTime","XmlFiles","JarFiles","EmailFiles","RF1Status","RBStatus","RF2Status","DVTStatus","BWConfigTag","ChangeDescription","User","FailureReason","updatedTimestamp","BUILD_ID","BUILD_URL") values ('${params.ReleaseNumber}',sysdate,'${params.CRQ}','GATEWAY','${env.GatewayEnvironment}_Swindon','${env.GatewayType}','','','','${params.GatewayVersion}','','Active','','','','','','','','','','','${user}','PASSED',sysdate, '${BUILD_ID}','${BUILD_URL}')"""
			
					println("DEBUG: Insert query is: " + insert_query)
			
					DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${env.dbUserName}", dbPassword: "${env.dbPassword}", dbDriver: "${env.dbDriver}", insertQuery: insert_query
					echo "DB insertion completed"
				}				
			}
		}


    }
}		
