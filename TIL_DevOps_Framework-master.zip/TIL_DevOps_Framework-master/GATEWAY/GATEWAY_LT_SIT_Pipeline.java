//[CICD-476] Fix: import this package as part of the fix
import groovy.time.*

//[CICD-727] Insert Deployment metadata to release notes DB.
import groovy.json.JsonOutput
import groovy.sql.*
import java.sql.Driver


//[CICD-476] Fix: function to get elapsed time duration 
def elapsedTime(Closure closure){
    def timeStart = new Date()
    closure()
    def timeStop = new Date()
    return TimeCategory.minus(timeStop, timeStart).toMilliseconds()
}

def load_groovy_files() {
	// This function is to load all groovy files, where in common functions will be kept.
	emailFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/emailFunctions.groovy"
	commonFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/commonFunctions.groovy"

	//[CICD-727] Insert Deployment metadata to release notes DB.
	DB_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/dbFunctions.groovy"	
}

def checkout_git_repositories() {
	// This function is to checkout all the required GIT repositories.
	checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'JENKINS_FILE']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_DevOps_Framework.git']]])
}

def get_build_num(){
	//This method returns the build number based on the previous build number for corresponding release.
	//String jobName = System.getenv('JOB_NAME')
	println (job_name)
	def seq_no
	def job = jenkins.model.Jenkins.instance.getItemByFullName(job_name)
	for (def build : job.builds){
		if (build.displayName.startsWith("${ReleaseNumber}")){
			//println build.properties.environment.BUILD_NUMBER.toString()
			if (build.displayName.contains('_')){
				seq_no = build.displayName.split("${ReleaseNumber}" + '_')[1].split('_')[0]
				if(seq_no.isInteger()){
				    seq_no = seq_no.toInteger() + 1
					//seq_no += 1
					return seq_no
					break;
				}
			}
		}	
	}
	if (seq_no == null || !seq_no.isInteger()){
		seq_no = 1
		return seq_no
	}
}

def getChangeString() {
	MAX_MSG_LEN = 100
	def changeString = ""

	echo "Gathering SCM changes"
	def changeLogSets = currentBuild.changeSets
	for (int i = 0; i < changeLogSets.size(); i++) {
		def entries = changeLogSets[i].items
		for (int j = 0; j < entries.length; j++) {
			def entry = entries[j]
			truncated_msg = entry.msg.take(MAX_MSG_LEN)
			changeString += "<br><br>${entry.commitId}      by    ${entry.author}    on    ${new Date(entry.timestamp)}:" + "<br>" + "${truncated_msg}" + "<br><br>" 
			def files = new ArrayList(entry.affectedFiles)
			for (int k = 0; k < files.size(); k++) {
				def file = files[k]
				if (file.path.contains("${params.GatewayType}/")  || file.path.contains("Gateway_Configuration/${params.GatewayType}/${params.Environment}/")) {
					changeString += "${file.editType.name} : ${file.path}" + "<br>"
				}
			}
		}
	}
	if (!changeString) {
		changeString = " - No new changes"
	}
	return changeString
}

// Global Parameters to use in the stages.

date_now = new Date()

// Mail recipents for the individual stages.

def dev_mailRecipients = "tanaji.kisangadekar@vodafone.com, tssiukintegrationdevleads@vodafone.com, j.raghavendra@vodafone.com, gopakumar.achari1@vodafone.com, santosh.kumarjha@vodafone.com, ${params.BUILD_REQUESTER}"

def lt_approvers_mailRecipents = "tanaji.kisangadekar@vodafone.com, tssiukintegrationdevleads@vodafone.com, j.raghavendra@vodafone.com, gopakumar.achari1@vodafone.com"

def sit_promote_mailRecipents = "DL-VESTibcoSupport@vodafone.com, tanaji.kisangadekar@vodafone.com, j.raghavendra@vodafone.com, gopakumar.achari1@vodafone.com, tssiukintegrationdevleads@vodafone.com"

def prod_prmotote_mailRecipents = "tanaji.kisangadekar@vodafone.com, j.raghavendra@vodafone.com, gopakumar.achari1@vodafone.com, tssiukintegrationdevleads@vodafone.com"

def get_body_build_summary(deployParams){
	
	def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
		.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		</style>
		<table class="tg" style="undefined;table-layout: fixed; width: 900px">
		<colgroup>
		<col style="width: 100px">
		<col style="width: 350px">
		<col style="width: 100px">
		<col style="width: 350px">
		</colgroup>
		  <tr>
			<th class="tg-amwm" colspan="4">BUILD SUMMARY</th>
		  </tr>
		  <tr>
			<td class="tg-1wig">Submitted By</td>
			<td class="tg-0lax">${currentBuild.getRawBuild().getCauses()[0].getUserId()}</td>
			<td class="tg-1wig">Date</td>
			<td class="tg-0lax">${date_now}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">RELEASE NUMBER</td>
			<td class="tg-0lax">${env.ReleaseNumber}</td>
			<td class="tg-1wig">JIRA NUMBER</td>
			<td class="tg-0lax">${env.JIRANo}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">Gateway Version</td>
			<td class="tg-0lax" colspan="3">${deployParams.artefactVersion}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">JIRADes</td>
			<td class="tg-0lax" colspan="3">${env.JIRADes}</td>
		  </tr>		  
		  <tr>
			<td class="tg-1wig">BUILD_URL</td>
			<td class="tg-0lax" colspan="3">${BUILD_URL}</td>
		  </tr>
		  <tr>
		</table>
		<br><br><br>
		<table class="tg" style="undefined;table-layout: fixed; width: 900px">
		<colgroup>
		<col style="width: 100px">
		<col style="width: 350px">
		<col style="width: 100px">
		<col style="width: 350px">
		</colgroup>
		  <tr>
			<td class="tg-1wig">CHANGES COMMITTED</td>
			<td class="tg-0lax" colspan="3">${getChangeString()}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">LOG_URL</td>
			<td class="tg-0lax" colspan="3">${BUILD_URL}/console</td>
		  </tr>  
		</table>
	"""
	emailBody = body_build_summary
	return body_build_summary
}
SIT_ENV = 'T1'
nextVersion = " "
displayName = " "
emailBody = " "

// [CICD-727]: Push all the deployment details to Release notes DB. 
user = ""

//ADO 623654 Add timeout to the pipeline 

pipeline {
    agent any
	options {
        preserveStashes(buildCount: 49)
        timeout(time: 20, unit: 'DAYS')
    }
/* 	parameters {
        string(name: 'ReleaseNumber', defaultValue: '', description: 'ReleaseNumber')
    	string(name: 'JIRANo', defaultValue: '', description: 'JIRANo')
    	text(name: 'JIRADes', defaultValue: '', description: 'JIRADes')
    } */
    environment {
		//SIT_ENV = "T1"
		GROUPID = "GATEWAY"
		// Moving Gateway type to input parameter
		//GatewayType = "IGW02"
		REPO_URL = "195.233.197.150:8081"
		LT_REPO = "LINKTEST_REPO"
		SIT_REPO = "SIT_REPO"
		PROD_REPO = "PROD_REPO"
		STAGING_REPO = "STAGING_REPO"
		//[CICD-539] Insert Deployment metadata to release notes DB.
		dbURL = 'jdbc:oracle:thin:@195.233.199.13:33000:TIBTST1'
		dbUserName = 'CICD_OWN_DB01'
		dbPassword = 'TIL_CICD_DB'
		dbDriver = 'oracle.jdbc.driver.OracleDriver'
    }

    stages {
		stage('Preparation') {
			steps {
				
				script{
					// Validate input parameters and fail the pipeline if the parameters are not in valid format.
					if (! BUILD_REQUESTER.matches('^[a-zA-Z0-9._%+-]+@vodafone.com$')){
						error('Please enter Valid Vodafone email ID for Build Requester')
						currentBuild.result = 'ABORTED'
					}					
					if (JIRANo.indexOf(' ') != -1){
						error('Parameter validation failed.JIRANo should not contain space in between.')
						currentBuild.result = 'ABORTED'
					}
					
					String regex = /(^CCS\d+\.\d+_[a-zA-Z0-9]+$)|(^CCS\d+\.\d+$)/
					if(ReleaseNumber == ""){
						error('ReleaseNumber is mandatory for Gateway Pipeline')
						currentBuild.result = 'ABORTED'
					} else if(ReleaseNumber.indexOf(' ') != -1){
						error('ReleaseNumber parameter should not contain spaces in between')
						currentBuild.result = 'ABORTED'
					} else if (!(ReleaseNumber ==~ regex)){
						error('ReleaseNumber parameter is not in standard format. Please input either in CCS20.12 or CCS20.12_x format')
						currentBuild.result = 'ABORTED'
					}					
					
					// Checkout required GIT repositories.
					checkout_git_repositories()
				
					//Load all functions files from GIT. point to exact source file
					load_groovy_files()
				
					//Checkout Framework Artefacts from automation repository
					echo "Gateway Type selected is:${params.GatewayType}"
					echo "Release number selected is: ${params.ReleaseNumber}"
				
					displayName = "${params.ReleaseNumber}_${BUILD_NUMBER}_${params.JIRANo}"
					currentBuild.displayName = "${displayName}"
				}
				//checkout gateway build code to show commit message info
				git branch: "${params.ReleaseNumber}", credentialsId: 'GITHUBKEY', poll: false, url: 'https://github.vodafone.com/VFUK-INTEGRATION/Gateway.git'
                // git credentialsId: 'GITHUBKEY', poll: false, url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git'

				emailext mimeType: 'text/html',
						 subject: "[Jenkins]: ${currentBuild.fullDisplayName}  - " + "Build CHANGE LOG SUMMARY",
						 from:"TIL_GATEWAY@vodafone.com",
						 to: "${dev_mailRecipients}",
                         body: 	"${get_body_build_summary(artefactVersion:'')}" 		
			}			
		}
		stage("build") {
			steps {
			    git credentialsId: 'GITHUBKEY', poll: false, url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git'
				script {
					sh label: '', script: 'chmod 755 ./Build/get_next_version.sh'
					nextVersion = sh(script:"./Build/get_next_version.sh ${params.ReleaseNumber} ${env.REPO_URL} ${env.LT_REPO} ${env.GROUPID} ${params.GatewayType}" ,returnStdout: true).trim()
					echo "next Version is: ${nextVersion}"
					
					//Stash the important values so that these can be retrieved for stage restart.
					sh "mkdir -p DIR_STASH"
					sh "echo nextVersion:${nextVersion} >DIR_STASH/propfile"
					sh "echo displayName:${displayName} >>DIR_STASH/propfile"
					stash includes: 'DIR_STASH/propfile', name: 'stashProperties'

					// Tokenise the env specific variables,zip the config files, generate the build number, upload artefact to Nexus Linktest Repo
					build job: 'Gateway/GatewayJobs/Gateway_Build', parameters: [string(name: 'BranchName', value: "${params.ReleaseNumber}"), string(name: 'IRIS_NO', value: "${params.JIRANo}"), string(name: 'GroupId', value: "${env.GROUPID}"), string(name: 'Repository', value: "${LT_REPO}"), string(name: 'ArtifactId', value: "${params.GatewayType}"), text(name: 'IRISDes', value: "${params.JIRADes}"), string(name: 'GatewayType', value: "${params.GatewayType}"), string(name: 'Version', value: "${nextVersion}"), string(name: 'Parent_Job_Workspace', value: "${WORKSPACE}")]
					echo "Build Job is completed"
					
					// get the updated email body.
					emailBody = "${get_body_build_summary(artefactVersion:nextVersion)}"				
				}
			}
		}
		stage("LinkTest Notify Partner config Update") {
			when {
				expression { PartnerConfig == "true" }                    
			}			
			steps {
				// When Partner config is selected, send an email to DEV team to approve the partner config changes.
				script {
					GatewayUsers = commonFunctions.get_approvers_list('GatewayUsers')
					
					emailext mimeType: 'text/html',
						 subject: "[Jenkins]:${currentBuild.fullDisplayName}:Approval email for Partner Config Check?",
						 from:"TIL_GATEWAY@vodafone.com",
						 to: "${lt_approvers_mailRecipents}",
						 body: 	"${emailBody}" + "<br>" + 
								"<br><br><p><b><font size='5' color='Black'>Approve Partner Config changes : <a href='${BUILD_URL}input'>${currentBuild.displayName}</a></font></b></p>"
					def testOptions = 'YES\nNO'
					def userInput = input(
					  id: 'userInput', message: 'Partner Config changes updated and checked-in?',
					  submitterParameter: 'submitter',
					  submitter: "${GatewayUsers}"
					)	
				}
			}
		}		
		stage("Deploy to LinkTest Environment") {
			steps {
				script {
					// If the following values are blank, it means we are starting from stage and need to retrive the values from stash.
					unstash "stashProperties"
					if (nextVersion == " ") {
						nextVersion = sh(script:"cat ./DIR_STASH/propfile | grep -e nextVersion | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						echo "nextVersion after stage restart is:${nextVersion}"
					}
					if (displayName == " ") {
						//[CICD-593]: Checkout required GIT repositories after stage restart.
						checkout_git_repositories()						
						load_groovy_files()
						displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						currentBuild.displayName = "${displayName}_restart"
						echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
					}
 					if (emailBody == " ") {
						emailBody = "${get_body_build_summary(artefactVersion:nextVersion)}"
						echo "emailBody after stage restart is:${emailBody}"
					} 
				}
				// Invoke Ansible for Deployment
				sleep 5
				build job: 'Gateway/GatewayJobs/Gateway_Deployment', parameters: [string(name: 'Environment', value: "${params.Environment}"), string(name: 'repo_group_id', value: "${env.GROUPID}"), string(name: 'repo_artifact_id', value: "${params.GatewayType}"), string(name: 'repo_user', value: 'admin'), string(name: 'repo_repo_id', value: 'LINKTEST_REPO'), string(name: 'ArtefactVersion', value: "${nextVersion}"), string(name: 'GatewayType', value: "${params.GatewayType}")]
				echo " ${params.Environment} Deploy completed"
	            
                // Invoke job to update dashboard
				// Update dashboard with status
				// CICD-573 fix
					build job: '/TIL_PIPELINES/Common_Jobs/Dashboard_Publish', parameters: [string(name: 'Environment', value: "${params.Environment}"), string(name: 'Component', value: "${params.GatewayType}"), string(name: 'ArtefactVersion', value: "${nextVersion}"), string(name: 'Pipeline', value: "${params.GatewayType}_Pipeline"), string(name: 'Description', value: '')]
								
	
			}
		}
		stage("Deployment Validation In LinkTest Environment") {
			steps{
				// Run Automated tests if we have
				build 'Gateway/GatewayJobs/Gateway_SystemTesting'
				script{
					unstash "stashProperties"
					if (nextVersion == " ") {
						nextVersion = sh(script:"cat ./DIR_STASH/propfile | grep -e nextVersion | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						echo "nextVersion after stage restart is:${nextVersion}"
					}
					if (displayName == " ") {
						//[CICD-593]: Checkout required GIT repositories after stage restart.
						checkout_git_repositories()						
						load_groovy_files()
						displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						currentBuild.displayName = "${displayName}_restart"
						echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
					}
					if (emailBody == " ") {
						emailBody = "${get_body_build_summary(artefactVersion:nextVersion)}"
						echo "emailBody after stage restart is:${emailBody}"
					}
					
					GatewayApprovers = commonFunctions.get_approvers_list('GatewayApprovers')

					//[CICD-187]: [CICD-437] Enhance to generate release notes for SIT team.

					def emailContent = 	emailFunctions.get_gateway_sit_release_notes GATEWAY_TYPE: "${params.GatewayType}", RELEASE: "${params.ReleaseNumber}", CRQ: "${params.JIRANo}", gatewayVersion: "${nextVersion}", Description: "${params.JIRADes}", operation: OPERATION_NAME.replaceAll("[\\t\\n\\r]+","<br>"), partnerData: PARTNER_DATA.replaceAll("[\\t\\n\\r]+","<br>"), tokens: TOKENS.replaceAll("[\\t\\n\\r]+","<br>"), specialInst: SPECIAL_INSTRUCTIONS.replaceAll("[\\t\\n\\r]+","<br>")
					
					emailext mimeType: 'text/html',
						subject: "[Jenkins]:${currentBuild.fullDisplayName}:GATEWAY RELEASE NOTES FOR ${params.GatewayType} for ${params.RELEASE}",
						from:"TIL_DEPLOYMENTS@vodafone.com",
						to: "${dev_mailRecipients}",
						body: "${emailContent}"

 					emailext mimeType: 'text/html',
						 subject: "[Jenkins]:${currentBuild.fullDisplayName}:Approval email for promote Artefact to SIT",
						 from:"TIL_GATEWAY@vodafone.com",
						 to: "${lt_approvers_mailRecipents}",
						 body: 	"${emailBody}" + "<br>" + 
								"<br><br><p><b><font size='5' color='Black'>Signoff LinkTest Changes for deploying into SIT: <a href='${BUILD_URL}input'>${currentBuild.displayName}</a></font></b></p>"
					def testOptions = 'YES\nNO'
					def userInput = input(
					  id: 'userInput', message: 'Do you want to promote Artefact to SIT?',
					  submitterParameter: 'submitter',
					  submitter: "${GatewayApprovers}" 
					)
					
					//Promote Artifact to SIT Repository.
					
					build job: 'Gateway/GatewayJobs/Gateway_Artefact_Promotion', parameters: [string(name: 'GroupId', value: "${env.GROUPID}"), string(name: 'ArtifactId', value: "${params.GatewayType}"), string(name: 'VersionNo', value: "${nextVersion}"), string(name: 'SourceRepo', value: "${LT_REPO}"), string(name: 'DestinationRepo', value: "${SIT_REPO}")]					
					
					//[CICD-727]: Push all the deployment details to Release notes DB.
					
					user = currentBuild.rawBuild.causes[0].userId
					
					def release_ins_query = """Insert into CICD_RELEASE_SUMMARY (RELEASE_NO,PROJECT_NAME,JIRA_NO,CHANGE_DESCRIPTION,ENGINE_NAME,OPERATION,EAR_VERSION,EMS_VERSION,SQL_VERSION,COMPONENT_TYPE,STATUS,MASTER_GV,PROCESS_GV,ENGINE_TEMPLATE,APPEND_PREPEND,KNOWN_ERROR_INCLUSION,POST_MANUAL_CHANGES,PARTNER_DATA,GATEWAY_TOKEN,SPECIAL_INSTRUCTIONS,LINKTEST_RESULTS,CREATED_ON,GATEWAY_VERSION,GATEWAY_TYPE,CREATED_BY,FILE_CHANGES,APPROVAL,MODIFIED_ON,MODIFIED_BY,RESTART_ENGINES,BUILD_ID,BUILD_URL) values ('${params.ReleaseNumber}','','${params.JIRANo}','${params.JIRADes}','','${params.OPERATION_NAME}','','','','GATEWAY','Active','','','','','','','${params.PARTNER_DATA}','${params.TOKENS}','${params.SPECIAL_INSTRUCTIONS}','PASSED',sysdate,'${nextVersion}','${params.GatewayType}','${user}','','','','','','${BUILD_ID}','${BUILD_URL}')"""
					println("DEBUG: release notes Insert query is: " + release_ins_query)
					DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: release_ins_query
					
                    //[CICD-549] Insert Deployment metadata to deploment history database DB.
 					
					def insert_query = """Insert into CICD_DEPLOYMENT_HISTORY ("Release","DateTime","CRQ","ComponentType","Environment","EngineName","BwVersion","EmsVersion","SqlVersion","GatewayVersion","BwDeploymentType","DeploymentStatus","DeploymentTime","XmlFiles","JarFiles","EmailFiles","RF1Status","RBStatus","RF2Status","DVTStatus","BWConfigTag","ChangeDescription","User","FailureReason","updatedTimestamp","BUILD_ID","BUILD_URL") values ('${params.ReleaseNumber}',sysdate,'${params.JIRANo}','GATEWAY','${params.Environment}','${params.GatewayType}','','','','${nextVersion}','','Active','','','','','','','','','','${params.JIRADes}','${user}','PASSED',sysdate,'${BUILD_ID}','${BUILD_URL}')"""
		
					println("DEBUG: Insert query is: " + insert_query)
		
					DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: insert_query
				}				
			}
		}
		stage("Promote to SIT") {
			steps {
				// Approval to move code to SIT
				//input "Promote Change ${JIRANo} to ${SIT_Environment} environment ?"
				script{
					unstash "stashProperties"
					if (nextVersion == " ") {
						nextVersion = sh(script:"cat ./DIR_STASH/propfile | grep -e nextVersion | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						echo "nextVersion after stage restart is:${nextVersion}"
					}
					if (displayName == " ") {
						//[CICD-593]: Checkout required GIT repositories after stage restart.
						checkout_git_repositories()						
						load_groovy_files()
						displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						currentBuild.displayName = "${displayName}_restart"
						echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
					}
					if (emailBody == " ") {
						emailBody = "${get_body_build_summary(artefactVersion:nextVersion)}"
						echo "emailBody after stage restart is:${emailBody}"
					}
					promoteSITApprovers = commonFunctions.get_approvers_list('promoteSITApprovers')
					emailext mimeType: 'text/html',
						 subject: "[Jenkins]${currentBuild.fullDisplayName}:Choose SIT Environment to Deploy",
						 from:"TIL_GATEWAY@vodafone.com",
						 to: "${sit_promote_mailRecipents}",
						 body: 	"${emailBody}" + "<br>" +
								"<br><br><p><b><font size='5' color='Black'>CHOOSE SIT ENVIRONMENT TO DEPLOY: <a href='${BUILD_URL}input'>${currentBuild.displayName}</a></font></b></p>"						 

					def deployOptions = 'T1\nT3\nT4\nT7\nSIT04\nT8\nTILSIT1\nTILSIT2\nTILSIT3\nTILSIT5'
					def userInput = input(
					    id: 'userInput',
						message: 'Can you approve this ??', 
						submitterParameter: 'submitter',
						submitter: "${promoteSITApprovers}",
						parameters: [
									[$class: 'TextParameterDefinition', defaultValue: '0000', description: 'CHANGE REQUEST NUMBER', name: 'CRNum'],
									[$class: 'ChoiceParameterDefinition', choices: deployOptions, description: 'SELECT SIT ENVIRONMNET TO DEPLOY', name: 'SELECT_SIT_ENVIRONMNET_TO_DEPLOY']
							])
					echo (" Selected Environment is:"+userInput['SELECT_SIT_ENVIRONMNET_TO_DEPLOY'])
					SIT_ENV = sh(script: "echo ${userInput['SELECT_SIT_ENVIRONMNET_TO_DEPLOY']}", returnStdout: true).trim()
					//env.SIT_ENV = userInput['SELECT_SIT_ENVIRONMNET_TO_DEPLOY']
					echo ("CR NUMBER: "+userInput['CRNum'])
					echo ("submitted by: "+userInput['submitter'])
					//echo ("ENVIRONMENT SELECTED IS:"+userInput['SITENVIRONMENT'])
					//jobs = jobs + userInput['SITENVIRONMENT']
				}								
				echo "Promotion to ${SIT_ENV} is chosen"
				sleep 5
			}
		}
		stage("SIT Notify Partner config Update") {
			when {
				expression { PartnerConfig == "true" }                    
			}			
			steps {
				// When Partner config is selected, send an email to DEV team to approve the partner config changes.
				script {
					unstash "stashProperties"
					if (nextVersion == " ") {
						nextVersion = sh(script:"cat ./DIR_STASH/propfile | grep -e nextVersion | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						echo "nextVersion after stage restart is:${nextVersion}"
					}
					if (displayName == " ") {
						//[CICD-593]: Checkout required GIT repositories after stage restart.
						checkout_git_repositories()						
						load_groovy_files()
						displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						currentBuild.displayName = "${displayName}_restart"
						echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
					}
					if (emailBody == " ") {
						emailBody = "${get_body_build_summary(artefactVersion:nextVersion)}"
						echo "emailBody after stage restart is:${emailBody}"
					}
					promoteSITApprovers = commonFunctions.get_approvers_list('promoteSITApprovers')
					emailext mimeType: 'text/html',
						 subject: "[Jenkins]:${currentBuild.fullDisplayName}:Approval email for Partner Config Check?",
						 from:"TIL_GATEWAY@vodafone.com",
						 to: "${sit_promote_mailRecipents}",
						 body: 	"${emailBody}" + "<br>" + 
								"<br><br><p><b><font size='5' color='Black'>Approve Partner Config changes : <a href='${BUILD_URL}input'>${currentBuild.displayName}</a></font></b></p>"
					def testOptions = 'YES\nNO'
					def userInput = input(
					  id: 'userInput', message: 'Partner Config changes updated and checked-in?',
					  submitterParameter: 'submitter',
					  submitter: "${promoteSITApprovers}"
					)	
				}
			}
		}		
		stage("Deploy to SIT") {
			steps {
				// Deploy to SIT
				script {
					echo "Deploy to ${SIT_ENV} completed"
					unstash "stashProperties"
					if (nextVersion == " ") {
						nextVersion = sh(script:"cat ./DIR_STASH/propfile | grep -e nextVersion | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						echo "nextVersion after stage restart is:${nextVersion}"
					}
					if (displayName == " ") {
						//[CICD-593]: Checkout required GIT repositories after stage restart.
						checkout_git_repositories()						
						load_groovy_files()
						displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						currentBuild.displayName = "${displayName}_restart"
						echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
					}
					if (emailBody == " ") {
						emailBody = "${get_body_build_summary(artefactVersion:nextVersion)}"
						echo "emailBody after stage restart is:${emailBody}"
					}
				}
				build job: 'Gateway/GatewayJobs/Gateway_Deployment', parameters: [string(name: 'Environment', value: "${SIT_ENV}"), string(name: 'repo_group_id', value: "${env.GROUPID}"), string(name: 'repo_artifact_id', value: "${params.GatewayType}"), string(name: 'repo_user', value: 'admin'), string(name: 'repo_repo_id', value: 'SIT_REPO'), string(name: 'ArtefactVersion', value: "${nextVersion}"), string(name: 'GatewayType', value: "${params.GatewayType}")]
				
				// Invoke job to update dashboard
				// Update dashboard with status
				// CICD-573 fix
					build job: '/TIL_PIPELINES/Common_Jobs/Dashboard_Publish', parameters: [string(name: 'Environment', value: "${SIT_ENV}"), string(name: 'Component', value: "${params.GatewayType}"), string(name: 'ArtefactVersion', value: "${nextVersion}"), string(name: 'Pipeline', value: "${params.GatewayType}_Pipeline"), string(name: 'Description', value: '')]
				
			}	
		}
		stage("Testing in SIT") {
			steps {
				//wait for Testing in SIT
				script {
					unstash "stashProperties"
					if (nextVersion == " ") {
						nextVersion = sh(script:"cat ./DIR_STASH/propfile | grep -e nextVersion | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						echo "nextVersion after stage restart is:${nextVersion}"
					}
					if (displayName == " ") {
						//[CICD-593]: Checkout required GIT repositories after stage restart.
						checkout_git_repositories()						
						load_groovy_files()
						displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						currentBuild.displayName = "${displayName}_restart"
						echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
					}
					if (emailBody == " ") {
						emailBody = "${get_body_build_summary(artefactVersion:nextVersion)}"
						echo "emailBody after stage restart is:${emailBody}"
					}
				}
				echo "Testing in  ${SIT_ENV} completed"
				//input message: 'Promote change to Prod repositories if SIT Testing is Successful', ok: 'Success'
			}
		}			
		stage('Signoff'){
			steps {
				//Promote artefact to PROD Repo
				script{
					echo "INFO: Deployment is Successful."
					
					//[CICD-1524]: Getting user name for SIT deployment history
					user = currentBuild.rawBuild.causes[0].userId
					
					//[CICD-549] Insert Deployment metadata to deploment history database DB.
					
 					
					def insert_query = """Insert into CICD_DEPLOYMENT_HISTORY ("Release","DateTime","CRQ","ComponentType","Environment","EngineName","BwVersion","EmsVersion","SqlVersion","GatewayVersion","BwDeploymentType","DeploymentStatus","DeploymentTime","XmlFiles","JarFiles","EmailFiles","RF1Status","RBStatus","RF2Status","DVTStatus","BWConfigTag","ChangeDescription","User","FailureReason","updatedTimestamp","BUILD_ID","BUILD_URL") values ('${params.ReleaseNumber}',sysdate,'${params.JIRANo}','GATEWAY','${SIT_ENV}','${params.GatewayType}','','','','${nextVersion}','','Active','','','','','','','','','','${params.JIRADes}','${user}','PASSED',sysdate,'${BUILD_ID}','${BUILD_URL}')"""
		
					println("DEBUG: Insert query is: " + insert_query)
		
					DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: insert_query					
				}					
			}
		}	

    }
}
