//[CICD-476] Fix: import this package as part of the fix
import groovy.time.*


//[CICD-476] Fix: function to get elapsed time duration 
def elapsedTime(Closure closure){
    def timeStart = new Date()
    closure()
    def timeStop = new Date()
    return TimeCategory.minus(timeStop, timeStart).toMilliseconds()
}

def load_groovy_files() {
	// This function is to load all groovy files, where in common functions will be kept.
	emailFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/emailFunctions.groovy"
	commonFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/commonFunctions.groovy"
	
}

def checkout_git_repositories() {
	// This function is to checkout all the required GIT repositories.
	checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'JENKINS_FILE']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_DevOps_Framework.git']]])
}

def get_build_num(){
	//This method returns the build number based on the previous build number for corresponding release.
	//String jobName = System.getenv('JOB_NAME')
	println (job_name)
	def seq_no
	def job = jenkins.model.Jenkins.instance.getItemByFullName(job_name)
	for (def build : job.builds){
		if (build.displayName.startsWith("${ReleaseNumber}")){
			//println build.properties.environment.BUILD_NUMBER.toString()
			if (build.displayName.contains('_')){
				seq_no = build.displayName.split("${ReleaseNumber}" + '_')[1].split('_')[0]
				if(seq_no.isInteger()){
				    seq_no = seq_no.toInteger() + 1
					//seq_no += 1
					return seq_no
					break;
				}
			}
		}	
	}
	if (seq_no == null || !seq_no.isInteger()){
		seq_no = 1
		return seq_no
	}
}

def getChangeString() {
	MAX_MSG_LEN = 100
	def changeString = ""

	echo "Gathering SCM changes"
	def changeLogSets = currentBuild.changeSets
	for (int i = 0; i < changeLogSets.size(); i++) {
		def entries = changeLogSets[i].items
		for (int j = 0; j < entries.length; j++) {
			def entry = entries[j]
			truncated_msg = entry.msg.take(MAX_MSG_LEN)
			changeString += "<br><br>${entry.commitId}      by    ${entry.author}    on    ${new Date(entry.timestamp)}:" + "<br>" + "${truncated_msg}" + "<br><br>" 
			def files = new ArrayList(entry.affectedFiles)
			for (int k = 0; k < files.size(); k++) {
				def file = files[k]
				if (file.path.contains("${params.GatewayType}/")  || file.path.contains("Gateway_Configuration/${params.GatewayType}/${params.Environment}/")) {
					changeString += "${file.editType.name} : ${file.path}" + "<br>"
				}
			}
		}
	}
	if (!changeString) {
		changeString = " - No new changes"
	}
	return changeString
}

// Global Parameters to use in the stages.

date_now = new Date()

// Mail recipents for the individual stages.


def sit_promote_mailRecipents = "DL-VESTibcoSupport@vodafone.com, avatansh.sharma@vodafone.com, apoorva.agarwal@vodafone.com, tanaji.kisangadekar@vodafone.com, vikas.kumar42@vodafone.com, vipul.sharma1@vodafone.com, vipul.gautam@vodafone.com, jyoti.ranjanpradhan@vodafone.com, tssiukintegrationdevleads@vodafone.com, ${params.BUILD_REQUESTER}"

def get_body_build_summary(deployParams){
	
	def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
		.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		</style>
		<table class="tg" style="undefined;table-layout: fixed; width: 900px">
		<colgroup>
		<col style="width: 100px">
		<col style="width: 350px">
		<col style="width: 100px">
		<col style="width: 350px">
		</colgroup>
		  <tr>
			<th class="tg-amwm" colspan="4">BUILD SUMMARY</th>
		  </tr>
		  <tr>
			<td class="tg-1wig">Submitted By</td>
			<td class="tg-0lax">${currentBuild.getRawBuild().getCauses()[0].getUserId()}</td>
			<td class="tg-1wig">Date</td>
			<td class="tg-0lax">${date_now}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">RELEASE NUMBER</td>
			<td class="tg-0lax">${env.ReleaseNumber}</td>
			<td class="tg-1wig">JIRA NUMBER</td>
			<td class="tg-0lax">${env.JIRANo}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">Gateway Version</td>
			<td class="tg-0lax" colspan="3">${deployParams.artefactVersion}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">JIRADes</td>
			<td class="tg-0lax" colspan="3">${env.JIRADes}</td>
		  </tr>		  
		  <tr>
			<td class="tg-1wig">BUILD_URL</td>
			<td class="tg-0lax" colspan="3">${BUILD_URL}</td>
		  </tr>
		  <tr>
		</table>
		<br><br><br>
		<table class="tg" style="undefined;table-layout: fixed; width: 900px">
		<colgroup>
		<col style="width: 100px">
		<col style="width: 350px">
		<col style="width: 100px">
		<col style="width: 350px">
		</colgroup>
		  <tr>
			<td class="tg-1wig">CHANGES COMMITTED</td>
			<td class="tg-0lax" colspan="3">${getChangeString()}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">LOG_URL</td>
			<td class="tg-0lax" colspan="3">${BUILD_URL}/console</td>
		  </tr>  
		</table>
	"""
	emailBody = body_build_summary
	return body_build_summary
}
SIT_ENV = ''
nextVersion = " "
displayName = " "
emailBody = " "

// [CICD-727]: Push all the deployment details to Release notes DB. 
user = ""

pipeline {
    agent any
	options {
        preserveStashes(buildCount: 49)
    }
/* 	parameters {
        string(name: 'ReleaseNumber', defaultValue: '', description: 'ReleaseNumber')
    	string(name: 'JIRANo', defaultValue: '', description: 'JIRANo')
    	text(name: 'JIRADes', defaultValue: '', description: 'JIRADes')
    } */
    environment {
		SIT_ENV = "${params.Environment}"
		GROUPID = "GATEWAY"
		// Moving Gateway type to input parameter
		//GatewayType = "IGW02"
		REPO_URL = "195.233.197.150:8081"
		
		SIT_REPO = "SIT_REPO"
		
    }

    stages {
		stage('Preparation') {
			steps {
				
				script{
					// Validate input parameters and fail the pipeline if the parameters are not in valid format.
					if (! BUILD_REQUESTER.matches('^[a-zA-Z0-9._%+-]+@vodafone.com$')){
						error('Please enter Valid Vodafone email ID for Build Requester')
						currentBuild.result = 'ABORTED'
					}					
					if (JIRANo.indexOf(' ') != -1){
						error('Parameter validation failed.JIRANo should not contain space in between.')
						currentBuild.result = 'ABORTED'
					}
					
					String regex = /(^CCS\d+\.\d+_[a-zA-Z0-9]+$)|(^CCS\d+\.\d+$)/
					if(ReleaseNumber == ""){
						error('ReleaseNumber is mandatory for Gateway Pipeline')
						currentBuild.result = 'ABORTED'
					} else if(ReleaseNumber.indexOf(' ') != -1){
						error('ReleaseNumber parameter should not contain spaces in between')
						currentBuild.result = 'ABORTED'
					} else if (!(ReleaseNumber ==~ regex)){
						error('ReleaseNumber parameter is not in standard format. Please input either in CCS20.12 or CCS20.12_x format')
						currentBuild.result = 'ABORTED'
					}					
					
					// Checkout required GIT repositories.
					checkout_git_repositories()
				
					//Load all functions files from GIT. point to exact source file
					load_groovy_files()
				
					//Checkout Framework Artefacts from automation repository
					echo "Gateway Type selected is:${params.GatewayType}"
					echo "Release number selected is: ${params.ReleaseNumber}"
				
					displayName = "${params.ReleaseNumber}_${get_build_num()}_${params.JIRANo}"
					currentBuild.displayName = "${displayName}"
				}
				//checkout gateway build code to show commit message info
				git branch: "${params.ReleaseNumber}", credentialsId: 'GITHUBKEY', poll: false, url: 'https://github.vodafone.com/VFUK-INTEGRATION/Gateway.git'
                // git credentialsId: 'GITHUBKEY', poll: false, url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git'

				emailext mimeType: 'text/html',
						 subject: "[Jenkins]: ${currentBuild.fullDisplayName}  - " + "Build CHANGE LOG SUMMARY",
						 from:"TIL_GATEWAY",
						 to: "${sit_promote_mailRecipents}",
                         body: 	"${get_body_build_summary(artefactVersion:'')}" 		
			}			
		}
		stage("SIT Notify Partner config Update") {
			when {
				expression { PartnerConfig == "true" }                    
			}			
			steps {
				// When Partner config is selected, send an email to DEV team to approve the partner config changes.
				script {
					unstash "stashProperties"
					if (nextVersion == " ") {
						nextVersion = sh(script:"cat ./DIR_STASH/propfile | grep -e nextVersion | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						echo "nextVersion after stage restart is:${nextVersion}"
					}
					if (displayName == " ") {
						//[CICD-593]: Checkout required GIT repositories after stage restart.
						checkout_git_repositories()						
						load_groovy_files()
						displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						currentBuild.displayName = "${displayName}_restart"
						echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
					}
					if (emailBody == " ") {
						emailBody = "${get_body_build_summary(artefactVersion:nextVersion)}"
						echo "emailBody after stage restart is:${emailBody}"
					}
					promoteSITApprovers = commonFunctions.get_approvers_list('promoteSITApprovers')
					emailext mimeType: 'text/html',
						 subject: "[Jenkins]:${currentBuild.fullDisplayName}:Approval email for Partner Config Check?",
						 from:"TIL_GATEWAY",
						 to: "${sit_promote_mailRecipents}",
						 body: 	"${emailBody}" + "<br>" + 
								"<br><br><p><b><font size='5' color='Black'>Approve Partner Config changes : <a href='${BUILD_URL}input'>${currentBuild.displayName}</a></font></b></p>"
					def testOptions = 'YES\nNO'
					def userInput = input(
					  id: 'userInput', message: 'Partner Config changes updated and checked-in?',
					  submitterParameter: 'submitter',
					  submitter: "${promoteSITApprovers}"
					)	
				}
			}
		}		
		stage("Deploy to DR_SIT") {
			steps {
				
				script {
					echo "Deploy to ${SIT_ENV} completed"
					unstash "stashProperties"
					if (nextVersion == " ") {
						nextVersion = sh(script:"cat ./DIR_STASH/propfile | grep -e nextVersion | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						echo "nextVersion after stage restart is:${nextVersion}"
					}
					if (displayName == " ") {
						//[CICD-593]: Checkout required GIT repositories after stage restart.
						checkout_git_repositories()						
						load_groovy_files()
						displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						currentBuild.displayName = "${displayName}_restart"
						echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
					}
					if (emailBody == " ") {
						emailBody = "${get_body_build_summary(artefactVersion:nextVersion)}"
						echo "emailBody after stage restart is:${emailBody}"
					}
				}
				build job: 'DR_Pipeline/DR Gateway_Pipelines/DR_Gateway_Jobs/DR_Gateway_Deployment', parameters: [string(name: 'Environment', value: "${SIT_ENV}"), string(name: 'repo_group_id', value: "${env.GROUPID}"), string(name: 'repo_artifact_id', value: "${params.GatewayType}"), string(name: 'repo_user', value: 'admin'), string(name: 'repo_repo_id', value: 'SIT_REPO'), string(name: 'ArtefactVersion', value: "${nextVersion}"), string(name: 'GatewayType', value: "${params.GatewayType}")]
				
			}	
		}
			

    }
}
