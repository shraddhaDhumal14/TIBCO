

// Global Parameters to use in the stages.

date_now = new Date()



pipeline {
    agent any
	options {
        preserveStashes(buildCount: 49)
    }
	
    environment {
		GROUPID = "GATEWAY"
		//GatewayType = "IGW01"
		REPO_URL = "195.233.197.150:8081"
		SIT_REPO = "SIT_REPO"

    }

    stages {
		stage('Preparation') {
			steps {
				//Checkout Framework Artefacts from automation repository
				echo "Gateway Type selected is:${Gateway}"
				script{
				        if (Build_Version == ""){
						           currentBuild.result = 'ABORTED'
                                   error('Build_Version should be specified for the uplift')
						      }
					displayName = "${env.Gateway}_${env.Environment}_${env.Build_Version}"
					currentBuild.displayName = "${displayName}"
				}
						
			}			
		}

		
		stage("Environment Uplift") {
			steps {

				build job: 'Gateway/GatewayJobs/Gateway_Deployment', parameters: [string(name: 'Environment', value: "${env.Environment}"), string(name: 'repo_group_id', value: "${env.GROUPID}"), string(name: 'repo_artifact_id', value: "${env.Gateway}"), string(name: 'repo_user', value: 'admin'), string(name: 'repo_repo_id', value: "${env.SIT_REPO}"), string(name: 'ArtefactVersion', value: "${env.Build_Version}"), string(name: 'GatewayType', value: "${Gateway}")]
				echo " Linktest Deploy completed"
				
				// Update dashboard with status
				build job: '/TIL_PIPELINES/Common_Jobs/Dashboard_Publish', parameters: [string(name: 'Environment', value: "${env.Environment}"), string(name: 'Component', value: "${env.Gateway}"), string(name: 'ArtefactVersion', value: "${env.Build_Version}"), string(name: 'Pipeline', value: 'Gateway_Uplift'), string(name: 'Description', value: '')]				
				
			}
		}
		
	}	
}