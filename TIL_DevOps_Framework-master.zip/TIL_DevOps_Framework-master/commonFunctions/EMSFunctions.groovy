
/*********************************************************************************************************************
Author: Anil Kolli & Raghuram Koripalli
Date: 13/04/2020
/*********************************************************************************************************************
This file holds all the functions related to EMS generate and deployment.
Below are the functions listed in thsi file.
1. generate_ems_deployment()

/*********************************************************************************************************************
This function will generate ems workspace , download artefacts and take care of validation..

/*EMS Generate Function 
Input : 
	1. nexus_group_id
	2. nexus_user
	3. nexus_passwd
	4. nexus_repo_id
	5. nexus_url
	6. engines
	7. datetime
	8. crq_no
	9. release
	10. Environment
	11. emsIgnore
Output: 
	None. ( Creates workspace in EMS server and copy all the artefacts along with validations.)

*********************************************************************************************************************/

def generate_ems_deployment(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{

		//Checkout Framework Artefacts from automation repository
		checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "EMS_Deploy_${deployParams.Environment}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]			


		// move Environment Specific EMS Configurations to EMS Deployment Scripts location
		sh "mv ./EMS_Deploy_ENV/EMS_Configuration/${deployParams.Environment}/* ./EMS_Deploy_${deployParams.Environment}/EMS_Deployment"

		//Run ansible playbook to generate ems deployment  into environment
		ansiColor('xterm') {
			ansiblePlaybook(playbook: "./EMS_Deploy_${deployParams.Environment}/EMS_Deployment/generate.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Environment}_EMS", repo_group_id: "${deployParams.nexus_group_id}", repo_artifact_ids: "${deployParams.ems_engines}", repo_user: "${deployParams.nexus_user}", repo_pw: "${deployParams.nexus_passwd}", repo_repo_id: "${deployParams.nexus_repo_id}", repo_url: "${deployParams.nexus_url}", datetime: "${deployParams.datetime}", crq_num: "${deployParams.crq_no}", release: "${deployParams.release}", Environment: "${deployParams.Environment}", emsIgnore: "${deployParams.emsIgnore}"])
		}  	
    }
}

/*********************************************************************************************************************
/*EMS Deploy Function 
Input : 
	1. ems_engines
	2. datetime
	3. crq_no
	4. release
	5. Environment
	6. emsIgnore
	7. rollbackBackup
Output: None ( Runs the deployment and writes all failed engines in a file in workspace)
*********************************************************************************************************************/

def ems_deployment(deployParams) {
	//Running ansible play for deployment
	script{
		ansiColor('xterm') {
			ansiblePlaybook(playbook: "./EMS_Deploy_${deployParams.Environment}/EMS_Deployment/deploy.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Environment}_EMS", repo_artifact_ids: "${deployParams.ems_engines}", datetime: "${deployParams.datetime}", crq_num: "${deployParams.crq_no}", release: "${deployParams.release}", Environment: "${deployParams.Environment}", emsIgnore: "${deployParams.emsIgnore}", rollbackBackup:"${deployParams.rollbackBackup}"])
		}  	
    }
}


/*********************************************************************************************************************
/*EMS Rollback Function 
Input : 
	1. ems_engines
	2. datetime
	3. crq_no
	4. release
	5. Environment
	6. emsIgnore
	7. rollbackBackup
Output: None ( Runs the deployment and writes all failed engines in a file in workspace)
*********************************************************************************************************************/

def ems_rollback(deployParams) {
	//Running ansible play for rollback
	script{
		ansiColor('xterm') {
			ansiblePlaybook(playbook: "./EMS_Deploy_${deployParams.Environment}/EMS_Deployment/emsExplicitEngines.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Environment}_EMS", engines: "${deployParams.ems_engines}", datetime: "${deployParams.datetime}", crq_num: "${deployParams.crq_no}", release: "${deployParams.release}", Environment: "${deployParams.Environment}", emsIgnore: "${deployParams.emsIgnore}", rollbackBackup:"${deployParams.rollbackBackup}"])
		}  	
    }
}

def build_ems(deployParams) {
	// This function to build the SQL artefacts and then push to nexus.
		/*----------------------------------------------------------------------------------------
		stage setup part.
		------------------------------------------------------------------------------------------*/

		// Checkout EMS Artefacts from TIL_SQL Repository 
		checkout([$class: 'GitSCM', doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "EMS_Code"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_EMS.git']]])		
		
		
		
		//CICD-557 Dependency Validation Checkout
		
		// Do dos2unix for EMS rollback and rollforward files.
		sh "dos2unix ${WORKSPACE}/EMS_Code/${deployParams.RELEASE}/${deployParams.engine}/*.ems"
		
		// Create directory in EMS Build folder as required by Dependency Validationcheck script
		sh "mkdir -p ${WORKSPACE}/AUTOMATION/EMS_Build/${deployParams.RELEASE}/${deployParams.engine}/rollback"
		 
		// Copy Files to EMS Build folder for running dependecy validations
		sh "cp -R ${WORKSPACE}/EMS_Code/${deployParams.RELEASE}/${deployParams.engine} ${WORKSPACE}/AUTOMATION/EMS_Build/${deployParams.RELEASE}"
		
		
		// Move rollback files to rollback folder
		sh "mv ${WORKSPACE}/AUTOMATION/EMS_Build/${deployParams.RELEASE}/${deployParams.engine}/Rollback*.ems ${WORKSPACE}/AUTOMATION/EMS_Build/${deployParams.RELEASE}/${deployParams.engine}/rollback"
		
		// run dos2unix on dependency validations
        sh "dos2unix ${WORKSPACE}/AUTOMATION/EMS_Build/*.sh"
		sh label: '', script: 'chmod 755 ./AUTOMATION/EMS_Build/EMS_Dependency_Validation.sh'
		
		// Move to correct folder for execution
		sh label: '', script: 'cd ${WORKSPACE}/AUTOMATION/EMS_Build'
		
		// Perform dependency validation
		dir("${WORKSPACE}/AUTOMATION/EMS_Build"){
		  sh "./EMS_Dependency_Validation.sh -dependencyCheck ${deployParams.RELEASE} ${deployParams.engine}"
        }
		
		
		//remove Rollback folder and copy to original location.
		sh "mv ${WORKSPACE}/AUTOMATION/EMS_Build/${deployParams.RELEASE}/${deployParams.engine}/rollback/* ${WORKSPACE}/AUTOMATION/EMS_Build/${deployParams.RELEASE}/${deployParams.engine}/"
		sh "rm -rf ${WORKSPACE}/AUTOMATION/EMS_Build/${deployParams.RELEASE}/${deployParams.engine}/rollback"
		
		//sh label: '', script: 'chmod 755 ./AUTOMATION/TIL_Build/getArtefactVersion.sh'
		sh label: '', script: 'chmod 755 ./AUTOMATION/EMS_Build/set_emsVersion.sh'
		
		// Build EMS by taking artefacts from GIT.
		
		// Step 1: Get EMS version based on the release and last build in Nexus.
		//def nextEMSVersion = sh(script:"./AUTOMATION/TIL_Build/getArtefactVersion.sh ${deployParams.RELEASE} 'EMS_BUILD' ${deployParams.engine} ${deployParams.NEXUS_URL} ${deployParams.NEXUS_REPO} ${deployParams.EMS_GROUPID}" ,returnStdout: true).trim()
		def nextEMSVersion = sh(script:"./AUTOMATION/EMS_Build/set_emsVersion.sh ${deployParams.RELEASE} ${deployParams.NEXUS_URL} ${deployParams.NEXUS_REPO} ${deployParams.EMS_GROUPID} ${deployParams.NEXUS_USER} ${deployParams.NEXUS_PASSWD} ${deployParams.engine}", returnStdout: true).trim()
		println("DEBUG: EMS Version for the new EMS Build is:" + nextEMSVersion)

		// search replace .PR. to .{{env}}. token for all files for this release
		sh "find ${WORKSPACE}/EMS_Code/${deployParams.RELEASE}/${deployParams.engine}/* -type f -print -exec sed -i 's/\\.PR\\./.{{env}}./g' {} \\;"
		
		// tar up the EMS files
		sh "tar -zcvf EMS-${deployParams.engine}-${nextEMSVersion}.tar.gz -C EMS_Code/${deployParams.RELEASE}/${deployParams.engine} ."
		  
		// Generate Pom file for nexus promotion
		sh "touch EMS-${deployParams.engine}-${nextEMSVersion}.pom"
		  
		// Generate Readme file
		sh "echo \"${Description}\" > EMS-${deployParams.engine}-${nextEMSVersion}_Readme.txt"

		// Upload EMS tar file, pom and readme files to Nexus
		nexusArtifactUploader artifacts: [[artifactId: "${deployParams.engine}", classifier: '', file: "EMS-${deployParams.engine}-${nextEMSVersion}.tar.gz", type: 'tar.gz']], credentialsId: '74edde97-94e0-403c-93f6-cad6c46c45f8', groupId: "TIL_EMS", nexusUrl: "${deployParams.NEXUS_URL}", nexusVersion: "${deployParams.NEXUS_VERSION}", protocol: 'http', repository: "${deployParams.NEXUS_REPO}", version: "${nextEMSVersion}"
		
		nexusArtifactUploader artifacts: [[artifactId: "${deployParams.engine}", classifier: '', file: "EMS-${deployParams.engine}-${nextEMSVersion}.pom", type: 'pom']], credentialsId: '74edde97-94e0-403c-93f6-cad6c46c45f8', groupId: "TIL_EMS", nexusUrl: "${deployParams.NEXUS_URL}", nexusVersion: "${deployParams.NEXUS_VERSION}", protocol: 'http', repository: "${deployParams.NEXUS_REPO}", version: "${nextEMSVersion}"

		nexusArtifactUploader artifacts: [[artifactId: "${deployParams.engine}", classifier: '', file: "EMS-${deployParams.engine}-${nextEMSVersion}_Readme.txt", type: 'txt']], credentialsId: '74edde97-94e0-403c-93f6-cad6c46c45f8', groupId: "TIL_EMS", nexusUrl: "${deployParams.NEXUS_URL}", nexusVersion: "${deployParams.NEXUS_VERSION}", protocol: 'http', repository: "${deployParams.NEXUS_REPO}", version: "${nextEMSVersion}"
		
		println("DEBUG: Display all the artefacts created so far.")
		sh label: '', script: "ls -lrt ${WORKSPACE}"
		
		return nextEMSVersion
}

def ems_generate_lower_env(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{

		// move Environment Specific EMS Configurations to EMS Deployment Scripts location
		sh "mv ${WORKSPACE}/ENV/EMS_Configuration/${deployParams.Environment}/* ./AUTOMATION/EMS_Deployment"

		//Run ansible playbook to generate ems deployment  into environment
		ansiColor('xterm') {
			ansiblePlaybook(playbook: "${WORKSPACE}/AUTOMATION/EMS_Deployment/generate.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Environment}_EMS", repo_group_id: "${deployParams.nexus_group_id}", repo_artifact_ids: "${deployParams.repo_artifact_ids}", repo_user: "${deployParams.nexus_user}", repo_pw: "${deployParams.nexus_passwd}", repo_repo_id: "${deployParams.nexus_repo_id}", repo_url: "${deployParams.nexus_url}", datetime: "${deployParams.datetime}", crq_num: "${deployParams.crq_no}", release: "${deployParams.release}", Environment: "${deployParams.Environment}", emsIgnore: "${deployParams.emsIgnore}"])
		}  	
    }
}

def ems_deployment_lower_env(deployParams) {
	//Running ansible play for deployment
	script{
		ansiColor('xterm') {
			ansiblePlaybook(playbook: "${WORKSPACE}/AUTOMATION/EMS_Deployment/deploy_lower_environments.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Environment}_EMS", repo_artifact_ids: "${deployParams.ems_engines}", datetime: "${deployParams.datetime}", crq_num: "${deployParams.crq_no}", release: "${deployParams.release}", Environment: "${deployParams.Environment}", emsIgnore: "${deployParams.emsIgnore}", rollbackBackup:"${deployParams.rollbackBackup}"])
		}  	
    }
}

def ems_rollback_lower_env(deployParams) {
	//Running ansible play for rollback
	script{
		ansiColor('xterm') {
			ansiblePlaybook(playbook: "${WORKSPACE}/AUTOMATION/EMS_Deployment/emsExplicitEngines.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Environment}_EMS", engines: "${deployParams.ems_engines}", datetime: "${deployParams.datetime}", crq_num: "${deployParams.crq_no}", release: "${deployParams.release}", Environment: "${deployParams.Environment}", emsIgnore: "${deployParams.emsIgnore}", rollbackBackup:"${deployParams.rollbackBackup}"])
		}  	
    }
}

return this