
/*********************************************************************************************************************
Author: Anil Kolli & Raghuram Koripalli
Date: 17/04/2020
/*********************************************************************************************************************
This file holds all the functions related to SQL backup, generate and deployment.
Below are the functions listed in thsi file.
1. sql_backup()
2. sql_deploy()
3. sql_explicit_rollback()
4. sql_generate()

*********************************************************************************************************************/
/*********************************************************************************************************************
This function will take backup for the provided tables.
sql_backup()

/*sql_backup Function 
Input : 
	1. nexus_group_id
	2. nexus_user
	3. nexus_passwd
	4. nexus_repo_id
	5. nexus_url
	6. repo_artifact_ids
	7. datetime
	8. crq_no
	9. release
	10. Environment
	11. SQL_BACKUP_TABLES
Output: 
	None. ( Creates backup for all the tables provided as input and keep in backup folder in SQL workspace.)

*********************************************************************************************************************/
/*SQL Backup Function 
*/
def sql_backup(deployParams) {
	script{
		//Checkout Framework Artefacts from automation repository
		checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "SQL_Deploy_${deployParams.Environment}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]

		

		// create folder to store environment config.
		sh "mkdir -p ./SQL_Deploy_${deployParams.Environment}/SQL_Deployment/conf_properties"

		// move Environment Specific SQL Configurations to SQL Deployment Scripts location
		sh "mv ./SQL_Deploy_ENV/SQL_Configuration/${deployParams.Environment}/* ./SQL_Deploy_${deployParams.Environment}/SQL_Deployment/conf_properties"

		//Run ansible playbook to deploy artefacts into environment
		ansiColor('xterm') {
			ansiblePlaybook(playbook: "./SQL_Deploy_${deployParams.Environment}/SQL_Deployment/sqlBackUpTables.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Environment}_SQL", repo_group_id: "${deployParams.nexus_group_id}", repo_artifact_ids:"${deployParams.repo_artifact_ids}", repo_user:"${deployParams.nexus_user}", repo_pw:"${deployParams.nexus_passwd}", repo_repo_id:"${deployParams.nexus_repo_id}", repo_url:"${deployParams.nexus_url}", Release:"${deployParams.release}", Environment:"${deployParams.Environment}", datetime: "${deployParams.datetime}", CRQ_Num:"${deployParams.crq_no}", backupTables: "${deployParams.backup_tables}"])
		}
	}	
}

/*********************************************************************************************************************
This function will take care of SQL workspace creation and taking backup for the affected tables. 
sql_generate()
Input : 
	1. nexus_group_id
	2. nexus_user
	3. nexus_passwd
	4. nexus_repo_id
	5. nexus_url
	6. repo_artifact_ids
	7. datetime
	8. crq_no
	9. release
	10. Environment
Output: 
	None. ( Completes SQL deployment prepartion activities and creates back up for all the effected tables in target server.)

*********************************************************************************************************************/

def sql_generate(deployParams) {
	script{
		//Checkout Framework Artefacts from automation repository
		checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "SQL_Deploy_${deployParams.Environment}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]


		// create folder to store environment config.
		sh "mkdir -p ./SQL_Deploy_${deployParams.Environment}/SQL_Deployment/conf_properties"

		// move Environment Specific SQL Configurations to SQL Deployment Scripts location
		sh "mv ./SQL_Deploy_ENV/SQL_Configuration/${deployParams.Environment}/* ./SQL_Deploy_${deployParams.Environment}/SQL_Deployment/conf_properties"		
		
		// Run ansible playbook for SQL Geneartion
		ansiColor('xterm') {
			ansiblePlaybook(playbook: "./SQL_Deploy_${deployParams.Environment}/SQL_Deployment/sqlGenerate.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Environment}_SQL", repo_group_id: "${deployParams.nexus_group_id}", repo_artifact_ids:"${deployParams.repo_artifact_ids}", repo_user:"${deployParams.nexus_user}", repo_pw:"${deployParams.nexus_passwd}", repo_repo_id:"${deployParams.nexus_repo_id}", repo_url:"${deployParams.nexus_url}", Release:"${deployParams.release}", Environment:"${deployParams.Environment}", datetime: "${deployParams.datetime}", CRQ_Num:"${deployParams.crq_no}"])
		}
	}
}



/*********************************************************************************************************************
This function will take care of SQL Deployment for the provided engines and versions.
sql_deploy()
Input : 
	1. nexus_group_id
	2. nexus_user
	3. nexus_passwd
	4. nexus_repo_id
	5. nexus_url
	6. repo_artifact_ids
	7. datetime
	8. crq_no
	9. release
	10. Environment
Output: 
	None. ( Completes SQL Deployment and writes all the failed engines to text file in jenkins workspace.)

*********************************************************************************************************************/

def sql_deploy(deployParams) {
	script{
		ansiColor('xterm') {
			ansiblePlaybook(playbook: "./SQL_Deploy_${deployParams.Environment}/SQL_Deployment/sqlStaging_RF.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Environment}_SQL", repo_group_id: "${deployParams.nexus_group_id}", repo_artifact_ids:"${deployParams.repo_artifact_ids}", repo_user:"${deployParams.nexus_user}", repo_pw:"${deployParams.nexus_passwd}", repo_repo_id:"${deployParams.nexus_repo_id}", repo_url:"${deployParams.nexus_url}", Release:"${deployParams.release}", Environment:"${deployParams.Environment}", datetime: "${deployParams.datetime}", CRQ_Num:"${deployParams.crq_no}"])
		}
	}
}

/*********************************************************************************************************************
This function will take care of SQL Deployment for the provided engines and versions.
sql_explicit_rollback()
Input : 
	1. repo_artifact_ids
	2. datetime
	3. crq_no
	4. release
	5. Environment
Output: 
	None. ( Completes SQL rollback and writes all the failed engines to text file in jenkins workspace.)

*********************************************************************************************************************/
def sql_explicit_rollback(deployParams) {
	script{
		//Run ansible playbook to deploy artefacts into environment
		ansiColor('xterm') {
			ansiblePlaybook(playbook: "./SQL_Deploy_${deployParams.Environment}/SQL_Deployment/sqlStaging_RB.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Environment}_SQL", Release:"${deployParams.release}", Environment:"${deployParams.Environment}", datetime: "${deployParams.datetime}", CRQ_Num:"${deployParams.crq_no}", repo_artifact_ids:"${deployParams.repo_artifact_ids}"])
		}
    }
}

def build_sql(deployParams) {
	// This function to build the SQL artefacts and then push to nexus.
		/*----------------------------------------------------------------------------------------
		stage setup part.
		------------------------------------------------------------------------------------------*/

		// Checkout SQL Artefacts from TIL_SQL Repository 
		checkout([$class: 'GitSCM', doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "SQL_Code"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_SQL.git']]])			
		
		sh label: '', script: 'chmod 755 ./AUTOMATION/SQL_Build/set_sqlVersion.sh'
		
		// Build SQL by taking artefacts from GIT.
		
		// Step 1: Get SQL version based on the release and last build in Nexus.
		def nextSQLVersion = sh(script:"./AUTOMATION/SQL_Build/set_sqlVersion.sh ${deployParams.RELEASE} ${deployParams.NEXUS_URL} ${deployParams.NEXUS_REPO} ${deployParams.SQL_GROUPID} ${deployParams.NEXUS_USER} ${deployParams.NEXUS_PASSWD} ${deployParams.engine}", returnStdout: true).trim()
		println("DEBUG: SQL Version for the new SQL Build is:" + nextSQLVersion)
		
		// Create build folder with all the artefacts gathered from GIT .
		sh "cp ${WORKSPACE}/SQL_Code/${deployParams.RELEASE}/${deployParams.engine}/*.sql ./"
		sh "rm -rf ${WORKSPACE}/SQL_Code"
		sh "cp ${WORKSPACE}/AUTOMATION/SQL_Build/* ${WORKSPACE}"
		sh "chmod 755 ${WORKSPACE}/validate_special_symbols.sh"
			
		//[CICD-1786]- Run SQL Validation script to validate sql files for any special symbols present in it.
		sh label: '', script: "${WORKSPACE}/validate_special_symbols.sh ${deployParams.Environment} || { echo 'ERROR: SQL File validation Failed. Please check logs' ; exit 1; }"
		
		// Create SQL Build with the artefacts copied from GIT
		sh "tar -zcvf SQL-${deployParams.engine}-${nextSQLVersion}.tar.gz ./*.sql"
		sh "touch SQL-${deployParams.engine}-${nextSQLVersion}.pom"
		sh "echo ${deployParams.Description}> SQL-${deployParams.engine}-${nextSQLVersion}_Readme.txt"
		
		println("DEBUG: Display all the artefacts created so far.")
		sh label: '', script: "ls -lrt ${WORKSPACE}"
		
		// Upload SQL tar file, pom and readme files to Nexus
		nexusArtifactUploader artifacts: [[artifactId: "${deployParams.engine}", classifier: '', file: "SQL-${deployParams.engine}-${nextSQLVersion}.tar.gz", type: 'tar.gz']], credentialsId: '74edde97-94e0-403c-93f6-cad6c46c45f8', groupId: "TIL_SQL", nexusUrl: "${deployParams.NEXUS_URL}", nexusVersion: "${deployParams.NEXUS_VERSION}", protocol: 'http', repository: "${deployParams.NEXUS_REPO}", version: "${nextSQLVersion}"
		
		nexusArtifactUploader artifacts: [[artifactId: "${deployParams.engine}", classifier: '', file: "SQL-${deployParams.engine}-${nextSQLVersion}.pom", type: 'pom']], credentialsId: '74edde97-94e0-403c-93f6-cad6c46c45f8', groupId: "TIL_SQL", nexusUrl: "${deployParams.NEXUS_URL}", nexusVersion: "${deployParams.NEXUS_VERSION}", protocol: 'http', repository: "${deployParams.NEXUS_REPO}", version: "${nextSQLVersion}"

		nexusArtifactUploader artifacts: [[artifactId: "${deployParams.engine}", classifier: '', file: "SQL-${deployParams.engine}-${nextSQLVersion}_Readme.txt", type: 'txt']], credentialsId: '74edde97-94e0-403c-93f6-cad6c46c45f8', groupId: "TIL_SQL", nexusUrl: "${deployParams.NEXUS_URL}", nexusVersion: "${deployParams.NEXUS_VERSION}", protocol: 'http', repository: "${deployParams.NEXUS_REPO}", version: "${nextSQLVersion}"		
		
		return nextSQLVersion
}

def sql_generate_lower_env(deployParams) {
	script{
		
		// Assumption is both Automation framework is checkedout already to "AUTOMATION" folder and env configuration to "ENV" folder.

		// create folder to store environment config.
		sh "mkdir -p ./AUTOMATION/SQL_Deployment/conf_properties"

		// move Environment Specific SQL Configurations to SQL Deployment Scripts location
		sh "mv ./ENV/SQL_Configuration/${deployParams.Environment}/* ./AUTOMATION/SQL_Deployment/conf_properties"		
		
		// Run ansible playbook for SQL Geneartion
		ansiColor('xterm') {
			ansiblePlaybook(playbook: "./AUTOMATION/SQL_Deployment/sqlGenerate.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Environment}_SQL", repo_group_id: "${deployParams.nexus_group_id}", repo_artifact_ids:"${deployParams.repo_artifact_ids}", repo_user:"${deployParams.nexus_user}", repo_pw:"${deployParams.nexus_passwd}", repo_repo_id:"${deployParams.nexus_repo_id}", repo_url:"${deployParams.nexus_url}", Release:"${deployParams.release}", Environment:"${deployParams.Environment}", datetime: "${deployParams.datetime}", CRQ_Num:"${deployParams.crq_no}"])
		}
	}
}

def sql_deploy_lower_env(deployParams) {
	script{
		ansiColor('xterm') {
			ansiblePlaybook(playbook: "${WORKSPACE}/AUTOMATION/SQL_Deployment/sqlDeploy_lt_sit.yml", colorized: true, extras:'-v', extraVars: [host: "${deployParams.Environment}_SQL", repo_group_id: "${deployParams.nexus_group_id}", repo_artifact_ids:"${deployParams.repo_artifact_ids}", repo_user:"${deployParams.nexus_user}", repo_pw:"${deployParams.nexus_passwd}", repo_repo_id:"${deployParams.nexus_repo_id}", repo_url:"${deployParams.nexus_url}", Release:"${deployParams.release}", Environment:"${deployParams.Environment}", datetime: "${deployParams.datetime}", CRQ_Num:"${deployParams.crq_no}"])
		}
	}
}

def sql_explicit_rollback_lower_env(deployParams) {
	script{
		//Run ansible playbook to deploy artefacts into environment
		ansiColor('xterm') {
			ansiblePlaybook(playbook: "${WORKSPACE}/AUTOMATION/SQL_Deployment/sqlStaging_RB.yml", colorized: true, extras:'-v', extraVars: [host: "${deployParams.Environment}_SQL", Release:"${deployParams.release}", Environment:"${deployParams.Environment}", datetime: "${deployParams.datetime}", CRQ_Num:"${deployParams.crq_no}", repo_artifact_ids:"${deployParams.repo_artifact_ids}"])
		}
    }
}


return this;
