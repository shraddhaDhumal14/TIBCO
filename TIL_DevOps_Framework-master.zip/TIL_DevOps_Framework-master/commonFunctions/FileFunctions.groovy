
/*********************************************************************************************************************
Author: Anil Kolli & Raghuram Koripalli
Date: 20/04/2020
/*********************************************************************************************************************
This file holds all the functions related to File deployment(XML< JAR and Email).
Below are the functions listed in thsi file.


*********************************************************************************************************************/

/*********************************************************************************************************************




*********************************************************************************************************************/


/*Validate Files function for deployment 
*/
def validate_files(deployParams) {
	// Function to validate files in GIT repository. If file does not exist, then fail the engine and remove it from all the maps.
	// remove any files present 
	//sh "rm -rf ./${deployParams.Host}_Files_Deploy/File_Deployment/files/"
	
	// [CICD-193: FIX] - Checkout repository using tag to get the linked configuration.
 	def majv = deployParams.RELEASE.split('CCS')[1].split('\\.')[0]
	def minv = deployParams.RELEASE.split('CCS')[1].split('\\.')[1]		

	// make a files directory in File_Deploy folder
	sh "mkdir -p ./${deployParams.Host}_Files_Deploy/File_Deployment/files"
	def failed_engines = []
	def file_tag = ""
	
	//[CICD-1783]: BW_SNAP passed with engine name and BW Version. Use this to get the file tag.
	
	deployParams.map.each { engine, version ->

		// Get the file tag. If BW_VERSION exists for the engine, tag is enginename_bwVersion, else tag i sthe latest available for the release and engine.
		if((deployParams.BW_SNAP.containsKey(engine)) && (deployParams.BW_SNAP[engine].startsWith(majv + '_' + minv + '_'))){
			file_tag = engine + '_' + deployParams.BW_SNAP[engine]
		} else{
			file_tag = sh(returnStdout: true, script: "cd ${deployParams.Host}_Files_Config; git checkout --quiet master; git tag -l \"${engine}_${majv}_${minv}_\"[0-9]\"\"* | sort -V | tail -1").trim()
		}		
		print "DEBUG: file_tag taken for validate_files is: " + file_tag
		if(file_tag.length() != 0){
			def temp = sh(returnStdout: true, script: "cd ${deployParams.Host}_Files_Config; git checkout tags/${file_tag}").trim()
	
			def files_list = version.split(',')
			for (file in files_list) {
				def ret = sh(script: "cp ./${deployParams.Host}_Files_Config/${deployParams.Deployment_Type}/`basename ${file}` ./${deployParams.Host}_Files_Deploy/File_Deployment/files", returnStatus:true)
				if (ret != 0) {	
					echo "DEBUG: FILE NOT AVAILABLE FOR DEPLOYMNET. FAILED ENGINE FROM FILE VALIDATION is: ${engine}"
					failed_engines.add(engine)
					break;
				}
			}
		}
		else {
			failed_engines.add(engine)
		}
	}
	return failed_engines.join(";")
}
/*Deploy files
*/

def deploy_files(deployParams) {
	//Running the ansible deploy playbook
	ansiColor('xterm') {
			 ansiblePlaybook(playbook: "./${deployParams.Host}_Files_Deploy/File_Deployment/filesDeploy.yml", colorized: true, extras:'-v', extraVars: [host: "${deployParams.Host}_File", file_snap: "${deployParams.file_snap}", crq_num: "${deployParams.crq_no}", datetime: "${deployParams.datetime}"])
	}
}

/*Rollback files
*/
def rollback_files(deployParams) {
	//Running the ansible deploy playbook
	ansiColor('xterm') {
			 ansiblePlaybook(playbook: "./${deployParams.Host}_Files_Deploy/File_Deployment/filesRollBack.yml", colorized: true, extras:'-v', extraVars: [host: "${deployParams.Host}_File", file_snap: "${deployParams.file_snap}", crq_num: "${deployParams.crq_no}", datetime: "${deployParams.datetime}"])
	}
}

def validate_files_lt_env(deployParams) {
	
	// [CICD-193: FIX] - Checkout repository using tag to get the linked configuration.
 	def majv = deployParams.RELEASE.split('CCS')[1].split('\\.')[0]
	def minv = deployParams.RELEASE.split('CCS')[1].split('\\.')[1]		
	
	sh "mkdir -p ${WORKSPACE}/AUTOMATION/File_Deployment/files"
	def files_list = deployParams.engine_files.split(',')
	for (file in files_list) {
			// To be included: validation to check whether file path starts from ~/
			def ret_status = sh(script: "cp ${WORKSPACE}/APPLICATION/${deployParams.Deployment_Type}/`basename ${file}` ${WORKSPACE}/AUTOMATION/File_Deployment/files", returnStatus:true)
			if (ret_status != 0) {
				return "FAIL"
				break
			}
	}
	return "PASS"
}



def validate_files_lower_env(deployParams) {
	
	// [CICD-193: FIX] - Checkout repository using tag to get the linked configuration.
 	def majv = deployParams.RELEASE.split('CCS')[1].split('\\.')[0]
	def minv = deployParams.RELEASE.split('CCS')[1].split('\\.')[1]
	def file_tag = ""
	
	//[CICD-1783]: Fix to checkout files with correct tag.
	// If BW_VERSION exists, then checkout with enginename_bwversion tag , else, checkout with latest tag available in the release.
	if(deployParams.bw_ver.startsWith(majv + '_' + minv + '_')){
		file_tag = deployParams.engine_name + '_' + deployParams.bw_ver
	} else{
		file_tag = sh(returnStdout: true, script: "cd ${WORKSPACE}/APPLICATION; git checkout --quiet master; git tag -l ${deployParams.engine_name}_${majv}_${minv}_\"[0-9]\"* | sort -V | tail -1").trim()
	}
	
	if(file_tag.length() != 0){
		def temp = sh(returnStdout: true, script: "cd ${WORKSPACE}/APPLICATION; git checkout tags/${file_tag}").trim()
		sh "mkdir -p ${WORKSPACE}/AUTOMATION/File_Deployment/files"
		def files_list = deployParams.engine_files.split(',')
		for (file in files_list) {
			// To be included: validation to check whether file path starts from ~/
			def ret_status = sh(script: "cp ${WORKSPACE}/APPLICATION/${deployParams.Deployment_Type}/`basename ${file}` ${WORKSPACE}/AUTOMATION/File_Deployment/files", returnStatus:true)
			if (ret_status != 0) {
				return "FAIL"
				break
			}
		}		
	} else {
		sh "echo \"ERROR: No File tag exists for the engine ${deployParams.engine_name} for ${deployParams.RELEASE}. Please follow up with DEV team\""
		return "FAIL"
	}
	return "PASS"
}

def deploy_files_lower_env(deployParams) {
	// Deploy files function for LT and SIT.
	ansiColor('xterm') {
			 ansiblePlaybook(playbook: "${WORKSPACE}/AUTOMATION/File_Deployment/filesDeploy.yml", colorized: true, extras:'-v', extraVars: [host: "${deployParams.Host}_File", file_snap: "${deployParams.engine_files}", crq_num: "${deployParams.crq_no}", datetime: "${deployParams.datetime}"])
	}
}

def rollback_files_lower_env(deployParams) {
	//Running the ansible deploy playbook
	ansiColor('xterm') {
			 ansiblePlaybook(playbook: "${WORKSPACE}/AUTOMATION//File_Deployment/filesRollBack.yml", colorized: true, extras:'-v', extraVars: [host: "${deployParams.Host}_File", file_snap: "${deployParams.engine_files}", crq_num: "${deployParams.crq_no}", datetime: "${deployParams.datetime}"])
	}
}

def get_env_file_home(deployParams){
	// This function is to get file homepath for the given environment
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "TEMP_CHECKOUT"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: "https://github.vodafone.com/VFUK-INTEGRATION/${deployParams.git_repo}.git"]]]
	def filepath = sh(script:"cat ${WORKSPACE}/TEMP_CHECKOUT/FILE_Configuration/${deployParams.env}/${deployParams.env}_File | grep 'FILE_HOME' | awk -F ':' '{print \$2}' | tr -d ' '" ,returnStdout: true).trim()
	// remove checked out folder from workspace
	sh "rm -rf ${WORKSPACE}/TEMP_CHECKOUT"
	return filepath
}



return this