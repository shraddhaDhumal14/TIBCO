
/*********************************************************************************************************************
Author: Anil Kolli & Raghuram Koripalli
Date: 20/05/2020
/*********************************************************************************************************************
This file holds all the common functions which are used for the pipelines
Below are the functions listed in this file.

1. get_version_from_facts()
2. update_report_stats()
3. update_jenkins_dashboard()
4. elapsedTime()
5. get_approvers_list()
6. update_rollback_stats()

HISTORY:

17/06/2020: ANIL KOLLI: [CICD-374]: Added function update_report_stats() to update stats for filebeats for each of the build.
17/06/2020: ANIL KOLLI: [CICD-476]: updated function update_report_stats() to push data to jenkins dash board for each of the build.
17/06/2020: ANIL KOLLI: [CICD-476]: Added function update_jenkins_dashboard() to push data to jenkins dash board for each of the build.  
17/06/2020: ANIL KOLLI: [CICD-476]: Added function elapsedTime() to push data to jenkins dash board for each of the build.
03/07/2020: ANIL KOLLI: [CICD-178]: Added function get_approvers_list() to get the list of approvers list given the role.
28/09/2020: ANIL KOLLI: [CICD-336]: Added update_rollback_stats() function to update dash board and stats file for the rollback pipeline.

*********************************************************************************************************************/


/*********************************************************************************************************************
This funcction returns the version deployed in environment for the given engine from facts file.
input:
	release: CCS release
	engine_name: Name of the engines separated by ;
	deployment_type: BW/SQL/EMS

Output:
	version
*********************************************************************************************************************/
def get_version_from_facts(deployParams) {

	def version_string = ""
	ansiColor('xterm') {
		ansiblePlaybook(playbook: "./automation/Utils/getReleaseFacts/get_release_facts.yml", colorized: true, extras:'-v', extraVars: [host: "localhost", repo_artifact_ids: "${deployParams.engine_name}", release: "${deployParams.release}", Environment: "${deployParams.environment}", type: "${deployParams.deployment_type}"])
	}
	def facts_file = new File("${WORKSPACE}/automation/Utils/getReleaseFacts/${deployParams.type}_engine_versions.txt").readLines()
	if(fileExists("${WORKSPACE}/automation/Utils/getReleaseFacts/${deployParams.type}_engine_versions.txt")) {
		deployParams.engine_name.split(';').each { engine ->
			def fact_version = facts_file.findAll { it.contains("${engine}:") }
			//println(engine + ':' + version + ':' + fact_version)
			if(fact_version) {
				version_string = version_string + engine + ':' + fact_version
			}
		}
	}
	return version_string
}

// Function to update stats at jenkins dash board and ELK stats file.
// [CICD-374] && [CICD-476] fixes.
def update_report_stats(deployParams){
	//Iterate over the map for all the engines to update dash board and stats file.
	deployParams.map.keySet().each { engine_name ->
			date_print = new Date().format('yyyy/MM/dd HH:mm:ss')
			statsFile = new File(deployParams.statsFile)
			if(deployParams.map[engine_name]['BW_Deployment'] == "FAILED" || deployParams.map[engine_name]['BW_Deployment'] == "PASSED"){
				def bw_status = ""
				if(deployParams.map[engine_name]['BW_Restart'] == "PASSED") {
					bw_status = "SUCCESS"
				} else {
					bw_status = "FAILURE"
				}
				println(date_print + ',' + deployParams.Release+ ',' + "BW" + ',' + engine_name + ',' + deployParams.environment + ',' + bw_status + ',' + deployParams.map[engine_name]['BW_DURATION']+ ',' + deployParams.map[engine_name]['BW_VERSION'])
				statsFile.append('\n' + date_print + ',' + deployParams.Release+ ',' + "BW" + ',' + engine_name + ',' + deployParams.environment + ',' + bw_status + ',' + deployParams.map[engine_name]['BW_DURATION']+ ',' + deployParams.map[engine_name]['BW_VERSION'])
				//[CICD-374] Fix: Calling BW dashboard update.
				if(bw_status == "SUCCESS"){
					update_jenkins_dashboard type: "${deployParams.environment}", engine_name: engine_name, artefact_version: deployParams.map[engine_name]['BW_VERSION'], pipeline: "${deployParams.pipeline_name}"
				}
			}
			if(deployParams.map[engine_name]['EMS_Deployment'] == "FAILED" || deployParams.map[engine_name]['EMS_Deployment'] == "PASSED"){
				def ems_status = ""
				if(deployParams.map[engine_name]['EMS_Deployment'] == "PASSED") {
					ems_status = "SUCCESS"
				} else {
					ems_status = "FAILURE"
				}		
				println(date_print + ',' + deployParams.Release+ ',' + "EMS" + ',' + engine_name + ',' + deployParams.environment + ',' + ems_status + ',' + deployParams.map[engine_name]['EMS_DURATION']+ ',' + deployParams.map[engine_name]['EMS_VERSION'])
				statsFile.append('\n' + date_print + ',' + deployParams.Release+ ',' + "EMS" + ',' + engine_name + ',' + deployParams.environment + ',' + ems_status + ',' + deployParams.map[engine_name]['EMS_DURATION']+ ',' + deployParams.map[engine_name]['EMS_VERSION'])
				//[CICD-374] Fix: Calling EMS dash board update.
				if(ems_status == "SUCCESS" && deployParams.map[engine_name]['RESULT'] == "PASSED"){
					update_jenkins_dashboard type: "${deployParams.environment}_EMS", engine_name: engine_name, artefact_version: deployParams.map[engine_name]['EMS_VERSION'], pipeline: "${deployParams.pipeline_name}"
				}
			}
			if(deployParams.map[engine_name]['SQL_Deployment'] == "FAILED" || deployParams.map[engine_name]['SQL_Deployment'] == "PASSED"){
				def sql_status = ""
				if(deployParams.map[engine_name]['SQL_Deployment'] == "PASSED") {
					sql_status = "SUCCESS"
				} else {
					sql_status = "FAILURE"
				}		
				println(date_print + ',' + deployParams.Release+ ',' + "SQL" + ',' + engine_name + ',' + deployParams.environment + ',' + sql_status + ',' + deployParams.map[engine_name]['SQL_DURATION']+ ',' + deployParams.map[engine_name]['SQL_VERSION'])
				statsFile.append('\n' + date_print + ',' + deployParams.Release+ ',' + "SQL" + ',' + engine_name + ',' + deployParams.environment + ',' + sql_status + ',' + deployParams.map[engine_name]['SQL_DURATION']+ ',' + deployParams.map[engine_name]['SQL_VERSION'])
				//[CICD-374] Fix: Calling SQL dashboard update.
				if(sql_status == "SUCCESS" && deployParams.map[engine_name]['RESULT'] == "PASSED"){
					update_jenkins_dashboard type: "${deployParams.environment}_SQL", engine_name: engine_name, artefact_version: deployParams.map[engine_name]['SQL_VERSION'], pipeline: "${deployParams.pipeline_name}"
				}
			}	
	}
}


def update_jenkins_dashboard(deployParams) {
	// This function is to update environment dash board for the given artefacts
	build job: '/TIL_PIPELINES/Common_Jobs/Dashboard_Publish', parameters: [string(name: 'Environment', value: "${deployParams.type}"), string(name: 'Component', value: "${deployParams.engine_name}"), string(name: 'ArtefactVersion', value: "${deployParams.artefact_version}"), string(name: 'Pipeline', value: "${deployParams.pipeline}"), string(name: 'Description', value: '')]	
}


//[CICD-476] Fix: function to get elapsed time duration 
def elapsedTime(Closure closure){
    def timeStart = new Date()
    closure()
    def timeStop = new Date()
    return TimeCategory.minus(timeStop, timeStart).toMilliseconds()
}

def get_approvers_list(String str){
	outlist = sh (script: """cat /opt/tibco/.jenkins/config.xml | sed -n \'/role name=\"${str}\"/,\$p\' | sed \'/role>/q\' | grep "sid" | cut -d \'>\' -f 2 | cut -d \'<\' -f 1 | paste -s -d, -""",
			returnStdout: true).trim()
	return """${outlist}"""
}

def get_approvers_list_upper(String str){
	outlist = sh (script: """cat /opt/SP/tibco/.jenkins/config.xml | sed -n \'/role name=\"${str}\"/,\$p\' | sed \'/role>/q\' | grep "sid" | cut -d \'>\' -f 2 | cut -d \'<\' -f 1 | paste -s -d, -""",
			returnStdout: true).trim()
	return """${outlist}"""
}

// Function to update stats at jenkins dash board and ELK stats file for rollback pipeline.
def update_rollback_stats(deployParams){
	//Iterate over the map for all the engines to update dash board and stats file.
	deployParams.map.keySet().each { engine_name ->
			date_print = new Date().format('yyyy/MM/dd HH:mm:ss')
			statsFile = new File(deployParams.statsFile)
			if(deployParams.map[engine_name]['BW_Rollback'] == "FAILED" || deployParams.map[engine_name]['BW_Rollback'] == "PASSED"){
				def bw_status = ""
				def release = ""
				release = 'CCS' + deployParams.map[engine_name]['BW_VERSION'].split("_", 2)[0] + '.' + deployParams.map[engine_name]['BW_VERSION'].split("_", 2)[1].split('_').init().join('_')
				if(deployParams.map[engine_name]['BW_Restart'] == "PASSED") {
					bw_status = "SUCCESS"
				} else {
					bw_status = "FAILURE"
				}
				println(date_print + ',' + release+ ',' + "BW" + ',' + engine_name + ',' + deployParams.environment + ',' + bw_status + ',' + deployParams.map[engine_name]['BW_DURATION']+ ',' + deployParams.map[engine_name]['BW_VERSION'])
				statsFile.append('\n' + date_print + ',' + release + ',' + "BW" + ',' + engine_name + ',' + deployParams.environment + ',' + bw_status + ',' + deployParams.map[engine_name]['BW_DURATION']+ ',' + deployParams.map[engine_name]['BW_RB_VERSION'])
				//[CICD-374] Fix: Calling BW dashboard update.
				if(bw_status == "SUCCESS"){
					update_jenkins_dashboard type: "${deployParams.environment}", engine_name: engine_name, artefact_version: deployParams.map[engine_name]['BW_RB_VERSION'], pipeline: "${deployParams.pipeline_name}"
				}
			}
			if(deployParams.map[engine_name]['EMS_Deployment'] == "FAILED" || deployParams.map[engine_name]['EMS_Deployment'] == "PASSED"){
				def ems_status = ""
				def release = ""
				release = 'CCS' + deployParams.map[engine_name]['EMS_VERSION'].split("_", 2)[0] + '.' + deployParams.map[engine_name]['EMS_VERSION'].split("_", 2)[1].split('_').init().join('_')
				if(deployParams.map[engine_name]['EMS_Deployment'] == "PASSED") {
					ems_status = "SUCCESS"
				} else {
					ems_status = "FAILURE"
				}
				
				println(date_print + ',' + release + ',' + "EMS" + ',' + engine_name + ',' + deployParams.environment + ',' + ems_status + ',' + deployParams.map[engine_name]['EMS_DURATION']+ ',' + deployParams.map[engine_name]['EMS_VERSION'])
				statsFile.append('\n' + date_print + ',' + release + ',' + "EMS" + ',' + engine_name + ',' + deployParams.environment + ',' + ems_status + ',' + deployParams.map[engine_name]['EMS_DURATION']+ ',' + deployParams.map[engine_name]['EMS_RB_VERSION'])
				//[CICD-374] Fix: Calling EMS dash board update.
				if(ems_status == "SUCCESS" && deployParams.map[engine_name]['RESULT'] == "PASSED"){
					update_jenkins_dashboard type: "${deployParams.environment}_EMS", engine_name: engine_name, artefact_version: deployParams.map[engine_name]['EMS_RB_VERSION'], pipeline: "${deployParams.pipeline_name}"
				}
			}
			if(deployParams.map[engine_name]['SQL_Deployment'] == "FAILED" || deployParams.map[engine_name]['SQL_Deployment'] == "PASSED"){
				def sql_status = ""
				def release = ""
				release = 'CCS' + deployParams.map[engine_name]['SQL_VERSION'].split("_", 2)[0] + '.' + deployParams.map[engine_name]['SQL_VERSION'].split("_", 2)[1].split('_').init().join('_')				
				if(deployParams.map[engine_name]['SQL_Deployment'] == "PASSED") {
					sql_status = "SUCCESS"
				} else {
					sql_status = "FAILURE"
				}		
				println(date_print + ',' + release + ',' + "SQL" + ',' + engine_name + ',' + deployParams.environment + ',' + sql_status + ',' + deployParams.map[engine_name]['SQL_DURATION']+ ',' + deployParams.map[engine_name]['SQL_VERSION'])
				statsFile.append('\n' + date_print + ',' + release + ',' + "SQL" + ',' + engine_name + ',' + deployParams.environment + ',' + sql_status + ',' + deployParams.map[engine_name]['SQL_DURATION']+ ',' + deployParams.map[engine_name]['SQL_RB_VERSION'])
				//[CICD-374] Fix: Calling SQL dashboard update.
				if(sql_status == "SUCCESS" && deployParams.map[engine_name]['RESULT'] == "PASSED"){
					update_jenkins_dashboard type: "${deployParams.environment}_SQL", engine_name: engine_name, artefact_version: deployParams.map[engine_name]['SQL_RB_VERSION'], pipeline: "${deployParams.pipeline_name}"
				}
			}	
	}
}

def validate_input_parameters(deployParams) {
		def validationCheck = ""
		//1. Validate RELEASE parameter
		if(deployParams.containsKey('RELEASE')) {
			String regex = /(^CCS\d+\.\d+_[A-Z0-9]+$)|(^CCS\d+\.\d+$)/
			if(deployParams.RELEASE == ""){
				println("Release is mandatory for Delivery Pipeline")
				validationCheck = "F"
			}
			if (deployParams.RELEASE.indexOf(' ') != -1){
				println('RELEASE parameter should not contain spaces in between')
				validationCheck = "F"
			}
			if (!(deployParams.RELEASE ==~ regex)){
				println('RELEASE parameter is not in standard format. Please input either in CCS20.12 or CCS20.12_xx format')
				validationCheck = "F"
			}			
			
		}
		
		//2. Validate CRQ number
		if(deployParams.containsKey('CRQ')) {
			if(deployParams.CRQ == ""){
				println("CRQ Number should be specified for the Deployment")
				validationCheck = "F"
			}
			if (deployParams.CRQ.indexOf(' ') != -1){
				println('CRQ parameter should not contain spaces in between')
				validationCheck = "F"
			}			
		}
		
		//3. Validate Description parameter.
		if(deployParams.containsKey('DESCRIPTION')) {
			if(deployParams.DESCRIPTION == ""){
				println("DESCRIPTION parameter to be specified for the Deployment")
				validationCheck = "F"
			}
			//[CICD-1836]: Validating Description parameter against any symbols present in it.
			String regex_pattern = ".*[\\\\()\\[\\]\\?\\|\\%\\/\\\n]+.*"
			if (deployParams.DESCRIPTION ==~ regex_pattern){
				println('ERROR: Description parameter has symbols or new line present in it. Please input plain text for description parameter')
				validationCheck = "F"
			}			
		}	
		//4. Validate BUILD_REQUESTER parameter.
		if(deployParams.containsKey('BUILD_REQUESTER')) {
			if(! deployParams.BUILD_REQUESTER.matches('^[a-zA-Z0-9._%+-]+@vodafone.com$')){
				println("Please enter Valid email ID for Build Requester")
				validationCheck = "F"
			}
		}
		
		//5. Validate Description parameter.
		if(deployParams.containsKey('OPERATION_NAME')) {
			if(deployParams.OPERATION_NAME == ""){
				println("OPERATION_NAME parameter to be specified for the Deployment")
				validationCheck = "F"
			}
		}
		
		//6. Validate BW VERSION belongs to RELEASE or not.
		if(deployParams.containsKey('BW_VERSION') && deployParams.containsKey('RELEASE')) {
			if (deployParams.RELEASE.split('CCS')[1].split('_').join(".") != deployParams.BW_VERSION.split('_').init().join(".")){
				println("BW_VERSION should belong to Release Number provided")
				validationCheck = "F"
			}
		}

		//7. Validate EMS VERSION belongs to RELEASE or not.
		if(deployParams.containsKey('EMS_VERSION') && deployParams.containsKey('RELEASE')) {
			if (deployParams.RELEASE.split('CCS')[1].split('_').join(".") != deployParams.EMS_VERSION.split('_').init().join(".")){
				println("EMS_VERSION should belong to Release Number provided")
				validationCheck = "F"
			}
		}
		
		//8. Validate SQL VERSION belongs to RELEASE or not.
		if(deployParams.containsKey('SQL_VERSION') && deployParams.containsKey('RELEASE')) {
			if (deployParams.RELEASE.split('CCS')[1].split('_').join(".") != deployParams.SQL_VERSION.split('_').init().join(".")){
				println("SQL_VERSION should belong to Release Number provided")
				validationCheck = "F"
			}
		}
	
		//9. Validate SPL_Instruction parameter.
		if(deployParams.containsKey('SPECIAL_INSTRUCTIONS')) {
				if(deployParams.SPECIAL_INSTRUCTIONS.trim() == ""){
					println("SPECIAL_INSTRUCTIONS parameter to be specified for the Deployment. If not applicable mention NA")
					validationCheck = "F"
			}
		}

		//10. Validate DEPLOYMENT_FILES parameter when FILE_DEPLOYMENT is checked
		if(deployParams.containsKey('FILE_DEPLOYMENT') && deployParams.FILE_DEPLOYMENT) {
				if(deployParams.DEPLOYMENT_FILES.trim() == ""){
					println("DEPLOYMENT_FILES parameter to be specified, since FILE_DEPLOYMENT is checked.")
					validationCheck = "F"
			}
		}

		//11. Validate Master GV or Process GV parameter when only GV is checked
		if(deployParams.containsKey('ONLY_GV') && deployParams.ONLY_GV) {
				if(deployParams.MASTER_GV_UPDATE.trim() == "" && deployParams.PROCESS_GV_UPDATE.trim() == ""){
					println("MASTER_GV_UPDATE parameter or PROCESS_GV_UPDATE to be specified, since ONLY_GV is checked.")
					validationCheck = "F"
			}
		}
		
		if(validationCheck == "F"){
			error("Pipeline Input parameter validation failed. Please check the errors in Console log.")
			currentBuild.result = 'ABORTED'
		}
}

//[CICD-1760] Ability to validate ssh connectivity to all bw engine machines from BW Admin before running BW deployment
def checkAllSSHConnection(deployParams){
    all_server_status="false"
    env=""
    if ("${deployParams.Host}" == "T1" || "${deployParams.Host}" == "T3" || "${deployParams.Host}" == "T4" || "${deployParams.Host}" == "T7" || "${deployParams.Host}" == "DR_SIT"){
        println("Setting value to Env Prefix to SIT")
        env = "SIT"
    } else {
        println("Setting value to Env Prefix to Environment")
        env = "${deployParams.Host}"
    }
    def manual_automation_file = "${WORKSPACE}/${deployParams.automation_dir}/BW_Deployment/scripts/PostDeploymentChanges/ManualChanges_Automation_${deployParams.Host}.sh"
    sh "echo 'manual_automation_file : --> ${manual_automation_file}'"
    servers=sh(script: "grep -w \'^host=\' ${manual_automation_file} | head -1 | cut -d \'=\' -f 2-  | sed \'s/\"//g\' | tr -d \'\$\'", returnStdout: true).trim()
    sshuser=sh(script: "grep -w \'^usr=*\' ${manual_automation_file} | head -1 | cut -d \'=\' -f 2-  | sed \'s/\"//g\'", returnStdout: true).trim()
    while(all_server_status == "false")
    {
        ansiColor('xterm') {
            ansiblePlaybook(playbook: "${WORKSPACE}/${deployParams.automation_dir}/BW_Deployment/testSSH.yml", colorized: true, extras:'-v', extraVars: [host: "${deployParams.Host}_BW", ssh_user: "${sshuser}", ssh_host_list: "${servers}", bw_folder_release: "${deployParams.bw_folder_release}", crq_num: "${deployParams.crq_num}", datetime: "${deployParams.datetime}"])
         }

        def all_server_msg=sh(script: "cat ${WORKSPACE}/${deployParams.automation_dir}/BW_Deployment/ssh_test_result.txt", returnStdout: true).trim()
        all_server_status=sh(script: "cat ${WORKSPACE}/${deployParams.automation_dir}/BW_Deployment/ssh_result_msg.txt", returnStdout: true).trim()
        if(all_server_status == "true"){
            break;
        }
        else
        {
          def userInput = input(message: 'Some server connections are broken...', ok: 'Proceed',parameters: [booleanParam(defaultValue: true,description: all_server_msg,name: 'Check to retest, uncheck to skip')])
          if(!userInput)
                break;
        }
     }
                       
}

//[CICD-1760] Ability to ping the array of validate ssh connectivity to all bw engine machines from BW Admin before running BW deployment
def checkAnsibleConnection(deployParams)
{
    def ansible_check = "${WORKSPACE}/${deployParams.automation_dir}/BW_Deployment/scripts/ansiblehostcheck.sh"
    ansible_host_list="${deployParams.host_list}"
    while(1)
    {
        pingresponse=""
        pingresponse=sh(script: "sh ${ansible_check} \'${ansible_host_list}\'", returnStdout: true).trim()
        sh "echo '${pingresponse}'"
        if(pingresponse.contains("FAILURE"))
        {
          def userInput = input(message: 'Anisible Connectivity Unavailable', ok: 'Proceed',parameters: [booleanParam(defaultValue: true,description: "${pingresponse}",name: 'Check to retest, uncheck to skip')])
          if(!userInput)
               break;
        }
        else {
            break;
        }
    }
}

/************************************************************************************************************/
/* Please do not delete this below line. This is required to include this to any main pipeline */
return this
/************************************************************************************************************/
