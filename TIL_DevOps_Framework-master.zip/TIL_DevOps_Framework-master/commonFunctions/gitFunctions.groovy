
/******************************************************************************************************************** 
Author: Anil Kolli
Date: 15/04/2020
/******************************************************************************************************************** 
This file is having functions related to GIT repository and getting data from GIT.
1. get_bw_folder_name_from_gvconf()

/******************************************************************************************************************** 


/*********************************************************************************************************************
This function will get the folder name from engine specific gvconf, by checking out the repository with passed tag.
Assumption is folder names remains same across all the environments.

Input: Engines map for which folder names are required.
Output: string with engineName:Foldername separated by ; (eg: eng1:Folder1;eng2:folder2;....)
*********************************************************************************************************************/

def get_bw_folder_name_from_gvconf(deployParams){
	// Function to get Folder name for each of the engine selected for BW deployment.
	def bw_folders = ""
	//checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: "refs/tags/${engine}-${version}"]], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Application_Configuration"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_BW_Application_Configuration.git']]]
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Application_Configuration"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_BW_Application_Configuration.git']]]
	
	deployParams.engines_map.each { engine, version ->
		def gv_file = new File("${WORKSPACE}/Application_Configuration/BW_Configurations/${engine}/${engine}.gvconf").readLines()
		def result = gv_file.findAll { it.contains("Env/JMS/Connections/BW/MIG_JMSURL") }
		if(result) {
			bw_folders = bw_folders + engine + ':' + result[0].split('\\.')[0] + ';'
		}
	}
	// Cleanup repository in the workspace.
	sh "rm -rf ${WORKSPACE}/Application_Configuration"
	return bw_folders.substring(0, bw_folders.length() - 1);
}

/*********************************************************************************************************************
This function will return list fo files to deploy for each engine based on the typeof file.
Input 1: List of engines for which file deployment is required.
Input 2: Type of files ( XML / JAR / Email)
Output: string with engineName:list of files separated by ; (eg: eng1:fileist;eng2:fileList;....)
*********************************************************************************************************************/

def getEngineFiles(deployParams) {
	def engineFiles = ""
	
	//checkout BW_Applications repository.
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Application_Configuration"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_BW_Application_Configuration.git']]]
	
 	def majv = deployParams.RELEASE.split('CCS')[1].split('\\.')[0]
	def minv = deployParams.RELEASE.split('CCS')[1].split('\\.')[1]		
	def file_tag = ""
	def filehome = sh(script:"cat ${WORKSPACE}/ENV/FILE_Configuration/${deployParams.env}/${deployParams.env}_File | grep 'FILE_HOME' | awk -F ':' '{print \$2}' | tr -d ' '" ,returnStdout: true).trim()
	sh "cd ${WORKSPACE}/Application_Configuration; git checkout master"
	deployParams.engines.split(';').each { engine ->
	
			// Get latest tag name to checkout BW configuration for engine template.
			// [CICD-193: FIX] - Checkout repository using tag to get the linked configuration.
			//[CICD-1783]: Fix - checkout tag is enginename_bwversion when bw deployment exists.
			
			if((deployParams.map.containsKey(engine)) && (deployParams.map[engine].startsWith(majv + '_' + minv + '_'))){
				file_tag = engine + '_' + deployParams.map[engine]
			} else{
				file_tag = sh(returnStdout: true, script: "cd ${WORKSPACE}/Application_Configuration; git checkout --quiet master; git tag -l ${engine}_${majv}_${minv}_\"[0-9]\"*| sort -V | tail -1").trim()
			}		
			
			if(file_tag.length() != 0){
				echo "DEBUG: File get engineFiles Checkout tag is: ${file_tag}"
				sh "cd ${WORKSPACE}/Application_Configuration; git checkout tags/${file_tag}"
				def file_template = new File("${WORKSPACE}/Application_Configuration/Files_Engines_Mapping_Template/${deployParams.type}_Template.txt").readLines()
				def result = file_template.findAll { it.startsWith(engine) }
				if(result) {
					def modified_result = result[0].replaceAll("~", filehome)
					engineFiles = engineFiles + engine + ':' + modified_result.split(':')[1] + ';'
				}
			} else {
				sh "echo \"ERROR: No File tag exists for the engine ${engine} for ${deployParams.RELEASE}. Please follow up with DEV team.\""
				exit 1
			}
		}
		// Cleanup repository in the workspace.
		sh "rm -rf ${WORKSPACE}/Application_Configuration"
		if(engineFiles) {
			return engineFiles.substring(0, engineFiles.length() - 1);
		}
	
}



def getEngineFiles_lt(deployParams) {
	def engineFiles = ""
	
	//checkout BW_Applications repository.
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Application_Configuration"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_BW_Application_Configuration.git']]]
	
 	def majv = deployParams.RELEASE.split('CCS')[1].split('\\.')[0]
	def minv = deployParams.RELEASE.split('CCS')[1].split('\\.')[1]		
	
	def filehome = sh(script:"cat ${WORKSPACE}/ENV/FILE_Configuration/${deployParams.env}/${deployParams.env}_File | grep 'FILE_HOME' | awk -F ':' '{print \$2}' | tr -d ' '" ,returnStdout: true).trim()
	sh "cd Application_Configuration; git checkout master"
	deployParams.engines.split(';').each { engine ->
	
		def file_template = new File("${WORKSPACE}/Application_Configuration/Files_Engines_Mapping_Template/${deployParams.type}_Template.txt").readLines()
		def result = file_template.findAll { it.startsWith(engine) }
		if(result) {
			def modified_result = result[0].replaceAll("~", filehome)
			engineFiles = engineFiles + engine + ':' + modified_result.split(':')[1] + ';'
		}
	}
	// Cleanup repository in the workspace.
	sh "rm -rf ${WORKSPACE}/Application_Configuration"
	if(engineFiles) {
		return engineFiles.substring(0, engineFiles.length() - 1);
	}
}


/*********************************************************************************************************************
Function Name: get_engine_bw_folder_name_from_gvconf()
This function will get the folder name from engine specific gvconf, by checking out the repository with passed tag.
Assumption is folder names remains same across all the environments.

Input: Engine name
Output: Folder Name
*********************************************************************************************************************/

def get_engine_bw_folder_name_from_gvconf(deployParams){
	// Function to get Folder name for each of the engine selected for BW deployment.
	def bw_folder = ""
	//checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: "refs/tags/${engine}-${version}"]], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Application_Configuration"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_BW_Application_Configuration.git']]]
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Application_Configuration"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_BW_Application_Configuration.git']]]
	
	def gv_file = new File("${WORKSPACE}/Application_Configuration/BW_Configurations/${deployParams.engine}/${deployParams.engine}.gvconf").readLines()
	def result = gv_file.findAll { it.contains("Env/JMS/Connections/BW/MIG_JMSURL") }
	if(result) {
		bw_folder = result[0].split('\\.')[0]
	}
	// Cleanup repository in the workspace.
	sh "rm -rf ${WORKSPACE}/Application_Configuration"
	return bw_folder
}


return this


