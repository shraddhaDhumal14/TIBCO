
/*********************************************************************************************************************
Author: Anil Kolli
Date: 13/04/2020
/*********************************************************************************************************************
This file holds all the functions related to EMAIL generation and content creation.
Below are the functions listed in thsi file.
1. insert_row()
2. insert_release_table()
3. insert_release_table()
4. get_results_email_summary()
5. release_notes_email_body()
6. get_engine_versions_summary()
7. get_release_notes_bw_sit()
8. get_release_notes_bw_sit()

History:

13-Apr-2020: ANIL KOLLI : Initial Baselining.
02-Jul-2020: ANIL KOLLI : [CICD-187]: Added get_release_notes_bw_sit() function to generate release notes for BW for SIT team.
03-Jul-2020: ANIL KOLLI : [CICD-187]: Added get_release_notes_bw_sit() function to generate release notes for Gateway for SIT team.

/*********************************************************************************************************************
This function will insert a map as a row in the given format to HTML string, which is used to generate report.
*********************************************************************************************************************/


def insert_row(deployParams) {
	// This function is to insert row for each engine in status report
	def html_string = ""
	deployParams.map.each { key, value ->
		html_string = html_string + """<tr>"""
		html_string = html_string + """<td class="tg-0lax">${key}</td>"""
		html_string = html_string + """<td class="tg-0lax">${value['BW_VERSION']}</td>"""
		html_string = html_string + """<td class="tg-0lax">${value['BW_FOLDER_NAME']}</td>"""
		html_string = html_string + """<td class="tg-0lax">${value['BW_ENGINE_TYPE']}</td>"""
		html_string = html_string + """<td class="tg-0lax">${value['SQL_VERSION']}</td>"""
		html_string = html_string + """<td class="tg-0lax">${value['EMS_VERSION']}</td>"""
		html_string = html_string + """<td style="max-width:125px;" class="tg-0lax">${value['XML_FILES']}</td>"""
		html_string = html_string + """<td style="max-width:125px;" class="tg-0lax">${value['JAR_FILES']}</td>"""
		html_string = html_string + """<td style="max-width:125px;" class="tg-0lax">${value['EMAIL_FILES']}</td>"""
		html_string = html_string + """</tr>"""
	}
	return html_string
}

/*********************************************************************************************************************
Given the master map, this function creates HTML table out of keys and values( engines and versions) and return to the main HTML function. 
*********************************************************************************************************************/


def insert_release_table(deployParams) {
	// This function is to insert row for each engine in status report
	def html_string = ""
	deployParams.map.each { key, value ->
		
		html_string = html_string + """<br><br><table class="tg" style="undefined;table-layout: fixed; width: 100%"">"""
		html_string = html_string + """<colgroup><col style="width: 90px"><col style="width: 90px"><col style="width: 90px"><col style="width: 90px"></colgroup>""" 
		html_string = html_string + """<th class="tg-amwm" colspan="4">${key} - PREVIOUS BUILD TAGS</th>"""
		html_string = html_string + """<tr><td class="tg-0lax" colspan="4">BW_ENGINE: ${key}<br>BW_VERSION: ${value['BW_VERSION']}<br>BW_FOLDER_NAME: ${value['BW_FOLDER_NAME']}<br>BW_ENGINE_TYPE: ${value['BW_ENGINE_TYPE']}<br>SQL_VERSION: ${value['SQL_VERSION']}<br>EMS_VERSION: ${value['EMS_VERSION']}"""
		
 		// add BW engine release notes
 		if(value['BW_VERSION'] != "NA") {
			html_string = html_string + """<br><tr><td style="text-align:left" class="tg-amwm" colspan="4">${key} - BW PREVIOUS BUILD TAGS</td></tr>""" + """<tr><td class="tg-0lax" colspan="4"><pre>""" + "${get_engine_release_info engine: key, target_repo: 'LINKTEST_REPO', REPO_URL: deployParams.NEXUS_URL, GROUPID: deployParams.BW_GROUPID, version: deployParams.majorVersion + '_' + deployParams.minorVersion}" + """</td></tr></pre>"""
			//html_string = html_string + """<br></td></tr></table>"""
		}
		
		html_string = html_string + """<br><br>"""
		// add EMS engine release notes
		if(value['EMS_VERSION'] != "NA"){
			html_string = html_string + """<br><tr><td style="text-align:left" class="tg-amwm" colspan="4">${key} - EMS PREVIOUS BUILD TAGS</td></tr>""" + """<tr><td class="tg-0lax" colspan="4"><pre>""" + "${get_engine_release_info engine: key, target_repo: 'LINKTEST_REPO', REPO_URL: deployParams.NEXUS_URL, GROUPID: deployParams.EMS_GROUPID, version: deployParams.majorVersion + '_' + deployParams.minorVersion}" + """</td></tr></pre>"""
			//html_string = html_string + """<br></td></tr></table>"""
		}
		html_string = html_string + """<br><br>"""
		
		// add SQL engine release notes
		if(value['SQL_VERSION'] != "NA"){
			html_string = html_string + """<br><tr><td style="text-align:left" class="tg-amwm" colspan="4">${key} - SQL PREVIOUS BUILD TAGS</td></tr>""" + """<tr><td class="tg-0lax" colspan="4"><pre>""" + "${get_engine_release_info engine: key, target_repo: 'LINKTEST_REPO', REPO_URL: deployParams.NEXUS_URL, GROUPID: deployParams.SQL_GROUPID, version: deployParams.majorVersion + '_' + deployParams.minorVersion}" + """</td></tr></pre>"""
		}
		html_string = html_string + """<br></td></tr></table>"""
	}
	
	return html_string
}

/*********************************************************************************************************************
This function will take results map and create rows for each engine as a html string and returns to the main function.
*********************************************************************************************************************/


def insert_results_row(deployParams) {
	// This function is to insert row for each engine in status report
	def html_string = ""
	deployParams.map.each { key, value ->
		html_string = html_string + """<tr>"""
		html_string = html_string + """<td class="tg-0lax">${key}</td>"""
		value.each { key2, value2 ->
			if(value2 == "FAILED"){
				html_string = html_string + """
					<td class="tg-fail" colspan="1">${value2}</td>
				"""
			} else if(value2 == "PASSED") {
				html_string = html_string + """
					<td class="tg-pass" colspan="1">${value2}</td>
				"""
				
			} else if(value2 == "NOT_STARTED") {
				html_string = html_string + """
					<td class="tg-notstarted" colspan="1">${value2}</td>
				"""
				
			} else {
				html_string = html_string + """
					<td class="tg-notrequired" colspan="1">${value2}</td>
				"""
			}
		}
		html_string = html_string + """</tr>"""
	}
	return html_string
}



def insert_version_result_row(deployParams) {
	// This function is to insert row for each engine in status report
	def html_string = ""
	deployParams.map.each { key, value ->
		html_string = html_string + """<tr>"""
		html_string = html_string + """<td class="tg-0lax">${key}</td>"""
		html_string = html_string + """<td class="tg-${value['BW_Generation']}">${value['BW_Generation']}</td>"""
		html_string = html_string + """<td class="tg-${value['SQL_Deployment']}">${value['SQL_Deployment']}</td>"""
		html_string = html_string + """<td class="tg-${value['EMS_Deployment']}">${value['EMS_Deployment']}</td>"""
		html_string = html_string + """<td class="tg-${value['XML_Deployment']}">${value['XML_Deployment']}</td>"""
		html_string = html_string + """<td class="tg-${value['JAR_Deployment']}">${value['JAR_Deployment']}</td>"""
		html_string = html_string + """<td class="tg-${value['EMAIL_Deployment']}">${value['EMAIL_Deployment']}</td>"""
		html_string = html_string + """<td class="tg-${value['BW_Deployment']}">${value['BW_Deployment']}</td>"""
		html_string = html_string + """<td class="tg-${value['BW_Restart']}">${value['BW_Restart']}</td>"""
		html_string = html_string + """<td class="tg-${value['RF1_RESULT']}">${value['RF1_RESULT']}</td>"""
		html_string = html_string + """<td class="tg-${value['RB_RESULT']}">${value['RB_RESULT']}</td>"""
		html_string = html_string + """<td class="tg-${value['RF2_RESULT']}">${value['RF2_RESULT']}</td>"""
		html_string = html_string + """<td class="tg-${value['RESULT']}">${value['RESULT']}</td>"""
		html_string = html_string + """</tr>"""
	}
	return html_string
}

/*********************************************************************************************************************
 Function to generate Results email summary
*********************************************************************************************************************/



/* Function to generate Results email summary*/


def get_results_email_summary(deployParams){
	def date_format_report = new Date().format("dd/MM/yyy HH:mm")
	def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;width:150px;word-break:break-all;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
		.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:break-all;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		.tg .tg-PASSED{background-color:lightgreen;text-align:left;vertical-align:top}
		.tg .tg-FAILED{background-color:red;text-align:left;vertical-align:top}
		.tg .tg-NOT_STARTED{background-color:lightgrey;text-align:left;vertical-align:top}
		.tg .tg-NOT_REQUIRED{background-color:#E1E0A2;text-align:left;vertical-align:top}
		</style>
		<table class="tg" style="undefined;table-layout: fixed; width: 100%"">
		<colgroup>
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		</colgroup>
		  <tr>
			<th class="tg-amwm" colspan="9">BUILD SUMMARY</th>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">Submitted By</td>
			<td class="tg-0lax" colspan="3">${getBuildUserID()}</td>
			<td class="tg-1wig" colspan="2">Date</td>
			<td class="tg-0lax" colspan="2">${date_format_report}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">BUILD_DESCRIPTION</td>
			<td class="tg-0lax" colspan="7">${params.Description}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">BUILD_URL</td>
			<td class="tg-0lax" colspan="7">${BUILD_URL}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">REPORT_STAGE</td>
			<td class="tg-0lax" colspan="7">${deployParams.REPORT_STAGE}</td>			
		  </tr>
		  <tr>
		</table>
		<br><br><br>
		<table class="tg" style="undefined;table-layout: fixed; width: 100%"">
		<colgroup>
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		</colgroup>
		  <tr>
			<td class="tg-1wig" colspan="2">LOG_URL</td>
			<td class="tg-0lax" colspan="7">${BUILD_URL}/console</td>
		  </tr>
		</table>
		<br><br><br>
		<table class="tg" style="undefined;table-layout: fixed; width: 100%"">
		<colgroup>
		<col style="width: 250px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		</colgroup>
		<colgroup>
		<tr>
			<th class="tg-amwm" colspan="1">ENGINE_NAME</td>
			<th class="tg-amwm" colspan="1">BW_Generation</td>
			<th class="tg-amwm" colspan="1">SQL_Deployment</td>
			<th class="tg-amwm" colspan="1">EMS_Deployment</td>
			<th class="tg-amwm" colspan="1">XML_Deployment</td>
			<th class="tg-amwm" colspan="1">JAR_Deployment</td>
			<th class="tg-amwm" colspan="1">EMAIL_Deployment</td>
			<th class="tg-amwm" colspan="1">BW_Deployment</td>
			<th class="tg-amwm" colspan="1">BW_Restart</td>
			<th class="tg-amwm" colspan="1">RF1_RESULT</td>
			<th class="tg-amwm" colspan="1">RB_RESULT</td>
			<th class="tg-amwm" colspan="1">RF2_RESULT</td>
			<th class="tg-amwm" colspan="1">RESULT</td>
		</tr>
		</colgroup>
  		  ${insert_version_result_row map: deployParams.map}	
		</table>
	"""
	emailBody = body_build_summary
	writeFile file: "/opt/tibco/.jenkins/userContent/Upliftment/${params.Environment}/${params.Release}/${date_now}/Upliftment_Wrapper_Report.html", text: emailBody 
	echo "Upliftment Summary : http://195.233.197.150:8080/jenkins/userContent/Upliftment/${params.Environment}/${params.Release}/${date_now}/Upliftment_Wrapper_Report.html"

	return body_build_summary
}

/*********************************************************************************************************************
Function to generate Email Build Summary
*********************************************************************************************************************/



/* Function to generate Email Build Summary*/
def release_notes_email_body(deployParams){
	def date_format_report = new Date().format("dd/MM/yyy HH:mm")
	def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;width:150px;word-break:break-all;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
		.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:break-all;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		.tg .tg-pass{background-color:lightgreen;text-align:left;vertical-align:top}
		.tg .tg-fail{background-color:red;text-align:left;vertical-align:top}
		.tg .tg-notstarted{background-color:lightgrey;text-align:left;vertical-align:top}
		.tg .tg-notrequired{background-color:#E1E0A2;text-align:left;vertical-align:top}
		</style>
		<table class="tg" style="undefined;table-layout: fixed; width: 100%">
		<colgroup>
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		</colgroup>
		  <tr>
			<th class="tg-amwm" colspan="9">UPLIFTMENT ENGINES & VERSIONS SUMMARY</th>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">Submitted By</td>
			<td class="tg-0lax" colspan="3">${getBuildUserID()}</td>
			<td class="tg-1wig" colspan="2">Date</td>
			<td class="tg-0lax" colspan="2">${date_format_report}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">BUILD_DESCRIPTION</td>
			<td class="tg-0lax" colspan="3">${params.Description}</td>
			<td class="tg-1wig" colspan="2">TARGET ENVIRONMENT</td>
			<td class="tg-0lax" colspan="2">${params.Target_Env}</td>			
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">BUILD_URL</td>
			<td class="tg-0lax" colspan="7">${BUILD_URL}</td>
		  </tr>
		  <tr>
		</table>
		<br><br><br>
		<table class="tg" style="undefined;table-layout: fixed; width: 100%"">
		<colgroup>
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		</colgroup>
		  <tr>
			<td class="tg-1wig" colspan="2">LOG_URL</td>
			<td class="tg-0lax" colspan="7">${BUILD_URL}/console</td>
		  </tr>
		</table>
		<br><br><br>
		<table class="tg" style="undefined;table-layout: fixed; width: 100%"">
		<colgroup>
		<col style="width: 20%">
		<col style="width: 5%">
		<col style="width: 5%">
		<col style="width: 5%">
		<col style="width: 5%">
		<col style="width: 5%">
		<col style="width: 20%">
		<col style="width: 20%">
		<col style="width: 15%">
		</colgroup>
		<colgroup>
		<tr>
			<th class="tg-amwm" colspan="1">ENGINE_NAME</td>
			<th class="tg-amwm" colspan="1">BW_VERSION</td>
			<th class="tg-amwm" colspan="1">BW_FOLDER_NAME</td>
			<th class="tg-amwm" colspan="1">BW_DEPLOYMENT_TYPE</td>
			<th class="tg-amwm" colspan="1">SQL_VERSION</td>
			<th class="tg-amwm" colspan="1">EMS_VERSION</td>
			<th class="tg-amwm" colspan="1">XML_FILES</td>
			<th class="tg-amwm" colspan="1">JAR_FILES</td>
			<th class="tg-amwm" colspan="1">EMAIL_FILES</td>			
		</tr>
		</colgroup>
  		  ${insert_row map: deployParams.map}
		</table>
		<br><br>
		${insert_release_table map: deployParams.map, Promotion_Repo: deployParams.Promotion_Repo, NEXUS_URL: deployParams.NEXUS_URL, BW_GROUPID: deployParams.BW_GROUPID, EMS_GROUPID: deployParams.EMS_GROUPID, SQL_GROUPID: deployParams.SQL_GROUPID, majorVersion: deployParams.majorVersion, minorVersion: deployParams.minorVersion}
	"""
	emailBody = body_build_summary
	//writeFile file: "${WORKSPACE}/Reports/Upliftment_Summary_Report.html", text: emailBody
	writeFile file: "./Upliftment_Release_Report.html", text: emailBody 
	//echo "Upliftment Summary : http://195.233.197.150:8080/jenkins/userContent/Upliftment/${params.Environment}/${params.Release}/${date_now}/Upliftment_Report.html"				
	return body_build_summary
}


/*********************************************************************************************************************
Function to generate Email Build Summary
*********************************************************************************************************************/


/* Function to generate Email Build Summary*/
def get_engine_versions_summary(deployParams){
	def date_format_report = new Date().format("dd/MM/yyy HH:mm")
	def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;width:150px;word-break:break-all;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
		.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:break-all;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		.tg .tg-PASSED{background-color:lightgreen;text-align:left;vertical-align:top}
		.tg .tg-FAILED{background-color:red;text-align:left;vertical-align:top}
		.tg .tg-NOT_STARTED{background-color:lightgrey;text-align:left;vertical-align:top}
		.tg .tg-NOT_REQUIRED{background-color:#E1E0A2;text-align:left;vertical-align:top}
		</style>
		<table class="tg" style="undefined;table-layout: fixed; width: 100%"">
		<colgroup>
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		</colgroup>
		  <tr>
			<th class="tg-amwm" colspan="9">ENGINES & VERSIONS SUMMARY </th>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">Submitted By</td>
			<td class="tg-0lax" colspan="3">${getBuildUserID()}</td>
			<td class="tg-1wig" colspan="2">Date</td>
			<td class="tg-0lax" colspan="2">${date_format_report}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">BUILD_DESCRIPTION</td>
			<td class="tg-0lax" colspan="3">${params.Description}</td>
			<td class="tg-1wig" colspan="2">TARGET ENVIRONMENT</td>
			<td class="tg-0lax" colspan="2">${deployParams.Target_Env}</td>			
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">BUILD_URL</td>
			<td class="tg-0lax" colspan="7">${BUILD_URL}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">REPORT_STAGE</td>
			<td class="tg-0lax" colspan="7">${deployParams.REPORT_STAGE}</td>
		  </tr>
		  <tr>
		</table>
		<br><br><br>
		<table class="tg" style="undefined;table-layout: fixed; width: 100%"">
		<colgroup>
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		</colgroup>
		  <tr>
			<td class="tg-1wig" colspan="2">LOG_URL</td>
			<td class="tg-0lax" colspan="7">${BUILD_URL}/console</td>
		  </tr>
		</table>
		<br><br><br>
		<table class="tg" style="undefined;table-layout: fixed; width: 100%"">
		<colgroup>
		<col style="width: 20%">
		<col style="width: 5%">
		<col style="width: 5%">
		<col style="width: 5%">
		<col style="width: 5%">
		<col style="width: 5%">
		<col style="width: 20%">
		<col style="width: 20%">
		<col style="width: 15%">
		</colgroup>
		<colgroup>
		<tr>
			<th class="tg-amwm" colspan="1">ENGINE_NAME</td>
			<th class="tg-amwm" colspan="1">BW_VERSION</td>
			<th class="tg-amwm" colspan="1">BW_FOLDER_NAME</td>
			<th class="tg-amwm" colspan="1">BW_DEPLOYMENT_TYPE</td>
			<th class="tg-amwm" colspan="1">SQL_VERSION</td>
			<th class="tg-amwm" colspan="1">EMS_VERSION</td>
			<th class="tg-amwm" colspan="1">XML_FILES</td>
			<th class="tg-amwm" colspan="1">JAR_FILES</td>
			<th class="tg-amwm" colspan="1">EMAIL_FILES</td>
		</tr>
		</colgroup>
  		  ${insert_row map: deployParams.map}	
		</table>
	"""
	emailBody = body_build_summary
	//writeFile file: "${WORKSPACE}/Reports/Upliftment_Summary_Report.html", text: emailBody
	//writeFile file: "/opt/tibco/.jenkins/userContent/Upliftment/${params.Environment}/${params.Release}/${date_now}/Upliftment_Report.html", text: emailBody 
	//echo "Upliftment Summary : http://195.233.197.150:8080/jenkins/userContent/Upliftment/${params.Environment}/${params.Release}/${date_now}/Upliftment_Report.html"				
	return body_build_summary
}

/*Rollback files
*/
def rollback_files(deployParams) {
	String engines = ""
	engines = convert_map_to_string engine_map: deployParams.map
	//Running the ansible deploy playbook
	ansiColor('xterm') {
			 ansiblePlaybook(playbook: "./${deployParams.Host}_Files_Deploy/File_Deployment/filesRollBack.yml", colorized: true, extras:'-v', extraVars: [host: "${deployParams.Host}", file_snap: "${engines}", crq_num: "${deployParams.crq_no}", datetime: "${deployParams.datetime}"])
	}
}


/*********************************************************************************************************************
This function will insert a rows to result map for single engine.
*********************************************************************************************************************/

def insert_lt_result_row(deployParams) {
	// This function is to insert row for each engine in status report
	def html_string = ""
	deployParams.map.each { key, value ->
		html_string = html_string + """<tr>"""
		html_string = html_string + """<td class="tg-0lax">${key}</td>"""
		html_string = html_string + """<td class="tg-${value['BW_Generation']}">${value['BW_Generation']}</td>"""
		html_string = html_string + """<td class="tg-${value['SQL_Deployment']}">${value['SQL_Deployment']}</td>"""
		html_string = html_string + """<td class="tg-${value['EMS_Deployment']}">${value['EMS_Deployment']}</td>"""
		html_string = html_string + """<td class="tg-${value['XML_Deployment']}">${value['XML_Deployment']}</td>"""
		html_string = html_string + """<td class="tg-${value['JAR_Deployment']}">${value['JAR_Deployment']}</td>"""
		html_string = html_string + """<td class="tg-${value['EMAIL_Deployment']}">${value['EMAIL_Deployment']}</td>"""
		html_string = html_string + """<td class="tg-${value['BW_Deployment']}">${value['BW_Deployment']}</td>"""
		html_string = html_string + """<td class="tg-${value['BW_Restart']}">${value['BW_Restart']}</td>"""
		html_string = html_string + """<td class="tg-${value['RESULT']}">${value['RESULT']}</td>"""
		html_string = html_string + """</tr>"""
	}
	return html_string
}


/*********************************************************************************************************************
This function will resturn html string for LT pipelines which is having single engine.
*********************************************************************************************************************/


def get_lt_results_summary(deployParams){
	def date_format_report = new Date().format("dd/MM/yyy HH:mm")
	def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;width:150px;word-break:break-all;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
		.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:break-all;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		.tg .tg-PASSED{background-color:lightgreen;text-align:left;vertical-align:top}
		.tg .tg-FAILED{background-color:red;text-align:left;vertical-align:top}
		.tg .tg-NOT_STARTED{background-color:lightgrey;text-align:left;vertical-align:top}
		.tg .tg-NOT_REQUIRED{background-color:#E1E0A2;text-align:left;vertical-align:top}
		</style>
		<table class="tg" style="undefined;table-layout: fixed; width: 100%"">
		<colgroup>
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		</colgroup>
		  <tr>
			<th class="tg-amwm" colspan="9">DEPLOYMENT SUMMARY</th>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">Submitted By</td>
			<td class="tg-0lax" colspan="3">${getBuildUserID()}</td>
			<td class="tg-1wig" colspan="2">Date</td>
			<td class="tg-0lax" colspan="2">${date_format_report}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">RELEASE</td>
			<td class="tg-0lax" colspan="3">${deployParams.release}</td>
			<td class="tg-1wig" colspan="2">CRQ NUMBER</td>
			<td class="tg-0lax" colspan="2">${deployParams.crq_num}</td>
		  </tr>		  
		  <tr>
			<td class="tg-1wig" colspan="2">DEPLOYMENT_DESCRIPTION</td>
			<td class="tg-0lax" colspan="7">${params.Description}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">BUILD_URL</td>
			<td class="tg-0lax" colspan="7">${BUILD_URL}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">REPORT_STAGE</td>
			<td class="tg-0lax" colspan="7">${deployParams.REPORT_STAGE}</td>			
		  </tr>
		  <tr>
		</table>
		<br><br><br>
		
		<table class="tg" style="undefined;table-layout: fixed; width: 100%"">
		<colgroup>
		<col style="width: 20%">
		<col style="width: 5%">
		<col style="width: 5%">
		<col style="width: 5%">
		<col style="width: 5%">
		<col style="width: 5%">
		<col style="width: 20%">
		<col style="width: 20%">
		<col style="width: 15%">
		</colgroup>
		<colgroup>
		<tr>
			<th class="tg-amwm" colspan="1">ENGINE_NAME</td>
			<th class="tg-amwm" colspan="1">BW_VERSION</td>
			<th class="tg-amwm" colspan="1">BW_FOLDER_NAME</td>
			<th class="tg-amwm" colspan="1">BW_DEPLOYMENT_TYPE</td>
			<th class="tg-amwm" colspan="1">SQL_VERSION</td>
			<th class="tg-amwm" colspan="1">EMS_VERSION</td>
			<th class="tg-amwm" colspan="1">XML_FILES</td>
			<th class="tg-amwm" colspan="1">JAR_FILES</td>
			<th class="tg-amwm" colspan="1">EMAIL_FILES</td>
		</tr>
		</colgroup>
  		  ${insert_row map: deployParams.map}	
		</table>		
		<br><br><br>
		<table class="tg" style="undefined;table-layout: fixed; width: 100%"">
		<colgroup>
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		</colgroup>
		  <tr>
			<td class="tg-1wig" colspan="2">LOG_URL</td>
			<td class="tg-0lax" colspan="7">${BUILD_URL}/console</td>
		  </tr>
		</table>	
		<br><br><br><br>
		<table class="tg" style="undefined;table-layout: fixed; width: 100%"">
		<colgroup>
		<col style="width: 250px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		</colgroup>
		<colgroup>
		<tr>
			<th class="tg-amwm" colspan="1">ENGINE_NAME</td>
			<th class="tg-amwm" colspan="1">BW_Generation</td>
			<th class="tg-amwm" colspan="1">SQL_Deployment</td>
			<th class="tg-amwm" colspan="1">EMS_Deployment</td>
			<th class="tg-amwm" colspan="1">XML_Deployment</td>
			<th class="tg-amwm" colspan="1">JAR_Deployment</td>
			<th class="tg-amwm" colspan="1">EMAIL_Deployment</td>
			<th class="tg-amwm" colspan="1">BW_Deployment</td>
			<th class="tg-amwm" colspan="1">BW_Restart</td>
			<th class="tg-amwm" colspan="1">RESULT</td>
		</tr>
		</colgroup>
  		  ${insert_lt_result_row map: deployParams.map}	
		</table>
	"""
	emailBody = body_build_summary
	writeFile file: "/opt/tibco/.jenkins/userContent/Upliftment/${params.Environment}/${params.Release}/${date_now}/Upliftment_Wrapper_Report.html", text: emailBody 
	echo "Upliftment Summary : http://195.233.197.150:8080/jenkins/userContent/Upliftment/${params.Environment}/${params.Release}/${date_now}/Upliftment_Wrapper_Report.html"

	return body_build_summary
}


def insert_prod_result_row(deployParams) {
	// This function is to insert row for each engine in status report
	def html_string = ""
	deployParams.map.each { key, value ->
		html_string = html_string + """<tr>"""
		html_string = html_string + """<td class="tg-0lax">${key}</td>"""
		html_string = html_string + """<td class="tg-${value['BW_Generation']}">${value['BW_Generation']}</td>"""
		html_string = html_string + """<td class="tg-${value['SQL_Deployment']}">${value['SQL_Deployment']}</td>"""
		html_string = html_string + """<td class="tg-${value['EMS_Deployment']}">${value['EMS_Deployment']}</td>"""
		html_string = html_string + """<td class="tg-${value['XML_Deployment']}">${value['XML_Deployment']}</td>"""
		html_string = html_string + """<td class="tg-${value['JAR_Deployment']}">${value['JAR_Deployment']}</td>"""
		html_string = html_string + """<td class="tg-${value['EMAIL_Deployment']}">${value['EMAIL_Deployment']}</td>"""
		html_string = html_string + """<td class="tg-${value['BW_Deployment']}">${value['BW_Deployment']}</td>"""
		html_string = html_string + """<td class="tg-${value['BW_Restart']}">${value['BW_Restart']}</td>"""
		html_string = html_string + """<td class="tg-${value['RF1_RESULT']}">${value['RF1_RESULT']}</td>"""
		html_string = html_string + """<td class="tg-${value['RB_RESULT']}">${value['RB_RESULT']}</td>"""
		html_string = html_string + """<td class="tg-${value['RESULT']}">${value['RESULT']}</td>"""
		html_string = html_string + """</tr>"""
	}
	return html_string
}



/*********************************************************************************************************************
 Function to generate Results email summary
*********************************************************************************************************************/



/* Function to generate Results email summary*/


def get_prod_results_email_summary(deployParams){
	def date_format_report = new Date().format("dd/MM/yyy HH:mm")
	def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;width:150px;word-break:break-all;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
		.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:break-all;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		.tg .tg-PASSED{background-color:lightgreen;text-align:left;vertical-align:top}
		.tg .tg-FAILED{background-color:red;text-align:left;vertical-align:top}
		.tg .tg-NOT_STARTED{background-color:lightgrey;text-align:left;vertical-align:top}
		.tg .tg-NOT_REQUIRED{background-color:#E1E0A2;text-align:left;vertical-align:top}
		</style>
		<table class="tg" style="undefined;table-layout: fixed; width: 100%"">
		<colgroup>
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		</colgroup>
		  <tr>
			<th class="tg-amwm" colspan="9">DEPLOYMENT SUMMARY</th>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">Submitted By</td>
			<td class="tg-0lax" colspan="3">${getBuildUserID()}</td>
			<td class="tg-1wig" colspan="2">Date</td>
			<td class="tg-0lax" colspan="2">${date_format_report}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">DEPLOYMENT_DESCRIPTION</td>
			<td class="tg-0lax" colspan="7">${params.Description}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">DEPLOYMENT_URL</td>
			<td class="tg-0lax" colspan="7">${BUILD_URL}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">REPORT_STAGE</td>
			<td class="tg-0lax" colspan="7">${deployParams.REPORT_STAGE}</td>			
		  </tr>
		  <tr>
		</table>
		<br><br><br>
		<table class="tg" style="undefined;table-layout: fixed; width: 100%"">
		<colgroup>
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		</colgroup>
		  <tr>
			<td class="tg-1wig" colspan="2">LOG_URL</td>
			<td class="tg-0lax" colspan="7">${BUILD_URL}/console</td>
		  </tr>
		</table>
		<br><br><br>
		<table class="tg" style="undefined;table-layout: fixed; width: 100%"">
		<colgroup>
		<col style="width: 250px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		</colgroup>
		<colgroup>
		<tr>
			<th class="tg-amwm" colspan="1">ENGINE_NAME</td>
			<th class="tg-amwm" colspan="1">BW_Generation</td>
			<th class="tg-amwm" colspan="1">SQL_Deployment</td>
			<th class="tg-amwm" colspan="1">EMS_Deployment</td>
			<th class="tg-amwm" colspan="1">XML_Deployment</td>
			<th class="tg-amwm" colspan="1">JAR_Deployment</td>
			<th class="tg-amwm" colspan="1">EMAIL_Deployment</td>
			<th class="tg-amwm" colspan="1">BW_Deployment</td>
			<th class="tg-amwm" colspan="1">BW_Restart</td>
			<th class="tg-amwm" colspan="1">RF1_RESULT</td>
			<th class="tg-amwm" colspan="1">RB_RESULT</td>
			<th class="tg-amwm" colspan="1">RESULT</td>
		</tr>
		</colgroup>
  		  ${insert_prod_result_row map: deployParams.map}	
		</table>
	"""
	emailBody = body_build_summary
	writeFile file: "/opt/SP/tibco/.jenkins/userContent/Upliftment/${params.Environment}/${params.Release}/${date_now}/Upliftment_Wrapper_Report.html", text: emailBody 
	echo "Upliftment Summary : https://198.18.76.204:9080/jenkins/userContent/Upliftment/${params.Environment}/${params.Release}/${date_now}/Upliftment_Wrapper_Report.html"

	return body_build_summary
}


def insert_sit_result_row(deployParams) {
	// This function is to insert row for each engine in status report
	def html_string = ""
	deployParams.map.each { key, value ->
		html_string = html_string + """<tr>"""
		html_string = html_string + """<td class="tg-0lax">${key}</td>"""
		html_string = html_string + """<td class="tg-${value['BW_Generation']}">${value['BW_Generation']}</td>"""
		html_string = html_string + """<td class="tg-${value['SQL_Deployment']}">${value['SQL_Deployment']}</td>"""
		html_string = html_string + """<td class="tg-${value['EMS_Deployment']}">${value['EMS_Deployment']}</td>"""
		html_string = html_string + """<td class="tg-${value['XML_Deployment']}">${value['XML_Deployment']}</td>"""
		html_string = html_string + """<td class="tg-${value['JAR_Deployment']}">${value['JAR_Deployment']}</td>"""
		html_string = html_string + """<td class="tg-${value['EMAIL_Deployment']}">${value['EMAIL_Deployment']}</td>"""
		html_string = html_string + """<td class="tg-${value['BW_Deployment']}">${value['BW_Deployment']}</td>"""
		html_string = html_string + """<td class="tg-${value['BW_Restart']}">${value['BW_Restart']}</td>"""
		html_string = html_string + """<td class="tg-${value['RESULT']}">${value['RESULT']}</td>"""
		html_string = html_string + """</tr>"""
	}
	return html_string
}


/* Function to generate Results email summary for SIT*/


def get_sit_results_email_summary(deployParams){
	def date_format_report = new Date().format("dd/MM/yyy HH:mm")
	def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;width:150px;word-break:break-all;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
		.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:break-all;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		.tg .tg-PASSED{background-color:lightgreen;text-align:left;vertical-align:top}
		.tg .tg-FAILED{background-color:red;text-align:left;vertical-align:top}
		.tg .tg-NOT_STARTED{background-color:lightgrey;text-align:left;vertical-align:top}
		.tg .tg-NOT_REQUIRED{background-color:#E1E0A2;text-align:left;vertical-align:top}
		</style>
		<table class="tg" style="undefined;table-layout: fixed; width: 100%"">
		<colgroup>
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		</colgroup>
		  <tr>
			<th class="tg-amwm" colspan="9">DEPLOYMENT SUMMARY</th>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">Submitted By</td>
			<td class="tg-0lax" colspan="3">${getBuildUserID()}</td>
			<td class="tg-1wig" colspan="2">Date</td>
			<td class="tg-0lax" colspan="2">${date_format_report}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">DEPLOYMENT_DESCRIPTION</td>
			<td class="tg-0lax" colspan="7">${params.Description}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">DEPLOYMENT_URL</td>
			<td class="tg-0lax" colspan="7">${BUILD_URL}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">REPORT_STAGE</td>
			<td class="tg-0lax" colspan="7">${deployParams.REPORT_STAGE}</td>			
		  </tr>
		  <tr>
		</table>
		<br><br><br>
		<table class="tg" style="undefined;table-layout: fixed; width: 100%"">
		<colgroup>
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		</colgroup>
		  <tr>
			<td class="tg-1wig" colspan="2">LOG_URL</td>
			<td class="tg-0lax" colspan="7">${BUILD_URL}/console</td>
		  </tr>
		</table>
		<br><br><br>
		<table class="tg" style="undefined;table-layout: fixed; width: 100%"">
		<colgroup>
		<col style="width: 250px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		</colgroup>
		<colgroup>
		<tr>
			<th class="tg-amwm" colspan="1">ENGINE_NAME</td>
			<th class="tg-amwm" colspan="1">BW_Generation</td>
			<th class="tg-amwm" colspan="1">SQL_Deployment</td>
			<th class="tg-amwm" colspan="1">EMS_Deployment</td>
			<th class="tg-amwm" colspan="1">XML_Deployment</td>
			<th class="tg-amwm" colspan="1">JAR_Deployment</td>
			<th class="tg-amwm" colspan="1">EMAIL_Deployment</td>
			<th class="tg-amwm" colspan="1">BW_Deployment</td>
			<th class="tg-amwm" colspan="1">BW_Restart</td>
			<th class="tg-amwm" colspan="1">RESULT</td>
		</tr>
		</colgroup>
  		  ${insert_sit_result_row map: deployParams.map}	
		</table>
	"""
	emailBody = body_build_summary
	writeFile file: "/opt/tibco/.jenkins/userContent/Upliftment/${params.Environment}/${params.Release}/${date_now}/Upliftment_Wrapper_Report.html", text: emailBody 
	echo "Upliftment Summary : http://195.233.197.150:8080/jenkins/userContent/Upliftment/${params.Environment}/${params.Release}/${date_now}/Upliftment_Wrapper_Report.html"

	return body_build_summary
}

/*********************************************************************************************************************
[CICD-187]: Function to generate Email Build Summary for release notes for SIT bw

Usage:

def emailContent = 	get_release_notes_bw_sit map: ENGINE_MAP, ENGINE_NAME: "${params.ENGINE_NAME}", RELEASE: "${params.RELEASE}", CRQ: "${params.CRQ_NUM}", Description: "${params.DESCRIPTION}", buildRequester: "${params.Description}", fileChanges: FILES_DEPLOYED.replaceAll("[\\t\\n\\r]+","<br>"), masterGV: masterGV_Update.replaceAll("[\\t\\n\\r]+","<br>"), processGV: processGV_Update.replaceAll("[\\t\\n\\r]+","<br>"), engineTemplate: newEngineTemplate.replaceAll("[\\t\\n\\r]+","<br>"), append_prepend: APPEND_PREPEND_PATHS.replaceAll("[\\t\\n\\r]+","<br>"), manualChanges: POST_MANUAL_CHANGES.replaceAll("[\\t\\n\\r]+","<br>"), knownErrors: KNOWN_ERRORS_UPDATE.replaceAll("[\\t\\n\\r]+","<br>"), certChanges: CERTIFICATE_UPDATE.replaceAll("[\\t\\n\\r]+","<br>"), specialInst: SPECIAL_INSTRUCTIONS.replaceAll("[\\t\\n\\r]+","<br>")

*********************************************************************************************************************/



def get_release_notes_bw_sit(deployParams){
	def date_format_report = new Date().format("dd/MM/yyy HH:mm")
	def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Times, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;width:150px;word-break:break-all;border-color:#9ABAD9;color:#444;background-color:#FFFF;}
		.tg th{font-family:Times, sans-serif;font-size:26px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:break-all;border-color:#9ABAD9;color:#1A0504;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		.tg .tg-pass{background-color:lightgreen;text-align:left;vertical-align:top}
		.tg .tg-fail{background-color:red;text-align:left;vertical-align:top}
		.tg .tg-notstarted{background-color:lightgrey;text-align:left;vertical-align:top}
		.tg .tg-notrequired{background-color:#E1E0A2;text-align:left;vertical-align:top}
		</style>
		<table class="tg" style="table-layout: fixed; width: 100%"">
		  <tr>
			<th class="tg-amwm" colspan="8">SIT RELEASE NOTES<img src="vodafone_logo.png" alt="Vodafone Logo" width="35" height="35" align="right"></th>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">DEPLOYED_BY</td>
			<td class="tg-0lax" colspan="2">${getBuildUserID()}</td>
			<td class="tg-1wig" colspan="2">DATE</td>
			<td class="tg-0lax" colspan="2">${date_format_report}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">ENGINE_NAME</td>
			<td class="tg-0lax" colspan="2">${deployParams.ENGINE_NAME}</td>
			<td class="tg-1wig" colspan="2">RELEASE</td>
			<td class="tg-0lax" colspan="2">${deployParams.RELEASE}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">JIRA/PBI/CRQ NO</td>
			<td class="tg-0lax" colspan="2">${deployParams.CRQ}</td>
			<td class="tg-1wig" colspan="2">BUILD_REQUESTER</td>
			<td class="tg-0lax" colspan="2">${deployParams.buildRequester}</td>
		  </tr>		  
		  <tr>
			<td class="tg-1wig" colspan="2">BUILD_DESCRIPTION</td>
			<td class="tg-0lax" colspan="6">${deployParams.Description}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">OPERATION_NAME</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${deployParams.operationName}</div></td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">PROJECT_NAME</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${deployParams.projectName}</div></td>
		  </tr>		  
		  <tr>
			<td class="tg-1wig" colspan="2">BUILD_URL</td>
			<td class="tg-0lax" colspan="6">${BUILD_URL}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">BW_VERSION</td>
			<td class="tg-0lax" colspan="2">${deployParams.map["${deployParams.ENGINE_NAME}"]['BW_VERSION']}</td>
		    <td class="tg-1wig" colspan="2">EMS_VERSION</td>
			<td class="tg-0lax" colspan="2">${deployParams.map["${deployParams.ENGINE_NAME}"]['EMS_VERSION']}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">SQL_VERSION</td>
			<td class="tg-0lax" colspan="2">${deployParams.map["${deployParams.ENGINE_NAME}"]['SQL_VERSION']}</td>
			<td class="tg-1wig" colspan="2"></td>
			<td class="tg-0lax" colspan="2"></td>			
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">FILES_DEPLOYED</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${deployParams.fileChanges}</div></td>
		  </tr>		  
		  <tr>
			<td class="tg-1wig" colspan="2">MASTER_GV_UPDATES</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${deployParams.masterGV}</div></td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">PROCESS_GV_UPDATES</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${deployParams.processGV}</div></td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">NEW_ENGINE_TEMPLATE</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${deployParams.engineTemplate}</div></td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">APPEND_PREPEND_UPDATES</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${deployParams.append_prepend}</div></td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">POST_MANUAL_CHANGES</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${deployParams.manualChanges}</div></td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">KNOWN_ERRORS_EXCLUSION</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${deployParams.knownErrors}</div></td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">CERTIFICATE_UPDATE</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${deployParams.certChanges}</div></td>
		  </tr>			  
		  <tr>
			<td class="tg-1wig" colspan="2">SPECIAL_INSTRUCTIONS</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${deployParams.specialInst}</div></td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">LOG_URL</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${BUILD_URL}/console</div></td>
		  </tr>
		</table>		
	"""
	return body_build_summary
}

/*********************************************************************************************************************
[CICD-187]: Function to generate Email Build Summary for release notes for SIT Gateway

Usage:

def emailContent = 	get_gateway_sit_release_notes GATEWAY_TYPE: "${params.GATEWAY_TYPE}", RELEASE: "${params.ReleaseNumber}", CRQ: "${params.JIRANo}", gatewayVersion: "${nextVersion}", Description: "${params.JIRADes}", operation: OPERATION_NAME.replaceAll("[\\t\\n\\r]+","<br>"), partnerData: PARTNER_DATA.replaceAll("[\\t\\n\\r]+","<br>"), tokens: TOKENS.replaceAll("[\\t\\n\\r]+","<br>"), specialInst: SPECIAL_INSTRUCTIONS.replaceAll("[\\t\\n\\r]+","<br>")

*********************************************************************************************************************/


def get_gateway_sit_release_notes(deployParams){
	def date_format_report = new Date().format("dd/MM/yyy HH:mm")
	def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Times, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;width:150px;word-break:break-all;border-color:#9ABAD9;color:#444;background-color:#FFFF;}
		.tg th{font-family:Times, sans-serif;font-size:26px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:break-all;border-color:#9ABAD9;color:#1A0504;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		.tg .tg-pass{background-color:lightgreen;text-align:left;vertical-align:top}
		.tg .tg-fail{background-color:red;text-align:left;vertical-align:top}
		.tg .tg-notstarted{background-color:lightgrey;text-align:left;vertical-align:top}
		.tg .tg-notrequired{background-color:#E1E0A2;text-align:left;vertical-align:top}
		</style>
		<table class="tg" style="table-layout: fixed; width: 100%"">
		  <tr>
			<th class="tg-amwm" colspan="8">GATEWAY RELEASE NOTES<img src="vodafone_logo.png" alt="Vodafone Logo" width="35" height="35" align="right"></th>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">BUILD_REQUESTER</td>
			<td class="tg-0lax" colspan="2">${getBuildUserID()}</td>
			<td class="tg-1wig" colspan="2">Date</td>
			<td class="tg-0lax" colspan="2">${date_format_report}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">GATEWAY</td>
			<td class="tg-0lax" colspan="2">${deployParams.GATEWAY_TYPE}</td>
			<td class="tg-1wig" colspan="2">RELEASE</td>
			<td class="tg-0lax" colspan="2">${deployParams.RELEASE}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">JIRA/PBI/CRQ NO</td>
			<td class="tg-0lax" colspan="2">${deployParams.CRQ}</td>
			<td class="tg-1wig" colspan="2"></td>
			<td class="tg-0lax" colspan="2"></td>
		  </tr>		  
		  <tr>
			<td class="tg-1wig" colspan="2">BUILD_DESCRIPTION</td>
			<td class="tg-0lax" colspan="6">${deployParams.Description}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">BUILD_URL</td>
			<td class="tg-0lax" colspan="6">${BUILD_URL}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">GATEWAY_VERSION</td>
			<td class="tg-0lax" colspan="6">${deployParams.gatewayVersion}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">OPERATION_NAME</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${deployParams.operation}</div></td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">PARTNER_DATA</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${deployParams.partnerData}</div></td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">TOKENS</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${deployParams.tokens}</div></td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">LOG_URL</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${BUILD_URL}/console</div></td>
		  </tr>
		</table>		
	"""
	return body_build_summary
}

//582528- Swindon Trigger - Upstream User Issue
def getBuildUserID(){
    if(currentBuild.getBuildCauses('hudson.triggers.TimerTrigger$TimerTriggerCause'))
            return "time_triggered"
    else if(currentBuild.getBuildCauses('hudson.model.Cause$UpstreamCause'))
    {
           def upstreamCause = currentBuild.rawBuild.getCause(Cause.UpstreamCause)
           def upstreamJob = Jenkins.getInstance().getItemByFullName(upstreamCause.getUpstreamProject(), hudson.model.Job.class)
           if (upstreamJob) {
                    def upstreamBuild = upstreamJob.getBuildByNumber(upstreamCause.getUpstreamBuild())
                    if (upstreamBuild) {
                            def realUpstreamCause = upstreamBuild.getCause(Cause.UserIdCause)
                            if (realUpstreamCause) {
                                    return realUpstreamCause.getUserId()
                            }
                    }
            }
            return "Upstream Triggered"
     }
    else
            return currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId()
}


/************************************************************************************************************/
/* Please do not delete this below line. This is required to include this to any main pipeline */
return this
/************************************************************************************************************/