
/*********************************************************************************************************************
Author: Nani,Anil Kolli & Raghuram Koripalli
Date: 25/03/2021
/*********************************************************************************************************************
This file holds all the functions related to SQL backup, generate and deployment.
Below are the functions listed in thsi file.
1. deploy_artefact()
2. gateway_restart()
3. rollback_artefact()
4. gateway_status()
5. gateway_pid()


*********************************************************************************************************************/

def deploy_artefact(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
			
			sh "cp -r ./PROD_Conf/Gateway_Configuration/${deployParams.GatewayType}/${deployParams.gatewayEnvironment}/* ./${deployParams.Host}/Gateway_Deployment/"
			
			sh "cp ./${deployParams.Host}/Gateway_Deployment/${deployParams.GatewayType}_${deployParams.Host} ./${deployParams.Host}/Gateway_Deployment/host_vars/"
			
            // Generate host vars file for external apache
			sh "cp ./${deployParams.Host}/Gateway_Deployment/${deployParams.GatewayType}_${deployParams.Host} ./${deployParams.Host}/Gateway_Deployment/host_vars/${deployParams.GatewayType}_${deployParams.Host}_ExternalApache"
			// Generate host vars file for internal apache
			sh "cp ./${deployParams.Host}/Gateway_Deployment/${deployParams.GatewayType}_${deployParams.Host} ./${deployParams.Host}/Gateway_Deployment/host_vars/${deployParams.GatewayType}_${deployParams.Host}_InternalApache"
            // rename tokens file to instance specific
			sh "cp ./${deployParams.Host}/Gateway_Deployment/Tokens/${deployParams.GatewayType}_${deployParams.gatewayEnvironment} ./${deployParams.Host}/Gateway_Deployment/Tokens/${deployParams.GatewayType}_${deployParams.Host}"
            
			
			echo "DEBUG: nexus_ArtefactVersion is: ${deployParams.nexus_ArtefactVersion}"
		
			//Run ansible playbook to deploy artefacts into environment
			 ansiColor('xterm') {
    	    ansiblePlaybook(playbook: "./${deployParams.Host}/Gateway_Deployment/Ops_DeployCert.yml", colorized: true, extras:'-v', extraVars: [host: "${deployParams.GatewayType}_${deployParams.Host}", repo_group_id: "${deployParams.nexus_group_id}", repo_artifact_id: "${deployParams.nexus_artifact_id}", repo_user: "${deployParams.nexus_user}", repo_pw: "${deployParams.nexus_passwd}", repo_repo_id: "${deployParams.nexus_repo_id}", repo_version: "${deployParams.nexus_ArtefactVersion}", repo_url: "${deployParams.nexus_url}", datetime: "${deployParams.datetime}", crq_no: "${deployParams.crq_no}", gatewayRestart: "${deployParams.gatewayRestart}", deployType: "${deployParams.deployType}"])
	
			}
    }
}

def gateway_code(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
			
			//Gateway Deployments
			// Copy host configutaion files to Ansible deployment script location
			//sh "cp -r ./${deployParams.Host}/Gateway_Configuration/${deployParams.GatewayType}/${deployParams.gatewayEnvironment}/* ./${deployParams.Host}/Gateway_Deployment/"
			sh "cp -r ./PROD_Conf/Gateway_Configuration/${deployParams.GatewayType}/${deployParams.gatewayEnvironment}/* ./${deployParams.Host}/Gateway_Deployment/"
			
			// copy host variables from configuration to ansible host vars folder
			sh "cp ./${deployParams.Host}/Gateway_Deployment/${deployParams.Host} ./${deployParams.Host}/Gateway_Deployment/host_vars/"
			// Generate host vars file for external apache
			sh "cp ./${deployParams.Host}/Gateway_Deployment/${deployParams.Host} ./${deployParams.Host}/Gateway_Deployment/host_vars/${deployParams.Host}_ExternalApache"
			// Generate host vars file for internal apache
			sh "cp ./${deployParams.Host}/Gateway_Deployment/${deployParams.Host} ./${deployParams.Host}/Gateway_Deployment/host_vars/${deployParams.Host}_InternalApache"
            // rename tokens file to instance specific
			sh "cp ./${deployParams.Host}/Gateway_Deployment/Tokens/${deployParams.GatewayType}_${deployParams.gatewayEnvironment} ./${deployParams.Host}/Gateway_Deployment/Tokens/${deployParams.Host}"
            
			//sh "cp ./${deployParams.Host}/Gateway_Deployment/${deployParams.Host}_* ./${deployParams.Host}/Gateway_Deployment/host_vars/"
            
            //Gateway Restarts
			// Copy host configutaion files to Ansible deployment script location
			//sh "cp -r ./${deployParams.Host}/Gateway_Configuration/${deployParams.GatewayType}/${deployParams.gatewayEnvironment}/* ./${deployParams.Host}/Gateway_Restarts/"
			sh "cp -r ./PROD_Conf/Gateway_Configuration/${deployParams.GatewayType}/${deployParams.gatewayEnvironment}/* ./${deployParams.Host}/Gateway_Restarts/"
			
			// copy host variables from configuration to ansible host vars folder
			sh "cp ./${deployParams.Host}/Gateway_Restarts/${deployParams.Host} ./${deployParams.Host}/Gateway_Restarts/host_vars/"
			// Generate host vars file for external apache
			sh "cp ./${deployParams.Host}/Gateway_Restarts/${deployParams.Host} ./${deployParams.Host}/Gateway_Restarts/host_vars/${deployParams.Host}_ExternalApache"
			// Generate host vars file for internal apache
			sh "cp ./${deployParams.Host}/Gateway_Restarts/${deployParams.Host} ./${deployParams.Host}/Gateway_Restarts/host_vars/${deployParams.Host}_InternalApache"
            // rename tokens file to instance specific
			sh "cp ./${deployParams.Host}/Gateway_Restarts/Tokens/${deployParams.GatewayType}_${deployParams.gatewayEnvironment} ./${deployParams.Host}/Gateway_Restarts/Tokens/${deployParams.Host}"
            
			//sh "cp ./${deployParams.Host}/Gateway_Restarts/${deployParams.Host}_* ./${deployParams.Host}/Gateway_Restarts/host_vars/"

    }
}

// Gateway Restart
def gateway_restart(deployParams) {
	script{
			//Run ansible playbook to restart gateway instances
			ansiColor('xterm') {
                    ansiblePlaybook(playbook: "./${deployParams.Host}/Gateway_Deployment/Ops_Restart.yml", colorized: true, extras:'-v', extraVars: [host: "${deployParams.Host}", externalApache: "${deployParams.externalApache}", internalApache: "${deployParams.internalApache}", gatewayRestart: "${deployParams.gatewayRestart}"])
            }
        }   
}

//Gateway Rollback
def rollback_artefact(deployParams) {
	script{
			//Run ansible playbook to rollback deployed changes
            ansiColor('xterm') {		
                    ansiblePlaybook(playbook: "./${deployParams.Host}/Gateway_Deployment/rollbackCert.yml", colorized: true, extras:'-v', extraVars: [host: "${deployParams.GatewayType}_${deployParams.Host}", datetime: "${deployParams.datetime}", crq_no: "${deployParams.crq_no}", externalApache: "${deployParams.externalApache}", internalApache: "${deployParams.internalApache}", deployType: "${deployParams.deployType}"])
	         }
	}
}

// Gateway Status
def gateway_status(deployParams) {
	script{
			//Run ansible playbook to get gateway status
			 ansiColor('xterm') {
    	    ansiblePlaybook(playbook: "./${deployParams.Host}/Gateway_Deployment/gatewayStatus.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Host}"])

		  }
    }
}

// Gateway Pid 
def gateway_pid(deployParams) {
	script{
			//Run ansible playbook to get gateway status
			ansiColor('xterm') {
                    ansiblePlaybook(playbook: "./${deployParams.Host}/Gateway_Deployment/gatewayPID.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Host}"])
            }
    }
}


return this
