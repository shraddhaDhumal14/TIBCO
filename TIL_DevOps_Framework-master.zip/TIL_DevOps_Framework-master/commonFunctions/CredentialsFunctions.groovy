/* -----------------------------------------------------------------------------------------------------------------------------------------
Description: This file holds all the common functions related to Credentials
Author: Ram Shankar
Date: 07/03/2022

Functions:
1. getJenkinsCredentials()

*/

/* -----------------------------------------------------------------------------------------------------------------------------------------
Description: This function is to get the username or the password from the Jenkins Credential Manager
Input: group, key. Ex group is the name of the credential ID stored in Credential manager. Key will be either useraname or password 
Output: string.
----------------------------------------------------------------------------------------------------------------------------------------- */

def getJenkinsCredentials(deployParams) {
	def USERNAME = ""
    def PASSWD = ""
    withCredentials([usernamePassword(credentialsId: "${deployParams.group}", usernameVariable: 'N_USER', passwordVariable: 'N_PASSWD')])
     {
            USERNAME = N_USER
            PASSWD = N_PASSWD
     }
     if("${deployParams.key}" == "username")
     {
           return USERNAME
     }
     else if ("${deployParams.key}" == "password")
     {
           return PASSWD
     }
     else
     {
            error("Invalid Key to get Credential.")
			currentBuild.result = 'ABORTED'
     }
}

//------------------------------------------------------------------------------------------------------------------------------------------
// Do not remove this.
return this;
//------------------------------------------------------------------------------------------------------------------------------------------

