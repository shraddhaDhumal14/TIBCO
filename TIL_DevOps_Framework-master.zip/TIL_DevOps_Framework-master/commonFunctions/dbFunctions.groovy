/* -----------------------------------------------------------------------------------------------------------------------------------------
Description: This file holds all the common functions related to Oracle DB.
Author: Anil Kolli
Date: 05/08/2020

Functions:
1. myGetDBConnect()
2. get_previous_version()
3. get_current_versions_from_db()
4. get_current_versions_from_db()
5. get_rollback_versions_from_db()
6. dbInsertOrUpdate()
7. get_db_row_id_to_map()
8. update_db_row_fields()
9. get_only_gv_engines()
10. get_only_file_engines()
11. get_only_restart_engines()
12. get_success_engines_from_release()



History:
05/08/2020 - Anil Kolli - Added initial functions as part of rollback pipeline.
06/08/2020 - Anil Kolli - Added dbInsertOrUpdate function to the library.
22/09/2020 - Anil Kolli - Added update_deployment_status_in_db function to the library.
22/09/2020 - Anil Kolli - Updated get_current_versions_from_db function to set the DeploymentID for the current version in the map.
09/10/2020 - Anil Kolli - Added get_db_row_id_to_map and update_db_row_fields functions as part of CICD-977
09/10/2020 - Anil Kolli - commented build failure update in functions.
04/02/2021 - Anil Kolli - Added functions to retrive only GV, Only File and Only Restart and only success engines for the given release and environments
----------------------------------------------------------------------------------------------------------------------------------------- */

import groovy.json.JsonOutput
import groovy.sql.*
import java.sql.Driver

/* -----------------------------------------------------------------------------------------------------------------------------------------
Description: This function is to connect to Oracle DB and return connection object.
Input: dbURL(jdbc:oracle:thin:@195.233.199.13:33000:TIBTST1), dbUserName(MAP_OWN_ICC15), dbPassword(MAP_OWN_ICC15), dbDriver(oracle.jdbc.driver.OracleDriver)
Output: Connection Object.
----------------------------------------------------------------------------------------------------------------------------------------- */

def myGetDBConnect(deployParams) {     
     def mySQL = groovy.sql.Sql.newInstance(deployParams.dbURL,deployParams.dbUserName,deployParams.dbPassword,deployParams.dbDriver)
     return mySQL
}


/* -----------------------------------------------------------------------------------------------------------------------------------------
Description: This function is to get the previous version for the given field type(BW, EMS, SQL).
Input: type: Ear_Version, EMS_Version, SQL_Version
	   eng_name: Engine Name
Output: Rollback version for the given engine and type.
----------------------------------------------------------------------------------------------------------------------------------------- */
def get_previous_version(deployParams) {
	def prevQuery = """SELECT \"${deployParams.type}\" FROM (SELECT \"${deployParams.type}\", ROWNUM AS RN FROM (SELECT * FROM CICD_DEPLOYMENT_HISTORY WHERE \"EngineName\"=\'${deployParams.eng_name}\' and \"Environment\"=\'${deployParams.Environment}\' and  \"${deployParams.type}\" != 'NA' and \"${deployParams.type}\" is not null and \"${deployParams.type}\" != \'1\' and \"${deployParams.type}\" != \'0\' and \"FailureReason\"=\'PASSED\' and \"DeploymentStatus\"=\'Active\' ORDER BY \"DeploymentId\" DESC)) WHERE RN = 2"""
	println("DEBUG: Query is: " + prevQuery)
    def mySQL =  myGetDBConnect dbURL: deployParams.dbURL, dbUserName: deployParams.dbUserName, dbPassword: deployParams.dbPassword, dbDriver: deployParams.dbDriver 
	def rowResults = ""
    try {
 		rowResults = mySQL.rows(prevQuery)
	}
    catch (Exception e){
        print("Exception Occured :")
        println(e)
    } 
    finally {
        mySQL.close()
    }
	if(rowResults) {
		def response = rowResults[0][deployParams.type]
		rowResults = null
		println("DEBUG: previous version response is: " + response)
		return response
	}
}

/* -----------------------------------------------------------------------------------------------------------------------------------------
Description: Function to get current versions of BW, SQL and EMS for all the engines and update Master map.
Input: ROLLBACK Master Map
Output: Updated with current BW, EMS and SQL Versions got from DB.
----------------------------------------------------------------------------------------------------------------------------------------- */

def get_current_versions_from_db(deployParams) {
	// For each of the engine get latest entry from the database.
	deployParams.map.keySet().each { engine ->
		def selQuery = """SELECT * FROM (SELECT * FROM CICD_DEPLOYMENT_HISTORY WHERE \"EngineName\"=\'${engine}\' and \"Environment\"=\'${deployParams.Environment}\' and \"DeploymentStatus\"=\'Active\' and \"FailureReason\"='PASSED' ORDER BY \"DeploymentId\" DESC) WHERE ROWNUM = 1"""
		def mySQL =  myGetDBConnect dbURL: deployParams.dbURL, dbUserName: deployParams.dbUserName, dbPassword: deployParams.dbPassword, dbDriver: deployParams.dbDriver 
		def rowResults = ""
		try {
			rowResults = mySQL.rows(selQuery)
		}
		catch (Exception e){
			print("Exception Occured :")
			println(e)
		} 
		finally {
			mySQL.close()
		}

		//Update Master map with versions.
		if(rowResults['BwVersion'][0]) {
			deployParams.map[engine]['BW_VERSION'] = rowResults['BwVersion'][0]
		}
		if(rowResults['EmsVersion'][0]) {
			deployParams.map[engine]['EMS_VERSION'] = rowResults['EmsVersion'][0]
		}
		if(rowResults['SqlVersion'][0]) {
			deployParams.map[engine]['SQL_VERSION'] = rowResults['SqlVersion'][0]
		}
		if(rowResults['XmlFiles'][0]) {
			deployParams.map[engine]['XML_FILES'] = rowResults['XmlFiles'][0]
		}
		if(rowResults['JarFiles'][0]) {
			deployParams.map[engine]['JAR_FILES'] = rowResults['JarFiles'][0]
		}
		if(rowResults['EmailFiles'][0]) {
			deployParams.map[engine]['EMAIL_FILES'] = rowResults['EmailFiles'][0]
		}
		if(rowResults['BWConfigTag'][0]) {
			deployParams.map[engine]['BWConfigTag'] = rowResults['BWConfigTag'][0]
		}
		if(rowResults['DeploymentId'][0]) {
			deployParams.map[engine]['DB_ROW_ID'] = rowResults['DeploymentId'][0]
		}		
		rowResults = null
	}
}
/* -----------------------------------------------------------------------------------------------------------------------------------------
Description: Function to get rollback versions of BW, SQL and EMS for all the engines and update Master map.
Input: ROLLBACK Master Map
Output: Updated with rollback BW, EMS and SQL Versions got from DB.
----------------------------------------------------------------------------------------------------------------------------------------- */

// Function to get previous versions for each of the engine for rollback and update master map.
def get_rollback_versions_from_db(deployParams) {
	deployParams.map.keySet().each { engine ->
		if(deployParams.map[engine]['BW_VERSION'] != "NA") {
			def bw_rb_version = get_previous_version eng_name: engine, Environment: deployParams.Environment, type: 'BwVersion', dbURL: deployParams.dbURL, dbUserName: deployParams.dbUserName, dbPassword: deployParams.dbPassword, dbDriver: deployParams.dbDriver
			if(bw_rb_version && bw_rb_version != deployParams.map[engine]['BW_VERSION']) {
				deployParams.map[engine]['BW_RB_VERSION'] = bw_rb_version
				deployParams.map[engine]['BW_Generation'] = "NOT_STARTED"
				deployParams.map[engine]['BW_Rollback'] = "NOT_STARTED"
			}
		}
		if(deployParams.map[engine]['EMS_VERSION'] != "NA") {
			def ems_rb_version = get_previous_version eng_name: engine, type: 'EmsVersion', Environment: deployParams.Environment, dbURL: deployParams.dbURL, dbUserName: deployParams.dbUserName, dbPassword: deployParams.dbPassword, dbDriver: deployParams.dbDriver 
			if(ems_rb_version && ems_rb_version != deployParams.map[engine]['EMS_VERSION']) {
				deployParams.map[engine]['EMS_RB_VERSION'] = ems_rb_version
				deployParams.map[engine]['EMS_Rollback'] = "NOT_STARTED"
			}
		}
		if(deployParams.map[engine]['SQL_VERSION'] != "NA") {
			def sql_rb_version = get_previous_version eng_name: engine, type: 'SqlVersion', Environment: deployParams.Environment, dbURL: deployParams.dbURL, dbUserName: deployParams.dbUserName, dbPassword: deployParams.dbPassword, dbDriver: deployParams.dbDriver 
			if(sql_rb_version && sql_rb_version != deployParams.map[engine]['SQL_VERSION']) {
				deployParams.map[engine]['SQL_RB_VERSION'] = sql_rb_version
				deployParams.map[engine]['SQL_Rollback'] = "NOT_STARTED"
			}
		}
		if(deployParams.map[engine]['XML_FILES'] != "NA") {
			def xml_rb_files = get_previous_version eng_name: engine, type: 'XmlFiles', Environment: deployParams.Environment, dbURL: deployParams.dbURL, dbUserName: deployParams.dbUserName, dbPassword: deployParams.dbPassword, dbDriver: deployParams.dbDriver 
			if(xml_rb_files) {
				deployParams.map[engine]['XML_RB_FILES'] = xml_rb_files
				deployParams.map[engine]['XML_Rollback'] = "NOT_STARTED"
			}
		}
		if(deployParams.map[engine]['JAR_FILES'] != "NA") {
			def jar_rb_files = get_previous_version eng_name: engine, type: 'JarFiles', Environment: deployParams.Environment, dbURL: deployParams.dbURL, dbUserName: deployParams.dbUserName, dbPassword: deployParams.dbPassword, dbDriver: deployParams.dbDriver 
			if(jar_rb_files) {
				deployParams.map[engine]['JAR_RB_FILES'] = jar_rb_files
				deployParams.map[engine]['JAR_Rollback'] = "NOT_STARTED"
			}
		}
		if(deployParams.map[engine]['EMAIL_FILES'] != "NA") {
			def email_rb_files = get_previous_version eng_name: engine, type: 'EmailFiles', Environment: deployParams.Environment, dbURL: deployParams.dbURL, dbUserName: deployParams.dbUserName, dbPassword: deployParams.dbPassword, dbDriver: deployParams.dbDriver 
			if(email_rb_files) {
				deployParams.map[engine]['EMAIL_RB_FILES'] = email_rb_files
				deployParams.map[engine]['EMAIL_Rollback'] = "NOT_STARTED"
			}
		}
		if(deployParams.map[engine]['BWConfigTag'] != "NA") {
			def bw_rb_tag = get_previous_version eng_name: engine, type: 'BWConfigTag', Environment: deployParams.Environment, dbURL: deployParams.dbURL, dbUserName: deployParams.dbUserName, dbPassword: deployParams.dbPassword, dbDriver: deployParams.dbDriver 
			if(bw_rb_tag) {
				deployParams.map[engine]['BWConfigTag_RB'] = bw_rb_tag
			}
		}		
	}
}

/* -----------------------------------------------------------------------------------------------------------------------------------------
Description: Function to insert or update a row to the database.
Input: DB details and insert or update query.
Output: Data inserted into the table.
----------------------------------------------------------------------------------------------------------------------------------------- */

def dbInsertOrUpdate(deployParams) {
	def mySQL =  myGetDBConnect dbURL: deployParams.dbURL, dbUserName: deployParams.dbUserName, dbPassword: deployParams.dbPassword, dbDriver: deployParams.dbDriver
	mySQL.connection.autoCommit = false  
	try {
		println("Executing Query :" + deployParams.insertQuery)
		int rowAffected = mySQL.executeUpdate(deployParams.insertQuery);
		mySQL.commit()
		println("Insert/Update " + rowAffected + " row(s)")
	}
	catch(Exception ex) {
		println("Error in Executing Query :" + deployParams.insertQuery) 
		mySQL.rollback()
		println("Transaction rollback")
		println("Exception caught : " + ex); 
	}
	finally {
		mySQL.close()
	}
} 

/* -----------------------------------------------------------------------------------------------------------------------------------------
Description: Function to update deployment status to given status for the record, once all the rollback succeeds.
Input: ROLLBACK Master Map, status
Output: None
----------------------------------------------------------------------------------------------------------------------------------------- */
def update_deployment_status_in_db(deployParams) {
	// For each of the engine update deployment status to Rollback if the result is PASSED.
	deployParams.map.keySet().each { engine ->
		if(deployParams.map[engine]['RESULT'] == "PASSED") {
			def row_id = deployParams.map[engine]['DB_ROW_ID']
			def updateQuery = """UPDATE CICD_DEPLOYMENT_HISTORY SET \"DeploymentStatus\"=\'${deployParams.status}\' WHERE \"DeploymentId\"=\'${row_id}\'"""
			println("DEBUG: update query is: " + updateQuery)
			def mySQL =  myGetDBConnect dbURL: deployParams.dbURL, dbUserName: deployParams.dbUserName, dbPassword: deployParams.dbPassword, dbDriver: deployParams.dbDriver 
			mySQL.connection.autoCommit = false  
			try {
				println("Executing Query :" + updateQuery)
				int rowAffected = mySQL.executeUpdate(updateQuery);
				mySQL.commit()
				println("Insert/Update " + rowAffected + " row(s)")
			}
			catch(Exception ex) {
				println("Error in Executing Query :" + updateQuery) 
				mySQL.rollback()
				println("Transaction rollback")
				println("Exception caught : " + ex); 
				//currentBuild.result = 'FAILURE'         
			}
			finally {
				println("Trying to close the connection")
				mySQL.close()
				println("SQL Connection closed")
			}
		}
	}
}

/* -----------------------------------------------------------------------------------------------------------------------------------------
Description: Function to update deployment status to given status for the record in release notes DB, once all the rollback succeeds.
Input: ROLLBACK Master Map, status
Output: None
----------------------------------------------------------------------------------------------------------------------------------------- */
def update_deployment_status_in_release_db(deployParams) {
	// For each of the engine update deployment status to Rollback if the result is PASSED.
	deployParams.map.keySet().each { engine ->
		if(deployParams.map[engine]['RESULT'] == "PASSED") {
			def bw_version = deployParams.map[engine]['BW_VERSION']
			def ems_version = deployParams.map[engine]['EMS_VERSION']
			def sql_version = deployParams.map[engine]['SQL_VERSION']
			
			def updateQuery = """UPDATE CICD_RELEASE_SUMMARY SET \"STATUS\"=\'${deployParams.status}\' WHERE \"ENGINE_NAME\"=\'${engine}\' and \"EAR_VERSION\"=\'${bw_version}\' and \"EMS_VERSION\"=\'${ems_version}\' and \"SQL_VERSION\"=\'${sql_version}\'"""
			println("DEBUG: update query is: " + updateQuery)
			def mySQL =  myGetDBConnect dbURL: deployParams.dbURL, dbUserName: deployParams.dbUserName, dbPassword: deployParams.dbPassword, dbDriver: deployParams.dbDriver 
			mySQL.connection.autoCommit = false  
			try {
				println("Executing Query :" + updateQuery)
				int rowAffected = mySQL.executeUpdate(updateQuery);
				mySQL.commit()
				println("Insert/Update " + rowAffected + " row(s)")
			}
			catch(Exception ex) {
				println("Error in Executing Query :" + updateQuery) 
				mySQL.rollback()
				println("Transaction rollback")
				println("Exception caught : " + ex);
				//currentBuild.result = 'FAILURE'
			}
			finally {
				println("Trying to close the connection")
				mySQL.close()
				println("SQL Connection closed")
			}
		}
	}
}
/* -----------------------------------------------------------------------------------------------------------------------------------------
Description: Function to fetch DeploymentID for the records selected by selQuery and update in map.
Input: Master Map, sqlQuery and DB parameters
Output: None
----------------------------------------------------------------------------------------------------------------------------------------- */

//[CICD-977] : Adding function to get the deployment id for the passed selected query and update in map passed.
def get_db_row_id_to_map(deployParams) {
		
		// Get Deployment ID for the passed query and assign that ID to map passed.
		def mySQL =  myGetDBConnect dbURL: deployParams.dbURL, dbUserName: deployParams.dbUserName, dbPassword: deployParams.dbPassword, dbDriver: deployParams.dbDriver 
		def rowResults = ""
		def depID = ""
		try {
			rowResults = mySQL.rows(deployParams.selQuery)
		}
		catch (Exception e){
			print("Exception Occured :")
			println(e)
		} 
		finally {
			mySQL.close()
		}

		//Update Master map with versions.
 		if(rowResults['DeploymentId'][0]) {
			deployParams.map[deployParams.engine]['DB_ROW_ID'] = rowResults['DeploymentId'][0]
		}
		rowResults = null
}

/* -----------------------------------------------------------------------------------------------------------------------------------------
Description: Function to update DB with given update query.
Input: updateQuery and DB parameters
Output: None
----------------------------------------------------------------------------------------------------------------------------------------- */
//[CICD-977]: Function added as part of this JIRA to execute update query.

def update_db_row_fields(deployParams) {
	// execute the passed update query on to the database
	def mySQL =  myGetDBConnect dbURL: deployParams.dbURL, dbUserName: deployParams.dbUserName, dbPassword: deployParams.dbPassword, dbDriver: deployParams.dbDriver 
	mySQL.connection.autoCommit = false  
	try {
		println("Executing Query :" + deployParams.updateQuery)
		int rowAffected = mySQL.executeUpdate(deployParams.updateQuery);
		mySQL.commit()
		println("Insert/Update " + rowAffected + " row(s)")
	}
	catch(Exception ex) {
		println("Error in Executing Query :" + deployParams.updateQuery) 
		mySQL.rollback()
		println("Transaction rollback")
		println("Exception caught : " + ex); 
	}
	finally {
		println("Trying to close the connection")
		mySQL.close()
		println("SQL Connection closed")
	}
}

/* -----------------------------------------------------------------------------------------------------------------------------------------
Description: This function is to get the only gv engines for the given release.
Input: release: Release number
Output: List of engines joined by ';' for which ONLY GV changes deployed for the given release.
----------------------------------------------------------------------------------------------------------------------------------------- */
def get_only_gv_engines(deployParams) {

	def getOnlyGVQuery = """SELECT \"EngineName\" FROM (SELECT * FROM CICD_DEPLOYMENT_HISTORY WHERE \"Release\"=\'${deployParams.RELEASE}\' and \"Environment\"=\'${deployParams.Environment}\' and \"BwVersion\"=\'0\' and \"ComponentType\"=\'BW\' and \"BwDeploymentType\"=\'OnlyGV\' and \"FailureReason\"=\'PASSED\' and \"DeploymentStatus\"=\'Active\') ORDER BY \"DeploymentId\" DESC"""

	println("DEBUG: Query is: " + getOnlyGVQuery)

    def mySQL =  myGetDBConnect dbURL: deployParams.dbURL, dbUserName: deployParams.dbUserName, dbPassword: deployParams.dbPassword, dbDriver: deployParams.dbDriver 
	def rowResults = ""
    try {
 		rowResults = mySQL.rows(getOnlyGVQuery)
	}
    catch (Exception e){
        print("Exception Occured :")
        println(e)
    } 
    finally {
        mySQL.close()
    }
	response = ""
	if(rowResults) {
		response = ""
		rowResults.each { engine ->
			response = response + engine['EngineName'] + ';'
		}
		response = response.substring(0, response.length() - 1)
		rowResults = null
	}
	return response
}


/* -----------------------------------------------------------------------------------------------------------------------------------------
Description: This function is to get the engine list for which only File chnages  deployed as part of given release.
Input: 	release: Release number
		environment: Environment Name
Output: List of engines joined by ';' for which ONLY GV changes deployed for the given release.
----------------------------------------------------------------------------------------------------------------------------------------- */
def get_only_file_engines(deployParams) {

	def getOnlyFileQuery = """SELECT \"EngineName\" FROM (SELECT * FROM CICD_DEPLOYMENT_HISTORY WHERE \"Release\"=\'${deployParams.RELEASE}\' and \"Environment\"=\'${deployParams.Environment}\' and \"BwVersion\"=\'1\' and \"ComponentType\"=\'BW\' and \"BwDeploymentType\"=\'RESTART\' and \"SqlVersion\"=\'NA\' and \"FailureReason\"=\'PASSED\' and \"DeploymentStatus\"=\'Active\') ORDER BY \"DeploymentId\" DESC"""

	println("DEBUG: Query is: " + getOnlyFileQuery)

    def mySQL =  myGetDBConnect dbURL: deployParams.dbURL, dbUserName: deployParams.dbUserName, dbPassword: deployParams.dbPassword, dbDriver: deployParams.dbDriver 
	def rowResults = ""
    try {
 		rowResults = mySQL.rows(getOnlyFileQuery)
	}
    catch (Exception e){
        print("Exception Occured :")
        println(e)
    } 
    finally {
        mySQL.close()
    }
	response = ""
	if(rowResults) {
		response = ""
		rowResults.each { engine ->
			response = response + engine['EngineName'] + ';'
		}
		response = response.substring(0, response.length() - 1)
		rowResults = null
	}
	return response
}

/* -----------------------------------------------------------------------------------------------------------------------------------------
Description: This function is to get the engine list which was given only for restart as part of common sql changes.
Input: 	release: Release number
		environment: Environment Name
Output: List of engines joined by ';' for all restart engines as part of common sql.
----------------------------------------------------------------------------------------------------------------------------------------- */
def get_only_restart_engines(deployParams) {

	def getOnlyRestartQuery = """SELECT \"EngineName\" FROM (SELECT * FROM CICD_DEPLOYMENT_HISTORY WHERE \"Release\"=\'${deployParams.RELEASE}\' and \"Environment\"=\'${deployParams.Environment}\' and \"BwVersion\"=\'1\' and \"ComponentType\"=\'BW\' and \"BwDeploymentType\"=\'RESTART\' and \"SqlVersion\"=\'NA\' and \"EmsVersion\"=\'NA\' and \"XmlFiles\"=\'NA\' and \"EmailFiles\"=\'NA\' and \"JarFiles\"=\'NA\' and \"FailureReason\"=\'PASSED\' and \"DeploymentStatus\"=\'Active\') ORDER BY \"DeploymentId\" DESC"""

	println("DEBUG: Query is: " + getOnlyRestartQuery)

    def mySQL =  myGetDBConnect dbURL: deployParams.dbURL, dbUserName: deployParams.dbUserName, dbPassword: deployParams.dbPassword, dbDriver: deployParams.dbDriver 
	def rowResults = ""
    try {
 		rowResults = mySQL.rows(getOnlyRestartQuery)
	}
    catch (Exception e){
        print("Exception Occured :")
        println(e)
    } 
    finally {
        mySQL.close()
    }
	response = ""
	if(rowResults) {
		response = ""
		rowResults.each { engine ->
			response = response + engine['EngineName'] + ';'
		}
		response = response.substring(0, response.length() - 1)
		rowResults = null
	}
	return response
}


/* -----------------------------------------------------------------------------------------------------------------------------------------
Description: This function return the list of engines for which deployment got passed in the given release.
Input: 	release: Release number
		environment: Environment Name
Output: List of successfully deployed engines joined by ';'
----------------------------------------------------------------------------------------------------------------------------------------- */
def get_success_engines_from_release(deployParams) {

	def getPassedEngines = """SELECT \"EngineName\" FROM (SELECT * FROM CICD_DEPLOYMENT_HISTORY WHERE \"Release\"=\'${deployParams.RELEASE}\' and \"Environment\"=\'${deployParams.Environment}\' and \"ComponentType\"=\'BW\' and \"FailureReason\"=\'PASSED\' and \"DeploymentStatus\"=\'Active\') ORDER BY \"DeploymentId\" DESC"""

	println("DEBUG: Query is: " + getPassedEngines)

    def mySQL =  myGetDBConnect dbURL: deployParams.dbURL, dbUserName: deployParams.dbUserName, dbPassword: deployParams.dbPassword, dbDriver: deployParams.dbDriver 
	def rowResults = ""
    try {
 		rowResults = mySQL.rows(getPassedEngines)
	}
    catch (Exception e){
        print("Exception Occured :")
        println(e)
    } 
    finally {
        mySQL.close()
    }
	response = ""
	if(rowResults) {
		response = ""
		rowResults.each { engine ->
			response = response + engine['EngineName'] + ';'
		}
		response = response.substring(0, response.length() - 1)
		rowResults = null
	}
	return response
}






//------------------------------------------------------------------------------------------------------------------------------------------
// Do not remove this.
return this;
//------------------------------------------------------------------------------------------------------------------------------------------

