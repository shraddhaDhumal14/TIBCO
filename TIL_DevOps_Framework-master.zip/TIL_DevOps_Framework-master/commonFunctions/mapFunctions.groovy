/******************************************************************************************************************** 
Author: Anil Kolli
Date: 13/04/2020
/******************************************************************************************************************** 
This file holds functions related to Groovy maps like creating, updating and displaying. 

1. generate_map()
2. init_results_map
3. convert_map_to_string()
4. init_versions_map()
5. validate_map_from_facts()
6. display_master_map()

/******************************************************************************************************************** 

/******************************************************************************************************************** 
THis function is used to generate map from the given string format with eng1:ver1;eng2:ver2
Input: 
inputString: "eng1:ver1;eng2:ver2;eng3:ver3"
map: Map name for the geenarted map. 
*********************************************************************************************************************/

def generate_map(deployParams) {
	deployParams.inputString.split(';').each {param ->
	def engine_and_ver = param.split(":")

	if (engine_and_ver.length == 1){
		println ("DEBUG: map with no version")
		deployParams.map[engine_and_ver[0]] = 0
	}
	else{
		deployParams.map[engine_and_ver[0]] = engine_and_ver[1]
	}
  }		
}

/********************************************************************************************************************
This function is used to initialize the Results map.
Input:
type: type of Deployment with options as "BW, SQL, EMS, XML, JAR, EMAIL"
map: map name
engines: engine names joined as a string with ; as separator. 
*********************************************************************************************************************/
 


def init_results_map(deployParams) {
	def type = deployParams.type
	deployParams.engines.split(';').each { param ->
		if(type == "BW"){
			deployParams.map[param]['BW_Generation'] = 'NOT_STARTED'
			deployParams.map[param]['BW_Deployment'] = 'NOT_STARTED'
		}
		if(type == "SQL"){
			deployParams.map[param]['SQL_Deployment'] = 'NOT_STARTED'
		}		
		if(type == "EMS"){
			deployParams.map[param]['EMS_Deployment'] = 'NOT_STARTED'
		}
		if(type == "XML"){
			deployParams.map[param]['XML_Deployment'] = 'NOT_STARTED'
		}
		if(type == "JAR"){
			deployParams.map[param]['JAR_Deployment'] = 'NOT_STARTED'
		}		
		if(type == "EMAIL"){
			deployParams.map[param]['EMAIL_Deployment'] = 'NOT_STARTED'
		}
	}
}

/********************************************************************************************************************
This function converts map to string format.
Input: Map
Output: String 

*********************************************************************************************************************/

def convert_map_to_string(deployParams) {
	def map_str=""
	deployParams.engine_map.each { engine, version ->
		map_str = map_str + engine + ':' + version + ';'
	};
    if (map_str == "")
        return ""
    else 
        return map_str.substring(0, map_str.length() - 1);
}

/********************************************************************************************************************
This function initializes versions for  the map properties.
Input:
type: Type of the property , like, BW, SQL, EMS, BW_FOLDER, BW_TYPE
input_map: List of input map names in format [map1, map2, map3]
map: This is the Master map(which is map of maps) like, 
Eg: Billing-Equiniti:[BW_Generation:NOT_STARTED, SQL_Deployment:NOT_REQUIRED, EMS_Deployment:NOT_REQUIRED, XML_Deployment:NOT_REQUIRED, JAR_Deployment:NOT_REQUIRED, EMAIL_Deployment:NOT_REQUIRED, BW_Deployment:NOT_STARTED, BW_Restart:NOT_STARTED]

*********************************************************************************************************************/
def init_versions_map(deployParams) {
	def type = deployParams.type
	deployParams.input_map.each { engine, version ->
		if(type == "BW"){
			deployParams.map[engine]['BW_VERSION'] = version
		}
		if(type == "SQL"){
			deployParams.map[engine]['SQL_VERSION'] = version
		}		
		if(type == "EMS"){
			deployParams.map[engine]['EMS_VERSION'] = version
		}
		if(type == "BW_FOLDER"){
			deployParams.map[engine]['BW_FOLDER_NAME'] = version
		}
		if(type == "BW_TYPE"){
			deployParams.map[engine]['BW_ENGINE_TYPE'] = version
		}
		if(type == "XML_FILES"){
			deployParams.map[engine]['XML_FILES'] = version
		}
		if(type == "JAR_FILES"){
			deployParams.map[engine]['JAR_FILES'] = version
		}
		if(type == "EMAIL_FILES"){
			deployParams.map[engine]['EMAIL_FILES'] = version
		}		
	}
}

/*********************************************************************************************************************
This function compares versions from facts file.
If version picked up from Nexus is less than the one present in facts file, it means, later version deployed to env.
So, no need to pick this engine for deployment.

*********************************************************************************************************************/


def validate_map_from_facts(deployParams) {
	// Function to validate versions generated from NEXUS against facts file. 
	// If version in facts file is greater , then remove engine from upliftment.
	
	// First generate versions file from facts file for the type of deployment passed.
	ansiColor('xterm') {
		ansiblePlaybook(playbook: "./automation/Utils/getReleaseFacts/get_release_facts.yml", colorized: true, extras:'-v', extraVars: [host: "localhost", repo_artifact_ids: "${deployParams.map.keySet().join(';')}", release: "${deployParams.release}", Environment: "${deployParams.target_env}", type: "${deployParams.type}"])
	}
	def facts_file = new File("${WORKSPACE}/automation/Utils/getReleaseFacts/${deployParams.type}_engine_versions.txt").readLines()
	def remove_engines = ""
	if(fileExists("${WORKSPACE}/automation/Utils/getReleaseFacts/${deployParams.type}_engine_versions.txt")) {
		deployParams.map.each { engine, version ->
			def fact_version = facts_file.findAll { it.contains("${engine}:") }
			//println(engine + ':' + version + ':' + fact_version)
			if(fact_version) {
				if(version.split('_')[-1].toInteger() <= fact_version[-1].split(':')[1].split('_')[-1].toInteger()) {
					// Facts version is greater compared to NEXUS version. So no upliftment is needed.
					println("removing engine" + engine)
					remove_engines = remove_engines + engine + ';'
				}
			}
		}
	}
	// Remove engines from map , as upliftment is already done for these engines.
	remove_engines.split(';').each { param ->
		deployParams.map.remove(param)
	}
}


/*********************************************************************************************************************
This function prints the map.
*********************************************************************************************************************/



/* Function to display the map.
Input: map */

def display_master_map(deployParams) {
	def line = ""
	deployParams.map.each { engine, version ->
		line = line + engine + '->'
		version.each { key, value -> 
			line = line + key + ':' + value + ','
		}
		line = line + '\n'
	}
	println(line)
}


/* Function to remove engine from map.
Input1: engine_maps- list of all component maps
Input2: engine_list - list of engines to be removed  */
def remove_engines_from_maps(deployParams) {
	// removes engines from the map.
	//input: engine_map and engines_list
	//echo "DEBUG: in remove_engines_from_maps"
	deployParams.engine_maps.each {engine_map ->
		deployParams.engines_list.split(';').each {eng ->
			//println("DEBUG: removing ${eng} from ${engine_map}")
			engine_map.remove(eng)
		}
	}
}

def update_master_map(deployParams) {
	// This function is to update values for the master map for given stage.
	//update_master_map map: Master_Map, engines: "${BW_Engine_map.keySet().join(';')}", stage: "", status:""
	deployParams.engines.split(';').each { param ->
		deployParams.map[param][deployParams.stage] = deployParams.status
	}
}

/* Function added failed engines to rollback map.
Input1: engine_list 
Input2: engine_snap
Input3: rollback_map  */

def update_rollback_maps(deployParams) {
	deployParams.engines_list.split(';').each {eng ->
		if(deployParams.engine_snap.containsKey(eng)) {
			add_engine_to_map engine_map: deployParams.rollback_map, eng: eng, ver: deployParams.engine_snap[eng]
		}
	}
}

def update_version_map_result(deployParams) {
	// This function is to update values for the master map for given stage.
	//update_version_map_result map: VERSIONS_MAP, engines: "${BW_Engine_map.keySet().join(';')}", stage:"", status:""
	deployParams.engines.split(';').each { param ->
		if(deployParams.map.containsKey(param)){
		//echo "DEBUG: Updating result for ${param} for the stage ${deployParams.stage} and status ${deployParams.status}"
			if(deployParams.status == "FAILED"){
				deployParams.map[param]['RESULT'] = "FAILED"
				deployParams.map[param][deployParams.stage] = "FAILED"
			} else if(deployParams.status == "PASSED"){
				deployParams.map[param][deployParams.stage] = "PASSED"
			}
		}
	}
}


return this
