/*********************************************************************************************************************
Author: Srishty Sinha
Date: 25/07/2022
/*********************************************************************************************************************
This file holds all the functions related to static email updates.
Below are the functions listed in this file.
*********************************************************************************************************************/
import com.cwctravel.hudson.plugins.extended_choice_parameter.ExtendedChoiceParameterDefinition;
import hudson.tasks.Mailer;
import hudson.model.User;


@NonCPS
def getUserEmail(String id=null) {
    User user = User.getById(id ?: currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId(), false)
    user?.getProperty(Mailer.UserProperty.class).getAddress()
}

def getBuildUserID(){
    return currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId()
}

def getBuildUserName(){
    return currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserName()
}

def get_approvers_list(String approver_group){
	approvers_list = sh (script: """cat /opt/tibco/.jenkins/config.xml | sed -n \'/role name=\"${approver_group}\"/,\$p\' | sed \'/role>/q\' | grep "sid" | cut -d \'>\' -f 2 | cut -d \'<\' -f 1 | paste -s -d, -""", returnStdout: true).trim()
    return """${approvers_list}"""           
}

def get_approvers_email_list(String approvers_list){
   approvers_email=""
	approvers_list.split(',').each { user ->
            if(approvers_email.length() != 0)
              {
                    approvers_email += ","
              }
              approvers_email += getUserEmail(user)  
        }
    return """${approvers_email}"""   
}
/************************************************************************************************************/
/* Please do not delete this below line. This is required to include this to any main pipeline */
return this
/************************************************************************************************************/
