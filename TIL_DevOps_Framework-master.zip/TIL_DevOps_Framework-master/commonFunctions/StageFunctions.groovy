
/*********************************************************************************************************************
Author: Anil Kolli & Raghuram Koripalli
Date: 13/04/2020
/*********************************************************************************************************************
This file holds all the functions related to BW generate and deployment.
Below are the functions listed in thsi file.


*********************************************************************************************************************/

/* Function to update app conf with append and prepend paths for existing engine deployment app conf
appConfTemplate_path - template file path from workspace
appConf_path - engine appconf file path
engine - Engine Name
*/
def add_append_prepend_from_template(deployParams) {
	
	// First get values from template file for the engine passed.
	def lines = new File("${deployParams.appConfTemplate_path}").readLines()
	// Append path verification
	def matched_engine = lines.findAll { it.contains("Append|${deployParams.engine}|") }[0]
	if(matched_engine && !matched_engine.empty) {
		def appconf_file = "${deployParams.appConf_path}/${deployParams.engine}.appconf"
		// updating values from template.
		//appconf_file = appconf_file.append("${deployParams.common_engine}.par.appendClasspath=" + matched_engine.split("\\|")[2] + "\n")
		writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.appendClasspath=", "par.appendClasspath=" + matched_engine.split("\\|")[2])
	}
	else {
		println("DEBUG: Append Classpath  for engine ${deployParams.engine} not found in template file.")
	}
	// Prepend path verification
	def matched_engine_prepend = lines.findAll { it.contains("Prepend|${deployParams.engine}|") }[0]
	if(matched_engine_prepend && !matched_engine_prepend.empty) {
		def appconf_file = "${deployParams.appConf_path}/${deployParams.engine}.appconf"
		// updating values from template.
		//appconf_file = appconf_file.append("${deployParams.common_engine}.par.prependClasspath=" + matched_engine_prepend.split("\\|")[2].toString() + "\n")
		writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.prependClasspath=", "par.prependClasspath=" + matched_engine_prepend.split("\\|")[2])
	}
	else {
		println("DEBUG: Prepend Classpath  for engine ${deployParams.engine} not found in template file.")
	}				
}	

/* Function to generate app conf for existing engines 
Input : Engine list , Hosts, ReleaseNumber, FolderName, Description,
*/										
def generate_conf_files_existing_engines(deployParams) {
	// checkout Release templates repository
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Release_Repo"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_TestEnv_Configurations.git']]]
    
	// checkout Application configuration repository
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}_Conf"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_BW_Application_Configuration.git']]]
    // make a directory with conf
	sh "mkdir -p ./${deployParams.Host}_Conf/conf"
    echo "${deployParams.engines}"
	echo "${deployParams.folderName}"
	echo "${deployParams.description}"
	//echo "${deployParams.instances}"
    def engine_list = deployParams.engines.split(';')
	for (txt in engine_list) {
			echo "${txt}"
			def engine = txt.split(':')
			def eng_conf = engine[0]
			def eng_ver = engine[1]
			echo eng_conf
			// create directory if does not exist
			sh "mkdir -p ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}"
			sh "curl -o ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf  http://195.233.197.150:8081/repository/LINKTEST_REPO/TIL_BW/${eng_conf}/${eng_ver}/${eng_conf}-${eng_ver}.appconf"
			// Updating folder name in app.conf
			if(deployParams.folderName == "None"){
				println("Folder Name is None , no update is required")
			}
            else{
			 sh  "sed -i '/FolderName=/ s/=.*/=${deployParams.folderName}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
			}	
			// update values of app.conf with inputs provided during deployment
			// update description field
			sh  "sed -i '/description=/ s/=.*/=${deployParams.description}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
			// update release field
			sh  "sed -i '/releaseName=/ s/=.*/=${deployParams.ReleaseNumber}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
			//identifying engine name
			def common_eng_name = sh(script:"cat ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf | grep 'appendClasspath' | awk -F '.par' '{print \$1}'" ,returnStdout: true).trim()
            echo  "common_eng_name : $common_eng_name"
			// removing instance count parameter
            sh  "sed -i '/.*.par.instanceCount*/d' ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
			//Updating app conf params based on details from engines list
			
			def lines = new File("${WORKSPACE}/Release_Repo/BW_Configuration/${deployParams.Host}/Engines_Template.txt").readLines()
			def matched_engine = lines.findAll { it.contains("${eng_conf}|") }[0]
	        if(matched_engine && !matched_engine.empty) {
				//Reading app.conf file download from Nexus
				def appconf_file = "${WORKSPACE}/${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
				// Start updating values from template.
				if(matched_engine.split("\\|")[1] != null) {
					//newConfig = newConfig.replace("par.MaxHeapSize=", "par.MaxHeapSize=" + matched_engine.split("\\|")[1].toString())
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.MaxHeapSize=", "par.MaxHeapSize=" + matched_engine.split("\\|")[1].toString())
				}
				if(matched_engine.split("\\|")[2] != null) {
					//newConfig = newConfig.replace("par.LogfileCount=", "par.LogfileCount=" + matched_engine.split("\\|")[2].toString())
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.LogfileCount=", "par.LogfileCount=" + matched_engine.split("\\|")[2].toString())
				}
				if(matched_engine.split("\\|")[3] != null) {
					//newConfig = newConfig.replace("par.LogfileSize=", "par.LogfileSize=" + matched_engine.split("\\|")[3].toString())
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.LogfileSize=", "par.LogfileSize=" + matched_engine.split("\\|")[3].toString())
				}
				if(matched_engine.split("\\|")[4] != null) {
					//newConfig = newConfig.replace("par.threadCount=", "par.threadCount=" + matched_engine.split("\\|")[4].toString())
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.threadCount=", "par.threadCount=" + matched_engine.split("\\|")[4].toString())
				}		
				if(matched_engine.split("\\|")[5] != null) {
					//newConfig = newConfig.replace("par.initHeapSize=", "par.initHeapSize=" + matched_engine.split("\\|")[5].toString())
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.initHeapSize=", "par.initHeapSize=" + matched_engine.split("\\|")[5].toString())
				}
				if(matched_engine.split("\\|")[6] != null) {
					//newConfig = newConfig.replace("par.threadStackSize=", "par.threadStackSize=" + matched_engine.split("\\|")[6].toString())
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.threadStackSize=", "par.threadStackSize=" + matched_engine.split("\\|")[6].toString())
				}
				if(matched_engine.split("\\|")[7] == "true") {
					//newConfig = newConfig.replace("par.isFT=false", "par.isFT=" + matched_engine.split("\\|")[7].toString())
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.isFT=false", "par.isFT=" + matched_engine.split("\\|")[7].toString())
				}
				if(matched_engine.split("\\|")[8] != null) {
					//newConfig = newConfig.replace("par.FTWeight=", "par.FTWeight=" + matched_engine.split("\\|")[8].toString())
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.FTWeight=", "par.FTWeight=" + matched_engine.split("\\|")[8].toString())
				}
				if(matched_engine.split("\\|")[9] != null) {
					//newConfig = newConfig.replace("par.FTHeartbeatInterval=", "par.FTHeartbeatInterval=" + matched_engine.split("\\|")[9].toString())
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.FTHeartbeatInterval=", "par.FTHeartbeatInterval=" + matched_engine.split("\\|")[9].toString())
				}
				if(matched_engine.split("\\|")[10] != null) {
					//newConfig = newConfig.replace("par.FTActivationInterval=", "par.threadCount=" + matched_engine.split("\\|")[10].toString())
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.FTActivationInterval=", "par.threadCount=" + matched_engine.split("\\|")[10].toString())
				}
				if(matched_engine.split("\\|")[11] != null) {
					//newConfig = newConfig.replace("par.FTPreperationDelay=", "par.FTPreperationDelay=" + matched_engine.split("\\|")[11].toString())
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.FTPreperationDelay=", "par.FTPreperationDelay=" + matched_engine.split("\\|")[11].toString())
				}
				
				// Write back to the original appconf file.
				 //appconf_file.text = newConfig
				if(matched_engine.split("\\|")[13] == "true") {
					echo "checkpoint true condition"
					appconf_file = appconf_file.append("${common_eng_name}.par.CheckPointSelected=" + matched_engine.split("\\|")[14].toString())
				}
				
			}
            else{
				println("DEBUG: engine ${eng_conf} not found in new engines template file.")
				
            }
            
			// calling append and prepend function
			add_append_prepend_from_template appConfTemplate_path:"${WORKSPACE}/ENV/BW_Configuration/${deployParams.Host}/AppendPrependConfiguration.conf", appConf_path:"${WORKSPACE}/${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}", engine:"${eng_conf}", common_engine:"${common_eng_name}"
			// copy engine config files to single location for deployment job
			sh "cp ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/* ./${deployParams.Host}_Conf/conf"
			sh "cp ./${deployParams.Host}_Conf/BW_Configurations/${eng_conf}/* ./${deployParams.Host}_Conf/conf"
		  }
}

/* Function to update app conf with append and prepend paths for new engine deployment app conf
appConfTemplate_path - template file path from workspace
appConf_path - engine appconf file path
engine - Engine Name
*/
def update_append_prepend_from_template(deployParams) {
	
	// First get values from template file for the engine passed.
	def lines = new File("${deployParams.appConfTemplate_path}").readLines()
	// Append path verification
	def matched_engine = lines.findAll { it.contains("Append|${deployParams.engine}|") }[0]
	if(matched_engine && !matched_engine.empty) {
		def appconf_file = "${deployParams.appConf_path}/${deployParams.engine}.appconf"
		writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.appendClasspath=", "par.appendClasspath=" + matched_engine.split("\\|")[2].toString())
	}
	else {
		println("DEBUG: Append Classpath  for engine ${deployParams.engine} not found in template file.")
	}
	// Prepend path verification
	def matched_engine_prepend = lines.findAll { it.contains("Prepend|${deployParams.engine}|") }[0]
	if(matched_engine_prepend && !matched_engine_prepend.empty) {
		def appconf_file = "${deployParams.appConf_path}/${deployParams.engine}.appconf"
		writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.prependClasspath=", "par.prependClasspath=" + matched_engine_prepend.split("\\|")[2].toString())
	}
	else {
		println("DEBUG: Prepend Classpath  for engine ${deployParams.engine} not found in template file.")
	}				
}


/* Function to generate conf for new engines 
Input : 
Enginelist - List of engines , 
Environmet - Deployment environment
Host - Target Host ideally environment
ReleaseNumber - Release Number
Templetefilepath - New Engines app conf template path
Description - Descrition used in admin console
*/										
def generate_conf_files_new_engines(deployParams) {
	// checkout Release templates repository
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Release_Repo"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_TestEnv_Configurations.git']]]
    
	// checkout Application configuration repository
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}_Conf"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_BW_Application_Configuration.git']]]
    
	// make a directory with conf
	sh "mkdir -p ./${deployParams.Host}_Conf/conf"
   
	//echo "${deployParams.instances}"
    def engine_list = deployParams.engines.split(';')
	for (txt in engine_list) {
			echo "${txt}"
			def checkpoint
			def engine = txt.split(':')
			def eng_conf = engine[0]
			def eng_ver = engine[1]
			echo eng_conf
			// create directory if does not exist
			sh "mkdir -p ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}"
			sh "curl -o ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf  http://195.233.197.150:8081/repository/LINKTEST_REPO/TIL_BW/${eng_conf}/${eng_ver}/${eng_conf}-${eng_ver}.appconf"
			
			// identify par name for common engines which have differnt par name 
            //Remove par parameters
			def common_eng_name = sh(script:"cat ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf | grep 'appendClasspath' | awk -F '.par' '{print \$1}'" ,returnStdout: true).trim()
            echo  "common_eng_name : $common_eng_name"
			// First get values from template file for the engine passed.
	        def lines = new File("${WORKSPACE}/Release_Repo/BW_Configuration/${deployParams.Host}/Engines_Template.txt").readLines()
			def matched_engine = lines.findAll { it.contains("${eng_conf}|") }[0]
	        if(matched_engine && !matched_engine.empty) {
				//Reading app.conf file download from Nexus
				def appconf_file = "${WORKSPACE}/${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
				// Start updating values from template.
				if(matched_engine.split("\\|")[1] != null) {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.MaxHeapSize=", "par.MaxHeapSize=" + matched_engine.split("\\|")[1].toString()) 
                 }
				if(matched_engine.split("\\|")[2] != null) {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.LogfileCount=", "par.LogfileCount=" + matched_engine.split("\\|")[2].toString()) 
				}
				if(matched_engine.split("\\|")[3] != null) {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.LogfileSize=", "par.LogfileSize=" + matched_engine.split("\\|")[3].toString()) 
				}
				if(matched_engine.split("\\|")[4] != null) {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.threadCount=", "par.threadCount=" + matched_engine.split("\\|")[4].toString()) 
				}		
				if(matched_engine.split("\\|")[5] != null) {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.initHeapSize=", "par.initHeapSize=" + matched_engine.split("\\|")[5].toString()) 
				}
				if(matched_engine.split("\\|")[6] != null) {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.threadStackSize=", "par.threadStackSize=" + matched_engine.split("\\|")[6].toString()) 
				}
				if(matched_engine.split("\\|")[7] == "true") {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.isFT=false", "par.isFT=" + matched_engine.split("\\|")[7].toString()) 
				}
				if(matched_engine.split("\\|")[8] != null) {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.FTWeight=", "par.FTWeight=" + matched_engine.split("\\|")[8].toString())
				}
				if(matched_engine.split("\\|")[9] != null) {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.FTHeartbeatInterval=", "par.FTHeartbeatInterval=" + matched_engine.split("\\|")[9].toString())
				}
				if(matched_engine.split("\\|")[10] != null) {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.FTActivationInterval=", "par.threadCount=" + matched_engine.split("\\|")[10].toString())
				}
				if(matched_engine.split("\\|")[11] != null) {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.FTPreperationDelay=", "par.FTPreperationDelay=" + matched_engine.split("\\|")[11].toString())
				}
				if(matched_engine.split("\\|")[12] != null) {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.instanceCount=4", "par.instanceCount=" + matched_engine.split("\\|")[12].toString())
				}
				
				if(matched_engine.split("\\|")[13] == "true") {
					echo "checkpoint true condition"
					appconf_file = appconf_file.append("${common_eng_name}.par.CheckPointSelected=" + matched_engine.split("\\|")[14].toString())
					
				}

			}
            else{
				println("DEBUG: engine ${eng_conf} not found in new engines template file.")
				//Reading app.conf file download from Nexus
				def appconf_file = "${WORKSPACE}/${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
				
				echo "instance count from script ${deployParams.instanceCount}"
				writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.instanceCount=4", "par.instanceCount=" + deployParams.instanceCount) 
				sh "cat ${appconf_file}"
            }
             			
			// update Folder Name in app.conf with inputs provided during deployment
			if(deployParams.folderName == "None"){
				println("Folder Name is None , no update is required")
			}
            else{
			   sh  "sed -i '/FolderName=/ s/=.*/=${deployParams.folderName}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"	
            }				
			// update description field
			sh  "sed -i '/description=/ s/=.*/=${deployParams.description}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
			// update release field
			sh  "sed -i '/releaseName=/ s/=.*/=${deployParams.ReleaseNumber}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"				
			// calling update append and prepend function
			update_append_prepend_from_template appConfTemplate_path:"${WORKSPACE}/ENV/BW_Configuration/${deployParams.Host}/AppendPrependConfiguration.conf", appConf_path:"${WORKSPACE}/${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}", engine:"${eng_conf}"
			// copy engine config files to single location for deployment job
			sh "cp ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/* ./${deployParams.Host}_Conf/conf"
			sh "cp ./${deployParams.Host}_Conf/BW_Configurations/${eng_conf}/* ./${deployParams.Host}_Conf/conf"
		  }
}



// Generate app.conf files required for BW GV change deployment
/* Function to generate conf for only GV changes 
Input : 
Enginelist - List of engines , 
Host - Target Host ideally environment
ReleaseNumber - Release Number
Description - Descrition used in admin console
*/

def generate_conf_files_gv_change(deployParams) {
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}_Conf"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_BW_Application_Configuration.git']]]
    // make a directory with conf
	sh "mkdir -p ./${deployParams.Host}_Conf/conf"
    echo "${deployParams.engines}"
    def engine_list = deployParams.engines.split(';')
	for (txt in engine_list) {
		echo "${txt}"
		echo "before split"
		def engine = txt.split(':')
		def eng_conf = engine[0]

		echo eng_conf
		echo "after split"
		// create directory if does not exist
		sh "mkdir -p ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}"
		// Rename common gvchange app conf template to engine specific
		sh "cp ./${deployParams.Host}_Conf/GVChange_Configurations/GVChange.appconf ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
		
		// update Folder Name in app.conf with inputs provided during deployment
		if(deployParams.folderName == "None"){
			println("Folder Name is None , no update is required")
		}
		else{
		   sh  "sed -i '/FolderName=/ s/=.*/=${deployParams.folderName}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"	
		}
		// update cvsVersion field
		//sh  "sed -i '/CVSVersion=/ s/=.*/=${deployParams.cvsVersion}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
		
		// update release field
		sh  "sed -i '/releaseName=/ s/=.*/=${deployParams.ReleaseNumber}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
		
		// update description field
		sh  "sed -i '/description=/ s/=.*/=${deployParams.description}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
		//sh  "sed -i '/${eng_conf}.par.instanceCount=/ s/=.*/=${deployParams.instances}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
		// copy engine config files to single location for deployment job
		sh "cp ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/* ./${deployParams.Host}_Conf/conf"
		sh "cp -r ./${deployParams.Host}_Conf/BW_Configurations/${eng_conf}/* ./${deployParams.Host}_Conf/conf"	
	  }
}


/*BW Generate Function 
Input : 
Host
nexus_group_id
nexus_user
nexus_passwd
nexus_repo_id
nexus_url
engines
datetime
crq_no
engines_list
release
onlyGVChange
EnvPrefix
deployment_type
*/

def generate_bw_deployment(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{
		checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
		// create directory with name conf to copy config files
		sh "mkdir -p ./${deployParams.Host}/BW_Deployment/conf"
		sh "cp -r ./${deployParams.Host}_Conf/conf/* ./${deployParams.Host}/BW_Deployment/conf"
        sh "mkdir -p ./${deployParams.Host}/BW_Deployment/host_vars/${deployParams.Host}_BW"
		// Copy Environment specififc files to Ansible Host Vars 
		sh "cp -r ./ENV/BW_Configuration/${deployParams.Host}/* ./${deployParams.Host}/BW_Deployment/host_vars/${deployParams.Host}_BW"
		// Copy Manual Changes conf file from host vars to script folder
		sh "mv ./${deployParams.Host}/BW_Deployment/host_vars/${deployParams.Host}_BW/ManualChangesConfiguration.conf ./${deployParams.Host}/BW_Deployment/scripts/PostDeploymentChanges"
		echo "Engines in Deploy function : ${deployParams.engines}"
		//Run ansible playbook to generate artefacts for environment
		 ansiColor('xterm') {
		 ansiblePlaybook(playbook: "./${deployParams.Host}/BW_Deployment/generate.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Host}_BW", repo_group_id: "${deployParams.nexus_group_id}", repo_user: "${deployParams.nexus_user}", repo_pw: "${deployParams.nexus_passwd}", repo_repo_id: "${deployParams.nexus_repo_id}", repo_url: "${deployParams.nexus_url}", engines: "${deployParams.engines}", datetime: "${deployParams.datetime}", crq_num: "${deployParams.crq_no}", engines_list: "${deployParams.engines_list}", release: "${deployParams.release}", onlyGVChange: "${deployParams.onlyGVChange}", EnvPrefix: "${deployParams.EnvPrefix}", deployment_type: "${deployParams.deployment_type}", folderName: "${deployParams.folderName}", bw_folder_release: "${deployParams.bw_folder_release}", engine_group:"${deployParams.engine_group}"])

		}
		// Remove files generated in this iteration
		sh "rm -rf ./${deployParams.Host}_Conf/conf/*"
		sh "rm -rf ./${deployParams.Host}/BW_Deployment/conf/*"
		
    }
}


/*BW Deploy Function 
Input : 
Host
engines
datetime
crq_no
engines_list
release
onlyGVChange
appDynamics
FolderName
deployment_type
*/

def bw_deploy(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{
      //Run ansible playbook to generate artefacts for environment
	   ansiColor('xterm') {
		 ansiblePlaybook(playbook: "./${deployParams.Host}/BW_Deployment/deploy.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Host}_BW", engines: "${deployParams.engines}", datetime: "${deployParams.datetime}", crq_num: "${deployParams.crq_no}", engines_list: "${deployParams.engines_list}", release: "${deployParams.release}", onlyGVChange: "${deployParams.onlyGVChange}", appDynamics: "${deployParams.appDynamics}", FolderName: "${deployParams.FolderName}", deployment_type: "${deployParams.deployment_type}", bw_folder_release: "${deployParams.bw_folder_release}", engine_group: "${deployParams.engine_group}", EnvironmentRepository: "${deployParams.EnvironmentRepository}"])

		}
    }
}

/*Function to remove configs based on other component deployments 
Input : 
Host
engines_list : list of engines separated by ;
datetime
crq_no

*/

def bw_remove_config(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{
      //Run ansible playbook to generate artefacts for environment
	   ansiColor('xterm') {
		 ansiblePlaybook(playbook: "./${deployParams.Host}/BW_Deployment/removeConfig.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Host}_BW", engines_list: "${deployParams.engines_list}", datetime: "${deployParams.datetime}", crq_num: "${deployParams.crq_no}", folderName: "${deployParams.folderName}", bw_folder_release: "${deployParams.bw_folder_release}", engine_group:"${deployParams.engine_group}"])

		}
    }
}

/*Function to create rollback configs based on bw restart issue 
Input : 
Host
engines_list : list of succesfully restarted engines separated by ;
datetime
crq_no
removeConfig

*/

def bw_rollback_config_generate(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{
      //Run ansible playbook to generate rollback config for environment
	   ansiColor('xterm') {
		 ansiblePlaybook(playbook: "./${deployParams.Host}/BW_Deployment/rollbackConfigGeneration.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Host}_BW", engines_list: "${deployParams.engines_list}", datetime: "${deployParams.datetime}", crq_num: "${deployParams.crq_no}", removeConfig: "${deployParams.removeConfig}", folderName: "${deployParams.folderName}", bw_folder_release: "${deployParams.bw_folder_release}", engine_group:"${deployParams.engine_group}"])

		}
    }
}

/*Function to remove configs based on other component deployments 
Input : 
Host
host : list of engines separated by ;
datetime
crq_no

*/

def bw_restart(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{
      //Run ansible playbook to generate artefacts for environment
	   ansiColor('xterm') {
		 ansiblePlaybook(playbook: "./${deployParams.Host}/BW_Deployment/restartEngines.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Host}_BW", datetime: "${deployParams.datetime}", crq_num: "${deployParams.crq_no}", folderName: "${deployParams.folderName}", bw_folder_release: "${deployParams.bw_folder_release}", engine_group:"${deployParams.engine_group}"])

		}
    }
}

/*Function to rollback BW changes
Input : 
Host
datetime
crq_no

*/

def bw_rollback(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{
      //Run ansible playbook to generate artefacts for environment
	   ansiColor('xterm') {
		 ansiblePlaybook(playbook: "./${deployParams.Host}/BW_Deployment/rollbackDeployedEngines.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Host}_BW", datetime: "${deployParams.datetime}", crq_num: "${deployParams.crq_no}", folderName: "${deployParams.folderName}", bw_folder_release: "${deployParams.bw_folder_release}", engine_group:"${deployParams.engine_group}", EnvironmentRepository: "${deployParams.EnvironmentRepository}", engines_list:"${deployParams.engines_list}"])

		}
    }
}

/*Function to rollback for RB BW changes
Input : 
Host
datetime
crq_no

*/

def bw_rollback_RB(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{
      //Run ansible playbook to generate artefacts for environment
	   ansiColor('xterm') {
		 ansiblePlaybook(playbook: "./${deployParams.Host}/BW_Deployment/ExplicitRollbackDeployedEngines.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Host}_BW", datetime: "${deployParams.datetime}", crq_num: "${deployParams.crq_no}", folderName: "${deployParams.folderName}", bw_folder_release: "${deployParams.bw_folder_release}", engine_group:"${deployParams.engine_group}", EnvironmentRepository: "${deployParams.EnvironmentRepository}", engines_list:"${deployParams.engines_list}"])

		}
    }
}	

return this