
/******************************************************************************************************************** 
Author: Anil Kolli
Date: 13/04/2020
/******************************************************************************************************************** 
This file is having functions related to NEXUS repository and getting data from Nexus.
1. get_engine_release_info()
2. get_engines_from_nexus()
3. get_bw_folder_name()
4. get_bw_version_from_nexus()
/******************************************************************************************************************** 




/********************************************************************************************************************
This function is used to get RELEASE VERSIONS from NEXUS for the given engine.
Input:
REPO_URL: Nexus URL
target_repo: NEXUS Repository name from where we need to get versions. Eg: STAGING_REPO
GROUPID: Nexus GroupID
version: Major version and minor version , like 20_4
engine: engine name 
*********************************************************************************************************************/

def get_engine_release_info(deployParams){
	// This function is to get release info for all the builds happened for the given engine.
	// [CICD-323]: Fix is to read  continuationToken and iterate till it gets null value to fetch complete results.

	def continuationToken = ""
	sh(script: "curl -s -X GET \"${deployParams.REPO_URL}/service/rest/v1/search?repository=${deployParams.target_repo}&name=${deployParams.GROUPID}/*/${deployParams.version}_*/${deployParams.engine}-*.txt\" >curl_result")
	continuationToken = sh(script: "grep 'continuationToken' ${WORKSPACE}/curl_result | tail -1 | cut -d ':' -f 2 | tr -d ' ' | sed 's/\"//g'",returnStdout: true).trim()
	while(continuationToken != "null") {
		sh(script: "curl -s -X GET \"${deployParams.REPO_URL}/service/rest/v1/search?repository=${deployParams.target_repo}&name=${deployParams.GROUPID}/*/${deployParams.version}_*/${deployParams.engine}-*.txt&continuationToken=${continuationToken}\" >>curl_result")
		continuationToken = sh(script: "grep 'continuationToken' ${WORKSPACE}/curl_result | tail -1 | cut -d ':' -f 2 | tr -d ' ' | sed 's/\"//g'", returnStdout: true).trim()
		println("DEBUG: continuationToken is: " + continuationToken)
	}
	query_cmd = sh(script: "cat curl_result | grep \"downloadUrl\" | cut -d ':' -f 2- | tr -d ',' | sort -r -V | xargs -I{} curl -s -X GET \"{}\"", returnStdout: true).trim()
	return query_cmd
}

/*********************************************************************************************************************
99210 ONLY for OnlyGV description
Functipon to fetch latest BW_Version present in nexus in repo
Input:
REPO_URL: Nexus URL
target_repo: Nexus repository name to engines.
GROUPID: nexus group ID
extn: Artefact extension like, ear or tar.gz or xml
Output:
 engine latest versions
*********************************************************************************************************************/
def get_bw_version_from_nexus(deployParams) {
// Function to get list of engines and latest versions from Nexus
// [CICD-323]: Fix is to read continuationToken and iterate till it gets null value to fetch complete results.
 def continuationToken = ""
 sh(script: """curl -s -X GET \"${deployParams.REPO_URL}/service/rest/v1/search?repository=${deployParams.target_repo}&name=${deployParams.GROUPID}/${deployParams.engines}/*.${deployParams.extn}\" >curl_result""")
 continuationToken = sh(script: "grep 'continuationToken' ${WORKSPACE}/curl_result | tail -1 | cut -d ':' -f 2 | tr -d ' ' | sed 's/\"//g'",returnStdout: true).trim()
 while(continuationToken != "null") {
 sh(script: """curl -s -X GET \"${deployParams.REPO_URL}/service/rest/v1/search?repository=${deployParams.target_repo}&name=${deployParams.GROUPID}/${deployParams.engines}/*.${deployParams.extn}&continuationToken=${continuationToken}\" >>curl_result""")
 continuationToken = sh(script: "grep 'continuationToken' ${WORKSPACE}/curl_result | tail -1 | cut -d ':' -f 2 | tr -d ' ' | sed 's/\"//g'", returnStdout: true).trim()
 println("DEBUG: continuationToken is: " + continuationToken)
 }
 query_cmd = sh(script: " cat curl_result | grep \"name\" | sort -V -t/ -k 2,3 | tac | sort -u -t/ -k 2,2 | cut -d '/' -f 3", returnStdout: true).trim()
 println("query_cmd value")
 println(query_cmd)
 return query_cmd
}



/*********************************************************************************************************************
This function is used to get engines list promoted to particular environment.
Input:
REPO_UR: Nexus URL
target_repo: Nexus repository name to get promoted engines.
GROUPID: nexus group ID
version: majorVersion_minorVersion
extn: Artefact extension like, ear or tar.gz or xml
Output:
List of engines and versions (eng1:ver1;eng2:ver2)

*********************************************************************************************************************/


def get_engines_from_nexus(deployParams) {
	// Function to get list of engines and latest versions from Nexus
	// [CICD-323]: Fix is to read  continuationToken and iterate till it gets null value to fetch complete results.
	def continuationToken = ""
	sh(script: """curl -s -X GET \"${deployParams.REPO_URL}/service/rest/v1/search?repository=${deployParams.target_repo}&name=${deployParams.GROUPID}/*/${deployParams.version}_"[0-9]*"/*.${deployParams.extn}\" >curl_result""")
	continuationToken = sh(script: "grep 'continuationToken' ${WORKSPACE}/curl_result | tail -1 | cut -d ':' -f 2 | tr -d ' ' | sed 's/\"//g'",returnStdout: true).trim()
	while(continuationToken != "null") {
		sh(script: """curl -s -X GET \"${deployParams.REPO_URL}/service/rest/v1/search?repository=${deployParams.target_repo}&name=${deployParams.GROUPID}/*/${deployParams.version}_"[0-9]*"/*.${deployParams.extn}&continuationToken=${continuationToken}\" >>curl_result""")
		continuationToken = sh(script: "grep 'continuationToken' ${WORKSPACE}/curl_result | tail -1 | cut -d ':' -f 2 | tr -d ' ' | sed 's/\"//g'", returnStdout: true).trim()
		println("DEBUG: continuationToken is: " + continuationToken)
	}
	query_cmd = sh(script: "cat curl_result | grep \"name\" | sort -V -t/ -k 2,3 | tac | sort -u -t/ -k 2,2 | cut -d '/' -f 2-3 | tr '/' ':' | tr '\n' ';'", returnStdout: true).trim()
	return query_cmd
}

/*********************************************************************************************************************
This funcxtion tries to get Folder name for the given engine from LinkTest environmnet Application.txt file.
Assumption is folder names remains same across all the environments.
*********************************************************************************************************************/

def get_bw_folder_name(deployParams){
	// Function to get Folder name for each of theengine listed in BW folder from LinkTest Application.txt file
	def bw_folders = ""
	def application_file = new File("${WORKSPACE}/ENV/BW_Configuration/${deployParams.base_env}/Applications.txt").readLines()
	deployParams.engines.split(';').each { param ->
		def result = application_file.findAll { it.endsWith(param) }
		if(result) {
			bw_folders = bw_folders + param + ':' + result[-1].split('/')[0] + ';'
		}
	}
	if(bw_folders){
		return bw_folders.substring(0, bw_folders.length() - 1);
	}
}



/*********************************************************************************************************************
From the Environment Application.txt file, get whether the given engine i sNew or existing.
*********************************************************************************************************************/

def get_bw_deployment_type(deployParams){
	// Function to get Folder name for each of the engine listed in BW folder from LinkTest Application.txt file
	def bw_deployment_type = ""
	def application_file = new File("${WORKSPACE}/ENV/BW_Configuration/${deployParams.target_env}/Applications.txt").readLines()
	deployParams.engines.split(';').each { param ->
		def result = application_file.findAll { it.endsWith(param) }
		if(result) {
			bw_deployment_type = bw_deployment_type + param + ':' + 'Existing' + ';'
		} else {
			bw_deployment_type = bw_deployment_type + param + ':' + 'New' + ';'
		}
	}
	if(bw_deployment_type) {
		return bw_deployment_type.substring(0, bw_deployment_type.length() - 1);
	}
}


/********************************************************************************************************************
This function is used to check passed version existing for the engine or not?
Input: 
REPO_URL: Nexus URL
target_repo: Nexus repository in which we need tocheck for versions. Eg: LINKTEST_REPO
GROUPID: Nexus GroupID
version: engine version, like 20_4_4
engine: engine name 
Output: Command output
*********************************************************************************************************************/

def validate_nexus_version(deployParams){
	// This function is to get release info for all the builds happened for the given engine.
	def exec_cmd = sh(script: "curl -s --head  --request GET \"${deployParams.REPO_URL}/${deployParams.target_repo}/${deployParams.GROUPID}/${deployParams.engine}/${deployParams.version}/${deployParams.engine}-${deployParams.version}.${deployParams.extn}\" | grep \"200 OK\"", returnStatus: true)
	return exec_cmd
}

return this


