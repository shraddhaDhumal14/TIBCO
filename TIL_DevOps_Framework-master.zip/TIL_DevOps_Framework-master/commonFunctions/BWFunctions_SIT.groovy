
/*********************************************************************************************************************
Author: Anil Kolli & Raghuram Koripalli
Date: 13/04/2020
/*********************************************************************************************************************
This file holds all the functions related to BW generate and deployment.
Below are the functions listed in thsi file.


*********************************************************************************************************************/

/* Function to update app conf with append and prepend paths for existing engine deployment app conf
appConfTemplate_path - template file path from workspace
appConf_path - engine appconf file path
engine - Engine Name
*/
def add_append_prepend_from_template(deployParams) {
	
	// First get values from template file for the engine passed.
	def lines = new File("${deployParams.appConfTemplate_path}").readLines()
	// Append path verification
	def matched_engine = lines.findAll { it.contains("Append|${deployParams.engine}|") }[0]
	if(matched_engine && !matched_engine.empty) {
		//CICD-465: Fix for append path update for existing engines
		def appconf_file = new File("${deployParams.appConf_path}/${deployParams.engine}.appconf")
		// updating values from template.
		appconf_file = appconf_file.append("${deployParams.common_engine}.par.appendClasspath=" + matched_engine.split("\\|")[2] + "\n")
		//writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.appendClasspath=", "par.appendClasspath=" + matched_engine.split("\\|")[2])
	}
	else {
		println("DEBUG: Append Classpath  for engine ${deployParams.engine} not found in template file.")
	}
	// Prepend path verification
	def matched_engine_prepend = lines.findAll { it.contains("Prepend|${deployParams.engine}|") }[0]
	if(matched_engine_prepend && !matched_engine_prepend.empty) {
		//CICD-465: Fix for prepend path update for existing engines
		def appconf_file = new File("${deployParams.appConf_path}/${deployParams.engine}.appconf")
		// updating values from template.
		appconf_file = appconf_file.append("${deployParams.common_engine}.par.prependClasspath=" + matched_engine_prepend.split("\\|")[2].toString() + "\n")
		//writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.prependClasspath=", "par.prependClasspath=" + matched_engine_prepend.split("\\|")[2])
	}
	else {
		println("DEBUG: Prepend Classpath  for engine ${deployParams.engine} not found in template file.")
	}				
}	

/* 999210 ONLY for OnlyGV description 
Function to add Latest BW_Verion in Tibco Admin History Table 
Input : Engine list , Hosts, ReleaseNumber, FolderName, Description,nexus_url,nexus_repo_id,nexus_group_id
*/
def generate_conf_files_gv_change_description(deployParams) {
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}_Conf"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_BW_Application_Configuration.git']]]
    // make a directory with conf
	sh "mkdir -p ./${deployParams.Host}_Conf/conf"
    echo "${deployParams.engines}"
    def engine_list = deployParams.engines.split(';')
	
	def majv = deployParams.ReleaseNumber.split('CCS')[1].split('\\.')[0]
	def minv = deployParams.ReleaseNumber.split('CCS')[1].split('\\.')[1]	
	
	for (txt in engine_list) {
		echo "${txt}"
		echo "before split"
		def engine = txt.split(':')
		def eng_conf = engine[0]
		echo eng_conf
		
		nexusVersionFunc = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/nexusFunctions.groovy"
		def ear_version = nexusVersionFunc.get_bw_version_from_nexus REPO_URL:"${deployParams.nexus_url}", target_repo:"${deployParams.nexus_repo_id}", GROUPID:"${deployParams.nexus_group_id}", engines:"${eng_conf}", extn: "ear"
		
		println("EAR Version of ${eng_conf} is ${ear_version}")
		
		//def gv_version_desc = "${ear_version}" + "|" + "${deployParams.description}"
		//println("gv_version_desc : ${gv_version_desc}")
		
		// [CICD-193: FIX] - Checkout repository using tag to get the linked configuration.
		// [CICD-1719: FIX] - Fail the pipeline when checkout tag is not found.
		if(deployParams.use_tag != "no"){
			def last_tag = sh(returnStdout: true, script: "cd \"${deployParams.Host}\"_Conf; git tag -l ${eng_conf}_${majv}_${minv}_\"[0-9]\"* | sort -V | tail -1").trim()
			if(last_tag.length() != 0){
				def temp = sh(returnStdout: true, script: "cd ${deployParams.Host}_Conf; git checkout master; [[ \$(git tag --list | grep ${last_tag}) ]] && git checkout tags/${last_tag} || { echo \"ERROR: ${last_tag} is not available for checkout\"; exit 1; }").trim()
			} else {
				def temp = sh(returnStdout: true, script: "echo \"ERROR: NO Config Tag is available for checkout. Please follow up with DEV team\" ; exit 1").trim()
			}
		}
		
		// create directory if does not exist
		sh "mkdir -p ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}"
		// Rename common gvchange app conf template to engine specific
		sh "cp ./${deployParams.Host}_Conf/GVChange_Configurations/GVChange.appconf ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
		
		// update Folder Name in app.conf with inputs provided during deployment
		if(deployParams.folderName == "None"){
			println("Folder Name is None , no update is required")
		}
		else{
		   sh  "sed -i '/FolderName=/ s/=.*/=${deployParams.folderName}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"	
		}
		// update cvsVersion field
		//sh  "sed -i '/CVSVersion=/ s/=.*/=${deployParams.cvsVersion}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
		sh  "sed -i '/CVSVersion=/ s/=.*/=${ear_version}/' ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
		
		// update release field
		sh  "sed -i '/releaseName=/ s/=.*/=${deployParams.ReleaseNumber}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
		
		// update description field
		sh  "sed -i '/description=/ s/=.*/=${deployParams.description}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
		//sh  "sed -i '/description=/ s/=.*/=${gv_version_desc}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
		//sh  "sed -i '/${eng_conf}.par.instanceCount=/ s/=.*/=${deployParams.instances}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
		// copy engine config files to single location for deployment job
		sh "cp ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/* ./${deployParams.Host}_Conf/conf"
		sh "cp -r ./${deployParams.Host}_Conf/BW_Configurations/${eng_conf}/* ./${deployParams.Host}_Conf/conf"	
	  }
}

/* Function to generate app conf for existing engines 
Input : Engine list , Hosts, ReleaseNumber, FolderName, Description,
*/										
def generate_conf_files_existing_engines(deployParams) {
	
    
	// checkout Application configuration repository
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}_Conf"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_BW_Application_Configuration.git']]]
	
	//[CICD-1332]: Fix to refer the exact REPO for getting appconf file.
	def NEXUS_REPO = "SIT_REPO"
	
	if(deployParams.containsKey('BW_BUILD_REPO') && "${deployParams.BW_BUILD_REPO}" == "DEV_REPO"){
		NEXUS_REPO = "DEV_REPO"
	}
		
	
    // make a directory with conf
	sh "mkdir -p ./${deployParams.Host}_Conf/conf"
    echo "${deployParams.engines}"
	echo "${deployParams.folderName}"
	echo "${deployParams.description}"
	//echo "${deployParams.instances}"
    def engine_list = deployParams.engines.split(';')
	for (txt in engine_list) {
			echo "${txt}"
			def engine = txt.split(':')
			def eng_conf = engine[0]
			def eng_ver = engine[1]
			echo eng_conf
			
			// [CICD-213: FIX] - Checkout repository using tag to get the linked configuration.
			// [CICD-1719: FIX] - Fail the pipeline when checkout tag is not found.
			
			if(deployParams.use_tag != "no"){
				def eng_git_tag = eng_conf + '_' + eng_ver
				def temp = sh(returnStdout: true, script: "cd ${deployParams.Host}_Conf; git checkout master; [[ \$(git tag --list | grep ${eng_git_tag}) ]] && git checkout tags/${eng_git_tag} || { echo \"ERROR: ${eng_git_tag} is not available for checkout. Please follow up with DEV team\"; exit 1; }").trim()
			}
			
			// create directory if does not exist
			sh "mkdir -p ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}"
			//[CICD-1332]: Fix to refer the exact REPO for getting appconf file.
			sh "curl -o ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf  http://195.233.197.150:8081/repository/${NEXUS_REPO}/TIL_BW/${eng_conf}/${eng_ver}/${eng_conf}-${eng_ver}.appconf"
			// Updating folder name in app.conf
			if(deployParams.folderName == "None"){
				println("Folder Name is None , no update is required")
			}
            else{
			 sh  "sed -i '/FolderName=/ s/=.*/=${deployParams.folderName}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
			}	
			// update values of app.conf with inputs provided during deployment
			// update description field
			sh  "sed -i '/description=/ s/=.*/=${deployParams.description}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
			// update release field
			sh  "sed -i '/releaseName=/ s/=.*/=${deployParams.ReleaseNumber}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
			//identifying engine name
			def common_eng_name = sh(script:"cat ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf | grep 'appendClasspath' | awk -F '.par' '{print \$1}'" ,returnStdout: true).trim()
            echo  "common_eng_name : ${common_eng_name}"
			
			// removing instance count parameter
            //sh  "sed -i '/.*.par.instanceCount*/d' ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
			// Removing records in app conf
			
			//[CICD-998]: Fix to update appconf parameters for existing engines as well.
            sh  "sed -i '/.*.par.instanceCount*/d' ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
			sh  "sed -i '/.*.par.isFT/d' ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
			sh  "sed -i '/.*.par.FT*/d' ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
			sh  "sed -i '/.*.par.enablePar/d' ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"			
			
			//Updating app conf params based on details from engines list
			
			def lines = new File("${WORKSPACE}/ENV/BW_Configuration/${deployParams.Host}/Engines_Template.txt").readLines()
			def matched_engine = lines.findAll { it.contains("${eng_conf}|") }[0]
	        if(matched_engine && !matched_engine.empty) {
				//Reading app.conf file download from Nexus
				def appconf_file = "${WORKSPACE}/${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
				// Start updating values from template.
				if(matched_engine.split("\\|")[1] != null) {
					//newConfig = newConfig.replace("par.MaxHeapSize=", "par.MaxHeapSize=" + matched_engine.split("\\|")[1].toString())
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.MaxHeapSize=", "par.MaxHeapSize=" + matched_engine.split("\\|")[1].toString())
				}
				if(matched_engine.split("\\|")[2] != null) {
					//newConfig = newConfig.replace("par.LogfileCount=", "par.LogfileCount=" + matched_engine.split("\\|")[2].toString())
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.LogfileCount=", "par.LogfileCount=" + matched_engine.split("\\|")[2].toString())
				}
				if(matched_engine.split("\\|")[3] != null) {
					//newConfig = newConfig.replace("par.LogfileSize=", "par.LogfileSize=" + matched_engine.split("\\|")[3].toString())
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.LogfileSize=", "par.LogfileSize=" + matched_engine.split("\\|")[3].toString())
				}
				if(matched_engine.split("\\|")[4] != null) {
					//newConfig = newConfig.replace("par.threadCount=", "par.threadCount=" + matched_engine.split("\\|")[4].toString())
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.threadCount=", "par.threadCount=" + matched_engine.split("\\|")[4].toString())
				}		
				if(matched_engine.split("\\|")[5] != null) {
					//newConfig = newConfig.replace("par.initHeapSize=", "par.initHeapSize=" + matched_engine.split("\\|")[5].toString())
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.initHeapSize=", "par.initHeapSize=" + matched_engine.split("\\|")[5].toString())
				}
				if(matched_engine.split("\\|")[6] != null) {
					//newConfig = newConfig.replace("par.threadStackSize=", "par.threadStackSize=" + matched_engine.split("\\|")[6].toString())
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.threadStackSize=", "par.threadStackSize=" + matched_engine.split("\\|")[6].toString())
				}
				if(matched_engine.split("\\|")[7] == "true") {
					//newConfig = newConfig.replace("par.isFT=false", "par.isFT=" + matched_engine.split("\\|")[7].toString())
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.isFT=false", "par.isFT=" + matched_engine.split("\\|")[7].toString())
				}
				if(matched_engine.split("\\|")[8] != null) {
					//newConfig = newConfig.replace("par.FTWeight=", "par.FTWeight=" + matched_engine.split("\\|")[8].toString())
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.FTWeight=", "par.FTWeight=" + matched_engine.split("\\|")[8].toString())
				}
				if(matched_engine.split("\\|")[9] != null) {
					//newConfig = newConfig.replace("par.FTHeartbeatInterval=", "par.FTHeartbeatInterval=" + matched_engine.split("\\|")[9].toString())
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.FTHeartbeatInterval=", "par.FTHeartbeatInterval=" + matched_engine.split("\\|")[9].toString())
				}
				if(matched_engine.split("\\|")[10] != null) {
					//newConfig = newConfig.replace("par.FTActivationInterval=", "par.threadCount=" + matched_engine.split("\\|")[10].toString())
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.FTActivationInterval=", "par.threadCount=" + matched_engine.split("\\|")[10].toString())
				}
				if(matched_engine.split("\\|")[11] != null) {
					//newConfig = newConfig.replace("par.FTPreperationDelay=", "par.FTPreperationDelay=" + matched_engine.split("\\|")[11].toString())
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.FTPreperationDelay=", "par.FTPreperationDelay=" + matched_engine.split("\\|")[11].toString())
				}
				
				// Write back to the original appconf file.
				 //appconf_file.text = newConfig
				 //[CICD-998]: Fix to update appconf parameters for existing engines as well - commenting below line as we do not disturb checkpoint config. 
/* 				if(matched_engine.split("\\|")[13] == "true") {
					echo "checkpoint true condition"
					appconf_file = appconf_file.append("${common_eng_name}.par.CheckPointSelected=" + matched_engine.split("\\|")[14].toString())
				} */
				
			}
            else{
				//[CICD-998]: Fix to update appconf parameters for existing engines as well - commenting below line as we do not disturb checkpoint config. 
				sh  "sed -i '/.*\\.par\\..*/d' ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
				println("DEBUG: engine ${eng_conf} not found in new engines template file.")
				
            }
            
			// calling append and prepend function
			add_append_prepend_from_template appConfTemplate_path:"${WORKSPACE}/ENV/BW_Configuration/${deployParams.Host}/AppendPrependConfiguration.conf", appConf_path:"${WORKSPACE}/${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}", engine:"${eng_conf}", common_engine:"${common_eng_name}"
			// copy engine config files to single location for deployment job
			sh "cp ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/* ./${deployParams.Host}_Conf/conf"
			sh "cp ./${deployParams.Host}_Conf/BW_Configurations/${eng_conf}/* ./${deployParams.Host}_Conf/conf"
		  }
}

/* Function to update app conf with append and prepend paths for new engine deployment app conf
appConfTemplate_path - template file path from workspace
appConf_path - engine appconf file path
engine - Engine Name
*/
def update_append_prepend_from_template(deployParams) {
	
	// First get values from template file for the engine passed.
	def lines = new File("${deployParams.appConfTemplate_path}").readLines()
	// Append path verification
	def matched_engine = lines.findAll { it.contains("Append|${deployParams.engine}|") }[0]
	if(matched_engine && !matched_engine.empty) {
		def appconf_file = "${deployParams.appConf_path}/${deployParams.engine}.appconf"
		writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.appendClasspath=", "par.appendClasspath=" + matched_engine.split("\\|")[2].toString())
	}
	else {
		println("DEBUG: Append Classpath  for engine ${deployParams.engine} not found in template file.")
	}
	// Prepend path verification
	def matched_engine_prepend = lines.findAll { it.contains("Prepend|${deployParams.engine}|") }[0]
	if(matched_engine_prepend && !matched_engine_prepend.empty) {
		def appconf_file = "${deployParams.appConf_path}/${deployParams.engine}.appconf"
		writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.prependClasspath=", "par.prependClasspath=" + matched_engine_prepend.split("\\|")[2].toString())
	}
	else {
		println("DEBUG: Prepend Classpath  for engine ${deployParams.engine} not found in template file.")
	}				
}


/* Function to generate conf for new engines 
Input : 
Enginelist - List of engines , 
Environmet - Deployment environment
Host - Target Host ideally environment
ReleaseNumber - Release Number
Templetefilepath - New Engines app conf template path
Description - Descrition used in admin console
*/										
def generate_conf_files_new_engines(deployParams) {
	
    
	// checkout Application configuration repository
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}_Conf"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_BW_Application_Configuration.git']]]
	
	//[CICD-1332]: Fix to refer the exact REPO for getting appconf file.
	def NEXUS_REPO = "NEXUS_REPO"
    
	if(deployParams.containsKey('BW_BUILD_REPO') && "${deployParams.BW_BUILD_REPO}" == "DEV_REPO"){
		NEXUS_REPO = "DEV_REPO"
	}
	// make a directory with conf
	sh "mkdir -p ./${deployParams.Host}_Conf/conf"
   
	//echo "${deployParams.instances}"
    def engine_list = deployParams.engines.split(';')
	for (txt in engine_list) {
			echo "${txt}"
			def checkpoint
			def engine = txt.split(':')
			def eng_conf = engine[0]
			def eng_ver = engine[1]
			echo eng_conf
			
			// [CICD-213: FIX] - Checkout repository using tag to get the linked configuration.
			// [CICD-1719: FIX] - Fail the pipeline when checkout tag is not found.
			if(deployParams.use_tag != "no"){
				def eng_git_tag = eng_conf + '_' + eng_ver
				def temp = sh(returnStdout: true, script: "cd ${deployParams.Host}_Conf; git checkout master; [[ \$(git tag --list | grep ${eng_git_tag}) ]] && git checkout tags/${eng_git_tag} ||  { echo \"ERROR: ${eng_git_tag} is not available for checkout. Please follow up with DEV team\"; exit 1; }").trim()
			}

			
			// create directory if does not exist
			sh "mkdir -p ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}"
			//[CICD-1332]: Fix to refer the exact REPO for getting appconf file.
			sh "curl -o ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf  http://195.233.197.150:8081/repository/${NEXUS_REPO}/TIL_BW/${eng_conf}/${eng_ver}/${eng_conf}-${eng_ver}.appconf"
			
			// identify par name for common engines which have differnt par name 
            //Remove par parameters
			def common_eng_name = sh(script: "cat ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf | grep 'appendClasspath' | awk -F '.par' '{print \$1}'" ,returnStdout: true).trim()
            echo  "common_eng_name : $common_eng_name"
			// First get values from template file for the engine passed.
	        def lines = new File("${WORKSPACE}/ENV/BW_Configuration/${deployParams.Host}/Engines_Template.txt").readLines()
			def matched_engine = lines.findAll { it.contains("${eng_conf}|") }[0]
	        if(matched_engine && !matched_engine.empty) {
				//Reading app.conf file download from Nexus
				def appconf_file = "${WORKSPACE}/${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
				// Start updating values from template.
				if(matched_engine.split("\\|")[1] != null) {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.MaxHeapSize=", "par.MaxHeapSize=" + matched_engine.split("\\|")[1].toString()) 
                 }
				if(matched_engine.split("\\|")[2] != null) {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.LogfileCount=", "par.LogfileCount=" + matched_engine.split("\\|")[2].toString()) 
				}
				if(matched_engine.split("\\|")[3] != null) {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.LogfileSize=", "par.LogfileSize=" + matched_engine.split("\\|")[3].toString()) 
				}
				if(matched_engine.split("\\|")[4] != null) {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.threadCount=", "par.threadCount=" + matched_engine.split("\\|")[4].toString()) 
				}		
				if(matched_engine.split("\\|")[5] != null) {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.initHeapSize=", "par.initHeapSize=" + matched_engine.split("\\|")[5].toString()) 
				}
				if(matched_engine.split("\\|")[6] != null) {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.threadStackSize=", "par.threadStackSize=" + matched_engine.split("\\|")[6].toString()) 
				}
				if(matched_engine.split("\\|")[7] == "true") {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.isFT=false", "par.isFT=" + matched_engine.split("\\|")[7].toString()) 
				}
				if(matched_engine.split("\\|")[8] != null) {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.FTWeight=", "par.FTWeight=" + matched_engine.split("\\|")[8].toString())
				}
				if(matched_engine.split("\\|")[9] != null) {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.FTHeartbeatInterval=", "par.FTHeartbeatInterval=" + matched_engine.split("\\|")[9].toString())
				}
				if(matched_engine.split("\\|")[10] != null) {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.FTActivationInterval=", "par.threadCount=" + matched_engine.split("\\|")[10].toString())
				}
				if(matched_engine.split("\\|")[11] != null) {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.FTPreperationDelay=", "par.FTPreperationDelay=" + matched_engine.split("\\|")[11].toString())
				}
				if(matched_engine.split("\\|")[12] != null) {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.instanceCount=4", "par.instanceCount=" + matched_engine.split("\\|")[12].toString())
				}
				else{
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.instanceCount=4", "par.instanceCount=" + deployParams.instanceCount)
				
				}	
				
				if(matched_engine.split("\\|")[13] == "true") {
					echo "checkpoint true condition"
                    def appconf_file1 = new File("${WORKSPACE}/${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf")
				
					appconf_file1 = appconf_file1.append("${common_eng_name}.par.CheckPointSelected=" + matched_engine.split("\\|")[14].toString())
					
				}

			}
            else{
				println("DEBUG: engine ${eng_conf} not found in new engines template file.")
				//Reading app.conf file download from Nexus
				def appconf_file = "${WORKSPACE}/${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
				
				echo "instance count from script ${deployParams.instanceCount}"
				writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.instanceCount=4", "par.instanceCount=" + deployParams.instanceCount) 
				sh "cat ${appconf_file}"
            }
             			
			// update Folder Name in app.conf with inputs provided during deployment
			if(deployParams.folderName == "None"){
				println("Folder Name is None , no update is required")
			}
            else{
			   sh  "sed -i '/FolderName=/ s/=.*/=${deployParams.folderName}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"	
            }				
			// update description field
			sh  "sed -i '/description=/ s/=.*/=${deployParams.description}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
			// update release field
			sh  "sed -i '/releaseName=/ s/=.*/=${deployParams.ReleaseNumber}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"				
			// calling update append and prepend function
			update_append_prepend_from_template appConfTemplate_path:"${WORKSPACE}/ENV/BW_Configuration/${deployParams.Host}/AppendPrependConfiguration.conf", appConf_path:"${WORKSPACE}/${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}", engine:"${eng_conf}"
			// copy engine config files to single location for deployment job
			sh "cp ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/* ./${deployParams.Host}_Conf/conf"
			sh "cp ./${deployParams.Host}_Conf/BW_Configurations/${eng_conf}/* ./${deployParams.Host}_Conf/conf"
		  }
}



// Generate app.conf files required for BW GV change deployment
/* Function to generate conf for only GV changes 
Input : 
Enginelist - List of engines , 
Host - Target Host ideally environment
ReleaseNumber - Release Number
Description - Descrition used in admin console
*/

def generate_conf_files_gv_change(deployParams) {
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}_Conf"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_BW_Application_Configuration.git']]]
    // make a directory with conf
	sh "mkdir -p ./${deployParams.Host}_Conf/conf"
    echo "${deployParams.engines}"
    def engine_list = deployParams.engines.split(';')
	
	def majv = deployParams.ReleaseNumber.split('CCS')[1].split('\\.')[0]
	def minv = deployParams.ReleaseNumber.split('CCS')[1].split('\\.')[1]	
	
	for (txt in engine_list) {
		echo "${txt}"
		echo "before split"
		def engine = txt.split(':')
		def eng_conf = engine[0]
		echo eng_conf
		
		// [CICD-193: FIX] - Checkout repository using tag to get the linked configuration.
		// [CICD-1719: FIX] - Fail the pipeline when checkout tag is not found.
		if(deployParams.use_tag != "no"){
			def last_tag = sh(returnStdout: true, script: "cd \"${deployParams.Host}\"_Conf; git tag -l ${eng_conf}_${majv}_${minv}_\"[0-9]\"* | sort -V | tail -1").trim()
			if(last_tag.length() != 0){
				def temp = sh(returnStdout: true, script: "cd ${deployParams.Host}_Conf; git checkout master; [[ \$(git tag --list | grep ${last_tag}) ]] && git checkout tags/${last_tag} || { echo \"ERROR: ${last_tag} is not available for checkout\"; exit 1; }").trim()
			} else {
				def temp = sh(returnStdout: true, script: "echo \"ERROR: NO Config Tag is available for checkout. Please follow up with DEV team\" ; exit 1").trim()
			}
		}
		
		// create directory if does not exist
		sh "mkdir -p ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}"
		// Rename common gvchange app conf template to engine specific
		sh "cp ./${deployParams.Host}_Conf/GVChange_Configurations/GVChange.appconf ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
		
		// update Folder Name in app.conf with inputs provided during deployment
		if(deployParams.folderName == "None"){
			println("Folder Name is None , no update is required")
		}
		else{
		   sh  "sed -i '/FolderName=/ s/=.*/=${deployParams.folderName}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"	
		}
		// update cvsVersion field
		//sh  "sed -i '/CVSVersion=/ s/=.*/=${deployParams.cvsVersion}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
		
		// update release field
		sh  "sed -i '/releaseName=/ s/=.*/=${deployParams.ReleaseNumber}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
		
		// update description field
		sh  "sed -i '/description=/ s/=.*/=${deployParams.description}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
		//sh  "sed -i '/${eng_conf}.par.instanceCount=/ s/=.*/=${deployParams.instances}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
		// copy engine config files to single location for deployment job
		sh "cp ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/* ./${deployParams.Host}_Conf/conf"
		sh "cp -r ./${deployParams.Host}_Conf/BW_Configurations/${eng_conf}/* ./${deployParams.Host}_Conf/conf"	
	  }
}

// Generate app.conf files required for BW restarts
/* Function to generate conf for only restarts
Input : 
Enginelist - List of engines , 
Host - Target Host ideally environment
ReleaseNumber - Release Number
Description - Descrition used in admin console
*/

def generate_conf_files_restart(deployParams) {
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}_Conf"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_BW_Application_Configuration.git']]]
    // make a directory with conf
	sh "mkdir -p ./${deployParams.Host}_Conf/conf"
    echo "${deployParams.engines}"
    def engine_list = deployParams.engines.split(';')
	for (txt in engine_list) {
		echo "${txt}"
		echo "before split"
		def engine = txt.split(':')
		def eng_conf = engine[0]

		echo eng_conf
		echo "after split"
		// create directory if does not exist
		sh "mkdir -p ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}"
		// Rename common gvchange app conf template to engine specific
		sh "cp ./${deployParams.Host}_Conf/Restart_Configurations/Restart_Template.appconf ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
		
		// update Folder Name in app.conf with inputs provided during deployment
		if(deployParams.folderName == "None"){
			println("Folder Name is None , no update is required")
		}
		else{
		   sh  "sed -i '/FolderName=/ s/=.*/=${deployParams.folderName}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"	
		}
		sh "cp ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/* ./${deployParams.Host}_Conf/conf"
		//sh "cp -r ./${deployParams.Host}_Conf/BW_Configurations/${eng_conf}/* ./${deployParams.Host}_Conf/conf"	
	  }
}



/*BW Generate Function 
Input : 
Host
nexus_group_id
nexus_user
nexus_passwd
nexus_repo_id
nexus_url
engines
datetime
crq_no
engines_list
release
onlyGVChange
EnvPrefix
deployment_type
*/

def generate_bw_deployment(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{
		checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
		// create directory with name conf to copy config files
		sh "mkdir -p ./${deployParams.Host}/BW_Deployment/conf"
		sh "cp -r ./${deployParams.Host}_Conf/conf/* ./${deployParams.Host}/BW_Deployment/conf"
        sh "mkdir -p ./${deployParams.Host}/BW_Deployment/host_vars/${deployParams.Host}_BW"
		// Copy Environment specififc files to Ansible Host Vars 
		sh "cp -r ./ENV/BW_Configuration/${deployParams.Host}/* ./${deployParams.Host}/BW_Deployment/host_vars/${deployParams.Host}_BW"
		// Copy Manual Changes conf file from host vars to script folder
		sh "mv ./${deployParams.Host}/BW_Deployment/host_vars/${deployParams.Host}_BW/ManualChangesConfiguration.conf ./${deployParams.Host}/BW_Deployment/scripts/PostDeploymentChanges"
		echo "Engines in Deploy function : ${deployParams.engines}"
		//Run ansible playbook to generate artefacts for environment
		 ansiColor('xterm') {
		 ansiblePlaybook(playbook: "./${deployParams.Host}/BW_Deployment/generate.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Host}_BW", repo_group_id: "${deployParams.nexus_group_id}", repo_user: "${deployParams.nexus_user}", repo_pw: "${deployParams.nexus_passwd}", repo_repo_id: "${deployParams.nexus_repo_id}", repo_url: "${deployParams.nexus_url}", engines: "${deployParams.engines}", datetime: "${deployParams.datetime}", crq_num: "${deployParams.crq_no}", engines_list: "${deployParams.engines_list}", release: "${deployParams.release}", onlyGVChange: "${deployParams.onlyGVChange}", EnvPrefix: "${deployParams.EnvPrefix}", deployment_type: "${deployParams.deployment_type}", folderName: "${deployParams.folderName}", bw_folder_release: "${deployParams.bw_folder_release}", engine_group:"${deployParams.engine_group}"])

		}
		// Remove files generated in this iteration
		sh "rm -rf ./${deployParams.Host}_Conf/conf/*"
		sh "rm -rf ./${deployParams.Host}/BW_Deployment/conf/*"
		
    }
}


/*BW Generate Function for BW Restarts
Input : 
Host
datetime
crq_no
engines_list
deployment_type
folderName
bw_folder_release
engine_group
*/

def generate_bw_restart(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{
		checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
		// create directory with name conf to copy config files
		sh "mkdir -p ./${deployParams.Host}/BW_Deployment/conf"
		sh "cp -r ./${deployParams.Host}_Conf/conf/* ./${deployParams.Host}/BW_Deployment/conf"
        sh "mkdir -p ./${deployParams.Host}/BW_Deployment/host_vars/${deployParams.Host}_BW"
		// Copy Environment specififc files to Ansible Host Vars 
		sh "cp -r ./ENV/BW_Configuration/${deployParams.Host}/* ./${deployParams.Host}/BW_Deployment/host_vars/${deployParams.Host}_BW"
		// Copy Manual Changes conf file from host vars to script folder
		sh "mv ./${deployParams.Host}/BW_Deployment/host_vars/${deployParams.Host}_BW/ManualChangesConfiguration.conf ./${deployParams.Host}/BW_Deployment/scripts/PostDeploymentChanges"
		echo "Engines in Deploy function : ${deployParams.engines}"
		//Run ansible playbook to generate artefacts for environment
		 ansiColor('xterm') {
		 ansiblePlaybook(playbook: "./${deployParams.Host}/BW_Deployment/generateOnlyRestarts.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Host}_BW", datetime: "${deployParams.datetime}", crq_num: "${deployParams.crq_no}", engines_list: "${deployParams.engines_list}", release: "${deployParams.release}", deployment_type: "${deployParams.deployment_type}", folderName: "${deployParams.folderName}", bw_folder_release: "${deployParams.bw_folder_release}", engine_group:"${deployParams.engine_group}"])

		}
		// Remove files generated in this iteration
		sh "rm -rf ./${deployParams.Host}_Conf/conf/*"
		sh "rm -rf ./${deployParams.Host}/BW_Deployment/conf/*"
		
    }
}



/*BW Deploy Function 
Input : 
Host
engines
datetime
crq_no
engines_list
release
onlyGVChange
appDynamics
FolderName
deployment_type
*/

def bw_deploy(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{
      //Run ansible playbook to generate artefacts for environment
	   ansiColor('xterm') {
		 ansiblePlaybook(playbook: "./${deployParams.Host}/BW_Deployment/deploy.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Host}_BW", engines: "${deployParams.engines}", datetime: "${deployParams.datetime}", crq_num: "${deployParams.crq_no}", engines_list: "${deployParams.engines_list}", release: "${deployParams.release}", onlyGVChange: "${deployParams.onlyGVChange}", appDynamics: "${deployParams.appDynamics}", FolderName: "${deployParams.FolderName}", deployment_type: "${deployParams.deployment_type}", bw_folder_release: "${deployParams.bw_folder_release}", engine_group: "${deployParams.engine_group}", EnvironmentRepository: "${deployParams.EnvironmentRepository}"])

		}
    }
}

/*Function to remove configs based on other component deployments 
Input : 
Host
engines_list : list of engines separated by ;
datetime
crq_no

*/

def bw_remove_config(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{
      //Run ansible playbook to generate artefacts for environment
	   ansiColor('xterm') {
		 ansiblePlaybook(playbook: "./${deployParams.Host}/BW_Deployment/removeConfig.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Host}_BW", engines_list: "${deployParams.engines_list}", datetime: "${deployParams.datetime}", crq_num: "${deployParams.crq_no}", folderName: "${deployParams.folderName}", bw_folder_release: "${deployParams.bw_folder_release}", engine_group:"${deployParams.engine_group}"])

		}
    }
}

/*Function to create rollback configs based on bw restart issue 
Input : 
Host
engines_list : list of succesfully restarted engines separated by ;
datetime
crq_no
removeConfig

*/

def bw_rollback_config_generate(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{
      //Run ansible playbook to generate rollback config for environment
	   ansiColor('xterm') {
		 ansiblePlaybook(playbook: "./${deployParams.Host}/BW_Deployment/rollbackConfigGeneration.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Host}_BW", engines_list: "${deployParams.engines_list}", datetime: "${deployParams.datetime}", crq_num: "${deployParams.crq_no}", removeConfig: "${deployParams.removeConfig}", folderName: "${deployParams.folderName}", bw_folder_release: "${deployParams.bw_folder_release}", engine_group:"${deployParams.engine_group}"])

		}
    }
}

/*Function to remove configs based on other component deployments 
Input : 
Host
host : list of engines separated by ;
datetime
crq_no

*/

def bw_restart(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{
      //Run ansible playbook to generate artefacts for environment
	   ansiColor('xterm') {
		 ansiblePlaybook(playbook: "./${deployParams.Host}/BW_Deployment/restartEngines.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Host}_BW", datetime: "${deployParams.datetime}", crq_num: "${deployParams.crq_no}", folderName: "${deployParams.folderName}", bw_folder_release: "${deployParams.bw_folder_release}", engine_group:"${deployParams.engine_group}", engines_list:"${deployParams.engines_list_restart}"])

		}
    }
}

/*Function to rollback BW changes
Input : 
Host
datetime
crq_no

*/

def bw_rollback(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{
      //Run ansible playbook to generate artefacts for environment
	   ansiColor('xterm') {
		 ansiblePlaybook(playbook: "./${deployParams.Host}/BW_Deployment/rollbackDeployedEngines.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Host}_BW", datetime: "${deployParams.datetime}", crq_num: "${deployParams.crq_no}", folderName: "${deployParams.folderName}", bw_folder_release: "${deployParams.bw_folder_release}", engine_group:"${deployParams.engine_group}", EnvironmentRepository: "${deployParams.EnvironmentRepository}", engines_list:"${deployParams.engines_list}"])

		}
    }
}

/*Function to rollback for RB BW changes
Input : 
Host
datetime
crq_no

*/

def bw_rollback_RB(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{
      //Run ansible playbook to generate artefacts for environment
	   ansiColor('xterm') {
		 ansiblePlaybook(playbook: "./${deployParams.Host}/BW_Deployment/ExplicitRollbackDeployedEngines.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Host}_BW", datetime: "${deployParams.datetime}", crq_num: "${deployParams.crq_no}", folderName: "${deployParams.folderName}", bw_folder_release: "${deployParams.bw_folder_release}", engine_group:"${deployParams.engine_group}", EnvironmentRepository: "${deployParams.EnvironmentRepository}", engines_list:"${deployParams.engines_list}"])

		}
    }
}

/*Function to create deployment tool
Input : 
Host
datetime
crq_no

*/	


def bw_create_deployment_tool(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{
      //Run ansible playbook to generate artefacts for environment
	   ansiColor('xterm') {
		 ansiblePlaybook(playbook: "./automation/BW_Deployment/createDeploymentTool.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Host}_BW", datetime: "${deployParams.datetime}", crq_num: "${deployParams.crq_no}", folderName: "${deployParams.folderName}", bw_folder_release: "${deployParams.bw_folder_release}", EnvPrefix: "${deployParams.EnvPrefix}"])

		}
    }
}

/*Function to create deployment tool
Input : 
Host
datetime
crq_no

*/	


def bw_cleanUp(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{
      //Run ansible playbook to generate artefacts for environment
	   ansiColor('xterm') {
		 ansiblePlaybook(playbook: "./automation/BW_Deployment/cleanUp.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Host}_BW", datetime: "${deployParams.datetime}", crq_num: "${deployParams.crq_no}", folderName: "${deployParams.folderName}", bw_folder_release: "${deployParams.bw_folder_release}", engine_group: "${deployParams.engine_group}"])

		}
    }
}

/*Function to create rollback workspace based on bw restart issue 
Input : 
Host
engines_list : list of succesfully restarted engines separated by ;
datetime
crq_no
removeConfig

*/

def bw_rollback_config_prep(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{
      //Run ansible playbook to generate rollback config for environment
	   ansiColor('xterm') {
		 ansiblePlaybook(playbook: "./${deployParams.Host}/BW_Deployment/rollbackConfigPreparation.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Host}_BW", datetime: "${deployParams.datetime}", crq_num: "${deployParams.crq_no}", folderName: "${deployParams.folderName}", bw_folder_release: "${deployParams.bw_folder_release}", engine_group:"${deployParams.engine_group}"])

		}
    }
}


def create_tag(deployParams){
	
	// This function is to create tag for the given engine type and repository name.
	// Function calling: create_tag ENGINE_NAME: ENGINE_NAME, RELEASE: RELEASE, ENGINE_TYPE: ENGINE_TYPE, BW_VERSION: BW_VERSION, REPO_NAME: GIT_REPO_NAME.
	
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "APPLY_CONFIG"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: "https://github.vodafone.com/VFUK-INTEGRATION/${deployParams.REPO_NAME}.git"]]]
	
 	def majv = deployParams.RELEASE.split('CCS')[1].split('\\.')[0]
	def minv = deployParams.RELEASE.split('CCS')[1].split('\\.')[1]
	
	if(deployParams.ENGINE_TYPE == "OnlyGV"){
		// get the last tag created for this release. If it is existing , update the same tag.
		def last_tag = sh(returnStdout: true, script: "cd ./APPLY_CONFIG; git tag -l ${deployParams.ENGINE_NAME}_${majv}_${minv}_* | sort -V | tail -1").trim()
		println("DEBUG: last_tag is: " + last_tag)
		if(last_tag.length() != 0) {
			TAG_NAME = last_tag
		} else {
			TAG_NAME = "${ENGINE_NAME}_${majv}_${minv}_0"
		}
	} else if(deployParams.ENGINE_TYPE == "New" || deployParams.ENGINE_TYPE == "Existing"){
		TAG_NAME = "${ENGINE_NAME}_${deployParams.BW_VERSION}"
	} else if(deployParams.ENGINE_TYPE == "RESTART" && deployParams.FILE_DEPLOYMENT == "true") {
		// get the last tag created for this release. If it is existing , update the same tag.
		def last_tag = sh(returnStdout: true, script: "cd ./APPLY_CONFIG; git tag -l ${deployParams.ENGINE_NAME}_${majv}_${minv}_* | sort -V | tail -1").trim()
		println("DEBUG: last_tag is: " + last_tag)
		if(last_tag.length() != 0) {
			TAG_NAME = last_tag
		} else {
			TAG_NAME = "${ENGINE_NAME}_${majv}_${minv}_0"
		}				
	}
	println("DEBUG: command is: " + deployParams.REPO_NAME + ':' + TAG_NAME)
	if(TAG_NAME.length() != 0) {
		build job: 'TIL_PIPELINES/Common_Jobs/git_repo_tagging', parameters: [string(name: 'GIT_REPO_NAME', value: "${deployParams.REPO_NAME}"), string(name: 'TAG_NAME', value: "${TAG_NAME}")]
		//[CICD-539]: Insert Deployment metadata to release notes DB. return BW TAG created.
		return "${TAG_NAME}"
	}
}


/* Function to generate app conf for existing engines in lower environment
Input : Engine list , Hosts, ReleaseNumber, FolderName, Description,
*/										
def generate_conf_files_existing_engines_lower_env(deployParams) {
	
	// checkout Application configuration repository
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}_Conf"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_BW_Application_Configuration.git']]]
	
	//[CICD-1332]: Fix to refer the exact REPO for getting appconf file.
	def NEXUS_REPO = "SIT_REPO"
	
    // make a directory with conf
	sh "mkdir -p ./${deployParams.Host}_Conf/conf"
    echo "${deployParams.engines}"
	echo "${deployParams.folderName}"
	echo "${deployParams.description}"
	//echo "${deployParams.instances}"
    def engine_list = deployParams.engines.split(';')
	for (txt in engine_list) {
			echo "${txt}"
			def engine = txt.split(':')
			def eng_conf = engine[0]
			def eng_ver = engine[1]
			echo eng_conf
			// [CICD-193: FIX] - Checkout repository using tag to get the linked configuration.
			// [CICD-1719: FIX] - Fail the pipeline when checkout tag is not found.
			if(deployParams.use_tag != "no"){
				def eng_git_tag = eng_conf + '_' + eng_ver
				def temp = sh(returnStdout: true, script: "cd ${deployParams.Host}_Conf; git checkout master; [[ \$(git tag --list | grep ${eng_git_tag}) ]] && git checkout tags/${eng_git_tag} || { echo \"ERROR: ${eng_git_tag} is not available for checkout. Please follow up with DEV team\"; exit 1; }").trim()
			}
			
			// create directory if does not exist
			sh "mkdir -p ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}"
			//[CICD-1332]: Fix to refer the exact REPO for getting appconf file.
			sh "curl -o ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf  http://195.233.197.150:8081/repository/${NEXUS_REPO}/TIL_BW/${eng_conf}/${eng_ver}/${eng_conf}-${eng_ver}.appconf"
			// Updating folder name in app.conf
			if(deployParams.folderName == "None"){
				println("Folder Name is None , no update is required")
			}
            else{
			 sh  "sed -i '/FolderName=/ s/=.*/=${deployParams.folderName}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
			}	
			// update values of app.conf with inputs provided during deployment
			// update description field
			sh  "sed -i '/description=/ s/=.*/=${deployParams.description}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
			// update release field
			sh  "sed -i '/releaseName=/ s/=.*/=${deployParams.ReleaseNumber}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
			//identifying engine name
			def common_eng_name = sh(script:"cat ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf | grep 'appendClasspath' | awk -F '.par' '{print \$1}'" ,returnStdout: true).trim()
            echo  "common_eng_name : $common_eng_name"
			// removing instance count parameter
            //sh  "sed -i '/.*.par.instanceCount*/d' ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
			// Removing records in app conf
			sh  "sed -i '/.*\\.par\\..*/d' ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
            
			// calling append and prepend function
			add_append_prepend_from_template appConfTemplate_path:"${WORKSPACE}/ENV/BW_Configuration/${deployParams.Host}/AppendPrependConfiguration.conf", appConf_path:"${WORKSPACE}/${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}", engine:"${eng_conf}", common_engine:"${common_eng_name}"
			// copy engine config files to single location for deployment job
			sh "cp ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/* ./${deployParams.Host}_Conf/conf"
			sh "cp ./${deployParams.Host}_Conf/BW_Configurations/${eng_conf}/* ./${deployParams.Host}_Conf/conf"
		  }
}



/* Function to generate conf for new engines in lower environment
Input : 
Enginelist - List of engines , 
Environmet - Deployment environment
Host - Target Host ideally environment
ReleaseNumber - Release Number
Templetefilepath - New Engines app conf template path
Description - Descrition used in admin console
*/										
def generate_conf_files_new_engines_lower_env(deployParams) {
	
    
	// checkout Application configuration repository
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}_Conf"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_BW_Application_Configuration.git']]]
	
	//[CICD-1332]: Fix to refer the exact REPO for getting appconf file.
	def NEXUS_REPO = "SIT_REPO"
    
	// make a directory with conf
	sh "mkdir -p ./${deployParams.Host}_Conf/conf"
   
	//echo "${deployParams.instances}"
    def engine_list = deployParams.engines.split(';')
	for (txt in engine_list) {
			echo "${txt}"
			def checkpoint
			def engine = txt.split(':')
			def eng_conf = engine[0]
			def eng_ver = engine[1]
			echo eng_conf
			
			// [CICD-193: FIX] - Checkout repository using tag to get the linked configuration.
			// [CICD-1719: FIX] - Fail the pipeline when checkout tag is not found.
			if(deployParams.use_tag != "no"){
				def eng_git_tag = eng_conf + '_' + eng_ver
				def temp = sh(returnStdout: true, script: "cd ${deployParams.Host}_Conf; git checkout master; [[ \$(git tag --list | grep ${eng_git_tag}) ]] && git checkout tags/${eng_git_tag} || { echo \"ERROR: ${eng_git_tag} is not available for checkout. Please follow up with DEV team\"; exit 1; }").trim()			
			}
			
			// create directory if does not exist
			sh "mkdir -p ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}"
			//[CICD-1332]: Fix to refer the exact REPO for getting appconf file.
			sh "curl -o ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf  http://195.233.197.150:8081/repository/${NEXUS_REPO}/TIL_BW/${eng_conf}/${eng_ver}/${eng_conf}-${eng_ver}.appconf"
			
			// identify par name for common engines which have differnt par name 
            //Remove par parameters
			def common_eng_name = sh(script:"cat ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf | grep 'appendClasspath' | awk -F '.par' '{print \$1}'" ,returnStdout: true).trim()
            echo  "common_eng_name : $common_eng_name"
			// First get values from template file for the engine passed.
	        def lines = new File("${WORKSPACE}/ENV/BW_Configuration/${deployParams.Host}/Engines_Template.txt").readLines()
			def matched_engine = lines.findAll { it.contains("${eng_conf}|") }[0]
	        if(matched_engine && !matched_engine.empty) {
				//Reading app.conf file download from Nexus
				def appconf_file = "${WORKSPACE}/${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
				// Start updating values from template.
				if(matched_engine.split("\\|")[1] != null) {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.MaxHeapSize=", "par.MaxHeapSize=" + matched_engine.split("\\|")[1].toString()) 
                 }
				if(matched_engine.split("\\|")[2] != null) {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.LogfileCount=", "par.LogfileCount=" + matched_engine.split("\\|")[2].toString()) 
				}
				if(matched_engine.split("\\|")[3] != null) {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.LogfileSize=", "par.LogfileSize=" + matched_engine.split("\\|")[3].toString()) 
				}
				if(matched_engine.split("\\|")[4] != null) {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.threadCount=", "par.threadCount=" + matched_engine.split("\\|")[4].toString()) 
				}		
				if(matched_engine.split("\\|")[5] != null) {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.initHeapSize=", "par.initHeapSize=" + matched_engine.split("\\|")[5].toString()) 
				}
				if(matched_engine.split("\\|")[6] != null) {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.threadStackSize=", "par.threadStackSize=" + matched_engine.split("\\|")[6].toString()) 
				}
				if(matched_engine.split("\\|")[7] == "true") {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.isFT=false", "par.isFT=" + matched_engine.split("\\|")[7].toString()) 
				}
				if(matched_engine.split("\\|")[8] != null) {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.FTWeight=", "par.FTWeight=" + matched_engine.split("\\|")[8].toString())
				}
				if(matched_engine.split("\\|")[9] != null) {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.FTHeartbeatInterval=", "par.FTHeartbeatInterval=" + matched_engine.split("\\|")[9].toString())
				}
				if(matched_engine.split("\\|")[10] != null) {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.FTActivationInterval=", "par.threadCount=" + matched_engine.split("\\|")[10].toString())
				}
				if(matched_engine.split("\\|")[11] != null) {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.FTPreperationDelay=", "par.FTPreperationDelay=" + matched_engine.split("\\|")[11].toString())
				}
				if(matched_engine.split("\\|")[12] != null) {
					writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.instanceCount=4", "par.instanceCount=" + matched_engine.split("\\|")[12].toString())
				}
				
				if(matched_engine.split("\\|")[13] == "true") {
					echo "checkpoint true condition"
                    def appconf_file1 = new File("${WORKSPACE}/${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf")
				
					appconf_file1 = appconf_file1.append("${common_eng_name}.par.CheckPointSelected=" + matched_engine.split("\\|")[14].toString())
					
				}

			}
            else{
				println("DEBUG: engine ${eng_conf} not found in new engines template file.")
				//Reading app.conf file download from Nexus
				def appconf_file = "${WORKSPACE}/${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
				
				echo "instance count from script ${deployParams.instanceCount}"
				writeFile file: appconf_file, text: readFile(appconf_file).replaceAll("par.instanceCount=4", "par.instanceCount=" + deployParams.instanceCount) 
				sh "cat ${appconf_file}"
            }
             			
			// update Folder Name in app.conf with inputs provided during deployment
			if(deployParams.folderName == "None"){
				println("Folder Name is None , no update is required")
			}
            else{
			   sh  "sed -i '/FolderName=/ s/=.*/=${deployParams.folderName}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"	
            }				
			// update description field
			sh  "sed -i '/description=/ s/=.*/=${deployParams.description}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
			// update release field
			sh  "sed -i '/releaseName=/ s/=.*/=${deployParams.ReleaseNumber}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"				
			// calling update append and prepend function
			update_append_prepend_from_template appConfTemplate_path:"${WORKSPACE}/ENV/BW_Configuration/${deployParams.Host}/AppendPrependConfiguration.conf", appConf_path:"${WORKSPACE}/${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}", engine:"${eng_conf}"
			// copy engine config files to single location for deployment job
			sh "cp ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/* ./${deployParams.Host}_Conf/conf"
			sh "cp ./${deployParams.Host}_Conf/BW_Configurations/${eng_conf}/* ./${deployParams.Host}_Conf/conf"
		  }
}



// Generate app.conf files required for BW GV change deployment
/* Function to generate conf for only GV changes in lower environments
Input : 
Enginelist - List of engines , 
Host - Target Host ideally environment
ReleaseNumber - Release Number
Description - Descrition used in admin console
*/

def generate_conf_files_gv_change_lower_env(deployParams) {
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}_Conf"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_BW_Application_Configuration.git']]]
    // make a directory with conf
	sh "mkdir -p ./${deployParams.Host}_Conf/conf"
    echo "${deployParams.engines}"
    def engine_list = deployParams.engines.split(';')
	
	def majv = deployParams.ReleaseNumber.split('CCS')[1].split('\\.')[0]
	def minv = deployParams.ReleaseNumber.split('CCS')[1].split('\\.')[1]
	
	for (txt in engine_list) {
		echo "${txt}"
		echo "before split"
		def engine = txt.split(':')
		def eng_conf = engine[0]
		echo eng_conf
		echo "after split"

		// [CICD-193: FIX] - Checkout repository using tag to get the linked configuration.
		// [CICD-1719: FIX] - Fail the pipeline when checkout tag is not found.
		if(deployParams.use_tag != "no"){
			def last_tag = sh(returnStdout: true, script: "cd ${deployParams.Host}_Conf; git tag -l ${eng_conf}_${majv}_${minv}_\"[0-9]\"* | sort -V | tail -1").trim()
			if(last_tag.length() != 0){
				def temp = sh(returnStdout: true, script: "cd ${deployParams.Host}_Conf; git checkout master; [[ \$(git tag --list | grep ${last_tag}) ]] && git checkout tags/${last_tag} || { echo \"ERROR: ${last_tag} is not available for checkout\"; exit 1; }").trim()
			} else {
				def temp = sh(returnStdout: true, script: "echo \"ERROR: No Config is available for checkout. Please follow up with DEV team\"; exit 1").trim()
			}
		}

		// create directory if does not exist
		sh "mkdir -p ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}"
		// Rename common gvchange app conf template to engine specific
		sh "cp ./${deployParams.Host}_Conf/GVChange_Configurations/GVChange.appconf ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
		
		// update Folder Name in app.conf with inputs provided during deployment
		if(deployParams.folderName == "None"){
			println("Folder Name is None , no update is required")
		}
		else{
		   sh  "sed -i '/FolderName=/ s/=.*/=${deployParams.folderName}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"	
		}
		// update cvsVersion field
		//sh  "sed -i '/CVSVersion=/ s/=.*/=${deployParams.cvsVersion}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
		
		// update release field
		sh  "sed -i '/releaseName=/ s/=.*/=${deployParams.ReleaseNumber}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
		
		// update description field
		sh  "sed -i '/description=/ s/=.*/=${deployParams.description}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
		//sh  "sed -i '/${eng_conf}.par.instanceCount=/ s/=.*/=${deployParams.instances}/'  ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/${eng_conf}.appconf"
		// copy engine config files to single location for deployment job
		sh "cp ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}/* ./${deployParams.Host}_Conf/conf"
		sh "cp -r ./${deployParams.Host}_Conf/BW_Configurations/${eng_conf}/* ./${deployParams.Host}_Conf/conf"	
	  }
}

def get_domainAppsList(deployParams) {

		// This function is to generate Applications.txt file from domain with all the list of engines currently deployed in environment.
		
		// Remove if file already exists in destination directory.
		//sh "[[ -f ${WORKSPACE}/ENV/BW_Configuration/${deployParams.environment}/Applications.txt ]] && rm  -f ${WORKSPACE}/ENV/BW_Configuration/${deployParams.environment}/Applications.txt"

		// Get domain details.
		
		def TRA_HOME = sh(script:"cat ${WORKSPACE}/ENV/BW_Configuration/${deployParams.environment}/Deployment.properties | grep 'TRA_HOME' | awk -F '=' '{print \$2}'" ,returnStdout: true).trim()
		def Domain = sh(script:"cat ${WORKSPACE}/ENV/BW_Configuration/${deployParams.environment}/Deployment.properties | grep 'Domain=' | awk -F '=' '{print \$2}'" ,returnStdout: true).trim()
		def DomainUser = sh(script:"cat ${WORKSPACE}/ENV/BW_Configuration/${deployParams.environment}/Deployment.properties | grep 'DomainUser=' | awk -F '=' '{print \$2}'" ,returnStdout: true).trim()
		def DomainPwd = sh(script:"cat ${WORKSPACE}/ENV/BW_Configuration/${deployParams.environment}/Deployment.properties | grep 'DomainPwd=' | awk -F '=' '{print \$2}'" ,returnStdout: true).trim()
		ansiColor('xterm') {
			ansiblePlaybook(playbook: "${WORKSPACE}/AUTOMATION/Get_Domain_AppList/generateDomainApps.yml", colorized: true, extras:'-v', extraVars: [host: "${deployParams.Host}_BW", datetime: "${deployParams.datetime}", TRA_HOME: TRA_HOME, domainName: Domain, domainUser: DomainUser, domainPW: DomainPwd])
			// Move generated file to ENV folder.
			if(fileExists("${WORKSPACE}/AUTOMATION/Get_Domain_AppList/Applications.txt")) {
				sh "rm -f ${WORKSPACE}/ENV/BW_Configuration/${deployParams.environment}/Applications.txt"
				sh "cp ${WORKSPACE}/AUTOMATION/Get_Domain_AppList/Applications.txt ${WORKSPACE}/ENV/BW_Configuration/${deployParams.environment}/"
			}
		}
}


// Restart BW Admin and hawk for ansible group ending _BWAdmin and _Hawk 
/* 
Input : 
restartEnv - Environment to restart BW Admin and Hawk 
script_folder - BW_Admin_Activities folder in TIL Automation
*/
def restartBWAdminHawk(deployParams){ 
    inputRestartBWHawk = input(id: 'inputRestartBWHawk', message: "Do you want to restart BW and Hawk?", parameters: [booleanParam(defaultValue: true, description: 'Check to restart, uncheck to skip the stage', name: 'Restart BW and Hawk')])
    println("${deployParams.script_folder}")
    println("${deployParams.restartEnv}")
    if(inputRestartBWHawk)
    {
        println("Restart BW and Hawk started by user")
        ansiColor('xterm') {
        ansiblePlaybook (playbook: "${deployParams.script_folder}/restartAdmin.yml", colorized: true, extras: '', extraVars: [host: "${deployParams.restartEnv}_BWAdmin"])
        ansiblePlaybook (playbook: "${deployParams.script_folder}/restartHawk.yml", colorized: true, extras: '', extraVars: [host: "${deployParams.restartEnv}_Hawk"])
                        }
        restartSummary = sh (script: "cat ${deployParams.script_folder}/restartBWHawkSummary.log",returnStdout: true)
        restartStatus = sh (script: " grep 'Post.*not running' ${deployParams.script_folder}/restartBWHawkSummary.log",returnStatus: true)
        if(restartStatus)
            input(message: "Restart Success")
        else
            input(message: "Restart Failure \n\n${restartSummary}")
    }
    else
    {
        println("Restart BW and Hawk not opted by user")
    }
}

return this
