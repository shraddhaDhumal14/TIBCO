import com.cwctravel.hudson.plugins.extended_choice_parameter.ExtendedChoiceParameterDefinition
import hudson.tasks.Mailer;
import hudson.model.User;

def prepration ()
{   
	sh """ > hosts """
	INSTALL_TYPE.split(',').each { type ->
		//EMS_10_2,EMS_10_2_HF1,EMS_10_2_HF3,EMS_10_2_HF4,RV_8_6,RV_8_6_HF1,RV_8_6_HF3,TRA			  
					  									
					//create_hosts_file
					MAP['Install']["${type}"] = "true"
					def i =1;
					sh """ echo '\n[${type}]' >> hosts """
					SERVER_IP.split(';').each { IP ->
					sh """ echo '${type}_${i} ansible_host=${IP} ansible_port=22 ansible_user=tibco ansible_private_key_file=~/.ssh/id_rsa' >> hosts """
					i++;
					}
					 
				}
				println( MAP['Install'] )
				// sh "rm "${params.SOURCE}"/install/TIBCO_Installation_Automation/hosts"
				sh """ cp -u ./hosts "${params.SOURCE}"/install/TIBCO_Installation_Automation """
				sh """ chmod u+x,g+w,o+r "${params.SOURCE}"/install/TIBCO_Installation_Automation/hosts """
}

def installFunction ( host_name , install_type )
{
	env.PIPELINE_URL = "$BUILD_URL"				
					
				sh """ cd "${params.SOURCE}"/install/TIBCO_Installation_Automation; ansible-playbook "${params.SOURCE}"/install/TIBCO_Installation_Automation/TIBCODisplayInformation.yml -e host="${host_name}"  """
				
				input 'Proceed or Abort?'
				
				sh """ cd "${params.SOURCE}"/install/TIBCO_Installation_Automation; ansible-playbook "${params.SOURCE}"/install/TIBCO_Installation_Automation/TIBCOPipeSoftwareInstall.yml -e host="${host_name}" -e SOURCE="${params.SOURCE}" -e DESTINATION="${params.DESTINATION}" -e ENV_VAR="${params.ENV_VAR}" 2>&1 | tee "${params.SOURCE}"/install/TIBCO_Installation_Automation/Automation_Installation.log """	
				
				failcount = sh (script: """grep 'Fail Pipeline' "${params.SOURCE}"/install/TIBCO_Installation_Automation/Automation_Installation.log|wc -l""",returnStdout: true).trim()
				
				println("Failure count = ${failcount}")
				
				if(failcount.toInteger() > 0)
				{
					println("Failing pipeline")
					currentBuild.result = 'FAILURE'
				}
				println("Done")
				
				emailContent=" ${ install_type } is present in ${params.SERVER_IP}. Please review the changes"
    
				emailext mimeType: 'text/html', 
				subject: "${ install_type } - SUCCESSFUL",  
				from:"BWInstalltion@vodafone.com", 
				to: "${emailRecipents}", 
				body: "${emailContent}"	
}
def hotFixInstall (host_name , hf_type)
{
	sh """ cd "${params.SOURCE}"/install/TIBCO_Installation_Automation; ansible-playbook "${params.SOURCE}"/install/TIBCO_Installation_Automation/TIBCODisplayInformation.yml -e host="${host_name}" -e SOURCE="${params.SOURCE}" -e DESTINATION="${params.DESTINATION}" -e ENV_VAR="${params.ENV_VAR}" """
					
	input 'Proceed or Abort?'
					
	sh """ cd "${params.SOURCE}"/install/TIBCO_Installation_Automation; ansible-playbook "${params.SOURCE}"/install/TIBCO_Installation_Automation/TIBCOPipeHotfixInstall.yml -e host="${host_name}" -e SOURCE="${params.SOURCE}" -e DESTINATION="${params.DESTINATION}" -e ENV_VAR="${params.ENV_VAR}" 2>&1 | tee "${params.SOURCE}"/install/TIBCO_Installation_Automation/Automation_Installation.log """
	
	failcount = sh (script: """grep 'Fail Pipeline' "${params.SOURCE}"/install/TIBCO_Installation_Automation/Automation_Installation.log|wc -l""",returnStdout: true).trim()
				
	println("Failure count = ${failcount}")
				
	if(failcount.toInteger() > 0)
	{
		println("Failing pipeline")
		currentBuild.result = 'FAILURE'
	}
	println("Done")
	emailContent=" ${hf_type} is present in ${params.SERVER_IP}"
    
				emailext mimeType: 'text/html', 
				subject: "${ hf_type }  - SUCCESSFUL",  
				from:"BWInstalltion@vodafone.com", 
				to: "${emailRecipents}", 
				body: "${emailContent}"
}

SUBMITTED_DATE = ""
emailContent = ""

MAP = [:]

//EMS_10_2,EMS_10_2_HF1,EMS_10_2_HF3,EMS_10_2_HF4,RV_8_6,RV_8_6_HF1,RV_8_6_HF4,TRA_5_12,TRA_5_12_HF1,BW_5_15,BW_5_15_HF3,BW_DD_2_0,BW_DD_2_0_HF4,BW_EJB_5_4,BW_RJSON_2_1,BW_RJSON_2_1_HF10,BW_ADMIN_5_12,BW_ADMIN_5_12_HF

MAP['Install'] = ['EMS_10_2':'false', 'EMS_10_2_HF1':'false', 'EMS_10_2_HF3':'false', 'EMS_10_2_HF4':'false',  'RV_8_6':'false',  'RV_8_6_HF1':'false',  'RV_8_6_HF4':'false',  'TRA_5_12':'false','HAWK_6_2':'false' , 'TRA_5_12_HF1':'false', 'BW_5_15':'false', 'BW_5_15_HF3':'false', 'BW_DD_2_0':'false', 'BW_DD_2_0_HF4':'false', 'BW_EJB_6_1':'false','BW_RJSON_2_1':'false', 'BW_RJSON_2_1_HF10':'false', 'BW_ADMIN_5_12':'false','BW_ADMIN_5_12_HF':'false']
//emailRecipents = "devops-vfuk-integration@vodafone.com;rajesh.singh4@vodafone.com;asmita.khatate@vodafone.com"
emailRecipents = "devansh.patil@vodafone.com"
pipeline {
    agent any   

stages {
	stage('Prepration') {
		steps {
			script{
				prepration()
                }
            }
        }
	stage('Install EMS') {
		when {
				expression { "${MAP['Install']['EMS_10_2']}" == "true" }
			}
		steps {
			script{
					installFunction("EMS_10_2","EMS_10.2")
                }
            }
        }        

    stage('EMS HotFix 1 Install'){
		when {
				expression { "${MAP['Install']['EMS_10_2_HF1']}" == "true" }
			}
		steps {
			script{				  		
					hotFixInstall ( "EMS_10_2_HF1" ,"EMS_HF1")					  	 
			    }					   
			}
        }
    stage('EMS HotFix 3 Install'){
		when {
				expression { "${MAP['Install']['EMS_10_2_HF3']}" == "true" }
			}
		steps {
			script{				  		
					hotFixInstall ( "EMS_10_2_HF3" ,"EMS_HF3")					  	 
			    }					   
			}
        }
    stage('EMS HotFix 4 Install'){
		when {
				expression { "${MAP['Install']['EMS_10_2_HF4']}" == "true" }
			}
		steps {
			script{				  		
					hotFixInstall ( "EMS_10_2_HF4" ,"EMS_HF4")					  	 
			    }					   
			}
        }
	stage('Install RV') {
		when {
				expression { "${MAP['Install']['RV_8_6']}" == "true" }
			}
		steps {
			script{
					installFunction("RV_8_6","RV_8.6.1")
                }
            }
        }
    stage('RV HotFix 1 Install'){
		when {
				expression { "${MAP['Install']['RV_8_6_HF1']}" == "true" }
			}
		steps {
			script{				  		
					hotFixInstall ( "RV_8_6_HF1" ,"RV_HF1")					  	 
			    }					   
			}
        }
    stage('RV HotFix 4 Install'){
		when {
				expression { "${MAP['Install']['RV_8_6_HF4']}" == "true" }
			}
		steps {
			script{				  		
					hotFixInstall ( "RV_8_6_HF4" ,"RV_HF4")					  	 
			    }					   
			}
        }
	stage('Install TRA') {
		when {
				expression { "${MAP['Install']['TRA_5_12']}" == "true" }
			}
		steps {
			script{
					installFunction("TRA_5_12","TRA_5.12.3")
                }
            }
        }

	stage('Install HAWK') {
		when {
				expression { "${MAP['Install']['HAWK_6_2']}" == "true" }
			}
		steps {
			script{
					installFunction("HAWK_6_2","HAWK_6.2.3")
                }
            }
        }
 /*   stage('TRA HotFix 1 Install'){
		when {
				expression { "${MAP['Install']['TRA_5_12_HF1']}" == "true" }
			}
		steps {
			script{				  		
					hotFixInstall ( "TRA_5_12_HF1" ,"TRA_HF1")					  	 
			    }					   
			}
        }*/
	stage('Install BW') {
		when {
				expression { "${MAP['Install']['BW_5_15']}" == "true" }
			}
		steps {
			script{
					installFunction("BW_5_15","BW_5.15")
                }
            }
        }
    stage('BW HotFix 3 Install'){
		when {
				expression { "${MAP['Install']['BW_5_15_HF3']}" == "true" }
			}
		steps {
			script{				  		
					hotFixInstall ( "BW_5_15_HF3" ,"BW_HF3")					  	 
			    }					   
			}
        }	
	stage('Install DATABASE DRIVER') {
		when {
				expression { "${MAP['Install']['BW_DD_2_0']}" == "true" }
			}
		steps {
			script{
					installFunction("BW_DD_2_0","BW_DD_2.0.6")
                }
            }
        }
    stage('DATABASE DRIVER HotFix 4 Install'){
		when {
				expression { "${MAP['Install']['BW_DD_2_0_HF4']}" == "true" }
			}
		steps {
			script{				  		
					hotFixInstall ( "BW_DD_2_0_HF4" ,"DD_HF4")					  	 
			    }					   
			}
        }	
	stage('Install BW EJB') {
		when {
				expression { "${MAP['Install']['BW_EJB_6_1']}" == "true" }
			}
		steps {
			script{
					installFunction("BW_EJB_6_1","BW_EJB_6.1")
                }
            }
        }
	stage('Install RJSON') {
		when {
				expression { "${MAP['Install']['BW_RJSON_2_1']}" == "true" }
			}
		steps {
			script{
					installFunction("BW_RJSON_2_1","BW_RJSON_2.1")
                }
            }
        }
    stage('RJSON HotFix 10 Install'){
		when {
				expression { "${MAP['Install']['BW_RJSON_2_1_HF10']}" == "true" }
			}
		steps {
			script{				  		
					hotFixInstall ( "BW_RJSON_2_1_HF10" ,"BW_RJSON_HF10")					  	 
			    }					   
			}
        }	
	stage('Install ADMIN') {
		when {
				expression { "${MAP['Install']['BW_ADMIN_5_12']}" == "true" }
			}
		steps {
			script{
					installFunction("BW_ADMIN_5_12","BW_ADMIN_5.12")
                }
            }
        }
    stage('ADMIN HotFix 1 Install'){
		when {
				expression { "${MAP['Install']['BW_ADMIN_5_12_HF1']}" == "true" }
			}
		steps {
			script{				  		
					hotFixInstall ( "BW_ADMIN_5_12_HF1" ,"BW_ADMIN_HF1")					  	 
			    }					   
			}
        }
    }
}
