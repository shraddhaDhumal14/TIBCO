import com.cwctravel.hudson.plugins.extended_choice_parameter.ExtendedChoiceParameterDefinition
import hudson.tasks.Mailer;
import hudson.model.User;

def GitClone(RepoName, TargetDirectory, BranchName )
{
    int retryCount = 0;
    def error = ""
    while (1) 
    {
       if( retryCount > 0 && retryCount % 3 ==0 )
       {
        input 'Proceed or Abort?'      
       }
       try 
	   {

            checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: "*/${BranchName}"]], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${TargetDirectory}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: "https://github.vodafone.com/VFUK-INTEGRATION/${RepoName}.git"]]]
            env.BP_ERROR_CODE = ""
			env.BP_ERROR_MSG = ""
            return true
       }
       catch(Exception ex) 
	   {
		    env.BP_ERROR_CODE = "203"
			env.BP_ERROR_MSG = "Github connection failed"
			println(env.BP_ERROR_CODE + " : " +  env.BP_ERROR_MSG)
			println("Github connection failed.")
			currentBuild.result = 'ABORTED'

            //println("Exception caught : " + ex + "while downloading Repo " +  RepoName); 
            //error = ex;
            //println("Sleeping for 5 seconds .... Will Retry "+ (retryCount+1))
            //println "Red Alert!! Inform CICD Team ++ Git Error ++ ${error}"
            sleep 5            
        }
        retryCount++
    }     
    return false       
}

def prepration ()
{   
	GitClone("TIL_Automation_Framework", "TIL_AUTOMATION", "master")
	def i =1;
	IP_ADDRESS.split(';').each { IP ->
					
					ENV_Sample_Name = sh (script: """grep ${IP} ${WORKSPACE}/TIL_AUTOMATION/Installation/Redis/serverInfo.txt | awk -F~ '{print \$5}'""",returnStdout: true).trim()
					
					if(ENV_Sample_Name.contains(params.ENV))
					{
						allIpCorrectionCheck = "true"
					}
					else
					{
						println("Enviroment name does not match with IP please check if you are inserting correct IP: ${IP}")
						allIpCorrectionCheck = "false"
						break;
						
					}
					
					}				
		
}

//emailRecipents = "devops-vfuk-integration@vodafone.com;rajesh.singh4@vodafone.com;asmita.khatate@vodafone.com"
emailRecipents = "devansh.patil@vodafone.com"
allIpCorrectionCheck = "true"
clusterCommand = ""
clusterIp = ""
clusterPort = ""
ENV_Sample_Name = ""
REMOTE_HOME = ""

pipeline {
    agent any   

stages {
	stage('Prepration') {
		steps {
			script{
				prepration()
                }
            }
        }
	stage('Installing Redis') {
		when {
				expression { "${allIpCorrectionCheck}" == "true" }
			}
		steps {
			script{
					
					IP_ADDRESS.split(';').each { IP ->						
						
						
						PORTS = sh (script: """grep ${IP} ${WORKSPACE}/TIL_AUTOMATION/Installation/Redis/serverInfo.txt | awk -F~ '{print \$2}'""",returnStdout: true).trim()
						
						LOCAL_HOME = sh (script: """grep ${IP} ${WORKSPACE}/TIL_AUTOMATION/Installation/Redis/serverInfo.txt | awk -F~ '{print \$3}'""",returnStdout: true).trim()
						
						REMOTE_HOME = sh (script: """grep ${IP} ${WORKSPACE}/TIL_AUTOMATION/Installation/Redis/serverInfo.txt | awk -F~ '{print \$4}'""",returnStdout: true).trim()

						ENV_Sample_Name = sh (script: """grep ${IP} ${WORKSPACE}/TIL_AUTOMATION/Installation/Redis/serverInfo.txt | awk -F~ '{print \$5}'""",returnStdout: true).trim()						
						
						ansiColor('xterm') {
							ansiblePlaybook(playbook: "./TIL_AUTOMATION/Installation/Redis/redisInstall.yml", colorized: true, extras:'', extraVars: [host: "${ENV_Sample_Name}", local_home_dir: "${LOCAL_HOME}", remote_home_dir: "${REMOTE_HOME}",ports:"${PORTS}",workspace:"${WORKSPACE}",ip_address:"${IP}", pkg_name:"redis-stable.tar.gz"])
						}			
						
					}										
                }
            }
        }
	stage('Creating Redis Cluster') {
		when {
				expression { "${allIpCorrectionCheck}" == "true" }
			}
		steps {
			script{
					println("Testing")
				    arr_IP_ADDRESS = IP_ADDRESS.split(';')
					clusterIp = "${arr_IP_ADDRESS[0]}"					
					
					IP_ADDRESS.split(';').each { IP ->
						
						PORTS = sh (script: """grep ${IP} ${WORKSPACE}/TIL_AUTOMATION/Installation/Redis/serverInfo.txt | awk -F~ '{print \$2}'""",returnStdout: true).trim()						
						
						REMOTE_HOME = sh (script: """grep ${IP} ${WORKSPACE}/TIL_AUTOMATION/Installation/Redis/serverInfo.txt | awk -F~ '{print \$4}'""",returnStdout: true).trim()											
						
						println("Value of IP is ${IP} ")
						println("Value of Cluster Ip is ${clusterIp}")
						if("${IP}".equals("${clusterIp}"))
					    {   
							println("Inside cluseter if condition")
							arr_PORTS = PORTS.split(':')
							clusterPort = "${arr_PORTS[0]}"
							println("port value is : ${clusterPort}")
					    }						
						PORTS.split(':').each { p ->
							
							clusterCommand += "$IP:$p"
							clusterCommand += " "
						}
					}
					
				    println("Command Genrated is : ${clusterCommand}")
					
					clusterHost = sh (script: """grep ${clusterIp} ${WORKSPACE}/TIL_AUTOMATION/Installation/Redis/serverInfo.txt | awk -F~ '{print \$5}'""",returnStdout: true).trim()
					
					ansiColor('xterm') {
							ansiblePlaybook(playbook: "./TIL_AUTOMATION/Installation/Redis/clusterCreation.yml", colorized: true, extras:'', extraVars: [host: "${clusterHost}", remote_home_dir: "${REMOTE_HOME}",clusterPort:"${clusterPort}",clusterCommand:"${clusterCommand }",clusterIp :"${clusterIp}"])
							}
					
					sh """ scp tibco@"${clusterIp}":"${REMOTE_HOME}"/clusterlogs ${WORKSPACE} """

					def emailContent="Dear User,<br>Cluster creation in completed please check the logs for your referance.<BR>Pipeline : ${BUILD_URL}<br> This is auto generated email. Please do not respond, in case you want to connect to DevSecOps team. Please contact us on - <b>devops-vfuk-integration@vodafone.com</b>.<br>Thank you,<br> DevSecOps Team"
					emailext mimeType: 'text/html',
                    attachmentsPattern: 'clusterlogs',					
					subject: "Redis_Automated_Installtion - Cluster Creation Completed",
					from:"RedisAutomatedInstallation@vodafone.com",
					to: "${emailRecipents}", 
					body: "${emailContent}"					
                }
            }
        }		
    }
}
