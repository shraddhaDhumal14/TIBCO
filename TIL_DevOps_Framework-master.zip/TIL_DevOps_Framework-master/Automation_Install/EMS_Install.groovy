import com.cwctravel.hudson.plugins.extended_choice_parameter.ExtendedChoiceParameterDefinition
import hudson.tasks.Mailer;
import hudson.model.User;

def hotFixInstall (host_name , hf_type)
{
	sh """ cd /opt/tibco/install/TIBCO_Installation_Automation; ansible-playbook /opt/tibco/install/TIBCO_Installation_Automation/TIBCODisplayInformation.yml -e host="${host_name}" """
					
	input 'Proceed or Abort?'
					
	sh """ cd /opt/tibco/install/TIBCO_Installation_Automation; ansible-playbook /opt/tibco/install/TIBCO_Installation_Automation/TIBCOHotfixInstall.yml -e host="${host_name}" """
	
	emailContent=" EMS Hotfix ${hf_type} is present in ${host_name}"
    
				emailext mimeType: 'text/html', 
				subject: "EMS 10.2 Hotfix - SUCCESSFUL",  
				from:"EMSInstalltion@vodafone.com", 
				to: "${emailRecipents}", 
				body: "${emailContent}"
}

SUBMITTED_DATE = ""
emailContent = ""
//emailRecipents = "devops-vfuk-integration@vodafone.com;rajesh.singh4@vodafone.com;asmita.khatate@vodafone.com"
emailRecipents = "devansh.patil@vodafone.com"
pipeline {
    agent any   

stages {
	stage('Install EMS') {
		when {
				expression { "${params.Install_type}" == "Only_EMS" || "${params.Install_type}" == "EMS_HF" }
			}
		steps {
			script{
				env.PIPELINE_URL = "$BUILD_URL"				
					
				sh """ cd /opt/tibco/install/TIBCO_Installation_Automation; ansible-playbook /opt/tibco/install/TIBCO_Installation_Automation/TIBCODisplayInformation.yml -e host="${params.HOST}" """
				
				input 'Proceed or Abort?'
				
				sh """ cd /opt/tibco/install/TIBCO_Installation_Automation; ansible-playbook /opt/tibco/install/TIBCO_Installation_Automation/TIBCOSoftwareInstall.yml -e host="${params.HOST}" 2>&1 | tee /opt/tibco/install/TIBCO_Installation_Automation/Automation_Installation.log """	
				
				failcount = sh (script: """grep 'Fail Pipeline' /opt/tibco/install/TIBCO_Installation_Automation/Automation_Installation.log|wc -l""",returnStdout: true).trim()
				
				println("Failure count = ${failcount}")
				
				if(failcount.toInteger() > 0)
				{
					println("Failing pipeline")
					currentBuild.result = 'FAILURE'
				}
				println("Done")
				
				emailContent=" EMS 10.2 is present in ${params.HOST}. Please review the changes"
    
				emailext mimeType: 'text/html', 
				subject: "EMS 10.2 - SUCCESSFUL",  
				from:"EMSInstalltion@vodafone.com", 
				to: "${emailRecipents}", 
				body: "${emailContent}"				
					
                }
            }
        }        

       stage('EMS HotFix Install'){
		   when {
				expression { "${params.Install_type}" == "Only_HF" || "${params.Install_type}" == "EMS_HF" }
			}
			steps {
				script{
					  
					  println("Selected HF's ${HotFix}")
					  HotFix.split(',').each { type ->
					  
					  if(type == "ALL")
					  {										
						 hotFixInstall ( "EMSHF1_10.2" ,"HF1")
					  	 hotFixInstall ( "EMSHF3_10.2" ,"HF3")
					  	 hotFixInstall ( "EMSHF4_10.2" ,"HF4")
						 break;
					  }
					  else
					  {
						  if(type == "HF1")
					  	  {
					  		  hotFixInstall ( "EMSHF1_10.2" ,"HF1")					
					  	  }
					  	  if(type == "HF3")
					  	  {
					  		  hotFixInstall ( "EMSHF3_10.2" ,"HF3")
						  }
					  	  if(type == "HF4")
					  	  {
					  		  hotFixInstall ( "EMSHF4_10.2" ,"HF4")
					  	  }
					  }  
				}
            }
        } 
	}
  }	
}	                    
