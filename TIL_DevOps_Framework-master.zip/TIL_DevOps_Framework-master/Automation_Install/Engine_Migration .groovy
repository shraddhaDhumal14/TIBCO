import com.cwctravel.hudson.plugins.extended_choice_parameter.ExtendedChoiceParameterDefinition
import hudson.tasks.Mailer;
import hudson.model.User;

def prepration ()
{   
	  
	  ADMIN_IP = sh(script: """grep ${ENVIRONMENT}_BW /etc/ansible/hosts | cut -f2 -d' '| cut -f2 -d=""",returnStdout: true).trim()
	  println( "Admin IP is ${ADMIN_IP}")
	  
	  checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "ENV"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_TestEnv_Configurations.git']]]

	  checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Automation"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
	  
	  sh """ dos2unix ${WORKSPACE}/ENV/BW_Configuration/"${ENVIRONMENT}"/Applications.txt"""
	  ENGINES.split(';').each { type ->		  
					 
	  MAP["${type}"] = ['PRESENT':'notpresent', 'BUS':'None']
      
								
	  MAP["${type}"]['PRESENT'] = sh (script: """grep -E -w "${type}"\$ ${WORKSPACE}/ENV/BW_Configuration/"${ENVIRONMENT}"/Applications.txt | wc -l""", returnStdout: true ).trim()
      println("${MAP["${type}"]['PRESENT']}")
	
	  if (MAP["${type}"]['PRESENT'] > 0)
	  {
	     MAP["${type}"]['BUS'] = sh (script: """grep -E -w "${type}"\$ ${WORKSPACE}/ENV/BW_Configuration/"${ENVIRONMENT}"/Applications.txt |cut -f1 -d/ """, returnStdout: true).trim()
		
	  }
	 else
	 {
		println(" Engine ${type} is not present in ${ENVIRONMENT} ")	
	 }
	 def i =1;
     println( MAP["${type}"] )
	}


}

def exportEngine()
{  
	sh """ mkdir -p XML_FOLDER """
	sh """ cd XML_FOLDER; rm -rf *.xml"""
	
	ansiColor('xterm') {
	  		ansiblePlaybook (playbook: "${WORKSPACE}/Automation/Engine_Migration/export_prep.yml", colorized: true, extras: '', extraVars: [host: "${ENVIRONMENT}_BW",tibco_home: "${TIBCO_HOME}"])
          }	
		  
	ENGINES.split(';').each { type ->
	  if (MAP["${type}"]['PRESENT'] > 0)
	    {
	      ansiColor('xterm') {
	  		ansiblePlaybook (playbook: "${WORKSPACE}/Automation/Engine_Migration/export.yml", colorized: true, extras: '', extraVars: [host: "${ENVIRONMENT}_BW",tibco_home: "${TIBCO_HOME}", engine_name: "${type}", sbus: "${MAP["${type}"]['BUS']}", domain_name:"${EXPORT_DOMAIN_NAME}", user_name:"${EXPORT_USER_NAME}",password:"${EXPORT_PASSWORD}" ])
          }		  
		  
		 // sh """scp tibco@${ADMIN_IP}:${TIBCO_HOME}/vodafone/Engine_Migration/${ENVIRONMENT}_BW/${type}.xml ${WORKSPACE}/XML_FOLDER/${type}.xml """
	  	
	    }
	   else
	   {
	  	println(" Engine ${type} is not present in ${ENVIRONMENT} ")	
	   }
	}	
	
	sh """scp tibco@${ADMIN_IP}:${TIBCO_HOME}/vodafone/Engine_Migration/${ENVIRONMENT}_BW/Success_Export_List.txt ${WORKSPACE}/XML_FOLDER/Success_Export_List.txt """
	sh """scp tibco@${ADMIN_IP}:${TIBCO_HOME}/vodafone/Engine_Migration/${ENVIRONMENT}_BW/Failed_Export_List.txt ${WORKSPACE}/XML_FOLDER/Failed_Export_List.txt """
	
	def export_success_file = "${WORKSPACE}/XML_FOLDER/Success_Export_List.txt"
	if(fileExists(export_success_file)) {
		def export_success_ouput = readFile("${WORKSPACE}/XML_FOLDER/Success_Export_List.txt")
		if (export_success_ouput.size() != 0) {			
			export_success_ouput.split('\n').each { export_engine ->
			if(export_engine.trim().size() != 0)
			{
				sh """scp tibco@${ADMIN_IP}:${TIBCO_HOME}/vodafone/Engine_Migration/${ENVIRONMENT}_BW/${export_engine}.xml ${WORKSPACE}/XML_FOLDER/${export_engine}.xml """
			}
		}
	}
	}
	Success_Export_Engines = sh(script: """cat ${WORKSPACE}/XML_FOLDER/Success_Export_List.txt |  tr '\n' ',' | sed 's/,\$//'""",returnStdout: true).trim()
	Failed_Export_Engines = sh(script: """cat ${WORKSPACE}/XML_FOLDER/Failed_Export_List.txt |  tr '\n' ',' | sed 's/,\$//'""",returnStdout: true).trim()
	emailContent=" Please find the XML of Successfully exported engines in attachment.<br> Successfully exported Engines : ${Success_Export_Engines} <br> Failed export Engines : ${Failed_Export_Engines} <br> Admin Server IP : ${ADMIN_IP} <br> Path - ${TIBCO_HOME}/vodafone/Engine_Migration/${ENVIRONMENT}_BW"
    
	emailext mimeType: 'text/html',
	attachmentsPattern: "**/XML_FOLDER/*.xml",				
	subject: "XML Files for ${ENVIRONMENT}",  
	from:"BWMigration@vodafone.com", 
	to: "${emailRecipents}", 
	body: "${emailContent}"
}

def deployEngine()
{
	ansiColor('xterm') {
  		ansiblePlaybook (playbook: "${WORKSPACE}/Automation/Engine_Migration/deploy_prep.yml", colorized: true, extras: '', extraVars: [host: "${ENVIRONMENT}_BW", tibco_home: "${TIBCO_HOME}" ])
		  }
    
	def export_success_file = "${WORKSPACE}/XML_FOLDER/Success_Export_List.txt"
	if(fileExists(export_success_file)) {
		def export_success_ouput = readFile("${WORKSPACE}/XML_FOLDER/Success_Export_List.txt")
		if (export_success_ouput.size() != 0) {			
			export_success_ouput.split('\n').each { deploy_engine ->
				if(deploy_engine.trim().size() != 0)
				{ 
					ansiColor('xterm') {
					ansiblePlaybook (playbook: "${WORKSPACE}/Automation/Engine_Migration/deploy.yml", colorized: true, extras: '', extraVars: [host: "${ENVIRONMENT}_BW", tibco_home: "${TIBCO_HOME}", engine_name: "${deploy_engine}", sbus: "${MAP["${deploy_engine}"]['BUS']}", domain_name:"${DEPLOY_DOMAIN_NAME}", user_name:"${DEPLOY_USER_NAME}",password:"${DEPLOY_PASSWORD}" ])
					}
				}
			}
					
			sh """ mkdir -p TRA_FOLDER """
			sh """ cd TRA_FOLDER; rm -rf *.tra"""
			
			sh """scp tibco@${ADMIN_IP}:${TIBCO_HOME}/vodafone/Engine_Migration/${ENVIRONMENT}_BW/Success_Deploy_List.txt ${WORKSPACE}/TRA_FOLDER/Success_Deploy_List.txt """
			sh """scp tibco@${ADMIN_IP}:${TIBCO_HOME}/vodafone/Engine_Migration/${ENVIRONMENT}_BW/Failed_Deploy_List.txt ${WORKSPACE}/TRA_FOLDER/Failed_Deploy_List.txt """

			def deploy_success_file = "${WORKSPACE}/TRA_FOLDER/Success_Deploy_List.txt"
	        if(fileExists(deploy_success_file)) {
				def deploy_success_ouput = readFile("${WORKSPACE}/TRA_FOLDER/Success_Deploy_List.txt")
				if (deploy_success_ouput.size() != 0) {			
					deploy_success_ouput.split('\n').each { deploy_engine ->
						if(deploy_engine.trim().size() != 0)
						{ 
							sh """scp tibco@${APP_SERVER_IP}:${TIBCO_HOME}/tra/domain/${EXPORT_DOMAIN_NAME}/application/${deploy_engine}/${deploy_engine}-${deploy_engine}.tra ${WORKSPACE}/TRA_FOLDER/${EXPORT_DOMAIN_NAME}_${deploy_engine}.tra """
									
							sh """scp tibco@${APP_SERVER_IP}:${TIBCO_HOME}/tra/domain/${DEPLOY_DOMAIN_NAME}/application/${deploy_engine}/${deploy_engine}-${deploy_engine}.tra ${WORKSPACE}/TRA_FOLDER/${DEPLOY_DOMAIN_NAME}_${deploy_engine}.tra """
							
							emailContent=" Please find the TRA of deployed engine ${deploy_engine} in attachment"
			
							emailext mimeType: 'text/html',
							attachmentsPattern: "**/TRA_FOLDER/${EXPORT_DOMAIN_NAME}_${deploy_engine}.tra,**/TRA_FOLDER/${DEPLOY_DOMAIN_NAME}_${deploy_engine}.tra",				
							subject: "${deploy_engine}- Export and Deploy SUCCESSFUL for ${ENVIRONMENT}",  
							from:"BWMigration@vodafone.com", 
							to: "${emailRecipents}", 
							body: "${emailContent}"
						}
					}
				}
			}
			
			Success_Deploy_Engines = sh(script: """cat ${WORKSPACE}/TRA_FOLDER/Success_Deploy_List.txt |  tr '\n' ',' | sed 's/,\$//'""",returnStdout: true).trim()
			Failed_Deploy_Engines = sh(script: """cat ${WORKSPACE}/TRA_FOLDER/Failed_Deploy_List.txt |  tr '\n' ',' | sed 's/,\$//'""",returnStdout: true).trim()				
			
		}
	}
	emailContent=" Requested Engines: ${ENGINES} <br>Successfully exported Engines : ${Success_Export_Engines} <br> Export failure Engines : ${Failed_Export_Engines} <br> Successfully deployed Engines : ${Success_Deploy_Engines} <br> Deploy Failure Engines : ${Failed_Deploy_Engines}"
			
			emailext mimeType: 'text/html',
			//attachmentsPattern: "**/TRA_FOLDER/*.tra",				
			subject: "Export and Deployment Summary for ${ENVIRONMENT}",  
	    	from:"BWMigrationSummary@vodafone.com", 
			to: "${emailRecipents}", 
			body: "${emailContent}"
}


emailContent = ""
MAP = [:]
ADMIN_IP = ""
Success_Export_Engines = ""
Failed_Export_Engines = ""
Success_Deploy_Engines = ""
Failed_Deploy_Engines = ""
emailRecipents = "devops-vfuk-integration@vodafone.com;balaji.sukhadevghadage@vodafone.com;chandan.kumar@vodafone.com;rajesh.singh4@vodafone.com;asmita.khatate@vodafone.com;apurva.sarnot@vodafone.com;sai.chinni@vodafone.com;sagar.deshmukh2@vodafone.com;shraddha.khandgaure2@vodafone.com;mihir.kulkarni@vodafone.com;satish.kolisetty@vodafone.com;adarsh.yadav2@vodafone.com;ramesh.sirigineni2@vodafone.com;dl-vestibcosupport@vodafone.com"
//emailRecipents = "devansh.patil@vodafone.com;rajesh.singh4@vodafone.com;asmita.khatate@vodafone.com;"
pipeline {
    agent any   

stages {
	stage('Prepration') {
		steps {
			script{
				prepration()
                }
            }
        }
	stage('Export Engines') {
		steps {
			script{
					exportEngine()
					input 'Proceed with Deployment?'
                }
            }
        }   
    
    stage('Deploy Engines'){
		steps {
			script{				  		
					deployEngine()					  	 
			    }					   
			}
        }
    }
}
