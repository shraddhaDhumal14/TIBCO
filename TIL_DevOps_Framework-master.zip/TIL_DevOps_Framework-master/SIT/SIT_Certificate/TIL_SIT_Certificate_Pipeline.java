import java.text.*
import groovy.time.*

def date = new Date();
def sdf = new SimpleDateFormat("yyyyMMddHHmmss");
def date_time = sdf.format(date)
date_now = new Date().format( 'dd-MM-yyyy' )

def elapsedTime(Closure closure){
    def timeStart = new Date()
    closure()
    def timeStop = new Date()
    return TimeCategory.minus(timeStop, timeStart).toMilliseconds()
}
                
def Git_Checkout (){

//Checkout Ansible Scripts for Job
                                                checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Scripts"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]

//Checkout Scripts for Job
                                                
                                                checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Certificates"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/SIT_Test_Pipelines.git']]]
}

def get_body_build_summary(){
                                def date = new Date();
                                def sdf = new SimpleDateFormat("dd/MM/yyyy  HH:mm");
                                def date_time = sdf.format(date)
                                
                
                                def body_build_summary = """
                                                                <style type="text/css">
                                                                .tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
                                                                .tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
                                                                .tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
                                                                .tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
                                                                .tg .tg-2wig{font-weight:bold;text-align:center;vertical-align:top}
                                                                .tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
                                                                .tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
                                                                .tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
                                                                .tg .tg-0lax{text-align:left;vertical-align:top}
                                                                </style>
                                                                </style>
                                                                <table class="tg" style="undefined;table-layout: fixed; width: 100%">
                                                                <colgroup>
                                                                <col style="width: 90px">
                                                                <col style="width: 90px">
                                                                <col style="width: 90px">
                                                                <col style="width: 90px">
                                                                </colgroup>
                                                                  <tr>
                                                                                <th class="tg-amwm" colspan="6">Certificate Deployment</th>
                                                                  </tr>
                                                                  <tr>
                                                                                <td class="tg-1wig" colspan="2">Submitted By</td>
                                                                                <td class="tg-0lax" colspan="4">${currentBuild.getRawBuild().getCauses()[0].getUserId()}</td>
                                                                  </tr>
                                                                  <tr>
                                                                                <td class="tg-1wig" colspan="2">Date</td>
                                                                                <td class="tg-0lax" colspan="4">${date_time}</td>
                                                                  </tr>
                                                                  <tr>     
                                                                                <td class="tg-1wig" colspan="2">Environment</td>
                                                                                <td class="tg-0lax" colspan="4">${ENV}</td>
                                                                  </tr>
                                                                  <tr>     
                                                                                <td class="tg-1wig" colspan="2">CRQ_Number</td>
                                                                                <td class="tg-0lax" colspan="4">${CRQ}</td>
                                                                  </tr>
                                                                  <tr>     
                                                                                <td class="tg-1wig" colspan="2">Client_Name</td>
                                                                                <td class="tg-0lax" colspan="4">${Client_Name}</td>
                                                                  </tr>
                                                                  <tr>     
                                                                                <td class="tg-1wig" colspan="2">Certificate_Type</td>
                                                                                <td class="tg-0lax" colspan="4">${Certificate_Type}</td>
                                                                  </tr>
                                                                  <tr>     
                                                                                <td class="tg-1wig" colspan="2">Engine_List</td>
                                                                                <td class="tg-0lax" colspan="4">${Engine_List}</td>
                                                                  </tr>
                                                                  <tr>     
                                                                                <td class="tg-1wig" colspan="2">Certificates_List</td>
                                                                                <td class="tg-0lax" colspan="4">${Files}</td>
                                                                  </tr>
                                                                </table>
                                                                
                                                                <br><br><br>
                                """
                                emailBody = body_build_summary
                                return body_build_summary
}


def  Preparation ()           {
                
                
                displayName = "Cert_Deploy_${CRQ}_${BUILD_NUMBER}"
                currentBuild.displayName = "${displayName}"
                
                Git_Checkout ()
                
                sh '''
                
                                cp -rf ${WORKSPACE}/Certificates/Certificate_Configuration ${WORKSPACE}/Certificate_Configuration
                                cp -rf ${WORKSPACE}/Scripts/Certificate_Deployment_SIT ${WORKSPACE}/Certificate_Deployment
                                rm -R ${WORKSPACE}/Certificates ${WORKSPACE}/Scripts
                                
                                
                '''
                
if(fileExists("${WORKSPACE}/Certificate_Configuration/${Server_Type}/${ENV}/${Server_Type}_Certificateconfig.txt")) {                              
                                
                                sh '''                       
                                                cat ${WORKSPACE}/Certificate_Configuration/${Server_Type}/${ENV}/${Server_Type}_Certificateconfig.txt | grep ${Client_Name} | grep ${Certificate_Type} >> ${WORKSPACE}/data.txt

                                '''             
                                def File = "${WORKSPACE}/data.txt"
                                def readFile = new File("${File}")
                                def FileContent = readFile.readLines()
                                Content = "${FileContent}".split('\\|')
                                Engine_List = Content[1]
								backup_location = Content[3]
								
								
								echo "Certificate location path : ${backup_location}"
								echo "Following is the Engine list ${Engine_List}"
                                                
                }
                
                sh '''
                cd ${WORKSPACE}/Certificate_Configuration/${Server_Type}/${ENV}/Certs/${Client_Name}/${Certificate_Type}
                ls * > ${WORKSPACE}/FileList.txt
                '''
                cert_snap= ""
                def File1 = "${WORKSPACE}/FileList.txt"
                def readFile1 = new File("${File1}")
                def FileContent1 = readFile1.readLines()
                def Path = "${FileContent1}".split('\\[')
                def Path1 = Path[1].split('\\]')
                Files = Path1[0]
                FileList = Path1[0].split(', ')
                                                
                for (List in FileList) {
                                if (cert_snap.length() != 0) {
                                                cert_snap = "${cert_snap}" + "," + Content[3] + List                                           
                                }              else {
                                                // def first = List.split('\\[')
                                               cert_snap = "${Client_Name}" + ":" + Content[3] + List
                                                }
                }
                //cert_snap = "${File_list}".split('\\]')
                println "${cert_snap}"
                def emailBody = "${get_body_build_summary()}"
                                emailext  mimeType: 'text/html', 
                                subject: "[Jenkins]:Certificate Deployment",
                                from:"${Server_Type}_Certificate_Deploy",
                                to: "${dev_mailRecipients}",
                                body:"${emailBody}" + 
                                                                "<br><p><b><font size='2' color='Black'>${Server_Type}_Certificate_Deploy_BUILDURL: <a href='${BUILD_URL}input'>${BUILD_URL}</a></font></b></p>" 
                                input 'Proceed with  Cert Deploy?'
                /*           def Input = input( id: 'userInput', message: 'Do you want to Proceed the Deployment or Not ?',
                                                                parameters: [[$class: 'ChoiceParameterDefinition', defaultValue: 'Proceed', 
                                                                                description:'describing choices', name:'nameChoice', choices: "Proceed"]
                                                                                ],
                                                                submitterParameter: 'submitter',
                                                                submitter: "${dev_mailRecipients}"
                                                                ) 
                                                                println("DEBUG: Choice selected is: " + Input.nameChoice)
                */
}



def get_conf_files_restart(deployParams) {
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}_Conf"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_BW_Application_Configuration.git']]]
    // make a directory with conf
	sh "mkdir -p ./${deployParams.Host}_Conf/conf"
    echo "${deployParams.engines}"
	echo "${deployParams.folderName}"
    def engine_list = deployParams.engines.split(',')
		for (txt in engine_list) {
			echo "${txt}"
			def eng_conf = txt
			echo eng_conf
			// check if engine input has folder name associated 
			if(eng_conf.contains('/')){
				def engine_params = eng_conf.split('/')
				def folderName = engine_params[0]
				def engine_name = engine_params[1]
				// copy appconf file from master repository
				sh "cp ./${deployParams.Host}_Conf/Restart_Configurations/Restart_Template.appconf ./${deployParams.Host}_Conf/conf/${engine_name}.appconf"
			
				// update values of appconf with Folder name provided during deployment
				sh  "sed -i '/FolderName=/ s/=.*/=${folderName}/'  ./${deployParams.Host}_Conf/conf/${engine_name}.appconf"
		  
				
			}
			else{
				
				// copy appconf file from master repository
			sh "cp ./${deployParams.Host}_Conf/Restart_Configurations/Restart_Template.appconf ./${deployParams.Host}_Conf/conf/${eng_conf}.appconf"
			
			}	

			
			// create directory if does not exist
		   // sh "mkdir -p ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}"
			// copy appconf file from master repository
			//sh "mv ./${deployParams.Host}_Conf/Restart_Configurations/Restart_Template.appconf ./${deployParams.Host}_Conf/conf/${eng_conf}.appconf"
			
			// update values of appconf with Folder name provided during deployment
			//sh  "sed -i '/FolderName=/ s/=.*/=${deployParams.folderName}/'  ./${deployParams.Host}_Conf/conf/${eng_conf}.appconf"
	   }
}




def deploy_restart_bw(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
			
			//Checkout Environment specic configurations (tokens, properties files)
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "RESTART_ENV"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_TestEnv_Configurations.git']]]
			
			
			// create directory with name conf to copy config files
			sh "mkdir -p ./${deployParams.Host}/BW_Deployment/conf"
			
			// Copy deployment conf files  to conf directory in deployment script 
			
			sh "cp -r ./${deployParams.Host}_Conf/conf/* ./${deployParams.Host}/BW_Deployment/conf"
       
           	sh "mkdir -p ./${deployParams.Host}/BW_Deployment/host_vars/${deployParams.Host}_BW"

			// Copy Environment specififc files to Ansible Host Vars 
			sh "cp -r ./RESTART_ENV/BW_Configuration/${deployParams.Host}/* ./${deployParams.Host}/BW_Deployment/host_vars/${deployParams.Host}_BW"
			
			
		
			//Run ansible playbook to deploy artefacts into environment
			 ansiColor('xterm') {
    	     ansiblePlaybook(playbook: "./${deployParams.Host}/BW_Deployment/restartBW.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Host}_BW", engines: "${deployParams.engines}", datetime: "${deployParams.datetime}", crq_num: "${deployParams.crq_no}", bwDeployment: "${deployParams.bwDeployment}", bwRestart: "${deployParams.bwRestart}"])
	
		    }
    }
}




def Rollback_Input = ""


pipeline {
    agent any
                environment {
                                Content = ""
                                cert_snap = ""
                                FileList= ""
                                File_list = ""
                                Src_Path = "${WORKSPACE}/Certificate_Configuration/${Server_Type}/${ENV}/Certs/${Client_Name}/${Certificate_Type}"
                                def Engine_List = ""
                                dev_mailRecipients = "shraddha.khandgaure2@vodafone.com,Sagar.Deshmukh2@Vodafone.com,yogeshnamdeo.rathod@vodafone.com"
                                Files = ""
                                Status = ""
                                Signoff_Input = ""
                                BW_Input = ""
								backup_location = ""
                                
                }
    stages {
        stage ('Preparation') {
            steps {
                script {
                  cleanWs()  
                  Preparation ()
                    
                }
            }
        }
        stage ('Cert_Deployment stage') {
            steps {
                script {
                  
                                                                                Deploy_Duration = elapsedTime {
                                                                                                ansiColor('xterm') {
                                                                                                                ansiblePlaybook (playbook: "${WORKSPACE}/Certificate_Deployment/certsDeploy.yml", colorized: true, extras: '', extraVars: [host: "${ENV}_File", cert_snap: "${cert_snap}", datetime: "${date_time}", crq_num: "${CRQ}", Src_Path: "${Src_Path}", backup_location: "${backup_location}"])
                                                                                                }
                                                                                }
                                                                                Deploy_Duration = Deploy_Duration*0.001
                                                                                println("Deploy Duration in Sec: " + Deploy_Duration)
                                                                                println "Certificates Deployment Completed"
                }
            }
        }        
    
                                stage ('Restart the applications') {
            steps {
                script {
                                                                              /*  def BW1_Input = input( id: 'userInput', message: 'Do you want to Proceed for Manual or AutomationRestart ?',
                                                                                parameters: [[$class: 'ChoiceParameterDefinition', defaultValue: 'Manual', 
                                                                                description:'describing choices', name:'nameChoice', choices: "AutomationRestart"]
                                                                                ],
                                                                                submitterParameter: 'submitter',
                                                                                submitter: "${dev_mailRecipients}"
                                                                                )
																				
																				if ( BW1_Input.nameChoice == "Manual" ) {
                                                                                                
                                                                                println("DEBUG: Choice selected is: " + BW1_Input.nameChoice)
                                                                                println "Restarting"
                                                                                Status = "Success"
                                                                                                
                                                                                }
																				
																				 else
																				*/	
																					
																		
																		
																	/*	def FileEngine = "${WORKSPACE}/data.txt"
																		def readFileEngine = new File("${FileEngine}")
																		def FileContentEngine = readFileEngine.readLines()
																		ContentEngine = "${FileContentEngine}".split('\\|')
																		Engine_List = ContentEngine[1]
																	*/		
																	
																	echo "Engines to restart are: ${Engine_List}"
																		
																		input 'Proceed with  Engine Restart?'
																		
																						get_conf_files_restart engines:"${Engine_List}", Host:"${ENV}"
					           					
																						echo "Engines to restart are: ${Engine_List}"
																						deploy_restart_bw Host:"${ENV}", crq_no:"${CRQ}", engines:"${Engine_List}", datetime:"${date_now}"
																						
																		
																				
																				
                                                                                
                                                                                
                                                                /*BW_Input = input( id: 'userInput', message: 'Do you want to Proceed for Next Deploy Stage or Rollback the Certificates ?',
                                                                                parameters: [[$class: 'ChoiceParameterDefinition', defaultValue: 'Continue', 
                                                                                description:'describing choices', name:'nameChoice', choices: "Continue\nRollback"]
                                                                                ],
                                                                                submitterParameter: 'submitter',
                                                                                submitter: "${dev_mailRecipients}"
                                                                                )
                                                                                println("DEBUG: Choice selected is: " + BW_Input.nameChoice)
                                                                                
                                                                        */        
                                                                
                                                                }
                                                }
                                }
                
                             
                                
                               /* stage ('Rollback ') {
                                                when {
                                                     expression { BW_Input.nameChoice == "Rollback" || Signoff_Input.nameChoice == "Rollback" }
                                                }
            steps {
                script {
                                                                                
                                                                                if ( BW_Input.nameChoice == "Rollback" ) {
                                                                                                Rollback_Duration = elapsedTime {
                                                                                                                ansiColor('xterm') {
                                                                                                                                ansiblePlaybook (playbook: "${WORKSPACE}/Certificate_Deployment/certsRollBack.yml", colorized: true, extras: '', extraVars: [host: "${ENV}_File", cert_snap: "${cert_snap}", datetime: "${date_time}", crq_num: "${CRQ}"])
                                                                                                                }
                                                                                                }
                                                                                                Rollback_Duration = Rollback_Duration*0.001
                                                                                                println("Rollback Duration in Sec: " + Rollback_Duration)
                                                                                                println "Rollback Completed"
                                                                                                
                                                                                }
                                                                                
                                                                                if ( Rollback_Input == "Rollback" ) {
                                                                                                Rollback_Duration = elapsedTime {
                                                                                                
                                                                                                                ansiColor('xterm') {
                                                                                                                                ansiblePlaybook (playbook: "${WORKSPACE}/Certificate_Deployment/certsRollBack.yml", colorized: true, extras: '', extraVars: [host: "${ENV}_File", cert_snap: "${cert_snap}", datetime: "${date_time}", crq_num: "${CRQ}"])
                                                                                                                }
                                                                                                                
                                                                                                                ansiColor('xterm') {
                                                                                                                                ansiblePlaybook (playbook: "${WORKSPACE}/Certificate_Deployment/certsRollBack.yml", colorized: true, extras: '', extraVars: [host: "${ENV}_File", cert_snap: "${cert_snap}", datetime: "${date_time}", crq_num: "${CRQ}"])
                                                                                                                }
                                                                                                }
                                                                                                Rollback_Duration = Rollback_Duration*0.001
                                                                                                println("Rollback Duration in Sec: " + Rollback_Duration)
                                                                                                println "Rollback Completed"
                                                                                                
                                                                                }
                                                                                
                                                                                }
                                                                }
                                                } */
                                                
                                                                                                
                                                stage ('Sign Off') {
                                                
            steps {
                script {
                                                                                input 'Proceed with  Signoff ?'                                                                                    
                                                                                                println "Signoff Completed"
                                                                                                
                                                                                
                                                                                }
                                                                }
                                                }
                                
                
                
                }
}