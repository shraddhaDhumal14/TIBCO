def perf_mailRecipients = "raghuram.koripalli@vodafone.com"

def deploy_artefact(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
			
			// Copy host configutaion files to Ansible deployment script location
			sh "cp -r ./${deployParams.Host}/Gateway_Configuration/${deployParams.GatewayType}/${deployParams.gatewayEnvironment}/* ./${deployParams.Host}/Gateway_Deployment/"
			
			// copy host variables from configuration to ansible host vars folder
			sh "cp ./${deployParams.Host}/Gateway_Deployment/${deployParams.GatewayType}_${deployParams.Host} ./${deployParams.Host}/Gateway_Deployment/host_vars/"
			// rename tokens file to instance specific
			sh "cp ./${deployParams.Host}/Gateway_Deployment/Tokens/${deployParams.GatewayType}_${deployParams.gatewayEnvironment} ./${deployParams.Host}/Gateway_Deployment/Tokens/${deployParams.GatewayType}_${deployParams.Host}"
            
			echo "DEBUG: nexus_ArtefactVersion is: ${deployParams.nexus_ArtefactVersion}"
		
			//Run ansible playbook to deploy artefacts into environment
			 ansiColor('xterm') {
    	    ansiblePlaybook(playbook: "./${deployParams.Host}/Gateway_Deployment/Ops_Deploy.yml", colorized: true, extras:'-v', extraVars: [host: "${deployParams.GatewayType}_${deployParams.Host}", repo_group_id: "${deployParams.nexus_group_id}", repo_artifact_id: "${deployParams.nexus_artifact_id}", repo_user: "${deployParams.nexus_user}", repo_pw: "${deployParams.nexus_passwd}", repo_repo_id: "${deployParams.nexus_repo_id}", repo_version: "${deployParams.nexus_ArtefactVersion}", repo_url: "${deployParams.nexus_url}", datetime: "${deployParams.datetime}", crq_no: "${deployParams.crq_no}", gatewayRestart: "${deployParams.gatewayRestart}", deployType: "${deployParams.deployType}"])
	
			}
    }
}

def gateway_restart(deployParams) {
	script{
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
			//Run ansible playbook to restart gateway instances
			 ansiColor('xterm') {
    	   ansiblePlaybook(playbook: "./${deployParams.Host}/Gateway_Deployment/Ops_Restart.yml", colorized: true, extras:'-v', extraVars: [host: "${deployParams.GatewayType}_${deployParams.Host}", externalApache: "${deployParams.externalApache}", internalApache: "${deployParams.internalApache}", gatewayRestart: "${deployParams.gatewayRestart}"])

		  }
    }
}

def rollback_artefact(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{
			ansiColor('xterm') {		
			 //Run ansible playbook to rollback deployed changes
			 ansiblePlaybook(playbook: "./${deployParams.Host}/Gateway_Deployment/rollback.yml", colorized: true, extras:'-v', extraVars: [host: "${deployParams.GatewayType}_${deployParams.Host}", datetime: "${deployParams.datetime}", crq_no: "${deployParams.crq_no}", externalApache: "${deployParams.externalApache}", internalApache: "${deployParams.internalApache}"])
	         }
	}
}



// Global Parameters to use in the stages.

//date_format_report = new Date().format("dd/MM/yyy HH:mm")
date_now = " "
displayName = " "
emailBody = " "


pipeline {
    agent any
	options {
        preserveStashes(buildCount: 49)
    }

    environment {
		GROUPID = "GATEWAY"
		GatewayType = "IGW01_2.1"
		GatewayEnvironment = "Perf03"
		REPO_URL = "http://195.233.197.150:8081"
		SIT_REPO = "SIT_REPO"
		NEXUS_USER = "admin"
		NEXUS_PASSWD = "admin123"

    }

    stages {
		stage('Preparation') {
			steps {
			    deleteDir()
				echo "Release number selected is: ${params.ReleaseNumber}"
				script{
				        if (ReleaseNumber == ""){
						           currentBuild.result = 'ABORTED'
                                   error('ReleaseNumber to be specified for the Deployment')
						        }
						if (GatewayVersion == ""){
						           currentBuild.result = 'ABORTED'
                                   error('GatewayVersion to be specified for the Deployment')
						        }
				    	if (CRQ.indexOf(' ') != -1){
						         currentBuild.result = 'ABORTED'
                                 error('CR Number / IRIS Number should not contain spaces in between')
						       }
				    date_now = new Date().format("YYYYMMddHHmmss")
					displayName = "${params.ReleaseNumber}_${params.CRQ}"
					currentBuild.displayName = "${displayName}"
					//Stash the important values so that these can be retrieved for stage restart.
					sh "mkdir -p DIR_STASH"
					sh "echo date:${date_now} >DIR_STASH/propfile"
					sh "echo displayName:${displayName} >>DIR_STASH/propfile"
					stash includes: 'DIR_STASH/propfile', name: 'stashProperties'
				}
				echo "date:${date_now}"

						
			}			
		}

	stage("IGW01 233 6380 Deployment") {
			steps {
				// This stage is for deployment.
				script {
				 
				    // If the following values are blank, it means we are starting from stage and need to retrive the values from stash.
					unstash "stashProperties"
					if (date_now == " ") {
						date_now = sh(script:"cat ./DIR_STASH/propfile | grep -e date | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						echo "Date after stage restart is:${date_now}"
					}
					if (displayName == " ") {
						displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						currentBuild.displayName = "${displayName}_restart"
						echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
					}
					echo "Date without stage restart is:${date_now}"
					// Call deploy function by providing Details.
					deploy_artefact Host:'Perf03_233_6380', nexus_group_id:"${env.GROUPID}", nexus_artifact_id:"${env.GatewayType}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.SIT_REPO}", nexus_ArtefactVersion:"${params.GatewayVersion}", GatewayType:"${env.GatewayType}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CRQ}", datetime:"${date_now}", gatewayRestart:false, gatewayEnvironment:"${env.GatewayEnvironment}", deployType:"RF"
				}
			}
		}
		
	stage("IGW01 234 6380 Deployment") {
			steps {
				// This stage is for deployment.
				script {
				
				    // If the following values are blank, it means we are starting from stage and need to retrive the values from stash.
					unstash "stashProperties"
					if (date_now == " ") {
						date_now = sh(script:"cat ./DIR_STASH/propfile | grep -e date | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						echo "Date after stage restart is:${date_now}"
					}
					if (displayName == " ") {
						displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						currentBuild.displayName = "${displayName}_restart"
						echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
					}
					echo "Date without stage restart is:${date_now}"
					// Call deploy function by providing Details.
					deploy_artefact Host:'Perf03_234_6380', nexus_group_id:"${env.GROUPID}", nexus_artifact_id:"${env.GatewayType}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.SIT_REPO}", nexus_ArtefactVersion:"${params.GatewayVersion}", GatewayType:"${env.GatewayType}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CRQ}", datetime:"${date_now}", gatewayRestart:false, gatewayEnvironment:"${env.GatewayEnvironment}", deployType:"RF"
				   // Update dashboard with status
					build job: '/TIL_PIPELINES/Common_Jobs/Dashboard_Publish', parameters: [string(name: 'Environment', value: "Perf03"), string(name: 'Component', value: "IGW01_2.1"), string(name: 'ArtefactVersion', value: "${params.GatewayVersion}"), string(name: 'Pipeline', value: 'IGW01_2.1_Pipeline'), string(name: 'Description', value: '')]
					
				}
			}
		}		
	

	
		stage("Gateway Restart Approval") {
			steps {
				script {
					  	 input 'Proceed with gateway restarts ?'
					}
			}
		}
	
		stage("IGW01 233 6380 Gateway Restart") {
			steps {
				script {
					// If the following values are blank, it means we are starting from stage and need to retrive the values from stash.
					unstash "stashProperties"
					if (date_now == " ") {
						date_now = sh(script:"cat ./DIR_STASH/propfile | grep -e date | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						echo "Date after stage restart is:${date_now}"
					}
					if (displayName == " ") {
						displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						currentBuild.displayName = "${displayName}_restart"
						echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
					}

					gateway_restart Host:'Perf03_233_6380', GatewayType:"${env.GatewayType}", internalApache:false, externalApache:false, gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
			
				}
			}
		}
		
		stage("IGW01 234 6380 Gateway Restart") {
			steps {
				script {
					// If the following values are blank, it means we are starting from stage and need to retrive the values from stash.
					unstash "stashProperties"
					if (date_now == " ") {
						date_now = sh(script:"cat ./DIR_STASH/propfile | grep -e date | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						echo "Date after stage restart is:${date_now}"
					}
					if (displayName == " ") {
						displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						currentBuild.displayName = "${displayName}_restart"
						echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
					}

					gateway_restart Host:'Perf03_234_6380', GatewayType:"${env.GatewayType}", internalApache:false, externalApache:false, gatewayRestart:true, gatewayEnvironment:"${env.GatewayEnvironment}"
			
				}
			}
		}

    }
}		
