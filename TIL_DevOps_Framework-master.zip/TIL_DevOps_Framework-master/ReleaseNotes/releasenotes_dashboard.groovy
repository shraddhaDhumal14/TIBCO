//==============================Database Function====================================================

BUILD_DATE = ""

def displayDebug(strModule, strDebugMessage)
{
  def debug=1;
  if(debug == 1)
     {   
         println("***************************************")
         println("Module :" + strModule)
         println("Debug Message :" + strDebugMessage)
     }
}

def myGetDBConnect() {     
     def dbURL = 'jdbc:oracle:thin:@aukshocr.dc-dublin.de:33000:TIBTST1'
     def dbUserName = 'CICD_OWN_DB01'
     def dbPassword = 'TIL_CICD_DB'
     def dbDriver = 'oracle.jdbc.driver.OracleDriver'
     displayDebug('myGetDBConnect','Establishing DB Connectivity')
     def mySQL = groovy.sql.Sql.newInstance(dbURL,dbUserName,dbPassword,dbDriver)
     return mySQL                   
}


def myMultipleSelectQuery(selectQuery){     
     def mySQL =  myGetDBConnect()
  	 def rowData = [:]
	 def resultList = []
     def headerList
     displayDebug('myMultipleSelectQuery',selectQuery)
     def rowResults = mySQL.rows(selectQuery)
     mySQL.close()
     println(rowResults.size())
     if(rowResults.size() == 0)
            return resultList;
     else 
            headerList = new ArrayList(rowResults[0].keySet())
	 for(def rlcounter=0;rlcounter<rowResults.size();rlcounter++)
     {
         def row = rowResults[rlcounter];
         rowData = [:]
         for(def rwHeaderCnt=0;rwHeaderCnt<headerList.size();rwHeaderCnt++)
         { 
               rowData.put(headerList[rwHeaderCnt], row[rwHeaderCnt]!= null  ? row[rwHeaderCnt].toString() : "")
         }
		 resultList.add(rowData)
     }
	 headerList=null;
	rowResults = null;
	rowData = null;
	mySQL = null;
    return resultList;
}

def build_table(strQuery)
{
        displayDebug("getEngineList", strQuery)
        rowList = myMultipleSelectQuery(strQuery);
        def headerList;
        def build_user = currentBuild.rawBuild.causes[0].userId;
        def body_build_summary = ""
        def header = """
                     <html>
                        <head>
                                <style>
                                table {
                                  border-collapse: collapse;
                                  width: 100%;
                                }

                                th, td {
                                  text-align: left;
                                  padding: 8px;
                                }

                                tr:nth-child(even) {
                                background-color: black;
                                color: white;
                                }

                                tr:nth-child(odd) {
                                background-color: #0000335f;
                                } 
                                </style>
                        </head>
                     """
        
         
        if(rowList.size() > 0)
        {
            headerList = new ArrayList(rowList[0].keySet())
            body_build_summary +="<tr>";
            for(def rwHeaderCnt=0;rwHeaderCnt<headerList.size();rwHeaderCnt++)
                    { 
                           body_build_summary += "<th>" +  headerList[rwHeaderCnt].toString() + "</th>";
                    }
            body_build_summary +="</tr>";
        }
        
        for(engCounter=0; engCounter < rowList.size(); engCounter++)
			{
					row = rowList[engCounter];
                    body_build_summary +="<tr>";
                    for(def rwHeaderCnt=0;rwHeaderCnt<headerList.size();rwHeaderCnt++)
                    { 
                           body_build_summary += "<td>" +  (row[headerList[rwHeaderCnt].toString()]!= null  ? row[headerList[rwHeaderCnt].toString()].toString() : "") + "</td>";
                    }
                    body_build_summary +="</tr>";
                    
            }
            
        if(body_build_summary != "")
        {
                dashboard_details = """
                                    <BR>Report Genearated By : ${build_user}
                                    <BR>Report Created on : ${BUILD_DATE}
                                    <BR>BUILD ID : ${env.BUILD_ID}
                                    <BR>
                                    <BR>
                                 """
                body_build_summary = "<body>" + dashboard_details + "<table border='1'>" + body_build_summary + "</table></body></html>";
                body_build_summary = header + body_build_summary;
        }
        else
        {
            body_build_summary = "No records Found!!";
        }
        return body_build_summary;
}

def get_ISTIL_Consolidated(Release)
{
        
        strQuery = "SELECT RELEASE_NO, T1.ENGINE_NAME, GV, CASE WHEN EAR_VERSION_MAX is null THEN 'NA' WHEN EAR_VERSION_MAX='0' THEN'GV_DEPLOYMENT' WHEN EAR_VERSION_MAX='1' THEN 'NA' ELSE EAR_VERSION_MAX END EAR_VERSION_MAX, CASE WHEN EMS_VERSION_MAX is null THEN 'NA' ELSE EMS_VERSION_MAX END EAR_VERSION_MAX, CASE WHEN SQL_VERSION_MAX is null THEN 'NA' ELSE SQL_VERSION_MAX END SQL_VERSION_MAX from (select RELEASE_NO, ENGINE_NAME, MAX(SUBSTR(EAR_VERSION, 0, INSTR(EAR_VERSION, '_',-1))) || MAX(TO_NUMBER(SUBSTR(REPLACE(EAR_VERSION,'NA',''), INSTR(EAR_VERSION, '_',-1)+1))) as EAR_VERSION_MAX, MAX(SUBSTR(SQL_VERSION, 0, INSTR(SQL_VERSION, '_',-1))) || MAX(TO_NUMBER(SUBSTR(REPLACE(SQL_VERSION,'NA',''), INSTR(SQL_VERSION, '_',-1)+1))) as SQL_VERSION_MAX, MAX(SUBSTR(EMS_VERSION, 0, INSTR(EMS_VERSION, '_',-1))) || MAX(TO_NUMBER(SUBSTR(REPLACE(EMS_VERSION,'NA',''), INSTR(EMS_VERSION, '_',-1)+1))) as EMS_VERSION_MAX from CICD_RELEASE_SUMMARY where RELEASE_NO = '" + Release + "' and COMPONENT_TYPE = 'ISTIL' and STATUS = 'Active' group by RELEASE_NO, ENGINE_NAME ) T1 FULL OUTER JOIN (SELECT ENGINE_NAME, 'GV' as GV  from CICD_RELEASE_SUMMARY WHERE RELEASE_NO = '" + Release + "' and COMPONENT_TYPE = 'ISTIL' and STATUS = 'Active' group by RELEASE_NO, ENGINE_NAME having COUNT(ENGINE_NAME)=1 MINUS SELECT ENGINE_NAME, 'GV' as GV from CICD_RELEASE_SUMMARY WHERE RELEASE_NO = '" + Release + "' and COMPONENT_TYPE = 'ISTIL' and STATUS = 'Active' and EAR_VERSION <> '0') T2 ON T1.ENGINE_NAME = T2.ENGINE_NAME order by ENGINE_NAME"

        return build_table(strQuery);
}

def get_ISTIL_Detailed(Release)
{
        strQuery = "select RELEASE_SUMMARY_ID, ENGINE_NAME , CASE WHEN EAR_VERSION is null THEN 'NA' WHEN EAR_VERSION='0' THEN'GV_DEPLOYMENT' WHEN EAR_VERSION='1' THEN 'NA' ELSE EAR_VERSION END EAR_VERSION, EMS_VERSION,SQL_VERSION, COMPONENT_TYPE, STATUS  from CICD_RELEASE_SUMMARY where RELEASE_NO = '" + Release + "' and COMPONENT_TYPE = 'ISTIL' order by ENGINE_NAME, EAR_VERSION";
        return build_table(strQuery);
}

def get_GATEWAY_Consolidated(Release)
{
        strQuery = "select GATEWAY_TYPE, MAX(SUBSTR(GATEWAY_VERSION, 0, INSTR(GATEWAY_VERSION, '_',-1))) || MAX(TO_NUMBER(SUBSTR(REPLACE(GATEWAY_VERSION,'NA',''),INSTR(GATEWAY_VERSION, '_',-1)+1))) as GATEWAY_VERSION_MAX from CICD_RELEASE_SUMMARY where RELEASE_NO = '" + Release + "' and COMPONENT_TYPE = 'GATEWAY' and STATUS = 'Active' group by RELEASE_NO, GATEWAY_TYPE order by GATEWAY_TYPE";
        return build_table(strQuery);
}

def get_GATEWAY_Detailed(Release)
{
        strQuery = "select RELEASE_SUMMARY_ID, GATEWAY_TYPE, GATEWAY_VERSION, COMPONENT_TYPE, STATUS  from CICD_RELEASE_SUMMARY where RELEASE_NO = '" + Release + "' and COMPONENT_TYPE = 'GATEWAY' order by GATEWAY_TYPE,GATEWAY_VERSION";
        return build_table(strQuery);
}


def get_Release_Detailed(Release)
{
        strQuery = "SELECT RELEASE_SUMMARY_ID, RELEASE_NO, ENGINE_NAME, COMPONENT_TYPE, CASE WHEN EAR_VERSION is null THEN 'NA' WHEN EAR_VERSION='0' THEN'GV_DEPLOYMENT' WHEN EAR_VERSION='1' THEN 'NA' ELSE EAR_VERSION END EAR_VERSION, EMS_VERSION, SQL_VERSION, STATUS, PROJECT_NAME, JIRA_NO, CHANGE_DESCRIPTION, OPERATION, KNOWN_ERROR_INCLUSION, MASTER_GV, PROCESS_GV, APPEND_PREPEND, RESTART_ENGINES, ENGINE_TEMPLATE, POST_MANUAL_CHANGES, SPECIAL_INSTRUCTIONS, LINKTEST_RESULTS, FILE_CHANGES, GATEWAY_VERSION, GATEWAY_TYPE, PARTNER_DATA, GATEWAY_TOKEN, CREATED_BY, TO_CHAR(CREATED_ON, 'YYYY-MON-DD HH24:MI') CREATED_ON, TO_CHAR(MODIFIED_ON, 'YYYY-MON-DD HH24:MI') MODIFIED_ON, MODIFIED_BY, APPROVAL FROM CICD_RELEASE_SUMMARY where  RELEASE_NO='" + Release + "'";
        return build_table(strQuery);
}

def publishReport(reportName)
{   
    def strTable = "";
    switch(reportName)
    {
        case '1.ENGINE_CONSOLIDATED':
        
             strTable = "${get_ISTIL_Consolidated(Release)}"
             break;
             
        case '2.ENGINE_DETAILED':
        
             strTable = "${get_ISTIL_Detailed(Release)}"
             break;
        
        case '3.GATEWAY_CONSOLIDATED':
        
             strTable = "${get_GATEWAY_Consolidated(Release)}"
             break;
             
        case '4.GATEWAY_DETAILED':
        
             strTable = "${get_GATEWAY_Detailed(Release)}"
             break;

        case '5.DETAILED_RELEASE':
        
             strTable = "${get_Release_Detailed(Release)}"
             break;
        
         default:

            println("Report Name unknown")
            return "";
    }
    sh "echo '${strTable}' > '${reportName}.html'"
    sh "cat '${reportName}.html'"
    publishHTML([allowMissing: false, alwaysLinkToLastBuild: false, keepAll: false, reportDir: '.', reportFiles: "${reportName}.html", reportName: "${reportName}", reportTitles: ''])
}


def preparation_function(){
    // Initialize parameters to pipeline job.
		properties([parameters([
                            string(defaultValue: 'CCS20.1', description: '	*Mandatory. ex. CSS20.10', name: 'Release', trim: true), 
                            ])])
}

pipeline {
    agent any
    stages {
        
        stage('Preparation') {
			steps {
				script{
					deleteDir()
					preparation_function()
                    }
             }
        }
        
        stage('Generate Report') {
               steps{                      
                       script{
                           try {
                                    BUILD_DATE = sh (script: "echo \$(date +%F-%H:%M)", returnStdout: true).trim()
                                    
                                    publishReport('1.ENGINE_CONSOLIDATED')
                                    publishReport('2.ENGINE_DETAILED')
                                    publishReport('3.GATEWAY_CONSOLIDATED')
                                    publishReport('4.GATEWAY_DETAILED')
                                    publishReport('5.DETAILED_RELEASE')
                            }
                            catch (error) {
                                println("Build failed for some specific reason! - ${error}" )
                                println(error.getStackTrace().toString())
                                errorDescription=error;
                                currentBuild.result = 'FAILURE'
                            }                       
                      }//script
               }//steps
        }//stage 
    }// stages
}//pipeline