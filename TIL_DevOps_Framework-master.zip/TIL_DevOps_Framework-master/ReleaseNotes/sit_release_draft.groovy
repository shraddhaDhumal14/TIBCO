import com.cwctravel.hudson.plugins.extended_choice_parameter.ExtendedChoiceParameterDefinition
import hudson.tasks.Mailer;
import hudson.model.User;

@NonCPS
def getUserEmail(String id=null) {
    User user = User.getById(id ?: currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId(), false)
    user?.getProperty(Mailer.UserProperty.class).getAddress()
}

@NonCPS
def getBuildUserID(){
    return currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId()
}

def getBuildUserName(){
    return currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserName()
}

def get_approvers_list(String approver_group){
	approvers_list = sh (script: """cat /opt/tibco/.jenkins/config.xml | sed -n \'/role name=\"${approver_group}\"/,\$p\' | sed \'/role>/q\' | grep "sid" | cut -d \'>\' -f 2 | cut -d \'<\' -f 1 | paste -s -d, -""", returnStdout: true).trim()
    return "ram_shankar"
    //return """${approvers_list}"""           
}

def get_approvers_email_list(String approvers_list){
   approvers_email=""
	approvers_list.split(',').each { user ->
            if(approvers_email.length() != 0)
              {
                    approvers_email += ","
              }
              approvers_email += getUserEmail(user)  
        }
    return """${approvers_email}"""   
}

def displayDebug(strModule, strDebugMessage)
{
  def debug=1;
  if(debug == 1)
     {   
         println("***************************************")
         println("Module :" + strModule)
         println("Debug Message :" + strDebugMessage)
     }
}

def myGetDBConnect() {     
     def dbURL = 'jdbc:oracle:thin:@aukshocr.dc-dublin.de:33000:TIBTST1'
     def dbUserName = 'CICD_OWN_DB01'
     def dbPassword = 'TIL_CICD_DB'
     def dbDriver = 'oracle.jdbc.driver.OracleDriver'
     displayDebug('myGetDBConnect','Establishing DB Connectivity')
     def mySQL = groovy.sql.Sql.newInstance(dbURL,dbUserName,dbPassword,dbDriver)
     return mySQL                   
}

def mySingleSelectQuery(selectQuery){
     def mySQL =  myGetDBConnect()
  	 def rowData = [:]
     displayDebug('mySingleSelectQuery',selectQuery)
     def rowResults = mySQL.rows(selectQuery)
     mySQL.close();
     if(rowResults.size() == 0)
         return rowData;
     def headerList = new ArrayList(rowResults[0].keySet())
     for(def rlcounter=0;rlcounter<rowResults.size();rlcounter++)
     {
         def row = rowResults[rlcounter];
         rowData = [:]
         for(def rwHeaderCnt=0;rwHeaderCnt<headerList.size();rwHeaderCnt++)
         { 
           rowData.put(headerList[rwHeaderCnt], row[rwHeaderCnt]!= null  ? row[rwHeaderCnt].toString() : "")
         }
     }
	rowResults = null;
	mySQL = null;
	headerList = null;
    return rowData;
}

def myMultipleSelectQuery(selectQuery){     
     def mySQL =  myGetDBConnect()
  	 def rowData = [:]
	 def resultList = []
     displayDebug('myMultipleSelectQuery',selectQuery)
     def rowResults = mySQL.rows(selectQuery)
     mySQL.close()
     if(rowResults.size() == 0)
            return resultList;
     def headerList = new ArrayList(rowResults[0].keySet())
	 for(def rlcounter=0;rlcounter<rowResults.size();rlcounter++)
     {
         def row = rowResults[rlcounter];
         rowData = [:]
         for(def rwHeaderCnt=0;rwHeaderCnt<headerList.size();rwHeaderCnt++)
         { 
               rowData.put(headerList[rwHeaderCnt], row[rwHeaderCnt]!= null  ? row[rwHeaderCnt].toString() : "")
         }
		 resultList.add(rowData)
     }
	 headerList=null;
	rowResults = null;
	rowData = null;
	mySQL = null;
    return resultList;
}

def getReleaseSummaryID(type, value)
{
  
   if(value.length() == 0)
   {    
        return ""
   }
   strQuery = "select dbms_lob.substr(REPLACE(REGEXP_REPLACE(rtrim (xmlagg (xmlelement (e, RELEASE_SUMMARY_ID || ';') order by RELEASE_SUMMARY_ID asc).extract ('//text()'), ';'),'([^;]+)(;\\1)+', '\\1'), ';', ','), 4000, 1 )  RS_ID from CICD_RELEASE_SUMMARY where RELEASE_NO='${params.RELEASE}' AND ENGINE_NAME = '${params.ENGINE_NAME}' and " + type + " = '" + value + "' group by RELEASE_NO, COMPONENT_TYPE, ENGINE_NAME, " + type
   rowList = mySingleSelectQuery(strQuery);
   if(rowList.size() == 0)
   {
       error("Please check version deployed?   ${type}:${value}")
       currentBuild.result = 'FAILURE'
   }
   RS_ID = (rowList["RS_ID"] != null ) ? rowList["RS_ID"].toString() : ""
   RS_ID = "(RELEASE_SUMMARY_ID : " + RS_ID + ")"
   return RS_ID;
}

def getReleaseSummaryID(condition)
{
  
   strQuery = "select RELEASE_SUMMARY_ID AS RS_ID from CICD_RELEASE_SUMMARY where ${condition}"
   strQuery = strQuery.toString()
   rowList = myMultipleSelectQuery(strQuery);
   println(rowList.size())
   RS_ID=""
   if(rowList.size() == 0)
   {
       error("Please check version deployed? Version combination didnt return any row")
       currentBuild.result = 'FAILURE'
   }
   else if(rowList.size() == 1)
   {
       RS_ID = (rowList[0]["RS_ID"] != null ) ? rowList[0]["RS_ID"].toString() : "" 
   }
   //else if(rowList.size() > 1)
   else
   {
       println("Multiple entries found.")
       for(def rlCounter=0; rlCounter < rowList.size(); rlCounter++)
			    {
                    if(rlCounter != 0)
                        RS_ID += "~"
					RS_ID += (rowList[rlCounter]["RS_ID"] != null ) ? rowList[rlCounter]["RS_ID"].toString() : ""
                }
   }
   
   //RS_ID = "(RELEASE_SUMMARY_ID : " + RS_ID + ")"
   println("RELEASE_SUMMARY_ID: " + RS_ID)
   return RS_ID;
}

def getBuildSummary(condition, build_list)
{
    build_list = build_list.replaceAll("~",",")
    strQuery = "select RELEASE_SUMMARY_ID, CREATED_BY, TO_CHAR(CREATED_ON, 'DD-MON-YY HH24:MI') as CREATED_ON, PROJECT_NAME, OPERATION, CASE EAR_VERSION WHEN '0' THEN 'GV_DEPLOYMENT' WHEN '1' THEN 'RESTART' ELSE EAR_VERSION END EAR_VERSION, EMS_VERSION, SQL_VERSION, STATUS from CICD_RELEASE_SUMMARY where ${condition} and RELEASE_SUMMARY_ID in (" + build_list + ")"
    strQuery = strQuery.toString()
    rowList = myMultipleSelectQuery(strQuery);
    
    def headerList = new ArrayList(rowList[0].keySet())
    result = "RELEASE_SUMMARY_ID,CREATED_BY, CREATED_ON, PROJECT_NAME, OPERATION, EAR_VERSION, EMS_VERSION, SQL_VERSION, STATUS"
	 for(def rlcounter=0;rlcounter<rowList.size();rlcounter++)
     {
         def row = rowList[rlcounter];
         row_value=""
         for(def rwHeaderCnt=0;rwHeaderCnt<headerList.size();rwHeaderCnt++)
         { 
                if(rwHeaderCnt != 0)
                    row_value += "~"
                row_value += row[headerList[rwHeaderCnt]]!= null  ? row[headerList[rwHeaderCnt]].toString() : ""
                
               //rowData.put(headerList[rwHeaderCnt], row[rwHeaderCnt]!= null  ? row[rwHeaderCnt].toString() : "")
         }
         result += "\n" + row_value
     }
     return result
}

def getMultipleChoiceInput(Heading, Choice_Type, Options, Description, Size)
{
    def multiChoiceInput = new ExtendedChoiceParameterDefinition("${Heading}", "PT_CHECKBOX", "${Options}", "${Choice_Type}", 
                                                "", "", "", "", "", "", "", "", "", "", "", "", "",  
                                                "${Options}", 
                                                "", "", "", "", "", "", "", "",
                                                false,false, 
                                                Size, 
                                                "${Description}", 
                                                ",")
    return multiChoiceInput;
}

def getFileTypes(fileList){
  println("File List --> " + fileList)
  def extList = [];
  for (counter=0 ; counter < fileList.size(); counter++)
   {
        file = fileList[counter]
        if (file.lastIndexOf('.') < 0 && file.trim().length() > 0)
              extList.add("znoextn")    
        else if (file.length() > 0 && file.trim().length() > 0)
              extList.add(file.substring(file.lastIndexOf('.')+1)) 
   }
   println("Ext List --> " + extList)
   extList = extList.toUnique();
  println("Extn List "+extList);
  return extList;
}  

def remove_duplicates(listOfValues, delimeter){
    //listOfValues = (listOfValues!=null) ? listOfValues.toString().replaceAll("@#@#@#", ",") : "";
    listOfValues = (listOfValues!=null) ? listOfValues.toString().replaceAll(";;", "") : "";
    def valueList 
    if(delimeter == "#")
            valueList = (listOfValues!=null) ? listOfValues.split(/#/) : "";
    else if (delimeter == ";")
            valueList = (listOfValues!=null) ? listOfValues.split(/;/) : "";
    else    
            valueList = (listOfValues!=null) ? listOfValues.split(/,/) : "";
    for (valuecounter=0 ; valuecounter < valueList.size(); valuecounter++)
    {
             valueList[valuecounter] = valueList[valuecounter].trim()
    }
    displayDebug('remove_duplicates', "Input" + listOfValues)
    displayDebug('remove_duplicates', "Array" + valueList)
    def consolidate_values = valueList.toUnique().join("#")
    displayDebug('remove_duplicates', "AfterRemoveDuplicate" + consolidate_values)
    return consolidate_values
}


def getFileSummary(files){
   println(files)
   files = (files!=null) ? files.toString().replaceAll("\n", ",") : "";
   files = (files!=null) ? files.toString().replaceAll(";", ",") : "";
   def fileList = (files!=null) ? files.split(/,/) : "";
   def fileSummary= ""; def counter =0; def fileNames ="";
   println(fileSummary)
   extList = getFileTypes(fileList)
   println(extList)
   for (extcounter=0 ; extcounter < extList.size(); extcounter++)
      {
        extn = extList[extcounter]
        if(extn!="znoextn")
           fileSummary+= "<b>$extn Files</b> ==><br></br>";
        else
             fileSummary+= "<B>Files with no Extension</B> ==><br></br>  ";
        fileNames = "";
        for (filecounter=0 ; filecounter < fileList.size(); filecounter++)
         {
             file = fileList[filecounter]             
             if(file.endsWith("."+extn))
                {
                  if(fileNames == "")
                        fileNames = file;
                  else
                        fileNames += file; 
                  fileNames+="<br></br>";
                }
             else if(extn=="znoextn" && (file.lastIndexOf('.') < 0) && file.length()>0 && file.trim().length() > 0)
                {
                  if(fileNames == "")
                        fileNames = file;
                  else
                        fileNames += file;
                  fileNames+="<br></br>";                        
                }
         }
         fileSummary += fileNames
      }

    return fileSummary;
}


def changeBullets(myString,delimeter){
   displayDebug('changeBullets',myString)
   def summary=""
   if(myString.equals(null))
       return "";
   
   myString = (myString!=null) ? myString.toString().replaceAll("\n", delimeter) : "";
   
   points = myString.split(delimeter);
   displayDebug('changeBullets',points)
   for(counter=0; counter< points.size(); counter++)
   { 
        point=points[counter]
        if(point.trim() != "")
           {
             if(summary.equals(""))
                   summary+="<ul>";
			 summary += "<li>$point</li>"
            }
   }
   if(summary.equals(""))
       return "<p>NA</p>"
   else
     {
        summary+="</ul>";
        return summary;
      }
}


def maxVersion(col_name){
   strMaxQuery = "\nMAX(SUBSTR("+col_name+", 0, INSTR("+col_name+", '_',-1))) || MAX(TO_NUMBER(SUBSTR(REPLACE("+col_name+",'NA',''),INSTR("+col_name+", '_',-1)+1))) as " +col_name+ "_MAX"
   return strMaxQuery;
}

def consolidateColumn(col_name,delimeter){
   strcolumn = "\ndbms_lob.substr(rtrim (xmlagg (xmlelement (e, " + col_name + " || '" + delimeter + "')).extract( '//text()').getClobVal(),'" + delimeter + "'), 4000, 1 )  AS " +col_name+ "_LIST"
   return strcolumn;
}

def consolidateUniqueColumnValues(col_name){
   strcolumn = "\ndbms_lob.substr(REPLACE(REGEXP_REPLACE(rtrim (xmlagg (xmlelement (e, " + col_name + " || ';') order by " + col_name + " asc).extract ('//text()'), ';'),'([^;]+)(;\\1)+', '\\1'), ';', ','), 4000, 1 )  AS " +col_name+ "_LIST"
   return strcolumn;
}

def getEngineListDetailed(condition){ 
   strQuery = "select RELEASE_NO, COMPONENT_TYPE, ENGINE_NAME, " + maxVersion("EAR_VERSION") + ", "+ maxVersion("SQL_VERSION") + ", "+ maxVersion("EMS_VERSION") + ", " + consolidateUniqueColumnValues("JIRA_NO") + ", " + consolidateUniqueColumnValues("PROJECT_NAME") + ", " + consolidateUniqueColumnValues("CHANGE_DESCRIPTION") + ", " + consolidateUniqueColumnValues("OPERATION") + ", " + consolidateColumn("MASTER_GV","#") + ", " + consolidateColumn("PROCESS_GV","#") + ", " + consolidateUniqueColumnValues("FILE_CHANGES") + ", " + consolidateColumn("ENGINE_TEMPLATE",";") + ", " + consolidateColumn("APPEND_PREPEND",";") + ", " + consolidateColumn("KNOWN_ERROR_INCLUSION",";") + ", " + consolidateColumn("POST_MANUAL_CHANGES",";") + ", " + consolidateColumn("SPECIAL_INSTRUCTIONS",";") + ", " + consolidateColumn("RESTART_ENGINES",";") + ", " + consolidateUniqueColumnValues("ENGINE_TYPE") + ", " + consolidateColumn("BUILD_URL","\n") + " from CICD_RELEASE_SUMMARY where " + condition + " group by RELEASE_NO, COMPONENT_TYPE, ENGINE_NAME";
   rowList = myMultipleSelectQuery(strQuery);
   return rowList;
}


def getGatewayListDetailed(condition){
   strQuery = "select GATEWAY_TYPE, " + maxVersion("GATEWAY_VERSION") + ", dbms_lob.substr(rtrim (xmlagg (xmlelement (e, PARTNER_DATA || '\n')).extract( '//text()').getClobVal(),','), 4000, 1 ) PARTNER_DATA, dbms_lob.substr(rtrim (xmlagg (xmlelement (e, GATEWAY_TOKEN || '\n')).extract( '//text()').getClobVal(),','), 4000, 1 ) GATEWAY_TOKEN, dbms_lob.substr(rtrim (xmlagg (xmlelement (e, SPECIAL_INSTRUCTIONS || '\n')).extract( '//text()').getClobVal(),','), 4000, 1 ) SPECIAL_INSTRUCTIONS  from CICD_RELEASE_SUMMARY where " + condition + " group by RELEASE_NO, GATEWAY_TYPE";\
   rowList = myMultipleSelectQuery(strQuery);
   return rowList;
}

def removeFolderName(restartEngines)
{
    displayDebug('removeFolderName',restartEngines)
    def newRestartEngines = ""
    if(restartEngines.equals(null) || restartEngines=="")
              return "";
    engines = restartEngines.split(';');
    displayDebug('removeFolderName',engines)
    for(counter=0; counter< engines.size(); counter++)
    { 
        println(    )
        if(newRestartEngines!= "")
            newRestartEngines+= ";  "
        
        newRestartEngines += (engines[counter]).split('/')[1];
    }
    return newRestartEngines;
}



def get_release_notes_bw_sit(deployParams){
    def date_format_report = new Date().format("dd/MM/yyy HH:mm")
    def backgroundimage = "", subHeading = ""

    if(deployParams.isDraft == "true")
    {
           backgroundimage = " background=\"${WORKSPACE}/draft.jpg\""
           subHeading = " - DRAFT"
    }
    
    BW = "${params.BW_VERSION}"
    /*
    if(params.FILE_DEPLOYMENT)
    {
         BW += " (FILE DEPLOYMENT)"
    }
    if (params.ONLY_GV)
    {
         BW += " (ONLY GV)"
    }
    */
    project = getJIRAandProject(condition).split(",")[1]
    jira = getJIRAandProject(condition).split(",")[0]
	def body_build_summary = """
		${getcssContent()}
        <table class="tg" style="table-layout: fixed; width: 100%" ${backgroundimage}>        
		  <tr>
			<th class="tg-amwm" colspan="8">SIT Release for ${params.RELEASE}  ${subHeading}</th>
		  </tr>
          <tr>
			<th class="tg-amwm" colspan="8">${jira} | ${project}</th>
		  </tr>
         <tr>
            <td class="tg-1wig" colspan="1">PBI/JIRA/ADO/DEFECT</td>
            <td class="tg-0lax" colspan="3">${jira}</td>
			<td class="tg-1wig" colspan="1">PROJECT_NAME</td>
			<td class="tg-0lax" colspan="3">${project}</td>            
		  </tr>
          <tr>
            <td class="tg-1wig" colspan="1">Description of Change</td>
            <td class="tg-0lax" colspan="7">${deployParams.Description}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">Impacted TIL Operation(s)</td>
            <td class="tg-0lax" colspan="7">${deployParams.operationName}</td>
          </tr>
		  <tr>
            <td class="tg-1wig" colspan="1">Impacted Engine</td>
            <td class="tg-0lax" colspan="3">${params.ENGINE_NAME}</td>
           <td class="tg-1wig" colspan="1">Engine Type</td>
            <td class="tg-0lax" colspan="3">${deployParams.engine_type}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">BW Version</td>
            <td class="tg-0lax" colspan="3">${BW}</td>
            <td class="tg-1wig" colspan="1">EMS Version</td>
            <td class="tg-0lax" colspan="3">${params.EMS_VERSION}</td>            
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">SQL VERSION</td>
            <td class="tg-0lax" colspan="3">${params.SQL_VERSION}</td>
            <td class="tg-1wig" colspan="1">FILE DEPLOYMENT</td>
            <td class="tg-0lax" colspan="3">${params.FILE_DEPLOYMENT}</td>
          </tr>
           <tr>
            <td class="tg-1wig" colspan="1">ONLY_GV</td>
            <td class="tg-0lax" colspan="3">${params.ONLY_GV}</td>
            <td class="tg-1wig" colspan="1"></td>
            <td class="tg-0lax" colspan="3"></td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">TECH_CHANGES_INVOLVED</td>
            <td class="tg-0lax" colspan="7"><div class="multiline">${params.TECH_CHANGES_INVOLVED.replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
          </tr>
          <p id="bg-text" style="color:RED;font-size:40px;transform:rotate(300deg);-webkit-transform:rotate(300deg);">DRAFT DRAFT DRAFT</p>
          <tr>
			<th class="tg-amwm" colspan="8">File Deployments & Other Configurations</th>
		  </tr>
          <tr>
            <td class="tg-1wig" colspan="1">FILE Deployment Type</td>
            <td class="tg-0lax" colspan="7">${params.FILE_TYPES}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">FileChanges</td>
            <td class="tg-0lax" colspan="7">${deployParams.fileChanges}</td>
          </tr>

          <tr>
            <td class="tg-1wig" colspan="1">EngineTemplate</td>
            <td class="tg-0lax" colspan="7">${deployParams.engineTemplate}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">AppendPrependPath</td>
            <td class="tg-0lax" colspan="7">${deployParams.appendPrepand}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">KnownErrors</td>
            <td class="tg-0lax" colspan="7">${deployParams.knownError}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">PostManualChanges</td>
            <td class="tg-0lax" colspan="7">${deployParams.postManualChanges}</td>
          </tr>
          <tr> 
            <td class="tg-1wig" colspan="1">Special Instructions</td>
            <td class="tg-0lax" colspan="7">${deployParams.splInstructions}</td>
          </tr>         
          <tr>
			<td class="tg-1wig" colspan="1">Deployment Pipeline URL</td>
			<td class="tg-0lax" colspan="7"><div class="multiline">${deployParams.build_url.replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="1">LOG_URL</td>
			<td class="tg-0lax" colspan="7"><div class="multiline">${BUILD_URL}console</div></td>
		  </tr>
		</table>		
	"""
    
    println(body_build_summary);
	return body_build_summary
}	


def edit_summary(){
	def edit_summary = """
     <table class="tg" style="table-layout: fixed; width: 100%">        
		  <tr>
			<th class="tg-amwm" colspan="8">To Edit</th>
		  </tr>
		  <tr>
            <td class="tg-1wig" colspan="1">RELEASE</td>
            <td class="tg-0lax" colspan="3">${params.RELEASE}</td>
            <td class="tg-1wig" colspan="1">ENGINE NAME</td>
            <td class="tg-0lax" colspan="3">${params.ENGINE_NAME}</td>
          </tr>
           <tr>
             <td class="tg-1wig" colspan="1">BW Version</td>
            <td class="tg-0lax" colspan="3">${params.BW_VERSION} </td>
            <td class="tg-1wig" colspan="1">EMS Version</td>
            <td class="tg-0lax" colspan="3">${params.EMS_VERSION} </td>
          </tr>
           <tr>
             <td class="tg-1wig" colspan="1">SQL Version</td>
            <td class="tg-0lax" colspan="3">${params.SQL_VERSION} </td>
            <td class="tg-1wig" colspan="1">File Deployment</td>
            <td class="tg-0lax" colspan="3">${params.FILE_DEPLOYMENT}</td> 
          </tr>
          <tr>
             <td class="tg-1wig" colspan="1">ONLY GV</td>
            <td class="tg-0lax" colspan="3">${params.ONLY_GV}</td>
            <td class="tg-1wig" colspan="1">Release Summary ID</td>
            <td class="tg-0lax" colspan="3">${getReleaseSummaryID(condition)}</td> 
          </tr>
          <tr>
			<td class="tg-1wig" colspan="1">Edit Utility</td>
			<td class="tg-0lax" colspan="7">http://195.233.197.150:8080/jenkins/job/TIL_PIPELINES/job/SIT_RELEASE_REQUEST/job/RELEASE_SUMMARY_EDIT/</td>
		  </tr>
     </table>
     """
	return edit_summary
}

def getLinks()
{
    def linkSummary = """
        <table class="tg" style="table-layout: fixed; width: 100%">        
		  <tr>
			<th class="tg-amwm" colspan="8">Links</th>
		  </tr>
          <tr>
            <td class="tg-1wig" colspan="2">TA_DETAIL</td>
            <td class="tg-0lax" colspan="6"><div class="multiline">${params.TA_DETAIL.replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="2">TECH_CHANGES_INVOLVED</td>
            <td class="tg-0lax" colspan="2"><div class="multiline">${params.TECH_CHANGES_INVOLVED.replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
            <td class="tg-1wig" colspan="2">TESTING_PERFORMED</td>
            <td class="tg-0lax" colspan="2"><div class="multiline">${params.TESTING_PERFORMED.replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="2">TESTING_PERFORMED</td>
            <td class="tg-0lax" colspan="2"><div class="multiline">${params.TESTING_PERFORMED.replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
            <td class="tg-1wig" colspan="2">LINKTEST_STATUS</td>
            <td class="tg-0lax" colspan="2"><div class="multiline">${params.LINKTEST_STATUS.replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="2">REG_TESTCASE_EXEC</td>
            <td class="tg-0lax" colspan="2"><div class="multiline">${params.REG_TESTCASE_EXEC.replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
            <td class="tg-1wig" colspan="2">PROG_TESTCASE_EXEC</td>
            <td class="tg-0lax" colspan="2"><div class="multiline">${params.PROG_TESTCASE_EXEC.replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
          </tr>          
          <tr>
            <td class="tg-1wig" colspan="2">TEST_SHEET_LOCATION</td>
            <td class="tg-0lax" colspan="6"><div class="multiline">${params.TEST_SHEET_LOCATION.replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="2">LOG_LOCATION</td>
            <td class="tg-0lax" colspan="6"><div class="multiline">${params.LOG_LOCATION.replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="2">ARTIFACT_LOCATION</td>
            <td class="tg-0lax" colspan="6"><div class="multiline">${params.ARTIFACT_LOCATION.replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="2">SUPPLIMENT_DOC_LOCATION</td>
            <td class="tg-0lax" colspan="6"><div class="multiline">${params.SUPPLIMENT_DOC_LOCATION.replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="2">DESIGN_PPT_LOCATION</td>
            <td class="tg-0lax" colspan="6"><div class="multiline">${params.DESIGN_PPT_LOCATION.replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="2">LLD_LOCATION</td>
            <td class="tg-0lax" colspan="6"><div class="multiline">${params.LLD_LOCATION.replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
          </tr>      
          <tr>
            <td class="tg-1wig" colspan="2">FUNCTIONAL_DEPENDENCIES</td>
            <td class="tg-0lax" colspan="6"><div class="multiline">${params.FUNCTIONAL_DEPENDENCIES.replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
          </tr>          
		</table>		
	"""
    return linkSummary;
}

def getEmailSubject(condition)
{
    engList = getEngineListDetailed(condition);
    if(engList.size() < 1)
    {
       error("Please check engine name and version number.")
       currentBuild.result = 'FAILURE'
       return false;
    }
    row = engList[0];
    project_list = (row['PROJECT_NAME_LIST'] != null) ? row['PROJECT_NAME_LIST'].toString() : "";
    jira_list = (row['JIRA_NO_LIST'] != null) ? row['JIRA_NO_LIST'].toString() : "";
    EMAIL_SUBJECT = "[${params.RELEASE}]" + "-" + "${params.DEPLOYMENT_TYPE}" + " SIT Release Notification for ${params.ENGINE_NAME} " + "[" + jira_list + "-"  + project_list + "]"
    return true;
}


def getJIRAandProject(condition)
{
    engList = getEngineListDetailed(condition);
    if(engList.size() < 1)
    {
       error("Please check engine name and version number.")
       currentBuild.result = 'FAILURE'
       return false;
    }
    row = engList[0];
    project_list = (row['PROJECT_NAME_LIST'] != null) ? row['PROJECT_NAME_LIST'].toString() : "";
    jira_list = (row['JIRA_NO_LIST'] != null) ? row['JIRA_NO_LIST'].toString() : "";
    return  jira_list + ","  + project_list    
} 

def getSITRNemailContent(deployParams)
{
    def emailContent = ""
    engList = getEngineListDetailed(condition);
    if(engList.size() < 1)
    {
       println("*******Number of Engines is zero **********");
       return false;
    }
    
    engNumber = 1;
    for(engCounter=0; engCounter < engList.size(); engCounter++)
    {
            row = engList[engCounter];
            displayDebug("ISTIL Engine List","Engine $engCounter")
            
            releaseID = (row['RELEASE_SUMMARY_ID'] != null) ? row['RELEASE_SUMMARY_ID'] : "";
            releaseNumber = (row['RELEASE_NO'] != null) ? row['RELEASE_NO'] : "";
            componentType = (row['COMPONENT_TYPE'] !=null) ? row['COMPONENT_TYPE'] : "";
            earVersion =  ((row['EAR_VERSION_MAX']!= '') ? row['EAR_VERSION_MAX'] : "NA")
            sqlVersion =  ((row['SQL_VERSION_MAX']!= '') ? row['SQL_VERSION_MAX'] : "NA")
            emsVersion =  ((row['EMS_VERSION_MAX']!= '') ? row['EMS_VERSION_MAX'] : "NA")                    
            engineName = (row['ENGINE_NAME'] != null) ? row['ENGINE_NAME'].toString() : "";				
            project_list = (row['PROJECT_NAME_LIST'] != null) ? row['PROJECT_NAME_LIST'].toString() : "";            
            jira_list = (row['JIRA_NO_LIST'] != null) ? row['JIRA_NO_LIST'].toString() : "";
            engine_type = (row['ENGINE_TYPE_LIST'] != null) ? row['ENGINE_TYPE_LIST'].toString() : "";
            build_url = (row['BUILD_URL_LIST'] != null) ? row['BUILD_URL_LIST'].toString() : "";

            fileChanges = (row['FILE_CHANGES_LIST'] != null) ? row['FILE_CHANGES_LIST'].toString() : "";
            //fileChanges = remove_duplicates(fileChanges.replaceAll("\n", ","), ";") 
            //fileChanges = changeBullets(fileChanges,",");
            
            changeDescription = (row['CHANGE_DESCRIPTION_LIST'] != null) ? row['CHANGE_DESCRIPTION_LIST'].toString() : "";
            //changeDescription = remove_duplicates(changeDescription.replaceAll("\n", ","), ";") 
            //changeDescription = changeBullets(changeDescription,",");
            
            operation = (row['OPERATION_LIST'] != null) ? row['OPERATION_LIST'].toString() : "";
            //operation = remove_duplicates(operation.replaceAll("\n", ","), ";") 
            //operation = changeBullets(operation,",");
            
            masterGV = (row['MASTER_GV_LIST'] != null) ? row['MASTER_GV_LIST'].toString() : "";
            //masterGV = remove_duplicates(masterGV.replaceAll("\n", "#"), "#") 
            //masterGV = changeBullets(masterGV,"#");
            
            processGV = (row['PROCESS_GV_LIST'] != null) ? row['PROCESS_GV_LIST'].toString() : "";
            //processGV = remove_duplicates(processGV.replaceAll("\n", "#"), "#") 
            //processGV = changeBullets(processGV,"#");
            
            engineTemplate = (row['ENGINE_TEMPLATE_LIST'] != null) ? row['ENGINE_TEMPLATE_LIST'].toString() : "";
            //engineTemplate = remove_duplicates(engineTemplate.replaceAll("\n", ","), ";") 
            //engineTemplate = changeBullets(engineTemplate,",");
            
            appendPrepand = (row['APPEND_PREPEND_LIST'] != null) ? row['APPEND_PREPEND_LIST'].toString() : ""
            //appendPrepand = remove_duplicates(appendPrepand.replaceAll("\n", ","), ";") 
            //appendPrepand = changeBullets(appendPrepand,",");
            
            knownError = (row['KNOWN_ERROR_INCLUSION_LIST'] != null) ? row['KNOWN_ERROR_INCLUSION_LIST'].toString() : "";
            //knownError = remove_duplicates(knownError.replaceAll("\n", ","), ";") 
            //knownError = changeBullets(knownError,",");
            
            postManualChanges = (row['POST_MANUAL_CHANGES_LIST'] != null) ? row['POST_MANUAL_CHANGES_LIST'].toString() : "";
            //postManualChanges = remove_duplicates(postManualChanges.replaceAll("\n", ","), ";") 
            //postManualChanges = changeBullets(postManualChanges,",");
            
            splInstructions = (row['SPECIAL_INSTRUCTIONS_LIST'] != null) ? row['SPECIAL_INSTRUCTIONS_LIST'].toString() : "";
            //splInstructions = remove_duplicates(splInstructions.replaceAll("\n", ","), ";") 
            //splInstructions = changeBullets(splInstructions,",");
            
            restartEngines = (row['RESTART_ENGINES_LIST'] != null) ? row['RESTART_ENGINES_LIST'].toString() : "";
            //restartEngines = remove_duplicates(removeFolderName(restartEngines).replaceAll(";", ","), ";")
            //restartEngines = changeBullets(restartEngines,",");
            
            if(fileChanges!=null && fileChanges.toString().trim()!="")
            {
               //fileChanges = getFileSummary(fileChanges)
            }
            else
               fileChanges = "No File Changes"
           
                 
            emailContent+= get_release_notes_bw_sit isDraft:"${deployParams.isDraft}", isEdit:"${deployParams.isEdit}", BW_VERSION: earVersion, EMS_VERSION: emsVersion, SQL_VERSION: sqlVersion, ENGINE_NAME: engineName, JIRA: jira_list, PROJECT: project_list, operationName: operation.replaceAll("[\\t\\n\\r]+","<br>"), Description: changeDescription.replaceAll("[\\t\\n\\r]+","<br>"),  fileChanges: fileChanges.replaceAll("[\\t\\n\\r]+","<br>"), masterGV: masterGV.replaceAll("[\\t\\n\\r]+","<br>"), processGV: processGV.replaceAll("[\\t\\n\\r]+","<br>"), engineTemplate: engineTemplate.replaceAll("[\\t\\n\\r]+","<br>"), appendPrepand: appendPrepand.replaceAll("[\\t\\n\\r]+","<br>"), knownError: knownError.replaceAll("[\\t\\n\\r]+","<br>"), postManualChanges: postManualChanges.replaceAll("[\\t\\n\\r]+","<br>"), splInstructions: splInstructions.replaceAll("[\\t\\n\\r]+","<br>"), restartEngines: restartEngines.replaceAll("[\\t\\n\\r]+","<br>"), engine_type: engine_type.replaceAll("[\\t\\n\\r]+","<br>"), build_url: build_url.replaceAll("[\\t\\n\\r]+","<br>") 
            
            if(deployParams.isEdit == "true")
            { 
                emailContent += edit_summary()
            }            
    }
    if(deployParams.isDraft == "true")
    {
        //emailContent += getLinks() 
    }    
    println("============================================================")    
    println(emailContent)
    return emailContent
	
}



def preparation_function() {

        SITReleaseTechLeadApprovers = get_approvers_list('SITReleaseTechLeadApprovers')
        println(getBuildUserID())
        println(getUserEmail(getBuildUserID()))
        buildRequestorMail = getUserEmail(getBuildUserID())
        SUBMITTED_USER = currentBuild.rawBuild.causes[0].userId
        SUBMITTED_DATE = new Date().format("dd/MM/yyy HH:mm")
       
        checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'JENKINS_FILE']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_DevOps_Framework.git']]])

        commonFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/commonFunctions.groovy"
        DB_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/dbFunctions.groovy"
        echo "Preparation is done"        
     
}

def trigger_email(deployParams){

	emailext mimeType: 'text/html',
    subject: "[Jenkins]: ${EMAIL_SUBJECT} SIT - ${deployParams.mailsubject}",
	from:"TIL_SIT_RN_APPROVAL@vodafone.com",
	to: "${deployParams.mailRecipients}",
	body: "${ApprovalemailContent()}" 
}

def getcssContent(){
    def css = """
        <style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Times, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;width:150px;word-break:break-all;border-color:#9ABAD9;color:#444;}
		.tg th{font-family:Times, sans-serif;font-size:26px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:break-all;border-color:#9ABAD9;color:#1A0504;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		.tg .tg-pass{background-color:lightgreen;text-align:left;vertical-align:top}
		.tg .tg-fail{background-color:red;text-align:left;vertical-align:top}
		.tg .tg-notstarted{background-color:lightgrey;text-align:left;vertical-align:top}
		.tg .tg-notrequired{background-color:#E1E0A2;text-align:left;vertical-align:top}
		</style>
        """
     return css
}


def ApprovalemailContent(){
    project = getJIRAandProject(condition).split(",")[1]
    jira = getJIRAandProject(condition).split(",")[0]    
	def body_build_summary = """
		${getcssContent()}
		<table class="tg" style="table-layout: fixed; width: 100%"">
		  <tr>
			<th class="tg-amwm" colspan="8">SIT RELEASE NOTES - Request Approval</th>
		  </tr>
          <tr>
			<td class="tg-1wig" colspan="2">RELEASE</td>
			<td class="tg-0lax" colspan="6">${params.RELEASE} </td>
		  </tr>
          <tr>
			<td class="tg-1wig" colspan="2">ENGINE NAME</td>
			<td class="tg-0lax" colspan="6">${params.ENGINE_NAME}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">BW_VERSION</td>
			<td class="tg-0lax" colspan="6">${params.BW_VERSION}</td>
		  </tr>
 		  <tr>
			<td class="tg-1wig" colspan="2">EMS_VERSION</td>
            <td class="tg-0lax" colspan="6">${params.EMS_VERSION}</td>
		  </tr>
   		  <tr>
			<td class="tg-1wig" colspan="2">SQL_VERSION</td>
			<td class="tg-0lax" colspan="6">${params.SQL_VERSION}</td>
		  </tr>
          <tr>
            <td class="tg-1wig" colspan="1">ONLY_GV</td>
            <td class="tg-0lax" colspan="3">${params.ONLY_GV}</td>
            <td class="tg-1wig" colspan="1">FILE DEPLOYMENT</td>
            <td class="tg-0lax" colspan="3">${params.FILE_DEPLOYMENT}</td>
          </tr>
          <tr>
			<td class="tg-1wig" colspan="1">PROJECT_NAME</td>
			<td class="tg-0lax" colspan="3">${project}</td>
            <td class="tg-1wig" colspan="1">PBI/JIRA/ADO/DEFECT</td>
            <td class="tg-0lax" colspan="3">${jira}</td>
		  </tr>
          <tr>
			<td class="tg-1wig" colspan="2">TA DETAIL</td>
			<td class="tg-0lax" colspan="6">${params.TA_DETAIL}</td>
		  </tr>
  		  <tr>
			<td class="tg-amwm" colspan="2">Role</td>
            <td class="tg-amwm" colspan="1">Status</td>
            <td class="tg-amwm" colspan="3">Comments</td>
			<td class="tg-amwm" colspan="1">User</td>
			<td class="tg-amwm" colspan="1">DATE</td>			
		  </tr> 
          <tr>
			<td class="tg-0lax" colspan="2">Developer</td>
            <td class="tg-0lax" colspan="1">SUBMITTED</td>
			<td class="tg-0lax" colspan="3"></td>
            <td class="tg-0lax" colspan="1">${SUBMITTED_USER}</td>
			<td class="tg-0lax" colspan="1">${SUBMITTED_DATE}</td>			
		  </tr> 
          <tr>
			<td class="tg-0lax" colspan="2">Team Lead Approval</td>
			<td class="tg-0lax" colspan="1">${Apvl_TL_Status}</td>
            <td class="tg-0lax" colspan="3">${Apvl_TL_Comments}</td>
            <td class="tg-0lax" colspan="1">${Apvl_TL_Name}</td>
            <td class="tg-0lax" colspan="1">${Apvl_TL_Date}</td>			
		  </tr>          
          <tr>
			<td class="tg-1wig" colspan="2">Tech Leads</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${SITReleaseTechLeadApprovers}</div></td>
		  </tr>
          <tr>
			<td class="tg-1wig" colspan="2">ARTIFACTS LOCATION</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${params.ARTIFACT_LOCATION.replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
		  </tr>	
          <tr>
			<td class="tg-1wig" colspan="2">Approval Link</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${BUILD_URL}console</div></td>
		  </tr>	          
		</table>		
	"""
    body_build_summary+=getSITRNemailContent isDraft: "true", isEdit: "false"
	return body_build_summary
}


def validate_RN_parameters() {
	validationCheck = ""

        if(!params.ONLY_GV && !params.FILE_DEPLOYMENT)
        {
            if(params.BW_VERSION.trim().length() == 0 && params.EMS_VERSION.trim().length() == 0 && params.SQL_VERSION.trim().length() == 0 )
            {
                error("Enter either BW Version or EMS Version or SQL Version, If Only GV and File Deployment not selected")
                validationCheck = "F"
            }
        }          
        
        if(params.TECH_CHANGES_INVOLVED.trim() == ""){
			error("Please select the list of Tech changes involved")
		    validationCheck = "F"			
		}

        /*
        if(params.TA_DETAIL.trim() == ""){
			error("Please enter the TA Detail")
		    validationCheck = "F"			
		}

        if(params.TESTING_PERFORMED.trim() == ""){
			error("Please select the type of testing performed")
		    validationCheck = "F"			
		}

        if(params.LINKTEST_STATUS.trim() == ""){
			error("Please select the testing status")
		    validationCheck = "F"			
		} 

        if(params.STUB_TESTED.trim() == ""){
			error("Please select the stub tested")
		    validationCheck = "F"			
		}

        if(params.REG_TESTCASE_EXEC.trim() == ""){
			error("Please enter the no of regression testcase executed")
		    validationCheck = "F"			
		}

        if(params.PROG_TESTCASE_EXEC.trim() == ""){
			error("Please enter the no of progression testcase executed")
		    validationCheck = "F"			
		}

        if(params.TEST_SHEET_LOCATION.trim() == ""){
			error("Please enter the test sheet location")
		    validationCheck = "F"			
		} 
        
        if(params.ARTIFACT_LOCATION.trim() == ""){
			error("Please enter the artifact location")
		    validationCheck = "F"			
		}

        if(params.LOG_LOCATION.trim() == ""){
			error("Please enter the log location")
		    validationCheck = "F"			
		} 
        
        if(params.SUPPLIMENT_DOC_LOCATION.trim() == ""){
			error("Please enter the suppliment location if any")
		    validationCheck = "F"			
		}

        if(params.DESIGN_PPT_LOCATION.trim() == ""){
			error("Please enter the Design PPT Location")
		    validationCheck = "F"			
		} 
        
        if(params.LLD_LOCATION.trim() == ""){
			error("Please enter the LLD Location")
		    validationCheck = "F"			
		}
        */
	
		if(validationCheck == "F"){
			error("Pipeline Input parameter validation failed. Please check the errors in Console log.")
			currentBuild.result = 'FAILURE'
		}
}

def getRNID()
{
   strQuery = "SELECT RN_ID FROM CICD_RN_DATA where CREATED_BY = '${SUBMITTED_USER}' and BUILD_ID = '${BUILD_NUMBER}'"
   rowList = mySingleSelectQuery(strQuery);
   if(rowList.size() == 0)
   {
       error("Error checking RN")
       currentBuild.result = 'FAILURE'
   }
   RN_ID = (rowList["RN_ID"] != null ) ? rowList["RN_ID"].toString() : ""
   return RN_ID;
}

buildRequestorMail = ""
SITReleaseTechLeadApprovers = ""
TLapprovers_mailRecipients = "devops-vfuk-integration@vodafone.com"
SIT_mailRecipients = "devops-vfuk-integration@vodafone.com"
condition =""

Apvl_TL_Name=""
Apvl_TL_Status=""
Apvl_TL_Date=""
Apvl_TL_Comments=""

EMAIL_SUBJECT=""

SUBMITTED_USER=""
SUBMITTED_DATE=""
APPROVAL_COMMENTS=""

pipeline {
    agent any
    
options {
     timeout(time: 1, unit: 'DAYS')
}
    
environment {
        REPO_URL = "http://195.233.197.150:8081/repository"
		NEXUS_URL = "http://195.233.197.150:8081"
		NEXUS_USER = "admin"
		NEXUS_PASSWD = "admin123"
		BW_GROUPID = "TIL_BW"
		EMS_GROUPID = "TIL_EMS"
		SQL_GROUPID="TIL_SQL"
        SOURCE_REPO="LINKTEST_REPO"
		TARGET_REPO = "SIT_REPO"
        dbURL = 'jdbc:oracle:thin:@195.233.199.13:33000:TIBTST1'
		dbUserName = 'CICD_OWN_DB01'
		dbPassword = 'TIL_CICD_DB'
		dbDriver = 'oracle.jdbc.driver.OracleDriver'
    }
    
    stages {
		stage('Preparation') {
            options {
                timeout(time: 1, unit: 'DAYS')
            }
			steps {
				script{
					//deleteDir()
					//Call the preparation function.
					preparation_function()
                    
                    // Validate input parameters by calling the global function. This is located in vars folder in GITHUB.
                    commonFunctions.validate_input_parameters RELEASE: params.RELEASE
                    if(params.BW_VERSION){
                        commonFunctions.validate_input_parameters RELEASE: params.RELEASE, BW_VERSION: params.BW_VERSION 
                    }
                    if(params.EMS_VERSION){
                        commonFunctions.validate_input_parameters RELEASE: params.RELEASE, EMS_VERSION: params.EMS_VERSION 
                    }
                    if(params.SQL_VERSION){
                        commonFunctions.validate_input_parameters RELEASE: params.RELEASE, SQL_VERSION: params.SQL_VERSION 
                    }
                                        
                    validate_RN_parameters()
                    
                    currentBuild.displayName = "RN${BUILD_NUMBER}_${params.RELEASE}_${params.ENGINE_NAME}"
                    
                    
                    conditionList = []
                    if(params.BW_VERSION.length() != 0){
                                getReleaseSummaryID('EAR_VERSION', params.BW_VERSION)
                                condition = "EAR_VERSION = '${params.BW_VERSION}'"
                                conditionList.add(condition)
                    }   
                        
                    if(EMS_VERSION.length() != 0){
                                getReleaseSummaryID('EMS_VERSION', EMS_VERSION)
                                condition = "EMS_VERSION = '${params.EMS_VERSION}'"
                                conditionList.add(condition)  
                        }
                    if(SQL_VERSION.length() != 0){
                                getReleaseSummaryID('SQL_VERSION', SQL_VERSION)
                                condition = "SQL_VERSION = '${params.SQL_VERSION}'"
                                conditionList.add(condition)
                        }
                      
                    if(params.FILE_DEPLOYMENT)
                    {
                        if(params.BW_VERSION.length() == 0){
                            condition = "EAR_VERSION = '1'"
                            conditionList.add(condition)
                        }                        
                    }
                    
                    if(params.ONLY_GV)
                    {
                        if(params.BW_VERSION.length() == 0){
                            condition = "EAR_VERSION = '0'"
                            conditionList.add(condition)
                        }
                    }
                    
                    condition = ""
                    for (counter=0 ; counter < conditionList.size(); counter++)                        
                    {
                       if(counter != 0)
                            condition += " OR "
                       condition +=  conditionList[counter] + " \n" 
                    }
                    condition =  "RELEASE_NO='${env.RELEASE}' AND ENGINE_NAME='${params.ENGINE_NAME}' AND " + condition
                    
                    
                    /*
                    conditionList = []
                    if(params.BW_VERSION.length() != 0){
                                condition = " and EAR_VERSION='${params.BW_VERSION}'"
                                conditionList.add(condition)
                    }   
                        
                    if(EMS_VERSION.length() != 0){
                                condition = " and EMS_VERSION='${params.EMS_VERSION}'"
                                conditionList.add(condition)  
                        }
                        
                    if(SQL_VERSION.length() != 0){
                                condition = ""
                                if(params.BW_VERSION.length() == 0){
                                    condition = " and EAR_VERSION='1'"
                                }
                                condition += " and SQL_VERSION='${params.SQL_VERSION}'"
                                conditionList.add(condition)
                                
                        }
                      
                    if(params.FILE_DEPLOYMENT)
                    {
                        if(params.BW_VERSION.length() == 0){
                            condition = " and EAR_VERSION='1'"
                            conditionList.add(condition)
                        }
                    }
                    
                    if(params.ONLY_GV)
                    {
                        if(params.BW_VERSION.length() == 0){
                            condition = " and EAR_VERSION='0')"
                            conditionList.add(condition)
                        }
                    }

                    condition = ""
                    for (counter=0 ; counter < conditionList.size(); counter++)                        
                    {
                       condition +=  conditionList[counter] //+ " \n"
                    }


                    if(condition.length() != 0){
                        condition = "RELEASE_NO='${env.RELEASE}' AND (" + condition + ")"
                    }
                    else{
                        condition = "RELEASE_NO='${env.RELEASE}' AND (ENGINE_NAME = '${params.ENGINE_NAME}')"
                    } 
                    condition =  "RELEASE_NO='${env.RELEASE}' AND ENGINE_NAME='${params.ENGINE_NAME}'" + condition
                    */
                    
                    println(condition)
                    build_list=getReleaseSummaryID(condition)
                    selected_deployments = ""
                    if(build_list.contains("~"))
                    {
                        buildSummary = getBuildSummary(condition, build_list)
                        buildSummary = buildSummary.replaceAll("\n","<br></br>")
                    
                         listSize = build_list.split("~").length + 1
                    
                         multiSelect= getMultipleChoiceInput('List of Deployments', 'Deployments', build_list.replaceAll("~", ","), buildSummary, listSize)  
                         selected_deployments = input  id: 'customID', message: 'Multiple Deployment Found. \n Please select your deployments', ok: 'Select', parameters: [multiSelect]  
                        displayDebug('SelectDeployment', selected_deployments)
                        condition += " AND RELEASE_SUMMARY_ID IN (" + selected_deployments + ")"
                    }
                    else
                    {
                        selected_deployments = build_list
                    }
                    
                    println(condition)                    
                }
	
			}			
		}//stage Preparation
        
        
        stage('Send Draft Mail') {
            when {
				expression { getEmailSubject(condition) }
			}
			steps {
				script{	
                    emailContent=getSITRNemailContent isDraft: "true", isEdit: "true"
                    emailext mimeType: 'text/html', 
                     subject: "[Jenkins]: ${EMAIL_SUBJECT} - Draft",  
                     from:"TIL_SIT_RN_APPROVAL@vodafone.com", 
                     to: "${buildRequestorMail}", 
                     body: "${emailContent}"                   
                }
            }
        }
        
        
    }//stages    
}
      
