import com.cwctravel.hudson.plugins.extended_choice_parameter.ExtendedChoiceParameterDefinition

import org.docx4j.convert.in.xhtml.XHTMLImporterImpl;
import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.docx4j.openpackaging.parts.WordprocessingML.MainDocumentPart;
import org.docx4j.convert.out.pdf.PdfConversion;
import org.docx4j.convert.out.pdf.viaXSLFO.PdfSettings;

import org.docx4j.wml.Body;
import org.docx4j.wml.FldChar;
import org.docx4j.wml.ObjectFactory;
import org.docx4j.wml.P;
import org.docx4j.wml.R;
import org.docx4j.wml.STFldCharType;
import org.docx4j.wml.Text;
import org.docx4j.jaxb.Context;
import org.docx4j.wml.Br;

import org.docx4j.openpackaging.parts.WordprocessingML.HeaderPart;
import org.docx4j.openpackaging.parts.WordprocessingML.FooterPart;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;
import org.docx4j.openpackaging.parts.relationships.Namespaces;
import org.docx4j.relationships.Relationship;

import org.docx4j.Docx4J;

//==============================Database Function====================================================

def displayDebug(strModule, strDebugMessage)
{
  def debug=1;
  if(debug == 1)
     {   
         println("***************************************")
         println("Module :" + strModule)
         println("Debug Message :" + strDebugMessage)
     }
}

def myGetDBConnect() {     
     def dbURL = 'jdbc:oracle:thin:@aukshocr.dc-dublin.de:33000:TIBTST1'
     def dbUserName = 'CICD_OWN_DB01'
     def dbPassword = 'TIL_CICD_DB'
     def dbDriver = 'oracle.jdbc.driver.OracleDriver'
     displayDebug('myGetDBConnect','Establishing DB Connectivity')
     def mySQL = groovy.sql.Sql.newInstance(dbURL,dbUserName,dbPassword,dbDriver)
     return mySQL                   
}


def myMultipleSelectQuery(selectQuery){     
     def mySQL =  myGetDBConnect()
  	 def rowData = [:]
	 def resultList = []
     displayDebug('myMultipleSelectQuery',selectQuery)
     def rowResults = mySQL.rows(selectQuery)
     mySQL.close()
     if(rowResults.size() == 0)
            return resultList;
     def headerList = new ArrayList(rowResults[0].keySet())
	 for(def rlcounter=0;rlcounter<rowResults.size();rlcounter++)
     {
         def row = rowResults[rlcounter];
         rowData = [:]
         for(def rwHeaderCnt=0;rwHeaderCnt<headerList.size();rwHeaderCnt++)
         { 
               rowData.put(headerList[rwHeaderCnt], row[rwHeaderCnt]!= null  ? row[rwHeaderCnt].toString() : "")
         }
		 resultList.add(rowData)
     }
	 headerList=null;
	rowResults = null;
	rowData = null;
	mySQL = null;
    return resultList;
}


def mySingleSelectQuery(selectQuery){
     def mySQL =  myGetDBConnect()
  	 def rowData = [:]
     displayDebug('mySingleSelectQuery',selectQuery)
     def rowResults = mySQL.rows(selectQuery)
     mySQL.close();
     def headerList = new ArrayList(rowResults[0].keySet())
     for(def rlcounter=0;rlcounter<rowResults.size();rlcounter++)
     {
         def row = rowResults[rlcounter];
         rowData = [:]
         for(def rwHeaderCnt=0;rwHeaderCnt<headerList.size();rwHeaderCnt++)
         { 
           rowData.put(headerList[rwHeaderCnt], row[rwHeaderCnt]!= null  ? row[rwHeaderCnt].toString() : "")
         }
     }
	rowResults = null;
	mySQL = null;
	headerList = null;
    return rowData;
}


def myExecUpdateQuery(queryString) {
     def mySQL =  myGetDBConnect()
     mySQL.connection.autoCommit = false  
                 try {
                     println("Executing Update Query :" + queryString)
         int rowAffected = mySQL.executeUpdate(queryString);
         mySQL.commit()
         if(rowAffected > 0)
         {
         println("Successfully updated " + rowAffected + " rows") 
         }
         else
         {
           println("No records updated")
           return false;
         }
      }catch(Exception ex) {
         println("Error in Executing Update Query :" + queryString) 
                                 mySQL.rollback()
         println("Transaction rollback") 
         return false;
      }
      finally {
                     println("Trying to close the connection")
                     mySQL.close()
                                println("SQL Connection closed")
                  }
     return true
   }

 


def getFileTypes(fileList)
{
  def extList = [];
  for (counter=0 ; counter < fileList.size(); counter++)
   {
        file = fileList[counter]
        if (file.lastIndexOf('.') < 0 && file.trim().length() > 0)
              extList.add("znoextn")    
        else if (file.length() > 0 && file.trim().length() > 0)
              extList.add(file.substring(file.lastIndexOf('.')+1)) 
   }
   extList = extList.toUnique();
  println("Extn List "+extList);
  return extList;
  //return extList.unique(false).sort { it };
}  

def remove_duplicates(listOfValues)
{
    listOfValues = (listOfValues!=null) ? listOfValues.toString().replaceAll("@#@#@#", ",") : "";
    //listOfValues = (listOfValues!=null) ? listOfValues.toString().replaceAll(";", ",") : "";
     def valueList = (listOfValues!=null) ? listOfValues.split(/,/) : "";
    for (valuecounter=0 ; valuecounter < valueList.size(); valuecounter++)
    {
             valueList[valuecounter] = valueList[valuecounter].trim()
    }

    displayDebug('remove_duplicates', "Input" + listOfValues)
    displayDebug('remove_duplicates', "Array" + valueList)
    def consolidate_values = valueList.toUnique().join(",")
    displayDebug('remove_duplicates', "AfterRemoveDuplicate" + consolidate_values)
    return consolidate_values
}


def getFileSummary(files)
{
   files = (files!=null) ? files.toString().replaceAll("\n", ",") : "";
   files = (files!=null) ? files.toString().replaceAll(";", ",") : "";
   def fileList = (files!=null) ? files.split(/,/) : "";
   def fileSummary= ""; def counter =0; def fileNames ="";
   
   extList = getFileTypes(fileList)
   for (extcounter=0 ; extcounter < extList.size(); extcounter++)
      {
        extn = extList[extcounter]
        if(extn!="znoextn")
           fileSummary+= "<b>$extn Files</b> ==><br></br>";
        else
             fileSummary+= "<B>Files with no Extension</B> ==><br></br>  ";
        fileNames = "";
        for (filecounter=0 ; filecounter < fileList.size(); filecounter++)
         {
             file = fileList[filecounter]             
             if(file.endsWith("."+extn))
                {
                  if(fileNames == "")
                        fileNames = file;
                  else
                        fileNames += ";\n" + file; 
                  fileNames+="<br></br>";
                }
             else if(extn=="znoextn" && (file.lastIndexOf('.') < 0) && file.length()>0 && file.trim().length() > 0)
                {
                  if(fileNames == "")
                        fileNames = file;
                  else
                        fileNames += ";\n" + file;
                  fileNames+="<br></br>";                        
                }
         }
         fileSummary += fileNames
      }

    return fileSummary;
}


def changeBullets(myString,delimeter)
{
   displayDebug('changeBullets',myString)
   def summary=""
   if(myString.equals(null))
       return "";
   
   myString = (myString!=null) ? myString.toString().replaceAll("\n", delimeter) : "";
   //myString = (myString!=null) ? myString.toString().replaceAll(";", delimeter) : "";
   //myString = (myString!=null) ? myString.toString().replaceAll(",", delimeter) : "";
   
   points = myString.split(delimeter);
   println("***************************************************$points");
   displayDebug('changeBullets',points)
   for(counter=0; counter< points.size(); counter++)
   { 
        point=points[counter]
        if(point.trim() != "")
           {
             if(summary.equals(""))
                   summary+="<ul>";
			 summary += "<li>$point</li>"
            }
   }
   if(summary.equals(""))
       return "<p>NA</p>"
   else
     {
        summary+="</ul>";
        return summary;
      }
}


def maxVersion(col_name)
{
   //strMaxQuery = " CONCAT(MAX(SUBSTRING_INDEX("
   //strMaxQuery += col_name 
   //strMaxQuery += """, '_',2)),'_',REPLACE(LTRIM(REPLACE(MAX(LPAD(SUBSTRING_INDEX("""
   //strMaxQuery += col_name
   //strMaxQuery += ",'_',-1), 2, '0')),'0',' ')),' ','0')) "+ col_name + " ";
   
   //strMaxQuery = "MAX(SUBSTR("+col_name+", 0, INSTR("+col_name+", '_',-1))) AS "+col_name+"_PREFIX, "
   //strMaxQuery += "MAX(TO_NUMBER(SUBSTR(REPLACE("+col_name+",'NA',''), INSTR("+col_name+", '_',-1)+1))) as " +col_name+ "_MAX "
   
   strMaxQuery = "MAX(SUBSTR("+col_name+", 0, INSTR("+col_name+", '_',-1))) || MAX(TO_NUMBER(SUBSTR(REPLACE("+col_name+",'NA',''),INSTR("+col_name+", '_',-1)+1))) as " +col_name+ "_MAX"
   
   return strMaxQuery;
}

def getReleaseSummaryISTIL(condition)
{    
   strQuery = "SELECT RELEASE_NO, T1.ENGINE_NAME, GV, CASE EAR_VERSION_MAX WHEN '0' THEN 'GV_DEPLOYMENT' WHEN '1' THEN '' ELSE EAR_VERSION_MAX END EAR_VERSION_MAX, EMS_VERSION_MAX, SQL_VERSION_MAX, FILE_CHANGES_LIST from (select RELEASE_NO, ENGINE_NAME, " + maxVersion("EAR_VERSION") + ", "+ maxVersion("SQL_VERSION") + ", "+ maxVersion("EMS_VERSION") + ", rtrim (xmlagg (xmlelement (e, TRANSLATE(FILE_CHANGES,'\n'||'\t'||'\r','') || '')).extract ('//text()'), ',') FILE_CHANGES_LIST from CICD_RELEASE_SUMMARY where " + condition + " group by RELEASE_NO, ENGINE_NAME ) T1 FULL OUTER JOIN (SELECT ENGINE_NAME, 'GV' as GV  from CICD_RELEASE_SUMMARY WHERE " + condition + " group by RELEASE_NO, ENGINE_NAME having COUNT(ENGINE_NAME)=1 MINUS SELECT ENGINE_NAME, 'GV' as GV from CICD_RELEASE_SUMMARY WHERE " + condition + " and EAR_VERSION <> '0') T2 ON T1.ENGINE_NAME = T2.ENGINE_NAME";
   rowList = myMultipleSelectQuery(strQuery);
   return rowList;
}

def getReleaseSummaryGateway(condition)
{ 
   strQuery = "select GATEWAY_TYPE, " + maxVersion("GATEWAY_VERSION") + " from CICD_RELEASE_SUMMARY where " + condition + " group by GATEWAY_TYPE";
   rowList = myMultipleSelectQuery(strQuery);
   return rowList;
}


def getfunctinDeliveredISTIL(condition)
{
	strQuery = "select ENGINE_NAME, rtrim (xmlagg (xmlelement (e, ENGINE_TYPE || '@#@#@#')).extract ('//text()'), ',') ENGINE_TYPE, rtrim (xmlagg (xmlelement (e, OPERATION || '@#@#@#')).extract ('//text()'), ',') OPERATION_LIST, dbms_lob.substr(rtrim (xmlagg (xmlelement (e, CHANGE_DESCRIPTION || '@#@#@#')).extract( '//text()').getClobVal(),','), 4000, 1 ) CHANGE_DESCRIPTION_LIST from CICD_RELEASE_SUMMARY where " + condition + " group by RELEASE_NO, ENGINE_NAME"; 
    println(strQuery);
	rowList = myMultipleSelectQuery(strQuery);
	return rowList;
}


def getfunctinDeliveredGateway(condition)
{  
	strQuery = "select GATEWAY_TYPE, rtrim (xmlagg (xmlelement (e, OPERATION || '@#@#@#')).extract ('//text()'), ',') OPERATION_LIST, dbms_lob.substr(rtrim (xmlagg (xmlelement (e, CHANGE_DESCRIPTION || '@#@#@#')).extract( '//text()').getClobVal(),','), 4000, 1 ) CHANGE_DESCRIPTION_LIST from CICD_RELEASE_SUMMARY where " + condition + " group by RELEASE_NO, GATEWAY_TYPE"; 
	rowList = myMultipleSelectQuery(strQuery);
	return rowList;
}


def getEngineListDetailed(condition)
{ 
   strQuery = "select RELEASE_NO, COMPONENT_TYPE, ENGINE_NAME, " + maxVersion("EAR_VERSION") + ", "+ maxVersion("SQL_VERSION") + ", "+ maxVersion("EMS_VERSION") + ", dbms_lob.substr(rtrim (xmlagg (xmlelement (e, FILE_CHANGES || '\n')).extract( '//text()').getClobVal(),','), 4000, 1 ) FILE_CHANGES_LIST, dbms_lob.substr(rtrim (xmlagg (xmlelement (e, CHANGE_DESCRIPTION || '\n')).extract( '//text()').getClobVal(),','), 4000, 1 ) CHANGE_DESCRIPTION_LIST, rtrim (xmlagg (xmlelement (e, OPERATION || '\n')).extract ('//text()'), ',') OPERATION_LIST, dbms_lob.substr(rtrim (xmlagg (xmlelement (e, Master_GV || '\n')).extract( '//text()').getClobVal(),','), 4000, 1 ) MASTER_GV_LIST, dbms_lob.substr(rtrim (xmlagg (xmlelement (e, Process_GV || '\n')).extract( '//text()').getClobVal(),','), 4000, 1 ) PROCESS_GV_LIST, dbms_lob.substr(rtrim (xmlagg (xmlelement (e, ENGINE_TEMPLATE || '\n')).extract( '//text()').getClobVal(),','), 4000, 1 ) ENGINE_TEMPLATE_LIST, dbms_lob.substr(rtrim (xmlagg (xmlelement (e, APPEND_PREPEND || '\n')).extract( '//text()').getClobVal(),','), 4000, 1 ) APPEND_PREPEND_LIST, dbms_lob.substr(rtrim (xmlagg (xmlelement (e, KNOWN_ERROR_INCLUSION || '\n')).extract( '//text()').getClobVal(),','), 4000, 1 ) KNOWN_ERROR_INCLUSION_LIST, dbms_lob.substr(rtrim (xmlagg (xmlelement (e, POST_MANUAL_CHANGES || '\n')).extract( '//text()').getClobVal(),','), 4000, 1 ) POST_MANUAL_CHANGES_LIST, dbms_lob.substr(rtrim (xmlagg (xmlelement (e, SPECIAL_INSTRUCTIONS || '\n')).extract( '//text()').getClobVal(),','), 4000, 1 ) SPECIAL_INSTRUCTIONS_LIST, dbms_lob.substr(rtrim (xmlagg (xmlelement (e, RESTART_ENGINES || ';')).extract( '//text()').getClobVal(),';'), 4000, 1 ) RESTART_ENGINES_LIST from CICD_RELEASE_SUMMARY where " + condition + " group by RELEASE_NO, COMPONENT_TYPE, ENGINE_NAME";
   rowList = myMultipleSelectQuery(strQuery);
   return rowList;
}


def getGatewayListDetailed(condition)
{
   strQuery = "select GATEWAY_TYPE, " + maxVersion("GATEWAY_VERSION") + ", dbms_lob.substr(rtrim (xmlagg (xmlelement (e, PARTNER_DATA || '\n')).extract( '//text()').getClobVal(),','), 4000, 1 ) PARTNER_DATA, dbms_lob.substr(rtrim (xmlagg (xmlelement (e, GATEWAY_TOKEN || '\n')).extract( '//text()').getClobVal(),','), 4000, 1 ) GATEWAY_TOKEN, dbms_lob.substr(rtrim (xmlagg (xmlelement (e, SPECIAL_INSTRUCTIONS || '\n')).extract( '//text()').getClobVal(),','), 4000, 1 ) SPECIAL_INSTRUCTIONS  from CICD_RELEASE_SUMMARY where " + condition + " group by RELEASE_NO, GATEWAY_TYPE";\
   rowList = myMultipleSelectQuery(strQuery);
   return rowList;
}

def getConsolidatedList(condition,columnName)
{
   strQuery = "select dbms_lob.substr(rtrim (xmlagg (xmlelement (e, " + columnName + " || '@#@#@#')).extract( '//text()').getClobVal(),','), 4000, 1 ) " + columnName + "_LIST from CICD_RELEASE_SUMMARY where " + condition ;
   rowList = mySingleSelectQuery(strQuery);
   return rowList;
}


def getRestartList(condition)
{
   strQuery =   "WITH DATA1 AS \n" +
                "(select RESTART_ENGINES  str from CICD_RELEASE_SUMMARY where " + condition + " and RESTART_ENGINES IS NOT NULL), \n" +
                "DATA2 AS \n" +
                "(SELECT distinct regexp_substr(str, '[^;]+', 1, LEVEL) EngineWithPrefix \n" +
                "FROM DATA1 \n" +
                "CONNECT BY regexp_substr(str , '[^;]+', 1, LEVEL) IS NOT NULL), \n" +
                "DATA3 AS \n" +
                "(SELECT regexp_substr(EngineWithPrefix, '[^/]+', 1, 2) as RESTART_ENGINES_LIST from DATA2) \n" +
                "SELECT RESTART_ENGINES_LIST from DATA3 \n" +
                "MINUS \n" +
                "select ENGINE_NAME AS RESTART_ENGINES_LIST from CICD_RELEASE_SUMMARY where " + condition + " and ENGINE_NAME <> 'Common_SQL_Changes' " 
   rowList = myMultipleSelectQuery(strQuery);
   return rowList;
}

def removeFolderName(restartEngines)
{
    displayDebug('removeFolderName',restartEngines)
    def newRestartEngines = ""
    if(restartEngines.equals(null) || restartEngines=="")
              return "";
    engines = restartEngines.split(';');
    displayDebug('removeFolderName',engines)
    for(counter=0; counter< engines.size(); counter++)
    { 
        println(    )
        if(newRestartEngines!= "")
            newRestartEngines+= ";  "
        
        newRestartEngines += (engines[counter]).split('/')[1];
    }
    return newRestartEngines;
}

def getEngineList(relNum)
{
        def engineStr = ""
        println("====Release Number - " + relNum )
        strQuery = "select distinct ENGINE_NAME AS ENGINE_LIST from CICD_RELEASE_SUMMARY where RELEASE_NO = '" + relNum + "' and COMPONENT_TYPE = 'ISTIL' and status = 'Active' order by ENGINE_NAME";
        displayDebug("getEngineList", strQuery)
        rowList = myMultipleSelectQuery(strQuery);
        for(engCounter=0; engCounter < rowList.size(); engCounter++)
			{
					row = rowList[engCounter];
                    engine = (row['ENGINE_LIST'] !=null) ? row['ENGINE_LIST'] : "";
                    if(engCounter != 0 && engCounter != rowList.size())
                       engineStr += "\n"
                    engineStr+= engine 
            }
        return engineStr;
}

def getGatewayList(relNum)
{
        def gatewayStr = ""
        println("====Release Number - " + relNum )
        strQuery = "select distinct GATEWAY_TYPE AS GATEWAY_LIST from CICD_RELEASE_SUMMARY where RELEASE_NO = '" + relNum + "' and COMPONENT_TYPE = 'GATEWAY' and status = 'Active' order by GATEWAY_TYPE";
        displayDebug("getGatewayList", strQuery)
        rowList = myMultipleSelectQuery(strQuery);
        for(Counter=0; Counter < rowList.size(); Counter++)
			{
					row = rowList[Counter];
                    gateway = (row['GATEWAY_LIST'] !=null) ? row['GATEWAY_LIST'] : "";
                    if(Counter != 0 && Counter != rowList.size())
                       gatewayStr += "\n"
                    gatewayStr+= gateway 
            }
        return gatewayStr;
}

def covertCommaSepratedToSingleQuoted(LIST)
{
    def result = ""
    println(LIST)
    Array = LIST.split(',');                                      
                                       
    for(Counter=0; Counter < Array.size(); Counter++)
        {
                str = Array[Counter];
                if(Counter != 0)
                   result+= ", "
                result += "'" + str + "'"                
        }
    println(result)
    return result;
}

def updateEngineStatus(relNum,compType, engines,user)
{
		println("====Release Number - " + relNum + "====Component Type : " + compType + "====Engines : " + engines)
        //strQuery = "update CICD_RELEASE_SUMMARY SET Status = 'Descope' where RELEASE_NO = '" + relNum + "' and ENGINE_NAME = '" + //ENGINE_COMBINATION.split('~')[0] + "' and EAR_VERSION = '" + ENGINE_COMBINATION.split('~')[1] + "' and EMS_VERSION = '" + //ENGINE_COMBINATION.split('~')[2] + "' and SQL_VERSION = '" + ENGINE_COMBINATION.split('~')[3] + "'";
        strQuery = "update CICD_RELEASE_SUMMARY SET STATUS = 'Descope', MODIFIED_ON=sysdate, MODIFIED_BY='$user' where RELEASE_NO = '" + relNum + "' and ENGINE_NAME in (" + engines + ") and Status <> 'Descope'"
        displayDebug("updateEngineStatus", strQuery)
        response = myExecUpdateQuery(strQuery);
        return response
}



//===============================PDF Creation ==========================================================

def createPDF( WordprocessingMLPackage wordPackage, pdfFileName)
{
	FileOutputStream fileOutputStream = new FileOutputStream(pdfFileName);
	org.docx4j.Docx4J.toPDF(wordPackage, fileOutputStream);
	fileOutputStream.flush();
	fileOutputStream.close();
}

//==============================Tester================================================================

def addTableOfContent(MainDocumentPart documentPart) {
		ObjectFactory  factory = Context.getWmlObjectFactory();
        P paragraph = factory.createP();
 
        addFieldBegin(paragraph);
        addTableOfContentField(paragraph);
        addFieldEnd(paragraph);
 
        documentPart.getJaxbElement().getBody().getContent().add(paragraph);
    }


def addFieldBegin(P paragraph) {
		ObjectFactory  factory = Context.getWmlObjectFactory();
        R run = factory.createR();
        FldChar fldchar = factory.createFldChar();
        fldchar.setFldCharType(STFldCharType.BEGIN);
        fldchar.setDirty(true);
        run.getContent().add(getWrappedFldChar(fldchar));
        paragraph.getContent().add(run);
    }


def addTableOfContentField(P paragraph) {
		ObjectFactory  factory = Context.getWmlObjectFactory();
        R run = factory.createR();
        Text txt = new Text();
        txt.setSpace("preserve");
        txt.setValue("TOC \\o \"1-3\" \\h \\z \\u");
        run.getContent().add(factory.createRInstrText(txt));
        paragraph.getContent().add(run);
    }


def addFieldEnd(P paragraph) {
        ObjectFactory  factory = Context.getWmlObjectFactory();
        R run = factory.createR();
        FldChar fldcharend = factory.createFldChar();
        fldcharend.setFldCharType(STFldCharType.END);
        run.getContent().add(getWrappedFldChar(fldcharend));
        paragraph.getContent().add(run);
    }


def convertImageToByteArray(File file)
              throws FileNotFoundException, IOException {
          InputStream is = new FileInputStream(file);
         long length = file.length();
         // You cannot create an array using a long, it needs to be an int.
           if (length > Integer.MAX_VALUE) {
              System.out.println("File too large!!");
           }
         byte[] bytes = new byte[(int) length];
          int offset = 0;
          int numRead = 0;
          while (offset < bytes.length && (numRead = is.read(bytes, offset, bytes.length -  
                    offset)) >= 0) {
              offset += numRead;
          }
          // Ensure all the bytes have been read
          if (offset < bytes.length) {
              System.out.println("Could not completely read file "
                      + file.getName());
          }
          is.close();
           return bytes;
       }


def addImageToPackage(WordprocessingMLPackage wordMLPackage,
                            byte[] bytes) throws Exception {
        org.docx4j.openpackaging.parts.WordprocessingML.BinaryPartAbstractImage imagePart =
            org.docx4j.openpackaging.parts.WordprocessingML.BinaryPartAbstractImage.createImagePart(wordMLPackage, bytes);
 
        int docPrId = 1;
        int cNvPrId = 2;
            org.docx4j.dml.wordprocessingDrawing.Inline inline = imagePart.createImageInline("Filename hint",
                "Alternative text", docPrId, cNvPrId, false);
 
        P paragraph = addInlineImageToParagraph(inline);
 
        wordMLPackage.getMainDocumentPart().addObject(paragraph);
    }


def addInlineImageToParagraph(org.docx4j.dml.wordprocessingDrawing.Inline inline) {
        // Now add the in-line image to a paragraph
        ObjectFactory factory = new ObjectFactory();
        P paragraph = factory.createP();
        R run = factory.createR();
        paragraph.getContent().add(run);
        org.docx4j.wml.Drawing drawing = factory.createDrawing();
        run.getContent().add(drawing);
        drawing.getAnchorOrInline().add(inline);
        return paragraph;
    }

//===============================Document Creation=====================================================


def createDOCx(WordprocessingMLPackage wordPackage, DocxFileName)
{
    //org.docx4j.toc.TocGenerator tocGenerator = new org.docx4j.toc.TocGenerator(wordPackage);
	//tocGenerator.generateToc( 0, "TOC \\o \"1-3\" \\h \\z \\u \\h", false);
	//tocGenerator.updateToc( false); // true --> skip page numbering

	//File exportFile = new File(DocxFileName);
	//wordPackage.save(exportFile);
	Docx4J.save(wordPackage, new FileOutputStream(new File(DocxFileName)), Docx4J.FLAG_NONE);
	println("Saved Document");    
}


def makePageBr() {
		org.docx4j.wml.ObjectFactory factory = new org.docx4j.wml.ObjectFactory();
		P p = factory.createP();
		R r = factory.createR();
		Br br = factory.createBr();
		br.setType(org.docx4j.wml.STBrType.PAGE);
		r.getContent().add(br);
		p.getContent().add(r);
		return p;
}


def getWrappedFldChar(FldChar fldchar) {
		return new JAXBElement( new QName(Namespaces.NS_WORD12, "fldChar"), 
			FldChar.class, fldchar);
}

//===============================Document Content Creation ==============================================


def prepareDocContents(relNum,compType, condition, docxName, reportName, BUILD_DATE)
{
		println("====Release Number - " + relNum + "====Component Type : " + compType)
		WordprocessingMLPackage wordPackage = WordprocessingMLPackage.createPackage();
		MainDocumentPart mainDocumentPart = wordPackage.getMainDocumentPart();
		XHTMLImporterImpl importer = new XHTMLImporterImpl(wordPackage);
		
		List<Object> content ;
		
		mainDocumentPart.addStyledParagraphOfText("Title", "Release Document");
        mainDocumentPart.addStyledParagraphOfText("Subtitle", "" + relNum + "-" + compType);
        mainDocumentPart.addParagraphOfText("Generated by Jenkins");
        mainDocumentPart.addParagraphOfText("Generated on " + BUILD_DATE);
        mainDocumentPart.addParagraphOfText(reportName);
		
        try 
        {
            File file = new File("${WORKSPACE}@script/ReleaseNotes/vodafone-logo.png");
            byte[] bytes = convertImageToByteArray(file);
            addImageToPackage(wordPackage, bytes);
        }
        catch (error) {
            println("Error Accessing the vodafone logo - ${error}" )
            println(error.getStackTrace().toString())            
        }
        
        mainDocumentPart.addParagraphOfText(" ");
        mainDocumentPart.addParagraphOfText(" ");        
		mainDocumentPart.addParagraphOfText("Release Prepared By");
        mainDocumentPart.addParagraphOfText("${currentBuild.getRawBuild().getCauses()[0].getUserId()}");
		
		mainDocumentPart.addObject(makePageBr());
		mainDocumentPart.addStyledParagraphOfText("Title", "TABLE OF CONTENTS");
		addTableOfContent(mainDocumentPart);
		
        displayDebug("Heading 1","")
		mainDocumentPart.addObject(makePageBr());
		
		mainDocumentPart.addStyledParagraphOfText("Heading1", "1. Release Notes");
		//Release notes table
		//content.clear();
		tableContent = "";
		tableContent = get_table_release_document()
		content = importer.convert(new java.lang.String(tableContent),null);
		wordPackage.getMainDocumentPart().getContent().addAll(content);
				
		displayDebug("Heading 2","")
		if(compType == "ISTIL")
		{
		    
			releaseListISTIL = getReleaseSummaryISTIL(condition);
			
			mainDocumentPart.addStyledParagraphOfText("Heading1", "2. Release Summary");
			//Release summary table
			content.clear();
			tableContent = "";
			tableContent = get_table_release_summary_ISTIL(releaseListISTIL)
			content = importer.convert(tableContent,null);
			wordPackage.getMainDocumentPart().getContent().addAll(content);
			
		}
		else if(compType == "GATEWAY")
		{
			releaseListGateway = getReleaseSummaryGateway(condition);
			
			mainDocumentPart.addStyledParagraphOfText("Heading1", "2. Release Summary");
			//Release summary table
			content.clear();
			tableContent = "";
			tableContent = get_table_release_summary_Gateway(releaseListGateway)
			content = importer.convert(tableContent,null);
			wordPackage.getMainDocumentPart().getContent().addAll(content);
		}
		
        displayDebug("Heading 3","")
		mainDocumentPart.addObject(makePageBr());
		
		if(compType == "ISTIL")
		{
			functionListISTIL = getfunctinDeliveredISTIL(condition);
			
			mainDocumentPart.addStyledParagraphOfText("Heading1", "3. FUNCTIONALITY DELIVERED IN RELEASE");
			//Release functionality delivered table
			content.clear();
			tableContent = "";
			tableContent = get_table_functionality_delivered_ISTIL(functionListISTIL)
            println(tableContent);
			content = importer.convert(tableContent,null);
			wordPackage.getMainDocumentPart().getContent().addAll(content);
		}
		else if(compType == "GATEWAY")
		{
			functionListGateway = getfunctinDeliveredGateway(condition);
			
			mainDocumentPart.addStyledParagraphOfText("Heading1", "3. FUNCTIONALITY DELIVERED IN RELEASE");
			//Release functionality delivered table
			content.clear();
			tableContent = "";
			tableContent = get_table_functionality_delivered_gateway(functionListGateway)
			content = importer.convert(tableContent,null);
			wordPackage.getMainDocumentPart().getContent().addAll(content);
		}
        
        displayDebug("Heading 4","")
		mainDocumentPart.addObject(makePageBr());
		mainDocumentPart.addStyledParagraphOfText("Heading1", "4. CHANGE REQUESTS OR DEFECTS DELIVERED");
		
		if(compType == "ISTIL")
		{
		     displayDebug("Heading 4","Before Getting Engine List")
			engList = getEngineListDetailed(condition);
            displayDebug("Heading 4","After Getting Engine List")
			if(engList.size() < 1)
            {
               println("*******Number of Engines is zero **********");
               return false;
            }
            
            engNumber = 1;
            for(engCounter=0; engCounter < engList.size(); engCounter++)
			{
					row = engList[engCounter];
                    displayDebug("ISTIL Engine List","Engine $engCounter")
                    println("DEBUG:******************Engine $engCounter*******")
					
					releaseID = (row['RELEASE_SUMMARY_ID'] != null) ? row['RELEASE_SUMMARY_ID'] : "";
					releaseNumber = (row['RELEASE_NO'] != null) ? row['RELEASE_NO'] : "";
					componentType = (row['COMPONENT_TYPE'] !=null) ? row['COMPONENT_TYPE'] : "";
					earVersion =  ((row['EAR_VERSION_MAX']!= '') ? row['EAR_VERSION_MAX'] : "NA")
					sqlVersion =  ((row['SQL_VERSION_MAX']!= '') ? row['SQL_VERSION_MAX'] : "NA")
					emsVersion =  ((row['EMS_VERSION_MAX']!= '') ? row['EMS_VERSION_MAX'] : "NA")                    
					engineName = (row['ENGINE_NAME'] != null) ? row['ENGINE_NAME'].toString() : "";				
					fileChanges = (row['FILE_CHANGES_LIST'] != null) ? row['FILE_CHANGES_LIST'].toString() : "";
					changeDescription = (row['CHANGE_DESCRIPTION_LIST'] != null) ? row['CHANGE_DESCRIPTION_LIST'].toString() : "";
					//operation = (row['OPERATION_LIST'] != null) ? row['OPERATION_LIST'].toString() : "";
                    consolidate_operation = remove_duplicates(row['OPERATION_LIST'].replaceAll("\n", ",")) 
                    operation = changeBullets(consolidate_operation,",");
					masterGV = (row['MASTER_GV_LIST'] != null) ? row['MASTER_GV_LIST'].toString() : "";
					processGV = (row['PROCESS_GV_LIST'] != null) ? row['PROCESS_GV_LIST'].toString() : "";
					engineTemplate = (row['ENGINE_TEMPLATE_LIST'] != null) ? row['ENGINE_TEMPLATE_LIST'].toString() : "";
					appendPrepand = (row['APPEND_PREPEND_LIST'] != null) ? row['APPEND_PREPEND_LIST'].toString() : ""
					knownError = (row['KNOWN_ERROR_INCLUSION_LIST'] != null) ? row['KNOWN_ERROR_INCLUSION_LIST'].toString() : "";
					postManualChanges = (row['POST_MANUAL_CHANGES_LIST'] != null) ? row['POST_MANUAL_CHANGES_LIST'].toString() : "";
					splInstructions = (row['SPECIAL_INSTRUCTIONS_LIST'] != null) ? row['SPECIAL_INSTRUCTIONS_LIST'].toString() : "";
                    restartEngines = (row['RESTART_ENGINES_LIST'] != null) ? row['RESTART_ENGINES_LIST'].toString() : "";
                    restartEngines = remove_duplicates(removeFolderName(restartEngines).replaceAll(";", ","))                    
					if(fileChanges!=null && fileChanges.toString().trim()!="")
					   fileChanges = getFileSummary(fileChanges)
					else
					   fileChanges = "No File Changes"
					
					mainDocumentPart.addStyledParagraphOfText("Heading2", "4.$engNumber Engine $engNumber : $engineName");
					//Engine 1 notes table
					content.clear();
					tableContent = "";
					
					tableContent = get_table_engine(releaseNumber, componentType, earVersion, sqlVersion, emsVersion, engineName, fileChanges, changeDescription, operation, masterGV, processGV, engineTemplate, appendPrepand, knownError, postManualChanges, splInstructions, restartEngines);
					content = importer.convert(tableContent,null);
					wordPackage.getMainDocumentPart().getContent().addAll(content);
					//mainDocumentPart.addObject(makePageBr());
					mainDocumentPart.addParagraphOfText("");
					engNumber += 1;
			}
		
		}
		
		else if(compType == "GATEWAY")
		{
		
			gatewayList = getGatewayListDetailed(condition);
            if(gatewayList.size() < 1)
            {
               println("*******Number of Gateway is zero **********");
               return false;
            }
            
			gateNumber = 1;
			for(gateCounter=0; gateCounter < gatewayList.size(); gateCounter++)
			{
					row = gatewayList[gateCounter];
                    println("DEBUG:******************Engine $gateNumber*******")
					
					gatewayType = (row['GATEWAY_TYPE'] !=null) ? row['GATEWAY_TYPE'] : "";
					gatewayVersion = (row['GATEWAY_VERSION_MAX'] !='') ? row['GATEWAY_VERSION_MAX'] : "NA";
                    partnerData = (row['PARTNER_DATA'] !=null) ? row['PARTNER_DATA'].toString() : "";
					gatewayToken = (row['GATEWAY_TOKEN'] !=null) ? row['GATEWAY_TOKEN'].toString() : "";
					splInstructions = (row['SPECIAL_INSTRUCTIONS'] !=null) ? row['SPECIAL_INSTRUCTIONS'].toString() : "";
					
					mainDocumentPart.addStyledParagraphOfText("Heading2", "4.$gateNumber Gateway $gateNumber : $gatewayType");
					//Gateway notes table
					content.clear();
					tableContent = "";
					
					tableContent = get_table_gateway(gatewayType, gatewayVersion, partnerData, gatewayToken, splInstructions);
					content = importer.convert(tableContent,null);
					wordPackage.getMainDocumentPart().getContent().addAll(content);
					
					//mainDocumentPart.addObject(makePageBr());
					mainDocumentPart.addParagraphOfText("");
					gateNumber += 1;
			}
		}
		
        delimeter = "@#@#@#";
		if(compType == "ISTIL")
		{
		    
			println("DEBUG:******************KNOWN_ERROR_INCLUSION_LIST - ISTIL*******")
            mainDocumentPart.addStyledParagraphOfText("Heading1", "5. KNOWN ERRORS EXCLUSION");
			listResult=getConsolidatedList(condition,"KNOWN_ERROR_INCLUSION")
            listValue = (listResult["KNOWN_ERROR_INCLUSION_LIST"] != null ) ? changeBullets(listResult["KNOWN_ERROR_INCLUSION_LIST"].toString(), delimeter) : "--NA--"
           
            content.clear();
            content = importer.convert(listValue,null);
			wordPackage.getMainDocumentPart().getContent().addAll(content);
			
            println("DEBUG:******************ENV MASTER GV CONF - ISTIL*******")
			mainDocumentPart.addStyledParagraphOfText("Heading1", "6. ENV MASTER GV CONF");
			listResult=getConsolidatedList(condition,"MASTER_GV")
            
			listValue = (listResult["MASTER_GV_LIST"] != null) ? changeBullets(listResult["MASTER_GV_LIST"].toString(), delimeter) : "--NA--"
			
            content.clear();
            content = importer.convert(listValue,null);
			wordPackage.getMainDocumentPart().getContent().addAll(content);
			
            println("DEBUG:******************PROCESS MASTER GV CONF - ISTIL*******")
			mainDocumentPart.addStyledParagraphOfText("Heading1", "7. PROCESS MASTER GV CONF");
			listResult=getConsolidatedList(condition,"PROCESS_GV")
			listValue = (listResult["PROCESS_GV_LIST"] != null) ? changeBullets(listResult["PROCESS_GV_LIST"].toString(), delimeter) : "--NA--"
			
            content.clear();
            content = importer.convert(listValue,null);
			wordPackage.getMainDocumentPart().getContent().addAll(content);
			
            println("DEBUG:******************APPEND PREPEND CLASSPATH CONF - ISTIL*******")
			mainDocumentPart.addStyledParagraphOfText("Heading1", "8. APPEND PREPEND CLASSPATH CONF");
			listResult=getConsolidatedList(condition,"APPEND_PREPEND")
			listValue = (listResult["APPEND_PREPEND_LIST"] != null) ? changeBullets(listResult["APPEND_PREPEND_LIST"].toString(), delimeter) : "--NA--"
			
            content.clear();
            content = importer.convert(listValue,null);
			wordPackage.getMainDocumentPart().getContent().addAll(content);
            
            println("DEBUG:******************Manual Changes - ISTIL*******")
			mainDocumentPart.addStyledParagraphOfText("Heading1", "9. Manual Changes");
			listResult=getConsolidatedList(condition,"POST_MANUAL_CHANGES")
			listValue = (listResult["POST_MANUAL_CHANGES_LIST"] != null) ? changeBullets(listResult["POST_MANUAL_CHANGES_LIST"].toString(), delimeter) : "--NA--"
			
            content.clear();
            content = importer.convert(listValue,null);
			wordPackage.getMainDocumentPart().getContent().addAll(content);
            
            println("DEBUG:******************ENGINE TEMPLATE - ISTIL*******")
			mainDocumentPart.addStyledParagraphOfText("Heading1", "10. ENGINE TEMPLATE");
			listResult=getConsolidatedList(condition,"ENGINE_TEMPLATE")
			listValue = (listResult["ENGINE_TEMPLATE_LIST"] != null) ? changeBullets(listResult["ENGINE_TEMPLATE_LIST"].toString(), delimeter) : "--NA--"
			
            content.clear();
            content = importer.convert(listValue,null);
			wordPackage.getMainDocumentPart().getContent().addAll(content);
            
            println("DEBUG:******************Common SQL Changes - ISTIL*******")
			mainDocumentPart.addStyledParagraphOfText("Heading1", "11. ENGINE RESTART");
			listResult=getRestartList(condition)
            println(listResult["RESTART_ENGINES_LIST"].toString())
            println(listResult["RESTART_ENGINES_LIST"].join(delimeter))
			listValue = (listResult["RESTART_ENGINES_LIST"] != null) ? changeBullets(listResult["RESTART_ENGINES_LIST"].join(delimeter), delimeter) : "--NA--"
			
            content.clear();
            content = importer.convert(listValue,null);
			wordPackage.getMainDocumentPart().getContent().addAll(content);
            
		}		
		
		else if(compType == "GATEWAY")
		{
		
            println("DEBUG:******************Partner Data - Gateway*******")
            mainDocumentPart.addStyledParagraphOfText("Heading1", "5. Partner Data");
            listResult=getConsolidatedList(condition,"PARTNER_DATA")
            listValue = (listResult["PARTNER_DATA_LIST"] != null) ? changeBullets(listResult["PARTNER_DATA_LIST"].toString(), delimeter) : "--NA--"
		
            content.clear();
            content = importer.convert(listValue,null);
			wordPackage.getMainDocumentPart().getContent().addAll(content);
		
            println("DEBUG:******************Tokens - Gateway*******")
            mainDocumentPart.addStyledParagraphOfText("Heading1", "6. Tokens");
            listResult=getConsolidatedList(condition,"GATEWAY_TOKEN")
            listValue = (listResult["GATEWAY_TOKEN_LIST"] != null) ? changeBullets(listResult["GATEWAY_TOKEN_LIST"].toString(), delimeter) : "--NA--"
		
            content.clear();
            content = importer.convert(listValue,null);
			wordPackage.getMainDocumentPart().getContent().addAll(content);
		}
		
	//return wordPackage;
	println("Content Ready");
	createDOCx(wordPackage,docxName);
    println("File name saved --> ${docxName}")
    return true;
}

//===============================HTML Creation ========================================================


def get_table_css() {
    def css = """
				<style type="text/css">
					.tg  {border-collapse:collapse;border-spacing:0;}
					.tg td{border-color:black;border-style:solid;border-width:1px;font-family:Arial, sans-serif;font-size:14px;
					  overflow:hidden;padding:8px 14px;word-break:normal;}
					.tg th{border-color:black;border-style:solid;border-width:1px;font-family:Arial, sans-serif;font-size:14px;
					  font-weight:normal;overflow:hidden;padding:8px 14px;word-break:normal;}
					.tg .tg-headleft{border-color:inherit;font-size:14px;font-weight:bold;text-align:left;vertical-align:top}					.tg-headcenter{border-color:inherit;font-size:14px;font-weight:bold;text-align:center;vertical-align:top}
					.tg .tg-cellvalue{border-color:inherit;text-align:left;vertical-align:top}
					.tg 
				</style>
	"""
	return css
}


def get_table_release_document(){
     def tableContent = """
				<table class="tg">
						<thead>
						  <tr>
							<th class="tg-headleft">Release Version Number</th>
							<th class="tg-cellvalue">${env.RELEASE_DOC_VERSION}</th>
						  </tr>
						</thead>
						<tbody>
						  <tr>
							<td class="tg-headleft">Release Prepared By</td>
							<td class="tg-cellvalue">${currentBuild.getRawBuild().getCauses()[0].getUserId()}</td>
						  </tr>
						  <tr>
							<td class="tg-headleft">Contact for Release</td>
							<td class="tg-cellvalue">${env.RELEASE_CONTACT}</td>
						  </tr>
						  <tr>
							<td class="tg-headleft">Reason for Release</td>
							<td class="tg-cellvalue">${env.RELEASE_REASON}</td>
						  </tr>
						  <tr>
							<td class="tg-headleft">Production Go-Live</td>
							<td class="tg-cellvalue">${env.RELEASE_DATE}</td>
						  </tr>
						</tbody>
				</table>
	 """
	 tableContent = "<html><head><title>Release Note</title> " + get_table_css() + "</head><body>" + tableContent + "</body></html>"
	 return tableContent
}


def get_table_release_summary_ISTIL(releaseList){
     def tableContent = """
				<table class="tg">
				<thead>
				  <tr>
					<th class="tg-headcenter">S.No</th>
					<th class="tg-headcenter">ENGINE NAME</th>                    
					<th class="tg-headcenter">BW VERSION</th>
					<th class="tg-headcenter">EMS VERSION</th>
					<th class="tg-headcenter">SQL VERSION</th>
					<th class="tg-headcenter">FILE CHANGES</th>
				  </tr>
				</thead>
				<tbody>
			""";
				
                sno=1;
				
				for(def rlCounter=0; rlCounter < releaseList.size(); rlCounter++)
			    {
					row = releaseList[rlCounter];

						eName = (row['ENGINE_NAME'] != null) ? row['ENGINE_NAME'] : "";
                        gv = (row['GV'] != null && row['GV'] != "") ? (" - (" + row['GV'] + ")") : "";
						earVersion =  ((row['EAR_VERSION_MAX']!= '') ? row['EAR_VERSION_MAX'] : "NA")
						sqlVersion =  ((row['SQL_VERSION_MAX']!= '') ? row['SQL_VERSION_MAX'] : "NA")
						emsVersion =  ((row['EMS_VERSION_MAX']!= '') ? row['EMS_VERSION_MAX'] : "NA")
						files = getFileSummary(row['FILE_CHANGES_LIST']);
						
						tableContent += """
						  <tr>
							<td class="tg-cellvalue">$sno</td>
							<td class="tg-cellvalue">$eName $gv</td>                            
							<td class="tg-cellvalue">$earVersion</td>
							<td class="tg-cellvalue">$emsVersion</td>
							<td class="tg-cellvalue">$sqlVersion</td>
							<td class="tg-cellvalue">$files</td>
						  </tr>
						  """;
					 sno += 1;
				}
				
				tableContent += """</tbody></table>"""
	 tableContent = "<html><head><title>Release Note</title> " + get_table_css() + "</head><body>" + tableContent + "</body></html>"
	 return tableContent
}


def get_table_release_summary_Gateway(releaseList){
     def tableContent = """
				<table class="tg">
				<thead>
				  <tr>
				    <th class="tg-headcenter">S.No</th>
					<th class="tg-headcenter">Gateway Type</th>
					<th class="tg-headcenter">Gateway Version</th>
				  </tr>
				</thead>
				<tbody>
			""";
				
                sno=1;
				for(def rlCounter=0; rlCounter < releaseList.size(); rlCounter++)
			    {
					row = releaseList[rlCounter];

						gateType = (row['GATEWAY_TYPE'] != null) ? row['GATEWAY_TYPE'] : "" ;
						gateVersion = ((row['GATEWAY_VERSION_MAX']!='') ? row['GATEWAY_VERSION_MAX'] : "NA")                        
						
						tableContent += """
						  <tr>
						    <td class="tg-cellvalue">$sno</td>
							<td class="tg-cellvalue">$gateType</td>
							<td class="tg-cellvalue">$gateVersion</td>							
						  </tr>
						  """;
					 sno += 1;
				}
				
				tableContent += """</tbody></table>"""
	 tableContent = "<html><head><title>Release Note</title> " + get_table_css() + "</head><body>" + tableContent + "</body></html>"
	 return tableContent
}


def get_table_functionality_delivered_ISTIL(functionList){
     def tableContent = """
				<table class="tg" style="table-layout: fixed; width: 65%">
							<thead>
							  <tr>
								<th class="tg-headcenter">ENGINE</th>
								<th class="tg-headcenter">Operation</th>
								<th class="tg-headcenter">Change Description</th>
                                <th class="tg-headcenter">Engine Type</th>
							  </tr>
							</thead>
							<tbody>
							
						""";
			
			for( def funCounter=0; funCounter < functionList.size(); funCounter++)
			    {
					row = functionList[funCounter];

						eName = row['ENGINE_NAME'];
						consolidate_operation = remove_duplicates(row['OPERATION_LIST'].replaceAll("@#@#@#", ",")) 
                        operation = changeBullets(consolidate_operation,",");
						description = changeBullets(row['CHANGE_DESCRIPTION_LIST'],"@#@#@#");
                        enginetype = remove_duplicates(row['ENGINE_TYPE'].replaceAll("@#@#@#", ",")) 
                        enginetype = (enginetype.indexOf("UPDATED") != -1) ? "UPDATED" : "NEW";
						
						tableContent += """
							  <tr>
								<td class="tg-cellvalue">$eName</td>
								<td class="tg-cellvalue">$operation</td>
								<td class="tg-cellvalue">$description</td>
                                <td class="tg-cellvalue">$enginetype</td>
							  </tr>
							  """;
				}
				
				tableContent += """</tbody></table>"""
	 tableContent = "<html><head><title>Release Note</title> " + get_table_css() + "</head><body>" + tableContent + "</body></html>"
	 return tableContent
}


def get_table_functionality_delivered_gateway(functionList){
     def tableContent = """
				<table class="tg" style="table-layout: fixed; width: 65%">
							<thead>
							  <tr>
								<th class="tg-headcenter">Gateway Type</th>
								<th class="tg-headcenter">Operation</th>
								<th class="tg-headcenter">Change_Description</th>
							  </tr>
							</thead>
							<tbody>
							
						""";
						
						
			for(def funCounter=0; funCounter < functionList.size(); funCounter++)
			    {
					row = functionList[funCounter];

						gType = row['GATEWAY_TYPE'];
						consolidate_operation = remove_duplicates(row['OPERATION_LIST'].replaceAll("@#@#@#", ",")) 
                        operation = changeBullets(consolidate_operation,",");
						description = changeBullets(row['CHANGE_DESCRIPTION_LIST'],"@#@#@#");

						
						tableContent += """
							  <tr>
								<td class="tg-cellvalue">$gType</td>
								<td class="tg-cellvalue">$operation</td>
								<td class="tg-cellvalue">$description</td>
							  </tr>
							  """;
				}
				
				tableContent += """</tbody></table>"""
	 tableContent = "<html><head><title>Release Note</title> " + get_table_css() + "</head><body>" + tableContent + "</body></html>"
	 return tableContent
}


def get_table_gateway(gatewayType, gatewayVersion, partnerData, gatewayToken, splInstructions)
{
    def tableContent = """
				<table class="tg" style="table-layout: fixed; width: 70%">
							<tbody>
							  <tr>
								<td class="tg-headleft" colspan="1">Gateway <br></br>Type</td>
								<td class="tg-cellvalue" colspan="2">$gatewayType</td>
								<td class="tg-headleft" colspan="1">Gateway<br></br>Version</td>
								<td class="tg-cellvalue" colspan="2">$gatewayVersion</td>
							  </tr>							 
							  <tr>
								<td class="tg-headleft" colspan="1">Partner <br></br>Data</td>
								<td class="tg-cellvalue" colspan="5">$partnerData</td>
							  </tr>
							  <tr>
								<td class="tg-headleft" colspan="1">Tokens</td>
								<td class="tg-cellvalue" colspan="5">$gatewayToken</td>
							  </tr>
							  <tr>
								<td class="tg-headleft" colspan="1">Special<br></br>Instructions</td>
								<td class="tg-cellvalue" colspan="5">$splInstructions</td>
							  </tr>
							  </tbody>
				</table>
				<BR></BR>
	 """
	 tableContent = "<html><head><title>Release Note</title> " + get_table_css() + "</head><body>" + tableContent + "</body></html>"
	 return tableContent
}


def get_table_engine(releaseNumber, componentType, earVersion, sqlVersion, emsVersion, engineName, fileChanges, changeDescription, operation, masterGV, processGV, engineTemplate, appendPrepand, knownError, postManualChanges, splInstructions, restartEngines){
     def tableContent = """
				<table class="tg" style="table-layout: fixed; width: 70%">
							<tbody>
							  <tr>
								<td class="tg-headleft" colspan="1">BW<br></br>Version</td>
								<td class="tg-cellvalue" colspan="2">$earVersion</td>
								<td class="tg-headleft" colspan="1">SQL<br></br>VERSION</td>
								<td class="tg-cellvalue" colspan="2">$sqlVersion</td>
							  </tr>
							  <tr>
								<td class="tg-headleft" colspan="1">EMS<br></br>Version</td>
								<td class="tg-cellvalue" colspan="2">$emsVersion</td>
								<td class="tg-headleft" colspan="1">Component<br></br>Type</td>
								<td class="tg-cellvalue" colspan="2">$componentType</td>
							  </tr>
							  <tr>
								<td class="tg-headleft" colspan="1">Operation<br></br>Name</td>
								<td class="tg-cellvalue" colspan="2">$operation</td>
								<td class="tg-headleft" colspan="1">Change Description</td>
								<td class="tg-cellvalue" colspan="2">$changeDescription</td>
							  </tr>
							  <tr>
								<td class="tg-headleft" colspan="1">File<br></br>Changes</td>
								<td class="tg-cellvalue" colspan="5">$fileChanges</td>
							  </tr>
							  <tr>
								<td class="tg-headleft" colspan="1">Env Master<br></br>GV Conf</td>
								<td class="tg-cellvalue" colspan="5">$masterGV</td>
							  </tr>
							  <tr>
								<td class="tg-headleft" colspan="1">Process Master<br></br>GV Conf</td>
								<td class="tg-cellvalue" colspan="5">$processGV</td>
							  </tr>
							  <tr>
								<td class="tg-headleft" colspan="1">Engine<br></br>Template</td>
								<td class="tg-cellvalue" colspan="5">$engineTemplate</td>
							  </tr>
							  <tr>
								<td class="tg-headleft" colspan="1">Append<br></br>Prepend<br></br>Path</td>
								<td class="tg-cellvalue" colspan="5">$appendPrepand</td>
							  </tr>
							  <tr>
								<td class="tg-headleft" colspan="1">Known<br></br>Errors</td>
								<td class="tg-cellvalue" colspan="5">$knownError</td>
							  </tr>
							  <tr>
								<td class="tg-headleft" colspan="1">Post<br></br>Manual<br></br>Changes</td>
								<td class="tg-cellvalue" colspan="5">$postManualChanges</td>
							  </tr>
							  <tr> 
								<td class="tg-headleft" colspan="1">Special Instructions</td>
								<td class="tg-cellvalue" colspan="5">$splInstructions</td>
							  </tr>
                               <tr> 
								<td class="tg-headleft" colspan="1">Restart Engines</td>
								<td class="tg-cellvalue" colspan="5">$restartEngines</td>
							  </tr>
							</tbody>
				</table>
				<BR></BR>
	 """
	 tableContent = "<html><head><title>Release Note</title> " + get_table_css() + "</head><body>" + tableContent + "</body></html>"
	 return tableContent
}

def preparation_function(){
    // Initialize parameters to pipeline job.
		properties([parameters([
                            string(defaultValue: 'CCS20.1', description: '	*Mandatory. ex. CSS20.10', name: 'RELEASE_NO', trim: true), 
                            choice(choices: ['ISTIL','GATEWAY'], description: '*Mandatory.', name: 'COMPONENT_TYPE'), 
                            booleanParam(defaultValue: false, description: 'Check if you want to descope any engines. Valid only for COMPONENT_TYPE is ISTIL', name: 'DESCOPE_ENGINE'),
                            booleanParam(defaultValue: true, description: 'Uncheck if you want to create separate documents for each gateway. Valid only for COMPONENT_TYPE is Gateway', name: 'CONSOLIDATE_DOCUMENT'),
                            string(defaultValue: 'v1.0', description: '', name: 'RELEASE_DOC_VERSION', trim: true), 
                            string(defaultValue: '@vodafone.com', description: '*Mandatory. Please enter valid vodafone email id like xxx_xxx@vodafone.com', name: 'BUILD_REQUESTER', trim: true), 
                            string(defaultValue: '', description: '', name: 'RELEASE_CONTACT', trim: true), 
                            string(defaultValue: '', description: '', name: 'RELEASE_DATE', trim: true), 
                            string(defaultValue: '', description: '', name: 'RELEASE_REASON', trim: true)])])
}


def getMultipleChoiceInput(Heading, Choice_Type, Options, Description, Size)
{
    def multiChoiceInput = new ExtendedChoiceParameterDefinition("${Heading}", "PT_CHECKBOX", "${Options}", "${Choice_Type}", 
                                                "", "", "", "", "", "", "", "", "", "", "", "", "",  
                                                "${Options}", 
                                                "", "", "", "", "", "", "", "",
                                                false,false, 
                                                Size, 
                                                "${Description}", 
                                                ",")
    return multiChoiceInput;
}

def createDocument(RELEASE_NO,COMPONENT_TYPE, condition, docxFILE, reportName, BUILD_DATE)
{
    def response;
    try
    {
        response = "${prepareDocContents(RELEASE_NO,COMPONENT_TYPE, condition, docxFILE, reportName,  BUILD_DATE)}"
        if(response==false)
        { 
           println("No Release/No Engine/ No Gateway records found. So document not prepared");
        }
    }
    catch (error) {
        println("Build failed for some specific reason! - ${error}" )
        println(error.getStackTrace().toString())
        errorDescription=error;
        currentBuild.result = 'FAILURE'
    }
    return response
}



//===============================Main Pipeline ==========================================================

def docxFILE = "";
def response = ""
def dev_mailRecipients = "${params.BUILD_REQUESTER}";
def docResponse=""
def errorDescription=""
def selected_eng_gat=""
def BUILD_DATE = ""
def condition =""

pipeline {
    agent any
    stages {
    
        stage('Preparation') {
			steps {
				script{
					deleteDir()
					preparation_function()
                    BUILD_DATE = sh (script: "echo \$(date +%F-%H:%M)", returnStdout: true).trim()
                    //pwd = sh (script: "pwd", returnStdout: true).trim()
                    //sh "rm -Rf ${pwd}/*"
                    try {
								if(env.DESCOPE_ENGINE == "true" && env.COMPONENT_TYPE =="ISTIL")
                                {
                                        engineList = "${getEngineList(RELEASE_NO)}"
                                        displayDebug('Preparation-Engine List',engineList)
                                        engines_Array = engineList.split('\n');
                                        engines_params = ""
                                       
                                        for(engCounter=0; engCounter < engines_Array.size(); engCounter++)
                                            {
                                                    engine = engines_Array[engCounter];
                                                    engines_params +=engine
                                                    if(engCounter != rowList.size()-1)
                                                                engines_params += ","
                                            }
                                        displayDebug('Preparation-Engine Params',engines_params)
                                        Integer noofengine =  engines_Array.size() + 1
                                       
                                       def multiSelectEngine = getMultipleChoiceInput('List of Engines', 'Engine Names', engines_params, 'Please Select the engines to Descope (To skip, select none)', noofengine)  
                                    
                                        def selected_engines = input  id: 'customID', message: 'Select Engine to Descope', ok: 'Descope', parameters: [multiSelectEngine]  
                                        displayDebug('Preparation-Engines Selected', selected_engines)
                                        
                                        engines = covertCommaSepratedToSingleQuoted(selected_engines)
                                        
                                        def user = currentBuild.getRawBuild().getCauses()[0].getUserId()
                                        println("DEBUG: User -->" + user)
                
                                        descoped = "${updateEngineStatus(RELEASE_NO,COMPONENT_TYPE,engines,user)}"
                                        displayDebug('Preparation-Engines Descoped', descoped)
                                }
                                else
                                {
                                        displayDebug('Preparation-Engines Descoped', 'DESCOPE_ENGINE is not checked OR COMPONENT_TYPE is Gateway ')
                                }
                        }
						catch (error) {
						    println("Error caught in Exception while descoping engines")
                            println("Build failed for some specific reason! - ${error}" )
                            println(error.getStackTrace().toString())
                            errorDescription=error;
                            currentBuild.result = 'FAILURE'
						}
                        
                        try {
								if(env.CONSOLIDATE_DOCUMENT != "true")
                                //if(env.CONSOLIDATE_DOCUMENT == "false" && env.COMPONENT_TYPE =="GATEWAY")
                                {
                                        if(env.COMPONENT_TYPE =="ISTIL") 
                                        {
                                            egList = "${getEngineList(RELEASE_NO)}"
                                        }
                                        else
                                        {
                                            egList = "${getGatewayList(RELEASE_NO)}"
                                        }
                                        displayDebug('Preparation-Consolidate-List',egList)
                                        eg_Array = egList.split('\n');
                                        eg_params = ""
                                       
                                        for(egCounter=0; egCounter < eg_Array.size(); egCounter++)
                                            {
                                                    eg = eg_Array[egCounter];
                                                    eg_params += eg
                                                    if(egCounter != rowList.size()-1)
                                                                eg_params += ","
                                            }
                                        displayDebug('Preparation-Consolidate-Params',eg_params)
                                        Integer listSize =  eg_Array.size() + 1
                                       
                                       def multiSelect;
                                       
                                       if(env.COMPONENT_TYPE =="ISTIL")
                                       {
                                                multiSelect= getMultipleChoiceInput('List of Engines', 'Engine Names', eg_params, 'Please Select the engines', listSize)  
                                                selected_eng_gat = input  id: 'customID', message: 'Select the list of required Engines', ok: 'Select', parameters: [multiSelect]  
                                                displayDebug('Preparation-Consolidate-Selected', selected_eng_gat)
                                       }
                                       else
                                       {
                                                multiSelect= getMultipleChoiceInput('List of Gateways', 'Gateway Names', eg_params, 'Please Select the gateways', listSize)
                                                selected_eng_gat = input  id: 'customID', message: 'Select the list of required Gateway', ok: 'Select', parameters: [multiSelect]  
                                                displayDebug('Preparation-Consolidate-Selected', selected_eng_gat)
                                       }
  
                                }
                                else
                                {
                                        //displayDebug('Preparation-Consolidate', 'CONSOLIDATE_DOCUMENT is selected ')
                                        displayDebug('Preparation-Consolidate', 'Else block of  CONSOLIDATE_DOCUMENT block')
                                }
                        }
						catch (error) {
						    println("Error caught in Exception in consolidating report")
                            println("Build failed for some specific reason! - ${error}" )
                            println(error.getStackTrace().toString())
                            errorDescription=error;
                            currentBuild.result = 'FAILURE'
						}
                }				
			}			
		}//stage Preparation
                                
        
        stage('CreateReleaseNotes') {
               steps{
                       script{
                       reportList = []
                       reportMap = [:]
                       pwd = sh (script: "pwd", returnStdout: true).trim()
                       sh "rm -Rf ${pwd}/*"
                       
                       if(env.CONSOLIDATE_DOCUMENT == "true")
                       //if(!(env.CONSOLIDATE_DOCUMENT == "false" && env.COMPONENT_TYPE =="GATEWAY"))
                       {
                                reportMap = [:]
                                condition = "RELEASE_NO = '" + env.RELEASE_NO + "' and COMPONENT_TYPE = '" + env.COMPONENT_TYPE + "' and STATUS = 'Active'"
                                docxFILEpath = "${pwd}/${env.RELEASE_NO}-${env.COMPONENT_TYPE}.docx"
                                docxFILE = "${env.RELEASE_NO}-${env.COMPONENT_TYPE}.docx"
                                if(env.COMPONENT_TYPE =="ISTIL")
                                {
                                    reportName = "Consolidated Report of all engines"
                                }
                                else
                                {
                                    reportName = "Consolidated Report of all gateway"
                                }
                                
                                reportMap.put('condition', condition)
                                reportMap.put('docxFILEpath', docxFILEpath)
                                reportMap.put('docxFILE', docxFILE)
                                reportMap.put('reportName', reportName)
                                reportList.add(reportMap)
                       }
                       else
                       {
                                if(selected_eng_gat == "")
                                {
                                    //println("No Engine/Gateway Selected")
                                    println("No Gateway selected")
                                    currentBuild.result = 'FAILURE'
                                    return
                                }
                                
                                array_eng_gat = selected_eng_gat.split(',');                                      
                                println ("=========================================================");   
                                println(array_eng_gat)
                                for(Counter=0; Counter < array_eng_gat.size(); Counter++)
                                {
                                        reportMap = [:]
                                        eng_gat_name= array_eng_gat[Counter]
                                        docxFILEpath = "${pwd}/${env.RELEASE_NO}-${env.COMPONENT_TYPE}(${eng_gat_name}).docx"
                                        docxFILE = "${env.RELEASE_NO}-${env.COMPONENT_TYPE}(${eng_gat_name}).docx"
                                        if(env.COMPONENT_TYPE =="ISTIL")
                                        {
                                            reportName = "Engine Specific Report - " + eng_gat_name
                                            condition = "RELEASE_NO = '" + env.RELEASE_NO + "' and COMPONENT_TYPE = '" + env.COMPONENT_TYPE + "' and ENGINE_NAME = '" + eng_gat_name + "' and STATUS = 'Active'"
                                        }
                                        else
                                        {
                                            reportName = "Gateway Specific Report - " + eng_gat_name
                                            condition = "RELEASE_NO = '" + env.RELEASE_NO + "' and COMPONENT_TYPE = '" + env.COMPONENT_TYPE + "' and GATEWAY_TYPE = '" + eng_gat_name + "' and STATUS = 'Active'"
                                        }
                                        
                                        reportMap.put('condition', condition)
                                        reportMap.put('docxFILEpath', docxFILEpath)
                                        reportMap.put('docxFILE', docxFILE)
                                        reportMap.put('reportName', reportName)
                                        reportList.add(reportMap)
                                }
                                println("Size--->" + reportList.size())
                       }
                      
                       
                 for(def Counter=0; Counter < reportList.size(); Counter++)
			    {
					reportMap = reportList[Counter];   
                    
                    condition = reportMap['condition'] 
                    docxFILEpath = reportMap['docxFILEpath'] 
                    docxFILE = reportMap['docxFILE'] 
                    reportName = reportMap['reportName']                     

                        try {                                
                            
                            docResponse = "${createDocument(RELEASE_NO,COMPONENT_TYPE,condition,docxFILEpath,reportName,BUILD_DATE)}"
                            if(docResponse==false)
                            { 
                               println("No Release/No Engine/ No Gateway records found. So document not prepared");
                            }
                            
                
                        }
                        catch (error) {
                            println("Build failed for some specific reason! - ${error}" )
                            println(error.getStackTrace().toString())
                            errorDescription=error;
                            currentBuild.result = 'FAILURE'
                        }

                    sh "echo '***********Send Mail****************'"
                    if(errorDescription=="")
                    {
                           if(docResponse=="true")
                            {
                                emailBody = "Release Document created for the release ${env.RELEASE_NO} and component ${env.COMPONENT_TYPE} dated ${BUILD_DATE}"
                                println("FileName --> ${docxFILE}");
                                emailext mimeType: 'text/html', attachmentsPattern: "${docxFILE}",
                                                 subject: "[ReleaseNotes]:${env.RELEASE_NO}-${reportName}",
                                                 from:"ReleaseNotes_Automation@vodafone.com",
                                                 to: "${dev_mailRecipients}",
                                                 body: 	"${emailBody}" + "<br>" + 
                                                        "<br><br><p><b><font size='5' color='Black'>Release Document  <a href='${BUILD_URL}input'>${currentBuild.displayName}</a></font></b></p>"
                                println("Sending a mail with Attachment");
                            }
                            else
                            {
                                 emailBody = "No Release/No Engine/ No Gateway records found. So document not prepared for the release ${env.RELEASE_NO} and component ${env.COMPONENT_TYPE} dated ${BUILD_DATE}"
                                
                                emailext mimeType: 'text/html',
                                                 subject: "[ReleaseNotes]:${env.RELEASE_NO}-${reportName}",
                                                 from:"ReleaseNotes_Automation@vodafone.com",
                                                 to: "${dev_mailRecipients}",
                                                 body: 	"${emailBody}" + "<br>" + 
                                                        "<br><br><p><b><font size='5' color='Black'>Release Document <a href='${BUILD_URL}input'>${currentBuild.displayName}</a></font></b></p>"
                                println("Sending a mail");
                            }
                     }
                     else
                     {
                          emailBody = "Error in file creation. So document not prepared for the release ${env.RELEASE_NO} and component ${env.COMPONENT_TYPE} dated ${BUILD_DATE}"
                                
                                emailext mimeType: 'text/html',
                                                 subject: "[ReleaseNotes]:${env.RELEASE_NO}-${reportName}",
                                                 from:"ReleaseNotes_Automation@vodafone.com",
                                                 to: "${dev_mailRecipients}",
                                                 body: 	"${emailBody}" + "<br>" + 
                                                        "<br><br><p><b><font size='5' color='Black'>Release Document <a href='${BUILD_URL}input'>${currentBuild.displayName}</a></font></b></p>"
                                println("Sending a mail with Error Description");
                     }
                     sh "echo 'After sending mail'"
                }
                     
               }//script
            }//steps
        }//stage
    }//stages	
}//pipeline


