import com.cwctravel.hudson.plugins.extended_choice_parameter.ExtendedChoiceParameterDefinition

import org.docx4j.convert.in.xhtml.XHTMLImporterImpl;
import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.docx4j.openpackaging.parts.WordprocessingML.MainDocumentPart;
import org.docx4j.convert.out.pdf.PdfConversion;
import org.docx4j.convert.out.pdf.viaXSLFO.PdfSettings;

import org.docx4j.wml.Body;
import org.docx4j.wml.FldChar;
import org.docx4j.wml.ObjectFactory;
import org.docx4j.wml.P;
import org.docx4j.wml.R;
import org.docx4j.wml.STFldCharType;
import org.docx4j.wml.Text;
import org.docx4j.jaxb.Context;
import org.docx4j.wml.Br;

import org.docx4j.openpackaging.parts.WordprocessingML.HeaderPart;
import org.docx4j.openpackaging.parts.WordprocessingML.FooterPart;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;
import org.docx4j.openpackaging.parts.relationships.Namespaces;
import org.docx4j.relationships.Relationship;

import org.docx4j.Docx4J;

import hudson.tasks.Mailer;
import hudson.model.User;

@NonCPS
def getUserEmail(String id=null) {
    User user = User.getById(id ?: currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId(), false)
    user?.getProperty(Mailer.UserProperty.class).getAddress()
}

@NonCPS
def getBuildUserID(){
    return currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId()
}

def getBuildUserName(){
    return currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserName()
}

//==============================Database Function====================================================

def displayDebug(strModule, strDebugMessage)
{
  def debug=1;
  if(debug == 1)
     {   
         println("***************************************")
         println("Module :" + strModule)
         println("Debug Message :" + strDebugMessage)
     }
}

def myGetDBConnect() {     
     def dbURL = 'jdbc:oracle:thin:@aukshocr.dc-dublin.de:33000:TIBTST1'
     def dbUserName = 'CICD_OWN_DB01'
     def dbPassword = 'TIL_CICD_DB'
     def dbDriver = 'oracle.jdbc.driver.OracleDriver'
     displayDebug('myGetDBConnect','Establishing DB Connectivity')
     def mySQL = groovy.sql.Sql.newInstance(dbURL,dbUserName,dbPassword,dbDriver)
     return mySQL                   
}


def myMultipleSelectQuery(selectQuery){     
     def mySQL =  myGetDBConnect()
  	 def rowData = [:]
	 def resultList = []
     displayDebug('myMultipleSelectQuery',selectQuery)
     def rowResults = mySQL.rows(selectQuery)
     mySQL.close()
     if(rowResults.size() == 0)
            return resultList;
     def headerList = new ArrayList(rowResults[0].keySet())    
	 for(def rlcounter=0;rlcounter<rowResults.size();rlcounter++)
     {
         def row = rowResults[rlcounter];
         rowData = [:]
         for(def rwHeaderCnt=0;rwHeaderCnt<headerList.size();rwHeaderCnt++)
         { 
               rowData.put(headerList[rwHeaderCnt], row[rwHeaderCnt]!= null  ? row[rwHeaderCnt].toString() : "")
         }
		 resultList.add(rowData)
     }
	 headerList=null;
	rowResults = null;
	rowData = null;
	mySQL = null;
    return resultList;
}


def mySingleSelectQuery(selectQuery){
     def mySQL =  myGetDBConnect()
  	 def rowData = [:]
     displayDebug('mySingleSelectQuery',selectQuery)
     def rowResults = mySQL.rows(selectQuery)
     mySQL.close();
     def headerList = new ArrayList(rowResults[0].keySet())
     for(def rlcounter=0;rlcounter<rowResults.size();rlcounter++)
     {
         def row = rowResults[rlcounter];
         rowData = [:]
         for(def rwHeaderCnt=0;rwHeaderCnt<headerList.size();rwHeaderCnt++)
         { 
           rowData.put(headerList[rwHeaderCnt], row[rwHeaderCnt]!= null  ? row[rwHeaderCnt].toString() : "")
         }
     }
	rowResults = null;
	mySQL = null;
	headerList = null;
    return rowData;
}

def getRSColumnDetails(relNum,columnName)
{    
   strQuery = "SELECT RS.ENGINE_NAME, JIRA_NO, RS." + columnName + " from (SELECT DISTINCT RN_ID, ENGINE_NAME, DEPLOYMENTS, regexp_substr(DEPLOYMENTS,'[^,]+',1,level) NEW_DEPLOYMENT_ID FROM (SELECT * from CICD_RN_DATA where RELEASE_NO = '" + relNum +"'  AND STATUS = 'APPROVED') CONNECT BY  level <= (length ( DEPLOYMENTS ) - length ( replace ( DEPLOYMENTS, ',' ) ) + 1)  order by DEPLOYMENTS) RN INNER JOIN CICD_RELEASE_SUMMARY RS ON RS.RELEASE_NO = RELEASE_NO and RS.ENGINE_NAME = RN.ENGINE_NAME and RS.RELEASE_SUMMARY_ID = RN.NEW_DEPLOYMENT_ID where RS.RELEASE_NO = '" + relNum +"' and STATUS = 'Active' AND (RS." + columnName + " is not null and  UPPER(RS." + columnName + ") <> 'NA') ORDER BY RN.ENGINE_NAME";
   rowList = myMultipleSelectQuery(strQuery);
   return rowList;
}

def getRNColumnDetails(relNum,columnName)
{    
   strQuery = "SELECT RS.ENGINE_NAME, JIRA_NO, RN." + columnName + " from (SELECT DISTINCT RN_ID,  ENGINE_NAME, " + columnName + ", DEPLOYMENTS, regexp_substr(DEPLOYMENTS,'[^,]+',1,level) NEW_DEPLOYMENT_ID  FROM (SELECT * from CICD_RN_DATA where RELEASE_NO = '" + relNum +"' AND STATUS = 'APPROVED') CONNECT BY  level <= (length ( DEPLOYMENTS ) - length ( replace ( DEPLOYMENTS, ',' ) ) + 1)  order by DEPLOYMENTS) RN INNER JOIN CICD_RELEASE_SUMMARY RS ON RS.RELEASE_NO = RELEASE_NO and RS.ENGINE_NAME = RN.ENGINE_NAME and RS.RELEASE_SUMMARY_ID = RN.NEW_DEPLOYMENT_ID where RS.RELEASE_NO = '" + relNum +"' and STATUS = 'Active' AND (RN." + columnName + " is not null and  UPPER(RN." + columnName + ") <> 'NA') ORDER BY RN.ENGINE_NAME";
   rowList = myMultipleSelectQuery(strQuery);
   return rowList;
}


def getSITDeploymentHistory(relNum)
{    
   strQuery = "select ENGINE_NAME, BW_VERSION, EMS_VERSION, SQL_VERSION, FILE_DEPLOYMENT, ONLY_GV from CICD_RN_DATA where RELEASE_NO = '" + relNum +"' and STATUS = 'APPROVED' ORDER BY ENGINE_NAME, APPROVED_ON DESC";
   rowList = myMultipleSelectQuery(strQuery);
   return rowList;
}



def getEngineList(relNum)
{
        strQuery = "SELECT ENGINE_NAME from (SELECT DISTINCT ENGINE_NAME FROM CICD_RN_DATA where RELEASE_NO = '" + relNum + "'  AND STATUS = 'APPROVED' order by ENGINE_NAME )";
        rowList = myMultipleSelectQuery(strQuery);        
        return rowList;
}



//====================================================================================================

def addTableOfContent(MainDocumentPart documentPart) {
		ObjectFactory  factory = Context.getWmlObjectFactory();
        P paragraph = factory.createP();
 
        addFieldBegin(paragraph);
        addTableOfContentField(paragraph);
        addFieldEnd(paragraph);
 
        documentPart.getJaxbElement().getBody().getContent().add(paragraph);
    }


def addFieldBegin(P paragraph) {
		ObjectFactory  factory = Context.getWmlObjectFactory();
        R run = factory.createR();
        FldChar fldchar = factory.createFldChar();
        fldchar.setFldCharType(STFldCharType.BEGIN);
        fldchar.setDirty(true);
        run.getContent().add(getWrappedFldChar(fldchar));
        paragraph.getContent().add(run);
    }


def addTableOfContentField(P paragraph) {
		ObjectFactory  factory = Context.getWmlObjectFactory();
        R run = factory.createR();
        Text txt = new Text();
        txt.setSpace("preserve");
        txt.setValue("TOC \\o \"1-3\" \\h \\z \\u");
        run.getContent().add(factory.createRInstrText(txt));
        paragraph.getContent().add(run);
    }


def addFieldEnd(P paragraph) {
        ObjectFactory  factory = Context.getWmlObjectFactory();
        R run = factory.createR();
        FldChar fldcharend = factory.createFldChar();
        fldcharend.setFldCharType(STFldCharType.END);
        run.getContent().add(getWrappedFldChar(fldcharend));
        paragraph.getContent().add(run);
    }


def convertImageToByteArray(File file)
              throws FileNotFoundException, IOException {
          InputStream is = new FileInputStream(file);
         long length = file.length();
         // You cannot create an array using a long, it needs to be an int.
           if (length > Integer.MAX_VALUE) {
              System.out.println("File too large!!");
           }
         byte[] bytes = new byte[(int) length];
          int offset = 0;
          int numRead = 0;
          while (offset < bytes.length && (numRead = is.read(bytes, offset, bytes.length -  
                    offset)) >= 0) {
              offset += numRead;
          }
          // Ensure all the bytes have been read
          if (offset < bytes.length) {
              System.out.println("Could not completely read file "
                      + file.getName());
          }
          is.close();
           return bytes;
       }


def addImageToPackage(WordprocessingMLPackage wordMLPackage,
                            byte[] bytes) throws Exception {
        org.docx4j.openpackaging.parts.WordprocessingML.BinaryPartAbstractImage imagePart =
            org.docx4j.openpackaging.parts.WordprocessingML.BinaryPartAbstractImage.createImagePart(wordMLPackage, bytes);
 
        int docPrId = 1;
        int cNvPrId = 2;
            org.docx4j.dml.wordprocessingDrawing.Inline inline = imagePart.createImageInline("Filename hint",
                "Alternative text", docPrId, cNvPrId, false);
 
        P paragraph = addInlineImageToParagraph(inline);
 
        wordMLPackage.getMainDocumentPart().addObject(paragraph);
    }


def addInlineImageToParagraph(org.docx4j.dml.wordprocessingDrawing.Inline inline) {
        // Now add the in-line image to a paragraph
        ObjectFactory factory = new ObjectFactory();
        P paragraph = factory.createP();
        R run = factory.createR();
        paragraph.getContent().add(run);
        org.docx4j.wml.Drawing drawing = factory.createDrawing();
        run.getContent().add(drawing);
        drawing.getAnchorOrInline().add(inline);
        return paragraph;
    }

def makePageBr() {
		org.docx4j.wml.ObjectFactory factory = new org.docx4j.wml.ObjectFactory();
		P p = factory.createP();
		R r = factory.createR();
		Br br = factory.createBr();
		br.setType(org.docx4j.wml.STBrType.PAGE);
		r.getContent().add(br);
		p.getContent().add(r);
		return p;
}


def getWrappedFldChar(FldChar fldchar) {
		return new JAXBElement( new QName(Namespaces.NS_WORD12, "fldChar"), 
			FldChar.class, fldchar);
}

//==============================

def preparation_function(){
    // Initialize parameters to pipeline job.
        buildRequestorMail = getUserEmail(getBuildUserID())
		properties([parameters([
                       string(defaultValue: 'CCS22.2', description: '	*Mandatory. ex. CSS22.2', name: 'RELEASE_NO', trim: true)])])
        
        checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: "*/main"]], doGenerateSubmoduleConfigurations: false, quietOperation: true, userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: "https://github.vodafone.com/VFUK-INTEGRATION/TIL_Devops_Java_Automation.git"]]]       

}


def getMultipleChoiceInput(Heading, Choice_Type, Options, Description, Size)
{
    def multiChoiceInput = new ExtendedChoiceParameterDefinition("${Heading}", "PT_CHECKBOX", "${Options}", "${Choice_Type}", 
                                                "", "", "", "", "", "", "", "", "", "", "", "", "",  
                                                "${Options}", 
                                                "", "", "", "", "", "", "", "",
                                                false,false, 
                                                Size, 
                                                "${Description}", 
                                                ",")
    return multiChoiceInput;
}


//===============================Document Creation=====================================================


def createDocument(RELEASE_NO, docxFILE,  BUILD_DATE)
{
    def response;
    try
    {
        response = "${prepareDocContents(RELEASE_NO, docxFILE, BUILD_DATE)}"
        if(response==false)
        { 
           println("No Release/No Engine records found. So document not prepared");
        }
    }
    catch (error) {
        println("Build failed for some specific reason! - ${error}" )
        println(error.getStackTrace().toString())
        errorDescription=error;
        currentBuild.result = 'FAILURE'
    }
    return response
}



def createDOCx(WordprocessingMLPackage wordPackage, DocxFileName)
{
    //org.docx4j.toc.TocGenerator tocGenerator = new org.docx4j.toc.TocGenerator(wordPackage);
	//tocGenerator.generateToc( 0, "TOC \\o \"1-3\" \\h \\z \\u \\h", false);
	//tocGenerator.updateToc( false); // true --> skip page numbering

	//File exportFile = new File(DocxFileName);
	//wordPackage.save(exportFile);
	Docx4J.save(wordPackage, new FileOutputStream(new File(DocxFileName)), Docx4J.FLAG_NONE);
	println("Saved Document");    
}


//===============================Document Content Creation ==============================================


def prepareDocContents(relNum, docxName, BUILD_DATE)
{
		
		WordprocessingMLPackage wordPackage = WordprocessingMLPackage.createPackage();
		MainDocumentPart mainDocumentPart = wordPackage.getMainDocumentPart();
		XHTMLImporterImpl importer = new XHTMLImporterImpl(wordPackage);
		
		List<Object> content ;
		
        
        mainDocumentPart.addParagraphOfText(" ");
        mainDocumentPart.addParagraphOfText(" "); 
        mainDocumentPart.addParagraphOfText(" ");
        mainDocumentPart.addParagraphOfText(" "); 
        mainDocumentPart.addParagraphOfText(" ");
        mainDocumentPart.addParagraphOfText(" "); 
        mainDocumentPart.addStyledParagraphOfText("Title", "TIL ${env.RELEASE_NO}");        
        mainDocumentPart.addParagraphOfText("This document contains engines related information which needs to be deployed as part of " + relNum);
        mainDocumentPart.addParagraphOfText(" "); 
        mainDocumentPart.addParagraphOfText(" ");
        mainDocumentPart.addStyledParagraphOfText("Subtitle","${getUserEmail()}");
        
        /*
		mainDocumentPart.addStyledParagraphOfText("Title", "Release Document");
        mainDocumentPart.addStyledParagraphOfText("Subtitle", "" + relNum);
        mainDocumentPart.addParagraphOfText("Generated by Jenkins");
        mainDocumentPart.addParagraphOfText("Generated on " + BUILD_DATE);
		*/
        /*
        try 
        {
            File file = new File("${WORKSPACE}@script/ReleaseNotes/vodafone-logo.png");
            byte[] bytes = convertImageToByteArray(file);
            addImageToPackage(wordPackage, bytes);
        }
        catch (error) {
            println("Error Accessing the vodafone logo - ${error}" )
            println(error.getStackTrace().toString())            
        }
        */
	
		mainDocumentPart.addObject(makePageBr());
		mainDocumentPart.addStyledParagraphOfText("Title", "TABLE OF CONTENTS");
		addTableOfContent(mainDocumentPart);
        
        /////////////////////////////////////////////////////////////////////////////
		
        displayDebug("Heading 1","")
		mainDocumentPart.addObject(makePageBr());		
		mainDocumentPart.addStyledParagraphOfText("Heading1", "1. Release Summary");
		//content.clear();
		tableContent = "";
		tableContent = getHTMLTable_ReleaseDocument()
		content = importer.convert(new java.lang.String(tableContent),null);
		wordPackage.getMainDocumentPart().getContent().addAll(content);
        
        /////////////////////////////////////////////////////////////////////////////
		
        displayDebug("Heading 1","")
		mainDocumentPart.addStyledParagraphOfText("Heading1", "2. Release History");
		content.clear();
		tableContent = "";
		tableContent = getHTMLTable_ReleaseHistory()
		content = importer.convert(new java.lang.String(tableContent),null);
		wordPackage.getMainDocumentPart().getContent().addAll(content);
        
        

        
        displayDebug("Heading 4","")
		mainDocumentPart.addStyledParagraphOfText("Heading1", "3. CHANGE REQUESTS OR DEFECTS DELIVERED");
        mainDocumentPart.addStyledParagraphOfText("Heading2", "3.1 ISTIL");		
        engList = getEngineList(relNum);
        content.clear();
        tableContent = "";
        tableContent = getBulletPoints(engList)
        println(tableContent);
        content = importer.convert(tableContent,null);
        wordPackage.getMainDocumentPart().getContent().addAll(content);
        
        /////////////////////////////////////////////////////////////////////////////

        
        displayDebug("Heading 4","")
		mainDocumentPart.addStyledParagraphOfText("Heading1", "4. Change Requests/Defects Delivered");
        mainDocumentPart.addParagraphOfText("Please Refer attached excel file below for details on CR/JIRA/Defect delivered");
        content.clear();
        tableContent = "";
        tableContent = getHTMLTable_placeholder("attach the excel")
        println(tableContent);
        content = importer.convert(tableContent,null);
        wordPackage.getMainDocumentPart().getContent().addAll(content);
        
        //////////////////////////////////////////////////////////////////////////////
        
        displayDebug("Heading 4","")
        columnResult = getRSColumnDetails(relNum,"KNOWN_ERROR_INCLUSION")
        mainDocumentPart.addStyledParagraphOfText("Heading1", "5. KNOWN_ERROR_INCLUSION");   
        mainDocumentPart.addParagraphOfText("Please add below entries in the Known_Errors_exclusion.txt and Known_Errors.txt files to avoid deployment failure.");       
        content.clear();
        tableContent = "";
        tableContent = getHTMLTable(columnResult)
        println(tableContent);
        content = importer.convert(tableContent,null);
        wordPackage.getMainDocumentPart().getContent().addAll(content);     

        //////////////////////////////////////////////////////////////////////////////
        
        displayDebug("Heading 4","")
        columnResult = getRSColumnDetails(relNum,"MASTER_GV")
        mainDocumentPart.addStyledParagraphOfText("Heading1", "6. MASTER_GV");        
        content.clear();
        tableContent = "";
        tableContent = getTextContent(columnResult)
        println(tableContent);
        content = importer.convert(tableContent,null);
        wordPackage.getMainDocumentPart().getContent().addAll(content);        
        
        //////////////////////////////////////////////////////////////////////////////
        
        displayDebug("Heading 4","")
        columnResult = getRSColumnDetails(relNum,"PROCESS_GV")
        mainDocumentPart.addStyledParagraphOfText("Heading1", "7. PROCESS_GV");        
        content.clear();
        tableContent = "";
        tableContent = getTextContent(columnResult)
        println(tableContent);
        content = importer.convert(tableContent,null);
        wordPackage.getMainDocumentPart().getContent().addAll(content);        
        

        //////////////////////////////////////////////////////////////////////////////
        
        displayDebug("Heading 4","")
        columnResult = getRSColumnDetails(relNum,"ENGINE_TEMPLATE")
        mainDocumentPart.addStyledParagraphOfText("Heading1", "8. ENGINE_TEMPLATE");        
        content.clear();
        tableContent = "";
        tableContent = getHTMLTable(columnResult)
        println(tableContent);
        content = importer.convert(tableContent,null);
        wordPackage.getMainDocumentPart().getContent().addAll(content);        
        

        //////////////////////////////////////////////////////////////////////////////
        
        displayDebug("Heading 4","")
        columnResult = getRSColumnDetails(relNum,"APPEND_PREPEND")
        mainDocumentPart.addStyledParagraphOfText("Heading1", "9. APPEND_PREPEND");        
        content.clear();
        tableContent = "";
        tableContent = getHTMLTable(columnResult)
        println(tableContent);
        content = importer.convert(tableContent,null);
        wordPackage.getMainDocumentPart().getContent().addAll(content);  


        //////////////////////////////////////////////////////////////////////////////
        
        displayDebug("Heading 4","")
        columnResult = getRSColumnDetails(relNum,"POST_MANUAL_CHANGES")
        mainDocumentPart.addStyledParagraphOfText("Heading1", "10. POST_MANUAL_CHANGES");        
        content.clear();
        tableContent = "";
        tableContent = getHTMLTable(columnResult)
        println(tableContent);
        content = importer.convert(tableContent,null);
        wordPackage.getMainDocumentPart().getContent().addAll(content); 

        //////////////////////////////////////////////////////////////////////////////
        
        displayDebug("Heading 4","")
        columnResult = getRNColumnDetails(relNum,"ENV_MASTER_CONF")
        mainDocumentPart.addStyledParagraphOfText("Heading1", "11. ENV_MASTER_CONF");        
        content.clear();
        tableContent = "";
        tableContent = getTextContent(columnResult)
        println(tableContent);
        content = importer.convert(tableContent,null);
        wordPackage.getMainDocumentPart().getContent().addAll(content);

        //////////////////////////////////////////////////////////////////////////////
        
        displayDebug("Heading 4","")
        columnResult = getRNColumnDetails(relNum,"PROCESS_MASTER_CONF")
        mainDocumentPart.addStyledParagraphOfText("Heading1", "12. PROCESS_MASTER_CONF");        
        content.clear();
        tableContent = "";
        tableContent = getTextContent(columnResult)
        println(tableContent);
        content = importer.convert(tableContent,null);
        wordPackage.getMainDocumentPart().getContent().addAll(content);        

        //////////////////////////////////////////////////////////////////////////////
        
        displayDebug("Heading 4","")
        columnResult = getRNColumnDetails(relNum,"RESTART_ENGINES")
        mainDocumentPart.addStyledParagraphOfText("Heading1", "13. RESTART_ENGINES");        
        content.clear();
        tableContent = "";
        tableContent = getHTMLTable(columnResult)
        println(tableContent);
        content = importer.convert(tableContent,null);
        wordPackage.getMainDocumentPart().getContent().addAll(content); 

        //////////////////////////////////////////////////////////////////////////////
        
        displayDebug("Heading 4","")
        columnResult = getRNColumnDetails(relNum,"ROLLBACK_INSTRUCTION")
        mainDocumentPart.addStyledParagraphOfText("Heading1", "14. ROLLBACK_INSTRUCTION");        
        content.clear();
        tableContent = "";
        tableContent = getHTMLTable(columnResult)
        println(tableContent);
        content = importer.convert(tableContent,null);
        wordPackage.getMainDocumentPart().getContent().addAll(content);  

        //////////////////////////////////////////////////////////////////////////////
        
        displayDebug("Heading 4","")
        columnResult = getRSColumnDetails(relNum,"SPECIAL_INSTRUCTIONS")
	mainDocumentPart.addStyledParagraphOfText("Heading1", "15. SPECIAL_INSTRUCTION");
        content.clear();
        tableContent = "";
        tableContent = getTextContent(columnResult)
        println(tableContent);
        content = importer.convert(tableContent,null);
        wordPackage.getMainDocumentPart().getContent().addAll(content);        
        
        
        /////////////////////////////////////////////////////////////////////////////
            
        displayDebug("Heading 4","")
        mainDocumentPart.addStyledParagraphOfText("Heading1", "16. Manual Changes");        
        content.clear();
        tableContent = "";
        tableContent = getHTMLTable_placeholder("Manual Changes")
        println(tableContent);
        content = importer.convert(tableContent,null);
        wordPackage.getMainDocumentPart().getContent().addAll(content);
        
        /////////////////////////////////////////////////////////////////////////////
            
        displayDebug("Heading 4","")
        mainDocumentPart.addStyledParagraphOfText("Heading1", "17. SQL Scripts for manual deployment");        
        content.clear();
        tableContent = "";
        tableContent = getHTMLTable_placeholder("SQL Scripts for manual deployment")
        println(tableContent);
        content = importer.convert(tableContent,null);
        wordPackage.getMainDocumentPart().getContent().addAll(content);
        
        /////////////////////////////////////////////////////////////////////////////
            
        displayDebug("Heading 4","")
        mainDocumentPart.addStyledParagraphOfText("Heading1", "18. EMS Scripts for Manual deployment");
        mainDocumentPart.addParagraphOfText("Please take a backup of existing EMS config before execution.");
        content.clear();
        tableContent = "";
        tableContent = getHTMLTable_EMS()
        println(tableContent);
        content = importer.convert(tableContent,null);
        wordPackage.getMainDocumentPart().getContent().addAll(content);
        
        /////////////////////////////////////////////////////////////////////////////
            
        displayDebug("Heading 4","")
        mainDocumentPart.addStyledParagraphOfText("Heading1", "19. TA");
        
        content.clear();
        tableContent = "";
        tableContent = getHTMLTable_placeholder("TA Sheet")
        println(tableContent);
        content = importer.convert(tableContent,null);
        wordPackage.getMainDocumentPart().getContent().addAll(content);
        mainDocumentPart.addParagraphOfText("Note: Please add all the certificates in common PROD server path for certificates. (Mentioned in GV value of BW_GLOBAL_TRUSTED_CA_STORE)");
        
        
        /////////////////////////////////////////////////////////////////////////////
            
        displayDebug("Heading 4","")
        SITDeployments = getSITDeploymentHistory(relNum);
        mainDocumentPart.addStyledParagraphOfText("Heading1", "20. SIT Deployment History");
        
        content.clear();
        tableContent = "";
        tableContent = getHTMLTable(SITDeployments)
        println(tableContent);
        content = importer.convert(tableContent,null);
        wordPackage.getMainDocumentPart().getContent().addAll(content);
		
	//return wordPackage;
	println("Content Ready");
	createDOCx(wordPackage,docxName);
    println("File name saved --> ${docxName}")
    return true;
}



//===============================HTML Creation ========================================================


def get_table_css() {
    def css = """
				<style type="text/css">
					.tg  {border-collapse:collapse;border-spacing:0;}
					.tg td{border-color:black;border-style:solid;border-width:1px;font-family:Arial, sans-serif;font-size:14px;
					  overflow:hidden;padding:8px 14px;word-break:normal;}
					.tg th{border-color:black;border-style:solid;border-width:1px;font-family:Arial, sans-serif;font-size:14px;
					  font-weight:normal;overflow:hidden;padding:8px 14px;word-break:normal;}
					.tg .tg-headleft{border-color:inherit;font-size:14px;font-weight:bold;text-align:left;vertical-align:top}					.tg-headcenter{border-color:inherit;font-size:14px;font-weight:bold;text-align:center;vertical-align:top}
					.tg .tg-cellvalue{border-color:inherit;text-align:left;vertical-align:top}
					.tg 
				</style>
	"""
	return css
}


def getHTMLTable_ReleaseDocument(){
     def tableContent = """
				<table class='tg'>
						<thead>
						  <tr>
							<th colspan="2" class='tg-headleft'>Document Summary</th>							
						  </tr>
						</thead>
						<tbody>
                          <tr>
							<td class='tg-headleft'>Release Version Number</td>
							<td class='tg-cellvalue'>VFUK_TIL-RIG_${env.RELEASE_NO}_ReleaseNote_V1.0</td>
						  </tr>
						  <tr>
							<td class='tg-headleft'>Release Prepared By</td>
							<td class='tg-cellvalue'>${getBuildUserName()} (${getUserEmail()})</td>
						  </tr>
						  <tr>
							<td class='tg-headleft'>Contact for Release</td>
							<td class='tg-cellvalue'>TIL-DEV Team</td>
						  </tr>
                          <tr>
							<td class='tg-headleft'>Date</td>
							<td class='tg-cellvalue'>${BUILD_DATE}</td>
						  </tr>
						  <tr>
							<td class='tg-headleft'>Reason for Release</td>
							<td class='tg-cellvalue'>${env.RELEASE_NO} Production Release</td>
						  </tr>
						  <tr>
							<td class='tg-headleft'>Reviewed By</td>
							<td class='tg-cellvalue'>${getHTMLTable_placeholder('Reviewer Name')}</td>
						  </tr>
						</tbody>
				</table>
	 """
	 tableContent = "<html><head><title>Release Note</title> " + get_table_css() + "</head><body>" + tableContent + "</body></html>"
     println(tableContent)
	 return tableContent
}

def getHTMLTable_ReleaseHistory(){
     def tableContent = """
				<table class='tg'>
						<thead>
						  <tr>
							<th class='tg-headleft'>Patch</th>
                            <th class='tg-headleft'>Date</th>
                            <th class='tg-headleft'>Prepared By</th>
                            <th class='tg-headleft'>Revision Description</th>							
						  </tr>
						</thead>
						<tbody>
						  <tr>
							<td>1</td>
                            <td>${BUILD_DATE}</td>
                            <td>${getBuildUserName()}</td>
                            <td>${getHTMLTable_placeholder('CRQ Number')}</td>							
						  </tr>
                          <tr>
							<td></td><td></td><td></td><td></td>							
						  </tr>
                          <tr>
							<td></td><td></td><td></td><td></td>							
						  </tr>						  
						</tbody>
				</table>
	 """
	 tableContent = "<html><head><title>Release Note</title> " + get_table_css() + "</head><body>" + tableContent + "</body></html>"
	 return tableContent
}

def getHTMLTable_EMS(){
     def tableContent = """
				<table class='tg'>
						<thead>
						  <tr>
							<th class='tg-headleft'>EMS BUS</th>
                            <th class='tg-headleft'>RollForward Script</th>
                            <th class='tg-headleft'>Rollback Script</th>                            						
						  </tr>
						</thead>
						<tbody>
						  <tr>
							<td>CB01</td>
                            <td></td><td></td>                            
						  </tr>
                          <tr>
							<td>CB02</td>
                            <td></td><td></td>                            
						  </tr>
                          <tr>
							<td>CB03</td>
                            <td></td><td></td>                            
						  </tr>
                          <tr>
							<td>CB05</td>
                            <td></td><td></td>                            
						  </tr>
                          <tr>
							<td>PB</td>
                            <td></td><td></td>                            
						  </tr>
                          <tr>
							<td>SB01</td>
                            <td></td><td></td>                            
						  </tr>
                          <tr>
							<td>SB02</td>
                            <td></td><td></td>                            
						  </tr>
                          <tr>
							<td>SB03</td>
                            <td></td><td></td>                            
						  </tr>                         			  
						</tbody>
				</table>
	 """
	 tableContent = "<html><head><title>Release Note</title> " + get_table_css() + "</head><body>" + tableContent + "</body></html>"
	 return tableContent
}


def get_table_release_summary_ISTIL(releaseList){
     def tableContent = """
				<table class='tg'>
				<thead>
				  <tr>
					<th class='tg-headcenter'>S.No</th>
					<th class='tg-headcenter'>ENGINE NAME</th>                    
					<th class='tg-headcenter'>BW VERSION</th>
					<th class='tg-headcenter'>EMS VERSION</th>
					<th class='tg-headcenter'>SQL VERSION</th>
					<th class='tg-headcenter'>FILE CHANGES</th>
				  </tr>
				</thead>
				<tbody>
			""";
				
                sno=1;
				
				for(def rlCounter=0; rlCounter < releaseList.size(); rlCounter++)
			    {
					row = releaseList[rlCounter];

						eName = (row['ENGINE_NAME'] != null) ? row['ENGINE_NAME'] : "";
                        gv = (row['GV'] != null && row['GV'] != "") ? (" - (" + row['GV'] + ")") : "";
						earVersion =  ((row['EAR_VERSION_MAX']!= '') ? row['EAR_VERSION_MAX'] : "NA")
						sqlVersion =  ((row['SQL_VERSION_MAX']!= '') ? row['SQL_VERSION_MAX'] : "NA")
						emsVersion =  ((row['EMS_VERSION_MAX']!= '') ? row['EMS_VERSION_MAX'] : "NA")
						files = getFileSummary(row['FILE_CHANGES_LIST']);
						
						tableContent += """
						  <tr>
							<td class='tg-cellvalue'>$sno</td>
							<td class='tg-cellvalue'>$eName $gv</td>                            
							<td class='tg-cellvalue'>$earVersion</td>
							<td class='tg-cellvalue'>$emsVersion</td>
							<td class='tg-cellvalue'>$sqlVersion</td>
							<td class='tg-cellvalue'>$files</td>
						  </tr>
						  """;
					 sno += 1;
				}
				
				tableContent += """</tbody></table>"""
	 tableContent = "<html><head><title>Release Note</title> " + get_table_css() + "</head><body>" + tableContent + "</body></html>"
	 return tableContent
}

def getHTMLTable(deploymentList){
     
     if(deploymentList.size() > 0)
     {
        headerList = deploymentList[0].keySet()
    
         def tableContent = "<table class='tg'><thead><tr>\n"
         for(def rlCounter=0; rlCounter < headerList.size(); rlCounter++)
         {
             tableContent += "<th class='tg-headcenter'> " + headerList[rlCounter] + " </th>\n"
         }
         tableContent += "\n</tr></thead><tbody>"			
                    
 
            for(def rlCounter=0; rlCounter < deploymentList.size(); rlCounter++)
            {
                row = deploymentList[rlCounter];
                tableContent += "\n<tr>\n"
                for(def colCounter=0; colCounter < headerList.size(); colCounter++)
                 {
                     value = (row[headerList[colCounter]] != null) ? row[headerList[colCounter]] : "";
                     tableContent += "<td class='tg-cellvalue'> " + value + " </td>\n"
                 }
                tableContent += "\n</tr>\n";
            }
                    
         tableContent += "</tbody></table>"
         tableContent = "<html><head><title>Release Note</title> " + get_table_css() + "</head><body>" + tableContent + "</body></html>"
         tableContent = tableContent.replaceAll("&","&amp;")
         return tableContent
     }
     else
     {
          return "<html><head><title>Release Note</title> " + get_table_css() + "</head><body>" + "No Data Found" + "</body></html>"
     }
}

def getTextContent(deploymentList){
     
     if(deploymentList.size() > 0)
     {
        headerList = deploymentList[0].keySet()
        Content = ""
        for(def rlCounter=0; rlCounter < deploymentList.size(); rlCounter++)
        {
            row = deploymentList[rlCounter];
            engine = (row[headerList[0]] != null) ? row[headerList[0]] : "";
            jira = (row[headerList[1]] != null) ? row[headerList[1]] : "";
            value = (row[headerList[2]] != null) ? row[headerList[2]] : "";
            
            Content += "<p><b>----- " + engine + " ----- (" + jira + ")</b></p>"
            Content += "<p>" + value + "</p>"
            Content += "<p></p>"
        }
         Content = "<html><head><title>Release Note</title> " + get_table_css() + "</head><body>" + Content + "</body></html>"
         Content = Content.replaceAll("&","&amp;")
         return Content
     }
     else
     {
          return "<html><head><title>Release Note</title> " + get_table_css() + "</head><body>" + "No Data Found" + "</body></html>"
     }
}


def getBulletPoints(deploymentList){
     
     if(deploymentList.size() > 0)
     {
        headerList = deploymentList[0].keySet()
    
         def tableContent = "<ol>\n"
 
            for(def rlCounter=0; rlCounter < deploymentList.size(); rlCounter++)
            {
                row = deploymentList[rlCounter];
                tableContent += "<li>"
                for(def colCounter=0; colCounter < headerList.size(); colCounter++)
                 {
                     value = (row[headerList[colCounter]] != null) ? row[headerList[colCounter]] : "";
                     tableContent += value 
                 }
                tableContent += "</li>\n";
            }
                    
         tableContent += "</ol>"
         tableContent = "<html><head><title>Release Note</title> " + get_table_css() + "</head><body>" + tableContent + "</body></html>"
         return tableContent
     }
     else
     {
          return "<html><head><title>Release Note</title> " + get_table_css() + "</head><body>" + "No Data Found" + "</body></html>"
     }
}


def getHTMLTable_placeholder(messgae){
     
     return "<html><head><title>Release Note</title> " + get_table_css() + "</head><body> <p style='color:red'>---- Place holder for " + messgae + " ----</p></body></html>"
     
}



def get_table_functionality_delivered_ISTIL(functionList){
     def tableContent = """
				<table class='tg' style="table-layout: fixed; width: 65%">
							<thead>
							  <tr>
								<th class='tg-headcenter'>ENGINE</th>
								<th class='tg-headcenter'>Operation</th>
								<th class='tg-headcenter'>Change Description</th>
                                <th class='tg-headcenter'>Engine Type</th>
							  </tr>
							</thead>
							<tbody>
							
						""";
			
			for( def funCounter=0; funCounter < functionList.size(); funCounter++)
			    {
					row = functionList[funCounter];

						eName = row['ENGINE_NAME'];
						consolidate_operation = remove_duplicates(row['OPERATION_LIST'].replaceAll("@#@#@#", ",")) 
                        operation = changeBullets(consolidate_operation,",");
						description = changeBullets(row['CHANGE_DESCRIPTION_LIST'],"@#@#@#");
                        enginetype = remove_duplicates(row['ENGINE_TYPE'].replaceAll("@#@#@#", ",")) 
                        enginetype = (enginetype.indexOf("UPDATED") != -1) ? "UPDATED" : "NEW";
						
						tableContent += """
							  <tr>
								<td class='tg-cellvalue'>$eName</td>
								<td class='tg-cellvalue'>$operation</td>
								<td class='tg-cellvalue'>$description</td>
                                <td class='tg-cellvalue'>$enginetype</td>
							  </tr>
							  """;
				}
				
				tableContent += """</tbody></table>"""
	 tableContent = "<html><head><title>Release Note</title> " + get_table_css() + "</head><body>" + tableContent + "</body></html>"
	 return tableContent
}


def get_table_engine(releaseNumber, componentType, earVersion, sqlVersion, emsVersion, engineName, fileChanges, changeDescription, operation, masterGV, processGV, engineTemplate, appendPrepand, knownError, postManualChanges, splInstructions, restartEngines){
     def tableContent = """
				<table class='tg' style="table-layout: fixed; width: 70%">
							<tbody>
							  <tr>
								<td class='tg-headleft' colspan="1">BW<br></br>Version</td>
								<td class='tg-cellvalue' colspan="2">$earVersion</td>
								<td class='tg-headleft' colspan="1">SQL<br></br>VERSION</td>
								<td class='tg-cellvalue' colspan="2">$sqlVersion</td>
							  </tr>
							  <tr>
								<td class='tg-headleft' colspan="1">EMS<br></br>Version</td>
								<td class='tg-cellvalue' colspan="2">$emsVersion</td>
								<td class='tg-headleft' colspan="1">Component<br></br>Type</td>
								<td class='tg-cellvalue' colspan="2">$componentType</td>
							  </tr>
							  <tr>
								<td class='tg-headleft' colspan="1">Operation<br></br>Name</td>
								<td class='tg-cellvalue' colspan="2">$operation</td>
								<td class='tg-headleft' colspan="1">Change Description</td>
								<td class='tg-cellvalue' colspan="2">$changeDescription</td>
							  </tr>
							  <tr>
								<td class='tg-headleft' colspan="1">File<br></br>Changes</td>
								<td class='tg-cellvalue' colspan="5">$fileChanges</td>
							  </tr>
							  <tr>
								<td class='tg-headleft' colspan="1">Env Master<br></br>GV Conf</td>
								<td class='tg-cellvalue' colspan="5">$masterGV</td>
							  </tr>
							  <tr>
								<td class='tg-headleft' colspan="1">Process Master<br></br>GV Conf</td>
								<td class='tg-cellvalue' colspan="5">$processGV</td>
							  </tr>
							  <tr>
								<td class='tg-headleft' colspan="1">Engine<br></br>Template</td>
								<td class='tg-cellvalue' colspan="5">$engineTemplate</td>
							  </tr>
							  <tr>
								<td class='tg-headleft' colspan="1">Append<br></br>Prepend<br></br>Path</td>
								<td class='tg-cellvalue' colspan="5">$appendPrepand</td>
							  </tr>
							  <tr>
								<td class='tg-headleft' colspan="1">Known<br></br>Errors</td>
								<td class='tg-cellvalue' colspan="5">$knownError</td>
							  </tr>
							  <tr>
								<td class='tg-headleft' colspan="1">Post<br></br>Manual<br></br>Changes</td>
								<td class='tg-cellvalue' colspan="5">$postManualChanges</td>
							  </tr>
							  <tr> 
								<td class='tg-headleft' colspan="1">Special Instructions</td>
								<td class='tg-cellvalue' colspan="5">$splInstructions</td>
							  </tr>
                               <tr> 
								<td class='tg-headleft' colspan="1">Restart Engines</td>
								<td class='tg-cellvalue' colspan="5">$restartEngines</td>
							  </tr>
							</tbody>
				</table>
				<BR></BR>
	 """
	 tableContent = "<html><head><title>Release Note</title> " + get_table_css() + "</head><body>" + tableContent + "</body></html>"
	 return tableContent
}


//===============================Main Pipeline ==========================================================



BUILD_DATE = ""
buildRequestorMail = ""
def docResponse=""

pipeline {
agent any
stages {
    stage('Preparation') {
        steps {
            script{
                deleteDir()
                preparation_function()
                  
                 }       				
			}			
		}//stage Preparation
                                
    stage('Dump') {
			steps {
                script {
                
                    try {
                        sh "echo '******* Compiling JAVA Files **********'"
                        excelFileName="Dump.xlsx"
                        sh "javac -cp './excelJars/*' getDBResult.java Dump.java"
                        sh "java -cp \$(for i in excelJars/*.jar ; do echo -n \$i: ; done). -DFileName='${excelFileName}' -DDeveloper='${getBuildUserName()}' Dump ${params.RELEASE_NO}"
                    }
                    catch (error) {
                        println("Build failed while preparing Dump - ${error}" )
                        println(error.getStackTrace().toString())
                        errorDescription=error;
                        currentBuild.result = 'FAILURE'
                        return
                    }
                }//script
            }//steps
    }//stage  


    stage('TA Sheet Preparation') {
			steps {
                script {
                
                    try {
                        sh "echo '******* Compiling JAVA Files **********'"
                        excelFileName="TA_Sheet_${params.RELEASE_NO}_V1.0.xlsx"
                        sh "javac -cp './excelJars/*' getDBResult.java TASheet.java"
                        sh "java -cp \$(for i in excelJars/*.jar ; do echo -n \$i: ; done). -DFileName='${excelFileName}' -DDeveloper='${getBuildUserName()}' TASheet ${params.RELEASE_NO}"
                    }
                    catch (error) {
                        println("Build failed while preparing TA Sheet - ${error}" )
                        println(error.getStackTrace().toString())
                        errorDescription=error;
                        currentBuild.result = 'FAILURE'
                        return
                    }
                }//script
            }//steps
    }//stage 

    stage('Release Notes Excel') {
			steps {
                script {
                
                    try {
                        sh "echo '******* Compiling JAVA Files **********'"
                        excelFileName="VFUK_TIL-RIG_${params.RELEASE_NO}_ReleaseNote_V1.0.xlsx"
                        sh "javac -cp './excelJars/*' getDBResult.java prodRN.java"
                        sh "java -cp \$(for i in excelJars/*.jar ; do echo -n \$i: ; done). -DFileName='${excelFileName}' -DDeveloper='${getBuildUserName()}' prodRN ${params.RELEASE_NO}"
                    }
                    catch (error) {
                        println("Build failed while preparing Prod RN - ${error}" )
                        println(error.getStackTrace().toString())
                        errorDescription=error;
                        currentBuild.result = 'FAILURE'
                        return
                    }
                }//script
            }//steps
    }//stage     
    
    
    stage('Release Notes Document') {
       steps{
           script{
               errorDescription = ""
               docxFILE = ""
               
                
                try {
                   pwd = sh (script: "pwd", returnStdout: true).trim()
                   docxFILE = "VFUK_TIL-RIG_${env.RELEASE_NO}_ReleaseNote_V1.0.docx"
                   docxFILEpath = "${pwd}/${docxFILE}"
                   BUILD_DATE = sh (script: "echo \$(date +%F-%H:%M)", returnStdout: true).trim() 
                   docResponse = "${createDocument(RELEASE_NO,docxFILEpath,BUILD_DATE)}"
                   
                    if(docResponse==false)
                    { 
                       println("No Release/No Engine records found. So document not prepared");
                       currentBuild.result = 'FAILURE'
                    }
                    }
                catch (error) {
                    println("Build failed for some specific reason! - ${error}" )
                    println(error.getStackTrace().toString())
                    errorDescription=error;
                    currentBuild.result = 'FAILURE'
                }      
                     
               }//script
            }//steps
        }//stage
        
        stage('Send Email') {
            steps{
                script{
                emailBody = "Documents created for the release ${env.RELEASE_NO} - dated ${BUILD_DATE}"
                emailext mimeType: 'text/html', attachmentsPattern: "*.xlsx,*.docx",
                                 subject: "[ReleaseNotes]:${env.RELEASE_NO}",
                                 from:"ReleaseNotes_Automation@vodafone.com",
                                 to: "${buildRequestorMail}",
                                 body: 	"${emailBody}" + "<br>" + 
                                        "<br><br><p><b><font size='5' color='Black'>Release Document  <a href='${BUILD_URL}input'>${currentBuild.displayName}</a></font></b></p>"
                println("Sending a mail with Attachment");
                }
            }
        }
        
    }//stages	
}//pipeline


