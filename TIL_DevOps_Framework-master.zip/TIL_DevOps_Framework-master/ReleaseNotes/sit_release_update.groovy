import com.cwctravel.hudson.plugins.extended_choice_parameter.ExtendedChoiceParameterDefinition
import hudson.tasks.Mailer;
import hudson.model.User;

def preparation_function() {

            properties([
                    buildDiscarder(logRotator(artifactDaysToKeepStr: '', artifactNumToKeepStr: '', daysToKeepStr: '', numToKeepStr: '100')),                     
                    parameters([
                                string(defaultValue: 'CCS22.1', description: 'Enter the RELEASE_NO', name: 'RELEASE_NO', trim: true),
                                string(defaultValue: '112', description: 'Enter the RN ID to Edit', name: 'RN_ID', trim: true),
                                string(defaultValue: 'TEST-1234', description: 'MANDATORY PARAMETER: Please enter JIRA/ADO/PBI Number', name: 'CHANGE_REF_ID', trim: true),
                                string(defaultValue: 'Please provide the description like why this data is updated so the approver can approve data', description: 'MANDATORY PARAMETER: Please enter description like details related to the request ', name: 'DESCRIPTION', trim: true)                                  
                                ])
                    ])
           
           BUILD_REQUESTER =  getBuildUserID()
           buildRequestorMail = getUserEmail(getBuildUserID())           
           def column = [:]
           column = [columnName: "TECH_CHANGES_INVOLVED", columnSize: "300", columnDBValue: "", columnUserValue: "", Comment: "Enter the new TECH_CHANGES_INVOLVED"]
           DBDetails.add(column)
           column = [columnName: "TA_DETAIL", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new TA_DETAIL"]
           DBDetails.add(column)
           column = [columnName: "TESTING_PERFORMED", columnSize: "30", columnDBValue: "", columnUserValue: "", Comment: "Enter the new TESTING_PERFORMED"]
           DBDetails.add(column)
           column = [columnName: "REG_TESTCASE_EXEC", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new REG_TESTCASE_EXEC"]
           DBDetails.add(column)
           column = [columnName: "PROG_TESTCASE_EXEC", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new PROG_TESTCASE_EXEC"]
           DBDetails.add(column)
           column = [columnName: "STUB_TESTED", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new STUB_TESTED"]
           DBDetails.add(column)
           column = [columnName: "LINKTEST_STATUS", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new LINKTEST_STATUS"]
           DBDetails.add(column)
           column = [columnName: "TEST_SHEET_LOCATION", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new TEST_SHEET_LOCATION"]
           DBDetails.add(column)
           column = [columnName: "ARTIFACT_LOCATION", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new ARTIFACT_LOCATION"]
           DBDetails.add(column)
           column = [columnName: "LOG_LOCATION", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new LOG_LOCATION"]
           DBDetails.add(column)
           column = [columnName: "SUPPLIMENT_DOC_LOCATION", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new SUPPLIMENT_DOC_LOCATION"]
           DBDetails.add(column)
           column = [columnName: "DESIGN_PPT_LOCATION", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new DESIGN_PPT_LOCATION"]
           DBDetails.add(column)
           column = [columnName: "LLD_LOCATION", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new LLD_LOCATION"]
           DBDetails.add(column)
           column = [columnName: "FUNCTIONAL_DEPENDENCIES", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new FUNCTIONAL_DEPENDENCIES"]
           DBDetails.add(column)    
           /*           
           column = [columnName: "RESTART_ENGINES", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new RESTART_ENGINES"]
           DBDetails.add(column)
           column = [columnName: "ENV_MASTER_CONF", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new ENV_MASTER_CONF"]
           DBDetails.add(column)
           column = [columnName: "PROCESS_MASTER_CONF", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new PROCESS_MASTER_CONF"]
           DBDetails.add(column)
           column = [columnName: "APP_CONF_FILE", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new APP_CONF_FILE"]
           DBDetails.add(column)
           column = [columnName: "GV_CONF_FILE", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new GV_CONF_FILE"]
           DBDetails.add(column)
           column = [columnName: "PR_CONF_FILE", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new PR_CONF_FILE"]
           DBDetails.add(column)
           column = [columnName: "CONF_FILE_PATH", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new CONF_FILE_PATH"]
           DBDetails.add(column)
           column = [columnName: "CONFIG_CHANGES", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new CONFIG_CHANGES"]
           DBDetails.add(column)
           column = [columnName: "CLASS_PATH", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new CLASS_PATH"]
           DBDetails.add(column)
           column = [columnName: "ROLLBACK_INSTRUCTION", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new ROLLBACK_INSTRUCTION"]
           DBDetails.add(column)
           column = [columnName: "STATUS", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new STATUS"]
           DBDetails.add(column)  
           */           
}


def getBuildUserID(){
            return currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId()
}

@NonCPS
def getUserEmail(String id=null) {
    User user = User.getById(id ?: currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId(), false)
    user?.getProperty(Mailer.UserProperty.class).getAddress()
}

def get_approvers_list(String approver_group){
	approvers_list = sh (script: """cat /opt/tibco/.jenkins/config.xml | sed -n \'/role name=\"${approver_group}\"/,\$p\' | sed \'/role>/q\' | grep "sid" | cut -d \'>\' -f 2 | cut -d \'<\' -f 1 | paste -s -d, -""", returnStdout: true).trim()
    return """${approvers_list}"""           
}

//==============================Database Function====================================================

def displayDebug(strModule, strDebugMessage)
{
  def debug=1;
  if(debug == 1)
     {   
         println("***************************************")
         println("Module :" + strModule)
         println("Debug Message :" + strDebugMessage)
     }
}

def myGetDBConnect() {     
     def dbURL = 'jdbc:oracle:thin:@aukshocr.dc-dublin.de:33000:TIBTST1'
     def dbUserName = 'CICD_OWN_DB01'
     def dbPassword = 'TIL_CICD_DB'
     def dbDriver = 'oracle.jdbc.driver.OracleDriver'
     displayDebug('myGetDBConnect','Establishing DB Connectivity')
     def mySQL = groovy.sql.Sql.newInstance(dbURL,dbUserName,dbPassword,dbDriver)
     return mySQL                   
}

def mySingleSelectQuery(selectQuery){
     def mySQL =  myGetDBConnect()
  	 def rowData = [:]
     displayDebug('mySingleSelectQuery',selectQuery)
     def rowResults = mySQL.rows(selectQuery)
     mySQL.close();
     if(rowResults.size()==0)
        return rowData
     def headerList = new ArrayList(rowResults[0].keySet())
     for(def rlcounter=0;rlcounter<rowResults.size();rlcounter++)
     {
         def row = rowResults[rlcounter];
         rowData = [:]
         for(def rwHeaderCnt=0;rwHeaderCnt<headerList.size();rwHeaderCnt++)
         { 
           rowData.put(headerList[rwHeaderCnt], row[rwHeaderCnt]!= null  ? row[rwHeaderCnt].toString() : "")
         }
     }
	rowResults = null;
	mySQL = null;
	headerList = null;
    return rowData;
}

def myMultipleSelectQuery(selectQuery){     
     def mySQL =  myGetDBConnect()
  	 def rowData = [:]
	 def resultList = []
     displayDebug('myMultipleSelectQuery',selectQuery)
     def rowResults = mySQL.rows(selectQuery)
     mySQL.close()
     if(rowResults.size() == 0)
            return resultList;
     def headerList = new ArrayList(rowResults[0].keySet())
	 for(def rlcounter=0;rlcounter<rowResults.size();rlcounter++)
     {
         def row = rowResults[rlcounter];
         rowData = [:]
         for(def rwHeaderCnt=0;rwHeaderCnt<headerList.size();rwHeaderCnt++)
         { 
               rowData.put(headerList[rwHeaderCnt], row[rwHeaderCnt]!= null  ? row[rwHeaderCnt].toString() : "")
         }
		 resultList.add(rowData)
     }
	 headerList=null;
	rowResults = null;
	rowData = null;
	mySQL = null;
    return resultList;
}


def maxVersion(col_name){
   strMaxQuery = "\nMAX(SUBSTR("+col_name+", 0, INSTR("+col_name+", '_',-1))) || MAX(TO_NUMBER(SUBSTR(REPLACE("+col_name+",'NA',''),INSTR("+col_name+", '_',-1)+1))) as " +col_name+ "_MAX"
   return strMaxQuery;
}

def consolidateColumn(col_name,delimeter){
   strcolumn = "\ndbms_lob.substr(rtrim (xmlagg (xmlelement (e, " + col_name + " || '" + delimeter + "')).extract( '//text()').getClobVal(),'" + delimeter + "'), 4000, 1 )  AS " +col_name+ "_LIST"
   return strcolumn;
}

def consolidateUniqueColumnValues(col_name){
   strcolumn = "\ndbms_lob.substr(REPLACE(REGEXP_REPLACE(rtrim (xmlagg (xmlelement (e, " + col_name + " || ';') order by " + col_name + " asc).extract ('//text()'), ';'),'([^;]+)(;\\1)+', '\\1'), ';', ','), 4000, 1 )  AS " +col_name+ "_LIST"
   return strcolumn;
}

def getEngineListDetailed(condition){ 
   strQuery = "select RELEASE_NO, COMPONENT_TYPE, ENGINE_NAME, " + maxVersion("EAR_VERSION") + ", "+ maxVersion("SQL_VERSION") + ", "+ maxVersion("EMS_VERSION") + ", " + consolidateUniqueColumnValues("JIRA_NO") + ", " + consolidateUniqueColumnValues("PROJECT_NAME") + ", " + consolidateUniqueColumnValues("CHANGE_DESCRIPTION") + ", " + consolidateUniqueColumnValues("OPERATION") + ", " + consolidateColumn("MASTER_GV","#") + ", " + consolidateColumn("PROCESS_GV","#") + ", " + consolidateUniqueColumnValues("FILE_CHANGES") + ", " + consolidateColumn("ENGINE_TEMPLATE",";") + ", " + consolidateColumn("APPEND_PREPEND",";") + ", " + consolidateColumn("KNOWN_ERROR_INCLUSION",";") + ", " + consolidateColumn("POST_MANUAL_CHANGES",";") + ", " + consolidateColumn("SPECIAL_INSTRUCTIONS",";") + ", " + consolidateColumn("RESTART_ENGINES",";") + ", " + consolidateUniqueColumnValues("ENGINE_TYPE") + ", " + consolidateColumn("BUILD_URL","\n") + " from CICD_RELEASE_SUMMARY where " + condition + " group by RELEASE_NO, COMPONENT_TYPE, ENGINE_NAME";
   rowList = myMultipleSelectQuery(strQuery);
   return rowList;
}

def myExecUpdateQuery(queryString) {
     def mySQL =  myGetDBConnect()
     mySQL.connection.autoCommit = false  
                 try {
                     println("Executing Update Query :" + queryString)
         int rowAffected = mySQL.executeUpdate(queryString);
         mySQL.commit()
         if(rowAffected > 0)
         {
         println("Successfully updated " + rowAffected + " rows") 
         }
         else
         {
           println("No records updated")
           return false;
         }
      }catch(Exception ex) {
         println("Error in Executing Update Query :" + queryString) 
                                 mySQL.rollback()
         println("Transaction rollback") 
         return false;
      }
      finally {
                     println("Trying to close the connection")
                     mySQL.close()
                                println("SQL Connection closed")
                  }
     return true
   }

def getDBEditColumnValues(release_no, RN_ID)
{
        strQuery = "select " + getColumnNames() + " from CICD_RN_DATA where RELEASE_NO = '" + release_no + "' and BUILD_ID = '"  + RN_ID + "' and STATUS='APPROVED'"

        displayDebug("getDBEditColumnValues", strQuery)
        rowList = mySingleSelectQuery(strQuery);
        println(rowList.getClass())
        return rowList;                
}

def getRNDetail(release_no, RN_ID)
{
        strQuery = "select RELEASE_NO, ENGINE_NAME, BW_VERSION, EMS_VERSION, SQL_VERSION, FILE_DEPLOYMENT, ONLY_GV, DEPLOYMENTS from CICD_RN_DATA where RELEASE_NO = '" + release_no + "' and BUILD_ID = '"  + RN_ID + "' and STATUS='APPROVED'"

        displayDebug("getRNDetail", strQuery)
        rowList = mySingleSelectQuery(strQuery);
        println(rowList.getClass())
        return rowList;                
}


def getRNFullDetail(release_no, RN_ID)
{ 
        strQuery = "select ENGINE_NAME, BW_VERSION, EMS_VERSION, SQL_VERSION, FILE_DEPLOYMENT, ONLY_GV, TECH_CHANGES_INVOLVED, TA_DETAIL, TESTING_PERFORMED, REG_TESTCASE_EXEC, PROG_TESTCASE_EXEC, STUB_TESTED, LINKTEST_STATUS, TEST_SHEET_LOCATION, ARTIFACT_LOCATION, LOG_LOCATION, SUPPLIMENT_DOC_LOCATION, DESIGN_PPT_LOCATION, LLD_LOCATION, FUNCTIONAL_DEPENDENCIES, RESTART_ENGINES, ENV_MASTER_CONF, PROCESS_MASTER_CONF, APP_CONF_FILE, GV_CONF_FILE, PR_CONF_FILE, CONF_FILE_PATH, CONFIG_CHANGES, CLASS_PATH, ROLLBACK_INSTRUCTION from CICD_RN_DATA  where RELEASE_NO = '" + release_no + "' and BUILD_ID = '"  + RN_ID + "' and STATUS='APPROVED'"

        displayDebug("getRNFullDetail", strQuery)
        rowList = mySingleSelectQuery(strQuery);
        println(rowList.getClass())
        return rowList;                
}

def updateValue(release_no, RN_ID)
{
		 def updateValues = ""
        for(def colCounter=0;colCounter<DBDetails.size();colCounter++)
             { 
                   if(!(DBDetails[colCounter]["columnUserValue"]).equals(DBDetails[colCounter]["columnDBValue"]))
                   {
                        updateValues += DBDetails[colCounter]["columnName"] + "= q'[" + DBDetails[colCounter]["columnUserValue"] + "]', ";
                    }
             }
         if(updateValues == "")
         {
            println("Error : No details updated. User has not changed any values")
            currentBuild.result = 'FAILURE'
            return "User didnt change any value"
         }
        displayDebug('updateValue',updateValues)
        
        def user = currentBuild.getRawBuild().getCauses()[0].getUserId()
        println("DEBUG: User -->" + user)
    
        strQuery = "update CICD_RN_DATA SET " + updateValues + " APPROVED_ON=sysdate, APPROVED_BY='${APPROVED_BY}' where  RELEASE_NO = '" + release_no + "' and BUILD_ID = '"  + RN_ID + "'"
        displayDebug("updateColumnValue", strQuery)
        response = myExecUpdateQuery(strQuery);
        return response
}

def getColumnNames()
{
    def columnNames = ""
    for(def colCounter=0;colCounter<DBDetails.size();colCounter++)
         { 
               columnNames += DBDetails[colCounter]["columnName"];
               if(colCounter != DBDetails.size() -1)
                {
                    columnNames += ", ";
                }
         }
    displayDebug('getColumnNames',columnNames)
    return columnNames;
}

def getChangedColumnNames()
{
    def columnNames = ""
    for(def colCounter=0;colCounter<DBDetails.size();colCounter++)
         { 
               if(DBDetails[colCounter]["columnName"] != DBDetails[colCounter]["columnName"])
               {
                   columnNames += DBDetails[colCounter]["columnName"];
                   columnNames += ", ";                   
                }
         }
    if(columnNames == "")
            throw error 
    else
        columnNames = columnNames.substring(0, columnNames.length()-2)
    displayDebug('getChangedColumnNames',columnNames)
    return columnNames;
}

def getUpdatedRecords()
{
    def user = currentBuild.getRawBuild().getCauses()[0].getUserId()
    emailBody = ""
    for(def colCounter=0;colCounter<DBDetails.size();colCounter++)
         { 
               if(DBDetails[colCounter]["columnDBValue"] != DBDetails[colCounter]["columnUserValue"])
               {
                   emailBody += "<tr>"
                   emailBody += "<td>" + DBDetails[colCounter]["columnName"] + "</td>"
                   emailBody += "<td>" + DBDetails[colCounter]["columnDBValue"] + "</td>"
                   emailBody += "<td>" + DBDetails[colCounter]["columnUserValue"] + "</td>"
                   emailBody += "</tr>"
                }
         }
     if(emailBody == "")
            emailBody = "No values updated by the user"
     else
            {
            emailHead = """
                            <style type="text/css">
                                .tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
                                .tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;width:150px;word-break:break-all;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
                                .tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:break-all;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
                                .tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
                                .tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
                                .tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
                                .tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
                                .tg .tg-0lax{text-align:left;vertical-align:top}
                                .tg .tg-pass{background-color:lightgreen;text-align:left;vertical-align:top}
                                .tg .tg-fail{background-color:red;text-align:left;vertical-align:top}
                                .tg .tg-notstarted{background-color:lightgrey;text-align:left;vertical-align:top}
                                .tg .tg-notrequired{background-color:#E1E0A2;text-align:left;vertical-align:top}
                            </style>
                         """
            emailBody = "<BR><BR> SUBMITTED_BY - ${user}<BR>CHANGE_REF_ID - ${params.CHANGE_REF_ID}<BR> DESCRIPTION - ${params.DESCRIPTION}<BR><BR><table class='tg' style='undefined;table-layout: fixed; width:100%'><tr><th>COLUMN_NAME</th><th>OLD_VALUE</th><th>NEW_VALUE</th></tr>" + emailBody + "</table>"
            emailBody = emailHead +  emailBody
            }    
    emailBody += "<BR><BR> Values Edited by ${user} for RN_ID - ${params.RN_ID}"
    return emailBody
}

def getEmailSubject(condition)
{
    engList = getEngineListDetailed(condition);
    if(engList.size() < 1)
    {
       error("Please check engine name and version number.")
       currentBuild.result = 'FAILURE'
       return false;
    }
    row = engList[0];
    project_list = (row['PROJECT_NAME_LIST'] != null) ? row['PROJECT_NAME_LIST'].toString() : "";
    jira_list = (row['JIRA_NO_LIST'] != null) ? row['JIRA_NO_LIST'].toString() : "";
    EMAIL_SUBJECT = "[${params.RELEASE}]" + "-" + "${params.DEPLOYMENT_TYPE}" + " SIT Release Notification for ${params.ENGINE_NAME} " + "[" + jira_list + "-"  + project_list + "]"
    return true;
}


def getJIRAandProject(condition)
{
    engList = getEngineListDetailed(condition);
    if(engList.size() < 1)
    {
       error("Please check engine name and version number.")
       currentBuild.result = 'FAILURE'
       return false;
    }
    row = engList[0];
    project_list = (row['PROJECT_NAME_LIST'] != null) ? row['PROJECT_NAME_LIST'].toString() : "";
    jira_list = (row['JIRA_NO_LIST'] != null) ? row['JIRA_NO_LIST'].toString() : "";
    return  jira_list + ","  + project_list    
} 

def getcssContent(){
    def css = """
        <style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Times, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;width:150px;word-break:break-all;border-color:#9ABAD9;color:#444;}
		.tg th{font-family:Times, sans-serif;font-size:26px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:break-all;border-color:#9ABAD9;color:#1A0504;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		.tg .tg-pass{background-color:lightgreen;text-align:left;vertical-align:top}
		.tg .tg-fail{background-color:red;text-align:left;vertical-align:top}
		.tg .tg-notstarted{background-color:lightgrey;text-align:left;vertical-align:top}
		.tg .tg-notrequired{background-color:#E1E0A2;text-align:left;vertical-align:top}
		</style>
        """
     return css
}



def get_release_notes_bw_sit(deployParams){
    def date_format_report = new Date().format("dd/MM/yyy HH:mm")
    def backgroundimage = "", subHeading = ""

    if(deployParams.isDraft == "true")
    {
           backgroundimage = " background=\"${WORKSPACE}/draft.jpg\""
           subHeading = " - DRAFT"
    }
    
    row = getRNFullDetail(params.RELEASE_NO, params.RN_ID)
    
    
    TECH_CHANGES_INVOLVED = (row['TECH_CHANGES_INVOLVED'] != null) ? row['TECH_CHANGES_INVOLVED'] : "";
    TA_DETAIL = (row['TA_DETAIL'] != null) ? row['TA_DETAIL'] : "";
    TESTING_PERFORMED = (row['TESTING_PERFORMED'] != null) ? row['TESTING_PERFORMED'] : "";
    REG_TESTCASE_EXEC = (row['REG_TESTCASE_EXEC'] != null) ? row['REG_TESTCASE_EXEC'] : "";
    PROG_TESTCASE_EXEC = (row['PROG_TESTCASE_EXEC'] != null) ? row['PROG_TESTCASE_EXEC'] : "";
    STUB_TESTED = (row['STUB_TESTED'] != null) ? row['STUB_TESTED'] : "";
    STUB_TESTED = (row['STUB_TESTED'] != null) ? row['STUB_TESTED'] : "";
    LINKTEST_STATUS = (row['LINKTEST_STATUS'] != null) ? row['LINKTEST_STATUS'] : "";    
    TEST_SHEET_LOCATION = (row['TEST_SHEET_LOCATION'] != null) ? row['TEST_SHEET_LOCATION'] : "";
    ARTIFACT_LOCATION = (row['ARTIFACT_LOCATION'] != null) ? row['ARTIFACT_LOCATION'] : "";
    LOG_LOCATION = (row['LOG_LOCATION'] != null) ? row['LOG_LOCATION'] : "";
    SUPPLIMENT_DOC_LOCATION = (row['SUPPLIMENT_DOC_LOCATION'] != null) ? row['SUPPLIMENT_DOC_LOCATION'] : "";
    DESIGN_PPT_LOCATION = (row['DESIGN_PPT_LOCATION'] != null) ? row['DESIGN_PPT_LOCATION'] : "";
    LLD_LOCATION = (row['LLD_LOCATION'] != null) ? row['LLD_LOCATION'] : "";
    FUNCTIONAL_DEPENDENCIES = (row['FUNCTIONAL_DEPENDENCIES'] != null) ? row['FUNCTIONAL_DEPENDENCIES'] : "";
    RESTART_ENGINES = (row['RESTART_ENGINES'] != null) ? row['RESTART_ENGINES'] : "";
    ENV_MASTER_CONF = (row['ENV_MASTER_CONF'] != null) ? row['ENV_MASTER_CONF'] : "";
    PROCESS_MASTER_CONF = (row['PROCESS_MASTER_CONF'] != null) ? row['PROCESS_MASTER_CONF'] : "";
    APP_CONF_FILE = (row['APP_CONF_FILE'] != null) ? row['APP_CONF_FILE'] : "";
    GV_CONF_FILE = (row['GV_CONF_FILE'] != null) ? row['GV_CONF_FILE'] : "";
    PR_CONF_FILE = (row['PR_CONF_FILE'] != null) ? row['PR_CONF_FILE'] : "";
    CONF_FILE_PATH = (row['CONF_FILE_PATH'] != null) ? row['CONF_FILE_PATH'] : "";
    CONFIG_CHANGES = (row['CONFIG_CHANGES'] != null) ? row['CONFIG_CHANGES'] : "";
    CLASS_PATH = (row['CLASS_PATH'] != null) ? row['CLASS_PATH'] : "";
    ROLLBACK_INSTRUCTION = (row['ROLLBACK_INSTRUCTION'] != null) ? row['ROLLBACK_INSTRUCTION'] : "";
    
    FILE_DEPLOYMENT = (row['FILE_DEPLOYMENT'] != null) ? row['FILE_DEPLOYMENT'] : "";
    ONLY_GV = (row['ONLY_GV'] != null) ? row['ONLY_GV'] : "";
    BW_VERSION = (row['BW_VERSION'] != null) ? row['BW_VERSION'] : "";
    EMS_VERSION = (row['EMS_VERSION'] != null) ? row['EMS_VERSION'] : "";
    SQL_VERSION = (row['SQL_VERSION'] != null) ? row['SQL_VERSION'] : "";
    ENGINE_NAME = (row['ENGINE_NAME'] != null) ? row['ENGINE_NAME'] : "";
    
    
    BW = "${BW_VERSION}"
    if(FILE_DEPLOYMENT.equalsIgnoreCase("true"))
    {
         BW += " (RESTART)"
    }
    if (ONLY_GV.equalsIgnoreCase("true"))
    {
         BW += " (ONLY GV)"
    }
    
    project = getJIRAandProject(condition).split(",")[1]
    jira = getJIRAandProject(condition).split(",")[0]

	def body_build_summary = """
		${getcssContent()}
        <table class="tg" style="table-layout: fixed; width: 100%" ${backgroundimage}>        
		  <tr>
			<th class="tg-amwm" colspan="8">SIT RELEASE NOTES ${subHeading}</th>
		  </tr>
          <tr>
			<th class="tg-amwm" colspan="8">${jira} | ${project}</th>
		  </tr>
         <tr>
            <td class="tg-1wig" colspan="1">PBI/JIRA/ADO/DEFECT</td>
            <td class="tg-0lax" colspan="3">${jira}</td>
			<td class="tg-1wig" colspan="1">PROJECT_NAME</td>
			<td class="tg-0lax" colspan="3">${project}</td>            
		  </tr>
          <tr>
            <td class="tg-1wig" colspan="1">Description of Change</td>
            <td class="tg-0lax" colspan="7">${deployParams.Description}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">Impacted TIL Operation(s)</td>
            <td class="tg-0lax" colspan="7">${deployParams.operationName}</td>
          </tr>
		  <tr>
            <td class="tg-1wig" colspan="1">Impacted Engine</td>
            <td class="tg-0lax" colspan="3">${ENGINE_NAME}</td>
           <td class="tg-1wig" colspan="1">Engine Type</td>
            <td class="tg-0lax" colspan="3">${deployParams.engine_type}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">BW Version</td>
            <td class="tg-0lax" colspan="3">${BW}</td>
            <td class="tg-1wig" colspan="1">EMS Version</td>
            <td class="tg-0lax" colspan="3">${EMS_VERSION}</td>            
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">SQL VERSION</td>
            <td class="tg-0lax" colspan="3">${SQL_VERSION}</td>
            <td class="tg-1wig" colspan="1">FILE DEPLOYMENT</td>
            <td class="tg-0lax" colspan="3">${FILE_DEPLOYMENT}</td>
          </tr>
           <tr>
            <td class="tg-1wig" colspan="1">ONLY_GV</td>
            <td class="tg-0lax" colspan="3">${ONLY_GV}</td>
            <td class="tg-1wig" colspan="1"></td>
            <td class="tg-0lax" colspan="3"></td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">Impacted TIL Operation(s)</td>
            <td class="tg-0lax" colspan="7">${deployParams.operationName}</td>
          </tr>
          <p id="bg-text" style="color:RED;font-size:40px;transform:rotate(300deg);-webkit-transform:rotate(300deg);">DRAFT DRAFT DRAFT</p>
         <tr>
			<th class="tg-amwm" colspan="8">Updates to Master Conf File. Replace with Env specific values where required</th>
		  </tr>       
        <tr>
            <td class="tg-1wig" colspan="1">Env MasterGV Conf (From RS-masterGV)</td>
            <td class="tg-0lax" colspan="7">${deployParams.masterGV}</td>
          </tr>
        <tr>
            <td class="tg-1wig" colspan="1">Env MasterGV Conf </td>
            <td class="tg-0lax" colspan="7">${ENV_MASTER_CONF}</td>
          </tr>
        <tr>
            <td class="tg-1wig" colspan="1">Process MasterGV Conf (From RS-processGV)</td>
            <td class="tg-0lax" colspan="7">${deployParams.processGV}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">Process GVs</td>
            <td class="tg-0lax" colspan="7">${PROCESS_MASTER_CONF}</td>
          </tr>

          <tr>
            <td class="tg-1wig" colspan="1">App Conf File</td>
            <td class="tg-0lax" colspan="7">${APP_CONF_FILE}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">GV Conf File</td>
            <td class="tg-0lax" colspan="7">${GV_CONF_FILE}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">CONF_FILE_PATH</td>
            <td class="tg-0lax" colspan="7">${CONF_FILE_PATH}</td>
          </tr> 
          <tr>
            <td class="tg-1wig" colspan="1">PR Conf File</td>
            <td class="tg-0lax" colspan="7">${PR_CONF_FILE}</td>
          </tr>          
          <tr>
            <td class="tg-1wig" colspan="1">RESTART_ENGINES</td>
            <td class="tg-0lax" colspan="7">${RESTART_ENGINES}</td>
          </tr> 
          <tr>
            <td class="tg-1wig" colspan="1">CONF_FILE_PATH</td>
            <td class="tg-0lax" colspan="7">${CONF_FILE_PATH}</td>
          </tr> 
          <tr>
            <td class="tg-1wig" colspan="1">CONFIG_CHANGES</td>
            <td class="tg-0lax" colspan="7">${CONFIG_CHANGES}</td>
          </tr> 
          <tr>
            <td class="tg-1wig" colspan="1">CLASS_PATH</td>
            <td class="tg-0lax" colspan="7">${CLASS_PATH}</td>
          </tr> 
          <tr>
            <td class="tg-1wig" colspan="1">ROLLBACK_INSTRUCTION</td>
            <td class="tg-0lax" colspan="7">${ROLLBACK_INSTRUCTION}</td>
          </tr>           
          <tr>
			<th class="tg-amwm" colspan="8">File Deployments & Other Configurations</th>
		  </tr>
          <tr>
            <td class="tg-1wig" colspan="1">FILE Deployment Type</td>
            <td class="tg-0lax" colspan="7">****File Deployment Type</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">FileChanges</td>
            <td class="tg-0lax" colspan="7">${deployParams.fileChanges}</td>
          </tr>

          <tr>
            <td class="tg-1wig" colspan="1">EngineTemplate</td>
            <td class="tg-0lax" colspan="7">${deployParams.engineTemplate}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">AppendPrependPath</td>
            <td class="tg-0lax" colspan="7">${deployParams.appendPrepand}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">KnownErrors</td>
            <td class="tg-0lax" colspan="7">${deployParams.knownError}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">PostManualChanges</td>
            <td class="tg-0lax" colspan="7">${deployParams.postManualChanges}</td>
          </tr>
          <tr> 
            <td class="tg-1wig" colspan="1">Special Instructions</td>
            <td class="tg-0lax" colspan="7">${deployParams.splInstructions}</td>
          </tr>
           <tr> 
            <td class="tg-1wig" colspan="1">Restart Engines (From RS)</td>
            <td class="tg-0lax" colspan="7">${deployParams.restartEngines}</td>
          </tr>
          <tr>
			<td class="tg-1wig" colspan="1">ARTIFACTS LOCATION</td>
			<td class="tg-0lax" colspan="7"><div class="multiline">${ARTIFACT_LOCATION.replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
		  </tr>
          <tr>
			<td class="tg-1wig" colspan="1">Deployment Pipeline URL</td>
			<td class="tg-0lax" colspan="7"><div class="multiline">${deployParams.build_url.replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="1">LOG_URL</td>
			<td class="tg-0lax" colspan="7"><div class="multiline">${BUILD_URL}console</div></td>
		  </tr>
		</table>		
	"""
    
    println(body_build_summary);
	return body_build_summary
}	


def getSITRNemailContent(deployParams)
{
    def emailContent = ""
    engList = getEngineListDetailed(condition);
    if(engList.size() < 1)
    {
       println("*******Number of Engines is zero **********");
       return false;
    }
    
    engNumber = 1;
    for(engCounter=0; engCounter < engList.size(); engCounter++)
    {
            row = engList[engCounter];
            displayDebug("ISTIL Engine List","Engine $engCounter")
            
            releaseID = (row['RELEASE_SUMMARY_ID'] != null) ? row['RELEASE_SUMMARY_ID'] : "";
            releaseNumber = (row['RELEASE_NO'] != null) ? row['RELEASE_NO'] : "";
            componentType = (row['COMPONENT_TYPE'] !=null) ? row['COMPONENT_TYPE'] : "";
            earVersion =  ((row['EAR_VERSION_MAX']!= '') ? row['EAR_VERSION_MAX'] : "NA")
            sqlVersion =  ((row['SQL_VERSION_MAX']!= '') ? row['SQL_VERSION_MAX'] : "NA")
            emsVersion =  ((row['EMS_VERSION_MAX']!= '') ? row['EMS_VERSION_MAX'] : "NA")                    
            engineName = (row['ENGINE_NAME'] != null) ? row['ENGINE_NAME'].toString() : "";				
            project_list = (row['PROJECT_NAME_LIST'] != null) ? row['PROJECT_NAME_LIST'].toString() : "";            
            jira_list = (row['JIRA_NO_LIST'] != null) ? row['JIRA_NO_LIST'].toString() : "";
            engine_type = (row['ENGINE_TYPE_LIST'] != null) ? row['ENGINE_TYPE_LIST'].toString() : "";
            build_url = (row['BUILD_URL_LIST'] != null) ? row['BUILD_URL_LIST'].toString() : "";
            fileChanges = (row['FILE_CHANGES_LIST'] != null) ? row['FILE_CHANGES_LIST'].toString() : "";
            //fileChanges = remove_duplicates(fileChanges.replaceAll("\n", ","), ";") 
            //fileChanges = changeBullets(fileChanges,",");
            
            changeDescription = (row['CHANGE_DESCRIPTION_LIST'] != null) ? row['CHANGE_DESCRIPTION_LIST'].toString() : "";
            //changeDescription = remove_duplicates(changeDescription.replaceAll("\n", ","), ";") 
            //changeDescription = changeBullets(changeDescription,",");
            
            operation = (row['OPERATION_LIST'] != null) ? row['OPERATION_LIST'].toString() : "";
            //operation = remove_duplicates(operation.replaceAll("\n", ","), ";") 
            //operation = changeBullets(operation,",");
            
            masterGV = (row['MASTER_GV_LIST'] != null) ? row['MASTER_GV_LIST'].toString() : "";
            //masterGV = remove_duplicates(masterGV.replaceAll("\n", "#"), "#") 
            //masterGV = changeBullets(masterGV,"#");
            
            processGV = (row['PROCESS_GV_LIST'] != null) ? row['PROCESS_GV_LIST'].toString() : "";
            //processGV = remove_duplicates(processGV.replaceAll("\n", "#"), "#") 
            //processGV = changeBullets(processGV,"#");
            
            engineTemplate = (row['ENGINE_TEMPLATE_LIST'] != null) ? row['ENGINE_TEMPLATE_LIST'].toString() : "";
            //engineTemplate = remove_duplicates(engineTemplate.replaceAll("\n", ","), ";") 
            //engineTemplate = changeBullets(engineTemplate,",");
            
            appendPrepand = (row['APPEND_PREPEND_LIST'] != null) ? row['APPEND_PREPEND_LIST'].toString() : ""
            //appendPrepand = remove_duplicates(appendPrepand.replaceAll("\n", ","), ";") 
            //appendPrepand = changeBullets(appendPrepand,",");
            
            knownError = (row['KNOWN_ERROR_INCLUSION_LIST'] != null) ? row['KNOWN_ERROR_INCLUSION_LIST'].toString() : "";
            //knownError = remove_duplicates(knownError.replaceAll("\n", ","), ";") 
            //knownError = changeBullets(knownError,",");
            
            postManualChanges = (row['POST_MANUAL_CHANGES_LIST'] != null) ? row['POST_MANUAL_CHANGES_LIST'].toString() : "";
            //postManualChanges = remove_duplicates(postManualChanges.replaceAll("\n", ","), ";") 
            //postManualChanges = changeBullets(postManualChanges,",");
            
            splInstructions = (row['SPECIAL_INSTRUCTIONS_LIST'] != null) ? row['SPECIAL_INSTRUCTIONS_LIST'].toString() : "";
            //splInstructions = remove_duplicates(splInstructions.replaceAll("\n", ","), ";") 
            //splInstructions = changeBullets(splInstructions,",");
            
            restartEngines = (row['RESTART_ENGINES_LIST'] != null) ? row['RESTART_ENGINES_LIST'].toString() : "";
            //restartEngines = remove_duplicates(removeFolderName(restartEngines).replaceAll(";", ","), ";")
            //restartEngines = changeBullets(restartEngines,",");
            
            if(fileChanges!=null && fileChanges.toString().trim()!="")
            {
               //fileChanges = getFileSummary(fileChanges)
            }
            else
               fileChanges = "No File Changes"
           

            emailContent+= get_release_notes_bw_sit isDraft:"${deployParams.isDraft}", isEdit:"${deployParams.isEdit}", BW_VERSION: earVersion, EMS_VERSION: emsVersion, SQL_VERSION: sqlVersion, ENGINE_NAME: engineName, JIRA: jira_list, PROJECT: project_list, operationName: operation.replaceAll("[\\t\\n\\r]+","<br>"), Description: changeDescription.replaceAll("[\\t\\n\\r]+","<br>"),  fileChanges: fileChanges.replaceAll("[\\t\\n\\r]+","<br>"), masterGV: masterGV.replaceAll("[\\t\\n\\r]+","<br>"), processGV: processGV.replaceAll("[\\t\\n\\r]+","<br>"), engineTemplate: engineTemplate.replaceAll("[\\t\\n\\r]+","<br>"), appendPrepand: appendPrepand.replaceAll("[\\t\\n\\r]+","<br>"), knownError: knownError.replaceAll("[\\t\\n\\r]+","<br>"), postManualChanges: postManualChanges.replaceAll("[\\t\\n\\r]+","<br>"), splInstructions: splInstructions.replaceAll("[\\t\\n\\r]+","<br>"), restartEngines: restartEngines.replaceAll("[\\t\\n\\r]+","<br>"), engine_type: engine_type.replaceAll("[\\t\\n\\r]+","<br>"), build_url: build_url.replaceAll("[\\t\\n\\r]+","<br>") 
            
            if(deployParams.isEdit == "true")
            { 
                emailContent += edit_summary()
            }            
    }
    if(deployParams.isDraft == "true")
    {
        emailContent += getLinks() 
    }    
    println("============================================================")    
    println(emailContent)
    return emailContent
	
}

def setCondition(RNO,RN_ID)
{
        releaseDetail= getRNDetail(RNO,RN_ID)
        println(releaseDetail)
        RELEASE = releaseDetail['RELEASE_NO'].toString()
        ENGINE_NAME = releaseDetail['ENGINE_NAME'].toString()
        BW_VERSION = releaseDetail['BW_VERSION'].toString()
        EMS_VERSION = releaseDetail['EMS_VERSION'].toString()
        SQL_VERSION = releaseDetail['SQL_VERSION'].toString()
        FILE_DEPLOYMENT = releaseDetail['FILE_DEPLOYMENT'].toString()
        ONLY_GV = releaseDetail['ONLY_GV'].toString()
        DEPLOYMENTS = releaseDetail['DEPLOYMENTS'].toString()
        
        conditionList = []
        if(BW_VERSION.length() != 0){
                    //getReleaseSummaryID('EAR_VERSION', BW_VERSION)
                    condition = "EAR_VERSION = '${BW_VERSION}'"
                    conditionList.add(condition)
        }   
            
        if(EMS_VERSION.length() != 0){
                    //getReleaseSummaryID('EMS_VERSION', EMS_VERSION)
                    condition = "(EMS_VERSION = '${EMS_VERSION}'"
                    conditionList.add(condition)  
            }
        if(SQL_VERSION.length() != 0){
                    //getReleaseSummaryID('SQL_VERSION', SQL_VERSION)
                    condition = "SQL_VERSION = '${SQL_VERSION}'"
                    conditionList.add(condition)
            }
          
        if(FILE_DEPLOYMENT.equalsIgnoreCase("true"))
        {
            if(BW_VERSION.length() == 0){
                condition = "EAR_VERSION = '1'"
                conditionList.add(condition)
            }                        
        }
        
        if(ONLY_GV.equalsIgnoreCase("true"))
        {
            if(BW_VERSION.length() == 0){
                condition = "EAR_VERSION = '0'"
                conditionList.add(condition)
            }
        }
        
        condition = ""
        for (counter=0 ; counter < conditionList.size(); counter++)                        
        {
           if(counter != 0)
                condition += " OR "
           condition +=  conditionList[counter] + " \n" 
        }
        condition =  "RELEASE_NO='${RELEASE}' AND ENGINE_NAME='${ENGINE_NAME}' AND " + condition
        condition += " AND RELEASE_SUMMARY_ID IN (" + DEPLOYMENTS + ")"
 }


DBDetails = []
BUILD_REQUESTER = ""
//TLapprovers_mailRecipients = "musa.shaik3@vodafone.com, mangesh.deshpande@vodafone.com, balaji.sukhadevghadage@vodafone.com, tanaji.kisangadekar@vodafone.com, rohit.srivastava3@vodafone.com, rushikesh.nayak@vodafone.com, monika.gupta1@vodafone.com, punitha.kp@vodafone.com, aditya.kodukulla1@vodafone.com, murali.manam@vodafone.com, nitisha.tambe@vodafone.com, amol.belsare@vodafone.com, kartik.namjoshi@vodafone.com, amitesh.raj@vodafone.com, devops-vfuk-integration@vodafone.com "
//SIT_mailRecipients = "vfukintegrationadtil@vodafone.com"
TLapprovers_mailRecipients = "devops-vfuk-integration@vodafone.com"
SIT_mailRecipients = "devops-vfuk-integration@vodafone.com"

APPROVED_BY = ""
condition = ""
EMAIL_SUBJECT = ""
       
pipeline {
agent any

options {
     timeout(time: 6, unit: 'DAYS')
}

	stages {
		
        stage('PREPARATION') {
			steps {
                script {
                
                        preparation_function()
                        
                        echo "Release Number is: ${params.RELEASE_NO}"
                        echo "RN_ID is: ${params.RN_ID}"                
                }//script
            }//steps
         }//stage
        
        
        
        stage('Enter Value') {
			steps {
                script {
                        
                        releaseValue = getDBEditColumnValues(params.RELEASE_NO, params.RN_ID)
                        println("No of Rows fetched -->" + releaseValue.size())
                        
                        if(releaseValue.size() == 0)
                        {
                            println("No records to fetch. Check RN_ID ")
                            error("Cant identify a record to edit. Check RN_ID and RELEASE_NO combination or RN_ID is in APPROVED STATUS")
                            currentBuild.result = 'FAILURE'
                        }                                                
                        setCondition(params.RELEASE_NO, params.RN_ID)
                        def cname = ""
                        for(def colCounter=0;colCounter<DBDetails.size();colCounter++)
                        { 
                               cName = DBDetails[colCounter]["columnName"];
                               DBDetails[colCounter]["columnDBValue"] = (releaseValue[cName] != null ) ? releaseValue[cName].toString() : ""                       
                         }
                    
                                            
                    def userInput = input(
                    id:'userInput',message:"Enter the New values for RN_ID - ${params.RN_ID}",
                parameters: [
                [$class: 'TextParameterDefinition',defaultValue:DBDetails[0]['columnDBValue'],description:DBDetails[0]['Comment'],name:DBDetails[0]['columnName']],
                [$class: 'TextParameterDefinition',defaultValue:DBDetails[1]['columnDBValue'],description:DBDetails[1]['Comment'],name:DBDetails[1]['columnName']],
                [$class: 'TextParameterDefinition',defaultValue:DBDetails[2]['columnDBValue'],description:DBDetails[2]['Comment'],name:DBDetails[2]['columnName']],
                [$class: 'TextParameterDefinition',defaultValue:DBDetails[3]['columnDBValue'],description:DBDetails[3]['Comment'],name:DBDetails[3]['columnName']],
                [$class: 'TextParameterDefinition',defaultValue:DBDetails[4]['columnDBValue'],description:DBDetails[4]['Comment'],name:DBDetails[4]['columnName']],
                [$class: 'TextParameterDefinition',defaultValue:DBDetails[5]['columnDBValue'],description:DBDetails[5]['Comment'],name:DBDetails[5]['columnName']],
                [$class: 'TextParameterDefinition',defaultValue:DBDetails[6]['columnDBValue'],description:DBDetails[6]['Comment'],name:DBDetails[6]['columnName']],
                [$class: 'TextParameterDefinition',defaultValue:DBDetails[7]['columnDBValue'],description:DBDetails[7]['Comment'],name:DBDetails[7]['columnName']],
                [$class: 'TextParameterDefinition',defaultValue:DBDetails[8]['columnDBValue'],description:DBDetails[8]['Comment'],name:DBDetails[8]['columnName']],
                [$class: 'TextParameterDefinition',defaultValue:DBDetails[9]['columnDBValue'],description:DBDetails[9]['Comment'],name:DBDetails[9]['columnName']],
                [$class: 'TextParameterDefinition',defaultValue:DBDetails[10]['columnDBValue'],description:DBDetails[10]['Comment'],name:DBDetails[10]['columnName']],
                [$class: 'TextParameterDefinition',defaultValue:DBDetails[11]['columnDBValue'],description:DBDetails[11]['Comment'],name:DBDetails[11]['columnName']],
                [$class: 'TextParameterDefinition',defaultValue:DBDetails[12]['columnDBValue'],description:DBDetails[12]['Comment'],name:DBDetails[12]['columnName']],
                [$class: 'TextParameterDefinition',defaultValue:DBDetails[13]['columnDBValue'],description:DBDetails[13]['Comment'],name:DBDetails[13]['columnName']]                              
                    ])
                    
                for(def colCounter=0;colCounter<DBDetails.size();colCounter++)                
                { 
                       cName = DBDetails[colCounter]["columnName"];
                       DBDetails[colCounter]["columnUserValue"]  = userInput[cName];                 
                 }
                  //xxx                 
                }//script
            }//steps
        }//stage
        
        stage('VALIDATION') {
			steps {
                script {
                       sh "echo 'Validation'"
                       def isValid= true;
                       for(def colCounter=0;colCounter<DBDetails.size();colCounter++)
                        { 
                              if((DBDetails[colCounter]['columnUserValue'].length()) > (DBDetails[colCounter]['columnSize'].toInteger()))
                                {
                                    isValid= false;
                                    println("Length validation issue for column " + DBDetails[colCounter]['columnName'])
                                    println("Expected -> " + DBDetails[colCounter]['columnSize'] + "Actual -> " + DBDetails[colCounter]['columnUserValue'].length());
                                }
                         }
                         
                         if(!isValid)
                         {
                            println("Validation Not met. So aborting Updating")
                            currentBuild.result = 'FAILURE'
                         }
                         
                }//script
            }//steps
        }//stage
        
         stage('Approval') {
           steps {
                script {
                    
                    sh "echo 'Approval'"
                    techLeadmails = get_approvers_list('SITReleaseTechLeadApprovers')
                    techLeadmails += "," + TLapprovers_mailRecipients
                    println(techLeadmails)
                      
                    emailBody = getUpdatedRecords()
                    println(emailBody)
                    emailext mimeType: 'text/html',
                             subject: "[SIT RELEASE EDIT]:${params.RN_ID}-Update Approval",
                             from:"TIL_SIT_RN_UPDATE@vodafone.com",
                             to: "${SIT_mailRecipients}",
                             body: 	"${emailBody}" + "<br>" + 
                                    "<br><br><p><b><font size='5' color='Black'>SIT Release Notes - Edit  <a href='${BUILD_URL}input'>${currentBuild.displayName}</a></font></b></p>" 
                  
                     def TLInput = input( id: 'TLInput', message: 'Please Approve the Values Updated?',
                                parameters: 
                                [[$class: 'ChoiceParameterDefinition', defaultValue: 'REJECT', 
                                description:'Please provide your approval for updating the values', name:'Approval', choices: "REJECT\nAPPROVE"]],
                                submitterParameter: 'submitter',
                                submitter: "${techLeadmails}"
                           )
                          TLApproval = TLInput.Approval 
                          APPROVED_BY = TLInput.submitter                     
                         if(TLApproval == "APPROVE")
                         {   
                               println(" Approved by ${APPROVED_BY}")
                         }
                         else
                         {
                               println(" Rejected by ${APPROVED_BY}")
                               emailext mimeType: 'text/html',
                                 subject: "[SIT RELEASE EDIT]:${params.RN_ID}- Update Request Rejected",
                                 from:"TIL_SIT_RN_UPDATE@vodafone.com",
                                 to: "${techLeadmails},${buildRequestorMail}",
                                 body: 	"${emailBody}" + "<br>" + 
                                        "<br><br><p><b><font size='5' color='Black'>SIT Release Notes - Edit  <a href='${BUILD_URL}input'>${currentBuild.displayName}</a></font></b></p>" 
                               error "Update Request rejected by ${APPROVED_BY}"
                               currentBuild.result = 'FAILURE'                               
                         }
                }//script
            }//steps
        }//stage
        
        stage('UPDATING') {
			steps {
                script {
                       sh "echo 'UPDATING'"

                       upColumn = "${updateValue(params.RELEASE_NO, params.RN_ID)}"
                       displayDebug('After Updating Column Value', upColumn)
                }//script
            }//steps
        }//stage
        
        /*
        stage('Sending Email') {
			steps {
                script {
                       sh "echo 'Sending EMail'"
                       emailBody = getUpdatedRecords()
                       println(emailBody)
                        emailext mimeType: 'text/html',
                                 subject: "[ReleaseNotes]:${params.RN_ID}-Updation",
                                 from:"TIL_SIT_RN_UPDATE@vodafone.com",
                                 to: "${BUILD_REQUESTER}",
                                 body: 	"${emailBody}" + "<br>" + 
                                        "<br><br><p><b><font size='5' color='Black'>Release Summary - Edit  <a href='${BUILD_URL}input'>${currentBuild.displayName}</a></font></b></p>" 
                       
                       displayDebug('Sending Mail', 'After Sending Email')
                }//script
            }//steps
        }//stage
        */
        
        stage('Send Email') {
            when {
				expression { TLApproval == "APPROVE"}
			}
			steps {
            script{					
            
            SIT_mailRecipients += ", " + buildRequestorMail
            emailContent=getSITRNemailContent isDraft: "false", isEdit: "false"
            
            emailext mimeType: 'text/html', 
             subject: "[Jenkins]: ${EMAIL_SUBJECT} - SIT Release Notes",  
             from:"TIL_SIT_RN@vodafone.com", 
             to: "${SIT_mailRecipients}", 
             body: "${emailContent}"             
            }
            }
        }
        
    }//stages
}//pipeline 
