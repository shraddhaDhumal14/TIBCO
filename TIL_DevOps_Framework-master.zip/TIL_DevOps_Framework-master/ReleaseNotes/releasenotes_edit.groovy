def preparation_function() {

            properties([
                    buildDiscarder(logRotator(artifactDaysToKeepStr: '', artifactNumToKeepStr: '', daysToKeepStr: '', numToKeepStr: '50')), 
                    
                    parameters([
                                choice(choices: ['ISTIL','GATEWAY'], description: '*Mandatory.', name: 'COMPONENT_TYPE'),
                                string(defaultValue: '', description: '	Please refer release dashboard (Detailed Report) \n http://195.233.197.150:8080/jenkins/job/Utilities/job/ReleaseNotes_Dashboard/', name: 'RELEASE_SUMMARY_ID', trim: true),
                                string(defaultValue: '@vodafone.com', description: '*Mandatory. Please enter valid vodafone email id like xxx_xxx@vodafone.com', name: 'BUILD_REQUESTER', trim: true), 
                                ])
                    ])
            
           def column = [:]
           column = [columnName: "PROJECT_NAME", columnSize: "100", columnDBValue: "", columnUserValue: "", Comment: "Enter the new PROJECT_NAME"]
           DBDetails.add(column)
           column = [ columnName: "JIRA_NO", columnSize: "30", columnDBValue: "", columnUserValue: "", Comment: "Enter the new JIRA_NO"]
           DBDetails.add(column)
           column = [ columnName: "CHANGE_DESCRIPTION", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new CHANGE_DESCRIPTION"]
           DBDetails.add(column)
           column = [columnName: "OPERATION", columnSize: "1000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new OPERATION"]
           DBDetails.add(column)
           column = [columnName: "MASTER_GV", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new MASTER_GV"]
           DBDetails.add(column)
           column = [ columnName: "PROCESS_GV", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new PROCESS_GV"]
           DBDetails.add(column)
           column = [ columnName: "ENGINE_TEMPLATE", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new ENGINE_TEMPLATE"]
           DBDetails.add(column)
           column = [columnName: "APPEND_PREPEND", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new APPEND_PREPEND"]
           DBDetails.add(column)
           column = [columnName: "KNOWN_ERROR_INCLUSION", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new KNOWN_ERROR_INCLUSION"]
           DBDetails.add(column)
           column = [ columnName: "POST_MANUAL_CHANGES", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new POST_MANUAL_CHANGES"]
           DBDetails.add(column)
           column = [ columnName: "PARTNER_DATA", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new PARTNER_DATA"]
           DBDetails.add(column)
           column = [columnName: "GATEWAY_TOKEN", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new GATEWAY_TOKEN"]
           DBDetails.add(column)
           column = [columnName: "SPECIAL_INSTRUCTIONS", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new SPECIAL_INSTRUCTIONS"]
           DBDetails.add(column)
           column = [columnName: "LINKTEST_RESULTS", columnSize: "100", columnDBValue: "", columnUserValue: "", Comment: "Enter the new LINKTEST_RESULTS"]
           DBDetails.add(column)
           column = [columnName: "FILE_CHANGES", columnSize: "500", columnDBValue: "", columnUserValue: "", Comment: "Enter the new FILE_CHANGES"]
           DBDetails.add(column)
           column = [columnName: "RESTART_ENGINES", columnSize: "4000", columnDBValue: "", columnUserValue: "", Comment: "Enter the new RESTART_ENGINES"]
           DBDetails.add(column)
           column = [columnName: "STATUS", columnSize: "100", columnDBValue: "", columnUserValue: "", Comment: "Enter the new STATUS"]
           DBDetails.add(column)           
        
}

//==============================Database Function====================================================

def displayDebug(strModule, strDebugMessage)
{
  def debug=1;
  if(debug == 1)
     {   
         println("***************************************")
         println("Module :" + strModule)
         println("Debug Message :" + strDebugMessage)
     }
}

def myGetDBConnect() {     
     def dbURL = 'jdbc:oracle:thin:@aukshocr.dc-dublin.de:33000:TIBTST1'
     def dbUserName = 'CICD_OWN_DB01'
     def dbPassword = 'TIL_CICD_DB'
     def dbDriver = 'oracle.jdbc.driver.OracleDriver'
     displayDebug('myGetDBConnect','Establishing DB Connectivity')
     def mySQL = groovy.sql.Sql.newInstance(dbURL,dbUserName,dbPassword,dbDriver)
     return mySQL                   
}

def mySingleSelectQuery(selectQuery){
     def mySQL =  myGetDBConnect()
  	 def rowData = [:]
     displayDebug('mySingleSelectQuery',selectQuery)
     def rowResults = mySQL.rows(selectQuery)
     mySQL.close();
     if(rowResults.size()==0)
        return rowData
     def headerList = new ArrayList(rowResults[0].keySet())
     for(def rlcounter=0;rlcounter<rowResults.size();rlcounter++)
     {
         def row = rowResults[rlcounter];
         rowData = [:]
         for(def rwHeaderCnt=0;rwHeaderCnt<headerList.size();rwHeaderCnt++)
         { 
           rowData.put(headerList[rwHeaderCnt], row[rwHeaderCnt]!= null  ? row[rwHeaderCnt].toString() : "")
         }
     }
	rowResults = null;
	mySQL = null;
	headerList = null;
    return rowData;
}

def myExecUpdateQuery(queryString) {
     def mySQL =  myGetDBConnect()
     mySQL.connection.autoCommit = false  
                 try {
                     println("Executing Update Query :" + queryString)
         int rowAffected = mySQL.executeUpdate(queryString);
         mySQL.commit()
         if(rowAffected > 0)
         {
         println("Successfully updated " + rowAffected + " rows") 
         }
         else
         {
           println("No records updated")
           return false;
         }
      }catch(Exception ex) {
         println("Error in Executing Update Query :" + queryString) 
                                 mySQL.rollback()
         println("Transaction rollback") 
         return false;
      }
      finally {
                     println("Trying to close the connection")
                     mySQL.close()
                                println("SQL Connection closed")
                  }
     return true
   }

def getDBColumnValues(compType, release_sumary_id)
{
        strQuery = "select " + getColumnNames() + " from CICD_RELEASE_SUMMARY where COMPONENT_TYPE = '" + compType + "' and RELEASE_SUMMARY_ID = '"  + release_sumary_id + "'"

        displayDebug("getDBColumnValues", strQuery)
        rowList = mySingleSelectQuery(strQuery);
        println(rowList.getClass())
        return rowList;                
}


def updateValue(compType, release_summary_id)
{
		 def updateValues = ""
        for(def colCounter=0;colCounter<DBDetails.size();colCounter++)
             { 
                   if(!(DBDetails[colCounter]["columnUserValue"]).equals(DBDetails[colCounter]["columnDBValue"]))
                   {
                        updateValues += DBDetails[colCounter]["columnName"] + "= '" + DBDetails[colCounter]["columnUserValue"] + "', ";
                    }
             }
         if(updateValues == "")
         {
            println("Error : No details updated. User has not changed any values")
            currentBuild.result = 'FAILURE'
            return "User didnt change any value"
         }
        displayDebug('updateValue',updateValues)
        
        def user = currentBuild.getRawBuild().getCauses()[0].getUserId()
        println("DEBUG: User -->" + user)
    
        strQuery = "update CICD_RELEASE_SUMMARY SET " + updateValues + " MODIFIED_ON=sysdate, MODIFIED_BY='$user' where  COMPONENT_TYPE = '" + compType + "' and RELEASE_SUMMARY_ID = '"  + release_summary_id + "'"
        displayDebug("updateColumnValue", strQuery)
        response = myExecUpdateQuery(strQuery);
        return response
}

def getColumnNames()
{
    def columnNames = ""
    for(def colCounter=0;colCounter<DBDetails.size();colCounter++)
         { 
               columnNames += DBDetails[colCounter]["columnName"];
               if(colCounter != DBDetails.size() -1)
                {
                    columnNames += ", ";
                }
         }
    displayDebug('getColumnNames',columnNames)
    return columnNames;
}

def getChangedColumnNames()
{
    def columnNames = ""
    for(def colCounter=0;colCounter<DBDetails.size();colCounter++)
         { 
               if(DBDetails[colCounter]["columnName"] != DBDetails[colCounter]["columnName"])
               {
                   columnNames += DBDetails[colCounter]["columnName"];
                   columnNames += ", ";                   
                }
         }
    if(columnNames == "")
            throw error 
    else
        columnNames = columnNames.substring(0, columnNames.length()-2)
    displayDebug('getChangedColumnNames',columnNames)
    return columnNames;
}

def getUpdatedRecords()
{
    emailBody = ""
    for(def colCounter=0;colCounter<DBDetails.size();colCounter++)
         { 
               if(DBDetails[colCounter]["columnDBValue"] != DBDetails[colCounter]["columnUserValue"])
               {
                   emailBody += "<tr>"
                   emailBody += "<td>" + DBDetails[colCounter]["columnName"] + "</td>"
                   emailBody += "<td>" + DBDetails[colCounter]["columnDBValue"] + "</td>"
                   emailBody += "<td>" + DBDetails[colCounter]["columnUserValue"] + "</td>"
                   emailBody += "</tr>"
                }
         }
     if(emailBody == "")
            emailBody = "No values updated by the user"
     else
            {
            emailHead = """
                            <style type="text/css">
                                .tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
                                .tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;width:150px;word-break:break-all;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
                                .tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:break-all;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
                                .tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
                                .tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
                                .tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
                                .tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
                                .tg .tg-0lax{text-align:left;vertical-align:top}
                                .tg .tg-pass{background-color:lightgreen;text-align:left;vertical-align:top}
                                .tg .tg-fail{background-color:red;text-align:left;vertical-align:top}
                                .tg .tg-notstarted{background-color:lightgrey;text-align:left;vertical-align:top}
                                .tg .tg-notrequired{background-color:#E1E0A2;text-align:left;vertical-align:top}
                            </style>
                         """
            emailBody = "<table class='tg' style='undefined;table-layout: fixed; width:100%'><tr><th>COLUMN_NAME</th><th>OLD_VALUE</th><th>NEW_VALUE</th></tr>" + emailBody + "</table>"
            emailBody = emailHead +  emailBody
            }
    def user = currentBuild.getRawBuild().getCauses()[0].getUserId()
    emailBody += "<BR><BR> Values Edited by ${user} for RELEASE_SUMMARY_ID - ${params.RELEASE_SUMMARY_ID}"
    return emailBody
}


DBDetails = []
dev_mailRecipients = "${params.BUILD_REQUESTER}"
     
       
pipeline {
agent any

options {
     timeout(time: 6, unit: 'DAYS')
}

	stages {
		
        stage('PREPARATION') {
			steps {
                script {
                
                        preparation_function()
                        
                        echo "Release Number is: ${params.RELEASE_NO}"
                        echo "Component Type is: ${params.COMPONENT_TYPE}"
                        echo "RELEASE_SUMMARY_ID is: ${params.RELEASE_SUMMARY_ID}"                
                }//script
            }//steps
         }//stage
        
        
        
        stage('Enter Value') {
			steps {
                script {
                        
                        row = getDBColumnValues(params.COMPONENT_TYPE, params.RELEASE_SUMMARY_ID)
                        
                        println("No of Rows fetched -->" + row.size())
                        
                        if(row.size() == 0)
                        {
                            println("No records to fetch. Check RELEASE_SUMMARY_ID ")
                            error("Cant identify a record to edit. Check RELEASE_SUMMARY_ID and COMPONENT_TYPE combination")
                            currentBuild.result = 'FAILURE'
                        }                                                
                        
                        def cname = ""
                        for(def colCounter=0;colCounter<DBDetails.size();colCounter++)
                        { 
                               cName = DBDetails[colCounter]["columnName"];
                               DBDetails[colCounter]["columnDBValue"] = (row[cName] != null ) ? row[cName].toString() : ""                       
                         }
                    
                                            
                    def userInput = input(
                    id:'userInput',message:"Enter the New values for RELEASE_SUMMARY_ID - ${params.RELEASE_SUMMARY_ID}",
                parameters: [
                [$class: 'TextParameterDefinition',defaultValue:DBDetails[0]['columnDBValue'],description:DBDetails[0]['Comment'],name:DBDetails[0]['columnName']],
                [$class: 'TextParameterDefinition',defaultValue:DBDetails[1]['columnDBValue'],description:DBDetails[1]['Comment'],name:DBDetails[1]['columnName']],
                [$class: 'TextParameterDefinition',defaultValue:DBDetails[2]['columnDBValue'],description:DBDetails[2]['Comment'],name:DBDetails[2]['columnName']],
                [$class: 'TextParameterDefinition',defaultValue:DBDetails[3]['columnDBValue'],description:DBDetails[3]['Comment'],name:DBDetails[3]['columnName']],
                [$class: 'TextParameterDefinition',defaultValue:DBDetails[4]['columnDBValue'],description:DBDetails[4]['Comment'],name:DBDetails[4]['columnName']],
                [$class: 'TextParameterDefinition',defaultValue:DBDetails[5]['columnDBValue'],description:DBDetails[5]['Comment'],name:DBDetails[5]['columnName']],
                [$class: 'TextParameterDefinition',defaultValue:DBDetails[6]['columnDBValue'],description:DBDetails[6]['Comment'],name:DBDetails[6]['columnName']],
                [$class: 'TextParameterDefinition',defaultValue:DBDetails[7]['columnDBValue'],description:DBDetails[7]['Comment'],name:DBDetails[7]['columnName']],
                [$class: 'TextParameterDefinition',defaultValue:DBDetails[8]['columnDBValue'],description:DBDetails[8]['Comment'],name:DBDetails[8]['columnName']],
                [$class: 'TextParameterDefinition',defaultValue:DBDetails[9]['columnDBValue'],description:DBDetails[9]['Comment'],name:DBDetails[9]['columnName']],
                [$class: 'TextParameterDefinition',defaultValue:DBDetails[10]['columnDBValue'],description:DBDetails[10]['Comment'],name:DBDetails[10]['columnName']],
                [$class: 'TextParameterDefinition',defaultValue:DBDetails[11]['columnDBValue'],description:DBDetails[11]['Comment'],name:DBDetails[11]['columnName']],
                [$class: 'TextParameterDefinition',defaultValue:DBDetails[12]['columnDBValue'],description:DBDetails[12]['Comment'],name:DBDetails[12]['columnName']],
                [$class: 'TextParameterDefinition',defaultValue:DBDetails[13]['columnDBValue'],description:DBDetails[13]['Comment'],name:DBDetails[13]['columnName']],
                [$class: 'TextParameterDefinition',defaultValue:DBDetails[14]['columnDBValue'],description:DBDetails[14]['Comment'],name:DBDetails[14]['columnName']],
                [$class: 'TextParameterDefinition',defaultValue:DBDetails[15]['columnDBValue'],description:DBDetails[15]['Comment'],name:DBDetails[15]['columnName']],
                [$class: 'ChoiceParameterDefinition',choices:[DBDetails[16]['columnDBValue'],'Active','Descope'],description:DBDetails[16]['Comment'],name:DBDetails[16]['columnName']]
                              
                    ])

                for(def colCounter=0;colCounter<DBDetails.size();colCounter++)
                { 
                       cName = DBDetails[colCounter]["columnName"];
                       DBDetails[colCounter]["columnUserValue"]  = userInput[cName];                 
                 }     
                }//script
            }//steps
        }//stage
        
        stage('VALIDATION') {
			steps {
                script {
                       sh "echo 'Validation'"
                       def isValid= true;
                       for(def colCounter=0;colCounter<DBDetails.size();colCounter++)
                        { 
                              if((DBDetails[colCounter]['columnUserValue'].length()) > (DBDetails[colCounter]['columnSize'].toInteger()))
                                {
                                    isValid= false;
                                    println("Length validation issue for column " + DBDetails[colCounter]['columnName'])
                                    println("Expected -> " + DBDetails[colCounter]['columnSize'] + "Actual -> " + DBDetails[colCounter]['columnUserValue'].length());
                                }
                         }
                         
                         if(!isValid)
                         {
                            println("Validation Not met. So aborting Updating")
                            currentBuild.result = 'FAILURE'
                         }
                         
                }//script
            }//steps
        }//stage
        
        stage('UPDATING') {
			steps {
                script {
                       sh "echo 'UPDATING'"

                       upColumn = "${updateValue(params.COMPONENT_TYPE, params.RELEASE_SUMMARY_ID)}"
                       displayDebug('After Updating Column Value', upColumn)
                }//script
            }//steps
        }//stage
        
        stage('Sending Email') {
			steps {
                script {
                       sh "echo 'Sending EMail'"
                       emailBody = getUpdatedRecords()
                       println(emailBody)
                        emailext mimeType: 'text/html',
                                 subject: "[ReleaseNotes]:${params.RELEASE_SUMMARY_ID}-Updation",
                                 from:"ReleaseNotes_Automation@vodafone.com",
                                 to: "${dev_mailRecipients}",
                                 body: 	"${emailBody}" + "<br>" + 
                                        "<br><br><p><b><font size='5' color='Black'>Release Summary - Edit  <a href='${BUILD_URL}input'>${currentBuild.displayName}</a></font></b></p>" 
                       
                       displayDebug('After Sending Email', '')
                }//script
            }//steps
        }//stage
    
    }//stages
}//pipeline 
