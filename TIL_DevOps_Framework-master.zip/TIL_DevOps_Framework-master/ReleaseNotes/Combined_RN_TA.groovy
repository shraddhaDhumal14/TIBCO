import hudson.tasks.Mailer;
import hudson.model.User;

@NonCPS
def getUserEmail(String id=null) {
    User user = User.getById(id ?: currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId(), false)
    user?.getProperty(Mailer.UserProperty.class).getAddress()
}

@NonCPS
def getBuildUserID(){
    return currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId()
}

def getBuildUserName(){
    return currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserName()
}

def preparation_function(){
    // Initialize parameters to pipeline job.
        buildRequestorMail = getUserEmail(getBuildUserID())
		properties([parameters([
                       string(defaultValue: 'CCS22.2', description: '	*Mandatory. ex. CSS22.2', name: 'RELEASE_NO', trim: true)])])
        
        checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: "*/main"]], doGenerateSubmoduleConfigurations: false, quietOperation: true, userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: "https://github.vodafone.com/VFUK-INTEGRATION/TIL_Devops_Java_Automation.git"]]]       

}

BUILD_DATE = ""
buildRequestorMail = ""

pipeline {
agent any
stages {
    stage('Preparation') {
        steps {
            script{
                deleteDir()
                preparation_function()
                  
                 }       				
			}			
		}//stage Preparation
                                
    

    stage('Release Notes Excel') {
			steps {
                script {
                
                    try {
                        sh "echo '******* Compiling JAVA Files **********'"
                        excelFileName="VFUK_TIL-RIG_${params.RELEASE_NO}_ReleaseNote_V1.0.xlsx"
                        sh "javac -cp './excelJars/*' getDBResult.java Combined_prodRN.java"
                        sh "java -cp \$(for i in excelJars/*.jar ; do echo -n \$i: ; done). -DFileName='${excelFileName}' -DDeveloper='${getBuildUserName()}' Combined_prodRN ${params.RELEASE_NO}"
                    }
                    catch (error) {
                        println("Build failed while preparing Prod RN - ${error}" )
                        println(error.getStackTrace().toString())
                        errorDescription=error;
                        currentBuild.result = 'FAILURE'
                        return
                    }
                }//script
            }//steps
    }//stage  

    stage('TA Sheet') {
			steps {
                script {
                
                    try {
                        sh "echo '******* Compiling JAVA Files **********'"
                        excelFileName="VFUK_TIL-RIG_${params.RELEASE_NO}_TA_Sheet_V1.0.xlsx"
                        sh "javac -cp './excelJars/*' getDBResult.java TASheet_Combined.java"
                        sh "java -cp \$(for i in excelJars/*.jar ; do echo -n \$i: ; done). -DFileName='${excelFileName}' -DDeveloper='${getBuildUserName()}' TASheet_Combined ${params.RELEASE_NO}"
                    }
                    catch (error) {
                        println("Build failed while preparing Prod RN - ${error}" )
                        println(error.getStackTrace().toString())
                        errorDescription=error;
                        currentBuild.result = 'FAILURE'
                        return
                    }
                }//script
            }//steps
    }//stage    
       
        stage('Send Email') {
            steps{
                script{
                emailBody = "Documents created for the release ${env.RELEASE_NO} - dated ${BUILD_DATE}"
                emailext mimeType: 'text/html', attachmentsPattern: "*.xlsx,*.docx",
                                 subject: "[ReleaseNotes]:${env.RELEASE_NO}",
                                 from:"ReleaseNotes_Automation@vodafone.com",
                                 to: "${buildRequestorMail}",
                                 body: 	"${emailBody}" + "<br>" + 
                                        "<br><br><p><b><font size='5' color='Black'>Release Document  <a href='${BUILD_URL}input'>${currentBuild.displayName}</a></font></b></p>"
                println("Sending a mail with Attachment");
                }
            }
        }
        
    }//stages	
}//pipeline
