def call(Map deployParams=[:]) {
		currentBuild.result = 'ABORTED'
		log.error(deployParams.msg)
		error(deployParams.msg)
}