def call(Map deployParams=[:]) {
		def validationCheck = ""
		//1. Validate RELEASE parameter
		if(deployParams.containsKey('RELEASE')) {
			String regex = /(^CCS\d+\.\d+_[a-zA-Z0-9]+$)|(^CCS\d+\.\d+$)/
			if(deployParams.RELEASE == ""){
				log.error("Release is mandatory for Delivery Pipeline")
				validationCheck = "F"
			}
			if (deployParams.RELEASE.indexOf(' ') != -1){
				log.error('RELEASE parameter should not contain spaces in between')
				validationCheck = "F"
			}
			if (!(deployParams.RELEASE ==~ regex)){
				log.error('RELEASE parameter is not in standard format. Please input either in CCS20.12 or CCS20.12_xx format')
				validationCheck = "F"
			}			
			
		}
		
		//2. Validate CRQ number
		if(deployParams.containsKey('CRQ')) {
			if(deployParams.CRQ == ""){
				log.error("CRQ Number should be specified for the Deployment")
				validationCheck = "F"
			}
			if (deployParams.CRQ.indexOf(' ') != -1){
				log.error('CRQ parameter should not contain spaces in between')
				validationCheck = "F"
			}			
		}
		
		//3. Validate Description parameter.
		if(deployParams.containsKey('DESCRIPTION')) {
			if(deployParams.DESCRIPTION == ""){
				log.error("DESCRIPTION parameter to be specified for the Deployment")
				validationCheck = "F"
			}
		}	
		//4. Validate BUILD_REQUESTER parameter.
		if(deployParams.containsKey('BUILD_REQUESTER')) {
			if(! deployParams.BUILD_REQUESTER.matches('^[a-zA-Z0-9._%+-]+@vodafone.com$')){
				log.error("Please enter Valid email ID for Build Requester")
				validationCheck = "F"
			}
		}
		
		//5. Validate Description parameter.
		if(deployParams.containsKey('OPERATION_NAME')) {
			if(deployParams.OPERATION_NAME == ""){
				log.error("OPERATION_NAME parameter to be specified for the Deployment")
				validationCheck = "F"
			}
		}
		
		//6. Validate BW VERSION belongs to RELEASE or not.
		if(deployParams.containsKey('BW_VERSION') && deployParams.containsKey('RELEASE')) {
			if (deployParams.RELEASE.split('CCS')[1].split('_').join(".") != deployParams.BW_VERSION.split('_').init().join(".")){
				log.error("BW_VERSION should belong to Release Number provided")
				validationCheck = "F"
			}
		}

		//7. Validate EMS VERSION belongs to RELEASE or not.
		if(deployParams.containsKey('EMS_VERSION') && deployParams.containsKey('RELEASE')) {
			if (deployParams.RELEASE.split('CCS')[1].split('_').join(".") != deployParams.EMS_VERSION.split('_').init().join(".")){
				log.error("EMS_VERSION should belong to Release Number provided")
				validationCheck = "F"
			}
		}
		
		//8. Validate SQL VERSION belongs to RELEASE or not.
		if(deployParams.containsKey('SQL_VERSION') && deployParams.containsKey('RELEASE')) {
			if (deployParams.RELEASE.split('CCS')[1].split('_').join(".") != deployParams.SQL_VERSION.split('_').init().join(".")){
				log.error("SQL_VERSION should belong to Release Number provided")
				validationCheck = "F"
			}
		}
		
		if(validationCheck == "F"){
			failPipeline msg: "Pipeline Input parameter validation failed. Please check the errors in Console log."
		}
}