def info(message) {
	BLUE = '\033[0;34m'
	NC = '\033[0m'
	ansiColor('xterm') {
		echo "${BLUE}INFO: ${message} ${NC}"
	}
}

def warning(message) {
	YELLOW = '\033[0;43m'
	NC = '\033[0m'
	ansiColor('xterm') {
		echo "${YELLOW}WARNING: ${message} ${NC}"
	}
}

def error(message) {
	RED = '\033[0;31m'
	NC = '\033[0m'
	ansiColor('xterm') {
		echo "${RED}ERROR: ${message} ${NC}"
	}
}

def debug(message) {
	CYAN = '\033[0;33m'
	NC = '\033[0m'
	ansiColor('xterm') {
		echo "${CYAN}DEBUG: ${message} ${NC}"
	}
}