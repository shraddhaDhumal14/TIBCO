import hudson.tasks.Mailer;
import hudson.model.User;

@NonCPS
def getUserEmail(String id=null) {
    User user = User.getById(id ?: currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId(), false)
    user?.getProperty(Mailer.UserProperty.class).getAddress()
}

@NonCPS
def getBuildUserID(){
    return currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId()
}

def getBuildUserName(){
    return currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserName()
}

def get_approvers_list(String approver_group){
	approvers_list = sh (script: """cat /opt/tibco/.jenkins/config.xml | sed -n \'/role name=\"${approver_group}\"/,\$p\' | sed \'/role>/q\' | grep "sid" | cut -d \'>\' -f 2 | cut -d \'<\' -f 1 | paste -s -d, -""", returnStdout: true).trim()
    return """${approvers_list}"""           
}

def get_approvers_email_list(String approvers_list){
   approvers_email=""
	approvers_list.split(',').each { user ->
            println(user)
            if(approvers_email.length() != 0)
              {
                    approvers_email += ","
              }
              approvers_email += getUserEmail(user) 
              println(approvers_email)              
        }
    return """${approvers_email}"""   
}

@NonCPS
def checkExecutors()
{
    final jenkins = Jenkins.instance
        int busyCounter =0, oldCounter=0
        def jobMap = [:]
        for (def computer in jenkins.computers)
        {
                       for (def exec in computer.executors)
                 {
                   if(exec.isBusy())
                      {
                        jobMap.put(exec.executable.getDisplayName(), exec.getTimestampString())                
                        if (exec.getTimestampString().contains("mo"))
                        {
                              oldCounter += 1
                              //days = ((exec.getTimestampString().split(" ")[0] as int) * 30) + (exec.getTimestampString().split(" ")[2] as int)
                              //jobMap.put(exec.executable.getDisplayName(), days)
                              //println(exec.getTimestampString() +"-->" + exec.executable.getDisplayName() + "  Exec No :" +  exec.executable.getNumber()) 
                        }
                        busyCounter +=1
                      }
                 }
        }
        println(jobMap)
        jobMap = jobMap.sort {a, b -> b.value <=> a.value}
        emailBody = ""
        println(jobMap)
        jobMap.each { key, value -> 
                   emailBody += "<tr>"
                   emailBody += "<td>" + value + "</td>"
                   try
                   {
                       row = ""
                       row += "<td colspan='8'>" + key.toString().split("CCS")[0].split('»') + "</td>"
                       row += "<td colspan='8'>" + "CCS" + key.toString().split("CCS")[1] + "</td>"
                       emailBody += row
                   }
                   catch(Exception ex)
                   {
                      emailBody += "<td colspan='16'>" + key.toString() +"</td>"
                   }
                   emailBody += "</tr>"
                   //println value + "days##" + key.toString().split("CCS")[0].split('»') + "##CCS" + key.toString().split("CCS")[1]
                }
if(emailBody != "")
{
     emailHead = """
                            <style type="text/css">
                                .tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
                                .tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;width:150px;word-break:break-all;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
                                .tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:break-all;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
                                .tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
                                .tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
                                .tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
                                .tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
                                .tg .tg-0lax{text-align:left;vertical-align:top}
                                .tg .tg-pass{background-color:lightgreen;text-align:left;vertical-align:top}
                                .tg .tg-fail{background-color:red;text-align:left;vertical-align:top}
                                .tg .tg-notstarted{background-color:lightgrey;text-align:left;vertical-align:top}
                                .tg .tg-notrequired{background-color:#E1E0A2;text-align:left;vertical-align:top}
                            </style>
                         """
    emailBody = "<table class='tg' style='undefined;table-layout: fixed; width:100%'><tr><th>Days</th><th colspan='16'>Job Name</th></tr>" + emailBody + "</table>"
            emailBody = emailHead +  emailBody
            emailBody += "Running Jobs ${oldCounter}/${busyCounter}"
      
      

    emailext mimeType: 'text/html',
         subject: "[Jenkins]:Executors Report",
         from:"Jenkins_Automation@vodafone.com",
         to: "${mailRecipients}",
         body: 	"${emailBody}" + "<br>" + 
                "<br><br><p><b><font size='5' color='Black'>Executor Report  <a href='${BUILD_URL}input'>${currentBuild.displayName}</a></font></b></p>" 
}

println("Running Jobs ${oldCounter}/${busyCounter}")
//println(emailBody)

}

mailRecipients = ""

pipeline{
agent any
	stages {
		stage ('Executors') {
			steps {
				script {
                    DevopsUsers = get_approvers_list('DevOpsUsers')
                    mailRecipients = get_approvers_email_list(DevopsUsers);  
                    checkExecutors()
                    }
			}
		}
     }
}
