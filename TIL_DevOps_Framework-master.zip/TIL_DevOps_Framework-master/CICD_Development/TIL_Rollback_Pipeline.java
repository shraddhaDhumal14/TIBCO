import groovy.json.JsonOutput
import groovy.sql.*
import java.sql.Driver

def trigger_rollback_versions_email(deployParams){
	// This function is to trigger an email for the provided map.
	emailext mimeType: 'text/html',
	 subject: "[Jenkins]: Rollback Engines Version Summary",
	 from:"CICD_RollbackStatus@vodafone.com",
	 to: "${mailRecipients}",
	 body: 	"${get_Rollback_versions_summary map: deployParams.map, REPORT_STAGE: deployParams.REPORT_STAGE, Target_Env: deployParams.environment}" 
}

def trigger_rollback_results_email(deployParams){
	// This function is to trigger an email for the provided map.
	emailext mimeType: 'text/html',
	subject: "[Jenkins]: ${currentBuild.fullDisplayName}  - " + "Rollback Pipeline Results Summary",
	from:"CICD_RollbackStatus@vodafone.com",
	to: "${mailRecipients}",
	body: 	"${get_Rollback_results_email_summary map: deployParams.map, REPORT_STAGE: deployParams.REPORT_STAGE}" 
}


def insert_rollback_row(deployParams) {
	// This function is to insert row for each engine in status report
	def html_string = ""
	deployParams.map.each { key, value ->
		html_string = html_string + """<tr>"""
		html_string = html_string + """<td class="tg-0lax">${key}</td>"""
		html_string = html_string + """<td class="tg-0lax">${value['BW_VERSION']} -> ${value['BW_RB_VERSION']}  </td>"""
		html_string = html_string + """<td class="tg-0lax">${value['BW_FOLDER_NAME']}</td>"""
		html_string = html_string + """<td class="tg-0lax">${value['BW_ENGINE_TYPE']}</td>"""
		html_string = html_string + """<td class="tg-0lax">${value['SQL_VERSION']} -> ${value['SQL_RB_VERSION']}</td>"""
		html_string = html_string + """<td class="tg-0lax">${value['EMS_VERSION']} -> ${value['EMS_RB_VERSION']}</td>"""
		html_string = html_string + """<td style="max-width:125px;" class="tg-0lax">${value['XML_FILES']}</td>"""
		html_string = html_string + """<td style="max-width:125px;" class="tg-0lax">${value['JAR_FILES']}</td>"""
		html_string = html_string + """<td style="max-width:125px;" class="tg-0lax">${value['EMAIL_FILES']}</td>"""
        html_string = html_string + """<td style="max-width:125px;" class="tg-0lax">${value['BWConfigTag']} --> ${value['BWConfigTag_RB']}</td>"""
		html_string = html_string + """</tr>"""
	}
	return html_string
}

def insert_rollback_result_row(deployParams) {
	// This function is to insert row for each engine in status report
	def html_string = ""
	deployParams.map.each { key, value ->
		html_string = html_string + """<tr>"""
		html_string = html_string + """<td class="tg-0lax">${key}</td>"""
		html_string = html_string + """<td class="tg-${value['BW_Generation']}">${value['BW_Generation']}</td>"""
		html_string = html_string + """<td class="tg-${value['SQL_Rollback']}">${value['SQL_Rollback']}</td>"""
		html_string = html_string + """<td class="tg-${value['EMS_Rollback']}">${value['EMS_Rollback']}</td>"""
		html_string = html_string + """<td class="tg-${value['XML_Rollback']}">${value['XML_Rollback']}</td>"""
		html_string = html_string + """<td class="tg-${value['JAR_Rollback']}">${value['JAR_Rollback']}</td>"""
		html_string = html_string + """<td class="tg-${value['EMAIL_Rollback']}">${value['EMAIL_Rollback']}</td>"""
		html_string = html_string + """<td class="tg-${value['BW_Rollback']}">${value['BW_Rollback']}</td>"""
		html_string = html_string + """<td class="tg-${value['BW_Restart']}">${value['BW_Restart']}</td>"""
		html_string = html_string + """<td class="tg-${value['RESULT']}">${value['RESULT']}</td>"""
		html_string = html_string + """</tr>"""
	}
	return html_string
}

/* Function to generate Results email summary*/


def get_Rollback_results_email_summary(deployParams){
	def date_format_report = new Date().format("dd/MM/yyy HH:mm")
	def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;width:150px;word-break:break-all;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
		.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:break-all;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		.tg .tg-PASSED{background-color:lightgreen;text-align:left;vertical-align:top}
		.tg .tg-FAILED{background-color:red;text-align:left;vertical-align:top}
		.tg .tg-NOT_STARTED{background-color:lightgrey;text-align:left;vertical-align:top}
		.tg .tg-NOT_REQUIRED{background-color:#E1E0A2;text-align:left;vertical-align:top}
		</style>
		<table class="tg" style="undefined;table-layout: fixed; width: 100%"">
		<colgroup>
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		</colgroup>
		  <tr>
			<th class="tg-amwm" colspan="9">BUILD SUMMARY</th>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">Submitted By</td>
			<td class="tg-0lax" colspan="3">${currentBuild.getRawBuild().getCauses()[0].getUserId()}</td>
			<td class="tg-1wig" colspan="2">Date</td>
			<td class="tg-0lax" colspan="2">${date_format_report}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">BUILD_DESCRIPTION</td>
			<td class="tg-0lax" colspan="7">${params.Description}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">BUILD_URL</td>
			<td class="tg-0lax" colspan="7">${BUILD_URL}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">REPORT_STAGE</td>
			<td class="tg-0lax" colspan="7">${deployParams.REPORT_STAGE}</td>			
		  </tr>
		  <tr>
		</table>
		<br><br><br>
		<table class="tg" style="undefined;table-layout: fixed; width: 100%"">
		<colgroup>
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		</colgroup>
		  <tr>
			<td class="tg-1wig" colspan="2">LOG_URL</td>
			<td class="tg-0lax" colspan="7">${BUILD_URL}/console</td>
		  </tr>
		</table>
		<br><br><br>
		<table class="tg" style="undefined;table-layout: fixed; width: 100%"">
		<colgroup>
		<col style="width: 520px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		</colgroup>
		<colgroup>
		<tr>
			<th class="tg-amwm" colspan="1">ENGINE_NAME</td>
			<th class="tg-amwm" colspan="1">BW_Generation</td>
			<th class="tg-amwm" colspan="1">SQL_Rollback</td>
			<th class="tg-amwm" colspan="1">EMS_Rollback</td>
			<th class="tg-amwm" colspan="1">XML_Rollback</td>
			<th class="tg-amwm" colspan="1">JAR_Rollback</td>
			<th class="tg-amwm" colspan="1">EMAIL_Rollback</td>
			<th class="tg-amwm" colspan="1">BW_Rollback</td>
			<th class="tg-amwm" colspan="1">BW_Restart</td>
			<th class="tg-amwm" colspan="1">RESULT</td>
		</tr>
		</colgroup>
  		  ${insert_rollback_result_row map: deployParams.map}	
		</table>
	"""
	emailBody = body_build_summary
	return body_build_summary
}

/* Function to generate Email Build Summary*/
def get_Rollback_versions_summary(deployParams){
	def date_format_report = new Date().format("dd/MM/yyy HH:mm")
	def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;width:150px;word-break:break-all;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
		.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:break-all;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		.tg .tg-PASSED{background-color:lightgreen;text-align:left;vertical-align:top}
		.tg .tg-FAILED{background-color:red;text-align:left;vertical-align:top}
		.tg .tg-NOT_STARTED{background-color:lightgrey;text-align:left;vertical-align:top}
		.tg .tg-NOT_REQUIRED{background-color:#E1E0A2;text-align:left;vertical-align:top}
		</style>
		<table class="tg" style="undefined;table-layout: fixed; width: 100%"">
		<colgroup>
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		</colgroup>
		  <tr>
			<th class="tg-amwm" colspan="9">ROLLBACK ENGINES & VERSIONS SUMMARY </th>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">Submitted By</td>
			<td class="tg-0lax" colspan="3">${currentBuild.getRawBuild().getCauses()[0].getUserId()}</td>
			<td class="tg-1wig" colspan="2">Date</td>
			<td class="tg-0lax" colspan="2">${date_format_report}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">BUILD_DESCRIPTION</td>
			<td class="tg-0lax" colspan="3">${params.Description}</td>
			<td class="tg-1wig" colspan="2">TARGET ENVIRONMENT</td>
			<td class="tg-0lax" colspan="2">${deployParams.Target_Env}</td>			
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">BUILD_URL</td>
			<td class="tg-0lax" colspan="7">${BUILD_URL}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">REPORT_STAGE</td>
			<td class="tg-0lax" colspan="7">${deployParams.REPORT_STAGE}</td>
		  </tr>
		  <tr>
		</table>
		<br><br><br>
		<table class="tg" style="undefined;table-layout: fixed; width: 100%"">
		<colgroup>
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		<col style="width: 90px">
		</colgroup>
		  <tr>
			<td class="tg-1wig" colspan="2">LOG_URL</td>
			<td class="tg-0lax" colspan="7">${BUILD_URL}/console</td>
		  </tr>
		</table>
		<br><br><br>
		<table class="tg" style="undefined;table-layout: fixed; width: 100%"">
		<colgroup>
		<col style="width: 20%">
		<col style="width: 5%">
		<col style="width: 5%">
		<col style="width: 5%">
		<col style="width: 5%">
		<col style="width: 5%">
		<col style="width: 20%">
		<col style="width: 20%">
		<col style="width: 15%">
		</colgroup>
		<colgroup>
		<tr>
			<th class="tg-amwm" colspan="1">ENGINE_NAME</td>
			<th class="tg-amwm" colspan="1">BW_VERSION</td>
			<th class="tg-amwm" colspan="1">BW_FOLDER_NAME</td>
			<th class="tg-amwm" colspan="1">BW_DEPLOYMENT_TYPE</td>
			<th class="tg-amwm" colspan="1">SQL_VERSION</td>
			<th class="tg-amwm" colspan="1">EMS_VERSION</td>
			<th class="tg-amwm" colspan="1">XML_FILES</td>
			<th class="tg-amwm" colspan="1">JAR_FILES</td>
			<th class="tg-amwm" colspan="1">EMAIL_FILES</td>
            <th class="tg-amwm" colspan="1">BWConfigTag_RB</td>
		</tr>
		</colgroup>
  		  ${insert_rollback_row map: deployParams.map}	
		</table>
	"""
	emailBody = body_build_summary
	//writeFile file: "${WORKSPACE}/Reports/Upliftment_Summary_Report.html", text: emailBody
	//writeFile file: "/opt/tibco/.jenkins/userContent/Upliftment/${params.Environment}/${RELEASE}/${date_now}/Upliftment_Report.html", text: emailBody 
	//echo "Upliftment Summary : http://195.233.197.150:8080/jenkins/userContent/Upliftment/${params.Environment}/${RELEASE}/${date_now}/Upliftment_Report.html"				
	return body_build_summary
}



/*********************************************************************************************************************
This function will take care of SQL workspace creation and taking backup for the affected tables for rollback pipelines. 
sql_generate()
Input : 
	1. nexus_group_id
	2. nexus_user
	3. nexus_passwd
	4. nexus_repo_id
	5. nexus_url
	6. ROLLBACK_MAP
	7. datetime
	8. crq_no
	9. release
	10. Environment
Output: 
	None. ( Completes SQL deployment prepartion activities and creates back up for all the effected tables in target server.)

*********************************************************************************************************************/

def sql_rollback_generate(deployParams) {
		// Assumption is configuration is checked out in ENV Repository.
		//Checkout Framework Artefacts from automation repository
		checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "SQL_Deploy_${deployParams.Environment}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]

		// Generate SQL current versions string from the map. This will be in format engine1:version1;engine2:version2;engine3:version3
		sql_generate_map = deployParams.map.findAll { it.value['RESULT'] != "FAILED" && it.value['SQL_VERSION'] != "NA" }
		sql_current_map = sql_generate_map.collectEntries {sql_gen_key, sql_gen_value -> [sql_gen_key, sql_gen_value['SQL_VERSION']]}
		String sql_current_versions = mapFunc.convert_map_to_string engine_map:sql_current_map

		println("DEBUG: sql current versions: " + sql_current_versions)
		
		// Generate SQL previous versions string from the map for only engines which has sql current version. This will be in format engine1:version1;engine2:version2;engine3:version3
		sql_generate_rb_map = deployParams.map.findAll { it.value['RESULT'] != "FAILED" && it.value['SQL_VERSION'] != "NA" && it.value['SQL_RB_VERSION'] != "NA" && it.value['SQL_RB_VERSION'].matches(it.value['SQL_VERSION'].split('_').init().join('_') + "_(.*)") }
		String sql_rollback_versions = ""
		if(sql_generate_rb_map.size() != 0){
			sql_rollback_map = sql_generate_rb_map.collectEntries {sql_gen_key, sql_gen_value -> [sql_gen_key, sql_gen_value['SQL_RB_VERSION']]}
			sql_rollback_versions = mapFunc.convert_map_to_string engine_map:sql_rollback_map
		}
		println("DEBUG: sql rollback versions: " + sql_rollback_versions)

		// create folder to store environment config.
		sh "mkdir -p ./SQL_Deploy_${deployParams.Environment}/SQL_Deployment/conf_properties"

		// move Environment Specific SQL Configurations to SQL Deployment Scripts location
		sh "mv ./ENV/SQL_Configuration/${deployParams.Environment}/* ./SQL_Deploy_${deployParams.Environment}/SQL_Deployment/conf_properties"
		
		// Run ansible playbook for SQL Geneartion
		ansiColor('xterm') {
			ansiblePlaybook(playbook: "./SQL_Deploy_${deployParams.Environment}/SQL_Deployment/sql_Rollback_Generate.yml", colorized: true, extras:'', extraVars: [current_versions: sql_current_versions, previous_versions: sql_rollback_versions, host: "${deployParams.Environment}_SQL", repo_group_id: "${deployParams.nexus_group_id}",  repo_user:"${deployParams.nexus_user}", repo_pw:"${deployParams.nexus_passwd}", repo_repo_id:"${deployParams.nexus_repo_id}", repo_url:"${deployParams.nexus_url}", Environment:"${deployParams.Environment}", datetime: "${deployParams.datetime}", CRQ_Num:"${deployParams.crq_no}"])
		}
}


def ems_rollback_generate(deployParams) {
		
		// Assumption is configuration is checked out in ENV Repository.
		//Checkout Framework Artefacts from automation repository
		checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "EMS_Deploy_${deployParams.Environment}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]

		// Generate EMS current versions string from the map. This will be in format engine1:version1;engine2:version2;engine3:version3
		ems_generate_map = deployParams.map.findAll { it.value['RESULT'] != "FAILED" && it.value['EMS_VERSION'] != "NA" }
		ems_current_map = ems_generate_map.collectEntries {ems_gen_key, ems_gen_value -> [ems_gen_key, ems_gen_value['EMS_VERSION']]}
		String ems_current_versions = mapFunc.convert_map_to_string engine_map:ems_current_map		

		// Generate EMS previous versions string from the map for only engines which has ems current version. This will be in format engine1:version1;engine2:version2;engine3:version3
		ems_generate_rb_map = deployParams.map.findAll { it.value['RESULT'] != "FAILED" && it.value['EMS_VERSION'] != "NA" && it.value['EMS_RB_VERSION'] != "NA" && it.value['EMS_RB_VERSION'].matches(it.value['EMS_VERSION'].split('_').init().join('_') + "_(.*)") }
		
		String ems_rollback_versions = ""
		if(ems_generate_rb_map.size() != 0) {
			ems_rollback_map = ems_generate_rb_map.collectEntries {ems_gen_key, ems_gen_value -> [ems_gen_key, ems_gen_value['EMS_RB_VERSION']]}
			ems_rollback_versions = mapFunc.convert_map_to_string engine_map:ems_rollback_map
		}
		println("DEBUG: ems_rollback_versions are: " + ems_rollback_versions)

		// move Environment Specific EMS Configurations to EMS Deployment Scripts location
		sh "mv ./ENV/EMS_Configuration/${deployParams.Environment}/* ./EMS_Deploy_${deployParams.Environment}/EMS_Deployment"
		
		// Run ansible playbook for SQL Geneartion
		ansiColor('xterm') {
			ansiblePlaybook(playbook: "./EMS_Deploy_${deployParams.Environment}/EMS_Deployment/ems_Rollback_Generate.yml", colorized: true, extras:'', extraVars: [current_versions: ems_current_versions, previous_versions: ems_rollback_versions, host: "${deployParams.Environment}_EMS", repo_group_id: "${deployParams.nexus_group_id}",  repo_user:"${deployParams.nexus_user}", repo_pw:"${deployParams.nexus_passwd}", repo_repo_id:"${deployParams.nexus_repo_id}", repo_url:"${deployParams.nexus_url}", Environment:"${deployParams.Environment}", datetime: "${deployParams.datetime}", crq_num:"${deployParams.crq_no}", emsIgnore: "${deployParams.emsIgnore}"])
		}
}


def sql_rollback_deployment_stage(deployParams) {

	// Generate SQL current versions string from the map for only engines which has sql current version. This will be in format engine1:version1;engine2:version2;engine3:version3					
	sql_map = deployParams.map.findAll { it.value['RESULT'] != "FAILED" && it.value['SQL_VERSION'] != "NA" }
	sql_ver_map = sql_map.collectEntries {sql_map_key, sql_map_value -> [sql_map_key, sql_map_value['SQL_VERSION']]}
	String sql_versions = mapFunc.convert_map_to_string engine_map:sql_ver_map
	println("DEBUG:" + sql_versions)

	// Generate SQL previous versions string from the map for only engines which has sql current version. This will be in format engine1:version1;engine2:version2;engine3:version3
	sql_deploy_rb_map = deployParams.map.findAll { it.value['RESULT'] != "FAILED" && it.value['SQL_VERSION'] != "NA" && it.value['SQL_RB_VERSION'] != "NA" && it.value['SQL_RB_VERSION'].matches(it.value['SQL_VERSION'].split('_').init().join('_') + "_(.*)") }

	def sql_rollback_versions = ""
	if(sql_deploy_rb_map.size() != 0) {
		sql_rollback_map = sql_deploy_rb_map.collectEntries {sql_gen_key, sql_gen_value -> [sql_gen_key, sql_gen_value['SQL_RB_VERSION']]}
		sql_rollback_versions = mapFunc.convert_map_to_string engine_map:sql_rollback_map
	}

	ansiColor('xterm') {
		ansiblePlaybook(playbook: "./SQL_Deploy_${deployParams.Environment}/SQL_Deployment/sql_Rollback_Deployment.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Environment}_SQL", repo_group_id: "${deployParams.nexus_group_id}", current_versions: sql_versions, previous_versions: sql_rollback_versions, repo_user:"${deployParams.nexus_user}", repo_pw:"${deployParams.nexus_passwd}", repo_repo_id:"${deployParams.nexus_repo_id}", repo_url:"${deployParams.nexus_url}", Environment:"${deployParams.Environment}", datetime: "${deployParams.datetime}", CRQ_Num:"${deployParams.crq_no}"])
	}

	// Update maps with failed engines
	def sql_failed_path = "${WORKSPACE}/SQL_Deploy_${params.Environment}/SQL_Deployment/sqlDeploy_failure.txt"
	
	// Update maps with failed engines
	def sql_success_path = "${WORKSPACE}/SQL_Deploy_${params.Environment}/SQL_Deployment/sqlDeploy_success.txt"
	
	if(fileExists(sql_success_path)) {
		def sql_success_ouput = readFile("${WORKSPACE}/SQL_Deploy_${params.Environment}/SQL_Deployment/sqlDeploy_success.txt")
		if (sql_success_ouput.size() != 0) {
			 def success_file = new File("${WORKSPACE}/SQL_Deploy_${params.Environment}/SQL_Deployment/sqlDeploy_success.txt")
			 def sql_success_engines_list = success_file.readLines().join(';')
			 mapFunc.update_version_map_result map: deployParams.map, engines: sql_success_engines_list, stage: "SQL_Rollback", status:"PASSED"
			mapFunc.update_version_map_result map: deployParams.map, engines: sql_success_engines_list, stage: "RESULT", status:"PASSED"

		}
	}
	if(fileExists(sql_failed_path)) {
		def sql_failed_ouput = readFile("${WORKSPACE}/SQL_Deploy_${params.Environment}/SQL_Deployment/sqlDeploy_failure.txt")
		if (sql_failed_ouput.size() != 0) {
			 def failed_file = new File("${WORKSPACE}/SQL_Deploy_${params.Environment}/SQL_Deployment/sqlDeploy_failure.txt")
			 def sql_failed_engines_list = failed_file.readLines().join(';')
			 mapFunc.update_version_map_result map: deployParams.map, engines: sql_failed_engines_list, stage: "SQL_Rollback", status:"FAILED"
			 mapFunc.update_version_map_result map: deployParams.map, engines: sql_failed_engines_list, stage: "RESULT", status:"FAILED"

		}
	}					
	echo "SQL_DEPLOYMENT stage completed"
	//trigger_results_email map: VERSIONS_MAP, REPORT_STAGE: "SQL_Deployment"	
	
}

def ems_rollback_deployment_stage(deployParams) {

		// Get list of engines for EMS deployment.
		ems_map = deployParams.map.findAll { it.value['RESULT'] != "FAILED" && it.value['EMS_VERSION'] != "NA" }
		ems_ver_map = ems_map.collectEntries {ems_map_key, ems_map_value -> [ems_map_key, ems_map_value['EMS_VERSION']]}
		String ems_versions = mapFunc.convert_map_to_string engine_map:ems_ver_map

		// Generate SQL previous versions string from the map for only engines which has sql current version. This will be in format engine1:version1;engine2:version2;engine3:version3
		ems_deploy_rb_map = deployParams.map.findAll { it.value['RESULT'] != "FAILED" && it.value['EMS_VERSION'] != "NA" && it.value['EMS_RB_VERSION'] != "NA" && it.value['EMS_RB_VERSION'].matches(it.value['EMS_VERSION'].split('_').init().join('_') + "_(.*)") }
		
		def ems_rollback_versions = ""
		if(ems_deploy_rb_map.size() != 0) {
			ems_rollback_map = ems_deploy_rb_map.collectEntries {ems_gen_key, ems_gen_value -> [ems_gen_key, ems_gen_value['EMS_RB_VERSION']]}
			ems_rollback_versions = mapFunc.convert_map_to_string engine_map: ems_rollback_map
		}

		// Call ems deploy function by providing Environment Details and engines
		ansiColor('xterm') {
			ansiblePlaybook(playbook: "./EMS_Deploy_${deployParams.Environment}/EMS_Deployment/ems_Rollback_Deployment.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Environment}_EMS", current_versions: ems_versions, previous_versions: ems_rollback_versions, datetime: "${deployParams.datetime}", crq_num: "${deployParams.crq_no}", Environment: "${deployParams.Environment}", emsIgnore: "${deployParams.emsIgnore}", rollbackBackup:"${deployParams.rollbackBackup}"])
		}
		
		// Update Maps with Successful engines
		def ems_deployment_success_file = "${WORKSPACE}/EMS_Deploy_${params.Environment}/EMS_Deployment/deploy_success.txt"
		if(fileExists(ems_deployment_success_file)) {
			def ems_deployment_success_ouput = readFile("${WORKSPACE}/EMS_Deploy_${params.Environment}/EMS_Deployment/deploy_success.txt")
			if (ems_deployment_success_ouput.size() != 0) {
				def success_file = new File("${WORKSPACE}/EMS_Deploy_${params.Environment}/EMS_Deployment/deploy_success.txt")
				def ems_success_engines_list = success_file.readLines().join(';')
				mapFunc.update_version_map_result map: deployParams.map, engines: ems_success_engines_list, stage: "EMS_Rollback", status:"PASSED"
				mapFunc.update_version_map_result map: deployParams.map, engines: ems_success_engines_list, stage: "RESULT", status:"PASSED"
			}
		}
		// Update Maps with failed engines
		def ems_deployment_failed_file = "${WORKSPACE}/EMS_Deploy_${params.Environment}/EMS_Deployment/deploy_failure.txt"
		if(fileExists(ems_deployment_failed_file)) {
			def ems_deployment_failed_ouput = readFile("${WORKSPACE}/EMS_Deploy_${params.Environment}/EMS_Deployment/deploy_failure.txt")
			if (ems_deployment_failed_ouput.size() != 0) {
				def failed_file = new File("${WORKSPACE}/EMS_Deploy_${params.Environment}/EMS_Deployment/deploy_failure.txt")
				def ems_failed_engines_list = failed_file.readLines().join(';')
				mapFunc.update_version_map_result map: deployParams.map, engines: ems_failed_engines_list, stage: "EMS_Rollback", status:"FAILED"
				mapFunc.update_version_map_result map: deployParams.map, engines: ems_failed_engines_list, stage: "RESULT", status:"FAILED"
			}
		}					
		//trigger_results_email map: deployParams.map, REPORT_STAGE: "EMS_Rollback"
}
def file_rollback_generate(deployParams){
	// Stage function for file generate.
	
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Environment}_Files_Deploy"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
		
	// Checkout BW Configuration Repository
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Environment}_Files_Config"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_BW_Application_Configuration.git']]]					
	
	// Generate or get files for only rollback, as these needs to be deployed once current files are undeployed.


	// Validate XML files againset GIT for all the files listed in template file.
	def xml_updated_map = deployParams.map.findAll { it.value['RESULT'] != "FAILED" && it.value['XML_FILES'] != "NA" &&  it.value['XML_RB_FILES'] != "NA" }.collectEntries {xml_engine, xml_version -> [xml_engine, xml_version['XML_RB_FILES']]}
	if(xml_updated_map.size() != 0) {
		String xml_engines_failed = ""
		xml_engines_failed = RB_BW_Functions.get_rollback_files Host: "${deployParams.Environment}", Deployment_Type: "XML_Files", map: xml_updated_map, rollback_map: deployParams.map
		echo "DEBUG: xml_engines_failed are: ${xml_engines_failed}"	
		
		//update_version_map_result map: Master_Map, engines: "${BW_Engine_map.keySet().join(';')}", stage: "", status:""
		if(xml_engines_failed){
			mapFunc.update_version_map_result map: deployParams.map, engines: xml_engines_failed, stage: "XML_Rollback", status:"FAILED"
			mapFunc.update_version_map_result map: deployParams.map, engines: xml_engines_failed, stage: "RESULT", status:"FAILED"
		}
	}
	
	// Validate JAR files againset GIT for all the files listed in template file.
	def jar_updated_map = deployParams.map.findAll { it.value['RESULT'] != "FAILED" && it.value['JAR_FILES'] != "NA" && it.value['JAR_RB_FILES'] != "NA"  }.collectEntries {jar_engine, jar_version -> [jar_engine, jar_version['JAR_RB_FILES']]}
	if(jar_updated_map.size() != 0) {
		String jar_engines_failed = ""
		jar_engines_failed = RB_BW_Functions.get_rollback_files Host: "${deployParams.Environment}", Deployment_Type: "JAR_Files", map: jar_updated_map, rollback_map: deployParams.map
		echo "DEBUG: jar_engines_failed are: ${jar_engines_failed}"	
		// Update versions map with status for all the failed engines.
		if(jar_engines_failed){
			mapFunc.update_version_map_result map: deployParams.map, engines: jar_engines_failed, stage: "JAR_Rollback", status:"FAILED"
			mapFunc.update_version_map_result map: deployParams.map, engines: jar_engines_failed, stage: "RESULT", status:"FAILED"
		}
	}

	// Validate EMAIL files againset GIT for all the files listed in template file.
	def email_updated_map = deployParams.map.findAll { it.value['RESULT'] != "FAILED" && it.value['EMAIL_FILES'] != "NA"  && it.value['EMAIL_RB_FILES'] != "NA" }.collectEntries {email_engine, email_version -> [email_engine, email_version['EMAIL_RB_FILES']]}
	if(email_updated_map.size() != 0) {
		String email_engines_failed = ""
		email_engines_failed = RB_BW_Functions.get_rollback_files Host: "${deployParams.Environment}", Deployment_Type: "Email_Template", map: email_updated_map, rollback_map: deployParams.map
		echo "DEBUG: email_engines_failed are: ${email_engines_failed}"	
		// Update versions map with status for all the failed engines.
		if(email_engines_failed){
			mapFunc.update_version_map_result map: deployParams.map, engines: email_engines_failed, stage: "EMAIL_Rollback", status:"FAILED"
			mapFunc.update_version_map_result map: deployParams.map, engines: email_engines_failed, stage: "RESULT", status:"FAILED"
		}
	}
	// trigger result email after this stage
	println("DEBUG: ROLLBACK Map after file generation is: " + deployParams.map)
	//trigger_versions_email map: deployParams.map, REPORT_STAGE: "FILE_GENERATION"
	
}

def file_rollback_deployment_stage(deployParams){
	
	// Identify Engines for XML Rollback as part of Rollback stage.
	xml_rb_map = deployParams.map.findAll { it.value['RESULT'] != "FAILED" && it.value['XML_FILES'] != "NA" }
	if(xml_rb_map.size() != 0) {
		xml_rb_ver_map = xml_rb_map.collectEntries {xml_rb_map_key, xml_rb_map_value -> [xml_rb_map_key, xml_rb_map_value['XML_FILES']]}
		//Defect fixed for the issue observed in staging
		xml_rb_engines = mapFunc.convert_map_to_string engine_map: xml_rb_ver_map		
		FILE_Functions.rollback_files Host: "${deployParams.Environment}", Deployment_Type: "XML_Files", file_snap: xml_rb_engines, crq_no:"${deployParams.crq_no}", datetime:"${deployParams.datetime}" 
		echo "XML Rollback is done."
	} else {
		echo "DEBUG: There are no Engines for XML rollback"
	}	
	
	xml_map = deployParams.map.findAll { it.value['RESULT'] != "FAILED" && it.value['XML_FILES'] != "NA" && it.value['XML_RB_FILES'] != "NA" }
	if(xml_map.size() != 0) {
		
		//deploy the previous files.
		
		xml_ver_map = xml_map.collectEntries {xml_map_key, xml_map_value -> [xml_map_key, xml_map_value['XML_RB_FILES']]}
		//Defect fixed for the issue observed in staging
		xml_engines = mapFunc.convert_map_to_string engine_map: xml_ver_map
		FILE_Functions.deploy_files Host: "${deployParams.Environment}", Deployment_Type: "XML_Files", file_snap: xml_engines, crq_no:"${params.CRQ}", datetime:"${date_now}" 
		echo "XML deployment is done."
		// Update master report map with status for successful engine
		echo "DEBUG: SUCCESSFUL ENGINES FROM XML_DEPLOYMENT: ${xml_ver_map.keySet().join(';')}"
		mapFunc.update_version_map_result map: deployParams.map, engines: "${xml_ver_map.keySet().join(';')}", stage: "XML_Rollback", status:"PASSED"
		mapFunc.update_version_map_result map: deployParams.map, engines: "${xml_ver_map.keySet().join(';')}", stage: "RESULT", status:"PASSED"
	} else {
		echo "DEBUG: There are no Engines for XML File rollback Deployment."
	}
	
	email_rb_map = deployParams.map.findAll { it.value['RESULT'] != "FAILED" && it.value['EMAIL_FILES'] != "NA" }
	if(email_rb_map.size() != 0) {
		email_rb_ver_map = email_rb_map.collectEntries {email_rb_map_key, email_rb_map_value -> [email_rb_map_key, email_rb_map_value['EMAIL_FILES']]}
		//Defect fixed for the issue observed in staging
		email_rb_engines = mapFunc.convert_map_to_string engine_map: email_rb_ver_map		
		FILE_Functions.rollback_files Host: "${deployParams.Environment}", Deployment_Type: "EMAIL_FILES", file_snap: email_rb_engines, crq_no:"${deployParams.crq_no}", datetime:"${deployParams.datetime}" 
		echo "Email Rollback is done."
	} else {
		echo "DEBUG: There are no Engines for Email rollback"
	}	
	
	email_map = deployParams.map.findAll { it.value['RESULT'] != "FAILED" && it.value['EMAIL_FILES'] != "NA" && it.value['EMAIL_RB_FILES'] != "NA" }
	if(email_map.size() != 0) {
		
		//deploy the previous files.
		
		email_ver_map = email_map.collectEntries {email_map_key, email_map_value -> [email_map_key, email_map_value['EMAIL_RB_FILES']]}
		//Defect fixed for the issue observed in staging
		email_engines = mapFunc.convert_map_to_string engine_map: email_ver_map
		FILE_Functions.deploy_files Host: "${deployParams.Environment}", Deployment_Type: "EMAIL_FILES", file_snap: email_engines, crq_no:"${params.CRQ}", datetime:"${date_now}" 
		echo "Email deployment is done."
		// Update master report map with status for successful engine
		echo "DEBUG: SUCCESSFUL ENGINES FROM EMAIL_DEPLOYMENT: ${email_ver_map.keySet().join(';')}"
		mapFunc.update_version_map_result map: deployParams.map, engines: "${email_ver_map.keySet().join(';')}", stage: "EMAIL_Rollback", status:"PASSED"
	} else {
		echo "DEBUG: There are no Engines for Email File rollback Deployment."
	}
    
    jar_rb_map = deployParams.map.findAll { it.value['RESULT'] != "FAILED" && it.value['JAR_FILES'] != "NA" }
	if(jar_rb_map.size() != 0) {
		jar_rb_ver_map = jar_rb_map.collectEntries {jar_rb_map_key, jar_rb_map_value -> [jar_rb_map_key, jar_rb_map_value['JAR_FILES']]}
		//Defect fixed for the issue observed in staging
		jar_rb_map_value = mapFunc.convert_map_to_string engine_map: jar_rb_ver_map		
		FILE_Functions.rollback_files Host: "${deployParams.Environment}", Deployment_Type: "JAR_FILES", file_snap: jar_rb_map_value, crq_no:"${deployParams.crq_no}", datetime:"${deployParams.datetime}" 
		echo "JAR Rollback is done."
	} else {
		echo "DEBUG: There are no Engines for JAR rollback"
	}	
	
	jar_map = deployParams.map.findAll { it.value['RESULT'] != "FAILED" && it.value['JAR_FILES'] != "NA" && it.value['JAR_RB_FILES'] != "NA" }
	if(jar_map.size() != 0) {
		
		//deploy the previous files.
		
		jar_ver_map = jar_map.collectEntries {jar_map_key, jar_map_value -> [jar_map_key, jar_map_value['JAR_RB_FILES']]}
		//Defect fixed for the issue observed in staging
		jar_engines = mapFunc.convert_map_to_string engine_map: jar_ver_map
		FILE_Functions.deploy_files Host: "${deployParams.Environment}", Deployment_Type: "JAR_FILES", file_snap: jar_engines, crq_no:"${params.CRQ}", datetime:"${date_now}" 
		echo "JAR deployment is done."
		// Update master report map with status for successful engine
		echo "DEBUG: SUCCESSFUL ENGINES FROM EMAIL_DEPLOYMENT: ${jar_ver_map.keySet().join(';')}"
		mapFunc.update_version_map_result map: deployParams.map, engines: "${jar_ver_map.keySet().join(';')}", stage: "JAR_Rollback", status:"PASSED"
	} else {
		echo "DEBUG: There are no Engines for Email File rollback Deployment."
	}
	
	//trigger_results_email map: deployParams.map, REPORT_STAGE: "FILE_Deployment"	
}

def bw_rollback_generate(deployParams){
	
	// checkout Release templates repository
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Release_Repo"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: "https://github.vodafone.com/VFUK-INTEGRATION/${deployParams.EnvironmentRepository}"]]]
	
	// Construct Description for engine
	def user = currentBuild.rawBuild.causes[0].userId
	
	//[CICD-519]: Fix to handle special characters in Description part
	String desc = "${deployParams.description}".replaceAll(/(!|"|@|#|\$|%|&|\\/|\(|\)|=|\?)/, /\\$0/)
	desc = desc + "|" + "${user}"		
	
	//Group versios map with groupid and generate bw configuration in target host
	def BW_test_group_maps = deployParams.map.findAll { it.value['RESULT'] != "FAILED" && it.value['BW_RB_VERSION'] != "NA" }
	println("DEBUG: TEST: " + BW_test_group_maps)
	def BW_Deploy_group_maps = deployParams.map.findAll { it.value['RESULT'] != "FAILED" && it.value['BW_RB_VERSION'] != "NA" }.groupBy({ engine -> engine.value['GROUP_ID'] })
	println("DEBUG: map in BW generate function: "+ BW_Deploy_group_maps)

	BW_Deploy_group_maps.each { patteren_string, BW_Deploy_group ->
		eng_ver_map = BW_Deploy_group.collectEntries {bw_engine, bw_version -> [bw_engine, bw_version['BW_RB_VERSION']]}
		String engines_versions = mapFunc.convert_map_to_string engine_map:eng_ver_map
		println("DEBUG:" + engines_versions)
		String engines_list = "${eng_ver_map.keySet().join(';')}"
		println("DEBUG:" + engines_list)
		
		echo "DEBUG: pattern string is: ${patteren_string}"
		if(patteren_string.toString() != "null") {
			BW_type = patteren_string.split('_')[0]
			echo "DEBUG: BW_type is: ${BW_type}"
			BW_Folder = patteren_string.split('_')[1]
			group_id = patteren_string.split('_')[2]
		} else {
			BW_type = "None"
		}
		
		// Get release version from map itself. Because for rollback, versions will be from different releases as well.
		
		
		
		if(BW_type == "Existing"){
			
			println("DEBUG:" + group_id + "Generate conf file for type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list + " and engine version string is: " + engines_versions)
			RB_BW_Functions.generate_conf_files_existing_engines engines:engines_versions, Host: "${deployParams.Environment}", ReleaseNumber: "${deployParams.release}", folderName:BW_Folder, description:"${desc}"
			RB_BW_Functions.generate_bw_deployment Host:"${deployParams.Environment}", nexus_group_id:"${deployParams.nexus_group_id}", nexus_user:"${deployParams.nexus_user}", nexus_passwd:"${deployParams.nexus_passwd}", nexus_repo_id:"${deployParams.nexus_repo_id}", nexus_url:"${deployParams.nexus_url}", crq_no: "${deployParams.crq_no}", engines:engines_versions, datetime: "${deployParams.datetime}", engines_list:engines_list, EnvPrefix:"${deployParams.EnvPrefix}", deployment_type:"EXISTING", release:"${deployParams.release}", onlyGVChange:false, folderName:BW_Folder, bw_folder_release: "${deployParams.bw_release_num}", engine_group:patteren_string
		} else if (BW_type == "RESTART") {
			
			println("DEBUG:" + group_id + "Generate conf file for type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list)
			RB_BW_Functions.generate_conf_files_restart engines:engines_versions, Host: "${deployParams.Environment}", ReleaseNumber: "${deployParams.release}", folderName:BW_Folder, description:"${desc}"
			// Call generate function by passing details
			RB_BW_Functions.generate_bw_restart Host: "${deployParams.Environment}", crq_no: "${deployParams.crq_no}", datetime: "${deployParams.datetime}", engines_list:engines_list, deployment_type:"EXISTING", folderName:BW_Folder, bw_folder_release:"${deployParams.bw_release_num}", engine_group:patteren_string
			
		}else {
			println("DEBUG: Invalid Deployment type Identified. Please fix this issue")
		}
	}
	
	// Update maps with failed engines from BW Generate
	def bw_generate_failed_file = "${WORKSPACE}/${params.Environment}/BW_Deployment/generate_failure.txt"
	if(fileExists(bw_generate_failed_file)) {
		def bw_generate_failed_ouput = readFile("${WORKSPACE}/${params.Environment}/BW_Deployment/generate_failure.txt")
		if (bw_generate_failed_ouput.size() != 0) {
			def failed_file = new File("${WORKSPACE}/${params.Environment}/BW_Deployment/generate_failure.txt")
			def failed_engines_list = failed_file.readLines().join(';')
			mapFunc.update_version_map_result map: deployParams.map, engines: failed_engines_list, stage: "BW_Generation", status:"FAILED"
			mapFunc.update_version_map_result map: deployParams.map, engines: failed_engines_list, stage: "RESULT", status:"FAILED"
		}
	} 

	// Update maps with success engines from BW Generate
	def bw_generate_success_file = "${WORKSPACE}/${params.Environment}/BW_Deployment/generate_success.txt"
	if(fileExists(bw_generate_success_file)) {
		def bw_generate_success_ouput = readFile("${WORKSPACE}/${params.Environment}/BW_Deployment/generate_success.txt")
		if (bw_generate_success_ouput.size() != 0) {
			def success_file = new File("${WORKSPACE}/${params.Environment}/BW_Deployment/generate_success.txt")
			def success_engines_list = success_file.readLines().join(';')
			mapFunc.update_version_map_result map: deployParams.map, engines: success_engines_list, stage: "BW_Generation", status:"PASSED"
			mapFunc.update_version_map_result map: deployParams.map, engines: success_engines_list, stage: "RESULT", status:"PASSED"
		}
	}
	
	// Trigger Result Email
	//trigger_results_email map: deployParams.map, REPORT_STAGE: "BW_Generate"
	println("DEBUG: ROLLBACK_MAP after BW_Generation is: " + deployParams.map)
	
	def userInput = input(
	  id: 'userInput', message: 'Proceed with Deployment?',
	  submitterParameter: 'submitter'
	)
	

}

// Function for RF BW Deployment
def bw_rollback_deployment_stage(deployParams){ 

// First get list of engines failed in earlier stages from which we need to delete BW_Configs
	bw_delete_config = deployParams.map.findAll { it.value['RESULT'] == "FAILED" && it.value['BW_RB_VERSION'] != "NA" }.groupBy({ engine -> engine.value['GROUP_ID'] })
	bw_delete_config.each { patteren_string, BW_Delete_group ->
		// construct folder name, BW_TYpe, group_id and other details from pattern string and call remove config job.
		println("DEBUG: BW Delete Config engines for group:" + patteren_string)
		println("DEBUG:" + BW_Delete_group)
		remove_engines_list = BW_Delete_group.keySet().join(';')
		if(patteren_string.toString() != "null") {
			BW_type = patteren_string.split('_')[0]
			echo "DEBUG: BW_type is: ${BW_type}"
			BW_Folder = patteren_string.split('_')[1]
			group_id = patteren_string.split('_')[2]
			RB_BW_Functions.bw_remove_config Host: "${deployParams.Environment}", crq_no: "${deployParams.crq_no}", datetime: "${deployParams.datetime}", engines_list:"${remove_engines_list}", bw_folder_release: "${deployParams.bw_release_num}", engine_group:patteren_string, folderName:BW_Folder
		
		} else {
			echo "Nothing to remove from config"
		}
	}
	
	echo "DEBUG: Get List of engines for BW Deployment"
		
	//Group versios map with groupid and run deploy step in target host 
	def BW_Deploy_group_maps = deployParams.map.findAll { it.value['RESULT'] != "FAILED" && it.value['BW_RB_VERSION'] != "NA" }.groupBy({ engine -> engine.value['GROUP_ID'] })
	BW_Deploy_group_maps.each { patteren_string, BW_Deploy_group ->
		eng_ver_map = BW_Deploy_group.collectEntries {bw_engine, bw_version -> [bw_engine, bw_version['BW_RB_VERSION']]}
		String engines_versions = mapFunc.convert_map_to_string engine_map:eng_ver_map
		println("DEBUG:" + engines_versions)
		String engines_list = "${eng_ver_map.keySet().join(';')}"
		println("DEBUG:" + engines_list)

		current_eng_ver_map = BW_Deploy_group.collectEntries {bw_engine, bw_version -> [bw_engine, bw_version['BW_VERSION']]}
		String current_engines_versions = mapFunc.convert_map_to_string engine_map:current_eng_ver_map
		println("DEBUG:" + current_engines_versions)
		
		echo "DEBUG: pattern string is: ${patteren_string}"
		if(patteren_string.toString() != "null") {
			BW_type = patteren_string.split('_')[0]
			echo "DEBUG: BW_type is: ${BW_type}"
			BW_Folder = patteren_string.split('_')[1]
			group_id = patteren_string.split('_')[2]
		} else {
			BW_type = "None"
		}
		
		if(BW_type == "Existing"){
						
			println("DEBUG:" + group_id + "Deploy engines of type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list + " and engine version string is: " + engines_versions)
			// Run BW deploy function
			 RB_BW_Functions.bw_deploy Host:"${deployParams.Environment}", crq_no:"${deployParams.crq_no}", engines:engines_versions, current_engines:current_engines_versions, datetime:"${deployParams.datetime}", engines_list:engines_list, appDynamics:false, FolderName:BW_Folder, release:"${deployParams.release}", onlyGVChange:false, deployment_type:"ExistingEngines", bw_folder_release: "${deployParams.bw_release_num}", engine_group:patteren_string, EnvironmentRepository: "${deployParams.EnvironmentRepository}"

		} else {
			println("DEBUG: Invalid Deployment type Identified. Nothing to deploy")
		}

		// Updating maps for failed engines
		
		def bw_deployment_failed_file = "${WORKSPACE}/${params.Environment}/BW_Deployment/deployment_failure.txt"
		if(fileExists(bw_deployment_failed_file)) {
			def bw_deployment_failed_ouput = readFile("${WORKSPACE}/${params.Environment}/BW_Deployment/deployment_failure.txt")
			if (bw_deployment_failed_ouput.size() != 0) {
				def failed_file = new File("${WORKSPACE}/${params.Environment}/BW_Deployment/deployment_failure.txt")
				def failed_engines_list = failed_file.readLines().join(';')
				mapFunc.update_version_map_result map: deployParams.map, engines: failed_engines_list, stage: "BW_Rollback", status:"FAILED"
				mapFunc.update_version_map_result map: deployParams.map, engines: failed_engines_list, stage: "RESULT", status:"FAILED"
			}
		}

	 // Updating maps for engine engines

		def bw_deployment_success_file = "${WORKSPACE}/${params.Environment}/BW_Deployment/deployment_success.txt"
		if(fileExists(bw_deployment_success_file)) {
			def bw_deployment_success_ouput = readFile("${WORKSPACE}/${params.Environment}/BW_Deployment/deployment_success.txt")
			if (bw_deployment_success_ouput.size() != 0) {
				def success_file = new File("${WORKSPACE}/${params.Environment}/BW_Deployment/deployment_success.txt")
				def success_engines_list = success_file.readLines().join(';')
				mapFunc.update_version_map_result map: deployParams.map, engines: success_engines_list, stage: "BW_Rollback", status:"PASSED"
				mapFunc.update_version_map_result map: deployParams.map, engines: success_engines_list, stage: "RESULT", status:"PASSED"
			}
		}
		//trigger_results_email map: deployParams.map, REPORT_STAGE: "${patteren_string}_BW_Deployment"
		//[CICD-340]: Fix. Changed looping and input parameter.
		// Check deployment and hawk status
		println("DEBUG: ROLLBACK_MAP after BW_Rollback is: " + deployParams.map)
		def userInput1 = input(
			  id: 'userInput1', message: "BW Deployment of  Engines in ${patteren_string} are completed.Please validate and proceed for BW Restart",
			  submitterParameter: 'submitter'
			)		

	}
}

// Function for undeploying engines which does not have rollback version.
def bw_rollback_undeployment_stage(deployParams){ 

		//Group versios map with groupid and run deploy step in target host 
		def BW_Undeploy_maps = deployParams.map.findAll { it.value['RESULT'] != "FAILED" && it.value['BW_VERSION'] != "NA" && it.value['BW_RB_VERSION'] == "NA" }
		String engines_list = ""
		BW_Undeploy_maps.each { engine, version -> 
			engines_list = engines_list + version['BW_FOLDER_NAME'] + '/' + engine + ':' + version['BW_VERSION'] + ';'
		}
		engines_list = engines_list.substring(0, engines_list.length() - 1);
		println("DEBUG: undeploy engine string is: " + engines_list)

		// Get domain details from ENV configuration.
		def TRA_HOME = sh(script:"cat ${WORKSPACE}/ENV/BW_Configuration/${params.Environment}/Deployment.properties | grep 'TRA_HOME' | awk -F '=' '{print \$2}'" ,returnStdout: true).trim()
		def Domain = sh(script:"cat ${WORKSPACE}/ENV/BW_Configuration/${params.Environment}/Deployment.properties | grep 'Domain=' | awk -F '=' '{print \$2}'" ,returnStdout: true).trim()
		def DomainUser = sh(script:"cat ${WORKSPACE}/ENV/BW_Configuration/${params.Environment}/Deployment.properties | grep 'DomainUser=' | awk -F '=' '{print \$2}'" ,returnStdout: true).trim()
		def DomainPwd = sh(script:"cat ${WORKSPACE}/ENV/BW_Configuration/${params.Environment}/Deployment.properties | grep 'DomainPwd=' | awk -F '=' '{print \$2}'" ,returnStdout: true).trim()

		ansiColor('xterm') {
			ansiblePlaybook(playbook: "${WORKSPACE}/automation/BW_Undeploy/unDeployEngines.yml", colorized: true, extras:'-v', extraVars: [host: "${deployParams.Environment}_BW", TRA_HOME: TRA_HOME, domainName: Domain, domainUser: DomainUser, domainPW: DomainPwd, engines_list: engines_list, datetime: "${deployParams.datetime}", CRQ_Num: "${deployParams.crq_no}", EnvironmentRepository: "${deployParams.EnvironmentRepository}"])
			// Move generated file to ENV folder.
			def bw_undeploy_success_file = "${WORKSPACE}/automation/BW_Undeploy/deploy_success.txt"
			if(fileExists("${WORKSPACE}/automation/BW_Undeploy/deploy_success.txt")) {
				sh "cat ${WORKSPACE}/automation/BW_Undeploy/deploy_success.txt"
			}
		}

		def bw_undeploy_failed_file = "${WORKSPACE}/automation/BW_Undeploy/undeploy_failure.txt"
		if(fileExists(bw_undeploy_failed_file)) {
			def bw_undeploy_failed_ouput = readFile("${WORKSPACE}/automation/BW_Undeploy/undeploy_failure.txt")
			if (bw_undeploy_failed_ouput.size() != 0) {
				def failed_file = new File("${WORKSPACE}/automation/BW_Undeploy/undeploy_failure.txt")
				def failed_engines_list = failed_file.readLines().join(';')
				mapFunc.update_version_map_result map: deployParams.map, engines: failed_engines_list, stage: "BW_Rollback", status:"FAILED"
				mapFunc.update_version_map_result map: deployParams.map, engines: failed_engines_list, stage: "RESULT", status:"FAILED"
			}
		}

		def bw_undeploy_success_file = "${WORKSPACE}/automation/BW_Undeploy/undeploy_success.txt"
		if(fileExists(bw_undeploy_success_file)) {
			def bw_undeploy_success_ouput = readFile("${WORKSPACE}/automation/BW_Undeploy/undeploy_success.txt")
			if (bw_undeploy_success_ouput.size() != 0) {
				def success_file = new File("${WORKSPACE}/automation/BW_Undeploy/undeploy_success.txt")
				def success_engines_list = success_file.readLines().join(';')
				mapFunc.update_version_map_result map: deployParams.map, engines: success_engines_list, stage: "BW_Rollback", status:"PASSED"
				mapFunc.update_version_map_result map: deployParams.map, engines: success_engines_list, stage: "BW_Restart", status:"PASSED"
				mapFunc.update_version_map_result map: deployParams.map, engines: success_engines_list, stage: "RESULT", status:"PASSED"
			}
		}
}

def bw_rollback_restart_stage(deployParams){ 

	def restartMode = input(
		   message: 'Choose BW Restart Mode',
		   parameters: [
			 [$class: 'ChoiceParameterDefinition',
			  choices: ['Manual','Automation'].join('\n'),
			  name: 'input',
			  description: 'Select Restart Mode']
			])
	if ("$restartMode" == "Automation"){                
					 
		//Group versios map with groupid and run deploy step in target host 
		def BW_Deploy_group_maps = deployParams.map.findAll { it.value['RESULT'] != "FAILED" && it.value['BW_RB_VERSION'] != "NA" }.groupBy({ engine -> engine.value['GROUP_ID'] })
		BW_Deploy_group_maps.each { patteren_string, BW_Deploy_group ->
			eng_ver_map = BW_Deploy_group.collectEntries {bw_engine, bw_version -> [bw_engine, bw_version['BW_RB_VERSION']]}
			String engines_versions = mapFunc.convert_map_to_string engine_map:eng_ver_map
			println("DEBUG:" + engines_versions)
			String engines_list = "${eng_ver_map.keySet().join(';')}"
			println("DEBUG:" + engines_list)
			
			echo "DEBUG: pattern string is: ${patteren_string}"
			if(patteren_string.toString() != "null") {
				BW_type = patteren_string.split('_')[0]
				echo "DEBUG: BW_type is: ${BW_type}"
				BW_Folder = patteren_string.split('_')[1]
				group_id = patteren_string.split('_')[2]
				// Calling Restart Function
				RB_BW_Functions.bw_restart Host: "${deployParams.Environment}", crq_no: "${deployParams.crq_no}", datetime: "${deployParams.datetime}", bw_folder_release: "${deployParams.bw_release_num}", engine_group:patteren_string, folderName:BW_Folder, engines_list_restart:engines_list
			} 
		}
		// Check if BW Restart file exists for Failures
		def bw_restart_failed_file = "${WORKSPACE}/${params.Environment}/BW_Deployment/restart_failure.txt"
		if(fileExists(bw_restart_failed_file)) {
			def bw_restart_failed_ouput = readFile("${WORKSPACE}/${params.Environment}/BW_Deployment/restart_failure.txt")
			if (bw_restart_failed_ouput.size() != 0) {
				// Reading Restart Failure
				def failed_file = new File("${WORKSPACE}/${params.Environment}/BW_Deployment/restart_failure.txt")
				def failed_engines_list = failed_file.readLines().join(';')
				failed_engines_list.split(';').each { bw_engine ->
					if(deployParams.map.containsKey(bw_engine)) {
						deployParams.map[bw_engine]['RESULT'] = "FAILED"
						deployParams.map[bw_engine]['BW_Restart'] = "FAILED"
					}
				}
				
				// Email Restart Faileed Engines
				//trigger_results_email map: ROLLBACK_MAP, REPORT_STAGE: "BW_Restart"
				

				// If any failures with restart ask for User Input
				def rollbackMode = input(
				message: 'Proceed with Rollback for restart failed engines ?',
				parameters: [
				   [$class: 'ChoiceParameterDefinition',
				   choices: ['Yes','No'].join('\n'),
				   name: 'input',
				   description: 'Choose Rollback for restart failed engines']
				])
				   
				if ("$rollbackMode" == "Yes"){
					
					// Taking backup of CRQ for rollback failed engines
					
					def BW_rollback_group_maps_prep = deployParams.map.findAll { it.value['RESULT'] == "FAILED" && it.value['BW_RB_VERSION'] != "NA" }.groupBy({ engine -> engine.value['GROUP_ID'] })
					BW_rollback_group_maps_prep.each { patteren_string_config, BW_Rollback_Config ->
						eng_ver_map_config = BW_Rollback_Config.collectEntries {bw_engine, bw_version -> [bw_engine, bw_version['BW_RB_VERSION']]}
						String engines_versions = mapFunc.convert_map_to_string engine_map:eng_ver_map_config
						println("DEBUG:" + engines_versions)
						String engines_list = "${eng_ver_map_config.keySet().join(';')}"
						println("DEBUG:" + engines_list)
						
						echo "DEBUG: pattern string is: ${patteren_string_config}"
						if(patteren_string_config.toString() != "null") {
							BW_type = patteren_string_config.split('_')[0]
							echo "DEBUG: BW_type is: ${BW_type}"
							BW_Folder = patteren_string_config.split('_')[1]
							group_id = patteren_string_config.split('_')[2]
							// Calling Rollback config generate Function
							RB_BW_Functions.bw_rollback_config_prep Host: "${deployParams.Environment}", crq_no: "${deployParams.crq_no}", datetime: "${deployParams.datetime}", bw_folder_release: "${deployParams.bw_release_num}", engine_group:patteren_string_config, folderName:BW_Folder
					  } 
					}
					
					 // Identifying engines and remove config for rollback 
					def BW_rollback_group_maps_config = deployParams.map.findAll { it.value['RESULT'] != "FAILED" && it.value['BW_RB_VERSION'] != "NA" }.groupBy({ engine -> engine.value['GROUP_ID'] })
					BW_rollback_group_maps_config.each { patteren_string_config, BW_Rollback_Config ->
						eng_ver_map_config = BW_Rollback_Config.collectEntries {bw_engine, bw_version -> [bw_engine, bw_version['BW_RB_VERSION']]}
						String engines_versions = mapFunc.convert_map_to_string engine_map:eng_ver_map_config
						println("DEBUG:" + engines_versions)
						String engines_list = "${eng_ver_map_config.keySet().join(';')}"
						println("DEBUG:" + engines_list)
						
						echo "DEBUG: pattern string is: ${patteren_string_config}"
						if(patteren_string_config.toString() != "null") {
							BW_type = patteren_string_config.split('_')[0]
							echo "DEBUG: BW_type is: ${BW_type}"
							BW_Folder = patteren_string_config.split('_')[1]
							group_id = patteren_string_config.split('_')[2]
							// Calling Rollback config generate Function
							RB_BW_Functions.bw_rollback_config_generate Host: "${deployParams.Environment}", crq_no: "${deployParams.crq_no}", datetime: "${deployParams.datetime}", engines_list: "${engines_list}", removeConfig:true, bw_folder_release:"${deployParams.bw_release_num}", engine_group:patteren_string_config, folderName:BW_Folder
					  } 
					}
				  
					// Identifying engines for rollback 
					def BW_rollback_group_maps = deployParams.map.findAll { it.value['RESULT'] == "FAILED" && it.value['BW_RB_VERSION'] != "NA" }.groupBy({ engine -> engine.value['GROUP_ID'] })
					BW_rollback_group_maps.each { patteren_string, BW_Deploy_group ->
						eng_ver_map = BW_Deploy_group.collectEntries {bw_engine, bw_version -> [bw_engine, bw_version['BW_RB_VERSION']]}
						String engines_versions = mapFunc.convert_map_to_string engine_map:eng_ver_map
						println("DEBUG:" + engines_versions)
						String engines_list = "${eng_ver_map.keySet().join(';')}"
						println("DEBUG:" + engines_list)
						
						echo "DEBUG: pattern string is: ${patteren_string}"
						if(patteren_string.toString() != "null") {
							BW_type = patteren_string.split('_')[0]
							echo "DEBUG: BW_type is: ${BW_type}"
							BW_Folder = patteren_string.split('_')[1]
							group_id = patteren_string.split('_')[2]
							
							//Calling Rollback Function
							 RB_BW_Functions.bw_rollback Host: "${deployParams.Environment}", crq_no: "${deployParams.crq_no}", datetime: "${deployParams.datetime}", bw_folder_release: "${deployParams.bw_release_num}", engine_group:patteren_string, folderName:BW_Folder, EnvironmentRepository: "${deployParams.EnvironmentRepository}", engines_list:engines_list
							
								
						} 
					}
				}
				else {
					echo "Skipped Restart Rollback Based on selection"
					
				}								
			}							
		}
			
		// Reading restart successful engines file 
		def bw_restart_success_file = "${WORKSPACE}/${params.Environment}/BW_Deployment/restart_success.txt"
		if(fileExists(bw_restart_success_file)) {
				def success_file = new File("${WORKSPACE}/${params.Environment}/BW_Deployment/restart_success.txt")
				def success_engines_list = success_file.readLines().join(';')
				println("DEBUG: Restart succes engines are: " + success_engines_list)
				success_engines_list.split(';').each { bw_engine ->
					if(deployParams.map.containsKey(bw_engine)) {
						deployParams.map[bw_engine.trim()]['BW_Restart'] = "PASSED"
						deployParams.map[bw_engine.trim()]['RESULT'] = "PASSED"
					}
				}
				println("DEBUG: ROLLBACK map is: " + deployParams.map)
		}
		
	}
	else{
			
			// Manual Restart Selected
			def BW_restart_manual_maps = deployParams.map.findAll { it.value['RESULT'] != "FAILED" && it.value['BW_RB_VERSION'] != "NA" }.collectEntries {restart_engine, restart_version -> [restart_engine, restart_version['BW_RB_VERSION']]}
			BW_restart_manual_maps.keySet().each { bw_engine ->
				if(deployParams.map.containsKey(bw_engine)) {
					deployParams.map[bw_engine]['BW_Restart'] = "MANUAL"
				}
		   }
		   
		   // Input for manual restart failed engine list

			def failedEngineList = input(
				id: 'failedEngineList',
				message: 'Please Provide list of Engines failed during manual restart separated by ;', 
				parameters: [
							[$class: 'TextParameterDefinition', defaultValue: '', description: 'List of engines failed during manual restart', name: 'failedEngineList'],
				])
				
			if(failedEngineList){	
				
			   // Update maps with manual restart failed engines
			   mapFunc.update_version_map_result map: deployParams.map, engines: failedEngineList, stage: "BW_Restart", status:"FAILED"
			   //CICD-330 - Fix to fail status  
			   mapFunc.update_version_map_result map: deployParams.map, engines: failedEngineList, stage: "RESULT", status:"FAILED"
				//println(ROLLBACK_MAP)
			}

	}
	//CICD-330 - Fix for common sql changes
	if(SQL_Restart_Engines.length() != 0){
		SQL_Restart_Engines.split(';').each { engine ->
			if(deployParams.map[engine]['BW_Restart'] == "FAILED"){
				deployParams.map['Common_SQL_Changes']['RESULT'] == "FAILED"
			}
		}
	}
}

/* def redeploy_rollback_failed_engines(deployParams){

		// Get list of engines for EMS re deployment.
		ems_map = deployParams.map.findAll { it.value['RESULT'] == "FAILED" && it.value['EMS_Rollback'] == "PASSED" }
		ems_ver_map = ems_map.collectEntries {ems_map_key, ems_map_value -> [ems_map_key, ems_map_value['EMS_VERSION']]}
		String ems_versions = mapFunc.convert_map_to_string engine_map:ems_ver_map
		println("DEBUG:" + ems_versions)					
		
		// Call ems deploy function by providing Environment Details and engines
		ansiColor('xterm') {
			ansiblePlaybook(playbook: "./EMS_Deploy_${deployParams.Environment}/EMS_Deployment/deploy.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Environment}_EMS", repo_artifact_ids: ems_versions, datetime: "${deployParams.datetime}", crq_num: "${deployParams.crq_no}", release: "${deployParams.release}", Environment: "${deployParams.Environment}", emsIgnore: "${deployParams.emsIgnore}", rollbackBackup:false])
		} 		
		
		// Get list of engines for SQL re deployment.
		sql_map = deployParams.map.findAll { it.value['RESULT'] == "FAILED" && it.value['SQL_Rollback'] == "PASSED" }
		sql_ver_map = sql_map.collectEntries {sql_map_key, sql_map_value -> [sql_map_key, sql_map_value['SQL_VERSION']]}
		String sql_versions = mapFunc.convert_map_to_string engine_map:sql_ver_map
		println("DEBUG:" + sql_versions)

		// Call sql deploy function by providing environment Details and engines
		ansiColor('xterm') {
			ansiblePlaybook(playbook: "./SQL_Deploy_${deployParams.Environment}/SQL_Deployment/sqlStaging_RF.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Environment}_SQL", repo_group_id: "${deployParams.nexus_sql_group_id}", repo_artifact_ids:sql_versions, repo_user:"${deployParams.nexus_user}", repo_pw:"${deployParams.nexus_passwd}", repo_repo_id:"${deployParams.nexus_repo_id}", repo_url:"${deployParams.nexus_url}", Release:"${deployParams.release}", Environment:"${deployParams.Environment}", datetime: "${deployParams.datetime}", CRQ_Num:"${deployParams.crq_no}"])
		}		
		
		// Identify Engines for XML Re Deployment and proceed with deployment.
		xml_map = deployParams.map.findAll { it.value['RESULT'] == "FAILED" && it.value['XML_Rollback'] == "PASSED" }
		if(xml_map.size() != 0) {
			xml_ver_map = xml_map.collectEntries {xml_map_key, xml_map_value -> [xml_map_key, xml_map_value['XML_FILES']]}
			//Defect fixed for the issue observed in staging
			xml_engines = mapFunc.convert_map_to_string engine_map: xml_ver_map
			FILE_Functions.deploy_files Host:"${deployParams.Environment}", Deployment_Type: "XML_Files", file_snap: xml_engines, crq_no:"${deployParams.crq_no}", "${deployParams.datetime}" 
			echo "XML deployment is done."
		} else {
			echo "DEBUG: There are no Engines for XML File re deployment."
		}

		// Identify Engines for JAR Re Deployment and proceed with deployment.
		jar_map = deployParams.map.findAll { it.value['RESULT'] == "FAILED" && it.value['JAR_Rollback'] == "PASSED" }
		if(jar_map.size() != 0) {
			jar_ver_map = jar_map.collectEntries {jar_map_key, jar_map_value -> [jar_map_key, jar_map_value['JAR_FILES']]}
			jar_engines = mapFunc.convert_map_to_string engine_map: jar_ver_map
			FILE_Functions.deploy_files Host:"${deployParams.Environment}", Deployment_Type: "JAR_Files", file_snap: jar_engines, crq_no:"${deployParams.crq_no}", "${deployParams.datetime}"
			echo "JAR deployment is done."
		} 
		else {
			echo "DEBUG: There are no Engines for JAR File Deployment."
		}
		// Identify Engines for EMAIL Deployment and proceed with deployment.
		email_map = deployParams.map.findAll { it.value['RESULT'] == "FAILED" && it.value['EMAIL_Rollback'] == "PASSED" }
		if(email_map.size() != 0) {
			email_ver_map = email_map.collectEntries {email_map_key, email_map_value -> [email_map_key, email_map_value['EMAIL_FILES']]}
			email_engines = mapFunc.convert_map_to_string engine_map: email_ver_map
			FILE_Functions.deploy_files Host:"${deployParams.Environment}", Deployment_Type: "EMAIL_Files", file_snap: email_engines, crq_no:"${deployParams.crq_no}", "${deployParams.datetime}"
			echo "EMAIL deployment is done."
		} 
		else {
			echo "DEBUG: There are no Engines for EMAIL File Deployment."
		}

} */


def load_groovy_files() {
	// This function is to load all groovy files, where in common functions will be kept.
	emailFunc = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/emailFunctions.groovy"
	mapFunc = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/mapFunctions.groovy"
	nexusFunc = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/nexusFunctions.groovy"
	gitFunc = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/gitFunctions.groovy"
	EMS_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/EMSFunctions.groovy"
	SQL_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/SQLFunctions.groovy"
	BW_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/BWFunctions.groovy"
	RB_BW_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/RB_BWFunctions.groovy"
	FILE_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/FileFunctions.groovy"
	DB_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/dbFunctions.groovy"
	commonFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/commonFunctions.groovy"
}

def checkout_git_repositories() {
	// This function is to checkout all the required GIT repositories.
	// Checkout Environment configurations.
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "ENV"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: "https://github.vodafone.com/VFUK-INTEGRATION/${EnvironmentRepository}"]]]
	
	// Checkout Automation files from GITHUB repository.
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "automation"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
	
	
	checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'JENKINS_FILE']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_DevOps_Framework.git']]])	
}

def construct_maps() {

	// Initialize ROLLBACK MAster map
	ROLLBACK_ENGINES.split(';').each { engine ->
		ROLLBACK_MAP[engine] = ['BW_VERSION':'NA', 'BW_RB_VERSION':'NA', 'BW_FOLDER_NAME':'NA','BW_ENGINE_TYPE':'Existing', 'BWConfigTag':'NA', 'BWConfigTag_RB':'NA', 'GROUP_ID':'NA', 'EMS_VERSION':'NA', 'EMS_RB_VERSION':'NA', 'SQL_VERSION':'NA', 'SQL_RB_VERSION':'NA', 'XML_FILES':'NA', 'XML_RB_FILES':'NA', 'JAR_FILES':'NA', 'JAR_RB_FILES':'NA', 'EMAIL_FILES':'NA', 'EMAIL_RB_FILES':'NA', 'RESULT':'NA', 'SQL_Rollback':'NOT_REQUIRED', 'EMS_Rollback':'NOT_REQUIRED', 'XML_Rollback':'NOT_REQUIRED', 'JAR_Rollback':'NOT_REQUIRED', 'EMAIL_Rollback':'NOT_REQUIRED', 'BW_Generation':'NOT_REQUIRED', 'BW_Rollback':'NOT_REQUIRED',  'BW_Restart':'NOT_STARTED', 'DB_ROW_ID':'NA']
	}
	
	println("DEBUG: ROLLBACK Map: " + ROLLBACK_MAP)
	// Get current versions for each of the engine and update maps.
	DB_Functions.get_current_versions_from_db map: ROLLBACK_MAP, Environment: "${params.Environment}", dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}" 
	println("DEBUG: ROLLBACK Map: " + ROLLBACK_MAP)
	
	// Get previous  versions for each of the engine and update maps.
	DB_Functions.get_rollback_versions_from_db map: ROLLBACK_MAP, Environment: "${params.Environment}", dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}"
	
	println("DEBUG: " + ROLLBACK_MAP)

	// If there is common SQL engine in engines list, then read restart engines which are affected with sql changes.
	if(ROLLBACK_MAP.containsKey("Common_SQL_Changes")){
		
		SQL_Restart_Engines = input(
			id: 'SQL_Restart_Engines',
			message: 'Please Provide list of Engines to be restarted for Common SQL Scripts separated by;', 
			parameters: [
						[$class: 'TextParameterDefinition', defaultValue: '', description: 'Engines for Common SQL Scripts', name: 'CommonEngines_List'],
			])
		println("DEBUG: SQL Restart engines are wuith SQL_Restart_Engines:" + SQL_Restart_Engines)
	
		if(SQL_Restart_Engines.length() != 0){
			def SQL_Restart_Versions = ""
			SQL_Restart_Engines.split(';').each { engine ->
				if(! ROLLBACK_MAP.containsKey(engine)){
					ROLLBACK_MAP[engine] = ['BW_VERSION':'1', 'BW_RB_VERSION':'NA', 'BW_FOLDER_NAME':'NA','BW_ENGINE_TYPE':'RESTART', 'GROUP_ID':'NA', 'EMS_VERSION':'NA', 'EMS_RB_VERSION':'NA', 'SQL_VERSION':'NA', 'SQL_RB_VERSION':'NA', 'XML_FILES':'NA', 'XML_RB_FILES':'NA', 'JAR_FILES':'NA', 'JAR_RB_FILES':'NA', 'EMAIL_FILES':'NA', 'EMAIL_RB_FILES':'NA', 'RESULT':'NA', 'SQL_Rollback':'NOT_REQUIRED', 'EMS_Rollback':'NOT_REQUIRED', 'XML_Rollback':'NOT_REQUIRED', 'JAR_Rollback':'NOT_REQUIRED', 'EMAIL_Rollback':'NOT_REQUIRED', 'BW_Generation':'NOT_REQUIRED', 'BW_Rollback':'NOT_REQUIRED',  'BW_Restart':'NOT_STARTED']
				} else if(ROLLBACK_MAP[engine]['BW_VERSION'] == 'NA'){
					ROLLBACK_MAP[engine]['BW_VERSION'] == '1'
				}
			}
		}
	} 	

	// Updating bw deployment type and version for only sql changed engines 
	only_sql_deployment_engines = ROLLBACK_MAP.findAll { it.value['BW_VERSION'] == "NA" && it.value['SQL_VERSION'] != "NA" }
	println("DEBUG: Only sql engines are : " + only_sql_deployment_engines)
	only_sql_deployment_engines.keySet().each { engi ->
		ROLLBACK_MAP[engi]['BW_VERSION'] = "1"
		ROLLBACK_MAP[engi]['BW_RB_VERSION'] = "1"
		ROLLBACK_MAP[engi]['BW_ENGINE_TYPE'] = "RESTART"
		ROLLBACK_MAP[engi]['BW_Generation'] = "NOT_STARTED"
		ROLLBACK_MAP[engi]['BW_Restart'] = "NOT_STARTED"
	}
	
	// Update BW_VERSION and ENGINE_TYPE for only file deploymnet engines.
	file_deployment_engines = ROLLBACK_MAP.findAll { it.value['XML_FILES'] != "NA" || it.value['JAR_FILES'] != "NA" || it.value['EMAIL_FILES'] != "NA" }
	file_deployment_engines.keySet().each { engine ->
		if(ROLLBACK_MAP[engine]['BW_VERSION'] == "NA") {
			ROLLBACK_MAP[engine]['BW_VERSION'] = "1"
			ROLLBACK_MAP[engine]['BW_ENGINE_TYPE'] = "RESTART"
		}
	}
	
	// Get folder name for each of the BW engine.
	
	def BW_Engine_Snap = ROLLBACK_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['BW_VERSION'] != "NA" }
	def bw_engine_map = BW_Engine_Snap.collectEntries {bw_map_key, bw_map_value -> [bw_map_key, bw_map_value['BW_VERSION']]}
	if(bw_engine_map.size() != 0) {
		def folder_string = gitFunc.get_bw_folder_name_from_gvconf engines_map: bw_engine_map
		if(folder_string) {
			mapFunc.generate_map inputString:folder_string, map:bw_engine_map
			println(bw_engine_map)
		}
	} else {
		println("DEBUG: There are no BW engines for deployment and no need to get any folders")
	}
	
	if(bw_engine_map.size() != 0){
		mapFunc.init_versions_map map: ROLLBACK_MAP, type: 'BW_FOLDER', input_map: bw_engine_map
	}

    // Change the folder names as per staging and production formats.
	if("${params.Environment}" == "Staging" || "${params.Environment}" == "Production"|| "${params.Environment}" == "Production_ISTIL_Swindon") {
		ROLLBACK_MAP.each { pl_engine, pl_version ->
			if(ROLLBACK_MAP[pl_engine]['BW_FOLDER_NAME'] == "SB01"){
				ROLLBACK_MAP[pl_engine]['BW_FOLDER_NAME'] = "ServiceBus1"
			}
			if(ROLLBACK_MAP[pl_engine]['BW_FOLDER_NAME'] == "SB02") {
				ROLLBACK_MAP[pl_engine]['BW_FOLDER_NAME'] = "ServiceBus2"
			}
		}
	} else if("${params.Environment}" ==~ /^T\d+/) {
		ROLLBACK_MAP.each { pl_engine, pl_version ->
			if(ROLLBACK_MAP[pl_engine]['BW_FOLDER_NAME'] == "SB01"){
				ROLLBACK_MAP[pl_engine]['BW_FOLDER_NAME'] = "None"
			}
			if(ROLLBACK_MAP[pl_engine]['BW_FOLDER_NAME'] == "SB02") {
				ROLLBACK_MAP[pl_engine]['BW_FOLDER_NAME'] = "None"
			}
		}
	}


	// Grouping BW engines for deployment based on engine type and folder name.
	def group_engine_type_maps = ROLLBACK_MAP.findAll { it.value['BW_RB_VERSION'] != "NA" }.groupBy({ engine -> engine.value['BW_ENGINE_TYPE'] })
	group_engine_type_maps.each { g_type_key, g_type_value ->
			def group_engine_type_folder_maps = g_type_value.groupBy({ engine -> engine.value['BW_FOLDER_NAME'] })
			group_engine_type_folder_maps.each{ g_type_folder_key, g_type_folder_value ->
				def counter = 1
				def gID = 1
				g_type_folder_value.each { g_type_folder_value_key, g_type_folder_value_value ->
					ROLLBACK_MAP[g_type_folder_value_key]['GROUP_ID'] = g_type_key + '_' + g_type_folder_key + '_' + gID
					if(counter < 5){
						counter++
					} else {
						counter = 0
						gID++ 
					}
				}
			}
	}	
	// Print ROLLBACK MAP for debugging purpose.
	println("DEBUG: 2" + ROLLBACK_MAP)
}


def preparation_function() {
		date_now = new Date().format("YYYYMMddHHmmss")
	
		// Release number as per BW deployment tool standard
		bw_release_num = RELEASE.replace(".","_")
		println(bw_release_num)
		
		majorVersion = RELEASE.split('CCS')[1].split('\\.')[0]
		minorVersion = RELEASE.split('CCS')[1].split('\\.')[1]
		
		displayName = "${RELEASE}_${BUILD_NUMBER}"
		currentBuild.displayName = "${displayName}"	
		
		if ("${params.Environment}" == "T1" || "${params.Environment}" == "T3" || "${params.Environment}" == "T4" || "${params.Environment}" == "T7" || "${params.Environment}" == "SIT04"){
			println("Setting value to Env Prefix to SIT")
			Env_Prefix = "SIT" 
		} else {
			println("Setting value to Env Prefix to Environment") 
			Env_Prefix = "${params.Environment}"
		}		
		
		// Release number as per BW deployment tool standard
		bw_release_num = RELEASE.replace(".","_")
		println(bw_release_num)
		
		// Assign mail recipents based on environment.
		if("${params.Environment}" == "LinkTest" || "${params.Environment}" == "LNKTest14" || "${params.Environment}" == "LNKTest15") {
			mailRecipients = "${dev_mail_recipents}"
			EnvironmentRepository = "TIL_TestEnv_Configurations"
            ReportFile = "/opt/tibco/DevOps_Reporting/Report/DevOps_report.txt"
		} else if ("${params.Environment}" == "T1" || "${params.Environment}" == "T3" || "${params.Environment}" == "T4" || "${params.Environment}" == "T7" || "${params.Environment}" == "SIT04") {
			mailRecipients = "${ves_mail_recipents}"
			EnvironmentRepository = "TIL_TestEnv_Configurations"
            ReportFile = "/opt/tibco/DevOps_Reporting/Report/DevOps_report.txt"
		} else if("${params.Environment}" == "Staging" || "${params.Environment}".startsWith("Production") || "${params.Environment}" == "Production_ISTIL_Swindon") {
			mailRecipients = "${ops_mail_recipents}"
			EnvironmentRepository = "TIL_Production_Configuration"
            ReportFile = "/opt/tibco/DevOps_Reporting/Report/DevOps_report.txt"
		} else {
			error("Environment ${params.Environment} Not Handled. Please add in code") 
		}
        mailRecipients += ",${params.BUILD_REQUESTER}"
		// Checkout required GIT repositories.
		checkout_git_repositories()
	
		//Load all functions files from GIT. point to exact source file
		load_groovy_files()
		
		// Construct VERSION_MAP and RESULTS_MAP with all the engines from NEXUS.
		construct_maps()
	
}


ROLLBACK_MAP = [:]
majorVersion = ""
minorVersion = ""
Env_Prefix = ""
bw_release_num = ""
SQL_Restart_Engines = ""
dev_mail_recipents = "devops-vfuk-integration@vodafone.com, tssiukintegrationdevleads@vodafone.com"
ves_mail_recipents = "devops-vfuk-integration@vodafone.com, DL-VESTibcoSupport@vodafone.com"
ops_mail_recipents = "devops-vfuk-integration@vodafone.com, DL-TSSC-AO2-UK-Integration_TIL-RIG_L2@vodafone.com"
mailRecipients = ""
RELEASE = "CCS20.X"
EnvironmentRepository = ""
ReportFile = ""

pipeline {
    agent any
	options {
        preserveStashes(buildCount: 49)
    }

    environment {
		REPO_URL = "http://195.233.197.150:8081/repository"
		NEXUS_URL = "http://195.233.197.150:8081"
		NEXUS_USER = "admin"
		NEXUS_PASSWD = "admin123"
		Promotion_Repo = "PROD_REPO"
		BW_GROUPID = "TIL_BW"
		EMS_GROUPID = "TIL_EMS"
		SQL_GROUPID="TIL_SQL"
		emsIgnore = "false"
		UPLIFTMENT_REF_REPO = "LINKTEST_REPO"
		BW_InstanceCount = 2
		//EnvironmentRepository = "TIL_TestEnv_Configurations"
		dbURL = 'jdbc:oracle:thin:@195.233.199.13:33000:TIBTST1'
		dbUserName = 'CICD_OWN_DB01'
		dbPassword = 'TIL_CICD_DB'
		dbDriver = 'oracle.jdbc.driver.OracleDriver'		
    }

    stages {
		stage('RollbackPreparation') {
			steps {
				script{
					deleteDir()
					preparation_function()
					trigger_rollback_versions_email map: ROLLBACK_MAP, REPORT_STAGE: "PREPARATION", environment: "${params.Environment}"
					def userInput = input(
						  id: 'userInputRF1SQL', message: 'Proceed with Geneartion?',
						  submitterParameter: 'submitter'
						)
					
                }				
			}			
		}
		
  		stage('SQL Generate') {
			when {
				 expression { ROLLBACK_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['SQL_VERSION'] != "NA" }.size() != 0 }
				}
			steps {
				script{
					sql_rollback_generate Environment:"${params.Environment}", nexus_group_id:"${env.SQL_GROUPID}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.UPLIFTMENT_REF_REPO}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CRQ}", datetime:"${date_now}", release:"${RELEASE}", map: ROLLBACK_MAP 
				}	
			}
		} 
		
		stage('EMS Generate') {
			when {
				 expression { ROLLBACK_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['EMS_VERSION'] != "NA" }.size() != 0 }
				}
			steps {
				script{
					ems_rollback_generate Environment:"${params.Environment}", nexus_group_id:"${env.EMS_GROUPID}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.UPLIFTMENT_REF_REPO}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CRQ}", datetime:"${date_now}", release:"${RELEASE}", map: ROLLBACK_MAP, emsIgnore: "${env.emsIgnore}" 
				}	
			}
		}
		
 		stage('BW Generate') {
		    when {
			     expression { ROLLBACK_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['BW_VERSION'] != "NA" }.size() != 0 }
			    }
			steps {
				script {
					//Calling BW  Generate Function	
					bw_rollback_generate Environment:"${params.Environment}", nexus_group_id:"${env.BW_GROUPID}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.UPLIFTMENT_REF_REPO}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CRQ}", datetime:"${date_now}", release:"${RELEASE}", map: ROLLBACK_MAP, EnvPrefix: "${Env_Prefix}", bw_release_num: bw_release_num, EnvironmentRepository: EnvironmentRepository, description: "${params.Description}"
					
					// Generate results email after BW_Generate step.
					trigger_rollback_results_email map: ROLLBACK_MAP, REPORT_STAGE: "BW_Generate"
				}
			}
		}
		
 		stage('FILE Generate') {
		    when {
			     expression { ROLLBACK_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['BWConfigTag_RB'] != "NA" && (it.value['XML_FILES'] != "NA" || it.value['JAR_FILES'] != "NA" ||  it.value['EMAIL_FILES'] != "NA")}.size() != 0 }
			    }
			steps {
				script{
					file_rollback_generate Environment: "${params.Environment}", map: ROLLBACK_MAP, crq_no: "${params.CRQ}", datetime: "${date_now}"
				}
			}
		}
		
		stage('File Rollback') {
		    when {
			     expression { ROLLBACK_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['BWConfigTag_RB'] != "NA" && (it.value['XML_FILES'] != "NA" || it.value['JAR_FILES'] != "NA" ||  it.value['EMAIL_FILES'] != "NA")}.size() != 0 }
			    }			
			steps {
				 script {
					 file_rollback_deployment_stage Environment: "${params.Environment}", map: ROLLBACK_MAP, crq_no:"${params.CRQ}", datetime:"${date_now}"
					 
					// Generate results email after BW_Generate step.
					trigger_rollback_results_email map: ROLLBACK_MAP, REPORT_STAGE: "File_Rollback"
				}
			}	 
		}		
		
		stage('SQL Rollback') {
		    when {
			     expression { ROLLBACK_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['SQL_VERSION'] != "NA" }.size() != 0 }
			    }
			steps {
				script {
					def userInput = input(
						  id: 'userInputRF1SQL', message: 'Proceed with SQL Rollback?',
						  submitterParameter: 'submitter'
						)
					sql_rollback_deployment_stage Environment:"${params.Environment}", nexus_group_id:"${env.SQL_GROUPID}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.UPLIFTMENT_REF_REPO}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CRQ}", datetime:"${date_now}", map: ROLLBACK_MAP
					
					// Generate results email after BW_Generate step.
					trigger_rollback_results_email map: ROLLBACK_MAP, REPORT_STAGE: "SQL_Rollback"					
				}
			}
		}
		
		stage('EMS Rollback') {
		    when {
			     expression { ROLLBACK_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['EMS_VERSION'] != "NA" }.size() != 0 }
			    }
			steps {
				script {
					def userInput = input(
						  id: 'userInputEMS', message: 'Proceed with EMS Rollback?',
						  submitterParameter: 'submitter'
						)
					ems_rollback_deployment_stage Environment:"${params.Environment}", nexus_group_id:"${env.EMS_GROUPID}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.UPLIFTMENT_REF_REPO}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CRQ}", datetime:"${date_now}", map: ROLLBACK_MAP, emsIgnore: "${env.emsIgnore}"
					
					// Generate results email after BW_Generate step.
					trigger_rollback_results_email map: ROLLBACK_MAP, REPORT_STAGE: "EMS_Rollback"					
				}
			}
		}
 		stage('BW Rollback') {
		    when {
			     expression { ROLLBACK_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['BW_VERSION'] != "NA" && it.value['BW_RB_VERSION'] != "NA"}.size() != 0 }
			    }
			steps {
				script {
					def userInput = input(
						  id: 'userInputEMS', message: 'Proceed with BW Rollback?',
						  submitterParameter: 'submitter'
						)
					// Calling BW Rollback
					bw_rollback_deployment_stage Environment:"${params.Environment}", nexus_group_id:"${env.BW_GROUPID}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.UPLIFTMENT_REF_REPO}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CRQ}", datetime:"${date_now}", release:"${RELEASE}", map: ROLLBACK_MAP, EnvPrefix: "${Env_Prefix}", bw_release_num: bw_release_num, EnvironmentRepository: EnvironmentRepository
					
					// Generate results email after BW_Generate step.
					trigger_rollback_results_email map: ROLLBACK_MAP, REPORT_STAGE: "BW_Rollback"					
				}
			}
		}
 		stage('BW Undeploy') {
		    when {
			     expression { ROLLBACK_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['BW_VERSION'] != "NA"  && it.value['BW_VERSION'] != "1" && it.value['BW_RB_VERSION'] == "NA"}.size() != 0 }
			    }
			steps {
				script {
					def userInput = input(
						  id: 'userInputEMS', message: 'Proceed with BW Undeploy?',
						  submitterParameter: 'submitter'
						)
					// Calling BW undeployment for the engines which does not have any rollback version.
					bw_rollback_undeployment_stage Environment:"${params.Environment}", crq_no:"${params.CRQ}", datetime:"${date_now}", release:"${RELEASE}", map: ROLLBACK_MAP, EnvironmentRepository: EnvironmentRepository
					
					// Generate results email after BW_Generate step.
					trigger_rollback_results_email map: ROLLBACK_MAP, REPORT_STAGE: "BW_Undeploy"					
				}
			}
		}		
		stage('BW Restart') {
		    when {
			     expression { ROLLBACK_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['BW_VERSION'] != "NA" && it.value['BW_Restart'] != "PASSED"}.size() != 0 }
			    }
			steps {
				script{
					// Calling BW Restart Stage function
				 	bw_rollback_restart_stage Environment:"${params.Environment}", nexus_group_id:"${env.BW_GROUPID}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.UPLIFTMENT_REF_REPO}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CRQ}", datetime:"${date_now}", release:"${RELEASE}", map: ROLLBACK_MAP, EnvPrefix: "${Env_Prefix}", bw_release_num: bw_release_num, EnvironmentRepository: EnvironmentRepository
					
					// Generate results email after BW_Generate step.
					trigger_rollback_results_email map: ROLLBACK_MAP, REPORT_STAGE: "BW_Restart"					
				} 
			}
		}	
		stage('Singoff') {			
			steps {
				script {
					// Update DB records with status as Rollback for all the rollback successful engines.
					DB_Functions.update_deployment_status_in_db map: ROLLBACK_MAP, status: "Rollback", release: RELEASE, dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}" 
					
					//Update dash board as well along with stats file.
					commonFunctions.update_rollback_stats map: ROLLBACK_MAP, environment: "${params.Environment}", statsFile: "${ReportFile}", pipeline_name: '${env.JOB_NAME}'					
					
                    // Generate results email after BW_Generate step.
					trigger_rollback_results_email map: ROLLBACK_MAP, REPORT_STAGE: "RESULT"
					
					// Update DB records with status as Rollback for all the rollback successful engines in release notes DB if the deployment is LinkTest.
					
						DB_Functions.update_deployment_status_in_release_db map: ROLLBACK_MAP, status: "Rollback", release: RELEASE, dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}" 
					
				}
			}
		}
	}
}
