import com.cwctravel.hudson.plugins.extended_choice_parameter.ExtendedChoiceParameterDefinition
import java.text.*
import groovy.time.*
import hudson.tasks.Mailer;
import hudson.model.User;
import groovy.json.JsonOutput
import groovy.sql.*
import java.sql.Driver

def getcssContent(){
    def css = """
        <style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Times, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;width:150px;word-break:break-all;border-color:#9ABAD9;color:#444;}
		.tg th{font-family:Times, sans-serif;font-size:26px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:break-all;border-color:#9ABAD9;color:#1A0504;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		.tg .tg-pass{background-color:lightgreen;text-align:left;vertical-align:top}
		.tg .tg-fail{background-color:red;text-align:left;vertical-align:top}
		.tg .tg-notstarted{background-color:lightgrey;text-align:left;vertical-align:top}
		.tg .tg-notrequired{background-color:#E1E0A2;text-align:left;vertical-align:top}
		</style>
        """
     return css
}

def myGetDBConnect() {     
     def dbURL = 'jdbc:oracle:thin:@aukshocr.dc-dublin.de:33000:TIBTST1'
     def dbUserName = 'CICD_OWN_DB01'
     def dbPassword = 'TIL_CICD_DB'
     def dbDriver = 'oracle.jdbc.driver.OracleDriver'
     //displayDebug('myGetDBConnect','Establishing DB Connectivity')
     def mySQL = groovy.sql.Sql.newInstance(dbURL,dbUserName,dbPassword,dbDriver)
     return mySQL                   
}

def myMultipleSelectQuery(selectQuery){     
     def mySQL =  myGetDBConnect()
  	 def rowData = [:]
	 def resultList = []
     //displayDebug('myMultipleSelectQuery',selectQuery)
     def rowResults = mySQL.rows(selectQuery)
     mySQL.close()
     if(rowResults.size() == 0)
            return resultList;
     def headerList = new ArrayList(rowResults[0].keySet())
	 for(def rlcounter=0;rlcounter<rowResults.size();rlcounter++)
     {
         def row = rowResults[rlcounter];
         rowData = [:]
         for(def rwHeaderCnt=0;rwHeaderCnt<headerList.size();rwHeaderCnt++)
         { 
               rowData.put(headerList[rwHeaderCnt], row[rwHeaderCnt]!= null  ? row[rwHeaderCnt].toString() : "")
         }
		 resultList.add(rowData)
     }
	 headerList=null;
	rowResults = null;
	rowData = null;
	mySQL = null;
    return resultList;
}

def sit_deployment_status()
{
    def sit_deployment_report = ""
     
     sit_deployment_report+="<table class='tg' style='table-layout: fixed; width: 100%'>\n"
     sit_deployment_report+="<tr>\n"      
         sit_deployment_report+="<th class='tg-amwm'>ENGINE_NAME</th>\n<th class='tg-amwm'>CRQ</th>\n<th class='tg-amwm'>RELEASE</th>\n<th class='tg-amwm'>ENVIRONMENT</th>\n<th class='tg-amwm'>ONLY_GV</th>\n<th class='tg-amwm'>BW_VERSION</th>\n<th class='tg-amwm'>EMS_VERSION</th>\n<th class='tg-amwm'>SQL_VERSION</th>\n<th class='tg-amwm'>DESCRIPTION</th>\n<th class='tg-amwm'>FILE_DEPLOYMENT</th>\n<th class='tg-amwm'>BUILD_REQUESTER</th>\n<th class='tg-amwm'>DEPLOY_STATUS</th>\n"
      
     sit_deployment_report+="</tr>\n"	
	 EngineId.split(',').each { tmpengine ->
		
		sit_deployment_report+="</tr>\n"
		sit_deployment_report+="<td class='tg-1wig'>${SITDeploymentEnginesDetails[tmpengine]['ENGINE_NAME']}</td>\n<td class='tg-1wig'>${SITDeploymentEnginesDetails[tmpengine]['CRQ']}</td>\n<td class='tg-1wig'>${SITDeploymentEnginesDetails[tmpengine]['RELEASE']}</td>\n<td class='tg-1wig'>${SITDeploymentEnginesDetails[tmpengine]['ENVIRONMENT']}</td>\n<td class='tg-1wig'>${SITDeploymentEnginesDetails[tmpengine]['ONLY_GV']}</td>\n<td class='tg-1wig'>${SITDeploymentEnginesDetails[tmpengine]['BW_VERSION']}</td>\n<td class='tg-1wig'>${SITDeploymentEnginesDetails[tmpengine]['EMS_VERSION']}</td>\n<td class='tg-1wig'>${SITDeploymentEnginesDetails[tmpengine]['SQL_VERSION']}</td>\n<td class='tg-1wig'>${SITDeploymentEnginesDetails[tmpengine]['DESCRIPTION']}</td>\n<td class='tg-1wig'>${SITDeploymentEnginesDetails[tmpengine]['FILE_DEPLOYMENT']}</td>\n<td class='tg-1wig'>${SITDeploymentEnginesDetails[tmpengine]['BUILD_REQUESTER']}</td>\n"
		if(SITDeploymentEnginesDetails[tmpengine]['DEPLOY_STATUS'] == "FAILED")
		{
			sit_deployment_report+="<td class='tg-fail'>${SITDeploymentEnginesDetails[tmpengine]['DEPLOY_STATUS']}</td>\n"
		}
		else if (SITDeploymentEnginesDetails[tmpengine]['DEPLOY_STATUS'] == "SUCCESS")
		{
			sit_deployment_report+="<td class='tg-pass'>${SITDeploymentEnginesDetails[tmpengine]['DEPLOY_STATUS']}</td>\n"
		}
		else
		{
			sit_deployment_report+="<td class='tg-notstarted'>${SITDeploymentEnginesDetails[tmpengine]['DEPLOY_STATUS']}</td>\n"
		}
			
		}
		sit_deployment_report+="</tr>\n"
		
    sit_deployment_report+="</tr>\n"
    sit_deployment_report+="</table>"
    println ("${sit_deployment_report}")
    return sit_deployment_report;
}

def sendEmail(subjectSuffix, mailRecipients)
{
    def body_build_summary = ""  
    
    
    body_build_summary += getcssContent()
    body_build_summary += sit_deployment_status()     
	body_build_summary += "<br><p><b><font size='2' color='Black'>SIT_DEPLOYMENT_AUTOMATION_BUILDURL: <a href='${BUILD_URL}input'>${BUILD_URL}</a></font></b></p>"
        
    emailext mimeType: 'text/html',
    subject: "[Jenkins]: ${subjectSuffix}",
	from:"TIL_SIT_DEPLOYMENT_Automation@vodafone.com",
	to: "${mailRecipients}",
	body: "${body_build_summary}" 
}

def fetchvalues()
{
    strQuery = """SELECT DISTINCT TDD_ID,RELEASE_NO,TECH_CHANGES_INVOLVED,ENGINE_NAME,SIT_ENV,ONLY_GV,BW_VERSION,EMS_VERSION,SQL_VERSION,CHANGE_REF_DESCRIPTION,FILE_DEPLOYMENT,SIT_APPROVAL FROM CICD_RELEASES WHERE STAGE_COMPLETED = 'SIT_SHEDULED_DEPLOY'"""
    strQuery = strQuery.toString()
    rowList = myMultipleSelectQuery(strQuery);
    
    def headerList = new ArrayList(rowList[0].keySet())	
	 for(def rlcounter=0;rlcounter<rowList.size();rlcounter++)
     {
         def row = rowList[rlcounter];
		 println("ROW : ${row}")
		 def TmpTddID =""
         for(def rwHeaderCnt=0;rwHeaderCnt<headerList.size();rwHeaderCnt++)
         {   
			 if(rwHeaderCnt%12 == 0)
			 {  
				row_value = row[headerList[rwHeaderCnt]]!= null  ? row[headerList[rwHeaderCnt]].toString() : ""
				TmpTddID = row_value
				
				SITDeploymentEnginesDetails[TmpTddID] = ['RELEASE':'','CRQ':'','ENVIRONMENT':'','ENGINE_NAME':'','ONLY_GV':'','BW_VERSION':'','EMS_DEPLOYMENT':'','EMS_VERSION':'','SQL_DEPLOYMENT':'','SQL_VERSION':'','DESCRIPTION':'','FILE_DEPLOYMENT':'','BUILD_REQUESTER':'','DEPLOY_STATUS':'PENDING']				
				if (rlcounter == rowList.size()-1)
					EngineId = EngineId +  TmpTddID
				else
					EngineId = EngineId +  TmpTddID +","
			 }
			 else if (rwHeaderCnt%12 == 1)
			 {
				row_value = row[headerList[rwHeaderCnt]]!= null  ? row[headerList[rwHeaderCnt]].toString() : ""
				SITDeploymentEnginesDetails[TmpTddID]['RELEASE']=row_value
				println(row_value)
			 }
			 else if (rwHeaderCnt%12 == 2)
			 {
				row_value = row[headerList[rwHeaderCnt]]!= null  ? row[headerList[rwHeaderCnt]].toString() : ""
				SITDeploymentEnginesDetails[TmpTddID]['CRQ']=row_value
				println(row_value)
			 }
			 else if (rwHeaderCnt%12 == 3)
			 {
				row_value = row[headerList[rwHeaderCnt]]!= null  ? row[headerList[rwHeaderCnt]].toString() : ""
				SITDeploymentEnginesDetails[TmpTddID]['ENGINE_NAME']=row_value
				println(row_value)
			 }
			 else if (rwHeaderCnt%12 == 4)
			 {
				row_value = row[headerList[rwHeaderCnt]]!= null  ? row[headerList[rwHeaderCnt]].toString() : ""
				SITDeploymentEnginesDetails[TmpTddID]['ENVIRONMENT']=row_value
				println(row_value)
			 }
			 else if (rwHeaderCnt%12 == 5)
			 {
				row_value = row[headerList[rwHeaderCnt]]!= null  ? row[headerList[rwHeaderCnt]].toString() : ""
				SITDeploymentEnginesDetails[TmpTddID]['ONLY_GV']=row_value
				println(row_value)
			 }
			 else if (rwHeaderCnt%12 == 6)
			 {
				row_value = row[headerList[rwHeaderCnt]]!= null  ? row[headerList[rwHeaderCnt]].toString() : ""
				SITDeploymentEnginesDetails[TmpTddID]['BW_VERSION']=row_value
				println(row_value)
			 }
			 else if (rwHeaderCnt%12 == 7)
			 {
				if ( row[headerList[rwHeaderCnt]]!= null )
				{
					if ( row[headerList[rwHeaderCnt]]!= 'NA' )
					{
						SITDeploymentEnginesDetails[TmpTddID]['EMS_VERSION']= row[headerList[rwHeaderCnt]].toString()
						SITDeploymentEnginesDetails[TmpTddID]['EMS_DEPLOYMENT']= "true"
					}
					else
					{
						SITDeploymentEnginesDetails[TmpTddID]['EMS_VERSION']= ""
						SITDeploymentEnginesDetails[TmpTddID]['EMS_DEPLOYMENT']= "false"
					}
				}
				else
				{
					SITDeploymentEnginesDetails[TmpTddID]['EMS_VERSION'] = ""
					SITDeploymentEnginesDetails[TmpTddID]['EMS_DEPLOYMENT']= "false"
				}

			 }
			 else if (rwHeaderCnt%12 == 8)
			 {  
				if ( row[headerList[rwHeaderCnt]]!= null )
				{
					if ( row[headerList[rwHeaderCnt]]!= 'NA' )
					{
						SITDeploymentEnginesDetails[TmpTddID]['SQL_VERSION']= row[headerList[rwHeaderCnt]].toString()
						SITDeploymentEnginesDetails[TmpTddID]['SQL_DEPLOYMENT']= "true"
					}
					else
					{
						SITDeploymentEnginesDetails[TmpTddID]['SQL_VERSION']= ""
						SITDeploymentEnginesDetails[TmpTddID]['SQL_DEPLOYMENT']= "false"
					}
				}
				else
				{
					SITDeploymentEnginesDetails[TmpTddID]['SQL_VERSION'] = ""
					SITDeploymentEnginesDetails[TmpTddID]['SQL_DEPLOYMENT']= "false"
				}				
				
			 }
			 else if (rwHeaderCnt%12 == 9)
			 {
				row_value = row[headerList[rwHeaderCnt]]!= null  ? row[headerList[rwHeaderCnt]].toString() : ""
				SITDeploymentEnginesDetails[TmpTddID]['DESCRIPTION']=row_value
				println(row_value)
			 }
			 else if (rwHeaderCnt%12 == 10)
			 {
				row_value = row[headerList[rwHeaderCnt]]!= null  ? row[headerList[rwHeaderCnt]].toString() : ""
				SITDeploymentEnginesDetails[TmpTddID]['FILE_DEPLOYMENT']=row_value
				println(row_value)
			 }		
			 else
			 {
				row_value = row[headerList[rwHeaderCnt]]!= null  ? row[headerList[rwHeaderCnt]].toString() : ""
				SITDeploymentEnginesDetails[TmpTddID]['BUILD_REQUESTER']=row_value
				println(row_value)
			 }	 
         }
     }
	 
}

EngineId = ""
Main_Id = ""
Failed_Engine_List = []
def Engine_List = []
usermails= "devansh.patil@vodafone.com;j.raghavendra@vodafone.com;devops-vfuk-integration@vodafone.com"
// usermails= "devansh.patil@vodafone.com"

// SITDeploymentEnginesDetails = ["EngineName":"","Release":"","Environment":"","Operations":""]
SITDeploymentEnginesDetails = [:]

pipeline {
	agent any
	environment {
		
		dbURL = 'jdbc:oracle:thin:@195.233.199.13:33000:TIBTST1'
		dbUserName = 'CICD_OWN_DB01'
		dbPassword = 'TIL_CICD_DB'
		dbDriver = 'oracle.jdbc.driver.OracleDriver'
	}
	
	stages {
		stage('Prepration') {
		
			steps {
				script {
					
					fetchvalues()
					println(EngineId)
					println(SITDeploymentEnginesDetails)
					
					checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'JENKINS_FILE']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_DevOps_Framework.git']]])
					DB_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/dbFunctions.groovy"	
		        }
	        }
		}
		
		stage('SIT Deployment Call'){
			steps {
				script {
					if(EngineId.size() != 0)
					{   
						sendEmail("SIT Deployment Automation- Start", usermails)
						
						EngineId.split(',').each { tmpengine ->					
						sit_deploy_pipe = build job: 'CICD_Development/Devansh/TTD_SIT_Standalone', 
								parameters: [
											string(name: 'RELEASE', value: "${SITDeploymentEnginesDetails[tmpengine]['RELEASE']}"),
											string(name: 'TDD_ID', value: "${tmpengine}"),
											string(name: 'CRQ', value: "${SITDeploymentEnginesDetails[tmpengine]['CRQ']}"),
											string(name: 'Environment', value: "${SITDeploymentEnginesDetails[tmpengine]['ENVIRONMENT']}"),
											string(name: 'ENGINE_NAME', value: "${SITDeploymentEnginesDetails[tmpengine]['ENGINE_NAME']}"),
											booleanParam(name: 'ONLY_GV', value: "${SITDeploymentEnginesDetails[tmpengine]['ONLY_GV']}"),
											string(name: 'BW_VERSION', value: "${SITDeploymentEnginesDetails[tmpengine]['BW_VERSION']}"),
											booleanParam(name: 'EMS_DEPLOYMENT', value: "${SITDeploymentEnginesDetails[tmpengine]['EMS_DEPLOYMENT']}"),
											string(name: 'EMS_VERSION', value: "${SITDeploymentEnginesDetails[tmpengine]['EMS_VERSION']}"), 
											booleanParam(name: 'SQL_DEPLOYMENT', value: "${SITDeploymentEnginesDetails[tmpengine]['SQL_DEPLOYMENT']}"),
											string(name: 'SQL_VERSION', value: "${SITDeploymentEnginesDetails[tmpengine]['SQL_VERSION']}"),
											string(name: 'Description', value: "${SITDeploymentEnginesDetails[tmpengine]['DESCRIPTION']}"),
											string(name: 'FILE_DEPLOYMENT', value: "${SITDeploymentEnginesDetails[tmpengine]['FILE_DEPLOYMENT']}"),
											string(name: 'BUILD_REQUESTER', value: "${SITDeploymentEnginesDetails[tmpengine]['BUILD_REQUESTER']}")				
										], propagate:false 
								
								println(sit_deploy_pipe.result + " : ${sit_deploy_pipe.buildVariables.ST_ERROR_CODE}")
						if(sit_deploy_pipe.buildVariables.ST_ERROR_CODE != "200")
						{
							println("Engine Deployment Failed")
							SITDeploymentEnginesDetails[tmpengine]['DEPLOY_STATUS'] = "FAILED"
							def updateQuery = "UPDATE CICD_RELEASES SET STAGE_COMPLETED='SIT_AUTO_DEPLOYMENT_FAILED',SIT_DEPLOYMENT_ON = sysdate WHERE TDD_ID=${tmpengine}" 
					    	println("DEBUG: Update query is: " + updateQuery)
						DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: updateQuery
						}
						else
						{
							SITDeploymentEnginesDetails[tmpengine]['DEPLOY_STATUS'] = "SUCCESS"
						}
						}
					}
					else
					{
						println("No engine for deployment")
					}
					println(SITDeploymentEnginesDetails)
					
					
				}					
			}
		}		
		 stage('Mail Report') {		
			steps {
                script {
					if(EngineId.size() != 0)
					{   
						echo "Mail Report"					
						sendEmail("SIT Deployment Automation Report", usermails)
					}
					else
					{
						println("No engine for deployment")
					}
                }
            }
        } 
	}
}
