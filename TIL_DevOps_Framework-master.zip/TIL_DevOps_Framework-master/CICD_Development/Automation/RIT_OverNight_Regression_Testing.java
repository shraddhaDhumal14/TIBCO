import java.text.*
import groovy.time.*
import hudson.tasks.Mailer;
import hudson.model.User;


//  Testing Related Email Body Preparation
def get_body_build_summary(){
    def date = new Date();
    def sdf = new SimpleDateFormat("dd-MM-yyyy");
    def submitted_date = sdf.format(date)
    
    def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
		.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		</style>
		</style>
		<table class="tg" style="undefined;table-layout: fixed; width: 1000px">
		<colgroup>
		<col style="width: 100px">
		<col style="width: 500px">
		<col style="width: 100px">
		<col style="width: 500px">
		</colgroup>
		  <tr>
			<th class="tg-amwm" colspan="2">TEST_AUTOMATION_SUMMARY</th>
		  </tr>
		  <tr>
			<td class="tg-1wig">Engine</td>
			<td class="tg-0lax">${ENGINE_NAME}</td>
		  </tr>
		  <tr>	
			<td class="tg-1wig">Test_Result</td>
			<td class="tg-0lax">${getMapResultTable()}</td>
		  </tr>            
          <tr>	
		   <td class="tg-1wig">TESTCASE Report</td>
		   <td class="tg-0lax">${TESTCASE_REPORT}</td>
		 </tr>
		 <tr>	
		   <td class="tg-1wig">Report url</td>
		   <td class="tg-0lax">${REPORT_URL}</td>
		 </tr>
		  <tr>
			<td class="tg-1wig">Submitted On</td>
			<td class="tg-0lax">${submitted_date}</td>
		  </tr>
		</table>
		<br>
	"""
	emailBody = body_build_summary
	return body_build_summary
}

def getMapResultTable(){
    def MapTable = ""
    MapTable+= """
          <table>
		  <tr>
			<th class="tg-amwm">Operation</th>
            <th class="tg-amwm">Reg_Pass</td> 
            <th class="tg-amwm">Reg_Fail</td>
            <th class="tg-amwm">Reg_Status</td>
            <th class="tg-amwm">TEST_STATUS</td>
            <th class="tg-amwm">TOTAL_TC</td>
		  </tr>
          """
    
    for (operation in Operations){
      MapTable+= """   
		  <tr>
            <td class="tg-0lax">${operation}</td>
            <td class="tg-0lax">${TestMapResult[operation]['Reg_Pass']}</td> 
            <td class="tg-0lax">${TestMapResult[operation]['Reg_Fail']}</td>
            <td class="tg-0lax">${TestMapResult[operation]['Reg_Status']}</td>
            <td class="tg-0lax">${TestMapResult[operation]['TEST_STATUS']}</td>
            <td class="tg-0lax">${TestMapResult[operation]['TOTAL_TC']}</td>
		  </tr>
		  """
    }
    MapTable+= "</table>"
    return MapTable
}


def Preparation () {
	
    def date = new Date();
	def sdf = new SimpleDateFormat("yyyyMMddHHmmss");
	date_time = sdf.format(date)

    
  //  TESTCASE_REPORT = "http://${NEXUS_URL}/repository/TEST_AUTOMATION_REPO/RTCP_Reports/${ENGINE_NAME}/${RELEASE_NO}_${date_time}/${ENGINE_NAME}-${RELEASE_NO}_${date_time}.zip"
    REPORT_URL = "http://195.233.197.150:8081/#browse/browse:TEST_AUTOMATION_REPO:RTCP_Reports%2F${ENGINE_NAME}"
	TESTCASE_REPORT="https://github.vodafone.com/VFUK-INTEGRATION/RIT_Overnight_Regression_Logs/tree/main/${ENGINE_NAME}"

	sh 'cp -r ${WORKSPACE}/Project/${ENGINE_NAME}  ${WORKSPACE}/${ENGINE_NAME}_RIT'
	sh 'cp -r ${WORKSPACE}/Script/Test_Automation_Scripts ${WORKSPACE}/Test_Automation_Scripts'
        sh 'cd ${WORKSPACE}'
	sh 'chmod 766 ${WORKSPACE}/${ENGINE_NAME}_RIT'
	sh 'chmod -f 766 ${WORKSPACE}/${ENGINE_NAME}_RIT/Logical/AntScripts/*.xml'
	
	    
	//Replaces the windows parameters Values to RTCP Box Values in Ant Files   
    
    sh '''
			AntFiles="${WORKSPACE}/${ENGINE_NAME}_RIT/Logical/AntScripts/*.xml"
			# Replaces the windows parameters Values to RTCP Box Values in Ant Files   
				   
			sed -i 's#name="install.dir" value=.*/>#name="install.dir" value="/opt/SP/tibco/IBM/RationalIntegrationTester"/>#g' ${AntFiles}
			sed -i 's#environment=.* project#environment="'${ENVIRONMENT}'" project#g' ${AntFiles}
			sed -i 's#basedir=.* default#basedir="./../.." default#g' ${AntFiles}
			sed -i 's#ghp"#ghp" securityToken="P:8647bc48-c250-4168-9855-b8379b057d1a"#g' ${AntFiles}
				
			cd ${WORKSPACE}
			# Coverting the Total Project into tar file
			tar -czvf ${ENGINE_NAME}_RIT.tar.gz ${ENGINE_NAME}_RIT
				
		'''        
}

def Test_Preparation()
{
    // Executing Ansible Scripts for RIT Project Deployment Preparation in RTCP Box

    ansiColor('xterm') {
        ansiblePlaybook (playbook: "${WORKSPACE}/Test_Automation_Scripts/Preparation.yml", colorized: true, extras: '', extraVars: [host: "RIT_TEST", Engine_Name: "${ENGINE_NAME}_RIT", date_time: "${date_time}", Workspace: "${WORKSPACE}"])
       	//Deleting the tar and engine_RIT to reduce the disk space after successful preparation,  in UKTILAHR box 
	    sh '''
              rm -Rf ${ENGINE_NAME}_RIT
              rm ${ENGINE_NAME}_RIT.tar.gz
         '''
    }
}

// Ant File Execution for all Operations Progression
def Automation_Testing (testing_Type) {        
		println("Automation_Testing Map --> " + TestMapResult)
        for (operation in Operations){	 
			
            if((testing_Type == "Progression" && TestMapResult[operation]['Prog_Status'] != "XML MISSING") || (testing_Type == "Regression" && TestMapResult[operation]['Reg_Status'] != "XML MISSING"))    
            {
                // Executing Ansible Scripts for RIT Project Deploying in RTCP Box
                AntFile="${ENGINE_NAME}_${operation}_${testing_Type}.xml"
                ansiColor('xterm') {
                    ansiblePlaybook (playbook: "${WORKSPACE}/Test_Automation_Scripts/Test_Execution.yml", colorized: true, extras:'-v', extraVars: [host: "RIT_TEST", Ant_File: "${AntFile}", Engine_Name: "${ENGINE_NAME}_RIT", date_time: "${date_time}", Workspace: "${WORKSPACE}", Log_File: "${operation}_${testing_Type}_Result.log", file: "${operation}_${testing_Type}.log"])
			}
            }
            else
            {
                println("Skipping Testing for ${operation} for ${testing_Type}")                
            }
	   }
}

// Reports and Cleaning the Workspace
def Reporting_CleanUp () {
	
	//def date = new Date();
	//def sdf = new SimpleDateFormat("yyyy-MM-dd-HH:mm");
	//date_time = sdf.format(date)
	
	ansiColor('xterm') {
			ansiblePlaybook (playbook: "${WORKSPACE}/Test_Automation_Scripts/Reportin_And_Cleanup.yml", colorized: true, extras:'-v', extraVars: [host: "RIT_TEST", Engine_Name: "${ENGINE_NAME}_RIT", date_time: "${date_time}", Workspace: "${WORKSPACE}", Engine: "${ENGINE_NAME}", Workspace: "${WORKSPACE}"])
			
			// Uploading RTCP Reports in to NEXUS
			//nexusArtifactUploader artifacts: [[artifactId: "${ENGINE_NAME}", classifier: '', file: "${WORKSPACE}/${ENGINE_NAME}.zip", type: 'zip']], credentialsId: '74edde97-94e0-403c-93f6-cad6c46c45f8', groupId: "RTCP_Reports", nexusUrl: "${NEXUS_URL}", nexusVersion: "${NEXUS_VERSION}", protocol: 'http', repository: "${RTCP_REPO}", version: "${date_time}"
            
            sh "mv ${ENGINE_NAME}.zip ${ENGINE_NAME}_${date_time}.zip"
            
            // nexusArtifactUploader artifacts: [[artifactId: "${ENGINE_NAME}", classifier: '', file: "${WORKSPACE}/${ENGINE_NAME}_${date_time}.zip", type: 'zip']], credentialsId: '74edde97-94e0-403c-93f6-cad6c46c45f8', groupId: "RTCP_Reports", nexusUrl: "${NEXUS_URL}", nexusVersion: "${NEXUS_VERSION}", protocol: 'http', repository: "${RTCP_REPO}", version: "${RELEASE_NO}_${date_time}"
										
	}
    
    for (operation in Operations)
	{
		TestMapResult[operation]['TOTAL_TC'] = 0
		TestMapResult[operation]['TEST_STATUS'] = ''
        
        if(TestMapResult[operation]['Prog_Status'] != "XML MISSING")
        {
            ta_result = sh(script:"grep 'tests executed' ${operation}_Progression_Result.log | tail -1 | cut -d ']' -f3 | xargs" ,returnStdout: true).trim()
            println("TA Result -->" + ta_result)
            if ( ta_result == "0 tests executed" ) 
            {
                TestMapResult[operation]['Prog_Total'] = '0'
                TestMapResult[operation]['Prog_Pass'] = '0'
                TestMapResult[operation]['Prog_Fail'] = '0'
                TestMapResult[operation]['Prog_Status'] = "FAILED"
				TestMapResult[operation]['TEST_STATUS'] = "FAILED"
            } 
			else if ( ta_result == "1 tests executed - passed" ) 
            {
                TestMapResult[operation]['Prog_Total'] = '1'
                TestMapResult[operation]['Prog_Pass'] = '1'
                TestMapResult[operation]['Prog_Fail'] = '0'
                TestMapResult[operation]['Prog_Status'] = "PASSED"
				TestMapResult[operation]['TEST_STATUS'] = "SUCCESS"
            }  
            else {
                TestMapResult[operation]['Prog_Total'] = ta_result.split('-')[0].split(' ')[0]
                
                pass_fail_msg = ta_result.split('-')[1]
                if ( "${pass_fail_msg}" == " all passed" ) {
                    TestMapResult[operation]['Prog_Fail'] = 0
                } 
                else if("${pass_fail_msg}".trim() == "failed")
                {
                    TestMapResult[operation]['Prog_Fail'] = 1
                }
                else {
                    TestMapResult[operation]['Prog_Fail'] = pass_fail_msg.split(' ')[1]
                }
                TestMapResult[operation]['Prog_Pass'] = TestMapResult[operation]['Prog_Total'].toInteger() - TestMapResult[operation]['Prog_Fail'].toInteger()
                statusFile = new File("${WORKSPACE}/${operation}_Progression_Result.log")
				TestMapResult[operation]['TOTAL_TC'] = ((TestMapResult[operation]['TOTAL_TC'] as Integer) + (TestMapResult[operation]['Prog_Total'] as Integer)).toString()
				
                statusContent = sh(script:"grep 'RunTests execution ended with code: 0' ${operation}_Progression_Result.log" ,returnStdout: true).trim()
                if (statusContent.contains('RunTests execution ended with code: 0')) {
                    TestMapResult[operation]['Prog_Status'] = "SUCCESS"
                }else {
                    TestMapResult[operation]['Prog_Status'] = "FAILED"
                } 
				
				if(TestMapResult[operation]['Prog_Status'] == 'SUCCESS')
				{
					TestMapResult[operation]['TEST_STATUS'] = 'SUCCESS'
				}
				else
				{
					TestMapResult[operation]['TEST_STATUS'] = 'FAILED'
				}
             }
        }

        if(TestMapResult[operation]['Reg_Status'] != "XML MISSING" && TestMapResult[operation]['Reg_Status'] != "NEW")
        {
            ta_result = sh(script:"grep 'tests executed' ${operation}_Regression_Result.log | tail -1 | cut -d ']' -f3 | xargs" ,returnStdout: true).trim()
            
            if ( ta_result == "0 tests executed" ) 
            {
                TestMapResult[operation]['Reg_Total'] = '0'
                TestMapResult[operation]['Reg_Pass'] = '0'
                TestMapResult[operation]['Reg_Fail'] = '0'
                TestMapResult[operation]['Reg_Status'] = "FAILED"
				TestMapResult[operation]['TEST_STATUS'] = "FAILED"
            } 
			else if ( ta_result == "1 tests executed - passed" ) 
            {
                TestMapResult[operation]['Reg_Total'] = '1'
                TestMapResult[operation]['Reg_Pass'] = '1'
                TestMapResult[operation]['Reg_Fail'] = '0'
                TestMapResult[operation]['Reg_Status'] = "PASSED"
				if(TestMapResult[operation]['Prog_Status'] != "FAILED")
				{
					TestMapResult[operation]['TEST_STATUS'] = "SUCCESS"
				}
				else
				{
					TestMapResult[operation]['TEST_STATUS'] = "FAILED"
				}
            }
            else {
                TestMapResult[operation]['Reg_Total'] = ta_result.split('-')[0].split(' ')[0]
                
                pass_fail_msg = ta_result.split('-')[1]
                if ( "${pass_fail_msg}" == " all passed" ) {
                    TestMapResult[operation]['Reg_Fail'] = 0
                }
                else if("${pass_fail_msg}".trim() == "failed")
                {
                    TestMapResult[operation]['Reg_Fail'] = 1
                }                
                else {
                    TestMapResult[operation]['Reg_Fail'] = pass_fail_msg.split(' ')[1]
                }
                TestMapResult[operation]['Reg_Pass'] = TestMapResult[operation]['Reg_Total'].toInteger() - TestMapResult[operation]['Reg_Fail'].toInteger()
                statusFile = new File("${WORKSPACE}/${operation}_Regression_Result.log")
				TestMapResult[operation]['TOTAL_TC'] = ((TestMapResult[operation]['TOTAL_TC'] as Integer) + (TestMapResult[operation]['Reg_Total'] as Integer)).toString()
                                         
                statusContent = sh(script:"grep 'RunTests execution ended with code: 0' ${operation}_Regression_Result.log" ,returnStdout: true).trim()                                        
                if (statusContent.contains('RunTests execution ended with code: 0')) {
                    TestMapResult[operation]['Reg_Status'] = "SUCCESS"
                }else {
                    TestMapResult[operation]['Reg_Status'] = "FAILED"
                } 
				if(TestMapResult[operation]['Reg_Status'] == 'SUCCESS' && TestMapResult[operation]['Prog_Status'] != 'FAILED')
				{
					TestMapResult[operation]['TEST_STATUS'] = 'SUCCESS'
				}
				else
				{
					TestMapResult[operation]['TEST_STATUS'] = 'FAILED'
				}
            }
        }
            
        TestMapResult[operation]['Reg_Pass'] = ((TestMapResult[operation]['Prog_Pass'] as Integer) + (TestMapResult[operation]['Reg_Pass'] as Integer)).toString()
		TestMapResult[operation]['Reg_Fail'] = ((TestMapResult[operation]['Prog_Fail'] as Integer) + (TestMapResult[operation]['Reg_Fail'] as Integer)).toString()
	}//for loop ends
		
          
               
    println("TestMapResult  " +TestMapResult)
    
	string updateQuery="UPDATE AUTO_TA_SUMMARY SET  STATUS='Inactive' where CREATED_ON = sysdate and STATUS ='Active'" 
              	
    println("DEBUG: AUTO_TA_SUMMARY query is: " + updateQuery)
    DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: updateQuery 
    
    //Insert into Table
     
     for (operation in Operations)
	 {
        
		string insert_query="INSERT INTO AUTO_TA_SUMMARY ( RELEASE_NO,  ENGINE_NAME, OPERATION, RIT_BRANCH, ENVIRONMENT, REG_PASS, REG_FAIL, TOTAL_TC, TEST_STATUS, STATUS, CREATED_ON, TESTCASE_REPORT_URL, BUILD_ID,MAIN_PIPE_ID,DEVELOPER) VALUES ( '${RELEASE_NO}',  ${ENGINE_NAME}, ${operation}, ${GIT_BRANCH}, ${ENVIRONMENT}, ${TestMapResult[operation]['Reg_Pass']}, ${TestMapResult[operation]['Reg_Fail']}, ${TestMapResult[operation]['TOTAL_TC']}, ${TestMapResult[operation]['TEST_STATUS']}, 'Active', sysdate, ${TESTCASE_REPORT}, ${BUILD_NUMBER}, ${MAIN_PIPE_ID}, ${DEVELOPER})" 
				
					
		println("DEBUG: AUTO_TA_SUMMARY query is: " + insert_query)
		DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: insert_query 	
    }
}

def validate_parameter() {
        def validationCheck = ""
   
        //1. Validate Release Numebr
        if(RELEASE_NO == ""){
            println("Release No is mandatory")
            validationCheck = "F"
        }
        
		//2. Validate Engine Name
        if(ENGINE_NAME == ""){
            println("Engine name is mandatory")
            validationCheck = "F"
        }
        
        //3. ENVIRONMENT is Mandatory
        if(ENVIRONMENT == ""){
            println("ENVIRONMENT is mandatory")
            validationCheck = "F"
        }
        
        //4. validate Operation_Name
        if(OPERATION_NAME == ""){
            println("Operation Name is mandatory")
            validationCheck = "F"
        }
        else if (OPERATION_NAME.indexOf(' ') != -1){
            println('Operation Name should not contain spaces in between')
            validationCheck = "F"
        }
        else
        {
             Operations = OPERATION_NAME.replaceAll(';',',').split(',')
             println("Operation List --> " + Operations) 
             Operations.each { id ->
                  TestMapResult[id] = ['Reg_Total':'','Reg_Pass':'', 'Reg_Fail':'', 'Reg_Status':'', 'Prog_Total':'','Prog_Pass':'', 'Prog_Fail':'', 'Prog_Status':'', 'TEST_STATUS':'', 'TOTAL_TC' : '']
             }
        }        

        //5. GIT_BRANCH is Mandatory
        if(GIT_BRANCH == ""){
            println("GIT_BRANCH is mandatory")
            validationCheck = "F"
        }        

        if(validationCheck == "F"){
            env.TA_ERROR_CODE = "501"
            env.TA_ERROR_MSG = "Pipeline Input parameter validation failed."
			error("Pipeline Input parameter validation failed. Please check the errors in Console log.")

		}        

}

def download_git_repo()
{
	//Checkout Rit Project
	try {
    checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/${GIT_BRANCH}']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Project"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/RIT_${ENGINE_NAME}.git']]]
    }
    catch(Exception Ex)
    {
        error("Repo (RIT_${ENGINE_NAME}) or Branch (${GIT_BRANCH}) not found")
    }
	
    
	//Checkout Ansible Scripts			
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Script"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
    
    //Checkout Common function Scripts	
	checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'JENKINS_FILE']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_DevOps_Framework.git']]])

	DB_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/dbFunctions.groovy"	
}


def fileStructureCheck()
{
    
    //RIT Repo Exist
    RepoFolder = "${WORKSPACE}/Project"
	if (!fileExists(RepoFolder)) {	
	    env.TA_ERROR_CODE = "516"
        env.TA_ERROR_MSG = ("RIT_${ENGINE_NAME} Repo missing")
        error ("Repository RIT_${ENGINE_NAME} was not found")
    }
    
    //Engine name folder inside RIT Repo
    EngineFolder = "${RepoFolder}/${ENGINE_NAME}"
	if (!fileExists(EngineFolder)) {	
        
		env.TA_ERROR_CODE = "516"
        env.TA_ERROR_MSG = ("${ENGINE_NAME} folder missing inside RIT_${ENGINE_NAME} Repo")
		println ("${ENGINE_NAME} folder missing inside RIT_${ENGINE_NAME} Repo")
        currentBuild.result = 'No RIT Repo available'
		
    }
    
    //Logical folder inside RIT Repo
    LogicalFolder = "${EngineFolder}/Logical"
	if (!fileExists(LogicalFolder)) {	
        
		env.TA_ERROR_CODE = "516"
        env.TA_ERROR_MSG = ("Logical folder missing inside RIT_${ENGINE_NAME} Repo")
		println ("Logical folder missing inside RIT_${ENGINE_NAME} Repo")
        	
    }
    
    //Ant script folder inside RIT Repo
    AntFolder = "${LogicalFolder}/AntScripts"
	if (!fileExists(AntFolder)) {	
        
		env.TA_ERROR_CODE = "516"
        env.TA_ERROR_MSG = ("Ant script folder missing inside RIT_${ENGINE_NAME} Repo")
		println ("Ant script folder missing inside RIT_${ENGINE_NAME} Repo")
    }
    
    AntFilesCheck = true
    //All regression and Progression testcase available for all operation name
    for (operation in Operations) {
        Ant_File_Regression = "${AntFolder}/${ENGINE_NAME}_${operation}_Regression.xml"
        Ant_File_Progression = "${AntFolder}/${ENGINE_NAME}_${operation}_Progression.xml"
        
        TestMapResult[operation]['Reg_Total'] = "0"
        TestMapResult[operation]['Reg_Fail'] = "0"
        TestMapResult[operation]['Reg_Pass'] = "0" 
        TestMapResult[operation]['Reg_Status'] = "NA"        

        TestMapResult[operation]['Prog_Total'] = "0"
        TestMapResult[operation]['Prog_Fail'] = "0"
        TestMapResult[operation]['Prog_Pass'] = "0"
        TestMapResult[operation]['Prog_Status'] = "NA"
            
        if (!fileExists(Ant_File_Regression)) {	
            println("Regression Test xml file missing for operation ${operation}")
            AntFilesCheck = false
            TestMapResult[operation]['Reg_Status'] = "XML MISSING"             
        }
        
        if (ENGINE_TYPE == "New") {	
            println("Engine Type is New. So skipping Progression testing")
            TestMapResult[operation]['Reg_Status'] = "NEW"            
        }
        
        if (!fileExists(Ant_File_Progression)) {	
            println("Progression Test xml file missing for operation ${operation}")
            AntFilesCheck = false
            TestMapResult[operation]['Prog_Status'] = "XML MISSING"
        }
    }
    println("Initial Map --> "  + TestMapResult)
    if(!AntFilesCheck)
        
		//env.TA_ERROR_CODE = "517"
        //env.TA_ERROR_MSG = "Progression or Regression Test case xml file missing in Ant Script folder"
		println ("Progression or Regression Test case xml file missing in Ant Script folder")
    }



def Operations= ""
def date_time= ""
REPORT_URL=""
TESTCASE_REPORT=""
SUBMITTER_EMAIL=""
Status =""
TestMapResult = [:]

        
pipeline {
	agent any
	environment {	

        TA_ERROR_CODE = ""
        TA_ERROR_MSG = ""	


		NEXUS_URL="195.233.197.150:8081"
		NEXUS_VERSION="nexus3"
		RTCP_REPO="TEST_AUTOMATION_REPO"				
		
        RIT_Folder = "/opt/SP/tibco/IBM/RationalIntegrationTester"

        //[CICD-539] Insert Deployment metadata to release notes DB.
		dbURL = 'jdbc:oracle:thin:@195.233.199.13:33000:TIBTST1'
		dbUserName = 'CICD_OWN_DB01'
		dbPassword = 'TIL_CICD_DB'
		dbDriver = 'oracle.jdbc.driver.OracleDriver'
        
	}
	
	stages {
		stage('Preparation') {
		
			steps {
                script {
					cleanWs()
                    env.PIPELINE_URL = "$BUILD_URL"	
                    validate_parameter()
					
					def date = new Date();
					def sdf = new SimpleDateFormat("yyyyMMddHHmmss");
					date_time = sdf.format(date)
					SEQ_NO = "SNO_" + "${date_time}"		
					println "${SEQ_NO}"
                    currentBuild.displayName = "${SEQ_NO}_${RELEASE_NO}_${Engine_Name}_${BUILD_NUMBER}"
                    download_git_repo()                        
                    fileStructureCheck ()
					Preparation ()					

				}
			}
		}
        
        stage('Test Preparation') {		
			steps {
                script {
                    echo "Test Preparation"
                    Test_Preparation()
                }
            }
        }
		
/*		stage('Progression Testing') {
            steps {
                script {
					echo "Progression_Testing"
                    Automation_Testing("Progression")	
				}
			}
		}*/
        
        stage('Regression Testing') {
            when { expression { ENGINE_TYPE == "Existing" || ENGINE_TYPE == "UPDATED" } }
            steps {
                script {
					echo "Regression_Testing"
                    Automation_Testing("Regression")
		
				}
			}
		}
        
		stage('Reporting & CleanUp') {			
			steps {
                script {	
	                Reporting_CleanUp ()
					println " ======>> Reporting & CleanUp <<======"
                }
            }
        }
        
		stage('Log Git Push') {
			steps {
                script {
			
						statusFile = new File("${WORKSPACE}/Result_Log.txt")
						statusContent = statusFile.readLines()													
                        
                        if (statusContent[-1].contains(' RunTests execution ended with code: 0')) {
							Status = "SUCCESS"
						}else {
							Status = "FAILED"
						}
						sh "rm -Rf CODE/"
						
						checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: "*/main"]], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "CODE"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: "https://github.vodafone.com/VFUK-INTEGRATION/RIT_Overnight_Regression_Logs.git"]]]
						sh "if [ -d ./CODE/${ENGINE_NAME} ]; then rm -Rf -v ./CODE/${ENGINE_NAME}; fi;"
						sh "mkdir ./CODE/${ENGINE_NAME}"
						sh "cp  ./*.log ./CODE/${ENGINE_NAME}"
						sh "cp  ./*.txt ./CODE/${ENGINE_NAME}"
						dir("CODE/${ENGINE_NAME}") {
							sh "pwd"
							sh "ls -lrt"							
							sh "git status"
							sh "git add ."
							sh "git commit -m \"Pushing RIT logs\""
							sh "git push origin HEAD:main"							
						}
						emailext  mimeType: 'text/html', attachmentsPattern: '*.log,*.txt',
						subject: "[Jenkins]:${currentBuild.fullDisplayName}:Test_Results - Request Approval",
						from:"Test_Automation@vodafone.com",
						to: "vfukintegrationadtil@vodafone.com;devops-vfuk-integration@vodafone.com",
						//to: "${techLeadmails}",
						body: 	"${get_body_build_summary()}" + 
							"<br><p><b><font size='2' color='Black'>TEST_AUTOMATION_BUILDURL: <a href='${BUILD_URL}input'>${BUILD_URL}</a></font></b></p>"	
				
				}
			}
		}

	}
post {
        always {
				script {
					if ( "${currentBuild.currentResult}" == "SUCCESS") 
                    {
						env.TA_ERROR_CODE = "200"
                        env.TA_ERROR_MSG = "Test Automation Completed"                         
					} 
                    else 
                    {
                        if(env.TA_ERROR_CODE == "" || env.TA_ERROR_CODE == null)
                        {
                            env.TA_ERROR_CODE = "518"
                            env.TA_ERROR_MSG = "TA Execution Failure "
                        }
 					}					 
					//println("Error Code : "+env.TA_ERROR_CODE)
                    //println("Error MSG : "+env.TA_ERROR_MSG)                    
				}
		}    
    }
}
  
