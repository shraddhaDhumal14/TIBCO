import com.cwctravel.hudson.plugins.extended_choice_parameter.ExtendedChoiceParameterDefinition
import java.text.*
import groovy.time.*
import hudson.tasks.Mailer;
import hudson.model.User;
import groovy.json.JsonOutput
import groovy.sql.*
import java.sql.Driver

def getcssContent(){
    def css = """
        <style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Times, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;width:150px;word-break:break-all;border-color:#9ABAD9;color:#444;}
		.tg th{font-family:Times, sans-serif;font-size:26px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:break-all;border-color:#9ABAD9;color:#1A0504;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		.tg .tg-pass{background-color:lightgreen;text-align:left;vertical-align:top}
		.tg .tg-fail{background-color:red;text-align:left;vertical-align:top}
		.tg .tg-notstarted{background-color:lightgrey;text-align:left;vertical-align:top}
		.tg .tg-notrequired{background-color:#E1E0A2;text-align:left;vertical-align:top}
		</style>
        """
     return css
}

def myGetDBConnect() {     
     def dbURL = 'jdbc:oracle:thin:@aukshocr.dc-dublin.de:33000:TIBTST1'
     def dbUserName = 'CICD_OWN_DB01'
     def dbPassword = 'TIL_CICD_DB'
     def dbDriver = 'oracle.jdbc.driver.OracleDriver'
     //displayDebug('myGetDBConnect','Establishing DB Connectivity')
     def mySQL = groovy.sql.Sql.newInstance(dbURL,dbUserName,dbPassword,dbDriver)
     return mySQL                   
}

def myMultipleSelectQuery(selectQuery){     
     def mySQL =  myGetDBConnect()
  	 def rowData = [:]
	 def resultList = []
     //displayDebug('myMultipleSelectQuery',selectQuery)
     def rowResults = mySQL.rows(selectQuery)
     mySQL.close()
     if(rowResults.size() == 0)
            return resultList;
     def headerList = new ArrayList(rowResults[0].keySet())
	 for(def rlcounter=0;rlcounter<rowResults.size();rlcounter++)
     {
         def row = rowResults[rlcounter];
         rowData = [:]
         for(def rwHeaderCnt=0;rwHeaderCnt<headerList.size();rwHeaderCnt++)
         { 
               rowData.put(headerList[rwHeaderCnt], row[rwHeaderCnt]!= null  ? row[rwHeaderCnt].toString() : "")
         }
		 resultList.add(rowData)
     }
	 headerList=null;
	rowResults = null;
	rowData = null;
	mySQL = null;
    return resultList;
}

def fetchvalues()
{   

	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: "main"]], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "ManualAutomation"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: "https://github.vodafone.com/VFUK-INTEGRATION/TIL_Manual_Automation.git"]]]	
	
	sh "cat ${WORKSPACE}/ManualAutomation/RITRegression.txt"
	def counter=0;
	def line;
	def Instance = new File("${WORKSPACE}/ManualAutomation/RITRegression.txt").readLines()	
	for (inst in Instance)
	{
		println "${inst}"
		
		eng_value = inst.split('~')[0]
		env_value = inst.split('~')[1]
		TmpEngineName = eng_value + '_' + env_value				
		DeployedEnginesDetails[TmpEngineName] = ['Engine':'','Release':'','Environment':'','Operations':'','GitBranch':'','Developer':'']				
		DeployedEnginesDetails[TmpEngineName]['Engine']=eng_value
		if (counter == Instance.size()-1)
				EngineId = EngineId +  TmpEngineName
		else
				EngineId = EngineId +  TmpEngineName +","			 
				
		DeployedEnginesDetails[TmpEngineName]['Release']="Overnight"
		DeployedEnginesDetails[TmpEngineName]['Developer']="Automation"

		if(env_value == "LNKTest14")
		{
			DeployedEnginesDetails[TmpEngineName]['Environment']="LNKTEST14"
		}
		else if(env_value == "LNKTest15")
		{
			DeployedEnginesDetails[TmpEngineName]['Environment']="LNKTEST15"
		}
		else if(env_value == "LinkTest")
		{
			DeployedEnginesDetails[TmpEngineName]['Environment']="LNKTEST16"
		}
		else if(env_value == "LNKTst17")
		{
			DeployedEnginesDetails[TmpEngineName]['Environment']="LNKTEST17"
		}
		else
		{
			DeployedEnginesDetails[TmpEngineName]['Environment']=env_value
		}
		counter++;				
	} 				
}	 
 

def checkRitEngine(def tmp_list,def nc_tmp_list,String engine_id)
{   

   def engine = DeployedEnginesDetails[engine_id]['Engine']
	
	sh (script: "curl -H \"Authorization: token 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\" https://github.vodafone.com/api/v3/repos/VFUK-INTEGRATION/RIT_${engine}/branches?per_page=100 >RIT_branches.tmp")
	sh '''
	    set +e
		if [[ -s RIT_main.tmp ]]
		then
			rm -v RIT_main.tmp
		fi
		if [[ -s RIT_master.tmp ]]
		then
			rm -v RIT_master.tmp
		fi
		echo "true" >RIT_repofound.tmp

		if [[ "`jq .message RIT_branches.tmp 2>/dev/null`" == '"Not Found"' ]]
		then
			echo "RIT_${engine} Repo not found" > RIT_release.tmp
			echo "false" >RIT_repofound.tmp
		fi
		
		jq .[].name RIT_branches.tmp > tmp_RIT_branches.tmp
		mv tmp_RIT_branches.tmp RIT_branches.tmp
		
		grep "main" RIT_branches.tmp > RIT_main.tmp
		grep "master" RIT_branches.tmp > RIT_master.tmp
		
		if [[ -s RIT_main.tmp ]]
		then
			echo "main" >RIT_release.tmp
		elif [[ -s RIT_master.tmp ]]
		then
			echo "master" >RIT_release.tmp
		fi
		
	'''
	 branch_name = sh(script: "cat RIT_release.tmp", returnStdout: true).trim()
	 println(branch_name)
	 
	 
	 
	 if (branch_name == "main" || branch_name == "master")
	 { 
        
		sh "rm -Rf RITREPO/"
		
		checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: "${branch_name}"]], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "RITREPO"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: "https://github.vodafone.com/VFUK-INTEGRATION/RIT_${engine}.git"]]]
		
		sh(script: "chmod +x GetRegressionOperationsList.sh; dos2unix GetRegressionOperationsList.sh; ./GetRegressionOperationsList.sh ${engine};")
		sh(script: "cat operation_list")
		def tmpoperation= sh(script: "cat operation_list", returnStdout: true).trim()
		println(tmpoperation.getClass())
		DeployedEnginesDetails[engine_id]['GitBranch']=branch_name
		if (tmpoperation?.trim()) {
					
			println("Engine contains operations")
			println("Operation names ${tmpoperation}")
			DeployedEnginesDetails[engine_id]['Operations']=tmpoperation			
			tmp_list.add(engine_id)
			println("Engine operation ${DeployedEnginesDetails[engine_id]['Operations']}")
		}
		else
		{
			nc_tmp_list.add(engine_id)
			println(nc_tmp_list)
		}
	 }
	 else
	 {   
		println("RIT setup not present in main/master")
		 nc_tmp_list.add(engine_id)
		 println(nc_tmp_list)
	 }
}

def email_test_result_operations()
{
    def test_result_summary = ""
    
    strQuery = "SELECT ENGINE_NAME, OPERATION, ENVIRONMENT, RELEASE_NO, REG_PASS, REG_FAIL, TOTAL_TC, TEST_STATUS, TESTCASE_REPORT_URL, BUILD_ID, DEVELOPER  FROM AUTO_TA_SUMMARY WHERE MAIN_PIPE_ID = ${Main_Id}"
    rowList = myMultipleSelectQuery(strQuery);
    
     def headerList = new ArrayList(rowList[0].keySet())
     
     test_result_summary+="<table class='tg' style='table-layout: fixed; width: 100%'>\n"
     test_result_summary+="<tr>\n"
     for(def rwHeaderCnt=0;rwHeaderCnt<headerList.size();rwHeaderCnt++)
     { 
         test_result_summary+="<th class='tg-amwm'>${headerList[rwHeaderCnt]}</th>\n"
     } 
     test_result_summary+="</tr>\n"
	 for(def rlcounter=0;rlcounter<rowList.size();rlcounter++)
     {
         def row = rowList[rlcounter];
         test_result_summary+="<tr>\n"
         for(def rwHeaderCnt=0;rwHeaderCnt<headerList.size();rwHeaderCnt++)
         { 
            row_value = row[headerList[rwHeaderCnt]]!= null  ? row[headerList[rwHeaderCnt]].toString() : ""
			if(row_value == "FAILED")
			{
				test_result_summary+="<td class='tg-fail'>${row_value}</td>\n"
			}
			else if (row_value == "SUCCESS")
			{
				test_result_summary+="<td class='tg-pass'>${row_value}</td>\n"
			}
			else
			{
				test_result_summary+="<td class='tg-1wig'>${row_value}</td>\n"
			}
                         
         }
         test_result_summary+="</tr>\n"
     }
    
    test_result_summary+="</table>"
    println test_result_summary
    return test_result_summary;
}
def sendEmail(subjectSuffix, mailRecipients)
{
    def body_build_summary = ""  
    
    if(subjectSuffix != "")
    {
        subjectSuffix = "- " + subjectSuffix
    }
    
    
    body_build_summary += getcssContent()
    body_build_summary += email_test_result_operations()     
	body_build_summary += "<br><p><b><font size='2' color='Black'>TEST_AUTOMATION_BUILDURL: <a href='${BUILD_URL}input'>${BUILD_URL}</a></font></b></p>"
        
    emailext mimeType: 'text/html',
    subject: "[Jenkins]: ${subjectSuffix}",
	from:"TIL_Overnight_TA_Automation@vodafone.com",
	to: "${mailRecipients}",
	body: "${body_build_summary}" 
}

EngineId = ""
NcEngineId = ""
Main_Id = ""
Failed_Engine_List = []
// String[] NC_Engine_List
def NC_Engine_List = []
def Engine_List = []
//String[] NC_Engine_List = []

// DeployedEnginesDetails = ["EngineName":"","Release":"","Environment":"","Operations":""]
DeployedEnginesDetails = [:]

pipeline {
	agent any
	environment {
		
		dbURL = 'jdbc:oracle:thin:@195.233.199.13:33000:TIBTST1'
		dbUserName = 'CICD_OWN_DB01'
		dbPassword = 'TIL_CICD_DB'
		dbDriver = 'oracle.jdbc.driver.OracleDriver'
	}
	
	stages {
		stage('Prepration') {
		
			steps {
				script {					
					
					fetchvalues()
					println(EngineId)
					println(DeployedEnginesDetails)
					
					checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'JENKINS_FILE']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_DevOps_Framework.git']]])
					DB_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/dbFunctions.groovy"	
		        }
	        }
		}
		
		stage('Engine Check'){
			steps {
				script {
					
					checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: "main"]], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "CODE"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: "https://github.vodafone.com/VFUK-INTEGRATION/git-hook-test.git"]]]
					
					println(NC_Engine_List.getClass())
					sh "mv ${WORKSPACE}/CODE/GetRegressionOperationsList.sh ${WORKSPACE}"
					println("Stage is working")
					EngineId.split(',').each { tmpengine ->
					 checkRitEngine(Engine_List,NC_Engine_List,tmpengine)
						println(tmpengine)
				    }
					println(NC_Engine_List)
					println(Engine_List)
					Engine_List = Engine_List.unique()
					NC_Engine_List = NC_Engine_List.unique()
					EngineId = Engine_List.join(",")					
					println(DeployedEnginesDetails)
					println(EngineId)
				}					
			}
		}
		stage('RIT Execution'){
			steps {
				script {
					Main_Id = "$BUILD_NUMBER"
					if(EngineId.size() != 0)
					{
						EngineId.split(',').each { tmpengine ->					
						rit_overnight_ta_pipe = build job: '/Automation/RIT_OverNight_Regression_Testing', 
                    		parameters: [
	                                    string(name: 'RELEASE_NO', value: DeployedEnginesDetails[tmpengine]['Release']),
	                                    string(name: 'ENVIRONMENT', value: DeployedEnginesDetails[tmpengine]['Environment']),
	                                    string(name: 'ENGINE_NAME', value: DeployedEnginesDetails[tmpengine]['Engine']),
										string(name: 'OPERATION_NAME', value: DeployedEnginesDetails[tmpengine]['Operations']),
	                                    string(name: 'ENGINE_TYPE', value: "Existing"),
										string(name: 'MAIN_PIPE_ID', value: "${Main_Id}"),
										string(name: 'GIT_BRANCH', value: DeployedEnginesDetails[tmpengine]['GitBranch']),
										string(name: 'DEVELOPER', value: DeployedEnginesDetails[tmpengine]['Developer'])
	                                ], propagate:false
									
						println(rit_overnight_ta_pipe.result + " : ${rit_overnight_ta_pipe.buildVariables.TA_ERROR_CODE}")
						if(rit_overnight_ta_pipe.buildVariables.TA_ERROR_CODE != "200")
						{
							Failed_Engine_List.add(DeployedEnginesDetails[tmpengine]['Engine'])
							string insert_query1="INSERT INTO AUTO_TA_SUMMARY ( RELEASE_NO,  ENGINE_NAME, OPERATION, RIT_BRANCH, ENVIRONMENT, REG_PASS, REG_FAIL, TOTAL_TC, TEST_STATUS, STATUS, CREATED_ON, TESTCASE_REPORT_URL, BUILD_ID,MAIN_PIPE_ID,DEVELOPER) VALUES ( '${DeployedEnginesDetails[tmpengine]['Release']}',  ${DeployedEnginesDetails[tmpengine]['Engine']},'RIT Pipeline Failed', 'main', ${DeployedEnginesDetails[tmpengine]['Environment']}, 0, 0, 0, 'RIT Pipeline Failed', 'RIT_Execution_Failed', sysdate, '', '', ${Main_Id}, ${DeployedEnginesDetails[tmpengine]['Developer']})" 
				
					
						println("DEBUG: AUTO_TA_SUMMARY query is: " + insert_query1)
						DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: insert_query1
						}					
						}
					}
					println(Failed_Engine_List)
					if(NC_Engine_List.size() != 0)
					{
						NcEngineId = NC_Engine_List.join(",")
						NcEngineId.split(',').each { tmpengine ->
						
						string insert_query="INSERT INTO AUTO_TA_SUMMARY ( RELEASE_NO,  ENGINE_NAME, OPERATION, RIT_BRANCH, ENVIRONMENT, REG_PASS, REG_FAIL, TOTAL_TC, TEST_STATUS, STATUS, CREATED_ON, TESTCASE_REPORT_URL, BUILD_ID,MAIN_PIPE_ID,DEVELOPER) VALUES ( '${DeployedEnginesDetails[tmpengine]['Release']}',  ${DeployedEnginesDetails[tmpengine]['Engine']},'RIT setup is not present', 'main', ${DeployedEnginesDetails[tmpengine]['Environment']}, 0, 0, 0, 'RIT setup is not present', 'RIT_Missing', sysdate, '', '', ${Main_Id}, ${DeployedEnginesDetails[tmpengine]['Developer']})" 
				
					
						println("DEBUG: AUTO_TA_SUMMARY query is: " + insert_query)
						DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: insert_query
						
					}
					}
				}
			}		
		}
		
		 stage('Mail Report') {		
			steps {
                script {
                    echo "Mail Report"
					def usermails= "vfukintegrationadtil@vodafone.com;devops-vfuk-integration@vodafone.com"
                    sendEmail("Overnight Regression Report", usermails)
                }
            }
        } 
	}
}
