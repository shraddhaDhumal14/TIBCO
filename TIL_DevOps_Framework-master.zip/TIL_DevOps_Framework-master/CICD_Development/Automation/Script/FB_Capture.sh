#!/bin/bash

release=`echo $1 | cut -b 4-9`
Release_Number=`echo $1 | tr _ .`
echo $Release_Number
echo PROJECTNAME,FEATUREBRANCHREF,LASTCOMMITER > Feature_branch_cleanup.csv


if [ -s Release.csv ]
then
	rm -v Release.csv
fi

if [ -s ISTIL_AppVersion-.csv ]
then
	rm -v ISTIL_AppVersion-.csv
fi

if [ -s Finalbranch.txt ]
then
	rm -v Finalbranch.txt
fi

wget --http-user admin --http-password=admin123 http://195.233.197.150:8081/repository/PROD_CONFIG/ISTIL_AppVersion/ISTIL_AppVersion-.csv
sed -n "/$release/p" ISTIL_AppVersion-.csv >> Release.csv




while read line
do
engine_name=`echo $line | cut -d, -f2`
echo $engine_name
#curl "https://github.vodafone.com/api/v3/repos/$line/branches?access_token=81f1011dc8806aa162d1afb0af39b2a9ca2c918b&page=1&per_page=100" | grep -w "name" | cut -d ':' -f2 |
#curl "https://github.vodafone.com/api/v3/repos/$line/branches?access_token=81f1011dc8806aa162d1afb0af39b2a9ca2c918b&page=1&per_page=100" | egrep -w "name|sha" | sed -e 's/name/@/'| tr -d '\012'| tr -s '@' '\012'|cut -d\" -f3,7|tr -s '"' ',' |
curl -H "Authorization: token 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" "https://github.vodafone.com/api/v3/repos/VFUK-INTEGRATION/TIL_$engine_name/branches?&page=1&per_page=100" | egrep -w "name|sha" | sed -e 's/"name"/@/'| tr -d '\012'| tr -s '@' '\012'|cut -d\" -f2,6|grep [0-9a-zA-Z] | tr -s '"' ',' |
while read line1
do
line_sha=`echo $line1 | cut -d, -f2`
echo $line1
curl -H "Authorization: token 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" "https://github.vodafone.com/api/v3/repos/VFUK-INTEGRATION/TIL_$engine_name/commits/$line_sha" | grep \"login\"| awk '{print $2}'| tr -d '"' | sort | uniq  > user.tmp
login=`cat user.tmp`   
echo $login                                                           #http(s)://HOSTNAME/api/v3/repos/OWNER/REPO/branches
echo $engine_name,$line1,$login>> Finalbranch.txt
done
done < Release.csv

cat Finalbranch.txt | grep -E 'CCS[0-9]{2}\.[0-9]+_([AB]_[^\,]|[AB][^\,]|[^AB])' | cut -d, -f1,2,4> Featurebranch.txt

echo "----------------------------------------------"
echo $Release_Number

grep -E "$Release_Number" Featurebranch.txt | awk -F\" '{print $1,$2,$3}' >> Feature_branch_cleanup.csv

echo "PROJECTNAME,FEATUREBRANCHREF,LASTCOMMITER" > FeatureBkp.csv
sed -n '/bkp/p' Feature_branch_cleanup.csv >> FeatureBkp.csv
sed -n '/Bkp/p' Feature_branch_cleanup.csv >> FeatureBkp.csv
sed -n '/backup/p' Feature_branch_cleanup.csv >> FeatureBkp.csv
sed -n '/Backup/p' Feature_branch_cleanup.csv >> FeatureBkp.csv

grep -v -f FeatureBkp.csv Feature_branch_cleanup.csv > Final_Deletion_List.csv


# mailx -a Final_Deletion_List.csv -s "Feature Branch cleanup action `date`" devansh.patil@vodafone.com,swapnil.dubale@vodafone.com < /opt/tibco/tmp/GitHubAPI/email.txt
