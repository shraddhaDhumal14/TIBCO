#!/bin/bash

while read line
  do
  engine_name=`echo $line | cut -d, -f1` 
  branch_name=`echo $line | cut -d, -f2` 
  echo $engine_name 
  echo $branch_name
  
  curl -X DELETE -H "Authorization: token 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" https://github.vodafone.com/api/v3/repos/VFUK-INTEGRATION/TIL_$engine_name/git/refs/heads/$branch_name

 done < Final_Deletion_List.csv
