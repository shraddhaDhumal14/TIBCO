// Global Parameters to use in the stages.
date_now = new Date().format( 'dd-MM-yyyy' )

//[CICD-507] Insert Deployment metadata to TIL_BUILD_HISTORY DB.
import groovy.json.JsonOutput
import groovy.sql.*
import java.sql.Driver
import groovy.time.*
import jenkins.model.Jenkins


def GitClone(RepoName, TargetDirectory, BranchName )
{
    int retryCount = 0;
    def error = ""
    while (1) 
    {
       if( retryCount > 0 && retryCount % 3 ==0 )
       {
        input 'Proceed or Abort?'      
       }
       try 
	   {
            
            checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: "*/${BranchName}"]], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${TargetDirectory}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: "https://github.vodafone.com/VFUK-INTEGRATION/${RepoName}.git"]]]
            env.BP_ERROR_CODE = ""
			env.BP_ERROR_MSG = ""
            return true
       }
       catch(Exception ex) 
	   {
		    env.BP_ERROR_CODE = "203"
			env.BP_ERROR_MSG = "Github connection failed"
			println(env.BP_ERROR_CODE + " : " +  env.BP_ERROR_MSG)
			println("Github connection failed.")
			currentBuild.result = 'ABORTED'
			
            //println("Exception caught : " + ex + "while downloading Repo " +  RepoName); 
            //error = ex;
            //println("Sleeping for 5 seconds .... Will Retry "+ (retryCount+1))
            //println "Red Alert!! Inform CICD Team ++ Git Error ++ ${error}"
            sleep 5            
        }
        retryCount++
    }     
    return false       
}




// Mail recipents for the individual stages.
def bw_mailRecipients = "${params.BUILD_REQUESTER};j.raghavendra@vodafone.com;gopakumar.achari1@vodafone.com;devansh.patil@vodafone.com"


user = ""
git_leaks_count = ""
git_leaks_array = []

pipeline {
	agent any
	options {
        	timeout(time: 2, unit: 'DAYS')
	}
	
	stages 
	{
		stage('Preparation') 
		{
			steps 
			{
                script
				{					
					env.PIPELINE_URL = "$BUILD_URL"				    
					GitClone("${REPO_NAME}", "TIL_SOURCE_SonarQube", "${params.BranchName}")
					GitClone("TIL_Automation_Framework", "TIL_AUTOMATION", "master")
					echo "Preparation is done"
                }
			}
		}
		stage('GitLeak Scan') 
		{
			steps 
			{
                script
				{
					 echo "Starting GitLeak Scan stage"
					 sh(script:"ssh 10.78.192.62 'rm -rfv /opt/tibco/Mend_GitLeak/Gitleak/TIL_SOURCE_SonarQube || exit 0'")					
					 sh(script:" scp -r TIL_SOURCE_SonarQube 10.78.192.62:/opt/tibco/Mend_GitLeak/Gitleak/")
					 sh(script:"ssh 10.78.192.62 '/opt/tibco/Mend_GitLeak/Gitleak/gitleak_scan.sh; echo gitleak_executed'")
					 echo "Git leak executed success"
					 sh(script:"echo ${WORKSPACE}")					
					 sh(script:"scp 10.78.192.62:/opt/tibco/Mend_GitLeak/Gitleak/output.json ${WORKSPACE}")					 
					 sh(script:"cp TIL_AUTOMATION/BW_Deployment/scripts/GitLeaks_Mend/Parsegitleaks.sh ${WORKSPACE}")					
					 git_leaks_count = sh(script:"grep RuleID output.json | wc -l", returnStdout: true).trim()					
					 sh(script: "chmod +x Parsegitleaks.sh; dos2unix Parsegitleaks.sh; ./Parsegitleaks.sh;")					 

                }					 					
			}
		}		
		
   		stage('Mail Report') 
		{       	
			steps 
			{
				script
				{
					get_body_build_summary = "<p>Hi,<br><br> Please find the detailed attached report includes secrets, vulnerabilities for your repository <b>\"${REPO_NAME}\" in ${params.BranchName} branch</b>.<br> <b> Overall there are ${git_leaks_count} vulnerabilities</b> are found.<br> Please take necessary remedial action before proceeding for your development.<br><br>	Thanks and Regards,<br>	CICD Team <br> </p>"
					
					sh(script:"cp ${WORKSPACE}/output.csv ${WORKSPACE}/Gitleaks_Scan_Report_${REPO_NAME}.csv")
					// This is to compose an email to send the Build Summary along with EAR DIFF.				

					emailext mimeType: 'text/html', attachmentsPattern: "Gitleaks_Scan_Report_${REPO_NAME}.csv",
					subject: "[Jenkins]: GIT LEAKS SCAN REPORT for ${REPO_NAME}",
					from:"TIL_GITLEAKS_SCAN@vodafone.com",
					to: "${bw_mailRecipients}",
					body: "${get_body_build_summary}" 				
				}		
			}						
		}
	}  
}	
