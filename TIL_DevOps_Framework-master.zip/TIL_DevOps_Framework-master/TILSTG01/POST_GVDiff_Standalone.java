// Calling global functions from shared libraries.
//@Library('myLibrary@master') _

//[CICD-476] Fix: import this package as part of the fix
import groovy.time.*

//[CICD-539] Insert Deployment metadata to release notes DB.
import groovy.json.JsonOutput
import groovy.sql.*
import java.sql.Driver
import com.cwctravel.hudson.plugins.extended_choice_parameter.ExtendedChoiceParameterDefinition
import hudson.tasks.Mailer
import hudson.model.User

def POST_GVDiff_Stage(){
	
	release_no=params.RELEASE.replace(".", "_")
	
checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Temp"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: "https://github.vodafone.com/VFUK-INTEGRATION/TIL_DevOps_Framework.git"]]]
							
							dir_loc = sh (script: """pwd""",returnStdout: true).trim()
							println("dir_loc = ${dir_loc}") 
							
							sh(script: "ssh uk2994yr /opt/SP/tibco/bw_deployment/gvoutput.sh ${params.CRQ} ${release_no} ;")
							sh(script: "scp tibco@uk2994yr:/opt/SP/tibco/bw_deployment/${release_no}/GVOUTPUT_${release_no}_${params.CRQ}.txt ${dir_loc}")
														

	// Trigger Result Email
	// Attach Post GV Diff reports in the email while sending deployment status
	emailext mimeType: 'text/html',
	subject: "[Jenkins]: ${currentBuild.fullDisplayName}  - " + "Post GV DIFF Report",
	from:"CICD_ISTILDeploymentStatus@vodafone.com",
	to: "${mailRecipients}",
	body: 	"Post GV DIFF CSV File attachment for ${params.RF}_${params.CRQ}_${params.RELEASE}",
	attachmentsPattern: "**/GVOUTPUT_${release_no}_${params.CRQ}.txt"
	
			FILE="GVOUTPUT_${release_no}_${params.CRQ}.txt"

	nexusArtifactUploader artifacts: [[artifactId: "Standalone_GVOUTPUT__${params.RF}_${params.CRQ}_${params.RELEASE}_${TimeStamp}", classifier: '', file: "${FILE}", type: 'txt']], credentialsId: '74edde97-94e0-403c-93f6-cad6c46c45f8', groupId: "POST_GV_DIFF/Standalone", nexusUrl: "${NEXUS_URL1}", nexusVersion: "${NEXUS_VERSION}", repository: "TEST_REPO", protocol: 'http'
	
}


mailRecipients = "srishty.sinha@vodafone.com,sweety.kumari@vodafone.com,shivam.pandey2@vodafone.com,aakansha.singh@vodafone.com,atul.kumar5@vodafone.com"
date_now = " "
emailBody = " "

// Pipeline parameters.
FolderName = ""
nexusFunc = ""
emailFunc = ""
mapFunc = ""
user = ""


import groovy.json.JsonOutput

pipeline {
    agent any
	options {
        preserveStashes(buildCount: 49)
    }

    environment {
		TimeStamp=new Date().format("YYYYMMddHHmmss")
		REPO_URL = "http://195.233.197.150:8081/repository"
		NEXUS_URL = "http://195.233.197.150:8081"
		NEXUS_URL1 = "195.233.197.150:8081" 
		NEXUS_USER = "admin"
		NEXUS_PASSWD = "admin123"
		NEXUS_VERSION="nexus3" 
		Promotion_Repo = "PROD_REPO"		
		}

   stages {
		stage('POST_GVDiff') {
			steps {
				script{
						POST_GVDiff_Stage()
                }				
			}			
		}
			}
}
