// Calling global functions from shared libraries.
//@Library('myLibrary@master') _

//[CICD-476] Fix: import this package as part of the fix
import groovy.time.*

//[CICD-539] Insert Deployment metadata to release notes DB.
import groovy.json.JsonOutput
import groovy.sql.*
import java.sql.Driver
import com.cwctravel.hudson.plugins.extended_choice_parameter.ExtendedChoiceParameterDefinition
import hudson.tasks.Mailer
import hudson.model.User

//[CICD-476] Fix: function to get elapsed time duration 
def elapsedTime(Closure closure){
    def timeStart = new Date()
    closure()
    def timeStop = new Date()
    return TimeCategory.minus(timeStop, timeStart).toMilliseconds()
}


def trigger_results_email(deployParams){
	// This function is to trigger an email for the provided map.
	emailext mimeType: 'text/html',
	subject: "[Jenkins]: ${currentBuild.fullDisplayName}  - " + "Upliftment Results Summary",
	from:"CICD_ISTILDeploymentStatus@vodafone.com",
	to: "${mailRecipients}",
	body: 	"${emailFunc.get_results_email_summary map: deployParams.map, REPORT_STAGE: deployParams.REPORT_STAGE}" 
}

def trigger_versions_email(deployParams){
	// This function is to trigger an email for the provided map.
	emailext mimeType: 'text/html',
	 subject: "[Jenkins]: Upliftment Engines Version Summary",
	 from:"CICD_ISTILDeploymentStatus@vodafone.com",
	 to: "${mailRecipients}",
	 body: 	"${emailFunc.get_engine_versions_summary map: deployParams.map, REPORT_STAGE: deployParams.REPORT_STAGE, Target_Env: params.Target_Env}" 
}

// Funcation to Get jenkins users from the given role
def get_approvers_list(String str){
	outlist = sh (script: """cat /opt/tibco/.jenkins/config.xml | sed -n \'/role name=\"${str}\"/,\$p\' | sed \'/role>/q\' | grep "sid" | cut -d \'>\' -f 2 | cut -d \'<\' -f 1 | paste -s -d, -""",
			returnStdout: true).trim()
	return """${outlist}"""
}


def load_groovy_files() {
	// This function is to load all groovy files, where in common functions will be kept.
	emailFunc = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/emailFunctions.groovy"
	mapFunc = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/mapFunctions.groovy"
	nexusFunc = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/nexusFunctions.groovy"
	gitFunc = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/gitFunctions.groovy"
	EMS_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/EMSFunctions.groovy"
	SQL_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/SQLFunctions.groovy"
	BW_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/BWFunctions.groovy"
	FILE_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/FileFunctions.groovy"
	commonFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/commonFunctions.groovy"
	//[CICD-539] Insert Deployment metadata to release notes DB.
	DB_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/dbFunctions.groovy"	
}

def checkout_git_repositories() {
	// This function is to checkout all the required GIT repositories.
	// Checkout Environment configurations.
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "ENV"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Production_Configuration.git']]]
	
	// Checkout Automation files from GITHUB repository.
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "automation"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
	
	
	checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'JENKINS_FILE']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_DevOps_Framework.git']]])	
}

def construct_maps() {
	
	// Construct map by getting all the engines and versions from Nexus and validating each version.
	def BW_Versions = nexusFunc.get_engines_from_nexus target_repo: "${env.UPLIFTMENT_REF_REPO}", REPO_URL: "${env.NEXUS_URL}", GROUPID: "${env.BW_GROUPID}", version: "${majorVersion}_${minorVersion}", extn: "ear" 
	if(BW_Versions){
		mapFunc.generate_map inputString:BW_Versions, map:BW_Engine_Snap
	
		// Validate BW engine versions against facts file 
		mapFunc.validate_map_from_facts map: BW_Engine_Snap, type: "bw", target_env: "${params.Target_Env}_BW", release: RELEASE   
		println(BW_Engine_Snap)
	} else {
		println("DEBUG: There are no BW engines for deployment")
	}
	
	// --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//
	
	// Append only GV chnages as well to BW_Versions.
	if(OnlyGV_Engines != ""){
		def OnlyGV_Versions = ""
		OnlyGV_Engines.split(';').each { engine ->
			OnlyGV_Versions = OnlyGV_Versions + engine + ':' + "0" + ';'
			OnlyGV_Engine_Type[engine] = "OnlyGV"
		}
		if(OnlyGV_Versions) {
			mapFunc.generate_map inputString:OnlyGV_Versions, map:OnlyGV_Engine_Snap
			//BW_Versions = BW_Versions + OnlyGV_Versions.substring(0, OnlyGV_Versions.length() - 1)
		}
	}	
	
	// --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//

	def EMS_Versions = nexusFunc.get_engines_from_nexus target_repo: "${env.UPLIFTMENT_REF_REPO}", REPO_URL: "${env.NEXUS_URL}", GROUPID: "${env.EMS_GROUPID}", version: "${majorVersion}_${minorVersion}", extn: "tar.gz" 
	if(EMS_Versions){
		mapFunc.generate_map inputString:EMS_Versions, map:EMS_Engine_Snap
	
		// Validate EMS engine versions against facts file 
		mapFunc.validate_map_from_facts map: EMS_Engine_Snap, type: "ems", target_env: "${params.Target_Env}", release: RELEASE   
		println(EMS_Engine_Snap)
	} else {
		println("DEBUG: There are no EMS engines for deployment")
	}

	//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//					
	def SQL_Versions = nexusFunc.get_engines_from_nexus target_repo: "${env.UPLIFTMENT_REF_REPO}", REPO_URL: "${env.NEXUS_URL}", GROUPID: "${env.SQL_GROUPID}", version: "${majorVersion}_${minorVersion}", extn: "tar.gz"
	if(SQL_Versions) {
		mapFunc.generate_map inputString:SQL_Versions, map:SQL_Engine_Snap
	
		// Validate EMS engine versions against facts file 
		mapFunc.validate_map_from_facts map: SQL_Engine_Snap, type: "sql", target_env: "${params.Target_Env}", release: RELEASE
		println(SQL_Engine_Snap)
	}  else {
		println("DEBUG: There are no SQL engines for deployment")
	}
	
	
	// Get deploymnet type , whether its new or existing engine for each engine
	if(BW_Engine_Snap.size() != 0) {
		def type_string = nexusFunc.get_bw_deployment_type engines: "${BW_Engine_Snap.keySet().join(';')}", target_env: "${params.Target_Env}"
		mapFunc.generate_map inputString:type_string, map:BW_Type_Snap
		println(BW_Type_Snap)
	} else {
		println("DEBUG: There are no BW engines for deployment and no need to get deployment types.")
	}

	// Construct File maps for deployment. Assumption is file templates are available at BW_Configurations repository.
// [CICD-1783]: Fix , instead of use_tag, pass BW_Engine_Snap , so that function will consider the BW_Version while getting the file tag.
	if(BW_Engine_Snap.size() != 0 || params.OnlyFile_Engines) {
		
		//[CICD-311]: Fix to handle only file deploy engines as well.
		if(BW_Engine_Snap.size() != 0 && params.OnlyFile_Engines){
			fileDeployEngines = params.OnlyFile_Engines + ';' + BW_Engine_Snap.keySet().join(';')
		} 
		else if(BW_Engine_Snap.size() == 0){
			fileDeployEngines = params.OnlyFile_Engines
		}
		else{
			fileDeployEngines = BW_Engine_Snap.keySet().join(';')
		}
	   //[CICD-311]: Fix to handle only file deploy engines as well.
		def XML_Files = gitFunc.getEngineFiles engines: "${fileDeployEngines}", type: "XML", env: "${params.Target_Env}", RELEASE: "${params.RELEASE}", map: BW_Engine_Snap
		if(XML_Files){
			mapFunc.generate_map inputString:XML_Files, map:XML_Files_Snap
			println(XML_Files_Snap)
		} else {
			println("DEBUG: There are no XML files to deploy")
		}
	
		//[CICD-311]: Fix to handle only file deploy engines as well.
		def JAR_Files = gitFunc.getEngineFiles engines: "${fileDeployEngines}", type: "Jar", env: "${params.Target_Env}", RELEASE: "${params.RELEASE}", map: BW_Engine_Snap
		if(JAR_Files) {
			mapFunc.generate_map inputString:JAR_Files, map:JAR_Files_Snap
			println(JAR_Files_Snap)
		}
		
		//[CICD-311]: Fix to handle only file deploy engines as well.
		def Email_Files = gitFunc.getEngineFiles engines: "${fileDeployEngines}", type: "Email", env: "${params.Target_Env}", RELEASE: "${params.RELEASE}", map: BW_Engine_Snap
		if(Email_Files){
			mapFunc.generate_map inputString:Email_Files, map:EMAIL_Files_Snap
			println(EMAIL_Files_Snap)					
		}
		
	} else {
		println("DEBUG: No BW Engines for deployment and no file deployments as well.")
	}


	//[CICD-355 Fix]: Moving the following two sections here to avoid Only GV change engines picking file deployment.
	
	// Combine ONLY GV chnage BW engines to have single map.
	BW_Engine_Snap = BW_Engine_Snap + OnlyGV_Engine_Snap
	BW_Type_Snap = BW_Type_Snap + OnlyGV_Engine_Type
	
	
	
	// Get folder name for each of the BW engine.
	if(BW_Engine_Snap.size() != 0) {
		def folder_string = gitFunc.get_bw_folder_name_from_gvconf engines_map: BW_Engine_Snap
		if(folder_string) {
			mapFunc.generate_map inputString:folder_string, map:BW_Folder_Snap
			println(BW_Folder_Snap)
		}
	} else {
		println("DEBUG: There are no BW engines for deployment and no need to get any folders")
	}
	
	
	// Adding Restart Engines for Common SQL SQL_Restart_Engine_Snap
	// CICD-330
	
	if(SQL_Engine_Snap.containsKey("Common_SQL_Changes")){
		
		SQL_Restart_Engines = input(
			id: 'SQL_Restart_Engines',
			message: 'Please Provide list of Engines to be restarted for Common SQL Scripts separated by;', 
			parameters: [
						[$class: 'TextParameterDefinition', defaultValue: '', description: 'Engines for Common SQL Scripts', name: 'CommonEngines_List'],
			])
		println("DEBUG: SQL Restart engines are wuith SQL_Restart_Engines:" + SQL_Restart_Engines)
	
		if(SQL_Restart_Engines.length() != 0){
		def SQL_Restart_Versions = ""
		SQL_Restart_Engines.split(';').each { engine ->
			if(! BW_Engine_Snap.containsKey(engine)){
			 SQL_Restart_Versions = SQL_Restart_Versions + engine + ':' + "1" + ';'
			}
		}
			mapFunc.generate_map inputString:SQL_Restart_Versions, map:SQL_Restart_Engine_Snap
	  }
			
	} 
	

	// Construct versions master map.
	// CICD-330
	Engines_Map = BW_Engine_Snap + EMS_Engine_Snap + SQL_Engine_Snap + BW_Folder_Snap + BW_Type_Snap + XML_Files_Snap + JAR_Files_Snap + EMAIL_Files_Snap + SQL_Restart_Engine_Snap
	def engineKeys = Engines_Map.keySet()
	
	//[CICD-476] && [CICD-374] Fix: Added BW, EMS and SQL Duration fields to the map.
	//[CICD-977] Fix: Added DB_ROW_ID field to the map to get the exact row id of the inserted record in DB and update subsequent stage results (RB status and RF2 Status)
	Engines_Map.each { key, value ->
		VERSIONS_MAP[key] = ['BW_VERSION':'NA', 'BW_FOLDER_NAME':'NA', 'BW_ENGINE_TYPE':'NA', 'EMS_VERSION':'NA', 'SQL_VERSION':'NA', 'XML_FILES':'NA', 'JAR_FILES':'NA', 'EMAIL_FILES':'NA', 'RESULT':'NA', 'RF1_RESULT':'NA', 'RF2_RESULT':'NA', 'RB_RESULT':'NA', 'BW_Generation':'NOT_REQUIRED', 'SQL_Deployment':'NOT_REQUIRED', 'EMS_Deployment':'NOT_REQUIRED', 'XML_Deployment':'NOT_REQUIRED', 'JAR_Deployment':'NOT_REQUIRED', 'EMAIL_Deployment':'NOT_REQUIRED', 'BW_Deployment':'NOT_REQUIRED',  'BW_Restart':'NOT_STARTED', 'EMS_DURATION':'0', 'SQL_DURATION':'0', 'BW_DURATION':'0', 'FILE_DURATION':'0', 'DB_ROW_ID':'0']
	}
	
	if(BW_Engine_Snap.size() != 0){
		mapFunc.init_versions_map map: VERSIONS_MAP, type: 'BW', input_map: BW_Engine_Snap
	}
	if(EMS_Engine_Snap.size() != 0){ 
		mapFunc.init_versions_map map: VERSIONS_MAP, type: 'EMS', input_map: EMS_Engine_Snap 
	}
	if(SQL_Engine_Snap.size() != 0){
		mapFunc.init_versions_map map: VERSIONS_MAP, type: 'SQL', input_map: SQL_Engine_Snap
	}
	if(BW_Folder_Snap.size() != 0){
		mapFunc.init_versions_map map: VERSIONS_MAP, type: 'BW_FOLDER', input_map: BW_Folder_Snap
	}
	if(BW_Type_Snap.size() != 0){
		mapFunc.init_versions_map map: VERSIONS_MAP, type: 'BW_TYPE', input_map: BW_Type_Snap
	}
	if(XML_Files_Snap.size() != 0){
		mapFunc.init_versions_map map: VERSIONS_MAP, type: 'XML_FILES', input_map: XML_Files_Snap
	}
	if(JAR_Files_Snap.size() != 0){
		mapFunc.init_versions_map map: VERSIONS_MAP, type: 'JAR_FILES', input_map: JAR_Files_Snap
	}
	if(EMAIL_Files_Snap.size() != 0){
		mapFunc.init_versions_map map: VERSIONS_MAP, type: 'EMAIL_FILES', input_map: EMAIL_Files_Snap
	}					
	
	
	// display VERSIONS MAP
	mapFunc.display_master_map map: VERSIONS_MAP
	
	// Initialize all the values for RESULTS_MAP
	
	// UPDATE Results map based on the versions given as input.
	
	if(BW_Engine_Snap.size() != 0){
		mapFunc.init_results_map map: VERSIONS_MAP, type: 'BW', engines: "${BW_Engine_Snap.keySet().join(';')}"
	}
	if(EMS_Engine_Snap.size() != 0){ 
		mapFunc.init_results_map map: VERSIONS_MAP, type: 'EMS', engines: "${EMS_Engine_Snap.keySet().join(';')}" 
	}
	if(SQL_Engine_Snap.size() != 0){
		mapFunc.init_results_map map: VERSIONS_MAP, type: 'SQL', engines: "${SQL_Engine_Snap.keySet().join(';')}" 
	}
	if(XML_Files_Snap.size() != 0){
		mapFunc.init_results_map map: VERSIONS_MAP, type: 'XML', engines: "${XML_Files_Snap.keySet().join(';')}"
	}
	if(JAR_Files_Snap.size() != 0){
		mapFunc.init_results_map map: VERSIONS_MAP, type: 'JAR', engines: "${JAR_Files_Snap.keySet().join(';')}"
	}
	if(EMAIL_Files_Snap.size() != 0){
		mapFunc.init_results_map map: VERSIONS_MAP, type: 'EMAIL', engines: "${EMAIL_Files_Snap.keySet().join(';')}" 
	}
	
	
	
	// Remove Coomon_SQL_Engines from Deployment if it is already added.
	// CICD-330
	/*if(VERSIONS_MAP.containsKey("Common_SQL_Changes")){
			VERSIONS_MAP.remove('Common_SQL_Changes')
	}*/
	// Updating bw deployment type and version for only sql changed engines 
	// CICD-330 : Adding common sql engine functionality 		
	only_sql_deployment_engines = VERSIONS_MAP.findAll { it.value['BW_VERSION'] == "NA" && it.value['SQL_VERSION'] != "NA" }
	only_sql_deployment_engines.keySet().each { engi ->
	         if(engi == "Common_SQL_Changes") {
				if(SQL_Restart_Engine_Snap.size() != 0){
					
					SQL_Restart_Engine_Snap.keySet().each { engine ->
						
						bw_folder = gitFunc.get_engine_bw_folder_name_from_gvconf engine: engine
						
						if(bw_folder){
							VERSIONS_MAP[engine]['BW_FOLDER_NAME'] =  bw_folder
						} else {
							error("Check the engine name and Folder name in GV conf for proper format")
						}
						VERSIONS_MAP[engine]['BW_VERSION'] = "1"
				        VERSIONS_MAP[engine]['BW_ENGINE_TYPE'] = "RESTART"
						VERSIONS_MAP[engine]['BW_Restart'] = "NOT_STARTED"
					  }
					}
			 } 
			 else {
				bw_folder = gitFunc.get_engine_bw_folder_name_from_gvconf engine: engi
				if(bw_folder){
					VERSIONS_MAP[engi]['BW_FOLDER_NAME'] =  bw_folder
				} else {
					error("Check the engine name and Folder name in GV conf for proper format")
				}
				VERSIONS_MAP[engi]['BW_VERSION'] = "1"
				VERSIONS_MAP[engi]['BW_ENGINE_TYPE'] = "RESTART"
				VERSIONS_MAP[engi]['BW_Restart'] = "NOT_STARTED"
			 }
		}
		
	//[CICD-311]: Fix to handle only file deploy engines as well.

   if (OnlyFile_Engines){
       
	   OnlyFile_Engines.split(';').each { bw_engine ->
	   
	      bw_folder = gitFunc.get_engine_bw_folder_name_from_gvconf engine: bw_engine
				if(bw_folder){
					VERSIONS_MAP[bw_engine]['BW_FOLDER_NAME'] =  bw_folder
				} else {
					error("Check the engine name and Folder name in GV conf for proper format")
				}
				VERSIONS_MAP[bw_engine]['BW_VERSION'] = "1"
				VERSIONS_MAP[bw_engine]['BW_ENGINE_TYPE'] = "RESTART"
	     
	   }
   }
   
  // Change the folder names as per TILSTG01 and production formats.
	
	VERSIONS_MAP.each { pl_engine, pl_version ->
		if(VERSIONS_MAP[pl_engine]['BW_FOLDER_NAME'] == "SB01"){
			VERSIONS_MAP[pl_engine]['BW_FOLDER_NAME'] = "ServiceBus1"
		}
		if(VERSIONS_MAP[pl_engine]['BW_FOLDER_NAME'] == "SB02") {
			VERSIONS_MAP[pl_engine]['BW_FOLDER_NAME'] = "ServiceBus2"
		}
		if(VERSIONS_MAP[pl_engine]['BW_FOLDER_NAME'] == "SB03") {
			VERSIONS_MAP[pl_engine]['BW_FOLDER_NAME'] = "ServiceBus3"
		}
	}
	
	// Moving this block to prepartion function
/* 	def group_engine_type_maps = VERSIONS_MAP.findAll { it.value['BW_VERSION'] != "NA" }.groupBy({ engine -> engine.value['BW_ENGINE_TYPE'] })
	group_engine_type_maps.each { g_type_key, g_type_value ->
			def group_engine_type_folder_maps = g_type_value.groupBy({ engine -> engine.value['BW_FOLDER_NAME'] })
			group_engine_type_folder_maps.each{ g_type_folder_key, g_type_folder_value ->
				def counter = 1
				def gID = 1
				g_type_folder_value.each { g_type_folder_value_key, g_type_folder_value_value ->
					VERSIONS_MAP[g_type_folder_value_key]['GROUP_ID'] = g_type_key + '_' + g_type_folder_key + '_' + gID
					if(counter < 5){
						counter++
					} else {
						counter = 0
						gID++ 
					}
				}
			}
	} */
	
}

// Function for BW Restart

def bw_restart_stage(){ 

def restartMode = input(
	   message: 'Choose BW Restart Mode',
	   parameters: [
		 [$class: 'ChoiceParameterDefinition',
		  choices: ['Manual','Automation'].join('\n'),
		  name: 'input',
		  description: 'Select Restart Mode']
		])
if ("$restartMode" == "Automation"){                
				 
	//Group versios map with groupid and run deploy step in target host 
	def BW_Deploy_group_maps = VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['BW_VERSION'] != "NA" }.groupBy({ engine -> engine.value['GROUP_ID'] })
	BW_Deploy_group_maps.each { patteren_string, BW_Deploy_group ->
		eng_ver_map = BW_Deploy_group.collectEntries {bw_engine, bw_version -> [bw_engine, bw_version['BW_VERSION']]}
		String engines_versions = mapFunc.convert_map_to_string engine_map:eng_ver_map
		println("DEBUG:" + engines_versions)
		String engines_list = "${eng_ver_map.keySet().join(';')}"
		println("DEBUG:" + engines_list)
		
		echo "DEBUG: pattern string is: ${patteren_string}"
		if(patteren_string.toString() != "null") {
			BW_type = patteren_string.split('_')[0]
			echo "DEBUG: BW_type is: ${BW_type}"
			BW_Folder = patteren_string.split('_')[1]
			group_id = patteren_string.split('_')[2]
			// Calling Restart Function
			BW_Functions.bw_restart Host:"${params.Target_Env}", crq_no:"${params.CRQ}", datetime:"${date_now}", bw_folder_release:bw_release_num, engine_group:patteren_string, folderName:BW_Folder, engines_list_restart:engines_list
		} 
	  }
	// Check if BW Restart file exists for Failures
	def bw_restart_failed_file = "${WORKSPACE}/${params.Target_Env}/BW_Deployment/restart_failure.txt"
	if(fileExists(bw_restart_failed_file)) {
		def bw_restart_failed_ouput = readFile("${WORKSPACE}/${params.Target_Env}/BW_Deployment/restart_failure.txt")
		if (bw_restart_failed_ouput.size() != 0) {
		    // Reading Restart Failure
			def failed_file = new File("${WORKSPACE}/${params.Target_Env}/BW_Deployment/restart_failure.txt")
			def failed_engines_list = failed_file.readLines().join(';')
			  
			failed_engines_list.split(';').each { bw_engine ->
				if(VERSIONS_MAP.containsKey(bw_engine)) {
					// CICD1684 - removing updating Result Map with Failed status
					//VERSIONS_MAP[bw_engine]['RESULT'] = "FAILED"
					VERSIONS_MAP[bw_engine]['BW_Restart'] = "FAILED"
				}
			}
			
			// Email Restart Faileed Engines
			trigger_results_email map: VERSIONS_MAP, REPORT_STAGE: "BW_Restart"
			

            // If any failures with restart ask for User Input
			def rollbackMode = input(
			message: 'Proceed with Rollback for restart failed engines ?',
			parameters: [
			   [$class: 'ChoiceParameterDefinition',
			   choices: ['Yes','No'].join('\n'),
			   name: 'input',
			   description: 'Choose Rollback for restart failed engines']
			])
			   
			if ("$rollbackMode" == "Yes"){
				// CICD1684 - updating Result Map with Failed status when rollback is selected
				failed_engines_list.split(';').each { bw_engine ->
				if(VERSIONS_MAP.containsKey(bw_engine)) {
					VERSIONS_MAP[bw_engine]['RESULT'] = "FAILED"
				}
				}
				
				// Taking backup of CRQ for rollback failed engines
				
				def BW_rollback_group_maps_prep = VERSIONS_MAP.findAll { it.value['RESULT'] == "FAILED" && it.value['BW_VERSION'] != "NA" }.groupBy({ engine -> engine.value['GROUP_ID'] })
				BW_rollback_group_maps_prep.each { patteren_string_config, BW_Rollback_Config ->
					eng_ver_map_config = BW_Rollback_Config.collectEntries {bw_engine, bw_version -> [bw_engine, bw_version['BW_VERSION']]}
					String engines_versions = mapFunc.convert_map_to_string engine_map:eng_ver_map_config
					println("DEBUG:" + engines_versions)
					String engines_list = "${eng_ver_map_config.keySet().join(';')}"
					println("DEBUG:" + engines_list)
					
					echo "DEBUG: pattern string is: ${patteren_string_config}"
					if(patteren_string_config.toString() != "null") {
						BW_type = patteren_string_config.split('_')[0]
						echo "DEBUG: BW_type is: ${BW_type}"
						BW_Folder = patteren_string_config.split('_')[1]
						group_id = patteren_string_config.split('_')[2]
						// Calling Rollback config generate Function
						BW_Functions.bw_rollback_config_prep Host:"${params.Target_Env}", crq_no:"${params.CRQ}", datetime:"${date_now}", bw_folder_release:bw_release_num, engine_group:patteren_string_config, folderName:BW_Folder
				  } 
				}
				
				 // Identifying engines and remove config for rollback 
			    def BW_rollback_group_maps_config = VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['BW_VERSION'] != "NA" }.groupBy({ engine -> engine.value['GROUP_ID'] })
				BW_rollback_group_maps_config.each { patteren_string_config, BW_Rollback_Config ->
					eng_ver_map_config = BW_Rollback_Config.collectEntries {bw_engine, bw_version -> [bw_engine, bw_version['BW_VERSION']]}
					String engines_versions = mapFunc.convert_map_to_string engine_map:eng_ver_map_config
					println("DEBUG:" + engines_versions)
					String engines_list = "${eng_ver_map_config.keySet().join(';')}"
					println("DEBUG:" + engines_list)
					
					echo "DEBUG: pattern string is: ${patteren_string_config}"
					if(patteren_string_config.toString() != "null") {
						BW_type = patteren_string_config.split('_')[0]
						echo "DEBUG: BW_type is: ${BW_type}"
						BW_Folder = patteren_string_config.split('_')[1]
						group_id = patteren_string_config.split('_')[2]
						// Calling Rollback config generate Function
						BW_Functions.bw_rollback_config_generate Host:"${params.Target_Env}", crq_no:"${params.CRQ}", datetime:"${date_now}", engines_list:"${engines_list}", removeConfig:true, bw_folder_release:bw_release_num, engine_group:patteren_string_config, folderName:BW_Folder
				  } 
				}
			  
			    // Identifying engines for rollback 
			    def BW_rollback_group_maps = VERSIONS_MAP.findAll { it.value['RESULT'] == "FAILED" && it.value['BW_VERSION'] != "NA" }.groupBy({ engine -> engine.value['GROUP_ID'] })
				BW_rollback_group_maps.each { patteren_string, BW_Deploy_group ->
					eng_ver_map = BW_Deploy_group.collectEntries {bw_engine, bw_version -> [bw_engine, bw_version['BW_VERSION']]}
					String engines_versions = mapFunc.convert_map_to_string engine_map:eng_ver_map
					println("DEBUG:" + engines_versions)
					String engines_list = "${eng_ver_map.keySet().join(';')}"
					println("DEBUG:" + engines_list)
					
					echo "DEBUG: pattern string is: ${patteren_string}"
					if(patteren_string.toString() != "null") {
						BW_type = patteren_string.split('_')[0]
						echo "DEBUG: BW_type is: ${BW_type}"
						BW_Folder = patteren_string.split('_')[1]
						group_id = patteren_string.split('_')[2]
						
						//Calling Rollback Function
						 BW_Functions.bw_rollback Host:"${params.Target_Env}", crq_no:"${params.CRQ}", datetime:"${date_now}", bw_folder_release:bw_release_num, engine_group:patteren_string, folderName:BW_Folder, EnvironmentRepository: "${env.EnvironmentRepository}", engines_list:engines_list
						
							
					} 
				}
			}
			else {
				echo "Skipped Restart Rollback Based on selection"
				
			}								
		}							
	}
		
		// Reading restart successful engines file 
		def bw_restart_success_file = "${WORKSPACE}/${params.Target_Env}/BW_Deployment/restart_success.txt"
	    if(fileExists(bw_restart_success_file)) {
			  def bw_restart_success_ouput = readFile("${WORKSPACE}/${params.Target_Env}/BW_Deployment/restart_success.txt")
			  def success_file = new File("${WORKSPACE}/${params.Target_Env}/BW_Deployment/restart_success.txt")
			  def success_engines_list = success_file.readLines().join(';')
			  success_engines_list.split(';').each { bw_engine ->
					if(VERSIONS_MAP.containsKey(bw_engine)) {
						VERSIONS_MAP[bw_engine]['BW_Restart'] = "PASSED"
					}
			   }
		}
	
	}
	else{
		
		// Manual Restart Selected
		def BW_restart_manual_maps = VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['BW_VERSION'] != "NA" }.collectEntries {restart_engine, restart_version -> [restart_engine, restart_version['BW_VERSION']]}
        BW_restart_manual_maps.keySet().each { bw_engine ->
			if(VERSIONS_MAP.containsKey(bw_engine)) {
                VERSIONS_MAP[bw_engine]['BW_Restart'] = "MANUAL"
			}
       }
	   
	   // Input for manual restart failed engine list

		def failedEngineList = input(
			id: 'failedEngineList',
			message: 'Please Provide list of Engines failed during manual restart separated by ;', 
			parameters: [
						[$class: 'TextParameterDefinition', defaultValue: '', description: 'List of engines failed during manual restart', name: 'failedEngineList'],
			])
			
		if(failedEngineList){	
			
		   // Update maps with manual restart failed engines
		   mapFunc.update_version_map_result map: VERSIONS_MAP, engines: failedEngineList, stage: "BW_Restart", status:"FAILED"
		   //CICD-330 - Fix to fail status  
		   mapFunc.update_version_map_result map: VERSIONS_MAP, engines: failedEngineList, stage: "RESULT", status:"FAILED"
			//println(VERSIONS_MAP)
		}

	}

	//CICD-330 - Fix for common sql changes
	SQL_Restart_Engine_Snap.keySet().each { engine ->
		if(VERSIONS_MAP[engine]['BW_Restart'] == "FAILED"){
			VERSIONS_MAP['Common_SQL_Changes']['RESULT'] == "FAILED"
		}
    }	
}

// Function to clean deployment workspace and setup deployment tool
def clean_deployment_workspace(){

def BW_cleanup_group_maps = VERSIONS_MAP.findAll { it.value['BW_VERSION'] != "NA" }.groupBy({ engine -> engine.value['GROUP_ID'] })
	BW_cleanup_group_maps.each { patteren_string, BW_cleanup_group ->
	eng_ver_map = BW_cleanup_group.collectEntries {bw_engine, bw_version -> [bw_engine, bw_version['BW_VERSION']]}
	
	if(patteren_string.toString() != "null") {
		BW_type = patteren_string.split('_')[0]
		echo "DEBUG: BW_type is: ${BW_type}"
		BW_Folder = patteren_string.split('_')[1]
		group_id = patteren_string.split('_')[2]
		
		//calling Cleanup Function
		BW_Functions.bw_cleanUp Host:"${params.Target_Env}", crq_no:"${params.CRQ}", datetime:"${date_now}", release:"${params.RELEASE}", folderName:BW_Folder, bw_folder_release:bw_release_num, engine_group:patteren_string
		
	  } 
	}

   // creating BW Deployment tool for future use
	BW_Functions.bw_create_deployment_tool Host:"${params.Target_Env}", crq_no:"${params.CRQ}", datetime:"${date_now}", release:"${params.RELEASE}", bw_folder_release:bw_release_num, EnvPrefix:"${Env_Prefix}"	

}	
	

// Function for RF BW Deployment
def RF_bw_deployment_stage(){ 

// First get list of engines failed in earlier stages from which we need to delete BW_Configs
	bw_delete_config = VERSIONS_MAP.findAll { it.value['RESULT'] == "FAILED" && it.value['BW_VERSION'] != "NA" }.groupBy({ engine -> engine.value['GROUP_ID'] })
	bw_delete_config.each { patteren_string, BW_Delete_group ->
		// construct folder name, BW_TYpe, group_id and other details from pattern string and call remove config job.
		println("DEBUG: BW Delete Config engines for group:" + patteren_string)
		println("DEBUG:" + BW_Delete_group)
		remove_engines_list = BW_Delete_group.keySet().join(';')
		if(patteren_string.toString() != "null") {
			BW_type = patteren_string.split('_')[0]
			echo "DEBUG: BW_type is: ${BW_type}"
			BW_Folder = patteren_string.split('_')[1]
			group_id = patteren_string.split('_')[2]
			BW_Functions.bw_remove_config Host:"${params.Target_Env}", crq_no:"${params.CRQ}", datetime:"${date_now}", engines_list:"${remove_engines_list}", bw_folder_release:bw_release_num, engine_group:patteren_string, folderName:BW_Folder
		
		} else {
			echo "Nothing to remove from config"
		}
	}
	
	echo "DEBUG: Get List of engines for BW Deployment"
		
	//Group versios map with groupid and run deploy step in target host 
	def BW_Deploy_group_maps = VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['BW_VERSION'] != "NA" }.groupBy({ engine -> engine.value['GROUP_ID'] })
	BW_Deploy_group_maps.each { patteren_string, BW_Deploy_group ->
		eng_ver_map = BW_Deploy_group.collectEntries {bw_engine, bw_version -> [bw_engine, bw_version['BW_VERSION']]}
		String engines_versions = mapFunc.convert_map_to_string engine_map:eng_ver_map
		println("DEBUG:" + engines_versions)
		String engines_list = "${eng_ver_map.keySet().join(';')}"
		println("DEBUG:" + engines_list)
		
		echo "DEBUG: pattern string is: ${patteren_string}"
		if(patteren_string.toString() != "null") {
			BW_type = patteren_string.split('_')[0]
			echo "DEBUG: BW_type is: ${BW_type}"
			BW_Folder = patteren_string.split('_')[1]
			group_id = patteren_string.split('_')[2]
		} else {
			BW_type = "None"
		}
		
		if(BW_type == "Existing"){
						
			println("DEBUG:" + group_id + "Deploy engines of type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list + " and engine version string is: " + engines_versions)
						
			// Run BW deploy function
			 BW_Functions.bw_deploy Host:"${params.Target_Env}", crq_no:"${params.CRQ}", engines:engines_versions, datetime:"${date_now}", engines_list:engines_list, appDynamics:false, FolderName:BW_Folder, release:"${params.RELEASE}", onlyGVChange:false, deployment_type:"ExistingEngines", bw_folder_release:bw_release_num, engine_group:patteren_string, EnvironmentRepository: "${env.EnvironmentRepository}"

		} else if(BW_type == "New") {
			println("DEBUG:" + group_id + "Deploy engines of type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list + " and engine version string is: " + engines_versions)
						
			// Run BW deploy function
			BW_Functions.bw_deploy Host:"${params.Target_Env}", crq_no:"${params.CRQ}", engines:engines_versions, datetime:"${date_now}", engines_list:engines_list, appDynamics:false, FolderName:BW_Folder, release:"${params.RELEASE}", onlyGVChange:false, deployment_type:"NewEngines", bw_folder_release:bw_release_num, engine_group:patteren_string, EnvironmentRepository: "${env.EnvironmentRepository}"

		} else if (BW_type == "OnlyGV") {
			println("DEBUG:" + group_id + "Deploy engines of type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list + " and engine version string is: " + engines_versions)
						
			// Run BW deploy function
			BW_Functions.bw_deploy Host:"${params.Target_Env}", crq_no:"${params.CRQ}", engines:engines_versions, datetime:"${date_now}", engines_list:engines_list, appDynamics:false, FolderName:BW_Folder, release:"${params.RELEASE}", onlyGVChange:true, deployment_type:"ExistingEngines", bw_folder_release:bw_release_num, engine_group:patteren_string, EnvironmentRepository: "${env.EnvironmentRepository}"
						
		} else {
			println("DEBUG: Invalid Deployment type Identified. Nothing to deploy")
		}

		// Updating maps for failed engines
		
		def bw_deployment_failed_file = "${WORKSPACE}/${params.Target_Env}/BW_Deployment/deployment_failure.txt"
		if(fileExists(bw_deployment_failed_file)) {
			def bw_deployment_failed_ouput = readFile("${WORKSPACE}/${params.Target_Env}/BW_Deployment/deployment_failure.txt")
			if (bw_deployment_failed_ouput.size() != 0) {
				def failed_file = new File("${WORKSPACE}/${params.Target_Env}/BW_Deployment/deployment_failure.txt")
				def failed_engines_list = failed_file.readLines().join(';')
				mapFunc.update_version_map_result map: VERSIONS_MAP, engines: failed_engines_list, stage: "BW_Deployment", status:"FAILED"
			}
		}

	 // Updating maps for engine engines

		def bw_deployment_success_file = "${WORKSPACE}/${params.Target_Env}/BW_Deployment/deployment_success.txt"
		if(fileExists(bw_deployment_success_file)) {
			def bw_deployment_success_ouput = readFile("${WORKSPACE}/${params.Target_Env}/BW_Deployment/deployment_success.txt")
			if (bw_deployment_success_ouput.size() != 0) {
				def success_file = new File("${WORKSPACE}/${params.Target_Env}/BW_Deployment/deployment_success.txt")
				def success_engines_list = success_file.readLines().join(';')
				mapFunc.update_version_map_result map: VERSIONS_MAP, engines: success_engines_list, stage: "BW_Deployment", status:"PASSED"
			}
		}
		trigger_results_email map: VERSIONS_MAP, REPORT_STAGE: "${patteren_string}_BW_Deployment"
		//[CICD-340]: Fix. Changed looping and input parameter.
		// Check deployment and hawk status
		def userInput1 = input(
			  id: 'userInput1', message: "BW Deployment of  Engines in ${patteren_string} are completed.Please validate and proceed for next deployments",
			  submitterParameter: 'submitter'
			)		

	}
	//[CICD-1522]: Attach GV Diff reports in the email while sending deployment status
	emailext mimeType: 'text/html',
	subject: "[Jenkins]: ${currentBuild.fullDisplayName}  - " + "Upliftment Results Summary",
	from:"CICD_ISTILDeploymentStatus@vodafone.com",
	to: "${mailRecipients}",
	body: 	"${emailFunc.get_sit_results_email_summary map: VERSIONS_MAP, REPORT_STAGE: 'BW_Deployment'}",
	attachmentsPattern: "**/${params.Target_Env}/BW_Deployment/GV_DIFF_SUMMARY/*.html"
	//[CICD-1522]: Changes END	
	
}

// RB BW Deployment Stage

def RB_bw_deployment_stage(){
   // First get list of engines failed in earlier stages from which we need to delete BW_Configs
	bw_delete_config = VERSIONS_MAP.findAll { it.value['RESULT'] == "FAILED" && it.value['BW_VERSION'] != "NA" && it.value['BW_VERSION'] != "1" }.groupBy({ engine -> engine.value['GROUP_ID'] })
	bw_delete_config.each { patteren_string, BW_Delete_group ->
		// construct folder name, BW_TYpe, group_id and other details from pattern string and call remove config job.
		println("DEBUG: BW Delete Config engines for group:" + patteren_string)
		println("DEBUG:" + BW_Delete_group)
		remove_engines_list = BW_Delete_group.keySet().join(';')
		if(patteren_string.toString() != "null") {
			BW_type = patteren_string.split('_')[0]
			echo "DEBUG: BW_type is: ${BW_type}"
			BW_Folder = patteren_string.split('_')[1]
			group_id = patteren_string.split('_')[2]
			BW_Functions.bw_remove_config Host:"${params.Target_Env}", crq_no:"${params.CRQ}", datetime:"${date_now}", engines_list:"${remove_engines_list}", bw_folder_release:bw_release_num, engine_group:patteren_string, folderName:BW_Folder
		
		} else {
			echo "Nothing to remove from config"
		}
		
	}
	
	echo "DEBUG: Get List of engines for BW Deployment"
	
	// Get list of engines for BW_Deployment.
	
	//Group versios map with groupid and run deploy step in target host 
	def BW_Deploy_group_maps = VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['BW_VERSION'] != "NA" && it.value['BW_VERSION'] != "1" }.groupBy({ engine -> engine.value['GROUP_ID'] })
	BW_Deploy_group_maps.each { patteren_string, BW_Deploy_group ->
		eng_ver_map = BW_Deploy_group.collectEntries {bw_engine, bw_version -> [bw_engine, bw_version['BW_VERSION']]}
		String engines_versions = mapFunc.convert_map_to_string engine_map:eng_ver_map
		println("DEBUG:" + engines_versions)
		String engines_list = "${eng_ver_map.keySet().join(';')}"
		println("DEBUG:" + engines_list)
		
		echo "DEBUG: pattern string is: ${patteren_string}"
		if(patteren_string.toString() != "null") {
			BW_type = patteren_string.split('_')[0]
			echo "DEBUG: BW_type is: ${BW_type}"
			BW_Folder = patteren_string.split('_')[1]
			group_id = patteren_string.split('_')[2]
		} else {
			BW_type = "None"
		}
		
						
			println("DEBUG:" + group_id + "Deploy engines of type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list + " and engine version string is: " + engines_versions)
						
			// Run BW RB Rollback function
			
			 BW_Functions.bw_rollback_RB Host:"${params.Target_Env}", crq_no:"${params.CRQ}", datetime:"${date_now}", bw_folder_release:bw_release_num, engine_group:patteren_string, folderName:BW_Folder, EnvironmentRepository: "${env.EnvironmentRepository}", engines_list:engines_list
		



		// Updating maps for failed engines
		
		def bw_deployment_failed_file = "${WORKSPACE}/${params.Target_Env}/BW_Deployment/rb_deployment_failure.txt"
		if(fileExists(bw_deployment_failed_file)) {
			def bw_deployment_failed_ouput = readFile("${WORKSPACE}/${params.Target_Env}/BW_Deployment/rb_deployment_failure.txt")
			if (bw_deployment_failed_ouput.size() != 0) {
				def failed_file = new File("${WORKSPACE}/${params.Target_Env}/BW_Deployment/rb_deployment_failure.txt")
				def failed_engines_list = failed_file.readLines().join(';')
				mapFunc.update_version_map_result map: VERSIONS_MAP, engines: failed_engines_list, stage: "BW_Deployment", status:"FAILED"
			}
		}

		trigger_results_email map: VERSIONS_MAP, REPORT_STAGE: "${patteren_string}_RB_BW_Deployment"
		// Check deployment and hawk status
		//[CICD-340]: Fix , changed looping and input location.
		def userInput1 = input(
			  id: 'userInput1', message: "BW Rollcak of  Engines in ${patteren_string} are completed.Please validate and proceed for next deployments",
			  submitterParameter: 'submitter'
			)		
	}
	
}

def artefact_promotion_stage(){

def BW_PROMOTE_MAPS = VERSIONS_MAP.findAll { it.value['RESULT'] == "PASSED" && it.value['BW_VERSION'] != "NA" && it.value['BW_VERSION'] != "1" && it.value['BW_VERSION'] != "0" }.collectEntries {promote_bw_engine, promote_bw_version -> [promote_bw_engine, promote_bw_version['BW_VERSION']]}
	def EMS_PROMOTE_MAPS = VERSIONS_MAP.findAll { it.value['RESULT'] == "PASSED" && it.value['EMS_VERSION'] != "NA" }.collectEntries {promote_ems_engine, promote_ems_version -> [promote_ems_engine, promote_ems_version['EMS_VERSION']]}
	def SQL_PROMOTE_MAPS = VERSIONS_MAP.findAll { it.value['RESULT'] == "PASSED" && it.value['SQL_VERSION'] != "NA" }.collectEntries {promote_sql_engine, promote_sql_version -> [promote_sql_engine, promote_sql_version['SQL_VERSION']]}


	// Promote EMS artefacts to PROD_REPO.
	EMS_PROMOTE_MAPS.each { ems_promote_eng, ems_promote_ver ->

		// Call artefacts promotion function with these details.
		artifactPromotion artifactId: ems_promote_eng, classifier: '', debug: true, extension: 'tar.gz', groupId: "${env.EMS_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.Promotion_Repo}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.UPLIFTMENT_REF_REPO}", stagingUser: "${env.NEXUS_USER}", version: ems_promote_ver
		
		artifactPromotion artifactId: ems_promote_eng, classifier: '', debug: true, extension: 'txt', groupId: "${env.EMS_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.Promotion_Repo}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.UPLIFTMENT_REF_REPO}", stagingUser: "${env.NEXUS_USER}", version: ems_promote_ver
		
	}

	// Promote EMS artefacts to PROD_REPO.
	SQL_PROMOTE_MAPS.each { sql_promote_eng, sql_promote_ver ->

		// Call artefacts promotion function with these details.
		artifactPromotion artifactId: sql_promote_eng, classifier: '', debug: true, extension: 'tar.gz', groupId: "${env.SQL_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.Promotion_Repo}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.UPLIFTMENT_REF_REPO}", stagingUser: "${env.NEXUS_USER}", version: sql_promote_ver
		
		artifactPromotion artifactId: sql_promote_eng, classifier: '', debug: true, extension: 'txt', groupId: "${env.SQL_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.Promotion_Repo}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.UPLIFTMENT_REF_REPO}", stagingUser: "${env.NEXUS_USER}", version: sql_promote_ver
		
					
	}

	// Promote EMS artefacts to PROD_REPO.
	BW_PROMOTE_MAPS.each { bw_promote_eng, bw_promote_ver ->

		// Call artefacts promotion function with these details.
		artifactPromotion artifactId: bw_promote_eng, classifier: '', debug: true, extension: 'ear', groupId: "${env.BW_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.Promotion_Repo}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.UPLIFTMENT_REF_REPO}", stagingUser: "${env.NEXUS_USER}", version: bw_promote_ver
		
		artifactPromotion artifactId: bw_promote_eng, classifier: '', debug: true, extension: 'appconf', groupId: "${env.BW_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.Promotion_Repo}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.UPLIFTMENT_REF_REPO}", stagingUser: "${env.NEXUS_USER}", version: bw_promote_ver
		
		artifactPromotion artifactId: bw_promote_eng, classifier: '', debug: true, extension: 'html', groupId: "${env.BW_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.Promotion_Repo}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.UPLIFTMENT_REF_REPO}", stagingUser: "${env.NEXUS_USER}", version: bw_promote_ver
		
		artifactPromotion artifactId: bw_promote_eng, classifier: '', debug: true, extension: 'proddiff', groupId: "${env.BW_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.Promotion_Repo}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.UPLIFTMENT_REF_REPO}", stagingUser: "${env.NEXUS_USER}", version: bw_promote_ver
		
		artifactPromotion artifactId: bw_promote_eng, classifier: '', debug: true, extension: 'txt', groupId: "${env.BW_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.Promotion_Repo}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.UPLIFTMENT_REF_REPO}", stagingUser: "${env.NEXUS_USER}", version: bw_promote_ver
	}
   echo "PROMOTION STAGE Completed."

}

def ems_rf_deployment_stage(){

// run BW_Generation stage with existing loogic.
	// Get list of engines for EMS deployment.
	ems_map = VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['EMS_VERSION'] != "NA" }
	ems_ver_map = ems_map.collectEntries {ems_map_key, ems_map_value -> [ems_map_key, ems_map_value['EMS_VERSION']]}
	String ems_versions = mapFunc.convert_map_to_string engine_map:ems_ver_map
	println("DEBUG:" + ems_versions)					
	
	// Call ems deploy function by providing Environment Details and engines
	EMS_Functions.ems_deployment Environment:"${params.Target_Env}", crq_no:"${params.CRQ}", ems_engines:"${ems_versions}", datetime:"${date_now}", release:"${params.RELEASE}", emsIgnore:"${env.emsIgnore}", rollbackBackup:false
 
	// Update Maps with Successful engines
 	def ems_deployment_success_file = "${WORKSPACE}/EMS_Deploy_${params.Target_Env}/EMS_Deployment/deploy_success.txt"
	if(fileExists(ems_deployment_success_file)) {
		def ems_deployment_success_ouput = readFile("${WORKSPACE}/EMS_Deploy_${params.Target_Env}/EMS_Deployment/deploy_success.txt")
		if (ems_deployment_success_ouput.size() != 0) {
			def success_file = new File("${WORKSPACE}/EMS_Deploy_${params.Target_Env}/EMS_Deployment/deploy_success.txt")
			def ems_success_engines_list = success_file.readLines().join(';')
			mapFunc.update_version_map_result map: VERSIONS_MAP, engines: ems_success_engines_list, stage: "EMS_Deployment", status:"PASSED"
		}
	}
	
	// Update Maps with failed engines
	
	def ems_deployment_failed_file = "${WORKSPACE}/EMS_Deploy_${params.Target_Env}/EMS_Deployment/deploy_failure.txt"
	if(fileExists(ems_deployment_failed_file)) {
		def ems_deployment_failed_ouput = readFile("${WORKSPACE}/EMS_Deploy_${params.Target_Env}/EMS_Deployment/deploy_failure.txt")
		if (ems_deployment_failed_ouput.size() != 0) {
			def failed_file = new File("${WORKSPACE}/EMS_Deploy_${params.Target_Env}/EMS_Deployment/deploy_failure.txt")
			def ems_failed_engines_list = failed_file.readLines().join(';')
			mapFunc.update_version_map_result map: VERSIONS_MAP, engines: ems_failed_engines_list, stage: "EMS_Deployment", status:"FAILED"
		}
	}

}

def file_rf_deployment_stage(){

// Identify Engines for XML Deployment and proceed with deployment.
		xml_map = VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['XML_FILES'] != "NA" }
		if(xml_map.size() != 0) {
			xml_ver_map = xml_map.collectEntries {xml_map_key, xml_map_value -> [xml_map_key, xml_map_value['XML_FILES']]}
			//Defect fixed for the issue observed in TILSTG01
			xml_engines = mapFunc.convert_map_to_string engine_map: xml_ver_map
			FILE_Functions.deploy_files Host:"${params.Target_Env}", Deployment_Type: "XML_Files", file_snap: xml_engines, crq_no:"${params.CRQ}", datetime:"${date_now}" 
			echo "XML deployment is done."
			// Update master report map with status for successful engine
			echo "DEBUG: SUCCESSFUL ENGINES FROM XML_DEPLOYMENT: ${xml_ver_map.keySet().join(';')}"
			mapFunc.update_version_map_result map: VERSIONS_MAP, engines: "${xml_ver_map.keySet().join(';')}", stage: "XML_Deployment", status:"PASSED"
		} else {
		echo "DEBUG: There are no Engines for XML File Deployment."
		}

		// Identify Engines for JAR Deployment and proceed with deployment.
		jar_map = VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['JAR_FILES'] != "NA" }
		if(jar_map.size() != 0) {
			jar_ver_map = jar_map.collectEntries {jar_map_key, jar_map_value -> [jar_map_key, jar_map_value['JAR_FILES']]}
			//Defect fixed for the issue observed in TILSTG01
			jar_engines = mapFunc.convert_map_to_string engine_map: jar_ver_map
			FILE_Functions.deploy_files Host:"${params.Target_Env}", Deployment_Type: "JAR_Files", file_snap: jar_engines, crq_no:"${params.CRQ}", datetime:"${date_now}" 
			echo "JAR deployment is done."
			// Update master report map with status for successful engine
			echo "DEBUG: SUCCESSFUL ENGINES FROM JAR_DEPLOYMENT: ${jar_ver_map.keySet().join(';')}"
			mapFunc.update_version_map_result map: VERSIONS_MAP, engines: "${jar_ver_map.keySet().join(';')}", stage: "JAR_Deployment", status:"PASSED"
		} 
		else {
		 echo "DEBUG: There are no Engines for JAR File Deployment."
		}

		// Identify Engines for EMAIL Deployment and proceed with deployment.
		email_map = VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['EMAIL_FILES'] != "NA" }
		if(email_map.size() != 0) {
			email_ver_map = email_map.collectEntries {email_map_key, email_map_value -> [email_map_key, email_map_value['EMAIL_FILES']]}
			//Defect fixed for the issue observed in TILSTG01
			email_engines = mapFunc.convert_map_to_string engine_map: email_ver_map
			FILE_Functions.deploy_files Host:"${params.Target_Env}", Deployment_Type: "EMAIL_Files", file_snap: email_engines, crq_no:"${params.CRQ}", datetime:"${date_now}" 
			echo "EMAIL deployment is done."
			// Update master report map with status for successful engine
			echo "DEBUG: SUCCESSFUL ENGINES FROM EMAIL_DEPLOYMENT: ${email_ver_map.keySet().join(';')}"
			mapFunc.update_version_map_result map: VERSIONS_MAP, engines: "${email_ver_map.keySet().join(';')}", stage: "EMAIL_Deployment", status:"PASSED"
		} 
		else {
		 echo "DEBUG: There are no Engines for EMAIL File Deployment."
		}				
	}

def bw_generate_stage(){
	
//Checkout Environment Configurations
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "ENV"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Production_Configuration.git']]]
	
	// checkout Release templates repository
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Release_Repo"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Production_Configuration.git']]]
	
	// Construct Description for engine
	//def user = currentBuild.rawBuild.causes[0].userId
	//println(user);
	
	//[CICD-519]: Fix to handle special characters in Description part
	String desc = "${params.Description}".replaceAll(/(!|"|@|#|\$|%|&|\\/|\(|\)|=|\?)/, /\\$0/)
	desc = desc + "|" + "${user}"		
	
	//def desc = "${params.Description}".trim() + "|" + "${user}"
	//println(desc); 
	//Group versios map with groupid and generate bw configuration in target host 
	def BW_Deploy_group_maps = VERSIONS_MAP.groupBy({ engine -> engine.value['GROUP_ID'] })

	BW_Deploy_group_maps.each { patteren_string, BW_Deploy_group ->
		eng_ver_map = BW_Deploy_group.collectEntries {bw_engine, bw_version -> [bw_engine, bw_version['BW_VERSION']]}
		String engines_versions = mapFunc.convert_map_to_string engine_map:eng_ver_map
		println("DEBUG:" + engines_versions)
		String engines_list = "${eng_ver_map.keySet().join(';')}"
		println("DEBUG:" + engines_list)
		
		echo "DEBUG: pattern string is: ${patteren_string}"
		if(patteren_string.toString() != "null") {
			BW_type = patteren_string.split('_')[0]
			echo "DEBUG: BW_type is: ${BW_type}"
			BW_Folder = patteren_string.split('_')[1]
			group_id = patteren_string.split('_')[2]
		} else {
			BW_type = "None"
		}
		
		
		if(BW_type == "Existing"){
			
			println("DEBUG:" + group_id + "Generate conf file for type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list + " and engine version string is: " + engines_versions)
			
			BW_Functions.generate_conf_files_existing_engines engines:engines_versions, Host:"${params.Target_Env}", ReleaseNumber:"${params.RELEASE}", folderName:BW_Folder, description:"${desc}"
			
			BW_Functions.generate_bw_deployment Host:"${params.Target_Env}", nexus_group_id:"${env.BW_GROUPID}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.UPLIFTMENT_REF_REPO}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CRQ}", engines:engines_versions, datetime:"${date_now}", engines_list:engines_list, EnvPrefix:"${Env_Prefix}", deployment_type:"EXISTING", release:"${params.RELEASE}", onlyGVChange:false, folderName:BW_Folder, bw_folder_release:bw_release_num, engine_group:patteren_string
		} else if(BW_type == "New") {
			
			println("DEBUG:" + group_id + "Generate conf file for type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list + " and engine version string is: " + engines_versions)
			BW_Functions.generate_conf_files_new_engines engines:engines_versions, Host:"${params.Target_Env}", ReleaseNumber:"${params.RELEASE}", folderName:BW_Folder, description:"${desc}", instanceCount:"${env.BW_InstanceCount}"
			// Call generate function by passing details
			
			BW_Functions.generate_bw_deployment Host:"${params.Target_Env}", nexus_group_id:"${env.BW_GROUPID}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.UPLIFTMENT_REF_REPO}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CRQ}", engines:engines_versions, datetime:"${date_now}", engines_list:engines_list, EnvPrefix:"${Env_Prefix}", deployment_type:"NEW", release:"${params.RELEASE}", onlyGVChange:false, folderName:BW_Folder, bw_folder_release:bw_release_num, engine_group:patteren_string
		} else if (BW_type == "OnlyGV") {
			
			println("DEBUG:" + group_id + "Generate conf file for type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list + " and engine version string is: " + engines_versions)
			BW_Functions.generate_conf_files_gv_change_description engines:engines_versions, Host:"${params.Target_Env}", ReleaseNumber:"${params.RELEASE}", folderName:BW_Folder, description:"${desc}", nexus_url:"${env.NEXUS_URL}", nexus_repo_id:"${env.UPLIFTMENT_REF_REPO}", nexus_group_id:"${env.BW_GROUPID}" 
			
			// Call generate function by passing details
			BW_Functions.generate_bw_deployment Host:"${params.Target_Env}", nexus_group_id:"${env.BW_GROUPID}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.UPLIFTMENT_REF_REPO}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CRQ}", engines:engines_versions, datetime:"${date_now}", engines_list:engines_list, EnvPrefix:"${Env_Prefix}", deployment_type:"EXISTING", release:"${params.RELEASE}", onlyGVChange:true, folderName:BW_Folder, bw_folder_release:bw_release_num, engine_group:patteren_string
			
		} 
		else if (BW_type == "RESTART") {
			
			println("DEBUG:" + group_id + "Generate conf file for type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list)
			BW_Functions.generate_conf_files_restart engines:engines_versions, Host:"${params.Target_Env}", ReleaseNumber:"${params.RELEASE}", folderName:BW_Folder, description:"${desc}"
			
			// Call generate function by passing details
			BW_Functions.generate_bw_restart Host:"${params.Target_Env}", crq_no:"${params.CRQ}", datetime:"${date_now}", engines_list:engines_list, deployment_type:"EXISTING", folderName:BW_Folder, bw_folder_release:bw_release_num, engine_group:patteren_string
			
		}else {
			println("DEBUG: Invalid Deployment type Identified. Please fix this issue")
		}
	}
	
	// Update maps with failed engines from BW Generate
	def bw_generate_failed_file = "${WORKSPACE}/${params.Target_Env}/BW_Deployment/generate_failure.txt"
	if(fileExists(bw_generate_failed_file)) {
		def bw_generate_failed_ouput = readFile("${WORKSPACE}/${params.Target_Env}/BW_Deployment/generate_failure.txt")
		if (bw_generate_failed_ouput.size() != 0) {
			def failed_file = new File("${WORKSPACE}/${params.Target_Env}/BW_Deployment/generate_failure.txt")
			def failed_engines_list = failed_file.readLines().join(';')
			mapFunc.update_version_map_result map: VERSIONS_MAP, engines: failed_engines_list, stage: "BW_Generation", status:"FAILED"
		}
	} 

	// Update maps with success engines from BW Generate
	def bw_generate_success_file = "${WORKSPACE}/${params.Target_Env}/BW_Deployment/generate_success.txt"
	if(fileExists(bw_generate_success_file)) {
		def bw_generate_success_ouput = readFile("${WORKSPACE}/${params.Target_Env}/BW_Deployment/generate_success.txt")
		if (bw_generate_success_ouput.size() != 0) {
			def success_file = new File("${WORKSPACE}/${params.Target_Env}/BW_Deployment/generate_success.txt")
			def success_engines_list = success_file.readLines().join(';')
			mapFunc.update_version_map_result map: VERSIONS_MAP, engines: success_engines_list, stage: "BW_Generation", status:"PASSED"
		}
	}
	
	// Trigger Result Email
	//780325 Changes
	//trigger_results_email map: VERSIONS_MAP, REPORT_STAGE: "BW_Generate"
	// Attach Pre GV Diff reports in the email while sending deployment status
	emailext mimeType: 'text/html',
	subject: "[Jenkins]: ${currentBuild.fullDisplayName}  - " + "Upliftment Results Summary",
	from:"CICD_ISTILDeploymentStatus@vodafone.com",
	to: "${mailRecipients}",
	body: 	"${emailFunc.get_sit_results_email_summary map: VERSIONS_MAP, REPORT_STAGE: 'BW_Generate'}",
	attachmentsPattern: "**/${params.Target_Env}/BW_Deployment/GV_GENDIFF_SUMMARY/*.html"
	// 780325 Changes END
	
	//--------------------------------[CICD-590:] Fix Begins Here---------------------------------------------------------------------------------------------------------------------
	bw_ignore_map = VERSIONS_MAP.findAll { it.value['BW_Generation'] == "PASSED" }
	if(bw_ignore_map.size() != 0) {
			//[CICD-590]: Provide an option to ignore engines after BW generation step. 
			def ignore_after_bw_generate = input(
				id: 'ignore_after_bw_generate',
				message: 'Please Provide list of Engines to be ignored from Deployment separated by ;', 
				parameters: [
							[$class: 'TextParameterDefinition', defaultValue: '', description: 'Ignore Engines List', name: 'Engines_Ignore_List'],
				])
				
			// First set the status to IGNORE for all the given engines to be ignored.
			if(ignore_after_bw_generate.size() != 0){
				ignore_after_bw_generate.split(';').each { bw_engine ->
					if(VERSIONS_MAP.containsKey(bw_engine)) {
						VERSIONS_MAP[bw_engine]['RESULT'] = "IGNORE"
					}
				}
			}
			
			// Now delete the configs generated in workspace for all the engines for which RESULT is set as IGNORE.
			bw_delete_config = VERSIONS_MAP.findAll { it.value['RESULT'] == "IGNORE" && it.value['BW_VERSION'] != "NA" }.groupBy({ engine -> engine.value['GROUP_ID'] })
			bw_delete_config.each { patteren_string, BW_Delete_group ->
				// construct folder name, BW_TYpe, group_id and other details from pattern string and call remove config job.
				println("DEBUG: BW Delete Config engines for group:" + patteren_string)
				println("DEBUG:" + BW_Delete_group)
				remove_engines_list = BW_Delete_group.keySet().join(';')
				if(patteren_string.toString() != "null") {
					BW_type = patteren_string.split('_')[0]
					echo "DEBUG: BW_type is: ${BW_type}"
					BW_Folder = patteren_string.split('_')[1]
					group_id = patteren_string.split('_')[2]
					BW_Functions.bw_remove_config Host:"${params.Target_Env}", crq_no:"${params.CRQ}", datetime:"${date_now}", engines_list:"${remove_engines_list}", bw_folder_release:bw_release_num, engine_group:patteren_string, folderName:BW_Folder
				
				} else {
					echo "Nothing to remove from config"
				}
			}
			
			//Remove engines listed as IGNORE from Map.
			if(ignore_after_bw_generate){
				mapFunc.remove_engines_from_maps engine_maps: [VERSIONS_MAP], engines_list: ignore_after_bw_generate
				println(VERSIONS_MAP)
			}
			
			// Trigger Result Email
			trigger_results_email map: VERSIONS_MAP, REPORT_STAGE: "BW_Generate_after_ignore"
	}
	//--------------------------------[CICD-590:] Fix Ends Here---------------------------------------------------------------------------------------------------------------------
	
	
	def userInput = input(
	  id: 'userInput', message: 'Proceed with RF1 Deployment?',
	  submitterParameter: 'submitter'
	)
	

}	
		
def RB_File_Deployment_Stage(){
	// This function is file deployemnet for roll back stage.
						 
	// Identify Engines for XML Rollback as part of Rollback stage.
	xml_rb_map = VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['XML_Deployment'] == "PASSED" }
	if(xml_rb_map.size() != 0) {
		xml_rb_ver_map = xml_rb_map.collectEntries {xml_rb_map_key, xml_rb_map_value -> [xml_rb_map_key, xml_rb_map_value['XML_FILES']]}
		//Defect fixed for the issue observed in TILSTG01
		xml_rb_engines = mapFunc.convert_map_to_string engine_map: xml_rb_ver_map		
		FILE_Functions.rollback_files Host:"${params.Target_Env}", Deployment_Type: "XML_Files", file_snap: xml_rb_engines, crq_no:"${params.CRQ}", datetime:"${date_now}" 
		echo "XML Rollback is done."
	} else {
		echo "DEBUG: There are no Engines for XML rollback"
	}

	// Identify Engines for JAR Deployment and proceed with deployment.
	jar_rb_map = VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['JAR_Deployment'] == "PASSED" }
	if(jar_rb_map.size() != 0) {
		jar_rb_ver_map = jar_rb_map.collectEntries {jar_rb_map_key, jar_rb_map_value -> [jar_rb_map_key, jar_rb_map_value['JAR_FILES']]}
		//Defect fixed for the issue observed in TILSTG01
		jar_rb_engines = mapFunc.convert_map_to_string engine_map: jar_rb_ver_map		
		FILE_Functions.rollback_files Host:"${params.Target_Env}", Deployment_Type: "JAR_Files", file_snap: jar_rb_engines, crq_no:"${params.CRQ}", datetime:"${date_now}" 
		echo "JAR Rollback is done."
		
	} else {
		echo "DEBUG: There are no Engines for JAR File rollback"
	}
	
	// Identify Engines for EMAIL Deployment and proceed with deployment.
	email_rb_map = VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['EMAIL_FILES'] == "PASSED" }
	if(email_rb_map.size() != 0) {
		email_rb_ver_map = email_rb_map.collectEntries {email_rb_map_key, email_rb_map_value -> [email_rb_map_key, email_rb_map_value['EMAIL_FILES']]}
		//Defect fixed for the issue observed in TILSTG01
		email_rb_engines = mapFunc.convert_map_to_string engine_map: email_rb_ver_map		
		FILE_Functions.rollback_files Host:"${params.Target_Env}", Deployment_Type: "EMAIL_Files", file_snap: email_rb_engines, crq_no:"${params.CRQ}", datetime:"${date_now}" 
		echo "EMAIL Rollback is done."
	} else {
		echo "DEBUG: There are no Engines for EMAIL File rollback"
	}				
}

def RB_PostDeployment(){
	
// Identify EMS engines to roll back.
	ems_rollback_engines = VERSIONS_MAP.findAll { it.value['RESULT'] == "FAILED" && it.value['EMS_Deployment'] == "PASSED" }
	println("DEBUG: EMS Rollback engines are: " + ems_rollback_engines)

	ems_rollback_engines_list = ems_rollback_engines.keySet().join(';')
	if(ems_rollback_engines_list){
		// Call rollback function by providing environment Details and engines
		EMS_Functions.ems_rollback Environment:"${params.Target_Env}", crq_no:"${params.CRQ}", ems_engines:"${ems_rollback_engines_list}", datetime:"${date_now}", release:"${params.RELEASE}", emsIgnore:"${env.emsIgnore}", rollbackBackup:false
	}
	// Identify SQL Engines for Rollback
	sql_rollback_engines = VERSIONS_MAP.findAll { it.value['RESULT'] == "FAILED" && it.value['SQL_Deployment'] == "PASSED" }
	println("DEBUG: SQL Rollback engines are: " + sql_rollback_engines)

	if(sql_rollback_engines.size() != 0){
		// Fixing issue with SQL rollback
		
		sql_ver_map = sql_rollback_engines.collectEntries {sql_map_key, sql_map_value -> [sql_map_key, sql_map_value['SQL_VERSION']]}
		String sql_versions = mapFunc.convert_map_to_string engine_map:sql_ver_map
		println("DEBUG:" + sql_versions)
			
		sql_rollback_engines_list = sql_rollback_engines.keySet().join(';')		
		
		// Call rollback function by providing environment Details and engines
		SQL_Functions.sql_explicit_rollback Environment:"${params.Target_Env}", crq_no:"${params.CRQ}", repo_artifact_ids: sql_versions, datetime:"${date_now}", release:"${params.RELEASE}"
	}
	// Assign overall result to RB-ROLLBACK Results so far.
	VERSIONS_MAP.keySet().each { engi ->
		if(VERSIONS_MAP[engi]['RESULT'] == "FAILED"){
			if(VERSIONS_MAP[engi]['RF1_RESULT'] == "FAILED"){
				VERSIONS_MAP[engi]['RB_RESULT'] = "NOT_STARTED"
			} else {
				VERSIONS_MAP[engi]['RB_RESULT'] = VERSIONS_MAP[engi]['RESULT']
			}
		} else {
			VERSIONS_MAP[engi]['RB_RESULT'] = "PASSED"
		}
	}
	trigger_results_email map: VERSIONS_MAP, REPORT_STAGE: "RB_POSTDeployment"
	
	//[CICD-977] Update Deployment History DB with RB result for each of the engine passed RF1 stage and done with RB stage.
	VERSIONS_MAP.keySet().each { engi -> 
			//Update record with status after RB stage.
			def updateQuery = """UPDATE CICD_DEPLOYMENT_HISTORY SET \"updatedTimestamp\"=sysdate, \"RBStatus\"=\'${VERSIONS_MAP[engi]['RB_RESULT']}\', \"FailureReason\"=\'${VERSIONS_MAP[engi]['RESULT']}\' WHERE \"DeploymentId\"=\'${VERSIONS_MAP[engi]['DB_ROW_ID']}\'"""
			
			DB_Functions.update_db_row_fields dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", updateQuery: updateQuery
	}	
	
	def userInput = input(
	  id: 'userInput', message: 'Proceed with RF2 Deployment?',
	  submitterParameter: 'submitter'
	)
	// Removing Engines after RB
	 def engineListRF2 = input(
		id: 'engineListRF2',
		message: 'Please Provide list of Engines to be ignored from RF2 separated by ;', 
		parameters: [
					[$class: 'TextParameterDefinition', defaultValue: '', description: 'Ignore Engines List', name: 'Engines_List'],
		])
	if(engineListRF2){	
	   // updating status with ignore to identify ignored engines
		engineListRF2.split(';').each { engine ->
			// CICD-555: Fix to validate engine name in VERSIONS_MAP.
			if (VERSIONS_MAP.containsKey(engine)) {
				VERSIONS_MAP[engine]['RESULT'] = "IGNORE"
			}
		}

       // Removing ignored engines from BW Deployment path
		bw_ignore_config = VERSIONS_MAP.findAll { it.value['RESULT'] == "IGNORE" && it.value['BW_VERSION'] != "NA" }.groupBy({ engine -> engine.value['GROUP_ID'] })
		bw_ignore_config.each { patteren_string1, BW_Ignore_group ->
			// construct folder name, BW_TYpe, group_id and other details from pattern string and call remove config job.
			println("DEBUG: BW Delete Config engines for group:" + patteren_string1)
			println("DEBUG:" + BW_Ignore_group)
			remove_engines_list = BW_Ignore_group.keySet().join(';')
			if(patteren_string1.toString() != "null") {
				BW_type = patteren_string1.split('_')[0]
				echo "DEBUG: BW_type is: ${BW_type}"
				BW_Folder = patteren_string1.split('_')[1]
				group_id = patteren_string1.split('_')[2]
				BW_Functions.bw_remove_config Host:"${params.Target_Env}", crq_no:"${params.CRQ}", datetime:"${date_now}", engines_list:"${remove_engines_list}", bw_folder_release:bw_release_num, engine_group:patteren_string1, folderName:BW_Folder
			
			} else {
				echo "Nothing to remove from config"
			}
			
		}	   
	   
	   mapFunc.remove_engines_from_maps engine_maps: [VERSIONS_MAP], engines_list: engineListRF2
	   
		println(VERSIONS_MAP)
	}	

}	

def preparation_function(){
		
		// Initialize parameters to pipeline job.
		properties([parameters([string(defaultValue: 'CCS20.5', description: 'Please enter Release', name: 'RELEASE', trim: false), string(defaultValue: 'Test', description: 'Please enter CRQ Number', name: 'CRQ', trim: false), choice(choices: ['TILSTG01'], description: 'Please select environment', name: 'Target_Env'), string(defaultValue: 'test', description: 'Please enter description', name: 'Description', trim: false), string(defaultValue: '', description: 'Please enter Only GV Change Engines separated by ;', name: 'OnlyGV_Engines', trim: true), string(defaultValue: '', description: 'Please enter Only File Deployment Engines separated by ;', name: 'OnlyFile_Engines', trim: true), string(defaultValue: '', description: 'Please enter engines to ignore deployment for separated by ;', name: 'IgnoreDeploymentEngines', trim: true)])])
		
		date_now = new Date().format("YYYYMMddHHmmss")
		// Release number as per BW deployment tool standard
		bw_release_num = RELEASE.replace(".","_")
		println(bw_release_num)

		majorVersion = RELEASE.split('CCS')[1].split('\\.')[0]
		minorVersion = RELEASE.split('CCS')[1].split('\\.')[1]
		
		// Get TILSTG01 approver details.
		ReleaseApprovers = get_approvers_list('TILSTG01')
		//[CICD-539] Making user parameter as global parameter to use across the pipeline.
		user = currentBuild.rawBuild.causes[0].userId
		println("DEBUG: User name is: " + user)
		
		displayName = "${params.RELEASE}_${params.CRQ}_${BUILD_NUMBER}"
		currentBuild.displayName = "${displayName}"	
		
		if ("${params.Target_Env}" == "T1" || "${params.Target_Env}" == "T3" || "${params.Target_Env}" == "T4" || "${params.Target_Env}" == "T7"){
			println("Setting value to Env Prefix to SIT")
			Env_Prefix = "SIT" 
		}else {
			println("Setting value to Env Prefix to Environment") 
			Env_Prefix = "${params.Target_Env}"
		}
		// Checkout required GIT repositories.
		checkout_git_repositories()

		//Load all functions files from GIT. point to exact source file
		load_groovy_files()
		
		commonFunctions.validate_input_parameters RELEASE: params.RELEASE, CRQ: params.CRQ, DESCRIPTION: params.Description		

		// Construct VERSION_MAP and RESULTS_MAP with all the engines from NEXUS.
		construct_maps()
		
		def IgnoreEngines = "${params.IgnoreDeploymentEngines}"
		if(IgnoreEngines){
			mapFunc.remove_engines_from_maps engine_maps: [VERSIONS_MAP], engines_list: IgnoreEngines
			println(VERSIONS_MAP)
		}
		
		// Trigger an email to display engines and versions for deployment
		trigger_versions_email map: VERSIONS_MAP, REPORT_STAGE: "PREPARATION"

		// Release Summary Approval
		def userInput = input(
		  id: 'userInput', message: 'Verify Release Summary Report and procced with Deployment',
		  submitterParameter: 'submitter',
		  submitter: "${ReleaseApprovers}") 
		  
		// Input for Ignoring any engines for deployment

		def engineList = input(
			id: 'engineList',
			message: 'Please Provide list of Engines to be ignored from Deployment separated by ;', 
			parameters: [
						[$class: 'TextParameterDefinition', defaultValue: '', description: 'Ignore Engines List', name: 'Engines_List'],
			])
		if(engineList){	
			mapFunc.remove_engines_from_maps engine_maps: [VERSIONS_MAP], engines_list: engineList
			println(VERSIONS_MAP)
		}
		
		// Grouping BW engines for deployment based on engine type and folder name.
		def group_engine_type_maps = VERSIONS_MAP.findAll { it.value['BW_VERSION'] != "NA" }.groupBy({ engine -> engine.value['BW_ENGINE_TYPE'] })
		group_engine_type_maps.each { g_type_key, g_type_value ->
				def group_engine_type_folder_maps = g_type_value.groupBy({ engine -> engine.value['BW_FOLDER_NAME'] })
				group_engine_type_folder_maps.each{ g_type_folder_key, g_type_folder_value ->
					def counter = 1
					def gID = 1
					g_type_folder_value.each { g_type_folder_value_key, g_type_folder_value_value ->
						VERSIONS_MAP[g_type_folder_value_key]['GROUP_ID'] = g_type_key + '_' + g_type_folder_key + '_' + gID
						if(counter < 5){
							counter++
						} else {
							counter = 0
							gID++ 
						}
					}
				}
		}		
		trigger_versions_email map: VERSIONS_MAP, REPORT_STAGE: "VERSIONS AFTER IGNORE"
	
}	

def rf1_failure_engines_stage(){
		//stage function for "EMS/File/SQL_RB_RF1_FailurEngines"
					
		// Identify EMS engines to roll back.
		ems_rollback_engines = VERSIONS_MAP.findAll { it.value['RESULT'] == "FAILED" && it.value['EMS_Deployment'] == "PASSED" }
		println("DEBUG: EMS Rollback engines are: " + ems_rollback_engines)
		
		ems_rollback_engines_list = ems_rollback_engines.keySet().join(';')
		if(ems_rollback_engines_list){
			// Call rollback function by providing environment Details and engines
			EMS_Functions.ems_rollback Environment:"${params.Target_Env}", crq_no:"${params.CRQ}", ems_engines:"${ems_rollback_engines_list}", datetime:"${date_now}", release:"${params.RELEASE}", emsIgnore:"${env.emsIgnore}", rollbackBackup:false
		}
		// Identify SQL Engines for Rollback
		sql_rollback_engines = VERSIONS_MAP.findAll { it.value['RESULT'] == "FAILED" && it.value['SQL_Deployment'] == "PASSED" }
		println("DEBUG: SQL Rollback engines are: " + sql_rollback_engines)
		
		if(sql_rollback_engines.size() != 0){
			
			// Fixing issue with SQL rollback
			
			sql_ver_map = sql_rollback_engines.collectEntries {sql_map_key, sql_map_value -> [sql_map_key, sql_map_value['SQL_VERSION']]}
			String sql_versions = mapFunc.convert_map_to_string engine_map:sql_ver_map
			println("DEBUG:" + sql_versions)		
			
			sql_rollback_engines_list = sql_rollback_engines.keySet().join(';')
			
			// Call rollback function by providing environment Details and engines
			SQL_Functions.sql_explicit_rollback Environment:"${params.Target_Env}", crq_no:"${params.CRQ}", repo_artifact_ids: sql_versions, datetime:"${date_now}", release:"${params.RELEASE}"
		}
		// run ems rollback for the engines identified.
		
		// Assign overall result to RF1 Results so far.
		VERSIONS_MAP.keySet().each { engi ->
			if(VERSIONS_MAP[engi]['RESULT'] == "FAILED"){
				VERSIONS_MAP[engi]['RF1_RESULT'] = VERSIONS_MAP[engi]['RESULT']
			} else {
				VERSIONS_MAP[engi]['RF1_RESULT'] = "PASSED"
			}
		}
		trigger_results_email map: VERSIONS_MAP, REPORT_STAGE: "RF1-POSTDEPLOYMENT"
		
}

def rf2_failure_engines_stage(){
	
		// Stage function for "EMS/File/SQL_RB_RF2_FailurEngines"
			// Identify EMS engines to roll back.
		ems_rollback_engines = VERSIONS_MAP.findAll { it.value['RESULT'] == "FAILED" && it.value['EMS_Deployment'] == "PASSED" }
		println("DEBUG: EMS Rollback engines are: " + ems_rollback_engines)
		
		ems_rollback_engines_list = ems_rollback_engines.keySet().join(';')
		if(ems_rollback_engines_list){
			// Call rollback function by providing environment Details and engines
			EMS_Functions.ems_rollback Environment:"${params.Target_Env}", crq_no:"${params.CRQ}", ems_engines:"${ems_rollback_engines_list}", datetime:"${date_now}", release:"${params.RELEASE}", emsIgnore:"${env.emsIgnore}", rollbackBackup:false
		}
		// Identify SQL Engines for Rollback
		sql_rollback_engines = VERSIONS_MAP.findAll { it.value['RESULT'] == "FAILED" && it.value['SQL_Deployment'] == "PASSED" }
		println("DEBUG: SQL Rollback engines are: " + sql_rollback_engines)
		
		if(sql_rollback_engines.size() != 0){
			
		//Fixing issue with rollback
		
			sql_ver_map = sql_rollback_engines.collectEntries {sql_map_key, sql_map_value -> [sql_map_key, sql_map_value['SQL_VERSION']]}
			String sql_versions = mapFunc.convert_map_to_string engine_map:sql_ver_map
			println("DEBUG:" + sql_versions)
			
			//sql_rollback_engines_list = sql_rollback_engines.keySet().join(';')			
			// Call rollback function by providing environment Details and engines
			SQL_Functions.sql_explicit_rollback Environment:"${params.Target_Env}", crq_no:"${params.CRQ}", repo_artifact_ids: sql_versions, datetime:"${date_now}", release:"${params.RELEASE}"
		}
		// Assign overall result to RF1 Results so far.
		VERSIONS_MAP.keySet().each { engi ->
			if(VERSIONS_MAP[engi]['RESULT'] == "FAILED"){
				if(VERSIONS_MAP[engi]['RB_RESULT'] == "FAILED"){
					VERSIONS_MAP[engi]['RF2_RESULT'] = "NOT_STARTED"
				} else {
					VERSIONS_MAP[engi]['RF2_RESULT'] = VERSIONS_MAP[engi]['RESULT']
				}							
			} else {
				VERSIONS_MAP[engi]['RF2_RESULT'] = "PASSED"
				VERSIONS_MAP[engi]['RESULT'] = "PASSED"
			}
		}
		trigger_results_email map: VERSIONS_MAP, REPORT_STAGE: "RF2_PostDeployment"
	
	
}

def rf1_sql_deployment_stage(){
	// stage function for rf1 sql deployment
					
	// run BW_Generation stage with existing loogic.
	// Get list of engines for EMS deployment.
	sql_map = VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['SQL_VERSION'] != "NA" }
	sql_ver_map = sql_map.collectEntries {sql_map_key, sql_map_value -> [sql_map_key, sql_map_value['SQL_VERSION']]}
	String sql_versions = mapFunc.convert_map_to_string engine_map:sql_ver_map
	println("DEBUG:" + sql_versions)

	// Call sql deploy function by providing environment Details and engines
	SQL_Functions.sql_deploy Environment:"${params.Target_Env}", nexus_group_id:"${env.SQL_GROUPID}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.REPO}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CRQ}", repo_artifact_ids:"${sql_versions}", datetime:"${date_now}", release:"${params.RELEASE}"
	
	// Update maps with failed engines
	def sql_failed_path = "${WORKSPACE}/SQL_Deploy_${params.Target_Env}/SQL_Deployment/sqlDeploy_failure.txt"
	
	// Update maps with failed engines
	def sql_success_path = "${WORKSPACE}/SQL_Deploy_${params.Target_Env}/SQL_Deployment/sqlDeploy_success.txt"
	
	if(fileExists(sql_success_path)) {
		def sql_success_ouput = readFile("${WORKSPACE}/SQL_Deploy_${params.Target_Env}/SQL_Deployment/sqlDeploy_success.txt")
		if (sql_success_ouput.size() != 0) {
			 def success_file = new File("${WORKSPACE}/SQL_Deploy_${params.Target_Env}/SQL_Deployment/sqlDeploy_success.txt")
			 def sql_success_engines_list = success_file.readLines().join(';')
			 mapFunc.update_version_map_result map: VERSIONS_MAP, engines: sql_success_engines_list, stage: "SQL_Deployment", status:"PASSED"
		}
	}
	if(fileExists(sql_failed_path)) {
		def sql_failed_ouput = readFile("${WORKSPACE}/SQL_Deploy_${params.Target_Env}/SQL_Deployment/sqlDeploy_failure.txt")
		if (sql_failed_ouput.size() != 0) {
			 def failed_file = new File("${WORKSPACE}/SQL_Deploy_${params.Target_Env}/SQL_Deployment/sqlDeploy_failure.txt")
			 def sql_failed_engines_list = failed_file.readLines().join(';')
			 mapFunc.update_version_map_result map: VERSIONS_MAP, engines: sql_failed_engines_list, stage: "SQL_Deployment", status:"FAILED"
		}
	}					
	echo "SQL_DEPLOYMENT stage completed"
	//trigger_results_email map: VERSIONS_MAP, REPORT_STAGE: "SQL_Deployment"
	//[780325]: Attach SQL logs in the email while sending SQL deployment status
	emailext mimeType: 'text/html',
	subject: "[Jenkins]: ${currentBuild.fullDisplayName}  - " + "Upliftment Results Summary",
	from:"CICD_ISTILDeploymentStatus@vodafone.com",
	to: "${mailRecipients}",
	body: 	"${emailFunc.get_sit_results_email_summary map: VERSIONS_MAP, REPORT_STAGE: 'RF1_SQL_Deployment'}",
	attachmentsPattern: "**/SQL_Deploy_${params.Target_Env}/SQL_Deployment/SQL_Logs/*.zip"
	//[780325]: Changes END
	
}

def file_generate_satge_function(){
	// Stage function for file generate.
	
		checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${params.Target_Env}_Files_Deploy"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
	// Checkout BW Configuration Repository
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${params.Target_Env}_Files_Config"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_BW_Application_Configuration.git']]]					
	
	// Validate XML files againset GIT for all the files listed in template file.
	
	// [CICD-1783]: Fix to consider BW_VERSION while checking out the file tag.
	def BW_VERS_MAP = VERSIONS_MAP.findAll { it.value['BW_VERSION'] != "NA" }.collectEntries {bw_eng, bw_ver -> [bw_eng, bw_ver['BW_VERSION']]}
	
	
	def xml_updated_map = VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['XML_FILES'] != "NA"  }.collectEntries {xml_engine, xml_version -> [xml_engine, xml_version['XML_FILES']]}
	if(xml_updated_map.size() != 0) {
		String xml_engines_failed = ""
		xml_engines_failed = FILE_Functions.validate_files Host: "${params.Target_Env}", Deployment_Type: "XML_Files", map: xml_updated_map, RELEASE: "${params.RELEASE}", BW_SNAP: BW_VERS_MAP
		echo "DEBUG: xml_engines_failed are: ${xml_engines_failed}"	
		
		//update_version_map_result map: Master_Map, engines: "${BW_Engine_map.keySet().join(';')}", stage: "", status:""
		if(xml_engines_failed){
			mapFunc.update_version_map_result map: VERSIONS_MAP, engines: xml_engines_failed, stage: "XML_Deployment", status:"FAILED"
		}
	}
	
	// Validate JAR files againset GIT for all the files listed in template file.
	def jar_updated_map = VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['JAR_FILES'] != "NA"  }.collectEntries {jar_engine, jar_version -> [jar_engine, jar_version['JAR_FILES']]}
	if(jar_updated_map.size() != 0) {
		String jar_engines_failed = ""
		jar_engines_failed = FILE_Functions.validate_files Host: "${params.Target_Env}", Deployment_Type: "JAR_Files", map: jar_updated_map, RELEASE: "${params.RELEASE}", BW_SNAP: BW_VERS_MAP
		echo "DEBUG: jar_engines_failed are: ${jar_engines_failed}"	
		// Update versions map with status for all the failed engines.
		if(jar_engines_failed){
			mapFunc.update_version_map_result map: VERSIONS_MAP, engines: jar_engines_failed, stage: "JAR_Deployment", status:"FAILED"
		}
	}

	// Validate EMAIL files againset GIT for all the files listed in template file.
	def email_updated_map = VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['EMAIL_FILES'] != "NA"  }.collectEntries {email_engine, email_version -> [email_engine, email_version['EMAIL_FILES']]}
	if(email_updated_map.size() != 0) {
		String email_engines_failed = ""
		email_engines_failed = FILE_Functions.validate_files Host: "${params.Target_Env}", Deployment_Type: "Email_Template", map: email_updated_map, RELEASE: "${params.RELEASE}", BW_SNAP: BW_VERS_MAP
		echo "DEBUG: email_engines_failed are: ${email_engines_failed}"	
		// Update versions map with status for all the failed engines.
		if(email_engines_failed){
			mapFunc.update_version_map_result map: VERSIONS_MAP, engines: email_engines_failed, stage: "EMAIL_Deployment", status:"FAILED"
		}
	}
	// trigger result email after this stage
	trigger_versions_email map: VERSIONS_MAP, REPORT_STAGE: "FILE_GENERATION"
	
}

//GV_Utility_changes
def EMS_Generate()
{
	ems_generate_map = VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['EMS_VERSION'] != "NA" }
				ems_gen_map = ems_generate_map.collectEntries {ems_gen_key, ems_gen_value -> [ems_gen_key, ems_gen_value['EMS_VERSION']]}
				
				//Checkout Environment specic configurations (tokens, properties files)
				checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "EMS_Deploy_ENV"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Production_Configuration.git']]]
				
				String ems_engines = mapFunc.convert_map_to_string engine_map:ems_gen_map
				println("DEBUG: EMS engines considered for generate stage:" + ems_engines)
                
				// Call ems generate function by providing Environment Details and engines
				 EMS_Functions.generate_ems_deployment Environment:"${params.Target_Env}", nexus_group_id:"${env.EMS_GROUPID}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.UPLIFTMENT_REF_REPO}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CRQ}", ems_engines:"${ems_engines}", datetime:"${date_now}", release:"${params.RELEASE}", emsIgnore:"${env.emsIgnore}"
}

//GV_Utility_changes
def SQL_Generate()
{
	sql_generate_map = VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['SQL_VERSION'] != "NA" }
					sql_gen_map = sql_generate_map.collectEntries {sql_gen_key, sql_gen_value -> [sql_gen_key, sql_gen_value['SQL_VERSION']]}
					
					String sql_engines = mapFunc.convert_map_to_string engine_map:sql_gen_map
				
					//Checkout Environment specic configurations (tokens, properties files)
					checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "SQL_Deploy_ENV"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Production_Configuration.git']]]
											
					// calling sql backup function to take generate deployment runtime and backup of tables provided
					SQL_Functions.sql_generate Environment:"${params.Target_Env}", nexus_group_id:"${env.SQL_GROUPID}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.UPLIFTMENT_REF_REPO}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CRQ}", repo_artifact_ids:"${sql_engines}", datetime:"${date_now}", release:"${params.RELEASE}" 
}

//GV_Utility_changes
def RF1_POST_GVDiff_Stage(){
	
	release_no=params.RELEASE.replace(".", "_")
	
checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Temp"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: "https://github.vodafone.com/VFUK-INTEGRATION/TIL_DevOps_Framework.git"]]]
							
							dir_loc = sh (script: """pwd""",returnStdout: true).trim()
							println("dir_loc = ${dir_loc}") 
							
							sh(script: "ssh uk2994yr /opt/SP/tibco/bw_deployment/gvoutput.sh ${params.CRQ} ${release_no} ;")
							sh(script: "scp tibco@uk2994yr:/opt/SP/tibco/bw_deployment/${release_no}/GVOUTPUT_${release_no}_${params.CRQ}.txt ${dir_loc}")
														

	// Trigger Result Email
	// Attach Post GV Diff reports in the email while sending deployment status
	emailext mimeType: 'text/html',
	subject: "[Jenkins]: ${currentBuild.fullDisplayName}  - Post GV DIFF Report",
	from:"CICD_ISTILDeploymentStatus@vodafone.com",
	to: "${mailRecipients}",
	body: 	"Post GV DIFF CSV File attachment for RF1_${params.CRQ}_${params.RELEASE}",
	attachmentsPattern: "**/GVOUTPUT_${release_no}_${params.CRQ}.txt"
	
			FILE="GVOUTPUT_${release_no}_${params.CRQ}.txt"

	nexusArtifactUploader artifacts: [[artifactId: "RF1_GVOUTPUT__${params.CRQ}_${params.RELEASE}_${TimeStamp}", classifier: '', file: "${FILE}", type: 'txt']], credentialsId: '74edde97-94e0-403c-93f6-cad6c46c45f8', groupId: "POST_GV_DIFF/RF1", nexusUrl: "${NEXUS_URL1}", nexusVersion: "${NEXUS_VERSION}", repository: "TEST_REPO", protocol: 'http'
	
}

//GV_Utility_changes
def RF2_POST_GVDiff_Stage(){
	
	release_no=params.RELEASE.replace(".", "_")
	
checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Temp"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: "https://github.vodafone.com/VFUK-INTEGRATION/TIL_DevOps_Framework.git"]]]
							
							dir_loc = sh (script: """pwd""",returnStdout: true).trim()
							println("dir_loc = ${dir_loc}") 
							
							sh(script: "ssh uk2994yr /opt/SP/tibco/bw_deployment/gvoutput.sh ${params.CRQ} ${release_no} ;")
							sh(script: "scp tibco@uk2994yr:/opt/SP/tibco/bw_deployment/${release_no}/GVOUTPUT_${release_no}_${params.CRQ}.txt ${dir_loc}")
														

	// Trigger Result Email
	// Attach Post GV Diff reports in the email while sending deployment status
	emailext mimeType: 'text/html',
	subject: "[Jenkins]: ${currentBuild.fullDisplayName}  - Post GV DIFF Report",
	from:"CICD_ISTILDeploymentStatus@vodafone.com",
	to: "${mailRecipients}",
	body: 	"Post GV DIFF CSV File attachment for RF2_${params.CRQ}_${params.RELEASE}",
	attachmentsPattern: "**/GVOUTPUT_${release_no}_${params.CRQ}.txt"
	
			FILE="GVOUTPUT_${release_no}_${params.CRQ}.txt"

	nexusArtifactUploader artifacts: [[artifactId: "RF2_GVOUTPUT__${params.CRQ}_${params.RELEASE}_${TimeStamp}", classifier: '', file: "${FILE}", type: 'txt']], credentialsId: '74edde97-94e0-403c-93f6-cad6c46c45f8', groupId: "POST_GV_DIFF/RF2", nexusUrl: "${NEXUS_URL1}", nexusVersion: "${NEXUS_VERSION}", repository: "TEST_REPO", protocol: 'http'
	
}

def rf1_file_deployment_stage(){
	// stage function for RF1 file deployment
	// Identify Engines for XML Deployment and proceed with deployment.
	xml_map = VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['XML_FILES'] != "NA" }
	if(xml_map.size() != 0) {
		xml_ver_map = xml_map.collectEntries {xml_map_key, xml_map_value -> [xml_map_key, xml_map_value['XML_FILES']]}
		//Defect fixed for the issue observed in TILSTG01
		xml_engines = mapFunc.convert_map_to_string engine_map: xml_ver_map
		FILE_Functions.deploy_files Host:"${params.Target_Env}", Deployment_Type: "XML_Files", file_snap: xml_engines, crq_no:"${params.CRQ}", datetime:"${date_now}" 
		echo "XML deployment is done."
		// Update master report map with status for successful engine
		echo "DEBUG: SUCCESSFUL ENGINES FROM XML_DEPLOYMENT: ${xml_ver_map.keySet().join(';')}"
		mapFunc.update_version_map_result map: VERSIONS_MAP, engines: "${xml_ver_map.keySet().join(';')}", stage: "XML_Deployment", status:"PASSED"
	} else {
		echo "DEBUG: There are no Engines for XML File Deployment."
	}
	// Identify Engines for JAR Deployment and proceed with deployment.
	jar_map = VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['JAR_FILES'] != "NA" }
	if(jar_map.size() != 0) {
		jar_ver_map = jar_map.collectEntries {jar_map_key, jar_map_value -> [jar_map_key, jar_map_value['JAR_FILES']]}
		//Defect fixed for the issue observed in TILSTG01
		jar_engines = mapFunc.convert_map_to_string engine_map: jar_ver_map		
		FILE_Functions.deploy_files Host:"${params.Target_Env}", Deployment_Type: "JAR_Files", file_snap: jar_engines, crq_no:"${params.CRQ}", datetime:"${date_now}" 
		echo "JAR deployment is done."
		// Update master report map with status for successful engine
		echo "DEBUG: SUCCESSFUL ENGINES FROM JAR_DEPLOYMENT: ${jar_ver_map.keySet().join(';')}"
		mapFunc.update_version_map_result map: VERSIONS_MAP, engines: "${jar_ver_map.keySet().join(';')}", stage: "JAR_Deployment", status:"PASSED"
	} else {
		echo "DEBUG: There are no Engines for JAR File Deployment."
	}
	// Identify Engines for EMAIL Deployment and proceed with deployment.
	email_map = VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['EMAIL_FILES'] != "NA" }
	if(email_map.size() != 0) {
		email_ver_map = email_map.collectEntries {email_map_key, email_map_value -> [email_map_key, email_map_value['EMAIL_FILES']]}
		//Defect fixed for the issue observed in TILSTG01
		email_engines = mapFunc.convert_map_to_string engine_map: email_ver_map		
		FILE_Functions.deploy_files Host:"${params.Target_Env}", Deployment_Type: "EMAIL_Files", file_snap: email_engines, crq_no:"${params.CRQ}", datetime:"${date_now}" 
		echo "EMAIL deployment is done."
		// Update master report map with status for successful engine
		echo "DEBUG: SUCCESSFUL ENGINES FROM EMAIL_DEPLOYMENT: ${email_ver_map.keySet().join(';')}"
		mapFunc.update_version_map_result map: VERSIONS_MAP, engines: "${email_ver_map.keySet().join(';')}", stage: "EMAIL_Deployment", status:"PASSED"
	} else {
		echo "DEBUG: There are no Engines for EMAIL File Deployment."
	}				
	trigger_results_email map: VERSIONS_MAP, REPORT_STAGE: "FILE_Deployment"	
}

mailRecipients = "DL-TSSC-AO2-UK-Integration_TIL-RIG_L2@vodafone.com, dl-techvi-ito-ao-deaas-uk-til@vodafone.com, devops-vfuk-integration@vodafone.com"  //GV_Utility_changes
ReleaseApprovers = ""
date_now = " "
emailBody = " "
displayName = ""
bw_release_num = ""
BW_Engine_Snap = [:]
BW_Rollback_Engines = [:]
EMS_Engine_Snap = [:]
EMS_Rollback_Engines = [:]
SQL_Engine_Snap = [:]
SQL_Rollback_Engines = [:]
File_Deployment_Snap = [:]
XML_Files_Snap = [:]
XML_Rollback_Files = [:]
EMAIL_Files_Snap = [:]
EMAIL_Rollback_Files = [:]
JAR_Files_Snap = [:]
JAR_Rollback_Files = [:]
BW_Folder_Snap = [:]
Env_Prefix = ""
Engines_Map = [:]
VERSIONS_MAP = [:]
VERSIONS_DUP = [:]
RESULTS_MAP = [:]
BW_Type_Snap = [:]
OnlyGV_Engine_Snap = [:]
OnlyGV_Engine_Type = [:]
// Adding Restart Engines for Common SQL 
// CICD-330
SQL_Restart_Engine_Snap = [:]
SQL_Restart_Engines = ""


// Pipeline parameters.
BW_Deployment_Required = ""
SQL_Deployment_Required = ""
EMS_Deployment_Required = ""
File_Deployment_Required = ""
BW_Deployment_Type = ""
BW_Engines = ""
FolderName = ""
SQL_Versions = ""
SQL_BACKUP_TABLES = ""
EMS_Versions = ""
File_Deployment_Engines = ""
AppDynamics_Update = ""
nexusFunc = ""
emailFunc = ""
mapFunc = ""
Env_Prefix = ""
maps_list = []
BW_type = ""
BW_Folder = ""
group_id = ""
bw_deployment_failed_engines = ""
bw_deployment_success_engines = ""
REPORT_STAGE = ""
//[CICD-311]: Fix to handle only file deploy engines as well.
fileDeployEngines = ""
user = ""


import groovy.json.JsonOutput

pipeline {
    agent any
	options {
        preserveStashes(buildCount: 49)
    }

    environment {
		TimeStamp=new Date().format("YYYYMMddHHmmss") //GV_Utility_changes
		REPO_URL = "http://195.233.197.150:8081/repository"
		NEXUS_URL = "http://195.233.197.150:8081"
		NEXUS_URL1 = "195.233.197.150:8081"  //GV_Utility_changes
		NEXUS_USER = "admin"
		NEXUS_PASSWD = "admin123"
		NEXUS_VERSION="nexus3" //GV_Utility_changes
		Promotion_Repo = "PROD_REPO"
		BW_GROUPID = "TIL_BW"
		EMS_GROUPID = "TIL_EMS"
		SQL_GROUPID="TIL_SQL"
		emsIgnore = "false"
		UPLIFTMENT_REF_REPO = "STAGING_REPO"
		BW_InstanceCount = 2
		EnvironmentRepository = "TIL_Production_Configuration"
		//[CICD-539] Insert Deployment metadata to release notes DB.
		dbURL = 'jdbc:oracle:thin:@195.233.199.13:33000:TIBTST1'
		dbUserName = 'CICD_OWN_DB01'
		dbPassword = 'TIL_CICD_DB'
		dbDriver = 'oracle.jdbc.driver.OracleDriver'			
    }

    stages {
		stage('ReleasePreparation') {
			steps {
				script{
					deleteDir()
					preparation_function()
                }				
			}			
		}
		
   		stage('EMS Generate') {
			when {
			     expression { VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['EMS_VERSION'] != "NA" }.size() != 0 }
			    }
			steps {
				script{	
				//GV_Utility_changes
				EMS_Generate()
				}				
			}			
		} 

		stage('SQL Generate') {
		    when {
			     expression { VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['SQL_VERSION'] != "NA" }.size() != 0 }
			    }
			steps {
				script{
					//GV_Utility_changes
				SQL_Generate()
				}	
			}
		} 
 		stage('FILE Generate') {
		    when {
			     expression { VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['BW_VERSION'] != "NA" }.size() != 0 }
			    }
			steps {
				script{
					file_generate_satge_function()
				}
			}
		}		
		
		stage('BW Generate') {
		    when {
			     expression { VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['BW_VERSION'] != "NA" }.size() != 0 }
			    }
			steps {
				script {
					//Calling BW  Generate Function	
					bw_generate_stage()	
				}
			}
		}
		
		stage('RF1-SQL Deployment') {
		    when {
			     expression { VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['SQL_VERSION'] != "NA" }.size() != 0 }
			    }
			steps {
				script {
					def userInputRF1SQL = input(
						  id: 'userInputRF1SQL', message: 'Proceed with RF1 SQL Deployment?',
						  submitterParameter: 'submitter'
						)
					rf1_sql_deployment_stage()
				}
			}
		}
		
		stage('RF1-EMS Deployment') {
		    when {
			     expression { VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['EMS_VERSION'] != "NA" }.size() != 0 }
			    }
			steps {
				script {
					def userInputRF1EMS = input(
						  id: 'userInputRF1EMS', message: 'Proceed with RF1 EMS Deployment?',
						  submitterParameter: 'submitter'
						)
					// Get list of engines for EMS deployment.
					ems_map = VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['EMS_VERSION'] != "NA" }
					ems_ver_map = ems_map.collectEntries {ems_map_key, ems_map_value -> [ems_map_key, ems_map_value['EMS_VERSION']]}
					String ems_versions = mapFunc.convert_map_to_string engine_map:ems_ver_map
					println("DEBUG:" + ems_versions)					
					
					// Call ems deploy function by providing Environment Details and engines
				    EMS_Functions.ems_deployment Environment:"${params.Target_Env}", crq_no:"${params.CRQ}", ems_engines:"${ems_versions}", datetime:"${date_now}", release:"${params.RELEASE}", emsIgnore:"${env.emsIgnore}", rollbackBackup:false
				 
				    // Update Maps with Successful engines
					def ems_deployment_success_file = "${WORKSPACE}/EMS_Deploy_${params.Target_Env}/EMS_Deployment/deploy_success.txt"
					if(fileExists(ems_deployment_success_file)) {
						def ems_deployment_success_ouput = readFile("${WORKSPACE}/EMS_Deploy_${params.Target_Env}/EMS_Deployment/deploy_success.txt")
						if (ems_deployment_success_ouput.size() != 0) {
							def success_file = new File("${WORKSPACE}/EMS_Deploy_${params.Target_Env}/EMS_Deployment/deploy_success.txt")
							def ems_success_engines_list = success_file.readLines().join(';')
							mapFunc.update_version_map_result map: VERSIONS_MAP, engines: ems_success_engines_list, stage: "EMS_Deployment", status:"PASSED"
						}
					}
					// Update Maps with failed engines
					def ems_deployment_failed_file = "${WORKSPACE}/EMS_Deploy_${params.Target_Env}/EMS_Deployment/deploy_failure.txt"
					if(fileExists(ems_deployment_failed_file)) {
						def ems_deployment_failed_ouput = readFile("${WORKSPACE}/EMS_Deploy_${params.Target_Env}/EMS_Deployment/deploy_failure.txt")
						if (ems_deployment_failed_ouput.size() != 0) {
							def failed_file = new File("${WORKSPACE}/EMS_Deploy_${params.Target_Env}/EMS_Deployment/deploy_failure.txt")
							def ems_failed_engines_list = failed_file.readLines().join(';')
							mapFunc.update_version_map_result map: VERSIONS_MAP, engines: ems_failed_engines_list, stage: "EMS_Deployment", status:"FAILED"
						}
					}					
					//trigger_results_email map: VERSIONS_MAP, REPORT_STAGE: "RF1_EMS_Deployment"
					//[780325]: Attach EMS logs in the email while sending EMS deployment status
					emailext mimeType: 'text/html',
					subject: "[Jenkins]: ${currentBuild.fullDisplayName}  - " + "Upliftment Results Summary",
					from:"CICD_ISTILDeploymentStatus@vodafone.com",
					to: "${mailRecipients}",
					body: 	"${emailFunc.get_sit_results_email_summary map: VERSIONS_MAP, REPORT_STAGE: 'RF1_EMS_Deployment'}",
					attachmentsPattern: "**/EMS_Deploy_${params.Target_Env}/EMS_Deployment/EMS_Logs/*.zip"
					//[780325]: Changes END
				}
			}
		} 
		
		stage('RF1-File Deployment') {
			steps {
				 script {
					 rf1_file_deployment_stage()
				}
			}	 
		}		

		stage('RF1-BW Deployment') {
		    when {
			     expression { VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['BW_VERSION'] != "NA" }.size() != 0 }
			    }
			steps {
				script {
					def userInputRF1BW = input(
						  id: 'userInputRF1BW', message: 'Proceed with RF1 BW Deployment?',
						  submitterParameter: 'submitter'
						)
					// Calling RF1 BW Deployment
					RF_bw_deployment_stage()
					trigger_results_email map: VERSIONS_MAP, REPORT_STAGE: "RF1-BW-Deployment"
				}
			}
		}
		
		//GV_Utility_changes
		stage('RF1_POST_GVDiff') {
			steps {
				script{
					try {
						RF1_POST_GVDiff_Stage()
						} 
						catch(Exception e)
						{
						println("GV_POSTDiff stage failed, skipping the stage")
						
						def Error=e.toString()
						
						emailext mimeType: 'text/html',
						subject: "[Jenkins]: ${currentBuild.fullDisplayName}  - RF1 Post GV DIFF Stage",
						from:"CICD_ISTILDeploymentStatus@vodafone.com",
						to: "${mailRecipients}",
						body: 	"RF1 Post GV DIFF Stage failed and is not able to generate the output because of error ${Error} "
							}
                }				
			}			
		}
		
		stage('RF1-BW Restart') {
		    when {
			     expression { VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['BW_VERSION'] != "NA" }.size() != 0 }
			    }
			steps {
				echo "BW Restart"
				script{
					// Calling BW Restart Stage function
				 	bw_restart_stage()
					trigger_results_email map: VERSIONS_MAP, REPORT_STAGE: "RF1-BW-RESTART"
				} 
			}
		}		
		stage('EMS/File/SQL_RB_RF1_FailurEngines') {
			steps {
				script {
					rf1_failure_engines_stage()
					//[CICD-977] Insert Deployment metadata to deployment history DB and get deployment ID for the entered record after RF1 stage.
					VERSIONS_MAP.keySet().each { engi -> 
							def deployment_time = VERSIONS_MAP[engi]['SQL_DURATION'] + VERSIONS_MAP[engi]['EMS_DURATION'] + VERSIONS_MAP[engi]['BW_DURATION']
							
							def insert_query = """Insert into CICD_DEPLOYMENT_HISTORY ("Release","DateTime","CRQ","ComponentType","Environment","EngineName","BwVersion","EmsVersion","SqlVersion","GatewayVersion","BwDeploymentType","DeploymentStatus","DeploymentTime","XmlFiles","JarFiles","EmailFiles","RF1Status","RBStatus","RF2Status","DVTStatus","BWConfigTag","ChangeDescription","User","FailureReason","updatedTimestamp") values ('${params.RELEASE}',sysdate,'${params.CRQ}','BW','${params.Target_Env}','${engi}','${VERSIONS_MAP[engi]['BW_VERSION']}','${VERSIONS_MAP[engi]['EMS_VERSION']}','${VERSIONS_MAP[engi]['SQL_VERSION']}','','${VERSIONS_MAP[engi]['BW_ENGINE_TYPE']}','Active','${deployment_time}','${VERSIONS_MAP[engi]['XML_FILES']}','${VERSIONS_MAP[engi]['JAR_FILES']}','${VERSIONS_MAP[engi]['EMAIL_FILES']}','${VERSIONS_MAP[engi]['RF1_RESULT']}','${VERSIONS_MAP[engi]['RB_RESULT']}','${VERSIONS_MAP[engi]['RF2_RESULT']}','','','${params.Description}','${user}','${VERSIONS_MAP[engi]['RESULT']}',sysdate)"""

							println("DEBUG: Insert query is: " + insert_query)
							DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: insert_query
							
							// Get DeploymentId for the inserted record and update map with that value.
							def selQuery = """SELECT * FROM (SELECT * FROM CICD_DEPLOYMENT_HISTORY WHERE \"EngineName\"=\'${engi}\' and \"DeploymentStatus\"=\'Active\' and \"Environment\"=\'${params.Target_Env}\' and \"BwVersion\"=\'${VERSIONS_MAP[engi]['BW_VERSION']}\' and \"EmsVersion\"=\'${VERSIONS_MAP[engi]['EMS_VERSION']}\' and \"SqlVersion\"=\'${VERSIONS_MAP[engi]['SQL_VERSION']}\' ORDER BY \"DeploymentId\" DESC) WHERE ROWNUM = 1"""
							
							println("DEBUG: Select query for DB is: " + selQuery)
							
							// Get DB row id to maps for each of the inserted engines in the above step.
							DB_Functions.get_db_row_id_to_map map: VERSIONS_MAP, dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", selQuery: selQuery, engine: engi
					}
					println("DEBUG: MAP after RF1:" + VERSIONS_MAP)
					def userInput = input(
						id: 'userInput', message: 'Proceed with RB Deployment?',
						submitterParameter: 'submitter'
					)					
				}
			}
		}
		
		stage('RB-SQL Deployment') {
		    when {
			     expression { VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['SQL_VERSION'] != "NA" }.size() != 0 }
			    }
			steps {
				script {
					def userInputRBSQL = input(
						  id: 'userInputRBSQL', message: 'Proceed with RB SQL Deployment?',
						  submitterParameter: 'submitter'
						)
					// run BW_Generation stage with existing loogic.
					// Get list of engines for EMS deployment.
					sql_map = VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['SQL_VERSION'] != "NA" }
					sql_ver_map = sql_map.collectEntries {sql_map_key, sql_map_value -> [sql_map_key, sql_map_value['SQL_VERSION']]}
					String sql_versions = mapFunc.convert_map_to_string engine_map:sql_ver_map
					println("DEBUG:" + sql_versions)
					sql_rollback_engines_list = sql_ver_map.keySet().join(';')
					
					// Call rollback function by providing environment Details and engines
					SQL_Functions.sql_explicit_rollback Environment:"${params.Target_Env}", crq_no:"${params.CRQ}", repo_artifact_ids: sql_versions, datetime:"${date_now}", release:"${params.RELEASE}"
					
					
 					// Update maps with failed engines
					def sql_failed_path = "${WORKSPACE}/SQL_Deploy_${params.Target_Env}/SQL_Deployment/sqlrollback_failure.txt"
					
					// Update maps with failed engines
					def sql_success_path = "${WORKSPACE}/SQL_Deploy_${params.Target_Env}/SQL_Deployment/sqlrollback_success.txt"
					
					if(fileExists(sql_failed_path)) {
						def sql_failed_ouput = readFile("${WORKSPACE}/SQL_Deploy_${params.Target_Env}/SQL_Deployment/sqlrollback_failure.txt")
						if (sql_failed_ouput.size() != 0) {
							 def failed_file = new File("${WORKSPACE}/SQL_Deploy_${params.Target_Env}/SQL_Deployment/sqlrollback_failure.txt")
							 def sql_failed_engines_list = failed_file.readLines().join(';')
							 mapFunc.update_version_map_result map: VERSIONS_MAP, engines: sql_failed_engines_list, stage: "SQL_Deployment", status:"FAILED"
 						}
					}					
					echo "SQL RB stage completed"
					//trigger_results_email map: VERSIONS_MAP, REPORT_STAGE: "RB_SQL_Deployment"
					//[780325]: Attach SQL logs in the email while sending SQL deployment status
					emailext mimeType: 'text/html',
					subject: "[Jenkins]: ${currentBuild.fullDisplayName}  - " + "Upliftment Results Summary",
					from:"CICD_ISTILDeploymentStatus@vodafone.com",
					to: "${mailRecipients}",
					body: 	"${emailFunc.get_sit_results_email_summary map: VERSIONS_MAP, REPORT_STAGE: 'RB_SQL_Deployment'}",
					attachmentsPattern: "**/SQL_Deploy_${params.Target_Env}/SQL_Deployment/SQL_Logs/*.zip"
					//[780325]: Changes END
				}
			}
		} 
		stage('RB-EMS Deployment') {
		    when {
			     expression { VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['EMS_VERSION'] != "NA" }.size() != 0 }
			    }
			steps {
				script {
					def userInputRBEMS = input(
						  id: 'userInputRBEMS', message: 'Proceed with RB EMS Deployment?',
						  submitterParameter: 'submitter'
						)
					// run BW_Generation stage with existing loogic.
					// Get list of engines for EMS Rollback.
					ems_map = VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['EMS_VERSION'] != "NA" }
					ems_ver_map = ems_map.collectEntries {ems_map_key, ems_map_value -> [ems_map_key, ems_map_value['EMS_VERSION']]}
					String ems_versions = mapFunc.convert_map_to_string engine_map:ems_ver_map

                    ems_rollback_engines_list = ems_ver_map.keySet().join(';')					
					// Calling EMS Rollback Function
					EMS_Functions.ems_rollback Environment:"${params.Target_Env}", crq_no:"${params.CRQ}", ems_engines:"${ems_rollback_engines_list}", datetime:"${date_now}", release:"${params.RELEASE}", emsIgnore:"${env.emsIgnore}", rollbackBackup:false

					// Update Maps with failed engines
					def ems_deployment_failed_file = "${WORKSPACE}/EMS_Deploy_${params.Target_Env}/EMS_Deployment/rollback_failure.txt"
					if(fileExists(ems_deployment_failed_file)) {
						def ems_deployment_failed_ouput = readFile("${WORKSPACE}/EMS_Deploy_${params.Target_Env}/EMS_Deployment/rollback_failure.txt")
						if (ems_deployment_failed_ouput.size() != 0) {
							def failed_file = new File("${WORKSPACE}/EMS_Deploy_${params.Target_Env}/EMS_Deployment/rollback_failure.txt")
							def ems_failed_engines_list = failed_file.readLines().join(';')
							mapFunc.update_version_map_result map: VERSIONS_MAP, engines: ems_failed_engines_list, stage: "EMS_Deployment", status:"FAILED"
						}
					}					
					         //trigger_results_email map: VERSIONS_MAP, REPORT_STAGE: "RB_EMS_Deployment"
		//[780325]: Attach EMS logs in the email while sending EMS deployment status
		emailext mimeType: 'text/html',
		subject: "[Jenkins]: ${currentBuild.fullDisplayName}  - " + "Upliftment Results Summary",
		from:"CICD_ISTILDeploymentStatus@vodafone.com",
		to: "${mailRecipients}",
		body: 	"${emailFunc.get_sit_results_email_summary map: VERSIONS_MAP, REPORT_STAGE: 'RB_EMS_Deployment'}",
		attachmentsPattern: "**/EMS_Deploy_${params.Target_Env}/EMS_Deployment/EMS_Logs/*.zip"
		//[780325]: Changes END
				}
			}
		}
		
		stage('RB-File Deployment') {
			steps {
				script {
					 RB_File_Deployment_Stage()
					 trigger_results_email map: VERSIONS_MAP, REPORT_STAGE: "RB-FILE_DEPLOYMENT"
				}
			}	 
		}
		
		stage('RB-BW Deployment') {
		    when {
			     expression { VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['BW_VERSION'] != "NA" }.size() != 0 }
			    }
			steps {
				script {
					def userInputRBBW = input(
						  id: 'userInputRBBW', message: 'Proceed with RB BW Deployment?',
						  submitterParameter: 'submitter'
						)
					RB_bw_deployment_stage()
				  	
				}
			}
		}
		
		stage('RB-BW Restart') {
		    when {
			     expression { VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['BW_VERSION'] != "NA" }.size() != 0 }
			    }
			steps {
				echo "BW Restart"
				script{
					// Calling BW Restart Stage function
				 	bw_restart_stage()
					trigger_results_email map: VERSIONS_MAP, REPORT_STAGE: "RB_BW_RESTART"
				} 
			}
		}
		
		stage('EMS/File/SQL_RB_RB_FailurEngines') {
			steps {
				script {
					RB_PostDeployment()
				}
			}
		}

		stage('RF2-SQL Deployment') {
		    when {
			     expression { VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['SQL_VERSION'] != "NA" }.size() != 0 }
			    }
			steps {
				script {
					def userInputRF2SQL = input(
						  id: 'userInputRF2SQL', message: 'Proceed with RF2 SQL Deployment?',
						  submitterParameter: 'submitter'
						)
					// run BW_Generation stage with existing loogic.
					// Get list of engines for EMS deployment.
					sql_map = VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['SQL_VERSION'] != "NA" }
					sql_ver_map = sql_map.collectEntries {sql_map_key, sql_map_value -> [sql_map_key, sql_map_value['SQL_VERSION']]}
					String sql_versions = mapFunc.convert_map_to_string engine_map:sql_ver_map
					println("DEBUG:" + sql_versions)

					// Call sql deploy function by providing environment Details and engines
					SQL_Functions.sql_deploy Environment:"${params.Target_Env}", nexus_group_id:"${env.SQL_GROUPID}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.REPO}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CRQ}", repo_artifact_ids:"${sql_versions}", datetime:"${date_now}", release:"${params.RELEASE}"
					
 					// Update maps with failed engines
					def sql_failed_path = "${WORKSPACE}/SQL_Deploy_${params.Target_Env}/SQL_Deployment/sqlDeploy_failure.txt"
					
					// Update maps with failed engines
					def sql_success_path = "${WORKSPACE}/SQL_Deploy_${params.Target_Env}/SQL_Deployment/sqlDeploy_success.txt"
					if(fileExists(sql_failed_path)) {
						def sql_failed_ouput = readFile("${WORKSPACE}/SQL_Deploy_${params.Target_Env}/SQL_Deployment/sqlDeploy_failure.txt")
						if (sql_failed_ouput.size() != 0) {
							 def failed_file = new File("${WORKSPACE}/SQL_Deploy_${params.Target_Env}/SQL_Deployment/sqlDeploy_failure.txt")
							 def sql_failed_engines_list = failed_file.readLines().join(';')
							 mapFunc.update_version_map_result map: VERSIONS_MAP, engines: sql_failed_engines_list, stage: "SQL_Deployment", status:"FAILED"
 						}
					}					
					echo "SQL_DEPLOYMENT stage completed"
					//trigger_results_email map: VERSIONS_MAP, REPORT_STAGE: "RF2_SQL_Deployment"
					//[780325]: Attach SQL logs in the email while sending SQL deployment status
					emailext mimeType: 'text/html',
					subject: "[Jenkins]: ${currentBuild.fullDisplayName}  - " + "Upliftment Results Summary",
					from:"CICD_ISTILDeploymentStatus@vodafone.com",
					to: "${mailRecipients}",
					body: 	"${emailFunc.get_sit_results_email_summary map: VERSIONS_MAP, REPORT_STAGE: 'RF2_SQL_Deployment'}",
					attachmentsPattern: "**/SQL_Deploy_${params.Target_Env}/SQL_Deployment/SQL_Logs/*.zip"
					//[780325]: Changes END
				}
			}
		} 		
		
		stage('RF2-EMS Deployment') {
		    when {
			     expression { VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['EMS_VERSION'] != "NA" }.size() != 0 }
			    }
			steps {
				script {
					def userInputRF2EMS = input(
						  id: 'userInputRF2EMS', message: 'Proceed with RF2 EMS Deployment?',
						  submitterParameter: 'submitter'
						)
					ems_rf_deployment_stage()					
					//trigger_results_email map: VERSIONS_MAP, REPORT_STAGE: "RF2_EMS_Deployment"
					//[780325]: Attach EMS logs in the email while sending EMS deployment status
					emailext mimeType: 'text/html',
					subject: "[Jenkins]: ${currentBuild.fullDisplayName}  - " + "Upliftment Results Summary",
					from:"CICD_ISTILDeploymentStatus@vodafone.com",
					to: "${mailRecipients}",
					body: 	"${emailFunc.get_sit_results_email_summary map: VERSIONS_MAP, REPORT_STAGE: 'RF2_EMS_Deployment'}",
					attachmentsPattern: "**/EMS_Deploy_${params.Target_Env}/EMS_Deployment/EMS_Logs/*.zip"
					//[780325]: Changes END
				}
			}
		} 
		
		stage('RF2-File Deployment') {
			steps {
				 script {
					 
					file_rf_deployment_stage() 
					
				    trigger_results_email map: VERSIONS_MAP, REPORT_STAGE: "RF2_FILE_Deployment"
				}	 
			}
		}		

		stage('RF2-BW Deployment') {
		    when {
			     expression { VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['BW_VERSION'] != "NA" }.size() != 0 }
			    }
			steps {
				script {
					def userInputRF2BW = input(
						  id: 'userInputRF2BW', message: 'Proceed with RF2 BW Deployment?',
						  submitterParameter: 'submitter'
						)
					// Calling RF1 BW Deployment
					RF_bw_deployment_stage()
					trigger_results_email map: VERSIONS_MAP, REPORT_STAGE: "RF2_BW_Deployment"
				}
			}
		}
		
		//GV_Utility_changes
		stage('RF2_POST_GVDiff') {
			steps {
				script{
					try {
						RF2_POST_GVDiff_Stage()
						} 
						catch(Exception e) 
						{
						println("GV_POSTDiff stage failed, skipping the stage")
						
						def Error=e.toString()
						
						emailext mimeType: 'text/html',
						subject: "[Jenkins]: ${currentBuild.fullDisplayName}  - RF2 Post GV DIFF Stage",
						from:"CICD_ISTILDeploymentStatus@vodafone.com",
						to: "${mailRecipients}",
						body: 	"RF2 Post GV DIFF Stage failed and is not able to generate the output because of error ${Error} "
							}
                }				
			}			
		}
		
		stage('RF2-BW Restart') {
		    when {
			     expression { VERSIONS_MAP.findAll { it.value['RESULT'] != "FAILED" && it.value['BW_VERSION'] != "NA" }.size() != 0 }
			    }
			steps {
				echo "BW Restart"
				script{
					// Calling BW Restart Stage function
				 	bw_restart_stage()
					trigger_results_email map: VERSIONS_MAP, REPORT_STAGE: "RF2_BW_RESTART"
				} 
			}
		} 		
		stage('EMS/File/SQL_RB_RF2_FailurEngines') {
			steps {
				script {
					rf2_failure_engines_stage()
					//[CICD-977] Update Deployment History DB with RB result for each of the engine passed RF1 stage and done with RB stage.
					VERSIONS_MAP.keySet().each { engi -> 
							//Update record with status after RB stage.
							def updateQuery = """UPDATE CICD_DEPLOYMENT_HISTORY SET \"updatedTimestamp\"=sysdate, \"RF2Status\"=\'${VERSIONS_MAP[engi]['RF2_RESULT']}\', \"FailureReason\"=\'${VERSIONS_MAP[engi]['RESULT']}\' WHERE \"DeploymentId\"=\'${VERSIONS_MAP[engi]['DB_ROW_ID']}\'"""
							
							DB_Functions.update_db_row_fields dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", updateQuery: updateQuery
					}					
				}
			}
		}
		
		stage('TILSTG01 Signoff'){
		when {
			expression { VERSIONS_MAP.findAll { it.value['RESULT'] == "PASSED" }.size() != 0 }
			}
		steps {
			script {
				
				//[CICD-476] Fix: call update function to populate stats into a file.
				//[CICD-374] Fix: Update dash board as well along with stats file.
				commonFunctions.update_report_stats map: VERSIONS_MAP, Release: "${params.RELEASE}", environment: "${params.Target_Env}", statsFile: "/opt/tibco/DevOps_Reporting/Report/DevOps_report.txt", pipeline_name: 'TILSTG01/pipelines/Deployment_pipelines/TILBW_pipelines/TILSTG01_Pipeline'
				//[CICD-977] Fix: Removing the DB entry from here as it was handled in previous stages.
				
				//[CICD-448] Fix: Update release notes DB for all the engines successfully deployed in TILSTG01 as completed. These engines will not be picked for release notes any longer.
				// For all the engine records matching the release, mark them as complete.
				VERSIONS_MAP.keySet().each { engi -> 
						//Update record with status after RB stage.
						def updateQuery = """UPDATE CICD_RELEASE_SUMMARY SET \"MODIFIED_ON\"=sysdate, \"STATUS\"=\'Completed\', \"MODIFIED_BY\"=\'${user}\' WHERE \"RELEASE_NO\"=\'${params.RELEASE}\' and \"ENGINE_NAME\"=\'${engi}\' and \"STATUS\"=\'Active\'"""

						DB_Functions.update_db_row_fields dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", updateQuery: updateQuery
				}

				// Calling promotion stage
				def userInputRF2EMS = input(
					  id: 'userInputprmotion', message: 'Proceed with promotion?',
					  submitterParameter: 'submitter'
				)				
				artefact_promotion_stage()				
				clean_deployment_workspace()
				                                
			}
		}
      }
		
	}
}
