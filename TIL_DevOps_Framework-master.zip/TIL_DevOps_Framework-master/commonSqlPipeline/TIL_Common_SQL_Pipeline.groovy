@Library('myLibrary@master') _
commonSqlPipeline (
	RELEASE: params.RELEASE,
	BUILD_REQUESTER: params.BUILD_REQUESTER,
	CRQ: params.CRQ_NUMBER,
	DESCRIPTION: params.DESCRIPTION,
	RESTART_ENGINES: params.RESTART_ENGINES,
	ENVIRONMENT: params.ENVIRONMENT,
	BACKUP_TABLES: params.BACKUP_TABLES,
	ENGINE_NAME: "Common_SQL_Changes"
)
