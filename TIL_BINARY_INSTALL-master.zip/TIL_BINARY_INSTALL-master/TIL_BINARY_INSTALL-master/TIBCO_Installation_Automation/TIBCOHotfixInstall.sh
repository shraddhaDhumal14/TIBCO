# For adding the new softwares in the list user need to follow the below syntax and host value should be changed as per the new package.
####if you don't want to install any of the below listed softwares then comment the entries as below by keeping # symbol.
#echo 'Installing RV'
#if ! ansible-playbook TIBCOSoftwareInstall.yml -e host="RVHF"; then
#        echo ' RV installation failed'
#        exit 1
#fi

##################ask user to enter the software which is required to install#######
echo  "Enter the software keyword which is required to install."
read -p "Softwares are RVHF, BWHF, EMSHF, EMSHF_8.5, AdminHF, APIGatewayHF, SDKHF, ADBHF, TRAHF, HAWKHF, EJBPluginHF, RestJsonPluginHF, FTPPluginHF:-" SW 

############Display the list of software version and server details################
echo "Hi, $SW. is going to install, Please verify the server details and software version properly listed and proceed!!!"
ansible-playbook TIBCODisplayInformation.yml -e host="$SW"

#############Confirm if installation required with above listed software or not#####
echo "Do you wish to install all the above listed softwares in the specified destination server?"
select yn in "Yes" "No"; do
    case $yn in
        Yes ) make install; break;;
        No ) exit;;
    esac
done

########software installation starts here#############

ansible-playbook TIBCOHotfixInstall.yml  -e host="$SW" 2>&1 | tee $HOME/install/TIBCO_Installation_Automation/Automation_Installation.log
echo "$SW Execution is completed, please verify if any error above or check the failed count."

######################################################
