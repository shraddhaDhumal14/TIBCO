# For adding the new softwares in the list user need to follow the below syntax and host value should be changed as per the new package.
####if you don't want to install any of the below listed softwares then comment the entries as below by keeping # symbol.
#echo 'Installing RV'
#if ! ansible-playbook TIBCOSoftwareInstall.yml -e host="RV"; then
#        echo ' RV installation failed'
#        exit 1
#fi





############Display the list of software version and server details################
ansible-playbook TIBCODisplayInformation.yml -e host="all"

#############Confirm if installation required with above listed software or not#####
echo "Do you wish to install all the above listed softwares in the specified destination server?"
select yn in "Yes" "No"; do
    case $yn in
        Yes ) make install; break;;
        No ) exit;;
    esac
done


########software installation starts here#############

echo 'Installing RV'

if ! ansible-playbook TIBCOSoftwareInstall.yml -e host="RV" 2>&1 | tee $HOME/install/TIBCO_Installation_Automation/Automation_Installation.log; then
        echo ' RV installation failed'
        exit 1
fi
echo 'Installing EMS'

if ! ansible-playbook TIBCOSoftwareInstall.yml -e host="EMS" 2>&1 | tee $HOME/install/TIBCO_Installation_Automation/Automation_Installation.log; then
        echo 'EMS installation failed'
        exit 1
fi
#echo 'Installing TRA'

if ! ansible-playbook TIBCOSoftwareInstall.yml -e host="TRA" 2>&1 | tee $HOME/install/TIBCO_Installation_Automation/Automation_Installation.log; then
        echo ' TRA installation failed'
        exit 1
fi
echo 'Installing BW'

if ! ansible-playbook TIBCOSoftwareInstall.yml -e host="BW" 2>&1 | tee $HOME/install/TIBCO_Installation_Automation/Automation_Installation.log; then
        echo ' BW installation failed'
        exit 1
fi
echo 'Installing Admin'

if ! ansible-playbook TIBCOSoftwareInstall.yml -e host="Admin" 2>&1 | tee $HOME/install/TIBCO_Installation_Automation/Automation_Installation.log; then
        echo ' Admin installation failed'
        exit 1
fi
echo 'Installing API'

if ! ansible-playbook TIBCOSoftwareInstall.yml -e host="APIGateway" 2>&1 | tee $HOME/install/TIBCO_Installation_Automation/Automation_Installation.log; then
        echo 'APIGateway installation failed'
        exit 1
fi
echo 'Installing SDK'

if ! ansible-playbook TIBCOSoftwareInstall.yml -e host="SDK" 2>&1 | tee $HOME/install/TIBCO_Installation_Automation/Automation_Installation.log; then
        echo 'SDK installation failed'
       exit 1
fi
echo 'Installing ADB'

if ! ansible-playbook TIBCOSoftwareInstall.yml -e host="ADB" 2>&1 | tee $HOME/TIBCO_Installation_Automation/Automation_Installation.log; then
        echo 'ADB installation failed'
        exit 1
fi
echo 'Installing EJBPlugin'

if ! ansible-playbook TIBCOSoftwareInstall.yml -e host="EJBPlugin" 2>&1 | tee $HOME/install/TIBCO_Installation_Automation/Automation_Installation.log; then
        echo 'EJBPlugin installation failed'
        exit 1
fi
echo 'Installing RestJsonPlugin'

if ! ansible-playbook TIBCOSoftwareInstall.yml -e host="RestJsonPlugin" 2>&1 | tee $HOME/install/TIBCO_Installation_Automation/Automation_Installation.log; then
        echo 'RestJsonPlugin installation failed'
        exit 1
fi
echo 'Installing FTPPlugin'

if ! ansible-playbook TIBCOSoftwareInstall.yml -e host="FTPPlugin" 2>&1 | tee $HOME/install/TIBCO_Installation_Automation/Automation_Installation.log; then
        echo 'FTPPlugin installation failed'
        exit 1
fi






