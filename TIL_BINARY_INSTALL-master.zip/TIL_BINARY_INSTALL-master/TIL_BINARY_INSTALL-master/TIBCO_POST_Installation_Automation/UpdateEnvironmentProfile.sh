ansible-playbook EnvProfileUpdate/bash.yml -e host="all"
