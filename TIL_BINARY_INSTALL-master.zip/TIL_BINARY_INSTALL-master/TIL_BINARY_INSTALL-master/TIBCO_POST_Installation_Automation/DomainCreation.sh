ansible-playbook DomainCreation/domainCreation.yml -e host="Admin"
