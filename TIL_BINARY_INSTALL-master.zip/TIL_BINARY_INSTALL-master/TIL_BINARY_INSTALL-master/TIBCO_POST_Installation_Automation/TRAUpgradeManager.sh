ansible-playbook TRAUpgradeManager/TraUpgradeManager.yml -e host="BW,EMS,Admin"
