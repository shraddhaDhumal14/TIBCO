ansible-playbook AddJMSServer/AddJMSServer.yml -e host="Admin"
