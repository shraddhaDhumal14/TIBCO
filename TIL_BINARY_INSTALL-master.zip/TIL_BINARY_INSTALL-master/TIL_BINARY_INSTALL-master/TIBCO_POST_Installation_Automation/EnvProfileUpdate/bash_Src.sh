# .bash_profile 1

# Get the aliases and functions
if [ -f ~/.bashrc ]; then
        . ~/.bashrc
fi

# User specific environment and startup programs
PATH=$PATH:$HOME/bin:/sbin:/usr/sbin:/opt/tibco/tibcojre64/1.8.0/bin
export PATH

# TIL-DR Server ALIAS
alias logs='cd /opt/tibco/tra/domain/LNKTest01/application/logs'
alias tibco='cd /opt/tibco/'
alias ems='cd /opt/tibco/ems/'
alias tralogs='cd /opt/tibco/tra/domain/LNKTest01/logs'
alias hawk='cd /opt/tibco/tra/domain/LNKTest01'
alias admin='cd /opt/tibco/administrator/domain/LNKTest01/bin'

#Activespace - as part of DR Swindon project
#CLASSPATH=/opt/tibco/as/2.1/lib/as-common.jar:/opt/tibco/as/2.1/lib/as-admin.jar:/opt/tibco/
#JAVA_HOME=/opt/tibco/tibcojre64/1.8.0
#PATH=$JAVA_HOME/bin:$PATH
#TIBCO_HOME=/opt/tibco
#TRA_HOME=/opt/tibco/tra/5.11
#export PATH
#export LD_LIBRARY_PATH
#export CLASSPATH


