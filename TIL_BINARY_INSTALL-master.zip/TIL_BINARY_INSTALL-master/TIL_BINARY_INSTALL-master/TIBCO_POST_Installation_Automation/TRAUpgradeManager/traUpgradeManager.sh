Tibco_Home=$1
TRA_Version=$2
BW_Version=$3
TIBRV_Version=$4
EMS_Version=$5
export PATH=${PATH}:${Tibco_Home}/tra/${TRA_Version}/bin

export PATH=${PATH}:${Tibco_Home}/bw/${BW_Version}/bin

export PATH=${PATH}:${Tibco_Home}/tibrv/${TIBRV_Version}/bin
				
export PATH=${PATH}:${Tibco_Home}/ems/${EMS_Version}/bin


echo "----- All paths added to CLASSPATH -----"

cd ${Tibco_Home}/tra/5.11/bin
./traUpgradeManager -path ${Tibco_Home} -ems ${Tibco_Home}/ems/${EMS_Version}
