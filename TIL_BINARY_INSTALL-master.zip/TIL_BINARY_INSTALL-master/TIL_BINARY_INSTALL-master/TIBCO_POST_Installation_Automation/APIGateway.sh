ansible-playbook APIGateway/API_Exchange_Post.yml -e host="APIGateway"
