xmlfile=${1}
Tibco_Home=${2}
RS_Dest_Path=${3}
TRA_Version=${4}
cd ${Tibco_Home}/tra/${TRA_Version}/template/domainutility/cmdline
mkdir ${Tibco_Home}/tra/${TRA_Version}/template/domainutility/cmdline/tmp
cd ${RS_Dest_Path}
cp ${RS_Dest_Path}/${xmlfile} ${Tibco_Home}/tra/${TRA_Version}/template/domainutility/cmdline/tmp/${xmlfile}
cd ${Tibco_Home}/tra/${TRA_Version}/bin
./domainutilitycmd -cmdFile ${Tibco_Home}/${TRA_Version}/template/domainutility/cmdline/tmp/${xmlfile}
echo "----- JMS Details Added -----"