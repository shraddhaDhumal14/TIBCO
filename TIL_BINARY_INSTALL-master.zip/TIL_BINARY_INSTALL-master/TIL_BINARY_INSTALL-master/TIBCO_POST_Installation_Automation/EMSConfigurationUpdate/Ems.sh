RS_EMS_PATH=$1 #[/opt/tibco/configurations/tibco/cfgmgmt/ems]
EMS_PORT=$2 #[5122 5422 6122 7122 ]
SERVER_NAME=$3 #[LNKTEST-01]
SERVER_ID=$4 #[LNKTEST02]
CONF_FILE=$5
ENV_NAME=$6
EMS_Version=$7
RS_Dest_Path=$8
Tibco_Home=$9
HOSTNAME="${10}"
echo $HOSTNAME
EMS_PATH=$RS_EMS_PATH/$SERVER_ID/$EMS_PORT
cd $RS_EMS_PATH
mkdir $SERVER_ID
cd ${RS_Dest_Path}
mv ${RS_Dest_Path}/$CONF_FILE $EMS_PATH
#echo $EMS_PATH
#echo $SERVER_NAME
cd $EMS_PATH
sed -i "s#server \(.*\)=.*#server \1= $SERVER_NAME#" tibemsd.conf
sed -i "s#users \(.*\)=.*#users \1= "$EMS_PATH/users.conf"#" tibemsd.conf
sed -i "s#groups \(.*\)=.*#groups \1= "$EMS_PATH/groups.conf"#" tibemsd.conf
sed -i "s#topics \(.*\)=.*#topics \1= "$EMS_PATH/topics.conf"#" tibemsd.conf
sed -i "s#queues \(.*\)=.*#queues \1= "$EMS_PATH/queues.conf"#" tibemsd.conf
sed -i "s#acl_list \(.*\)=.*#acl_list \1= "$EMS_PATH/acl_list.conf"#" tibemsd.conf
sed -i "s#factories \(.*\)=.*#factories \1= "$EMS_PATH/factories.conf"#" tibemsd.conf
sed -i "s#routes \(.*\)=.*#routes \1= "$EMS_PATH/routes.conf"#" tibemsd.conf
sed -i "s#bridges \(.*\)=.*#bridges \1= "$EMS_PATH/bridges.conf"#" tibemsd.conf
sed -i "s#transports \(.*\)=.*#transports \1= "$EMS_PATH/transports.conf"#" tibemsd.conf
sed -i "s#tibrvcm \(.*\)=.*#tibrvcm \1= "$EMS_PATH/tibrvcm.conf"#" tibemsd.conf
sed -i "s#durables \(.*\)=.*#durables \1= "$EMS_PATH/durables.conf"#" tibemsd.conf
sed -i "s#channels \(.*\)=.*#channels \1= "$EMS_PATH/channels.conf"#" tibemsd.conf
sed -i "s#stores \(.*\)=.*#stores \1= "$EMS_PATH/stores.conf"#" tibemsd.conf
sed -i "s#listen \(.*\)=.*#listen \1= tcp://$EMS_PORT#" tibemsd.conf
sed -i "s#logfile \(.*\)=.*#logfile \1= "${Tibco_Home}/log/ems/$SERVER_ID-$CONF_FILE/$SERVER_ID-$CONF_FILE.log"#" tibemsd.conf
sed -i "s#ft_active \(.*\)=.*#ft_active \1=  #" tibemsd.conf
sed -i "s/VOD.UK.PR/VOD.UK.$ENV_NAME/g" queues.conf
sed -i "s/VOD.UK.PR/VOD.UK.$ENV_NAME/g" bridges.conf
sed -i "s/VOD.UK.PR/VOD.UK.$ENV_NAME/g" topics.conf
sed -i "s#url\(.*\)= tcp://auk.*#url\1= tcp://${HOSTNAME}:$EMS_PORT,${HOSTNAME}:$EMS_PORT#" factories.conf
cd ${EMS_PATH}
rm  routes.conf
touch routes.conf
mkdir datastore
file=startEms.sh
touch ${file}
echo "cd /opt/tibco/ems/${EMS_Version}/bin" >> ${file}
echo "./tibemsd64 -config $EMS_PATH/tibemsd.conf" >> ${file}
cd $EMS_PATH
#./${file}

