RS_Dest_Path=$1
Tibco_Home=$2
TRA_Version=$3
xmlfile=$4
cd ${Tibco_Home}/tra/${TRA_Version}/bin
./domainutilitycmd -cmdFile ${RS_Dest_Path}/${xmlfile} 

