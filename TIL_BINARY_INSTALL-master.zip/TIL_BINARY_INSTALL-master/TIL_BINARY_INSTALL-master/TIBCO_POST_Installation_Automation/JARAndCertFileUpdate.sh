ansible-playbook JARAndCertFileUpdate/Jars_and_Cerificates.yml -e host="BW"
