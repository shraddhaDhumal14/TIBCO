xmlfile="$1"
Tibco_Home="$2"
TRA_Version="$3"
RS_Dest_Path="$4"
export PATH=${PATH}:${Tibco_Home}/tra/${TRA_Version}/bin
echo "----- TRA paths added to CLASSPATH -----"
cd ${Tibco_Home}/tra/${TRA_Version}/template/domainutility/cmdline/
mkdir tmp 
cp ${RS_Dest_Path}/$xmlfile ${Tibco_Home}/tra/${TRA_Version}/template/domainutility/cmdline/tmp/ 
cd ${Tibco_Home}/tra/${TRA_Version}/bin
./domainutilitycmd -cmdFile ${Tibco_Home}/tra/${TRA_Version}/template/domainutility/cmdline/tmp/$xmlfile
echo "----- Domain Created -----"




