export ANSIBLE_CONFIG=$PATH:/opt/tibco/TEMP_INSTALL_DIR/install/TIBCO_POST_Installation_Automation/ansible.cfg
ansible-playbook /opt/tibco/TEMP_INSTALL_DIR/install/TIBCO_POST_Installation_Automation/DomainCreation/domainCreation.yml -e host="BW"
