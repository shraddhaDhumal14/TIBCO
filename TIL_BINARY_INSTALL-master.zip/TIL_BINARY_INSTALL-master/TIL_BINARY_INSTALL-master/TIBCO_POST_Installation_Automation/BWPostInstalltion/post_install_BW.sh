Tibco_Home="$1"
BW_Version="$2"
RS_Dest_Path="$3"
cd ${RS_Dest_Path}
cp ${RS_Dest_Path}/bwengine.tra ${Tibco_Home}/bw/${BW_Version}/bin/bwengine.tra
cd ${Tibco_Home}/bw/${BW_Version}/bin
sed -i "s#Tibco_Home#${Tibco_Home}#g" ${Tibco_Home}/bw/${BW_Version}/bin/bwengine.tra


