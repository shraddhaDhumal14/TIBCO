ansible-playbook EMSConfigurationUpdate/EMS.yml -e host="EMS"

