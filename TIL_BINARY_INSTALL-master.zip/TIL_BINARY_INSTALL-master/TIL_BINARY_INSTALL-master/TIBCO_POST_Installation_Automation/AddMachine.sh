export ANSIBLE_CONFIG=$PATH:/opt/tibco/install/TIBCO_POST_Installation_Automation/ansible.cfg
ansible-playbook /opt/tibco/install/TIBCO_POST_Installation_Automation/AddMachine/Ad_Machine.yml -e host="BW"
