#!/bin/sh
ProjectName=$1
DomainName=$2
Tibco_Home=$3
Tibco_Install=$4
source_path=${Tibco_Install}/configurations/tibco/cfgmgmt/asg
dest_path=${Tibco_Home}/env/${DomainName}/${ProjectName}/cfgmgmt/asg
logsource=${Tibco_Install}/configurations/tibco/cfgmgmt/asg/logs
logdest${Tibco_Home}/env/${DomainName}/${ProjectName}/cfgmgmt/asg/logs
d1=${Tibco_Install}/configurations/tibco/cfgmgmt
d2=`echo $dest_path|awk '{print $1"/asg/logs"}'`
dt=`date +'%Y%d%m%H%M'`
## Replacing the default env values with domain specific values,including log file directories
cat apps.prop|while read prop

do
echo " Replacing values for $prop file " 
orig=`echo $prop|awk -F'/' '{print $NF}'`
#do
cp $prop tmp/${orig}_bkp_beforechange_${dt}
mv $prop tmp/$orig 
#cat tmp/$orig|sed "s#$source_path#$dest_path#"|sed "s#%ASG_CONFIG_HOME%/logs#$logdest#"|sed "s#$logsource#$logdest#"|sed "s#$dest_path/asg/logs#$log_dest#" >> $prop
cat tmp/$orig|sed "s#${source_path}#${dest_path}#"|sed "s#%ASG_CONFIG_HOME%/logs#${logdest}#"|sed "s#${logsource}#${logdest}#"|sed "s#${d1}/asg/logs#${logdest}#" |sed "s#${d2}#${logdest}#" >>$prop

echo " Replaced values for $prop file "
done
