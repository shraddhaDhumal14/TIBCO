ProjectName="$1"
DomainName="$2"
FacadeHTTPPortNo="$3"
Tibco_Home="$4"
RS_Dest_Path="$5"
Tibrv_Version="$6"
Asg_Version="$7"
Tibco_Install="$8"
# 5.2	Software Prerequisite
# 5.2.1 TIBCO RV ${Tibrv_Version}.2

if ! [ -d "${Tibco_Install}/tibrv/${Tibrv_Version}" ];then

echo "Directory ${Tibco_Install}/tibrv/${Tibrv_Version} not Present ."
 else
 echo "Directory ${Tibco_Install}/tibrv/${Tibrv_Version} Present ."
 fi

# 5.2.2 API Exchange 2.1.0 & API Exchange 2.1.1 Hot Fix-1

 if ! [ -d "${Tibco_Install}/asg/${Asg_Version}" ];then

 echo "Directory ${Tibco_Install}/asg/${Asg_Version} not Present ."
 else
 echo "Directory ${Tibco_Install}/asg/${Asg_Version} Present ."
 fi


 # 5.5	Create Configuration Files
  # 5.5.1	Create Directories
   
 cd ${Tibco_Home}/
 mkdir env
 cd ${Tibco_Home}/env
 mkdir ${DomainName}
 echo "${DomainName} Directory is Created"
 cd ${Tibco_Home}/env/${DomainName}
 mkdir ${ProjectName}
 echo "${ProjectName} Directory is Created"

 cd ${Tibco_Home}/
if [ -d "${Tibco_Home}/log" ] ;then
 
  echo "Directory ${Tibco_Home}/log is Present."
   
   cd ${Tibco_Home}/log
    mkdir apx
    echo "apx Directory is Created"
   
  cd ${Tibco_Home}/log/apx
 
   mkdir ${DomainName}
   echo "${DomainName} Directory is Created"
 
  cd ${Tibco_Home}/log/apx/${DomainName}
  mkdir ${ProjectName}
  echo "${ProjectName} Directory is Created"
 
else
  echo "Directory ${Tibco_Home}/log not exists."
  cd ${Tibco_Home}
  mkdir log
  echo "Directory log is Created"
  cd ${Tibco_Home}/log
  mkdir apx
  echo "apx Directory is Created"

 cd ${Tibco_Home}/log/apx
   mkdir ${DomainName}
   echo "${DomainName} Directory is Created"
 
   cd ${Tibco_Home}/log/apx/${DomainName}
    mkdir ${ProjectName}
    echo "${ProjectName} Directory is Created"
fi

chmod 755 ${Tibco_Home}/log/apx/${DomainName}/${ProjectName} 

# 5.5.2	 Move Configuration Folder

cd ${Tibco_Install}/configurations/tibco

cp -r cfgmgmt ${Tibco_Home}/env/${DomainName}/${ProjectName}/

echo " cfgmgmt folder copied to ${Tibco_Home}/env/${DomainName}/${ProjectName} "

cd ${Tibco_Install}/asg/${Asg_Version}/bin
 cp *.tra  ${Tibco_Home}/env/${DomainName}/${ProjectName}/cfgmgmt/asg/
 cp *.cdd  ${Tibco_Home}/env/${DomainName}/${ProjectName}/cfgmgmt/asg/


# 5.5.3	Change the config file path and Log file path in tra, cdd and properties files.

cd ${Tibco_Home}/env/${DomainName}/${ProjectName}
cp -avr ${Tibco_Home}/env/${DomainName}/${ProjectName}/cfgmgmt ${Tibco_Home}/env/${DomainName}/${ProjectName}/tmp/
cd ${Tibco_Home}/env/${DomainName}/${ProjectName}
mkdir tmp/APXConfigReplace
cd ${Tibco_Home}/env/${DomainName}/${ProjectName}/tmp/APXConfigReplace
mkdir tmp
cp ${RS_Dest_Path}/replace.sh ${Tibco_Home}/env/${DomainName}/${ProjectName}/tmp/APXConfigReplace/replace.sh 
cp ${RS_Dest_Path}/apps.prop ${Tibco_Home}/env/${DomainName}/${ProjectName}/tmp/APXConfigReplace/apps.prop
cd ${Tibco_Home}/env/${DomainName}/${ProjectName}/tmp/APXConfigReplace
#sh replace.sh ${ProjectName} ${DomainName} ${Tibco_Home} ${Tibco_Install}

source_path=${Tibco_Install}/configurations/tibco/cfgmgmt/asg
dest_path=${Tibco_Home}/env/${DomainName}/${ProjectName}/cfgmgmt/asg
logsource=${Tibco_Install}/configurations/tibco/cfgmgmt/asg/logs
logdest=${Tibco_Home}/env/${DomainName}/${ProjectName}/cfgmgmt/asg/logs
d1=${Tibco_Install}/configurations/tibco/cfgmgmt

cd ${Tibco_Home}/env/${DomainName}/${ProjectName}/cfgmgmt/asg
sed -i "s#${source_path}#${dest_path}#" asg-configui.tra asg-engine.tra asg-password-hasher.tra asg-password-obfuscator.tra asg-tools.tra asg_cl.properties asg.properties asg_core.cdd asg_cl.cdd asg_validation.cdd
sed -i "s#%ASG_CONFIG_HOME%/logs#${logdest}#" asg-configui.tra asg-engine.tra asg-password-hasher.tra asg-password-obfuscator.tra asg-tools.tra asg_cl.properties asg.properties asg_core.cdd asg_cl.cdd asg_validation.cdd
sed -i "s#${logsource}#${logdest}#" asg-configui.tra asg-engine.tra asg-password-hasher.tra asg-password-obfuscator.tra asg-tools.tra asg_cl.properties asg.properties asg_core.cdd asg_cl.cdd asg_validation.cdd
sed -i "s#${d1}/asg/logs#${logdest}#" asg-configui.tra asg-engine.tra asg-password-hasher.tra asg-password-obfuscator.tra asg-tools.tra asg_cl.properties asg.properties asg_core.cdd asg_cl.cdd asg_validation.cdd


cd ${Tibco_Home}/env/${DomainName}/${ProjectName}/cfgmgmt/asg
 cp asg_core.cdd asg_core.cdd ${Tibco_Home}/env/${DomainName}/${ProjectName}/cfgmgmt/asg/

cd ${Tibco_Home}/env/${DomainName}/${ProjectName}/cfgmgmt/asg
 cp asg.properties asg_${ProjectName}_${FacadeHTTPPortNo}.properties
 
# Removing  ems  hawk Folders

cd ${Tibco_Home}/env/${DomainName}/${ProjectName}/cfgmgmt
rm -rf ems hawk
