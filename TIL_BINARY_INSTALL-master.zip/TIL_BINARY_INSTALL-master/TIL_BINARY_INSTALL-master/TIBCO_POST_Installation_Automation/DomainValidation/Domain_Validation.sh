xmlfile="$1"
domainName="$2"
TRA_Version="$3"
Tibco_Home="$4"
if ! find  ${Tibco_Home}/tra/domain/${domainName}/hawkagent_${domainName};then

echo -----hawkagent_${domainName} creation Un_Success-----
 else 
 echo -----hawkagent_${domainName} creation Success-----
 fi
 
 if ! find  ${Tibco_Home}/administrator/domain/${domainName}/bin/tibcoadmin_${domainName};then

echo -----tibcoadmin_${domainName} creation Un_Success-----
 else 
  echo -----tibcoadmin_${domainName} creation Success-----
  fi
  
  mkdir ${Tibco_Home}/tra/domain/${domainName}/tmp
  cp ${Tibco_Home}/tra/${TRA_Version}/template/domainutility/cmdline/tmp/${xmlfile} ${Tibco_Home}/tra/domain/${domainName}/tmp

echo "----- ${xmlfile} file coped to ${domainName}/tmp  Dir -----"

rm -rf  ${Tibco_Home}/tra/${TRA_Version}/template/domainutility/cmdline/tmp

echo "----- Removed Temp/${xmlfile} Dir -----"/
