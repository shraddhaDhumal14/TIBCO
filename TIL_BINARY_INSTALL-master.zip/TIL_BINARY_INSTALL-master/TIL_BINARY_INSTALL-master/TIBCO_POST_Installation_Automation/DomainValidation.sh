ansible-playbook DomainValidation/domain_Validation.yml -e host="Admin"
