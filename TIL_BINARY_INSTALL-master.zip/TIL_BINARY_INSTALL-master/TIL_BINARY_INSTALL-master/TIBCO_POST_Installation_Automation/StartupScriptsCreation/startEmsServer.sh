#!/bin/sh
###############################################################################
# Copyright 2004 TIBCO Software Inc. All rights reserved.
#
# This script controls one EMS Server that has been registered into one TIBCO
# domain (the folder containing this script must have the same name as the 
# domain).
#
# This script takes two arguments: EMS Port Number
#                                  "start", "stop" or "check"
#
# You must copy this script in each environment/domain.
# Example:
# 	/opt/tibco/env/MyDomain1/startEmsServer.sh for domain MyDomain1
#
# Build 1_03:
# - Added -follow to find command so symbolic links are resolved.
# - Moved EMS_SERVER variable to tibco.sh script.
# - Fixed findPid function for Linux.
#
# Build 1_04:
# - Fixed missing quote on line 139
#
# Build 1_05:
# - Fixed findPid function for HPUX
#
# $Header: /cvs/TIL_SOURCE/scripts/env/MyDomain1/startEmsServer.sh,v 1.9 2006/08/02 11:20:33 ayelr Exp $
###############################################################################

###############################################################################
# CHANGE THE FOLLOWING VARIABLE VALUES IF NECESSARY
###############################################################################

###############################################################################
# DO NOT CHANGE THE REST OF THE SCRIPT
###############################################################################

###############################################################################
# Guess the domain name from the path of the script itself

# folder of this script itself
DIRSCRIPT=`dirname "$0"`
DIRSCRIPT=`(cd "${DIRSCRIPT}" ; echo ${PWD})`

# (the domain name is the last word in the folder containing the script itself)
TIBCO_DOMAIN_NAME=`basename "$DIRSCRIPT"`

###############################################################################
# Setup temp variables

PRODUCT_NAME="TIBCO EMS Server ($TIBCO_DOMAIN_NAME, $1)"

###############################################################################
###  COMMON FUNCTIONS  ########################################################
###############################################################################

###############################################################################
# This function traces an error and exits.

pError() 
{
	echo "ERROR: $@" 1>&2
	exit 1
}

###############################################################################
# This function search for the PID of a running process.
#
# Takes a single argument : A string to search for in the process table
# 
# WARNING: PS COMMAND IN UNIX TRUNCATES OUTPUT IF IT EXCEEDS
#          80 COLUMNS IN WIDTH, THEREFORE, IF THE PATH POINTING
#          TO THE JRE/JAVA IS TOO LONG THEN THE GREP FOR
#          "tibcoadmin --" BELOW MAY FAIL.

findPid()
{
	case $OS_TYPE in
	'Linux')
		/bin/ps awxf | fgrep "$1" | fgrep -v 'grep' | awk '{print $1}'
	        ;;
	'HP-UX')
		/bin/ps -efx | fgrep "$1" | fgrep -v 'fgrep' | awk '{print $2}'
	        ;;
        *)
	        /usr/bin/ps -ef | fgrep "$1" | fgrep -v "grep" | awk '{print $2}'
	        ;;
        esac
}

###############################################################################
###  START  ###################################################################
###############################################################################

###############################################################################
# All environment variables are set in tibco.sh. Can't proceed further
# if file is missing

if [ -f "$DIRSCRIPT/tibco.sh" ]; then
        . "$DIRSCRIPT/tibco.sh"
else
        pError "File not found $DIRSCRIPT/tibco.sh"
fi

###############################################################################
# Check that the correct number of options have been passed

EMS_PORT=""
if [ $# = 2 ] ; then
	EMS_PORT=$1
	shift
else
	PRODUCT_NAME="TIBCO EMS Server ($TIBCO_DOMAIN_NAME)"
fi

[ $# -ne 1 ] && pError "Usage: $0 [EMS-port] start|stop|check" 

###############################################################################
# Check current user is tibco and not root or somebody else.

if [ "$1" = "start"  -o "$1" = "stop" ] ; then
	if id "$TIBCO_USER" >/dev/null 2>/dev/null ; then
		if [ `id | awk '{print $1}'` != `id "$TIBCO_USER"|awk '{print $1}'` ] ; then
			pError "Only $TIBCO_USER may start or stop $PRODUCT_NAME"
		fi
	else
		pError "User $TIBCO_USER does not exist... You must change the TIBCO_USER variable in the file $DIRSCRIPT/../tibco.sh..."
	fi
fi

###############################################################################
# Find the script that controls the server on the given Port Number
# Secondary servers have '-1', '-2' etc inserted in the script name

EMS_BIN=$TIBCO_HOME/tra/domain/$TIBCO_DOMAIN_NAME/application/TIBCOServers

if [ -z "$EMS_PORT" ] ; then
	SCRIPT_FILE=`/usr/bin/find $EMS_BIN -follow -name TIBCOServers-E*MS*.sh -print`
	FOUND=`/usr/bin/find $EMS_BIN -follow -name TIBCOServers-E*MS*.sh -print | wc -l`
	if [ "$FOUND" -gt "1" ] ; then
		echo ERROR: "Several EMS servers are registered in this domain, you need to call this script with the port number of the server to manage..." 1>&2
		# fixed for Build 1_04 (missing quote)
		pError "Usage: $0 [EMS-port] start|stop|check" 
	fi
else
	SCRIPT_FILE=`/usr/bin/find $EMS_BIN -follow -name TIBCOServers-E*MS*${EMS_PORT}.sh -print`
fi

###############################################################################
# Check that an EMS Server has been installed for this Port Number

[ -z "$SCRIPT_FILE" ] && pError "$PRODUCT_NAME not registered into domain $TIBCO_DOMAIN_NAME"

###############################################################################
# Main code.

NOHUP="nohup"
OS_TYPE=`uname -a | awk '{print $1}'`
case $OS_TYPE in
    'SunOS')	ulimit -n 256	;;
    *)          ;;
esac

# config file of the component
TRAFILE=`dirname $SCRIPT_FILE`/`basename $SCRIPT_FILE .sh`.tra

# search tibemsd process config file from TRAFILE
CONFIG_FILE=`fgrep JMS_CONFIG "$TRAFILE"`
CONFIG_FILE=${CONFIG_FILE##*JMS_CONFIG \"}
CONFIG_FILE=${CONFIG_FILE%%\"*}

# command to start the component
COMMAND="$SCRIPT_FILE --propFile $TRAFILE"

# string to search for finding the component PID
PROCFIND="$EMS_SERVER -config $CONFIG_FILE"

case "$1" in
###############################################################################
# 
# Start the component
#
###############################################################################
'start')
	PID=`findPid "$PROCFIND"`

	if [ "$PID" != "" ]; then
		echo "$PRODUCT_NAME already running"
	else
        	if [ -x $SCRIPT_FILE ]; then
			echo "$PRODUCT_NAME starting..."
			$NOHUP $COMMAND >/dev/null 2>&1 &
			echo "Started $PRODUCT_NAME"
		else
			echo "$PRODUCT_NAME not installed"
		fi

	fi
	;;

###############################################################################
# 
# Stop the component
#
###############################################################################
'stop')
	PID=`findPid "$PROCFIND"`

	if [ "$PID" != "" ]; then
		echo "$PRODUCT_NAME stopping."
		kill $PID
	else
		echo "$PRODUCT_NAME not running"
	fi
	;;

###############################################################################
# 
# Check if the component is running
#
###############################################################################
'check')
	PID=`findPid "$PROCFIND"`

	if [ "$PID" != "" ]; then
		echo "$PRODUCT_NAME running with pid $PID"
	else
		echo "$PRODUCT_NAME not running"
	fi
	;;

###############################################################################
# 
# Unrecognized Option
#
###############################################################################
*)
	echo "usage: $0 [start|stop|check]" 1>&2
	;;
esac

###############################################################################
###  END OF FILE  #############################################################
###############################################################################

