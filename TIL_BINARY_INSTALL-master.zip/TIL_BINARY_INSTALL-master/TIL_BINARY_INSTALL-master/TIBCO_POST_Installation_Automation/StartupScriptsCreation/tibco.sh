#!/usr/bin/ksh
###############################################################################
#
# Build 1_03:
# - Added EMS_SERVER here instead of the startEmsServer.sh script
#
# $Header: /cvs/TIL_SOURCE/scripts/env/tibco.sh,v 1.3 2006/06/28 14:56:42 ayelr Exp $
###############################################################################

###############################################################################
# Set up TIBCO variables

export BW_VERSION=5.13
export ADMIN_VERSION=5.11
export TRA_VERSION=5.11
#export ADAPTER_VERSION=5.6
#export EMS_VERSION=5.1
export TIBCO_HOME=/opt/tibco
export RV_HOME=$TIBCO_HOME/tibrv
export BW_HOME=$TIBCO_HOME/bw/$BW_VERSION
export TRA_HOME=$TIBCO_HOME/tra/$TRA_VERSION
#export EMS_HOME=$TIBCO_HOME/ems/$EMS_VERSION
export TPCL_HOME=$TIBCO_HOME/tpcl/$TRA_VERSION
export HAWK_HOME=$TIBCO_HOME/hawk
export ADMIN_HOME=$TIBCO_HOME/administrator/$ADMIN_VERSION
export DESIGNER_HOME=$TIBCO_HOME/designer/$TRA_VERSION
#export ADAPTER_HOME=$TIBCO_HOME/adapter
#export EJB_HOME=$ADAPTER_HOME/adejb/5.1
#export MQ_HOME=$ADAPTER_HOME/admqs/6.1
export JRE_HOME=$TIBCO_HOME/tibcojre64/1.6.0
#export ORACLE_HOME=/u00/app/oracle/product/9.2.0.6
export AS_HOME=$TIBCO_HOME/as/2.1
# UNIX account allowed to run the scripts
export TIBCO_USER=root

# Libraries
export PATH=$RV_HOME/bin:$JRE_HOME/bin:$TRA_HOME/bin:$DESIGNER_HOME/bin:$ADMIN_HOME/bin:$AS_HOME/bin:$AS_HOME/lib:$PATH
export CLASSPATH=$AS_HOME/lib/as-common.jar:$AS_HOME/lib/as-admin.jar:$AS_HOME/antlr-3.2.jar
export SHLIB_PATH=SHLIB_PATH:$AS_HOME/bin
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$AS_HOME/bin:$AS_HOME/lib:$JRE_HOME/lib
# Name of EMS Server binary (can be tibemsd on other platforms)
#EMS_SERVER=tibemsd64

###############################################################################
###  END OF FILE  #############################################################
###############################################################################


