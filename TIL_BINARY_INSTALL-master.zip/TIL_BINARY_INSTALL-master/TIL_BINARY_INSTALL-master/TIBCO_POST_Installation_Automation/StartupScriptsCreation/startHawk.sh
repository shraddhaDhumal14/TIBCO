#!/bin/sh
###############################################################################
# Copyright 2004 TIBCO Software Inc. All rights reserved.
#
# This script controls one TIBCO Hawk Agent for one TIBCO domain 
# (the folder containing this script must have the same name as the domain).
# If TIBCO Hawk HMA is not running, the Hawk Agent will automatically start it.
#
# This script takes one argument: "start", "stop" or "check"
#
# You must copy this script in each environment/domain.
# Example:
# 	/opt/tibco/env/MyDomain1/startHawk.sh for domain MyDomain1
#
# Build 1_03:
# - Added -follow to find command so symbolic links are resolved.
# - Added space to find exact PID (Text and Text01 were not separated in the 
# past).
# - Fixed findPid function for Linux.
#
# $Header: /cvs/TIL_SOURCE/scripts/env/MyDomain1/startHawk.sh,v 1.5 2006/06/28 14:56:42 ayelr Exp $
###############################################################################

###############################################################################
# CHANGE THE FOLLOWING VARIABLE VALUES IF NECESSARY
###############################################################################

###############################################################################
# DO NOT CHANGE THE REST OF THE SCRIPT
###############################################################################

###############################################################################
# Guess the domain name from the path of the script itself

# folder of this script itself
DIRSCRIPT=`dirname "$0"`
DIRSCRIPT=`(cd "${DIRSCRIPT}" ; echo ${PWD})`

# (the domain name is the last word in the folder containing the script itself)
TIBCO_DOMAIN_NAME=`basename "$DIRSCRIPT"`

###############################################################################
# Setup temp variables

PRODUCT_NAME="TIBCO Hawk Agent ($TIBCO_DOMAIN_NAME)"

###############################################################################
###  COMMON FUNCTIONS  ########################################################
###############################################################################

###############################################################################
# This function traces an error and exits.

pError() 
{
	echo "ERROR: $@" 1>&2
	exit 1
}

###############################################################################
# This function search for the PID of a running process.
#
# Takes a single argument : A string to search for in the process table
# 
# WARNING: PS COMMAND IN UNIX TRUNCATES OUTPUT IF IT EXCEEDS
#          80 COLUMNS IN WIDTH, THEREFORE, IF THE PATH POINTING
#          TO THE JRE/JAVA IS TOO LONG THEN THE GREP FOR
#          "tibcoadmin --" BELOW MAY FAIL.

findPid()
{
	case $OS_TYPE in
	'Linux')
		/bin/ps awxf | fgrep "$1" | fgrep -v 'grep' | awk '{print $1}'
	        ;;
	'HP-UX')
		/bin/ps -efx | fgrep "$1" | fgrep "tra" | fgrep -v '\\_'| awk '{print $2}'
	        ;;
        *)
	        /usr/bin/ps -ef | fgrep "$1" | fgrep -v "fgrep" | awk '{print $2}'
	        ;;
        esac
}

###############################################################################
###  START  ###################################################################
###############################################################################

###############################################################################
# All environment variables are set in tibco.sh. Can't proceed further
# if file is missing

if [ -f "$DIRSCRIPT/tibco.sh" ]; then
        . "$DIRSCRIPT/tibco.sh"
else
        pError "File not found $DIRSCRIPT/tibco.sh"
fi

###############################################################################
# Check that the correct number of options have been passed

[ $# -ne 1 ] && pError "Usage: $0 start|stop|check" 

###############################################################################
# Check current user is tibco and not root or somebody else.

if [ "$1" = "start"  -o "$1" = "stop" ] ; then
	if id "$TIBCO_USER" >/dev/null 2>/dev/null ; then
		if [ `id | awk '{print $1}'` != `id "$TIBCO_USER"|awk '{print $1}'` ] ; then
			pError "Only $TIBCO_USER may start or stop $PRODUCT_NAME"
		fi
	else
		pError "User $TIBCO_USER does not exist... You must change the TIBCO_USER variable in the file $DIRSCRIPT/../tibco.sh..."
	fi
fi

###############################################################################
# Find the script that controls the server on the given Port Number
# Secondary servers have '-1', '-2' etc inserted in the script name

HAWK_BIN=$TIBCO_HOME/tra/domain/$TIBCO_DOMAIN_NAME
SCRIPT_FILE=`/usr/bin/find $HAWK_BIN -follow -name hawkagent_$TIBCO_DOMAIN_NAME -print`

###############################################################################
# Check that script has been installed correctly

[ -z "$SCRIPT_FILE" ] && pError "$PRODUCT_NAME not installed"

###############################################################################
# Main code.

NOHUP="nohup"
OS_TYPE=`uname -a | awk '{print $1}'`
case $OS_TYPE in
    'SunOS')	ulimit -n 256	;;
    *)          ;;
esac

# config file of the component
TRAFILE="$HAWK_BIN/hawkagent_$TIBCO_DOMAIN_NAME.tra"

# command to start the component
COMMAND="$SCRIPT_FILE --propFile $TRAFILE"

# string to search for finding the component PID
PROCFIND="hawkagent_$TIBCO_DOMAIN_NAME "

case "$1" in
###############################################################################
# 
# Start the component
#
###############################################################################
'start')
	PID=`findPid "$PROCFIND"`

	if [ "$PID" != "" ]; then
		echo "$PRODUCT_NAME already running"
	else
        	if [ -x $SCRIPT_FILE ]; then
			echo "$PRODUCT_NAME starting..."
			$NOHUP $COMMAND >/dev/null 2>&1 &
			echo "Started $PRODUCT_NAME"
		else
			echo "$PRODUCT_NAME not installed"
		fi

	fi
	;;

###############################################################################
# 
# Stop the component
#
###############################################################################
'stop')
	PID=`findPid "$PROCFIND"`

	if [ "$PID" != "" ]; then
		echo "$PRODUCT_NAME stopping."
		kill $PID
	else
		echo "$PRODUCT_NAME not running"
	fi
	;;

###############################################################################
# 
# Check if the component is running
#
###############################################################################
'check')
	PID=`findPid "$PROCFIND"`

	if [ "$PID" != "" ]; then
		echo "$PRODUCT_NAME running with pid $PID"
	else
		echo "$PRODUCT_NAME not running"
	fi
	;;

###############################################################################
# 
# Unrecognized Option
#
###############################################################################
*)
	echo "Usage: $0 [start|stop|check]" 1>&2
	;;
esac

###############################################################################
###  END OF FILE  #############################################################
###############################################################################

