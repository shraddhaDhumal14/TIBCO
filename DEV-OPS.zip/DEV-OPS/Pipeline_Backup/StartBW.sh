
[tibco@TIL-BW-SIT1 AutoStart]$ cat StartBW.sh
#!/bin/sh
set -vx
########################################################
# Purpose : To start domain/ admin/hawk on T8
# Author  :
# Verion : 0.1
########################################################
rawFile='/opt/tibco/tools/AutoStart/stat.tmp'
final='/opt/tibco/tools/AutoStart/Final.txt'
log='/opt/tibco/tools/AutoStart/startBW.log'

domainStart()
{
`/opt/tibco/tools/AutoStart/rvd_port_check.sh`
`/opt/tibco/env/TILSIT1/startDomain.sh start >>$log`
sleep 2s
out=2
while [[ `/opt/tibco/env/TILSIT1/startDomain.sh check | grep -v grep | grep "running with pid" | wc -l` -lt $out ]]
do
        sleep 5s
done

echo "checking Domain and Hawk restarted successfully"
ExecutionTime=$(date)
echo "TimeStamp is $ExecutionTime" >>$log
echo "sleeping for 2 min" >>$log
sleep 2m
`/opt/tibco/env/TILSIT1/startDomain.sh check >>$log`
echo "waking up the process to start engines" >>$log
}

newdomainStart()
{
`/opt/tibco/tools/AutoStart/rvd_port_check.sh`
`/opt/tibco/env/TIL15SIT1/startDomain.sh start >>$log`
sleep 2s
out=2
while [[ `/opt/tibco/env/TIL15SIT1/startDomain.sh check | grep -v grep | grep "running with pid" | wc -l` -lt $out ]]
do
        sleep 5s
done


echo "checking Domain and Hawk restarted successfully"
ExecutionTime=$(date)
echo "TimeStamp is $ExecutionTime" >>$log
echo "sleeping for 2 min" >>$log
sleep 2m
`/opt/tibco/env/TIL15SIT1/startDomain.sh check >>$log`
echo "waking up the process to start engines" >>$log
}

startBW()
{
dir='/opt/tibco/tra/5.10/bin'

##T8 un comment##

domain='TILSIT1'
file='/opt/tibco/tools/AutoStart/TILSIT1.txt'

cd /opt/tibco/tra/5.10/bin
count=0

while IFS= read -r line
do
        count=$((count+1))
        if [ $count -lt 45 ]
        then
                app=$(echo $line | cut -d'"' -f 2)
                 printf '%s\n' ..
                 printf '%s\n' ..
                printf '%s\n' "$app" "$count" starting up >>$log
                `/opt/tibco/tra/5.10/bin/AppManage -start -app $app -user admin -pw adminSit -domain $domain >>$log`
                sleep 10s
                ExecutionTime1=$(date)
                echo "deployed at $ExecutionTime1" >>$log
                echo "moving to different app" >>$log

        else
                app=$(echo $line | cut -d'"' -f 2)
                 printf '%s\n' ..
                 printf '%s\n' ..
                printf '%s\n' "$app" "$count" starting up >>$log
                `/opt/tibco/tra/5.10/bin/AppManage -start -app $app -user admin -pw adminSit -domain $domain >>$log`
                count=0
                sleep 10s
                echo "Waiting for the engines to start" >>$log
                ExecutionTime2=$(date)
                echo "Deployed at $ExecutionTime2"
        fi
        # display $line or do somthing with $line
        #printf '%s\n' "$line"
done <$file
}

newstartBW()
{
dir='/opt/tibco/tra/5.12/bin'

##T8 un comment##

domain='TIL15SIT1'
file='/opt/tibco/tools/AutoStart/TIL15SIT1.txt'

cd /opt/tibco/tra/5.12/bin
count=0

while IFS= read -r line
do
        count=$((count+1))
        if [ $count -lt 45 ]
        then
                app=$(echo $line | cut -d'"' -f 2)
                 printf '%s\n' ..
                 printf '%s\n' ..
                printf '%s\n' "$app" "$count" starting up >>$log
                `/opt/tibco/tra/5.12/bin/AppManage -start -app $app -user admin -pw adminSit -domain $domain >>$log`
                sleep 10s
                ExecutionTime1=$(date)
                echo "deployed at $ExecutionTime1" >>$log
                echo "moving to different app" >>$log

        else
                app=$(echo $line | cut -d'"' -f 2)
                 printf '%s\n' ..
                 printf '%s\n' ..
                printf '%s\n' "$app" "$count" starting up >>$log
                `/opt/tibco/tra/5.12/bin/AppManage -start -app $app -user admin -pw adminSit -domain $domain >>$log`
                count=0
                sleep 10s
                echo "Waiting for the engines to start" >>$log
                ExecutionTime2=$(date)
                echo "Deployed at $ExecutionTime2"
        fi
        # display $line or do somthing with $line
        #printf '%s\n' "$line"
done <$file
echo "TimeStamp of script completion is $ExecutionTime" >>$log
}

checkStop()
{
# in here becasue the GW and apache have to be stopped
`kill -9 $(ps -aef | grep TILSIT1 | grep -v grep | awk '{print $2}')`
echo "No admin, domain and hawk rocess should be running" >>$log
gatherStat
}


gatherStat()
{
#To gather all the stats
`/bin/ps -aef | grep TILSIT1 | grep -v grep >$rawFile`

[ -s $rawFile ]
te=$?

if [[ $te = 0 ]]
then
        echo "not all are shutdown, progressing with scripted shutdown" >$log
        checkStop
else
        echo "first start the domain, admin and hawk" >>$log
        domainStart
        startBW
        echo "All should be started now, check process and logs. this feature is coming soon" >>$log

fi

}

gatherStat
newdomainStart
newstartBW

[tibco@TIL-BW-SIT1 AutoStart]$


<app name="ServiceBus1/TIL_SMSAdapter" xml="ServiceBus1/TIL_SMSAdapter.xml"/>
<app name="ServiceBus3/ProvisioningAndFulfilment-Misc" xml="ServiceBus3/ProvisioningAndFulfilment-Misc.xml"/>
<app name="ServiceBus3/PhysicalResourceManagement-Misc" xml="ServiceBus3/PhysicalResourceManagement-Misc.xml"/>
<app name="ServiceBus3/CustomerPersonalInfomationManagement-HLR-GHS" xml="ServiceBus3/CustomerPersonalInfomationManagement-HLR-GHS.xml"/>
<app name="ServiceBus2/CustomerIdentityManagement-IDAM" xml="ServiceBus2/CustomerIdentityManagement-IDAM.xml"/>
<app name="ServiceBus1/TMF669_PartyRoleManagement" xml="ServiceBus1/TMF669_PartyRoleManagement.xml"/>
[tibco@TIL-BW-SIT1 AutoStart]$ cleat
-bash: cleat: command not found
[tibco@TIL-BW-SIT1 AutoStart]$ clear
[tibco@TIL-BW-SIT1 AutoStart]$ cat TILSIT1.txt


[tibco@TIL-BW-SIT1 AutoStart]$ cat rvd_port_check.sh
ps -aef |grep -w $(netstat -nap | grep rvd | grep 7180 | awk '{print $7}' | awk -F "/" '{print $1}' | head -1) >> rvlog.txt
netstat -nap | grep rvd | grep 7180 | awk '{print $7}' | awk -F "/" '{print $1}' | head -1 | xargs kill -9 $1 >> rvlog.txt
[tibco@TIL-BW-SIT1 AutoStart]$
