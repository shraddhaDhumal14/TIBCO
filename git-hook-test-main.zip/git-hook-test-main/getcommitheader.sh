#!/bin/bash

jq .commit.message commitpayload.json|sed -e 's/.*\\n\\n//' -e 's/"$//' > commit_body

jq .commit.message commitpayload.json|sed -e 's/\\n\\n.*$//' -e 's/^"//' > commit_header_tmp

cut -d~ -f1 commit_header_tmp > commit_header
cut -d_ -f1 commit_header > sequence_no
cut -d_ -f2 commit_header > release_approval
approval_status=`grep -i approved release_approval`
[[ ! -z "$approval_status" ]] && echo "true" > release_approval || echo "false" > release_approval 
