import com.cwctravel.hudson.plugins.extended_choice_parameter.ExtendedChoiceParameterDefinition
import java.text.*
import groovy.time.*
import hudson.tasks.Mailer;
import hudson.model.User;
import groovy.json.JsonOutput
import groovy.sql.*
import java.sql.Driver

@NonCPS
def getUserEmail(String id=null) {
    User user = User.getById(id ?: currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId(), false)  
    user?.getProperty(Mailer.UserProperty.class).getAddress()
}

def get_approvers_list(String approver_group){
	approvers_list = sh (script: """cat /opt/tibco/.jenkins/config.xml | sed -n \'/role name=\"${approver_group}\"/,\$p\' | sed \'/role>/q\' | grep "sid" | cut -d \'>\' -f 2 | cut -d \'<\' -f 1 | paste -s -d, -""", returnStdout: true).trim()
    return """${approvers_list}"""           
}

def get_approvers_email_list(String approvers_list){
   approvers_email=""
	approvers_list.split(',').each { user ->
            if(approvers_email.length() != 0)
              {
                    approvers_email += ","
              }			  
              approvers_email += getUserEmail(user)  
        }
    return """${approvers_email}"""   
}

def dbInsertOrUpdate(deployParams) {

    int retryCount = 0;
    def mySQL = myGetDBConnect dbURL: deployParams.dbURL, dbUserName: deployParams.dbUserName, dbPassword: deployParams.dbPassword, dbDriver: deployParams.dbDriver
    while (1) 
    {
       if( retryCount > 0 && retryCount % 3 ==0 )
       {
        input 'Proceed or Abort?'      
       }
       try {
            mySQL.connection.autoCommit = false
            println("Executing Query :" + deployParams.insertQuery)
            int rowAffected = mySQL.executeUpdate(deployParams.insertQuery);
            mySQL.commit()
            mySQL.close()
            mySQL = null
            println("Insert/Update " + rowAffected + " row(s)")
            return true
        }
       catch(Exception ex) {
            println("Error in Executing Query :" + deployParams.insertQuery) 
            mySQL.rollback()
            mySQL.close()
            mySQL = null
            println("Sleeping for 60 seconds .... Will Retry "+ (retryCount+1)) 
            //println "Red Alert!! Inform CICD Team ++ DB Insert Error ++ ${ex}" 			
            sleep 60         
        }
        retryCount++
    }     
    return false       
}

def displayDebug(strModule, strDebugMessage)
{
  def debug=1;
  if(debug == 1)
     {   
         println("***************************************")
         println("Module :" + strModule)
         println("Debug Message :" + strDebugMessage)
     }
}

def myGetDBConnect(deployParams) {     
     def mySQL = groovy.sql.Sql.newInstance(deployParams.dbURL,deployParams.dbUserName,deployParams.dbPassword,deployParams.dbDriver)
     return mySQL
}

def mySingleSelectQuery(selectQuery){
     def mySQL =  myGetDBConnect dbURL: env.dbURL, dbUserName: env.dbUserName, dbPassword: env.dbPassword, dbDriver: env.dbDriver
  	 def rowData = [:]
     displayDebug('mySingleSelectQuery',selectQuery)
     def rowResults = mySQL.rows(selectQuery)
     mySQL.close();
     if(rowResults.size() == 0)
         return rowData;
     def headerList = new ArrayList(rowResults[0].keySet())
     for(def rlcounter=0;rlcounter<rowResults.size();rlcounter++)
     {
         def row = rowResults[rlcounter];
         rowData = [:]
         for(def rwHeaderCnt=0;rwHeaderCnt<headerList.size();rwHeaderCnt++)
         { 
           rowData.put(headerList[rwHeaderCnt], row[rwHeaderCnt]!= null  ? row[rwHeaderCnt].toString() : "")
         }
     }
	rowResults = null;
	mySQL = null;
	headerList = null;
    return rowData;
}

def errorCodeDecide(error_code, error_desc, pipeline_url)
{
    if(error_code == "")
    {
        echo "No Error Code Found "
        send_mail(error_code, error_desc, pipeline_url, devopsmail, "Action Required from ${ERROR_ACTIONEE}")
        return false;
    }

    //cbuser = currentBuild.rawBuild.causes[0].userId
    cbuser = User_ID
    sh(script: "line=`grep '${error_code}' CODE/Error_Codes`; echo \$line | awk -F~ '{print \$2}' > errdes; echo \$line | awk -F~ '{print \$3}' > erract; echo \$line | awk -F~ '{print \$4}' > erractne;");
    ERROR_DESC = sh(script: "cat errdes", returnStdout: true).trim()
    ERROR_ACTION = sh(script: "cat erract", returnStdout: true).trim()
    ERROR_ACTIONEE = sh(script: "cat erractne", returnStdout: true).trim()

    if(ERROR_ACTION == "Proceed") {
        return true;
    } else if(ERROR_ACTION == "Success" && ERROR_ACTIONEE == "Developer"){
		send_success_mail(error_code, error_desc, pipeline_url, cbuser, "TDD started for your commit!!!")
        return true;
	} else if(ERROR_ACTION == "Hold" && ERROR_ACTIONEE == "Developer"){
        send_mail(error_code, error_desc, pipeline_url, cbuser, "Action Required from ${ERROR_ACTIONEE}")
        return false;
    } else if(ERROR_ACTION == "Notify" && ERROR_ACTIONEE == "Developer"){
        send_mail(error_code, error_desc, pipeline_url, cbuser, "Action Required from ${ERROR_ACTIONEE}")
        return true;
    } else if (ERROR_ACTION == "Hold" && ERROR_ACTIONEE == "DevOps"){
        send_mail(error_code, error_desc, pipeline_url, devopsmail, "Action Required from ${ERROR_ACTIONEE}")
        return false;
    } else if(ERROR_ACTION == "Restart from Stage" && ERROR_ACTIONEE == "Developer"){
        send_mail(error_code, error_desc, pipeline_url, cbuser, "Action Required from ${ERROR_ACTIONEE}")
        return false;
    } else if (ERROR_ACTION == "Restart from Stage" && ERROR_ACTIONEE == "DevOps"){
        send_mail(error_code, error_desc, pipeline_url, devopsmail, "Action Required from ${ERROR_ACTIONEE}")
        return false;
    } else if(ERROR_ACTION == "Abort" && ERROR_ACTIONEE == "Developer"){
        send_mail(error_code, error_desc, pipeline_url, cbuser, "Action Required from ${ERROR_ACTIONEE}")
       return false;
    } else if(ERROR_ACTION == "Abort" && ERROR_ACTIONEE == "DevOps"){
        send_mail(error_code, error_desc, pipeline_url, devopsmail, "Action Required from ${ERROR_ACTIONEE}")
        return false;
    } else {
        echo "Error Handling not handled Proper"
        send_mail(error_code, error_desc, pipeline_url, devopsmail, "Action Required from ${ERROR_ACTIONEE}")
        return false;
    } 
}


def send_mail(error_code, error_desc, pipeline_url, emailRecipents, emailSubject)
{
    emailContent="Error Code : ${error_code}<BR> Error Description : ${error_desc}<BR> Error Pipeline : ${pipeline_url} <BR> Current Pipeline : ${BUILD_URL}"

    emailext mimeType: 'text/html', 
    subject: "${emailSubject}",  
    from:"BW_ORCHESTRATOR@vodafone.com", 
    to: "${emailRecipents}", 
    body: "${emailContent}"
}

def send_success_mail(success_code, success_desc, pipeline_url, emailRecipents, emailSubject)
{
    emailContent="Success Code : ${success_code}<BR> Success Description : ${success_desc}<BR> Success Pipeline : ${pipeline_url} <BR> Current Pipeline : ${BUILD_URL}"

    emailext mimeType: 'text/html', 
    subject: "${emailSubject}",  
    from:"BW_ORCHESTRATOR@vodafone.com", 
    to: "${emailRecipents}", 
    body: "${emailContent}"
}

def getcssContent(){
    def css = """
        <style type="text/css">
        .tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
        .tg td{font-family:Times, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;width:150px;word-break:break-all;border-color:#9ABAD9;color:#444;}
        .tg th{font-family:Times, sans-serif;font-size:26px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:break-all;border-color:#9ABAD9;color:#1A0504;background-color:#409cff;}
        .tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
        .tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
        .tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
        .tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
        .tg .tg-0lax{text-align:left;vertical-align:top}
        .tg .tg-pass{background-color:lightgreen;text-align:left;vertical-align:top}
        .tg .tg-fail{background-color:red;text-align:left;vertical-align:top}
        .tg .tg-notstarted{background-color:lightgrey;text-align:left;vertical-align:top}
        .tg .tg-notrequired{background-color:#E1E0A2;text-align:left;vertical-align:top}
        </style>
        """
     return css
}

def get_release_notes_bw_sit(deployParams){
    def date_format_report = new Date().format("dd/MM/yyy HH:mm")
    def backgroundimage = "", subHeading = ""
    println("In the mail fn")
    if(deployParams.isDraft == "true")
    {
           backgroundimage = " background=\"${WORKSPACE}/draft.jpg\""
           subHeading = " - DRAFT"
    }

    BW = "${deployParams.BW_VERSION}"
    /*
    if(params.FILE_DEPLOYMENT)
    {
         BW += " (FILE DEPLOYMENT)"
    }
    if (params.ONLY_GV)
    {
         BW += " (ONLY GV)"
    }
    */
    project = deployParams.PROJECT
    jira = deployParams.JIRA

    if(deployParams.EMS_VERSION == "false")
    {
           deployParams.EMS_VERSION = "NA"
    }
    if(deployParams.SQL_VERSION == "false")
    {
           deployParams.SQL_VERSION = "NA"
    }
    if(deployParams.ONLY_GV == "false")
    {
           deployParams.ONLY_GV = "NA"
    }
    if(!deployParams.FILE_DEPLOYMENT?.trim())
    {
           deployParams.FILE_DEPLOYMENT = "NA"
    }


	def body_build_summary = """
		${getcssContent()}
        <table class="tg" style="table-layout: fixed; width: 100%" ${backgroundimage}>        
		  <tr>
			<th class="tg-amwm" colspan="8">Release for ${deployParams.RELEASE}  ${subHeading}</th>
		  </tr>
          <tr>
			<th class="tg-amwm" colspan="8">${jira} | ${project}</th>
		  </tr>
         <tr>
            <td class="tg-1wig" colspan="1">PBI/ADO/DEFECT</td>
            <td class="tg-0lax" colspan="3">${jira}</td>
			<td class="tg-1wig" colspan="1">PROJECT_NAME</td>
			<td class="tg-0lax" colspan="3">${project}</td>            
		  </tr>
          <tr>
            <td class="tg-1wig" colspan="1">Description of Change</td>
            <td class="tg-0lax" colspan="7">${deployParams.Description}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">Impacted TIL Operation(s)</td>
            <td class="tg-0lax" colspan="7">${deployParams.operationName}</td>
          </tr>
		  <tr>
            <td class="tg-1wig" colspan="1">Impacted Engine</td>
            <td class="tg-0lax" colspan="3">${deployParams.ENGINE_NAME}</td>
           <td class="tg-1wig" colspan="1">Engine Type</td>
            <td class="tg-0lax" colspan="3">${deployParams.engine_type}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">BW Version</td>
            <td class="tg-0lax" colspan="3">${BW}</td>
            <td class="tg-1wig" colspan="1">EMS Deployment</td>
            <td class="tg-0lax" colspan="3">${deployParams.EMS_VERSION}</td>            
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">SQL Deployment</td>
            <td class="tg-0lax" colspan="3">${deployParams.SQL_VERSION}</td>
            <td class="tg-1wig" colspan="1">FILE DEPLOYMENT</td>
            <td class="tg-0lax" colspan="3">${deployParams.FILE_DEPLOYMENT}</td>
          </tr>
           <tr>
            <td class="tg-1wig" colspan="1">ONLY_GV</td>
            <td class="tg-0lax" colspan="3">${deployParams.ONLY_GV}</td>
            <td class="tg-1wig" colspan="1">ENVIRONMENT</td>
            <td class="tg-0lax" colspan="3">${deployParams.ENVIRONMENT}</td>
          </tr>
          <p id="bg-text" style="color:RED;font-size:40px;transform:rotate(300deg);-webkit-transform:rotate(300deg);">DRAFT DRAFT DRAFT</p>
         <tr>
			<th class="tg-amwm" colspan="8">Updates to Master Conf File. Replace with Env specific values where required</th>
		  </tr>       
        <tr>
            <td class="tg-1wig" colspan="1">Env MasterGV </td>
            <td class="tg-0lax" colspan="7">${deployParams.masterGV}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">Process GVs</td>
            <td class="tg-0lax" colspan="7">${deployParams.processGV}</td>
          </tr>        
          <tr>
            <td class="tg-1wig" colspan="1">RESTART_ENGINES</td>
            <td class="tg-0lax" colspan="7">${deployParams.restartEngines}</td>
          </tr>          
          <tr>
			<th class="tg-amwm" colspan="8">File Deployments & Other Configurations</th>
		  </tr>
          <tr>
            <td class="tg-1wig" colspan="1">FILE Deployment Type</td>
            <td class="tg-0lax" colspan="7">${deployParams.fileChanges}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">AppendPrependPath</td>
            <td class="tg-0lax" colspan="7">${deployParams.appendPrepand}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">KnownErrors</td>
            <td class="tg-0lax" colspan="7">${deployParams.knownError}</td>
          </tr>
          <tr> 
            <td class="tg-1wig" colspan="1">Special Instructions</td>
            <td class="tg-0lax" colspan="7">${deployParams.splInstructions}</td>
          </tr>
		  <tr> 
            <td class="tg-1wig" colspan="1">TA DETAIL</td>
            <td class="tg-0lax" colspan="7">${deployParams.taDetail}</td>
          </tr>
          <tr> 
            <td class="tg-1wig" colspan="1">Functional Dependencies</td>
            <td class="tg-0lax" colspan="7">${deployParams.functionalDependencies}</td>
          </tr>
		  <tr> 
            <td class="tg-1wig" colspan="1">Post Manual Changes</td>
            <td class="tg-0lax" colspan="7">${deployParams.postManualChanges}</td>
          </tr>
		  <tr> 
            <td class="tg-1wig" colspan="1">PRConf Changes</td>
            <td class="tg-0lax" colspan="7">${deployParams.prConf}</td>
          </tr>
          <tr>
	    <td class="tg-1wig" colspan="1">Main Pipeline URL</td>
	    <td class="tg-0lax" colspan="7"><div class="multiline">${deployParams.build_url.replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
	  </tr>
	  <tr>
	    <td class="tg-1wig" colspan="1">LOG_URL</td>
	    <td class="tg-0lax" colspan="7"><div class="multiline">${BUILD_URL}console</div></td>
	  </tr>
	</table>		
	"""

    println(body_build_summary);
	return body_build_summary
}	

def get_bw_sit_deploy_verification(){
    def date_format_report = new Date().format("dd/MM/yyy HH:mm")


	def body_build_summary = """
		${getcssContent()}
        <table class="tg" style="table-layout: fixed; width: 100%">        
		  <tr>
			<th class="tg-amwm" colspan="8">SIT Release for ${MAP['DP']['RELEASE']} ${MAP['DP']['CHANGE_REF_ID']}</th>
		  </tr>
          <tr>
			<th class="tg-amwm" colspan="8">${MAP['DP']['CHANGE_REF_ID']} | ${MAP['DP']['PROJECT_NAME']}</th>
		  </tr>
         <tr>
            <td class="tg-1wig" colspan="1">PBI/JIRA/ADO/DEFECT</td>
            <td class="tg-0lax" colspan="3">${MAP['DP']['CHANGE_REF_ID']}</td>
			<td class="tg-1wig" colspan="1">PROJECT_NAME</td>
			<td class="tg-0lax" colspan="3">${MAP['DP']['PROJECT_NAME']}</td>            
		  </tr>
		  <tr>
            <td class="tg-1wig" colspan="1">Engine Name</td>
            <td class="tg-0lax" colspan="7">${MAP['DP']['ENGINE_NAME'] }</td>
          </tr>
		  <tr>
            <td class="tg-1wig" colspan="1">Description of Change</td>
            <td class="tg-0lax" colspan="7">${MAP['DP']['DESCRIPTION'] }</td>
          </tr>          
		  <tr>
		    <td class="tg-1wig" colspan="1">Release</td>
            <td class="tg-0lax" colspan="3">${MAP['DP']['RELEASE']}</td>
            <td class="tg-1wig" colspan="1">Environment</td>
            <td class="tg-0lax" colspan="3">${MAP['SIT']['ENVIRONMENT']}</td>                        
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">BW Version</td>
            <td class="tg-0lax" colspan="3">${MAP['DP']['BW_VERSION']}</td>
            <td class="tg-1wig" colspan="1">EMS Version</td>
            <td class="tg-0lax" colspan="3">${MAP['SIT']['EMS_VERSION']}</td>            
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">SQL VERSION</td>
            <td class="tg-0lax" colspan="3">${MAP['SIT']['SQL_VERSION']}</td>
            <td class="tg-1wig" colspan="1">FILE DEPLOYMENT</td>
            <td class="tg-0lax" colspan="3">${MAP['SIT']['FILE_DEPLOYMENT']}</td>
          </tr>
           <tr>
            <td class="tg-1wig" colspan="1">ONLY_GV</td>
            <td class="tg-0lax" colspan="3">${MAP['DP']['ONLY_GV']}</td>
            <td class="tg-1wig" colspan="1">BUILD_REQUESTER</td>
            <td class="tg-0lax" colspan="3">${MAP['SIT']['BUILD_REQUESTER']}</td>
          </tr>
		   <tr>
            <td class="tg-1wig" colspan="1">ORCHESTRATOR Pipeline Link</td>
            <td class="tg-0lax" colspan="7">${BUILD_URL}</td>
          </tr>
		</table>		
	"""
    
    println(body_build_summary);
	return body_build_summary
}

def send_mail_release(emailRecipents, emailSubject, emailContent)
{

    emailext mimeType: 'text/html', 
    subject: "${emailSubject}",  
    from:"BW_ORCHESTRATOR@vodafone.com", 
    to: "${emailRecipents}", 
    body: "${emailContent}"
}

def GitClone(RepoName, TargetDirectory, BranchName )
{
    int retryCount = 0;
    def error = ""
    while (1) 
    {
       if( retryCount > 0 && retryCount % 3 ==0 )
       {
        input 'Proceed or Abort?'      
       }
       try 
	   {

            checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: "*/${BranchName}"]], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${TargetDirectory}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: "https://github.vodafone.com/VFUK-INTEGRATION/${RepoName}.git"]]]
            env.BP_ERROR_CODE = ""
			env.BP_ERROR_MSG = ""
            return true
       }
       catch(Exception ex) 
	   {
		    env.BP_ERROR_CODE = "203"
			env.BP_ERROR_MSG = "Github connection failed"
			println(env.BP_ERROR_CODE + " : " +  env.BP_ERROR_MSG)
			println("Github connection failed.")
			currentBuild.result = 'ABORTED'

            //println("Exception caught : " + ex + "while downloading Repo " +  RepoName); 
            //error = ex;
            //println("Sleeping for 5 seconds .... Will Retry "+ (retryCount+1))
            //println "Red Alert!! Inform CICD Team ++ Git Error ++ ${error}"
            sleep 5            
        }
        retryCount++
    }     
    return false       
}
def commonEngineFunction()
{
	GitClone("TIL_Automation_Framework", "TIL_AUTOMATION", "master")

	def comEngines = sh(script:"cat ./TIL_AUTOMATION/TIL_Build/Common_Engines_List | grep ${engine_name} || exit 0", returnStdout: true).trim()
	echo "DEBUG: comEngines value is: ${comEngines}"
	if (comEngines != null && !comEngines.isEmpty()) 
	{
		// Get the related engines list if it matches .
		COMMON_ENGINES_LIST = "${comEngines}".split("\n");
	} 
	else 
	{
		COMMON_ENGINES_LIST = "${engine_name}".split(";");
	}

	// exceptions in the common engines list are hard coded as below , since there is no specific format to get.

	if(engine_name == "ServiceExposure-Scheduled" || engine_name == "ServiceExposure-NonScheduled" ) 
	{
		COMMON_ENGINES_LIST = "ServiceExposure-NonScheduled, ServiceExposure-Scheduled".split(", "); 
	}

	if(engine_name == "RiskAndCreditManagement-Gemini" || engine_name == "My191-CheckServiceEligibility" )
	{
		COMMON_ENGINES_LIST = "RiskAndCreditManagement-Gemini, My191-CheckServiceEligibility".split(", "); 
	}

	if(engine_name == "ProvisioningAndFulfilment-MNP-FT-MVNO-TALKMOBILE" || engine_name == "ProvisioningAndFulfilment-MNP-FT-Postpay-VF-CONSUMER-1" || engine_name == "ProvisioningAndFulfilment-MNP-FT-Postpay-VF-Corp" ) 
	{
		COMMON_ENGINES_LIST = "ProvisioningAndFulfilment-MNP-FT-MVNO-TALKMOBILE, ProvisioningAndFulfilment-MNP-FT-Postpay-VF-CONSUMER-1, ProvisioningAndFulfilment-MNP-FT-Postpay-VF-Corp".split(", ");
	}

	echo "common engines list: ${COMMON_ENGINES_LIST}"
	//COMMON_ENGINES_STRING = COMMON_ENGINES_LIST.join(", ")
    COMMON_ENGINES_COUNT = COMMON_ENGINES_LIST.size()
}

def RN_recapture()
{

	//Build code :

	sh "rm -Rf CODE/"
        checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/main']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "CODE"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/git-hook-test.git']]]    

	//sh(script: "line=`tail -1 CODE/BW_BUILD.config`; echo \$line > BW_BUILD.config")
	sh(script: "chmod +x getcommitmsg.sh; ./getcommitmsg.sh")
	//sh(script: "cat BW_BUILD.config")
	sh(script: "cat sequence_no")
	approval_check = sh (script: """cat release_approval""",returnStdout: true).trim()

	//MAP['BW']['RELEASE'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$1}'""",returnStdout: true).trim()
	MAP['BW']['RELEASE'] = sh (script: """cat releaseno""",returnStdout: true).trim()

	if( approval_check == "false" || !MAP['DP']['ENVIRONMENT']?.trim() )
	{  
	       println("Give approved as string in GIT commit. Make sure you are using release branch to build and deploy")
	       currentBuild.result = 'ABORTED'
	       return
	}
	MAP['BW']['HAS_BW_BUILD'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$5}'""",returnStdout: true).trim()
	//MAP['BW']['TIL_MODULENAME'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$3}'""",returnStdout: true).trim()
	//MAP['BW']['TIL_ARCHIVEFILES'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$4}'""",returnStdout: true).trim()
	MAP['BW']['TIL_MODULENAME'] = sh (script: """cat reponame| sed 's/TIL_//g'""",returnStdout: true).trim()
	//MAP['BW']['TIL_ARCHIVEFILES'] = sh (script: """cat reponame| sed 's/TIL_//g'""",returnStdout: true).trim()

	//println("Before clone - ${MAP['BW']['TIL_MODULENAME']} and ${MAP['BW']['RELEASE']}")
	GitClone("TIL_${MAP['BW']['TIL_MODULENAME']}", "ENGINE_archive", "${MAP['BW']['RELEASE']}")
	MAP['BW']['TIL_ARCHIVEFILES'] = sh (script: """basename ENGINE_archive/Build/*.archive|cut -d. -f1""",returnStdout: true).trim()
	//println("TIL_Archivefiles = ${MAP['BW']['TIL_ARCHIVEFILES']}")

	MAP['BW']['PROJECTNAME'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$3}'""",returnStdout: true).trim()
	//MAP['BW']['TIL_TRAVERSION'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$6}'""",returnStdout: true).trim()
	//MAP['BW']['BW_VERSION'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$7}'""",returnStdout: true).trim()
	MAP['BW']['TIL_TRAVERSION'] = sh (script: """grep ${engine_name} CODE/applicationinfo.txt | awk -F~ '{print \$3}'""",returnStdout: true).trim()
	MAP['BW']['BW_VERSION'] = sh (script: """grep ${engine_name} CODE/applicationinfo.txt | awk -F~ '{print \$2}'""",returnStdout: true).trim()
	//println("BW ver = ${MAP['BW']['TIL_TRAVERSION']}")
	// println("Tra ver = ${MAP['BW']['BW_VERSION']}")
	MAP['BW']['JIRA_NUMBER'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$1}'""",returnStdout: true).trim()
	MAP['BW']['JIRA_DESCRIPTION'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$2}'""",returnStdout: true).trim()
	//MAP['BW']['SonarQube_Rules_Excluded'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$10}'""",returnStdout: true).trim()
	//MAP['BW']['SonarQube_Exclude_Directories_or_Files'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$11}'""",returnStdout: true).trim()

	println("Has bw build = ${MAP['BW']['HAS_BW_BUILD']}")
	if(MAP['BW']['HAS_BW_BUILD'] != "false" && MAP['BW']['HAS_BW_BUILD'] != "FALSE")
	{
	 	MAP['BW']['HAS_BW_BUILD'] = "true"
	}



	//Deploy code :

	//Deleting the existing downloaded code. In case of new config updates
	sh "rm -Rf CODE/"
	sh "rm -Rf TestENV/"
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/main']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "CODE"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/git-hook-test.git']]]

	sh(script: "cp BW_BUILD.config DEPLOY_BUILD.config")
	sh(script: "cat DEPLOY_BUILD.config")

	//MAP['DP']['RELEASE'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$1}'""",returnStdout: true).trim()
	MAP['DP']['RELEASE'] = MAP['BW']['RELEASE']

	// MAP['DP']['ENVIRONMENT'] = sh (script: """grep '${MAP['DP']['RELEASE']}' CODE/ENV_RELEASE_MAPPING.txt | awk -F~ '{print \$2}'""",returnStdout: true).trim()
	println("Env = ${MAP['DP']['ENVIRONMENT']}")  

	//MAP['DP']['ENGINE_NAME'] = sh (script: """cat reponame""",returnStdout: true).trim()
	MAP['DP']['ENGINE_NAME'] = MAP['BW']['TIL_MODULENAME']
	//MAP['DP']['ENGINE_NAME'] = COMMON_ENGINES_LIST[i]
	//if(MAP['BW']['HAS_BW_BUILD'] == "false" || MAP['BW']['HAS_BW_BUILD'] == "FALSE")
		//MAP['DP']['BW_VERSION'] = ""
	//else
		//MAP['DP']['BW_VERSION'] = bw_build_pipe.buildVariables.BW_VERSION

	seq_no = sh (script: """cat sequence_no""",returnStdout: true).trim()

	GitClone("TIL_TestEnv_Configurations", "TestENV", "master")			
	sh(script: "cp TestENV/BW_Configuration/${MAP['DP']['ENVIRONMENT']}/MasterConfiguration/*Env_gv_Config.gvconf Env_gv.conf")
	sh(script: "cp TestENV/BW_Configuration/${MAP['DP']['ENVIRONMENT']}/MasterConfiguration/*Process_gv_Config.gvconf Process_gv.conf")  

	sh(script: "chmod +x GV_Changes.sh; dos2unix GV_Changes.sh; ./GV_Changes.sh ${seq_no} BW_Config;")
	sh(script: "chmod +x File_Deployment.sh; dos2unix File_Deployment.sh; ./File_Deployment.sh ${seq_no};")
	sh(script: "./GV_Changes.sh ${seq_no} TestEnv ${MAP['DP']['ENVIRONMENT']};")  

	MAP['DP']['ONLY_GV'] = sh (script: """cat gv_deploy.tmp""",returnStdout: true).trim()
	MAP['DP']['MASTER_GV_UPDATE'] = sh (script: """cat master_gv_update.tmp""",returnStdout: true).trim()
	MAP['DP']['PROCESS_GV_UPDATE'] = sh (script: """cat process_gv_update.tmp""",returnStdout: true).trim()
	MAP['DP']['APPEND_PREPEND_PATHS'] = sh (script: """cat append_prepend_paths.tmp""",returnStdout: true).trim()
	MAP['DP']['PR_CONF_FILE'] = sh (script: """cat pr_conf_file.tmp""",returnStdout: true).trim()
	GitClone("TIL_Manual_Automation", "RN_Artifacts", "main")
	tmp_var= sh (script: """cat special_instructions.tmp""",returnStdout: true).trim()
	MAP['DP']['SPECIAL_INSTRUCTIONS']= sh(script: """grep $seq_no RN_Artifacts/ManualSpecialInstruction.txt | cut -f2 -d~""",returnStdout: true).trim()
	MAP['DP']['SPECIAL_INSTRUCTIONS'] += "\n${tmp_var}"
	MAP['DP']['POST_MANUAL_CHANGES'] = sh(script: """grep $seq_no RN_Artifacts/PostManualChanges.txt | cut -f2 -d~""",returnStdout: true).trim()
	MAP['DP']['TA_DETAIL'] = sh(script: """grep $seq_no RN_Artifacts/TADetail.txt | cut -f2 -d~""",returnStdout: true).trim()
	MAP['DP']['FUNCTIONAL_DEPENDENCIES'] = sh(script: """grep $seq_no RN_Artifacts/FunctionalDependencies.txt | cut -f2 -d~""",returnStdout: true).trim()		

	MAP['DP']['EMS_DEPLOYMENT'] = sh (script: """cat ems_deploy.tmp""",returnStdout: true).trim()

	MAP['DP']['SQL_DEPLOYMENT'] = sh (script: """cat sql_deploy.tmp""",returnStdout: true).trim()

	MAP['DP']['FILE_DEPLOYMENT'] = sh (script: """cat file_deploy.tmp""",returnStdout: true).trim()    

	MAP['DP']['DESCRIPTION'] = MAP['BW']['JIRA_DESCRIPTION']

	MAP['DP']['OPERATION_NAME'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$4}'""",returnStdout: true).trim()
	if(!MAP['DP']['OPERATION_NAME']?.trim())
		MAP['DP']['OPERATION_NAME'] = OP_name

	MAP['DP']['PROJECT_NAME'] = MAP['BW']['PROJECTNAME']

	MAP['DP']['ENGINE_TYPE'] = sh (script: """grep ${MAP['DP']['ENGINE_NAME']} TestENV/BW_Configuration/${MAP['DP']['ENVIRONMENT']}/Applications.txt | wc -l""",returnStdout: true).trim()
	println("Engine count in LT env is = ${MAP['DP']['ENGINE_TYPE']}")
	if(MAP['DP']['ENGINE_TYPE'].equals("0"))
		MAP['DP']['ENGINE_TYPE'] = "NEW"
	else
	MAP['DP']['ENGINE_TYPE'] = "UPDATED"

	println("Engine type = ${MAP['DP']['ENGINE_TYPE']}")

	MAP['DP']['CHANGE_REF_ID'] = MAP['BW']['JIRA_NUMBER']	

	def emailContent1 = ""
	println("Before function call")
	//emailContent = get_release_notes_bw_sit isDraft:"false", isEdit:"false", BW_VERSION: MAP['DP']['BW_VERSION']
	emailContent1= get_release_notes_bw_sit isDraft:"false", isEdit:"false", RELEASE: MAP['DP']['RELEASE'], BW_VERSION: MAP['DP']['BW_VERSION'], EMS_VERSION: MAP['DP']['EMS_DEPLOYMENT'], SQL_VERSION: MAP['DP']['SQL_DEPLOYMENT'], ENGINE_NAME: MAP['DP']['ENGINE_NAME'], JIRA: MAP['DP']['CHANGE_REF_ID'], PROJECT: MAP['DP']['PROJECT_NAME'], operationName: MAP['DP']['OPERATION_NAME'].replaceAll("[\\t\\n\\r]+","<br>") , Description: MAP['DP']['DESCRIPTION'].replaceAll("[\\t\\n\\r]+","<br>"),  fileChanges: MAP['DP']['FILE_DEPLOYMENT'].replaceAll("[\\t\\n\\r]+","<br>"), ONLY_GV: MAP['DP']['ONLY_GV'].replaceAll("[\\t\\n\\r]+","<br>"),ENVIRONMENT: MAP['DP']['ENVIRONMENT'].replaceAll("[\\t\\n\\r]+","<br>"), masterGV: MAP['DP']['MASTER_GV_UPDATE'].replaceAll("[\\t\\n\\r]+","<br>"), processGV: MAP['DP']['PROCESS_GV_UPDATE'].replaceAll("[\\t\\n\\r]+","<br>"), engineTemplate: MAP['DP']['ENGINE_NAME'].replaceAll("[\\t\\n\\r]+","<br>"), appendPrepand: MAP['DP']['APPEND_PREPEND_PATHS'].replaceAll("[\\t\\n\\r]+","<br>"), knownError: "NIL", postManualChanges: MAP['DP']['POST_MANUAL_CHANGES'], splInstructions: MAP['DP']['SPECIAL_INSTRUCTIONS'].replaceAll("[\\t\\n\\r]+","<br>"), restartEngines: MAP['DP']['ENGINE_NAME'], engine_type: MAP['DP']['ENGINE_TYPE'].replaceAll("[\\t\\n\\r]+","<br>"), build_url: BUILD_URL.replaceAll("[\\t\\n\\r]+","<br>"),taDetail: MAP['DP']['TA_DETAIL'].replaceAll("[\\t\\n\\r]+","<br>"),functionalDependencies: MAP['DP']['FUNCTIONAL_DEPENDENCIES'].replaceAll("[\\t\\n\\r]+","<br>"),prConf: MAP['DP']['PR_CONF_FILE'].replaceAll("[\\t\\n\\r]+","<br>")
	//emailContent="Test content"
	send_mail_release(MAP['ORCH']['USER'], "Release Parameters", emailContent1) 
}

def validate_trigger()
{

			sh(script: "chmod +x commitpayload.sh; ./commitpayload.sh ${build_id_var} ${job_name_var} ;")
			hooktrigger = sh (script: """cat iswebhook""",returnStdout: true).trim()

			println("Hook trigger = ${hooktrigger}")           

			if( hooktrigger == "Yes" )
		    	{

			       //checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/main']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "CODE"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/git-hook-test.git']]]    
			sh "rm -Rf CODE/"
			GitClone("git-hook-test", "CODE", "main")	
			//sh(script: "line=`tail -1 CODE/BW_BUILD.config`; echo \$line > BW_BUILD.config")
			/*sh(script: "chmod +x getcommitmsg.sh; ./getcommitmsg.sh")
			sh(script: "cat BW_BUILD.config")
			sh(script: "cat sequence_no")*/


			sh(script: "chmod +x getcommitheader.sh; ./getcommitheader.sh")
			sh(script: "cat commit_body")
			sh(script: "cat commit_header")
			sh(script: "cat sequence_no")

			commitbody = sh (script: """cat commit_body""",returnStdout: true).trim()
			approval_check = sh (script: """cat release_approval""",returnStdout: true).trim()

	 		//MAP['BW']['RELEASE'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$1}'""",returnStdout: true).trim()
	 		MAP['BW']['RELEASE'] = sh (script: """cat releaseno""",returnStdout: true).trim()			
			engine_name = sh (script: """cat reponame| sed 's/TIL_//g'""",returnStdout: true).trim()
			MAP['DP']['ISTIL_TSTIL'] = sh (script: """grep ${engine_name} CODE/applicationinfo.txt | awk -F~ '{print \$5}'""",returnStdout: true).trim()
			println(" Engine type ${MAP['DP']['ISTIL_TSTIL']}")
			//MAP['DP']['ENVIRONMENT'] = sh (script: """grep '${MAP['BW']['RELEASE']}' CODE/ENV_RELEASE_MAPPING.txt | awk -F~ '{print \$2}'""",returnStdout: true)
		    env_for_ccs = sh (script: """dos2unix CODE/ENV_RELEASE_MAPPING.txt; grep '${MAP['BW']['RELEASE']}' CODE/ENV_RELEASE_MAPPING.txt | awk -F~ '{print \$2}'""",returnStdout: true).trim()
			if ( MAP['DP']['ISTIL_TSTIL'] == "ISTIL")
			{	
				println("Inside ISTIL of if condition")
				MAP['DP']['ENVIRONMENT'] = sh (script: """dos2unix CODE/ENV_RELEASE_MAPPING.txt; grep '${MAP['BW']['RELEASE']}' CODE/ENV_RELEASE_MAPPING.txt | awk -F~ '{print \$2}'""",returnStdout: true).trim()
			}
			else
			{
				MAP['DP']['ENVIRONMENT'] = "LNKTest15"
			} 
			println("approval check =  ${approval_check} ,Env =  ${MAP['DP']['ENVIRONMENT']}")
			MAP['ORCH']['SEQ_NO']= sh (script: """cat sequence_no""",returnStdout: true).trim()
			if( approval_check == "true" && env_for_ccs?.trim() && MAP['ORCH']['SEQ_NO'].trim().matches('[0-9]{7}') )
	        	{  	
				release_approved = "true"
				payload = sh (script: """cat commitpayload.json""",returnStdout: true).trim()
				println("${payload}")
				//commitmessage = sh (script: """jq .commit.message commitpayload.json|sed 's/.*\\n\\n//'""",returnStdout: true).trim()
				//commitmessage = sh (script: '''jq .commit.message commitpayload.json|sed "s/\\\/~/g"''',returnStdout: true).trim()
				//println("Commit message = ${commitmessage}")
				User_ID = sh (script: """jq .commit.author.email commitpayload.json""",returnStdout: true).replaceAll("^\"|\"\$", "").trim();
				//println("User ID = ${User_ID}")
				(gl1, gl2, gl3, gl4, OP_name, fl_name) = sh (script: """jq .files[].filename commitpayload.json""",returnStdout: true).replaceAll("^\"|\"\$", "").trim().tokenize('/');
				//println("Operation name = ${OP_name}")
				//MAP['DP']['ENGINE_NAME'] = sh (script: """cat reponame""",returnStdout: true).trim()				
				println("Engine name = ${engine_name}")

                		MAP['ORCH']['ENGINE_NAME'] = sh (script: """cat reponame| sed 's/TIL_//g'""",returnStdout: true).trim()
                		MAP['ORCH']['RELEASE_NO'] = sh (script: """cat releaseno""",returnStdout: true).trim()
                		MAP['ORCH']['USER']=User_ID


                //println("After Insert into DB")
                //println(MAP['ORCH'])

				String[] commit_body_array
				commit_body_array = commitbody.split('~');
				println("Commit body array = ${commit_body_array}")

				String regex_pattern = ".*[\\\\()\\[\\]\\?\\|\\%\\&\\'\\/\\\n]+.*"
				if (commitbody ==~ regex_pattern){
					println('ERROR: Commit body has some special characters "\\,(,),[,],?,|,%,&,\',/," or new line in it. Please re-commit with plain text.')
					release_approved = errorCodeDecide('701', 'Commit body has some special characters "\\,(,),[,],?,|,%,&,\',/," or new line in it. Please re-commit with plain text.', '${BUILD_URL}')
				}
				else if (commit_body_array.size() < 4)
				{
					println('ERROR: Commit body is not proper. Commit body format should be: ADO_No.~Project Description~ProjectName~OpertationName. Please refer user guide and re-commit.')
					release_approved = errorCodeDecide('701', 'Commit body is not proper. Commit body format should be: ADO_No.~Project Description~ProjectName~OpertationName. Please refer user guide and re-commit', '${BUILD_URL}')
				}
				else if (commit_body_array[0].indexOf(' ') != -1)
				{
					println('ERROR: INTTIL NUMBER should not contain spaces in between. Please re-commit with out space.')
					release_approved = errorCodeDecide('701', 'INTTIL NUMBER should not contain spaces in between. Please re-commit without space.', '${BUILD_URL}')
				}
				else
				{
					success_decision = errorCodeDecide('700', 'Valid commit confirmation. Starting Build. No action required.', '${BUILD_URL}')
					if(success_decision)
                	{
                		println("Valid Commit. Proceeding to Build")

						println("Before Insert into DB")
                        println(MAP['ORCH'])

						commonEngineFunction()

						for(def i=0;i<COMMON_ENGINES_COUNT;i++)
						{
							def ins_query = "insert into CICD_RELEASES (SEQ_NO, RELEASE_NO, ENGINE_NAME, ORCH_URL,STATUS,STAGE_COMPLETED,CREATED_BY,CREATED_ON) values ('${MAP['ORCH']['SEQ_NO']}','${MAP['ORCH']['RELEASE_NO']}','${COMMON_ENGINES_LIST[i]}','${BUILD_URL}','Active','PREPARATION','${User_ID}',sysdate)"

							println("DEBUG: Insert query is: " + ins_query)
							dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: ins_query
                        }    
                        select_query = "select TDD_ID from CICD_RELEASES where ORCH_URL = '${BUILD_URL}' and ENGINE_NAME = '${engine_name}'"
                        rowList = mySingleSelectQuery(select_query);
                        MAP['ORCH']['TDD_ID'] = (rowList["TDD_ID"] != null ) ? rowList["TDD_ID"].toString() : ""
						println("Value of TDD_ID : ${MAP['ORCH']['TDD_ID']}")
                	}
                	else
                	{
							//SUBMITTED_USER = User_ID
                      		def devInput = input( id: 'devInput', message: 'Please check mail and approve if OK.')
                	}
				}		
	        }
			else
			{
				println("Error : Sequence No. and/or Approval string is missing in commit comments and/or commit not made in release branch. \n All the next stages will be skippied ")
			}

			}
}

def LT_deployment_prepration()
{
	//Deleting the existing downloaded code. In case of new config updates
	sh "rm -Rf CODE/"
	sh "rm -Rf TestENV/"
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/main']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "CODE"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/git-hook-test.git']]]

	//sh(script: "line=`tail -1 CODE/DEPLOY_BUILD.config`; echo \$line > DEPLOY_BUILD.config")
	sh(script: "cp BW_BUILD.config DEPLOY_BUILD.config")
	sh(script: "cat DEPLOY_BUILD.config")

			//MAP['DP']['RELEASE'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$1}'""",returnStdout: true).trim()
	MAP['DP']['RELEASE'] = MAP['BW']['RELEASE']

		// MAP['DP']['ENVIRONMENT'] = sh (script: """grep '${MAP['DP']['RELEASE']}' CODE/ENV_RELEASE_MAPPING.txt | awk -F~ '{print \$2}'""",returnStdout: true).trim()
	println("Env = ${MAP['DP']['ENVIRONMENT']}")  

	//MAP['DP']['ENGINE_NAME'] = sh (script: """cat reponame""",returnStdout: true).trim()
	//MAP['DP']['ENGINE_NAME'] = MAP['BW']['TIL_MODULENAME']
	
	//if(MAP['BW']['HAS_BW_BUILD'] == "false" || MAP['BW']['HAS_BW_BUILD'] == "FALSE")
		//MAP['DP']['BW_VERSION'] = ""
	//else
		//MAP['DP']['BW_VERSION'] = bw_build_pipe.buildVariables.BW_VERSION

	seq_no = sh (script: """cat sequence_no""",returnStdout: true).trim()
	GitClone("TIL_TestEnv_Configurations", "TestENV", "master")			
	sh(script: "cp TestENV/BW_Configuration/${MAP['DP']['ENVIRONMENT']}/MasterConfiguration/*Env_gv_Config.gvconf Env_gv.conf")
	sh(script: "cp TestENV/BW_Configuration/${MAP['DP']['ENVIRONMENT']}/MasterConfiguration/*Process_gv_Config.gvconf Process_gv.conf")  

	sh(script: "chmod +x GV_Changes.sh; dos2unix GV_Changes.sh; ./GV_Changes.sh ${seq_no} BW_Config;")
	sh(script: "chmod +x File_Deployment.sh; dos2unix File_Deployment.sh; ./File_Deployment.sh ${seq_no};")
	sh(script: "./GV_Changes.sh ${seq_no} TestEnv ${MAP['DP']['ENVIRONMENT']};")  

	MAP['DP']['ONLY_GV'] = sh (script: """cat gv_deploy.tmp""",returnStdout: true).trim()
	MAP['DP']['MASTER_GV_UPDATE'] = sh (script: """cat master_gv_update.tmp""",returnStdout: true).trim()
	MAP['DP']['PROCESS_GV_UPDATE'] = sh (script: """cat process_gv_update.tmp""",returnStdout: true).trim()
	MAP['DP']['APPEND_PREPEND_PATHS'] = sh (script: """cat append_prepend_paths.tmp""",returnStdout: true).trim()
	MAP['DP']['PR_CONF_FILE'] = sh (script: """cat pr_conf_file.tmp""",returnStdout: true).trim()
	GitClone("TIL_Manual_Automation", "RN_Artifacts", "main")
	tmp_var= sh (script: """cat special_instructions.tmp""",returnStdout: true).trim()
	MAP['DP']['SPECIAL_INSTRUCTIONS']= sh(script: """grep $seq_no RN_Artifacts/ManualSpecialInstruction.txt | cut -f2 -d~""",returnStdout: true).trim()
	MAP['DP']['SPECIAL_INSTRUCTIONS'] += "\n${tmp_var}"
	MAP['DP']['POST_MANUAL_CHANGES'] = sh(script: """grep $seq_no RN_Artifacts/PostManualChanges.txt | cut -f2 -d~""",returnStdout: true).trim()
	MAP['DP']['TA_DETAIL'] = sh(script: """grep $seq_no RN_Artifacts/TADetail.txt | cut -f2 -d~""",returnStdout: true).trim()
	MAP['DP']['FUNCTIONAL_DEPENDENCIES'] = sh(script: """grep $seq_no RN_Artifacts/FunctionalDependencies.txt | cut -f2 -d~""",returnStdout: true).trim()		

			//MAP['DP']['ONLY_GV'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$6}'""",returnStdout: true).trim()
	//MAP['DP']['ONLY_GV'] = sh (script: """cat gv_deploy.tmp""",returnStdout: true).trim()
			//MAP['DP']['EMS_DEPLOYMENT'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$7}'""",returnStdout: true).trim()	
	//MAP['DP']['DESCRIPTION'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$10}'""",returnStdout: true).trim()
	MAP['DP']['DESCRIPTION'] = MAP['BW']['JIRA_DESCRIPTION']
			//MAP['DP']['OPERATION_NAME'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$11}'""",returnStdout: true).trim()
	MAP['DP']['OPERATION_NAME'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$4}'""",returnStdout: true).trim()
	if(!MAP['DP']['OPERATION_NAME']?.trim())
		MAP['DP']['OPERATION_NAME'] = OP_name
			//MAP['DP']['PROJECT_NAME'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$12}'""",returnStdout: true).trim()
	MAP['DP']['PROJECT_NAME'] = MAP['BW']['PROJECTNAME']
			//MAP['DP']['ENGINE_TYPE'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$12}'""",returnStdout: true).trim()
	MAP['DP']['ENGINE_TYPE'] = sh (script: """grep ${MAP['DP']['ENGINE_NAME']} TestENV/BW_Configuration/${MAP['DP']['ENVIRONMENT']}/Applications.txt | wc -l""",returnStdout: true).trim()
	println("Engine count in LT env is = ${MAP['DP']['ENGINE_TYPE']}")
	if(MAP['DP']['ENGINE_TYPE'].equals("0"))
		MAP['DP']['ENGINE_TYPE'] = "NEW"
	else
		MAP['DP']['ENGINE_TYPE'] = "UPDATED"

	println("Engine type = ${MAP['DP']['ENGINE_TYPE']}")

			//MAP['DP']['CHANGE_REF_ID'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$13}'""",returnStdout: true).trim()
	MAP['DP']['CHANGE_REF_ID'] = MAP['BW']['JIRA_NUMBER']				

	def emailContent = ""
	println("Before function call")
	//emailContent = get_release_notes_bw_sit isDraft:"false", isEdit:"false", BW_VERSION: MAP['DP']['BW_VERSION']
	emailContent= get_release_notes_bw_sit isDraft:"false", isEdit:"false", RELEASE: MAP['DP']['RELEASE'], BW_VERSION: MAP['DP']['BW_VERSION'], EMS_VERSION: MAP['DP']['EMS_DEPLOYMENT'], SQL_VERSION: MAP['DP']['SQL_DEPLOYMENT'], ENGINE_NAME: MAP['DP']['ENGINE_NAME'], JIRA: MAP['DP']['CHANGE_REF_ID'], PROJECT: MAP['DP']['PROJECT_NAME'], operationName: MAP['DP']['OPERATION_NAME'].replaceAll("[\\t\\n\\r]+","<br>") , Description: MAP['DP']['DESCRIPTION'].replaceAll("[\\t\\n\\r]+","<br>"),  fileChanges: MAP['DP']['FILE_DEPLOYMENT'].replaceAll("[\\t\\n\\r]+","<br>"), ONLY_GV: MAP['DP']['ONLY_GV'].replaceAll("[\\t\\n\\r]+","<br>"),ENVIRONMENT: MAP['DP']['ENVIRONMENT'].replaceAll("[\\t\\n\\r]+","<br>"), masterGV: MAP['DP']['MASTER_GV_UPDATE'].replaceAll("[\\t\\n\\r]+","<br>"), processGV: MAP['DP']['PROCESS_GV_UPDATE'].replaceAll("[\\t\\n\\r]+","<br>"), engineTemplate: MAP['DP']['ENGINE_NAME'].replaceAll("[\\t\\n\\r]+","<br>"), appendPrepand: MAP['DP']['APPEND_PREPEND_PATHS'].replaceAll("[\\t\\n\\r]+","<br>"), knownError: "NIL", postManualChanges: MAP['DP']['POST_MANUAL_CHANGES'], splInstructions: MAP['DP']['SPECIAL_INSTRUCTIONS'].replaceAll("[\\t\\n\\r]+","<br>"), restartEngines: MAP['DP']['ENGINE_NAME'], engine_type: MAP['DP']['ENGINE_TYPE'].replaceAll("[\\t\\n\\r]+","<br>"), build_url: BUILD_URL.replaceAll("[\\t\\n\\r]+","<br>"),taDetail: MAP['DP']['TA_DETAIL'].replaceAll("[\\t\\n\\r]+","<br>"),functionalDependencies: MAP['DP']['FUNCTIONAL_DEPENDENCIES'].replaceAll("[\\t\\n\\r]+","<br>"),prConf: MAP['DP']['PR_CONF_FILE'].replaceAll("[\\t\\n\\r]+","<br>")
	//emailContent="Test content"
	send_mail_release(MAP['ORCH']['USER'], "Release Parameters", emailContent)
}

def sit_deployment_validation(){
	
	// sit_mail_list=get_approvers_email_list(SITBWApprovers)
	sit_mail_list = ""
	sit_mail_list += "parthasarathy.nemana@vodafone.com; anilreddy.kolli@vodafone.com;raghuram.koripalli@vodafone.com; DL-VESTibcoSupport@vodafone.com; Kartik.Namjoshi@Vodafone.com; debasis.panda2@vodafone.com;devops-vfuk-integration@vodafone.com"
	
	select_query = """SELECT * FROM (SELECT \"BwVersion\" , \"DateTime\" ,\"EngineName\" FROM CICD_DEPLOYMENT_HISTORY WHERE \"Environment\" = \'${MAP['SIT']['ENVIRONMENT']}\' AND \"Release\" = \'${MAP['DP']['RELEASE']}\' AND \"BwVersion\" != '1' AND \"BwVersion\" != '0' AND \"BwVersion\" != 'NA' AND \"EngineName\" = \'${MAP['DP']['ENGINE_NAME']}\' AND \"FailureReason\" = 'PASSED' ORDER BY \"DateTime\" DESC) WHERE ROWNUM <= 1"""
	rowList = mySingleSelectQuery(select_query);
	MAP['SIT']['DEP_BW_VERSION'] = (rowList["BwVersion"] != null ) ? rowList["BwVersion"].toString() : "0_0_0"
	println(MAP['SIT']['DEP_BW_VERSION'])
	def (tmp_year, tmp_release, tmp_bw_version) = "${MAP['SIT']['DEP_BW_VERSION']}".tokenize( '_' );
	def (year, release, bw_version) = "${MAP['DP']['BW_VERSION']}".tokenize( '_' );
	int int_tmp_bw_version = tmp_bw_version.toInteger()
	int int_bw_version = bw_version.toInteger()
	println(tmp_bw_version)
	if(int_bw_version < int_tmp_bw_version)
	{
		emailContent= "A higher version of engine is already deployed in SIT enviroment. <p> Engine Name :  ${MAP['DP']['ENGINE_NAME']}</p> <p> SIT Environment : ${MAP['SIT']['ENVIRONMENT']} </p><p> Current deployed version : ${MAP['SIT']['DEP_BW_VERSION']} </p> <p> Requested Version : ${MAP['DP']['BW_VERSION']} </p>"
		println("Higher version is already deployed in the enviroment")
		emailext mimeType: 'text/html',
		subject: "[Jenkins]: SIT Deployment Verification - Draft",
		from:"TIL_SIT_DEPLOYMENT@vodafone.com",
		to: "${sit_mail_list}",
		body: "${emailContent}"
		break;
	}																
	
	emailContent= get_bw_sit_deploy_verification() 

	emailext mimeType: 'text/html',
	subject: "[Jenkins]: SIT Deployment Verification - Draft",
	from:"TIL_SIT_DEPLOYMENT@vodafone.com",
	to: "${sit_mail_list}",
	body: "${emailContent}"
}


approval_check = ""

devopsmail = "devops-vfuk-integration@vodafone.com"
bw_build_pipe = ""
payload = ""
commitmessage = ""
User_ID = ""
OP_name = ""
fl_name = ""
engine_name = ""
MAP = [:]
hooktrigger = ""
release_approved = "false"
seq_no = ""
repofound = ""
rit_ta_pipe =""
rit_ta_pipe_skipped=""
userInput=""
COMMON_ENGINES_LIST=""
COMMON_ENGINES_COUNT=0
SITBWApprovers=""


            //MAP Declaration
            MAP['ORCH'] = ['SEQ_NO':'', 'TDD_ID':'', 'ENGINE_NAME':'', 'RELEASE_NO':'', 'USER':'']

            MAP['BW'] = ['RELEASE':'', 'TIL_MODULENAME':'', 'TIL_ARCHIVEFILES':'', 'PROJECTNAME':'',  'TIL_TRAVERSION':'', 'BW_VERSION':'', 'JIRA_NUMBER':'', 'JIRA_DESCRIPTION':'', 'SonarQube_Rules_Excluded':'', 'SonarQube_Exclude_Directories_or_Files':'']

            MAP['DP'] = ['RELEASE':'', 'ENVIRONMENT':'', 'ENGINE_NAME':'', 'BW_VERSION':'',  'ONLY_GV':'',  'MASTER_GV_UPDATE':'',  'PROCESS_GV_UPDATE':'',  'APPEND_PREPEND_PATHS':'',  'SPECIAL_INSTRUCTIONS':'', 'EMS_DEPLOYMENT':'', 'SQL_DEPLOYMENT':'', 'FILE_DEPLOYMENT':'', 'DESCRIPTION':'', 'OPERATION_NAME':'','PROJECT_NAME':'', 'ENGINE_TYPE':'', 'ISTIL_TSTIL':'','POST_MANUAL_CHANGES':'','TA_DETAIL':'','FUNCTIONAL_DEPENDENCIES':'','PR_CONF_FILE':'']

            MAP['RT'] = ['SEQ_NO':'', 'BRANCH':'', 'ENVIRONMENT':'', 'ENGINE_NAME':'',  'OPERATION_LIST':'', 'ENGINE_TYPE':'', 'EMAIL_ID':'']

            MAP['RN'] = ['SEQ_NO':'']
			
			MAP['SIT']=['ENVIRONMENT':'','BUILD_REQUESTER':'','CRQ':'','DEP_BW_VERSION':'','EMS_VERSION':'','SQL_VERSION':'','SIT_DEPLOY_TYPE':'']

pipeline{
agent any
	options {
        	timeout(time: 8, unit: 'DAYS')
	}
	environment {
		dbURL = 'jdbc:oracle:thin:@195.233.199.13:33000:TIBTST1'
		dbUserName = 'CICD_OWN_DB01'
		dbPassword = 'TIL_CICD_DB'
		dbDriver = 'oracle.jdbc.driver.OracleDriver'
    }

    stages {

        stage ('Preparation') {
			steps {
			script {			

					validate_trigger();	
                }
            }
        }

        stage ('BW_BUILD') {
		   when {
		    expression { hooktrigger == "Yes" && release_approved == "true" }
		   }
			steps {
				script {
                   println("BW Build")
                   while(1)
                   {
			RN_recapture();

			if(MAP['DP']['PR_CONF_FILE'].length() > 11500)
			{

				error_decision = errorCodeDecide('702', 'PR Conf File string is too long. Please reduce length and resume pipeline.', '${BUILD_URL}')
				if(error_decision)
				{
					break;
				}
				else
				{
					println("PR Conf File string is too long. Please reduce length and resume pipeline.")
					def devInput = input( id: 'devInput', message: 'Please check mail and approve if OK.')
					//RN_recapture();
				}
			}
			else
			{

		            if(MAP['BW']['HAS_BW_BUILD'] == "true" || MAP['BW']['HAS_BW_BUILD'] == "TRUE")
			    {
				bw_build_pipe = build job: '/TestDrivenDeployment/MEND_GIT_BUILD', 
                        	parameters: [
                        	            string(name: 'RELEASE', value: "${MAP['BW']['RELEASE']}"),
                                	    string(name: 'TIL_MODULENAME', value: "${MAP['BW']['TIL_MODULENAME']}"),
	                                    string(name: 'TIL_ARCHIVEFILES', value: "${MAP['BW']['TIL_ARCHIVEFILES']}"),
        	                            string(name: 'PROJECTNAME', value: "${MAP['BW']['PROJECTNAME']}"),
                	                    string(name: 'TIL_TRAVERSION', value: "${MAP['BW']['TIL_TRAVERSION']}"),
                        	            string(name: 'BW_VERSION', value: "${MAP['BW']['BW_VERSION']}"),
                                	    string(name: 'BUILD_REQUESTER', value: "${MAP['ORCH']['USER']}"),
    		                            string(name: 'JIRA_NUMBER', value: "${MAP['BW']['JIRA_NUMBER']}"),
     		                            string(name: 'TDD_ID', value: "${MAP['ORCH']['TDD_ID']}"),
             	        	            string(name: 'JIRA_DESCRIPTION', value: "${MAP['BW']['JIRA_DESCRIPTION']}") //,
                	                    //string(name: 'SonarQube_Rules_Excluded', value: "${MAP['BW']['SonarQube_Rules_Excluded']}"),
                                	    //string(name: 'SonarQube_Exclude_Directories_or_Files', value: "${MAP['BW']['SonarQube_Exclude_Directories_or_Files']}")
                        	], propagate:false

                        	println(bw_build_pipe.result + " : ${bw_build_pipe.buildVariables.BP_ERROR_CODE}")
                        	}
				else
				{
					println("Skipping BWBuild")
					break;
				}

                	        if( bw_build_pipe.buildVariables.BP_ERROR_CODE.equals("200") )
                       		{
                              		println("BW Build Success")
				  	def tmp_tdd_id = MAP['ORCH']['TDD_ID'].toInteger()+1;
					MAP['DP']['BW_VERSION'] = bw_build_pipe.buildVariables.BW_VERSION
					for(def i=1;i<COMMON_ENGINES_COUNT;i++)
					{
						def updateQuery = "UPDATE CICD_RELEASES SET BW_VERSION= '${MAP['DP']['BW_VERSION']}', BW_BUILD_URL='${bw_build_pipe.buildVariables.PIPELINE_URL}', STAGE_COMPLETED='BUILD', PROJECT_NAME='${MAP['BW']['PROJECTNAME']}', CHANGE_REF_ID='${MAP['BW']['JIRA_NUMBER']}', CHANGE_REF_DESCRIPTION='${MAP['BW']['JIRA_DESCRIPTION']}', ERROR_CODE='200', ERROR_DESCRIPTION='BW BUILD SUCCESS', STATUS='ACTIVE' WHERE TDD_ID=${tmp_tdd_id} and ENGINE_NAME= '${COMMON_ENGINES_LIST[i]}'" 
					    	println("DEBUG: Insert query is: " + updateQuery)
						dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: updateQuery

						tmp_tdd_id++;
				 	}
                              		break;
                        	}
                        	else
                        	{
                              		println("BW Build Failure Detected")
                              		println("${bw_build_pipe.buildVariables.BP_ERROR_CODE}")
                              		println("${bw_build_pipe.buildVariables.BP_ERROR_MSG}")
                              		error_decision = errorCodeDecide(bw_build_pipe.buildVariables.BP_ERROR_CODE, bw_build_pipe.buildVariables.BP_ERROR_MSG, bw_build_pipe.buildVariables.PIPELINE_URL)
                              		if(error_decision)
                              		{
                              		    break;
                              		}
                              		else
                              		{
                              		        //SUBMITTED_USER=currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId()    
                              		        def devInput = input( id: 'devInput', message: 'Please check mail and approve if OK.')
                              		}
                        	}
			}
                   }//while

                }
			}
		}

		stage ('BW_EMS_SQL') {
            when {
			     expression { ((MAP['BW']['HAS_BW_BUILD'] == "true" || MAP['BW']['HAS_BW_BUILD'] == "TRUE") && bw_build_pipe.result == "SUCCESS" && bw_build_pipe.buildVariables.BP_ERROR_CODE.equals("200")) && hooktrigger == "Yes" && release_approved == "true" || 
			     			(MAP['BW']['HAS_BW_BUILD'] == "false" || MAP['BW']['HAS_BW_BUILD'] == "FALSE") && hooktrigger == "Yes" && release_approved == "true" }
			    }
			steps {
				script {

                   println("Deployment Pipeline")
				   def tmp_tdd_id = MAP['ORCH']['TDD_ID'].toInteger();
                   for(def i=0;i<COMMON_ENGINES_COUNT;i++)
				   {
						while(1)
						{
							
							if(i == 0)
							{
								MAP['DP']['EMS_DEPLOYMENT'] = sh (script: """cat ems_deploy.tmp""",returnStdout: true).trim()
								MAP['DP']['SQL_DEPLOYMENT'] = sh (script: """cat sql_deploy.tmp""",returnStdout: true).trim()
								MAP['DP']['FILE_DEPLOYMENT'] = sh (script: """cat file_deploy.tmp""",returnStdout: true).trim()
							
							}
							else
							{	
								MAP['DP']['EMS_DEPLOYMENT'] = false
								MAP['DP']['SQL_DEPLOYMENT'] = false
								MAP['DP']['FILE_DEPLOYMENT'] = ""
							}
							MAP['DP']['ENGINE_NAME'] = COMMON_ENGINES_LIST[i]
							LT_deployment_prepration();

							userInput = input(id: 'userInput', message: 'Please check mail to validate the params and proeed by selecting the ENV. Select Re-capture for issues.',
							parameters: [[$class: 'ChoiceParameterDefinition', description:'describing choices', name:'nameChoice', choices: "${MAP['DP']['ENVIRONMENT']}\nRe-capture params\nLNKTest14\nLNKTest15\nLinkTest\nLNKTst17\nTILLT1\nTILLT2\nTILLT3\nTILLT4"]
							])

							println("Current Env = ${MAP['DP']['ENVIRONMENT']}")
							println("User input = ${userInput}")

							if( userInput != "Re-capture params" )
								{

								if( userInput == "${MAP['DP']['ENVIRONMENT']}" )	
								{
									//deploy_pipe = build job: '/TestDrivenDeployment/TDD_BW_DEPLOYMENT',
									deploy_pipe = build job: '/TestDrivenDeployment/TDD_BW_DEP_TEST',
									parameters: [
									string(name: 'SEQ_NO', value: "${seq_no}"),			
									string(name: 'RELEASE', value: "${MAP['DP']['RELEASE']}"),
									string(name: 'ENVIRONMENT', value: "${MAP['DP']['ENVIRONMENT']}"),
									string(name: 'ENGINE_NAME', value: "${MAP['DP']['ENGINE_NAME']}"),
									string(name: 'BW_VERSION', value: "${MAP['DP']['BW_VERSION']}"),
									booleanParam(name: 'ONLY_GV', value: "${MAP['DP']['ONLY_GV']}"),
									booleanParam(name: 'EMS_DEPLOYMENT', value: "${MAP['DP']['EMS_DEPLOYMENT']}"),
									booleanParam(name: 'SQL_DEPLOYMENT', value: "${MAP['DP']['SQL_DEPLOYMENT']}"),
									string(name: 'FILE_DEPLOYMENT', value: "${MAP['DP']['FILE_DEPLOYMENT']}"),
									string(name: 'DESCRIPTION', value: "${MAP['DP']['DESCRIPTION']}"),
									string(name: 'OPERATION_NAME', value: "${MAP['DP']['OPERATION_NAME']}"),
									string(name: 'PROJECT_NAME', value: "${MAP['DP']['PROJECT_NAME']}"),
									string(name: 'ENGINE_TYPE', value: "${MAP['DP']['ENGINE_TYPE']}"),
									string(name: 'TDD_ID', value: "${tmp_tdd_id}"),
									string(name: 'EMAIL_REQUESTER', value: "${MAP['ORCH']['USER']}"),
									string(name: 'CHANGE_REF_ID', value: "${MAP['DP']['CHANGE_REF_ID']}"),
									string(name: 'SPECIAL_INSTRUCTIONS', value: "${MAP['DP']['SPECIAL_INSTRUCTIONS']}"),
									string(name: 'APPEND_PREPEND_PATHS', value: "${MAP['DP']['APPEND_PREPEND_PATHS']}"),
									string(name: 'MASTER_GV_UPDATE', value: "${MAP['DP']['MASTER_GV_UPDATE']}"),
									string(name: 'PROCESS_GV_UPDATE', value: "${MAP['DP']['PROCESS_GV_UPDATE']}"),
									string(name: 'DEPLOYMENT_FILES', value: "Dummy")				    
									], propagate:false 

									println(deploy_pipe.result + " : ${deploy_pipe.buildVariables.DP_ERROR_CODE}")

									if( deploy_pipe.buildVariables.DP_ERROR_CODE.equals("200") )
									{
										println("Deployment Pipeline Success")
										break;
									}
									else
									{
										println("Deployment Pipeline Failure  Detected")
										println("${deploy_pipe.buildVariables.DP_ERROR_CODE}")
										println("${deploy_pipe.buildVariables.DP_ERROR_MSG}")
										error_decision = errorCodeDecide(deploy_pipe.buildVariables.DP_ERROR_CODE, deploy_pipe.buildVariables.DP_ERROR_MSG, deploy_pipe.buildVariables.PIPELINE_URL)
										if(error_decision)
										{
										break;
										}
										else
										{
														//SUBMITTED_USER = currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId()
										def devInput = input( id: 'devInput', message: 'Please check mail and approve if OK.')
										}
									}
									// break;
									}
									else
									{
										println("Changing environment to ${MAP['DP']['ENVIRONMENT']}")
										MAP['DP']['ENVIRONMENT'] = userInput
									}
								} // if( userInput == "Deploy" )
								else
								{
									println("Recapturing artifacts")
								} // else of if( userInput == "Deploy" )

                      }//while
					  tmp_tdd_id++
				   }//for loop
                }
			}
		}

		stage ('RIT TA') {
            		when {
			     expression { hooktrigger == "Yes" && release_approved == "true" && bw_build_pipe.result == "SUCCESS" && bw_build_pipe.buildVariables.BP_ERROR_CODE.equals("200") && deploy_pipe.result == "SUCCESS" && deploy_pipe.buildVariables.DP_ERROR_CODE.equals("200") }
			    }
			steps {
				script {

                   println("RIT TA")
				   MAP['DP']['ENGINE_NAME'] = MAP['BW']['TIL_MODULENAME']
				 while(1)
                   {

		    //Deleting the existing downloaded code. In case of new config updates   
		    sh "rm -Rf CODE/"
		    checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/main']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "CODE"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/git-hook-test.git']]]

			sh(script: "chmod +x validate_release.sh; dos2unix validate_release.sh; ./validate_release.sh ${MAP['DP']['RELEASE']} ${MAP['DP']['ENGINE_NAME']};")
			MAP['RT']['BRANCH'] = sh (script: """cat RIT_release.tmp""",returnStdout: true).trim()
			repofound = sh (script: """cat RIT_repofound.tmp""",returnStdout: true).trim()

			println("RIT repe name = RIT_${MAP['DP']['ENGINE_NAME']} , Branch name =  ${MAP['RT']['BRANCH']}")
			//checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '${MAP['RT']['BRANCH']}']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "RITREPO"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/RIT_${MAP['DP']['ENGINE_NAME']}.git']]]


		    if( repofound == "false" )
		    {
                              error_decision = errorCodeDecide("516", "RIT Engine Not Available", BUILD_URL.replaceAll("[\\t\\n\\r]+","<br>"))
                              if(error_decision)
                              {
                                  break;
                              }
                              else
                              {
                                      //SUBMITTED_USER = currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId()
									  userInput = input(id: 'userInput', message: 'Please select yes if you want to perform RIT TA',
             parameters: [
			 [$class: 'ChoiceParameterDefinition', defaultValue: 'YES',description:'describing choices', name:'nameChoice', choices: "YES\nNO"],
			 [$class: 'TextParameterDefinition', defaultValue: '',description:'comments', name:'RIT_comment']
             ])

			 if("${userInput['nameChoice']}" == "NO")
			 {
					 rit_ta_pipe_skipped = "200";
					 println("${userInput['RIT_comment']}")				 
				     break;
			 }            
		    }
			}
		    else
		    { //else for repo found = true

				GitClone("RIT_${MAP['DP']['ENGINE_NAME']}", "RITREPO", "${MAP['RT']['BRANCH']}")

			   sh(script: "chmod +x GetOperationsList.sh; dos2unix GetOperationsList.sh; ./GetOperationsList.sh ${MAP['DP']['ENGINE_NAME']};")
			   MAP['RT']['OPERATION_LIST'] = sh (script: """cat operation_list""",returnStdout: true).trim()
			   String[] operation_array;
			   operation_array = MAP['DP']['OPERATION_NAME'].split(';');
			   def flag_opr="false"
				for( String values : operation_array )
				{
					println(values);
					//MAP['RT']['OPERATION_NAME'] = MAP['DP']['OPERATION_NAME']
					if(!MAP['RT']['OPERATION_LIST'].contains(values.trim()))
					{
						//MAP['RT']['OPERATION_NAME'] = MAP['RT']['OPERATION_LIST']
						userInput = input(id: 'userInput', message: 'AntScript does not contains operation name ${values}. Please correct the RIT repo and select yes if you want to perform RIT TA',
						parameters: [[$class: 'ChoiceParameterDefinition', defaultValue: 'YES',description:'describing choices', name:'nameChoice', choices: "YES\nNO"],[$class: 'TextParameterDefinition', defaultValue: '',description:'comments', name:'RIT_comment']])

						if("${userInput['nameChoice']}" == "NO")
						{
							rit_ta_pipe_skipped = "200";
							println("${userInput['RIT_comment']}")
							flag_opr="true"
							break;
						}
						flag_opr="true"
					}
			  }
			  if( rit_ta_pipe_skipped == "200")
			  {
			  	break;
			  }
			  if( flag_opr.equals("false"))
			  { // else operationName fount in the operation_list = true			
				
				if(MAP['DP']['ENVIRONMENT'] == "LNKTest14")
				{
					MAP['RT']['ENVIRONMENT']="LNKTEST14"
				}
				else if(MAP['DP']['ENVIRONMENT'] == "LNKTest15")
				{
					MAP['RT']['ENVIRONMENT']="LNKTEST15"
				}
				else if(MAP['DP']['ENVIRONMENT'] == "LinkTest")
				{
					MAP['RT']['ENVIRONMENT']="LNKTEST16"
				}
				else if(MAP['DP']['ENVIRONMENT'] == "LNKTst17")
				{
					MAP['RT']['ENVIRONMENT']="LNKTEST17"
				}
				else
				{
					MAP['RT']['ENVIRONMENT']=MAP['DP']['ENVIRONMENT']
				}
				
			     println("Operation list from GetOperList = START ${MAP['RT']['OPERATION_LIST']} END")

				rit_ta_pipe = build job: '/TestDrivenDeployment/TDD_Test_Automation', 
                    		parameters: [
	                                    string(name: 'RELEASE_NO', value: "${MAP['DP']['RELEASE']}"),
	                                    string(name: 'ENVIRONMENT', value: "${MAP['RT']['ENVIRONMENT']}"),
	                                    string(name: 'ENGINE_NAME', value: "${MAP['DP']['ENGINE_NAME']}"),
	                                    string(name: 'SEQ_NO', value: "${seq_no}"),
	                                    string(name: 'OPERATION_NAME', value: "${MAP['DP']['OPERATION_NAME']}"),
	                                    string(name: 'ENGINE_TYPE', value: "${MAP['DP']['ENGINE_TYPE']}"),
                                        string(name: 'TDD_ID', value: "${MAP['ORCH']['TDD_ID']}"),
	                                    string(name: 'BUILD_REQUESTOR', value: "${MAP['ORCH']['USER']}"),
                                        string(name: 'GIT_BRANCH', value: "${MAP['RT']['BRANCH']}")
	                                ], propagate:false 

	                        println(rit_ta_pipe.result + " : ${rit_ta_pipe.buildVariables.TA_ERROR_CODE}")

	                        if( rit_ta_pipe.buildVariables.TA_ERROR_CODE.equals("200") )
	                        {	
	                              println("RIT TA Pipeline Success")
								  rit_ta_pipe_skipped == "201"
	                              break;
	                        }
	                        else
	                        {
	                              println("RIT TA Pipeline Failure Detected")
	                              println("${rit_ta_pipe.buildVariables.TA_ERROR_CODE}")
	                              println("${rit_ta_pipe.buildVariables.TA_ERROR_MSG}")
	                              error_decision = errorCodeDecide(rit_ta_pipe.buildVariables.TA_ERROR_CODE, rit_ta_pipe.buildVariables.TA_ERROR_MSG, rit_ta_pipe.buildVariables.PIPELINE_URL)
	                              if(error_decision)
	                              {	  
									  rit_ta_pipe_skipped == "201"
	                                  break;
	                              }
	                              else
	                              {
	                                      //SUBMITTED_USER=currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId()
	                                      def devInput = input( id: 'devInput', message: 'Please check mail and approve if OK.')
	                              }
	                        }
			} //if repofound
			}
                   } 
			 }    //while               
                }
		}
	   stage ('SIT RN') {
            when {
			     expression { hooktrigger == "Yes" && release_approved == "true" && bw_build_pipe.result == "SUCCESS" && bw_build_pipe.buildVariables.BP_ERROR_CODE.equals("200") && deploy_pipe.result == "SUCCESS" && deploy_pipe.buildVariables.DP_ERROR_CODE.equals("200") && ( rit_ta_pipe_skipped == "200" || ( rit_ta_pipe.result == "SUCCESS" && rit_ta_pipe.buildVariables.TA_ERROR_CODE.equals("200") ) ) }
			    }
			steps {
				script {

                   println("SIT RN")
				   def tmp_tdd_id = MAP['ORCH']['TDD_ID'].toInteger();
				   for(def i=0;i<COMMON_ENGINES_COUNT;i++)
				   {
						while(1)
						{

							if( rit_ta_pipe_skipped.equals("200"))
							{	
								if(i == 0)
								{
									updateQuery = "INSERT INTO TDD_TA_SUMMARY ( SEQ_NO,  RELEASE_NO,  ENGINE_NAME, OPERATION, RIT_BRANCH, ENVIRONMENT, PROG_PASS, PROG_FAIL, REG_PASS, REG_FAIL, TOTAL_TC, TEST_STATUS, STATUS, CREATED_ON, CREATED_BY, APPROVED_BY, TESTCASE_REPORT_URL, BUILD_URL) VALUES ( '${MAP['ORCH']['SEQ_NO']}', '${MAP['DP']['RELEASE']}', '${COMMON_ENGINES_LIST[i]}','${MAP['RT']['OPERATION_NAME']}', 'NA', 'NA', 0, 0, 0, 0, 0, 'Not executed via RIT TA', 'Active', sysdate, '${MAP['ORCH']['USER']}', '', 'NA', 'NA')"
									tmp_skip_var = "Skipping RIT because of following comments ${userInput['RIT_comment']}"							  
									dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: updateQuery
								}
								println("Skipped RIT TA updating in DB")                              
								updateQuery = "UPDATE CICD_RELEASES SET TEST_AUTOMATION_URL='${tmp_skip_var}' WHERE TDD_ID=${tmp_tdd_id}"
								dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: updateQuery
							}

							if(MAP['DP']['PR_CONF_FILE'].length() > 11500)
							{

								error_decision = errorCodeDecide('702', 'PR Conf File string is too long. Please reduce length and resume pipeline.', '${BUILD_URL}')
								if(error_decision)
								{
									break;
								}
								else
								{
									println("PR Conf File string is too long. Please reduce length and resume pipeline.")
									def devInput = input( id: 'devInput', message: 'Please check mail and approve if OK.')
									RN_recapture();
								}
							}
							else
							{
								int fieldsize = 3900;
								println("Replacing new line")
								MAP['DP']['PR_CONF_FILE']=MAP['DP']['PR_CONF_FILE'].replace("\n",",")
								println("${MAP['DP']['PR_CONF_FILE']}")
								String[] arr_prconffile = MAP['DP']['PR_CONF_FILE'].split("(?<=\\G.{" + fieldsize + "})");
								arr_prconffile += ["","","",""]
								println("prconf array = ${arr_prconffile}");

								//GitClone("TIL_DevOps_Framework", "JENKINS_FILE", "master")						
								//DB_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/dbFunctions.groovy"
								updateQuery = "UPDATE CICD_RELEASES SET POST_MANUAL_CHANGES= '${MAP['DP']['POST_MANUAL_CHANGES']}', SPECIAL_INSTRUCTIONS= '${MAP['DP']['SPECIAL_INSTRUCTIONS']}', TA_DETAIL= '${MAP['DP']['TA_DETAIL']}',FUNCTIONAL_DEPENDENCIES= '${MAP['DP']['FUNCTIONAL_DEPENDENCIES']}',PR_CONF_FILE= '${arr_prconffile[0]}',PR_CONF_FILE_2= '${arr_prconffile[1]}',PR_CONF_FILE_3= '${arr_prconffile[2]}' WHERE TDD_ID=${tmp_tdd_id}"
								//DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: updateQuery
								dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: updateQuery

								sit_rn_pipe = build job: '/TestDrivenDeployment/TDD_SIT_RELEASE_NOTES', 
								parameters: [
										string(name: 'TDD_ID', value: "${tmp_tdd_id}"),
										string(name: 'SEQ_NO', value: "${MAP['ORCH']['SEQ_NO']}"),
										string(name: 'BUILD_REQUESTOR', value: "${MAP['ORCH']['USER']}")
									], propagate:false 

								println(sit_rn_pipe.result + " : ${sit_rn_pipe.buildVariables.RN_ERROR_CODE}")

								if( sit_rn_pipe.buildVariables.RN_ERROR_CODE.equals("200"))
								{
									println("SIT RN Pipeline Success")
									break;
								}
								else
								{
									println("SIT RN Pipeline Failure Detected")
									println("${sit_rn_pipe.buildVariables.RN_ERROR_CODE}")
									println("${sit_rn_pipe.buildVariables.RN_ERROR_MSG}")
									error_decision = errorCodeDecide(sit_rn_pipe.buildVariables.RN_ERROR_CODE, sit_rn_pipe.buildVariables.RN_ERROR_MSG, sit_rn_pipe.buildVariables.PIPELINE_URL)
									if(error_decision)
									{
										break;
									}
									else
									{
										userInputRN = input(id: 'userInputRN', message: 'Please check mail to validate the RN. For changes, update the required repositories and proceed with Re-capture. Otherwise select Proceed without changes.',
										parameters: [[$class: 'ChoiceParameterDefinition', description:'describing choices', name:'nameChoice', choices: "Re-capture\nProceed without changes"]
										])

										println("Current Env = ${MAP['DP']['ENVIRONMENT']}")
										println("User input = ${userInputRN}")

										if( userInputRN == "Re-capture" )
										{
											RN_recapture();			
										}
									}
								}
							}
						}//while
						tmp_tdd_id++;
				   }//For loop
                }
			}
		}
		
		stage ('SIT_Deployment') {
            when {
			   expression { hooktrigger == "Yes" && release_approved == "true" && bw_build_pipe.result == "SUCCESS" && bw_build_pipe.buildVariables.BP_ERROR_CODE.equals("200") && deploy_pipe.result == "SUCCESS" && deploy_pipe.buildVariables.DP_ERROR_CODE.equals("200") && ( rit_ta_pipe_skipped == "200" || ( rit_ta_pipe.result == "SUCCESS" && rit_ta_pipe.buildVariables.TA_ERROR_CODE.equals("200") ) ) && sit_rn_pipe.result == "SUCCESS" && sit_rn_pipe.buildVariables.RN_ERROR_CODE.equals("200") }
			   }
			    
			steps {
				script {					
                    
                   println("SIT Deployment Pipeline")
				   
				   SITBWApprovers = get_approvers_list('promoteSITApprovers')
				   
				   def tmp_tdd_id = MAP['ORCH']['TDD_ID'].toInteger();
				   MAP['SIT']['EMS_VERSION'] =	deploy_pipe.buildVariables.EMS_VERSION
				   MAP['SIT']['SQL_VERSION'] = deploy_pipe.buildVariables.SQL_VERSION
				   for(def i=0;i<COMMON_ENGINES_COUNT;i++)
				   {
						while(1)
						{
														            
							MAP['DP']['ENGINE_NAME'] = COMMON_ENGINES_LIST[i]						
							
							MAP['SIT']['ENVIRONMENT'] = sh (script: """grep '${MAP['DP']['RELEASE']}' CODE/SIT_ENV_RELEASE_MAPPING.txt | awk -F~ '{print \$2}'""",returnStdout: true).trim()
							println("${MAP['SIT']['EMS_VERSION']}")
							println("${MAP['SIT']['SQL_VERSION']}")
							
							if(i == 0)
							{
								MAP['DP']['EMS_DEPLOYMENT'] = sh (script: """cat ems_deploy.tmp""",returnStdout: true).trim()
								if ( MAP['SIT']['EMS_VERSION'] == "NA" || MAP['SIT']['EMS_VERSION'] == "null" || MAP['SIT']['EMS_VERSION'] )
									MAP['SIT']['EMS_VERSION'] = ""
								MAP['DP']['SQL_DEPLOYMENT'] = sh (script: """cat sql_deploy.tmp""",returnStdout: true).trim()
								if ( MAP['SIT']['SQL_VERSION']  == "NA" || MAP['SIT']['SQL_VERSION']  == "null" || MAP['SIT']['SQL_VERSION'] )
									MAP['SIT']['SQL_VERSION'] = ""
								MAP['DP']['FILE_DEPLOYMENT'] = sh (script: """cat file_deploy.tmp""",returnStdout: true).trim()
							}
							else
							{		
								MAP['DP']['EMS_DEPLOYMENT'] = false
								MAP['DP']['SQL_DEPLOYMENT'] = false
								MAP['SIT']['EMS_VERSION'] = ""
								MAP['SIT']['SQL_VERSION'] = ""
								MAP['DP']['FILE_DEPLOYMENT'] = ""
							}
							
							sit_deployment_validation()
							
							
							def userInput = input(id: 'userInput', message: 'Please check mail to validate the params and proceed if OK',
							parameters: [
											[$class: 'TextParameterDefinition', defaultValue: '0000', description: 'CHANGE REQUEST NUMBER', name: 'CRNum'],
											[$class: 'ChoiceParameterDefinition', defaultValue: 'DEPLOY_and_RESTART',description:'describing choices', name:'DEPLOY_TYPE', choices: "DEPLOY_and_RESTART_NOW\nSIT_SHEDULED_DEPLOY"]
							],
							submitterParameter: 'submitter',
							submitter: "${SITBWApprovers}"
							)					
				
							MAP['SIT']['BUILD_REQUESTER'] = userInput.submitter
							MAP['SIT']['CHANGE_REF_ID'] = userInput['CRNum']
							MAP['SIT']['SIT_DEPLOY_TYPE'] = userInput['DEPLOY_TYPE']							
							
							println("User input = ${MAP['DP']['CHANGE_REF_ID']}")
							
							if( userInput['DEPLOY_TYPE'] == "DEPLOY_and_RESTART_NOW" )
							{						
								sit_deploy_pipe = build job: 'TestDrivenDeployment/TDD_SIT_BW_Deployment', 
								parameters: [
											string(name: 'RELEASE', value: "${MAP['DP']['RELEASE']}"),
											string(name: 'TDD_ID', value: "${tmp_tdd_id}"),
											string(name: 'CRQ', value: "${MAP['SIT']['CHANGE_REF_ID']}"),
											string(name: 'Environment', value: "${MAP['SIT']['ENVIRONMENT']}"),
											string(name: 'ENGINE_NAME', value: "${MAP['DP']['ENGINE_NAME']}"),
											booleanParam(name: 'ONLY_GV', value: "${MAP['DP']['ONLY_GV']}"),
											string(name: 'BW_VERSION', value: "${MAP['DP']['BW_VERSION']}"),
											booleanParam(name: 'EMS_DEPLOYMENT', value: "${MAP['DP']['EMS_DEPLOYMENT']}"),
											string(name: 'EMS_VERSION', value: "${MAP['SIT']['EMS_VERSION']}"), 
											booleanParam(name: 'SQL_DEPLOYMENT', value: "${MAP['DP']['SQL_DEPLOYMENT']}"),
											string(name: 'SQL_VERSION', value: "${MAP['SIT']['SQL_VERSION']}"),
											string(name: 'Description', value: "${MAP['DP']['DESCRIPTION']}"),
											string(name: 'FILE_DEPLOYMENT', value: "${MAP['DP']['FILE_DEPLOYMENT']}"),
											string(name: 'BUILD_REQUESTER', value: "${MAP['SIT']['BUILD_REQUESTER']}")		
										], propagate:false 
								
								println(sit_deploy_pipe.result + " : ${sit_deploy_pipe.buildVariables.ST_ERROR_CODE}")
								
								if( sit_deploy_pipe.buildVariables.ST_ERROR_CODE.equals("200") )
								{
									println("Deployment Pipeline Success")
									break;
								}
								else
								{
									// println("Deployment Pipeline Failure  Detected")
									// println("${sit_deploy_pipe.buildVariables.ST_ERROR_CODE}")
									// println("${sit_deploy_pipe.buildVariables.ST_ERROR_MSG}")
									error_decision = errorCodeDecide(sit_deploy_pipe.buildVariables.ST_ERROR_CODE, sit_deploy_pipe.buildVariables.ST_ERROR_MSG, sit_deploy_pipe.buildVariables.PIPELINE_URL)
									if(error_decision)
									{
										break;
									}
									else
									{
										SUBMITTED_USER = MAP['SIT']['BUILD_REQUESTER']
										def devInput = input( id: 'devInput', message: 'Please check mail and approve if OK.',submitterParameter: 'submitter', submitter: "${SUBMITTED_USER}")
									}
								}
							}
							else if ( userInput['DEPLOY_TYPE'] == "SIT_SHEDULED_DEPLOY" )
							{
								updateQuery = "UPDATE CICD_RELEASES SET TECH_CHANGES_INVOLVED= '${MAP['SIT']['CHANGE_REF_ID']}',SIT_ENV= '${MAP['SIT']['ENVIRONMENT']}', STAGE_COMPLETED='SIT_SHEDULED_DEPLOY',SIT_APPROVAL='${MAP['SIT']['BUILD_REQUESTER']}' WHERE TDD_ID=${tmp_tdd_id}"
								println("DEBUG: Insert query is: " + updateQuery)
								dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: updateQuery
								
								break;
							}
							else 
							{
								println("Re write information")
							}	
					} // while loop					
					 tmp_tdd_id++
				} // for loop
			}
		}
	}
		
}
}
