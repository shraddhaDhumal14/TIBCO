import groovy.json.JsonOutput
import groovy.sql.*
import java.sql.Driver

def dbInsertOrUpdate(deployParams) {
	  
    int retryCount = 0;
    def mySQL = myGetDBConnect dbURL: deployParams.dbURL, dbUserName: deployParams.dbUserName, dbPassword: deployParams.dbPassword, dbDriver: deployParams.dbDriver
    while (1) 
    {
       if( retryCount > 0 && retryCount % 3 ==0 )
       {
        input 'Proceed or Abort?'      
       }
       try {
            mySQL.connection.autoCommit = false
            println("Executing Query :" + deployParams.insertQuery)
            int rowAffected = mySQL.executeUpdate(deployParams.insertQuery);
            mySQL.commit()
            mySQL.close()
            mySQL = null
            println("Insert/Update " + rowAffected + " row(s)")
            return true
        }
       catch(Exception ex) {
            println("Error in Executing Query :" + deployParams.insertQuery) 
            mySQL.rollback()
            mySQL.close()
            mySQL = null
            println("Sleeping for 60 seconds .... Will Retry "+ (retryCount+1)) 
            //println "Red Alert!! Inform CICD Team ++ DB Insert Error ++ ${ex}" 			
            sleep 60         
        }
        retryCount++
    }     
    return false       
}

def displayDebug(strModule, strDebugMessage)
{
  def debug=1;
  if(debug == 1)
     {   
         println("***************************************")
         println("Module :" + strModule)
         println("Debug Message :" + strDebugMessage)
     }
}

def myGetDBConnect(deployParams) {     
     def mySQL = groovy.sql.Sql.newInstance(deployParams.dbURL,deployParams.dbUserName,deployParams.dbPassword,deployParams.dbDriver)
     return mySQL
}

def mySingleSelectQuery(selectQuery){
     def mySQL =  myGetDBConnect dbURL: env.dbURL, dbUserName: env.dbUserName, dbPassword: env.dbPassword, dbDriver: env.dbDriver
  	 def rowData = [:]
     displayDebug('mySingleSelectQuery',selectQuery)
     def rowResults = mySQL.rows(selectQuery)
     mySQL.close();
     if(rowResults.size() == 0)
         return rowData;
     def headerList = new ArrayList(rowResults[0].keySet())
     for(def rlcounter=0;rlcounter<rowResults.size();rlcounter++)
     {
         def row = rowResults[rlcounter];
         rowData = [:]
         for(def rwHeaderCnt=0;rwHeaderCnt<headerList.size();rwHeaderCnt++)
         { 
           rowData.put(headerList[rwHeaderCnt], row[rwHeaderCnt]!= null  ? row[rwHeaderCnt].toString() : "")
         }
     }
	rowResults = null;
	mySQL = null;
	headerList = null;
    return rowData;
}

def errorCodeDecide(error_code, error_desc, pipeline_url)
{
    if(error_code == "")
    {
        echo "No Error Code Found "
        send_mail(error_code, error_desc, pipeline_url, devopsmail, "Action Required from ${ERROR_ACTIONEE}")
        return false;
    }
    
    //cbuser = currentBuild.rawBuild.causes[0].userId
    cbuser = User_ID
    sh(script: "line=`grep '${error_code}' CODE/Error_Codes`; echo \$line | awk -F~ '{print \$2}' > errdes; echo \$line | awk -F~ '{print \$3}' > erract; echo \$line | awk -F~ '{print \$4}' > erractne;");
    ERROR_DESC = sh(script: "cat errdes", returnStdout: true).trim()
    ERROR_ACTION = sh(script: "cat erract", returnStdout: true).trim()
    ERROR_ACTIONEE = sh(script: "cat erractne", returnStdout: true).trim()
    
    if(ERROR_ACTION == "Proceed") {
        return true;
    } else if(ERROR_ACTION == "Success" && ERROR_ACTIONEE == "Developer"){
	send_success_mail(error_code, error_desc, pipeline_url, cbuser, "TDD started for your commit!!!")
        return true;
    } else if(ERROR_ACTION == "Hold" && ERROR_ACTIONEE == "Developer"){
        send_mail(error_code, error_desc, pipeline_url, cbuser, "Action Required from ${ERROR_ACTIONEE}")
        return false;
    } else if(ERROR_ACTION == "Notify" && ERROR_ACTIONEE == "Developer"){
        send_mail(error_code, error_desc, pipeline_url, cbuser, "Action Required from ${ERROR_ACTIONEE}")
        return true;
    } else if (ERROR_ACTION == "Hold" && ERROR_ACTIONEE == "DevOps"){
        send_mail(error_code, error_desc, pipeline_url, devopsmail, "Action Required from ${ERROR_ACTIONEE}")
        return false;
    } else if(ERROR_ACTION == "Restart from Stage" && ERROR_ACTIONEE == "Developer"){
        send_mail(error_code, error_desc, pipeline_url, cbuser, "Action Required from ${ERROR_ACTIONEE}")
        return false;
    } else if (ERROR_ACTION == "Restart from Stage" && ERROR_ACTIONEE == "DevOps"){
        send_mail(error_code, error_desc, pipeline_url, devopsmail, "Action Required from ${ERROR_ACTIONEE}")
        return false;
    } else if(ERROR_ACTION == "Abort" && ERROR_ACTIONEE == "Developer"){
        send_mail(error_code, error_desc, pipeline_url, cbuser, "Action Required from ${ERROR_ACTIONEE}")
       return false;
    } else if(ERROR_ACTION == "Abort" && ERROR_ACTIONEE == "DevOps"){
        send_mail(error_code, error_desc, pipeline_url, devopsmail, "Action Required from ${ERROR_ACTIONEE}")
        return false;
    } else {
        echo "Error Handling not handled Proper"
        send_mail(error_code, error_desc, pipeline_url, devopsmail, "Action Required from ${ERROR_ACTIONEE}")
        return false;
    } 
}

def send_mail(error_code, error_desc, pipeline_url, emailRecipents, emailSubject)
{
    emailContent="Error Code : ${error_code}<BR> Error Description : ${error_desc}<BR> Error Pipeline : ${pipeline_url} <BR> Current Pipeline : ${BUILD_URL}"
    
	    println("Email content: ${emailContent}")
	    println("Email Recipients : ${emailRecipents}")
	    
    emailext mimeType: 'text/html', 
    subject: "${emailSubject}",  
    from:"BW_ORCHESTRATOR@vodafone.com", 
    to: "${emailRecipents}", 
    body: "${emailContent}"
}

def send_success_mail(success_code, success_desc, pipeline_url, emailRecipents, emailSubject)
{
    emailContent="Success Code : ${success_code}<BR> Success Description : ${success_desc}<BR> Success Pipeline : ${pipeline_url} <BR> Current Pipeline : ${BUILD_URL}"
    
    emailext mimeType: 'text/html', 
    subject: "${emailSubject}",  
    from:"BW_ORCHESTRATOR@vodafone.com", 
    to: "${emailRecipents}", 
    body: "${emailContent}"
}

def send_mail_ta(error_desc, emailSubject, emailRecipents, pipeline_url)
{
    emailContent="Error Description : ${error_desc}<BR> Error Pipeline : ${pipeline_url}"
    
    emailext mimeType: 'text/html', 
    subject: "${emailSubject}",  
    from:"BW_ORCHESTRATOR@vodafone.com", 
    to: "${emailRecipents}", 
    body: "${emailContent}"
}


def getcssContent(){
    def css = """
        <style type="text/css">
        .tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
        .tg td{font-family:Times, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;width:150px;word-break:break-all;border-color:#9ABAD9;color:#444;}
        .tg th{font-family:Times, sans-serif;font-size:26px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:break-all;border-color:#9ABAD9;color:#1A0504;background-color:#409cff;}
        .tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
        .tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
        .tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
        .tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
        .tg .tg-0lax{text-align:left;vertical-align:top}
        .tg .tg-pass{background-color:lightgreen;text-align:left;vertical-align:top}
        .tg .tg-fail{background-color:red;text-align:left;vertical-align:top}
        .tg .tg-notstarted{background-color:lightgrey;text-align:left;vertical-align:top}
        .tg .tg-notrequired{background-color:#E1E0A2;text-align:left;vertical-align:top}
        </style>
        """
     return css
}

def get_release_notes_bw_sit(deployParams){
    def date_format_report = new Date().format("dd/MM/yyy HH:mm")
    def backgroundimage = "", subHeading = ""
    println("In the mail fn")
    if(deployParams.isDraft == "true")
    {
           backgroundimage = " background=\"${WORKSPACE}/draft.jpg\""
           subHeading = " - DRAFT"
    }
    
    BW = "${deployParams.BW_VERSION}"
    /*
    if(params.FILE_DEPLOYMENT)
    {
         BW += " (FILE DEPLOYMENT)"
    }
    if (params.ONLY_GV)
    {
         BW += " (ONLY GV)"
    }
    */
    project = deployParams.PROJECT
    jira = deployParams.JIRA
	    
    if(deployParams.EMS_VERSION == "false")
    {
           deployParams.EMS_VERSION = "NA"
    }
    if(deployParams.SQL_VERSION == "false")
    {
           deployParams.SQL_VERSION = "NA"
    }
    if(deployParams.ONLY_GV == "false")
    {
           deployParams.ONLY_GV = "NA"
    }
    if(!deployParams.FILE_DEPLOYMENT?.trim())
    {
           deployParams.FILE_DEPLOYMENT = "NA"
    }
	    
	    
	def body_build_summary = """
		${getcssContent()}
        <table class="tg" style="table-layout: fixed; width: 100%" ${backgroundimage}>        
		  <tr>
			<th class="tg-amwm" colspan="8">Release for ${deployParams.RELEASE}  ${subHeading}</th>
		  </tr>
          <tr>
			<th class="tg-amwm" colspan="8">${jira} | ${project}</th>
		  </tr>
         <tr>
            <td class="tg-1wig" colspan="1">PBI/ADO/DEFECT</td>
            <td class="tg-0lax" colspan="3">${jira}</td>
			<td class="tg-1wig" colspan="1">PROJECT_NAME</td>
			<td class="tg-0lax" colspan="3">${project}</td>            
		  </tr>
          <tr>
            <td class="tg-1wig" colspan="1">Description of Change</td>
            <td class="tg-0lax" colspan="7">${deployParams.Description}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">Impacted TIL Operation(s)</td>
            <td class="tg-0lax" colspan="7">${deployParams.operationName}</td>
          </tr>
		  <tr>
            <td class="tg-1wig" colspan="1">Impacted Engine</td>
            <td class="tg-0lax" colspan="3">${deployParams.ENGINE_NAME}</td>
           <td class="tg-1wig" colspan="1">Engine Type</td>
            <td class="tg-0lax" colspan="3">${deployParams.engine_type}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">BW Version</td>
            <td class="tg-0lax" colspan="3">${BW}</td>
            <td class="tg-1wig" colspan="1">EMS Deployment</td>
            <td class="tg-0lax" colspan="3">${deployParams.EMS_VERSION}</td>            
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">SQL Deployment</td>
            <td class="tg-0lax" colspan="3">${deployParams.SQL_VERSION}</td>
            <td class="tg-1wig" colspan="1">FILE DEPLOYMENT</td>
            <td class="tg-0lax" colspan="3">${deployParams.FILE_DEPLOYMENT}</td>
          </tr>
           <tr>
            <td class="tg-1wig" colspan="1">ONLY_GV</td>
            <td class="tg-0lax" colspan="3">${deployParams.ONLY_GV}</td>
            <td class="tg-1wig" colspan="1">ENVIRONMENT</td>
            <td class="tg-0lax" colspan="3">${deployParams.ENVIRONMENT}</td>
          </tr>
          <p id="bg-text" style="color:RED;font-size:40px;transform:rotate(300deg);-webkit-transform:rotate(300deg);">DRAFT DRAFT DRAFT</p>
         <tr>
			<th class="tg-amwm" colspan="8">Updates to Master Conf File. Replace with Env specific values where required</th>
		  </tr>       
        <tr>
            <td class="tg-1wig" colspan="1">Env MasterGV </td>
            <td class="tg-0lax" colspan="7">${deployParams.masterGV}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">Process GVs</td>
            <td class="tg-0lax" colspan="7">${deployParams.processGV}</td>
          </tr>        
          <tr>
            <td class="tg-1wig" colspan="1">RESTART_ENGINES</td>
            <td class="tg-0lax" colspan="7">${deployParams.restartEngines}</td>
          </tr>          
          <tr>
			<th class="tg-amwm" colspan="8">File Deployments & Other Configurations</th>
		  </tr>
          <tr>
            <td class="tg-1wig" colspan="1">FILE Deployment Type</td>
            <td class="tg-0lax" colspan="7">${deployParams.fileChanges}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">AppendPrependPath</td>
            <td class="tg-0lax" colspan="7">${deployParams.appendPrepand}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">KnownErrors</td>
            <td class="tg-0lax" colspan="7">${deployParams.knownError}</td>
          </tr>
          <tr> 
            <td class="tg-1wig" colspan="1">Special Instructions</td>
            <td class="tg-0lax" colspan="7">${deployParams.splInstructions}</td>
          </tr>
	  <tr> 
            <td class="tg-1wig" colspan="1">TA DETAIL</td>
            <td class="tg-0lax" colspan="7">${deployParams.taDetail}</td>
          </tr>
          <tr> 
            <td class="tg-1wig" colspan="1">Functional Dependencies</td>
            <td class="tg-0lax" colspan="7">${deployParams.functionalDependencies}</td>
          </tr>
		  <tr> 
            <td class="tg-1wig" colspan="1">Post Manual Changes</td>
            <td class="tg-0lax" colspan="7">${deployParams.postManualChanges}</td>
          </tr>
		  <tr> 
            <td class="tg-1wig" colspan="1">PRConf Changes</td>
            <td class="tg-0lax" colspan="7">${deployParams.prConf}</td>
          </tr>
          <tr>
	    <td class="tg-1wig" colspan="1">Main Pipeline URL</td>
	    <td class="tg-0lax" colspan="7"><div class="multiline">${deployParams.build_url.replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
	  </tr>
	  <tr>
	    <td class="tg-1wig" colspan="1">LOG_URL</td>
	    <td class="tg-0lax" colspan="7"><div class="multiline">${BUILD_URL}console</div></td>
	  </tr>
	</table>		
	"""
    
    println(body_build_summary);
	return body_build_summary
}	

def send_mail_release(emailRecipents, emailSubject, emailContent)
{
    
    emailext mimeType: 'text/html', 
    subject: "${emailSubject}",  
    from:"BW_ORCHESTRATOR@vodafone.com", 
    to: "${emailRecipents}", 
    body: "${emailContent}"
}

def GitClone(RepoName, TargetDirectory, BranchName )
{
    int retryCount = 0;
    def error = ""
    while (1) 
    {
       if( retryCount > 0 && retryCount % 3 ==0 )
       {
        input 'Proceed or Abort?'      
       }
       try 
	   {
            
            checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: "*/${BranchName}"]], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${TargetDirectory}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: "https://github.vodafone.com/VFUK-INTEGRATION/${RepoName}.git"]]]
            env.BP_ERROR_CODE = ""
			env.BP_ERROR_MSG = ""
            return true
       }
       catch(Exception ex) 
	   {
		    env.BP_ERROR_CODE = "203"
			env.BP_ERROR_MSG = "Github connection failed"
			println(env.BP_ERROR_CODE + " : " +  env.BP_ERROR_MSG)
			println("Github connection failed.")
			currentBuild.result = 'ABORTED'
			
            //println("Exception caught : " + ex + "while downloading Repo " +  RepoName); 
            //error = ex;
            //println("Sleeping for 5 seconds .... Will Retry "+ (retryCount+1))
            //println "Red Alert!! Inform CICD Team ++ Git Error ++ ${error}"
            sleep 5            
        }
        retryCount++
    }     
    return false       
}

def validate_TA()
{
		    //Deleting the existing downloaded code. In case of new config updates   
		sh "rm -Rf CODE/"
		checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/main']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "CODE"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/git-hook-test.git']]]
			
		sh(script: "chmod +x validate_release.sh; dos2unix validate_release.sh; ./validate_release.sh ${MAP['FE']['BRANCH']} ${MAP['ORCH']['ENGINE_NAME']};")
		MAP['RT']['BRANCH'] = sh (script: """cat RIT_release.tmp""",returnStdout: true).trim()
		repofound = sh (script: """cat RIT_repofound.tmp""",returnStdout: true).trim()

		println("RIT repe name = RIT_${MAP['ORCH']['ENGINE_NAME']} , Branch name =  ${MAP['FE']['BRANCH']}, Available Branch = ${MAP['RT']['BRANCH']}")
		//checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '${MAP['RT']['BRANCH']}']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "RITREPO"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/RIT_${MAP['DP']['ENGINE_NAME']}.git']]]
			
		def ta_issue = "false"
				
		if( repofound == "false" )
		{
			println("RIT repo found is false")
                	ta_issue = "true"
		}
	    	else
		{
			println("RIT repo found is true")
			GitClone("RIT_${MAP['ORCH']['ENGINE_NAME']}", "RITREPO", "${MAP['RT']['BRANCH']}")
			sh(script: "chmod +x GetOperationsList.sh; dos2unix GetOperationsList.sh; ./GetOperationsList.sh ${MAP['ORCH']['ENGINE_NAME']};")
			MAP['RT']['OPERATION_LIST'] = sh (script: """cat operation_list""",returnStdout: true).trim()
			String[] operation_array;
			operation_array = MAP['DP']['OPERATION_NAME'].split(';');
			println("Opr list from RIT repo = ${MAP['RT']['OPERATION_LIST']}")
			println("Opr list from commit = ${operation_array}")

			for( String values : operation_array )
			{
				println(values);
				//MAP['RT']['OPERATION_NAME'] = MAP['DP']['OPERATION_NAME']
				if(!MAP['RT']['OPERATION_LIST'].contains(values.trim()))
				{
					ta_issue = "true"
					break;
				}
			}
		  }
	
		if(ta_issue == "true")
		{
			send_mail_ta('RIT repo not proper or Operation names in commit does not match the AntScript. Please go to the below pipeline to abort and re-commit or to proceed without RIT TA', 'Action Required from Developer', MAP['ORCH']['USER'], '${BUILD_URL}')
			userInput = input(id: 'userInput', message: 'RIT repo not proper or Operation names in commit does not match the RIT test cases. Abort if you want to re-commit/Proceed to ignore RIT')
		//	parameters: [[$class: 'ChoiceParameterDefinition', defaultValue: 'YES',description:'describing choices', name:'nameChoice', choices: "YES\nNO"]])
			 
		//	if("${userInput['nameChoice']}" == "NO")
		//	{
		//		println("Proceeding with the build")
		//	}
		//	else
		//	{
		//		println("Aborting the build.")
		//		currentBuild.result = 'ABORTED'
		//		return	
		//	}
			println("RIT is not ready")
		}
		else
		{
			println("RIT is ready")
		}
}

def validate_trigger()
{
            sh(script: "chmod +x commitpayload.sh; ./commitpayload.sh ${build_id_var} ${job_name_var};")
			hooktrigger = sh (script: """cat iswebhook""",returnStdout: true).trim()
			
			if( hooktrigger == "Yes" )
		    	{
			
			       //checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/main']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "CODE"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/git-hook-test.git']]]    
			sh "rm -Rf CODE/"
			GitClone("git-hook-test", "CODE", "main")	
			//sh(script: "line=`tail -1 CODE/BW_BUILD.config`; echo \$line > BW_BUILD.config")
			/*sh(script: "chmod +x getcommitmsg.sh; ./getcommitmsg.sh")
			sh(script: "cat BW_BUILD.config")
			sh(script: "cat sequence_no")*/
				
				
			sh(script: "chmod +x getcommitheader.sh; ./getcommitheader.sh")
			sh(script: "cat commit_body")
			sh(script: "cat commit_header")
			sh(script: "cat sequence_no")
			
			fbcommitbody = sh (script: """cat commit_body""",returnStdout: true).trim()
				
			approval_check = sh (script: """cat release_approval""",returnStdout: true).trim()
		    
	 		MAP['BW']['RELEASE'] = sh (script: """cat releaseno""",returnStdout: true).trim()
			
			engine_name = sh (script: """cat reponame| sed 's/TIL_//g'""",returnStdout: true).trim()
				println("Engine name first = ${engine_name}")
			MAP['DP']['ISTIL_TSTIL'] = sh (script: """grep ${engine_name} CODE/applicationinfo.txt | awk -F~ '{print \$5}'""",returnStdout: true).trim()
			println(" Engine type ${MAP['DP']['ISTIL_TSTIL']}")
			//MAP['DP']['ENVIRONMENT'] = sh (script: """grep '${MAP['BW']['RELEASE']}' CODE/ENV_RELEASE_MAPPING.txt | awk -F~ '{print \$2}'""",returnStdout: true)
			env_for_ccs = sh (script: """dos2unix CODE/ENV_RELEASE_MAPPING.txt; grep '${MAP['BW']['RELEASE']}' CODE/ENV_RELEASE_MAPPING.txt | awk -F~ '{print \$2}'""",returnStdout: true).trim()
			sh(script: "dos2unix validate_feature.sh; chmod +x validate_feature.sh; ./validate_feature.sh;")
			env_for_ccs_fb = sh (script: """cat FEATURE_ENV""",returnStdout: true).trim()
				println("env_for_ccs = ${env_for_ccs}, env_for_ccs_fb = ${env_for_ccs_fb}")
		    	if ( MAP['DP']['ISTIL_TSTIL'] == "ISTIL")
			{	
				println("Inside ISTIL of if condition")
				MAP['DP']['ENVIRONMENT'] = env_for_ccs
				MAP['FE']['ENVIRONMENT'] = env_for_ccs_fb
			}
			else
			{
				MAP['DP']['ENVIRONMENT'] = "LNKTest15"
				MAP['FE']['ENVIRONMENT'] = "LNKTest15"
			} 
			println("approval check =  ${approval_check} ,Env =  ${MAP['FE']['ENVIRONMENT']}")
			MAP['ORCH']['SEQ_NO']= sh (script: """cat sequence_no""",returnStdout: true).trim()

			if( approval_check == "true" && env_for_ccs?.trim() && MAP['ORCH']['SEQ_NO'].trim().matches('[0-9]{7}') )
	        	{  	
                		println("Commit made in Release branch. All the pending stages will be skipped.")
				release_approved = "false"
	        	}
			else if( approval_check == "true" && env_for_ccs_fb?.trim() && MAP['ORCH']['SEQ_NO'].trim().matches('[0-9]{7}') )
			{
				MAP['FE']['BRANCH'] = MAP['BW']['RELEASE']
				sh(script: "cp FEATURE_RELNO releaseno;")
				release_approved = "true"
				payload = sh (script: """cat commitpayload.json""",returnStdout: true).trim()
				println("${payload}")
				//commitmessage = sh (script: """jq .commit.message commitpayload.json|sed 's/.*\\n\\n//'""",returnStdout: true).trim()
				//commitmessage = sh (script: '''jq .commit.message commitpayload.json|sed "s/\\\/~/g"''',returnStdout: true).trim()
				//println("Commit message = ${commitmessage}")
				User_ID = sh (script: """jq .commit.author.email commitpayload.json""",returnStdout: true).replaceAll("^\"|\"\$", "").trim();
				//println("User ID = ${User_ID}")
				(gl1, gl2, gl3, gl4, OP_name, fl_name) = sh (script: """jq .files[].filename commitpayload.json""",returnStdout: true).replaceAll("^\"|\"\$", "").trim().tokenize('/');
				//println("Operation name = ${OP_name}")
				//MAP['DP']['ENGINE_NAME'] = sh (script: """cat reponame""",returnStdout: true).trim()				
				println("Engine name = ${engine_name}")
               
                		MAP['ORCH']['ENGINE_NAME'] = sh (script: """cat reponame| sed 's/TIL_//g'""",returnStdout: true).trim()
                		MAP['ORCH']['RELEASE_NO'] = sh (script: """cat releaseno""",returnStdout: true).trim()
                		MAP['ORCH']['USER']=User_ID
                
                		println("Before Insert into DB")
                		println(MAP['ORCH'])
				
				MAP['DP']['OPERATION_NAME'] = sh (script: """cat commit_body | awk -F~ '{print \$4}'""",returnStdout: true).trim()
		    		if(!MAP['DP']['OPERATION_NAME']?.trim())
		    			MAP['DP']['OPERATION_NAME'] = OP_name
					
				validate_TA()
                
                		def ins_query = "insert into CICD_FB_RELEASES (SEQ_NO, RELEASE_NO, ENGINE_NAME, ORCH_URL,STATUS,STAGE_COMPLETED,CREATED_ON,CREATED_BY) values ('${MAP['ORCH']['SEQ_NO']}','${MAP['ORCH']['RELEASE_NO']}','${MAP['ORCH']['ENGINE_NAME']}','${BUILD_URL}','Active','PREPARATION',sysdate,'${MAP['ORCH']['USER']}')"
                
                		println("DEBUG: Insert query is: " + ins_query)
                		dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: ins_query
                    
                		select_query = "select TDD_ID from CICD_FB_RELEASES where ORCH_URL = '${BUILD_URL}'"
                		rowList = mySingleSelectQuery(select_query);
                		MAP['ORCH']['TDD_ID'] = (rowList["TDD_ID"] != null ) ? rowList["TDD_ID"].toString() : ""
				println("TDD ID = ${MAP['ORCH']['TDD_ID']}")

				String[] commit_body_array
				commit_body_array = fbcommitbody.split('~');
				println("Commit body array = ${commit_body_array}")
					
				String regex_pattern = ".*[\\\\()\\[\\]\\?\\|\\%\\&\\'\\/\\\n]+.*"
				if (fbcommitbody ==~ regex_pattern){
					println('ERROR: Commit body has some special characters "\\,(,),[,],?,|,%,&,\',/," or new line in it. Please re-commit with plain text.')
					release_approved = errorCodeDecide('701', 'Commit body has some special characters "\\,(,),[,],?,|,%,&,\',/," or new line in it. Please re-commit with plain text.', '${BUILD_URL}')
				}
				else if (commit_body_array.size() < 4)
				{
					println('ERROR: Commit body is not proper. Commit body format should be: ADO_No.~Project Description~ProjectName~OpertationName. Please refer user guide and re-commit.')
					release_approved = errorCodeDecide('701', 'Commit body is not proper. Commit body format should be: ADO_No.~Project Description~ProjectName~OpertationName. Please refer user guide and re-commit', '${BUILD_URL}')
				}
				else if (commit_body_array[0].indexOf(' ') != -1)
				{
					println('ERROR: ADO NUMBER should not contain spaces in between. Please re-commit with out space.')
					release_approved = errorCodeDecide('701', 'ADO NUMBER should not contain spaces in between. Please re-commit without space.', '${BUILD_URL}')
				}
				else
				{
					error_decision = errorCodeDecide('700', 'Valid Feature branch commit confirmation. Starting Build. No action required.', '${BUILD_URL}')
					if(error_decision)
                			{
                				println("Valid Commit. Proceeding to Build")
                			}
                			else
                			{
						// SUBMITTED_USER = User_ID
                      			//	def devInput = input( id: 'devInput', message: 'Please check mail and approve if OK.', submitterParameter: 'submitter', submitter: "${SUBMITTED_USER}")
							def devInput = input( id: 'devInput', message: 'Please check mail and approve if OK.')
                			}
				}
			}
			else
			{
				println("Error : Sequence No. and/or Approval string is missing in commit comments. \n All the pending stages will be skippied ")
			}

			}
			else
			{
				println("Not hook trigger ")
			}
}


approval_check = ""
devopsmail = "gopakumar.achari2@vodafone.com, devansh.patil1@vodafone.com"
bw_build_pipe = ""
payload = ""
commitmessage = ""
User_ID = ""
OP_name = ""
fl_name = ""
engine_name = ""
MAP = [:]
hooktrigger = ""
release_approved = "false"
seq_no = ""
repofound = ""
rit_ta_pipe =""
userInput=""
env_for_ccs = ""
env_for_ccs_fb = ""
ta_rn = "false"
rit_ta_pipe =""
rit_ta_pipe_skipped=""
userInput=""
fbcommitbody=""

//MAP Declaration
MAP['ORCH'] = ['SEQ_NO':'', 'TDD_ID':'', 'ENGINE_NAME':'', 'RELEASE_NO':'', 'USER':'']

MAP['FE'] = ['ENVIRONMENT':'', 'BRANCH':'', 'ENGINE_NAME':'', 'RELEASE_NO':'', 'USER':'']

MAP['BW'] = ['RELEASE':'', 'TIL_MODULENAME':'', 'TIL_ARCHIVEFILES':'', 'PROJECTNAME':'',  'TIL_TRAVERSION':'', 'BW_VERSION':'', 'JIRA_NUMBER':'', 'JIRA_DESCRIPTION':'', 'SonarQube_Rules_Excluded':'', 'SonarQube_Exclude_Directories_or_Files':'']

MAP['DP'] = ['RELEASE':'', 'ENVIRONMENT':'', 'ENGINE_NAME':'', 'BW_VERSION':'',  'ONLY_GV':'',  'MASTER_GV_UPDATE':'',  'PROCESS_GV_UPDATE':'',  'APPEND_PREPEND_PATHS':'',  'SPECIAL_INSTRUCTIONS':'', 'EMS_DEPLOYMENT':'', 'SQL_DEPLOYMENT':'', 'FILE_DEPLOYMENT':'', 'DESCRIPTION':'', 'OPERATION_NAME':'','PROJECT_NAME':'', 'ENGINE_TYPE':'', 'ISTIL_TSTIL':'','POST_MANUAL_CHANGES':'','TA_DETAIL':'','FUNCTIONAL_DEPENDENCIES':'','PR_CONF_FILE':'']

MAP['RT'] = ['SEQ_NO':'', 'BRANCH':'', 'ENVIRONMENT':'', 'ENGINE_NAME':'',  'OPERATION_LIST':'', 'ENGINE_TYPE':'', 'EMAIL_ID':'']

MAP['RN'] = ['SEQ_NO':'']

pipeline{
agent any
	options {
        timeout(time: 5, unit: 'DAYS')
	}
	environment {
		dbURL = 'jdbc:oracle:thin:@195.233.199.13:33000:TIBTST1'
		dbUserName = 'CICD_OWN_DB01'
		dbPassword = 'TIL_CICD_DB'
		dbDriver = 'oracle.jdbc.driver.OracleDriver'
    }
    
    stages {
        
        stage ('Preparation') {
			steps {
			script {
					sh "if [ -f errdes ]; then rm errdes; fi"
					sh "if [ -f erract ]; then rm erract; fi"
					sh "if [ -f erractne ]; then rm erractne; fi"
					sh "if [ -f Env_gv.conf ]; then rm Env_gv.conf; fi"
					sh "if [ -f Process_gv.conf ]; then rm Process_gv.conf; fi"
					sh "if [ -f process_gv_update.tmp ]; then rm process_gv_update.tmp; fi"
					sh "if [ -f master_gv_update.tmp ]; then rm master_gv_update.tmp; fi"
					sh "if [ -f sql_deploy.tmp ]; then rm sql_deploy.tmp; fi"
					sh "if [ -f gv_deploy.tmp ]; then rm gv_deploy.tmp; fi"
					sh "if [ -f ems_deploy.tmp ]; then rm ems_deploy.tmp; fi"
					sh "if [ -f file_deploy.tmp ]; then rm file_deploy.tmp; fi"
					sh "if [ -f special_instructions.tmp ]; then rm special_instructions.tmp; fi"
					sh "if [ -f Prepend_Removed.txt ]; then rm Prepend_Removed.txt; fi"
					sh "if [ -f Prepend_Added.txt ]; then rm Prepend_Added.txt; fi"
					sh "if [ -f Append_Removed.txt ]; then rm Append_Removed.txt; fi"
					sh "if [ -f Append_Added.txt ]; then rm Append_Added.txt; fi"
					sh "if [ -f commit_hist.tmp ]; then rm commit_hist.tmp; fi"
					sh "if [ -f commit_message.tmp ]; then rm commit_message.tmp; fi"
					sh "if [ -f append_prepend_paths.tmp ]; then rm append_prepend_paths.tmp; fi"
					sh "if [ -f iswebhook ]; then rm iswebhook; fi"
					sh "if [ -f reponame ]; then rm reponame; fi"
					sh "if [ -f releaseno ]; then rm releaseno; fi"
					sh "if [ -f commit_body ]; then rm commit_body; fi"
					sh "if [ -f commit_header_tmp ]; then rm commit_header_tmp; fi"					
					sh "if [ -f commit_header ]; then rm commit_header; fi"
					sh "if [ -f sequence_no ]; then rm sequence_no; fi"
					sh "if [ -f release_approval ]; then rm release_approval; fi"
					sh "if [ -f FEATURE_RELNO ]; then rm FEATURE_RELNO; fi"
					sh "if [ -f FEATURE_ENV ]; then rm FEATURE_ENV; fi"
					sh "if [ -f BW_BUILD.config ]; then rm BW_BUILD.config; fi"
					sh "if [ -f DEPLOY_BUILD.config ]; then rm DEPLOY_BUILD.config; fi"
					
					validate_trigger();

                }
            }
        }
        
        stage ('BW_BUILD') {
		   when {
		    expression { hooktrigger == "Yes" && release_approved == "true" }
		   }
			steps {
				script {
                   println("BW Build")
                   while(1)
                   {
		    sh "rm -Rf CODE/"
                    checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/main']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "CODE"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/git-hook-test.git']]]    
			
		    //sh(script: "line=`tail -1 CODE/BW_BUILD.config`; echo \$line > BW_BUILD.config")
		    sh(script: "chmod +x getcommitmsg.sh; ./getcommitmsg.sh")
		    //sh(script: "cat BW_BUILD.config")
		    sh(script: "cat sequence_no")
		    approval_check = sh (script: """cat release_approval""",returnStdout: true).trim()
		    
		    //MAP['BW']['RELEASE'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$1}'""",returnStdout: true).trim()
		    MAP['BW']['RELEASE'] = sh (script: """cat releaseno""",returnStdout: true).trim()

			 if( approval_check == "false" || !MAP['FE']['ENVIRONMENT']?.trim() )
		    {  
		       println("Give approved as string in GIT commit. Make sure you are using release branch to build and deploy")
		       currentBuild.result = 'ABORTED'
		       return
		    }
		    MAP['BW']['HAS_BW_BUILD'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$5}'""",returnStdout: true).trim()
		    //MAP['BW']['TIL_MODULENAME'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$3}'""",returnStdout: true).trim()
		    //MAP['BW']['TIL_ARCHIVEFILES'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$4}'""",returnStdout: true).trim()
		    MAP['BW']['TIL_MODULENAME'] = sh (script: """cat reponame| sed 's/TIL_//g'""",returnStdout: true).trim()
		    //MAP['BW']['TIL_ARCHIVEFILES'] = sh (script: """cat reponame| sed 's/TIL_//g'""",returnStdout: true).trim()
			    
		    //println("Before clone - ${MAP['BW']['TIL_MODULENAME']} and ${MAP['BW']['RELEASE']}")
		    GitClone("TIL_${MAP['BW']['TIL_MODULENAME']}", "ENGINE_archive", "${MAP['BW']['RELEASE']}")
		    //MAP['BW']['TIL_ARCHIVEFILES'] = sh (script: """basename ENGINE_archive/Build/*.archive|cut -d. -f1""",returnStdout: true).trim()
                    MAP['BW']['TIL_ARCHIVEFILES'] = MAP['BW']['TIL_MODULENAME'] 


		    //println("TIL_Archivefiles = ${MAP['BW']['TIL_ARCHIVEFILES']}")
			    
		    MAP['BW']['PROJECTNAME'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$3}'""",returnStdout: true).trim()
		    //MAP['BW']['TIL_TRAVERSION'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$6}'""",returnStdout: true).trim()
		    //MAP['BW']['BW_VERSION'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$7}'""",returnStdout: true).trim()
		    MAP['BW']['TIL_TRAVERSION'] = sh (script: """grep ${engine_name} CODE/applicationinfo.txt | awk -F~ '{print \$3}'""",returnStdout: true).trim()
		    MAP['BW']['BW_VERSION'] = sh (script: """grep ${engine_name} CODE/applicationinfo.txt | awk -F~ '{print \$2}'""",returnStdout: true).trim()
		    //println("BW ver = ${MAP['BW']['TIL_TRAVERSION']}")
		   // println("Tra ver = ${MAP['BW']['BW_VERSION']}")
		    MAP['BW']['JIRA_NUMBER'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$1}'""",returnStdout: true).trim()
		    MAP['BW']['JIRA_DESCRIPTION'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$2}'""",returnStdout: true).trim()
		    //MAP['BW']['SonarQube_Rules_Excluded'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$10}'""",returnStdout: true).trim()
		    //MAP['BW']['SonarQube_Exclude_Directories_or_Files'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$11}'""",returnStdout: true).trim()
		
		    println("Has bw build = ${MAP['BW']['HAS_BW_BUILD']}")
		    if(MAP['BW']['HAS_BW_BUILD'] != "false" && MAP['BW']['HAS_BW_BUILD'] != "FALSE")
		    {
		    	MAP['BW']['HAS_BW_BUILD'] = "true"
		    }

	            if(MAP['BW']['HAS_BW_BUILD'] == "true" || MAP['BW']['HAS_BW_BUILD'] == "TRUE")
		    {
			bw_build_pipe = build job: '/TestDrivenDeployment/TDD_FEATURE_BUILD', 
                        parameters: [
                                    string(name: 'RELEASE', value: "${MAP['BW']['RELEASE']}"),
                                    string(name: 'TIL_MODULENAME', value: "${MAP['BW']['TIL_MODULENAME']}"),
                                    string(name: 'TIL_ARCHIVEFILES', value: "${MAP['BW']['TIL_ARCHIVEFILES']}"),
                                    string(name: 'PROJECTNAME', value: "${MAP['BW']['PROJECTNAME']}"),
                                    string(name: 'FEATURE_BRANCH', value: "${MAP['FE']['BRANCH']}"),
                                    string(name: 'TIL_TRAVERSION', value: "${MAP['BW']['TIL_TRAVERSION']}"),
                                    string(name: 'BW_VERSION', value: "${MAP['BW']['BW_VERSION']}"),
                                    string(name: 'BUILD_REQUESTER', value: "${MAP['ORCH']['USER']}"),
                                    string(name: 'JIRA_NUMBER', value: "${MAP['BW']['JIRA_NUMBER']}"),
                                    string(name: 'TDD_ID', value: "${MAP['ORCH']['TDD_ID']}"),
                                    string(name: 'JIRA_DESCRIPTION', value: "${MAP['BW']['JIRA_DESCRIPTION']}") //,
                                    //string(name: 'SonarQube_Rules_Excluded', value: "${MAP['BW']['SonarQube_Rules_Excluded']}"),
                                    //string(name: 'SonarQube_Exclude_Directories_or_Files', value: "${MAP['BW']['SonarQube_Exclude_Directories_or_Files']}")
                                ], propagate:false
                        
                        println(bw_build_pipe.result + " : ${bw_build_pipe.buildVariables.BP_ERROR_CODE}")
                        }
			else
			{
				println("Skipping BWBuild")
				break;
			}
			
                        if( bw_build_pipe.buildVariables.BP_ERROR_CODE.equals("200") )
                        {
                              println("BW Build Success")
                              break;
                        }
                        else
                        {
                              println("BW Build Failure Detected")
                              println("${bw_build_pipe.buildVariables.BP_ERROR_CODE}")
                              println("${bw_build_pipe.buildVariables.BP_ERROR_MSG}")
                              error_decision = errorCodeDecide(bw_build_pipe.buildVariables.BP_ERROR_CODE, bw_build_pipe.buildVariables.BP_ERROR_MSG, bw_build_pipe.buildVariables.PIPELINE_URL)
                              if(error_decision)
                              {
                                  break;
                              }
                              else
                              {
                                      //SUBMITTED_USER = currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId()
				     // SUBMITTED_USER = User_ID
                                      //def devInput = input( id: 'devInput', message: 'Please check mail and approve if OK.', submitterParameter: 'submitter', submitter: "${SUBMITTED_USER}")
				      def devInput = input( id: 'devInput', message: 'Please check mail and approve if OK.')
                              }
                        }
                   }//while
                   
                }
			}
		}
        
		stage ('BW_EMS_SQL') {
            when {
			     expression { ((MAP['BW']['HAS_BW_BUILD'] == "true" || MAP['BW']['HAS_BW_BUILD'] == "TRUE") && bw_build_pipe.result == "SUCCESS" && bw_build_pipe.buildVariables.BP_ERROR_CODE.equals("200")) && hooktrigger == "Yes" && release_approved == "true" || 
			     			(MAP['BW']['HAS_BW_BUILD'] == "false" || MAP['BW']['HAS_BW_BUILD'] == "FALSE") && hooktrigger == "Yes" && release_approved == "true" }
			    }
			steps {
				script {
                    
                   println("Deployment Pipeline")
                   while(1)
                   {
                    
		    //Deleting the existing downloaded code. In case of new config updates
		    sh "rm -Rf CODE/"
		    checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/main']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "CODE"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/git-hook-test.git']]]
			
		    //sh(script: "line=`tail -1 CODE/DEPLOY_BUILD.config`; echo \$line > DEPLOY_BUILD.config")
		    sh(script: "cp BW_BUILD.config DEPLOY_BUILD.config")
		    sh(script: "cat DEPLOY_BUILD.config")
		    
                    //MAP['DP']['RELEASE'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$1}'""",returnStdout: true).trim()
		    MAP['DP']['RELEASE'] = MAP['BW']['RELEASE']
		  
               // MAP['DP']['ENVIRONMENT'] = sh (script: """grep '${MAP['DP']['RELEASE']}' CODE/ENV_RELEASE_MAPPING.txt | awk -F~ '{print \$2}'""",returnStdout: true).trim()
		    println("Env = ${MAP['FE']['ENVIRONMENT']}")  
                    //MAP['DP']['ENGINE_NAME'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$3}'""",returnStdout: true).trim()
		    //MAP['DP']['ENGINE_NAME'] = sh (script: """cat reponame""",returnStdout: true).trim()
		    MAP['DP']['ENGINE_NAME'] = MAP['BW']['TIL_MODULENAME']
                    if(MAP['BW']['HAS_BW_BUILD'] == "false" || MAP['BW']['HAS_BW_BUILD'] == "FALSE")
		    	MAP['DP']['BW_VERSION'] = ""
	            else
		    	MAP['DP']['BW_VERSION'] = bw_build_pipe.buildVariables.BW_VERSION
			    
		    seq_no = sh (script: """cat sequence_no""",returnStdout: true).trim()
		    GitClone("TIL_TestEnv_Configurations", "TestENV", "master")			
		    sh(script: "cp TestENV/BW_Configuration/${MAP['FE']['ENVIRONMENT']}/MasterConfiguration/*Env_gv_Config.gvconf Env_gv.conf")
		    sh(script: "cp TestENV/BW_Configuration/${MAP['FE']['ENVIRONMENT']}/MasterConfiguration/*Process_gv_Config.gvconf Process_gv.conf")  
			    
		    sh(script: "chmod +x GV_Changes.sh; dos2unix GV_Changes.sh; ./GV_Changes.sh ${seq_no} BW_Config;")
	            sh(script: "chmod +x File_Deployment.sh; dos2unix File_Deployment.sh; ./File_Deployment.sh ${seq_no};")
		    sh(script: "./GV_Changes.sh ${seq_no} TestEnv ${MAP['FE']['ENVIRONMENT']};")  
			    
		    MAP['DP']['ONLY_GV'] = sh (script: """cat gv_deploy.tmp""",returnStdout: true).trim()
		    MAP['DP']['MASTER_GV_UPDATE'] = sh (script: """cat master_gv_update.tmp""",returnStdout: true).trim()
		    MAP['DP']['PROCESS_GV_UPDATE'] = sh (script: """cat process_gv_update.tmp""",returnStdout: true).trim()
		    MAP['DP']['APPEND_PREPEND_PATHS'] = sh (script: """cat append_prepend_paths.tmp""",returnStdout: true).trim()
		    MAP['DP']['PR_CONF_FILE'] = sh (script: """cat pr_conf_file.tmp""",returnStdout: true).trim()
			GitClone("TIL_Manual_Automation", "RN_Artifacts", "main")
		    tmp_var= sh (script: """cat special_instructions.tmp""",returnStdout: true).trim()
			MAP['DP']['SPECIAL_INSTRUCTIONS']= sh(script: """grep $seq_no RN_Artifacts/ManualSpecialInstruction.txt | cut -f2 -d~""",returnStdout: true).trim()
			MAP['DP']['SPECIAL_INSTRUCTIONS'] += "\n${tmp_var}"
			MAP['DP']['POST_MANUAL_CHANGES'] = sh(script: """grep $seq_no RN_Artifacts/PostManualChanges.txt | cut -f2 -d~""",returnStdout: true).trim()
		        MAP['DP']['TA_DETAIL'] = sh(script: """grep $seq_no RN_Artifacts/TADetail.txt | cut -f2 -d~""",returnStdout: true).trim()
		        MAP['DP']['FUNCTIONAL_DEPENDENCIES'] = sh(script: """grep $seq_no RN_Artifacts/FunctionalDependencies.txt | cut -f2 -d~""",returnStdout: true).trim()		


			    
                    //MAP['DP']['ONLY_GV'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$6}'""",returnStdout: true).trim()
		    //MAP['DP']['ONLY_GV'] = sh (script: """cat gv_deploy.tmp""",returnStdout: true).trim()
                    //MAP['DP']['EMS_DEPLOYMENT'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$7}'""",returnStdout: true).trim()
		    MAP['DP']['EMS_DEPLOYMENT'] = sh (script: """cat ems_deploy.tmp""",returnStdout: true).trim()
                    //MAP['DP']['SQL_DEPLOYMENT'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$8}'""",returnStdout: true).trim()
		    MAP['DP']['SQL_DEPLOYMENT'] = sh (script: """cat sql_deploy.tmp""",returnStdout: true).trim()
                    //MAP['DP']['FILE_DEPLOYMENT'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$9}'""",returnStdout: true).trim()
		    MAP['DP']['FILE_DEPLOYMENT'] = sh (script: """cat file_deploy.tmp""",returnStdout: true).trim()    
                    //MAP['DP']['DESCRIPTION'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$10}'""",returnStdout: true).trim()
		    MAP['DP']['DESCRIPTION'] = MAP['BW']['JIRA_DESCRIPTION']
                    //MAP['DP']['OPERATION_NAME'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$11}'""",returnStdout: true).trim()
		    MAP['DP']['OPERATION_NAME'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$4}'""",returnStdout: true).trim()
		    if(!MAP['DP']['OPERATION_NAME']?.trim())
		    	MAP['DP']['OPERATION_NAME'] = OP_name
                    //MAP['DP']['PROJECT_NAME'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$12}'""",returnStdout: true).trim()
		    MAP['DP']['PROJECT_NAME'] = MAP['BW']['PROJECTNAME']
                    //MAP['DP']['ENGINE_TYPE'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$12}'""",returnStdout: true).trim()
		    
		    //MAP['DP']['ENGINE_TYPE'] = sh (script: """grep ${MAP['DP']['ENGINE_NAME']} CODE/applicationinfo.txt | awk -F~ '{print \$4}'""",returnStdout: true).trim()

			//MAP['DP']['CHANGE_REF_ID'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$13}'""",returnStdout: true).trim()
		    MAP['DP']['CHANGE_REF_ID'] = MAP['BW']['JIRA_NUMBER']		
			
			sh "cat TestENV/BW_Configuration/${MAP['FE']['ENVIRONMENT']}/Applications.txt"
			MAP['DP']['ENGINE_TYPE'] = sh (script: """grep ${MAP['DP']['ENGINE_NAME']} TestENV/BW_Configuration/${MAP['FE']['ENVIRONMENT']}/Applications.txt | wc -l""",returnStdout: true).trim()
			println("Engine count in LT env is = ${MAP['DP']['ENGINE_TYPE']}")
			if(MAP['DP']['ENGINE_TYPE'].equals("0"))
				MAP['DP']['ENGINE_TYPE'] = "NEW"
			else
				MAP['DP']['ENGINE_TYPE'] = "UPDATED"

			println("New Env = ${MAP['FE']['ENVIRONMENT']}")
			println("Engine type = ${MAP['DP']['ENGINE_TYPE']}")
				
			def emailContent = ""
			println("Before function call")
			//emailContent = get_release_notes_bw_sit isDraft:"false", isEdit:"false", BW_VERSION: MAP['DP']['BW_VERSION']
			emailContent= get_release_notes_bw_sit isDraft:"false", isEdit:"false", RELEASE: MAP['DP']['RELEASE'], BW_VERSION: MAP['DP']['BW_VERSION'], EMS_VERSION: MAP['DP']['EMS_DEPLOYMENT'], SQL_VERSION: MAP['DP']['SQL_DEPLOYMENT'], ENGINE_NAME: MAP['DP']['ENGINE_NAME'], JIRA: MAP['DP']['CHANGE_REF_ID'], PROJECT: MAP['DP']['PROJECT_NAME'], operationName: MAP['DP']['OPERATION_NAME'].replaceAll("[\\t\\n\\r]+","<br>") , Description: MAP['DP']['DESCRIPTION'].replaceAll("[\\t\\n\\r]+","<br>"),  fileChanges: MAP['DP']['FILE_DEPLOYMENT'].replaceAll("[\\t\\n\\r]+","<br>"), ONLY_GV: MAP['DP']['ONLY_GV'].replaceAll("[\\t\\n\\r]+","<br>"), ENVIRONMENT: MAP['FE']['ENVIRONMENT'].replaceAll("[\\t\\n\\r]+","<br>"), masterGV: MAP['DP']['MASTER_GV_UPDATE'].replaceAll("[\\t\\n\\r]+","<br>"), processGV: MAP['DP']['PROCESS_GV_UPDATE'].replaceAll("[\\t\\n\\r]+","<br>"), engineTemplate: MAP['DP']['ENGINE_NAME'].replaceAll("[\\t\\n\\r]+","<br>"), appendPrepand: MAP['DP']['APPEND_PREPEND_PATHS'].replaceAll("[\\t\\n\\r]+","<br>"), knownError: "NIL", postManualChanges: "Test", splInstructions: MAP['DP']['SPECIAL_INSTRUCTIONS'].replaceAll("[\\t\\n\\r]+","<br>"), restartEngines: MAP['DP']['ENGINE_NAME'], engine_type: MAP['DP']['ENGINE_TYPE'].replaceAll("[\\t\\n\\r]+","<br>"), build_url: BUILD_URL.replaceAll("[\\t\\n\\r]+","<br>"),taDetail: MAP['DP']['TA_DETAIL'].replaceAll("[\\t\\n\\r]+","<br>"),functionalDependencies: MAP['DP']['FUNCTIONAL_DEPENDENCIES'].replaceAll("[\\t\\n\\r]+","<br>"),prConf: MAP['DP']['PR_CONF_FILE'].replaceAll("[\\t\\n\\r]+","<br>")
			//emailContent="Test content"
			send_mail_release(MAP['ORCH']['USER'], "Release Parameters", emailContent) 				
				
			userInput = input(id: 'userInput', message: 'Please check mail to validate the params and proeed by selecting the ENV. Select Re-capture for issues.',
             parameters: [[$class: 'ChoiceParameterDefinition', 
                description:'describing choices', name:'nameChoice', choices: "${MAP['FE']['ENVIRONMENT']}\nRe-capture params\nLNKTest14\nLNKTest15\nLinkTest\nLNKTst17\nTILLT1\nTILLT2\nTILLT3\nTILLT4"]
             ])

		println("Current Env = ${MAP['FE']['ENVIRONMENT']}")
            println("User input = ${userInput}")
	    			   
			      if( userInput != "Re-capture params" )
                  {
			      	if( userInput == "${MAP['FE']['ENVIRONMENT']}" )	
						{				

			//deploy_pipe = build job: '/TestDrivenDeployment/TDD_BW_DEPLOYMENT',
			deploy_pipe = build job: '/TestDrivenDeployment/TDD_FEATURE_DEPLOY',
                    	parameters: [
									string(name: 'SEQ_NO', value: "${seq_no}"),			
                                    string(name: 'RELEASE', value: "${MAP['DP']['RELEASE']}"),
                                    string(name: 'Environment', value: "${MAP['FE']['ENVIRONMENT']}"),
                                    string(name: 'ENGINE_NAME', value: "${MAP['DP']['ENGINE_NAME']}"),
                                    string(name: 'BW_BUILD_REPO', value: "DEV_REPO"),
                                    string(name: 'BW_VERSION', value: "${MAP['DP']['BW_VERSION']}"),
                                    booleanParam(name: 'ONLY_GV', value: "${MAP['DP']['ONLY_GV']}"),
                                    booleanParam(name: 'EMS_DEPLOYMENT', value: "${MAP['DP']['EMS_DEPLOYMENT']}"),
                                    booleanParam(name: 'SQL_DEPLOYMENT', value: "${MAP['DP']['SQL_DEPLOYMENT']}"),
                                    string(name: 'FILE_DEPLOYMENT', value: "${MAP['DP']['FILE_DEPLOYMENT']}"),
                                    string(name: 'Description', value: "${MAP['DP']['DESCRIPTION']}"),
                                    string(name: 'OPERATION_NAME', value: "${MAP['DP']['OPERATION_NAME']}"),
                                    string(name: 'PROJECT_NAME', value: "${MAP['DP']['PROJECT_NAME']}"),
                                    string(name: 'ENGINE_TYPE', value: "${MAP['DP']['ENGINE_TYPE']}"),
                                    string(name: 'TDD_ID', value: "${MAP['ORCH']['TDD_ID']}"),
                                    string(name: 'BUILD_REQUESTER', value: "${MAP['ORCH']['USER']}"),
                                    string(name: 'CRQ', value: "${MAP['DP']['CHANGE_REF_ID']}"),
                                    string(name: 'SPECIAL_INSTRUCTIONS', value: "${MAP['DP']['SPECIAL_INSTRUCTIONS']}"),
                                    string(name: 'APPEND_PREPEND_PATHS', value: "${MAP['DP']['APPEND_PREPEND_PATHS']}"),
                                    string(name: 'MASTER_GV_UPDATE', value: "${MAP['DP']['MASTER_GV_UPDATE']}"),
                                    string(name: 'PROCESS_GV_UPDATE', value: "${MAP['DP']['PROCESS_GV_UPDATE']}"),
                                    string(name: 'DEPLOYMENT_FILES', value: "Dummy")				    
                                ], propagate:false 
                        
                        println(deploy_pipe.result + " : ${deploy_pipe.buildVariables.DP_ERROR_CODE}")
                        
                        if( deploy_pipe.buildVariables.DP_ERROR_CODE.equals("200") )
                        {
                              println("Deployment Pipeline Success")
                              break;
                        }
                        else
                        {
                              println("Deployment Pipeline Failure  Detected")
                              println("${deploy_pipe.buildVariables.DP_ERROR_CODE}")
                              println("${deploy_pipe.buildVariables.DP_ERROR_MSG}")
                              error_decision = errorCodeDecide(deploy_pipe.buildVariables.DP_ERROR_CODE, deploy_pipe.buildVariables.DP_ERROR_MSG, deploy_pipe.buildVariables.PIPELINE_URL)
                              if(error_decision)
                              {
                                  break;
                              }
                              else
                              {
                                      //SUBMITTED_USER = currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId()
				      // SUBMITTED_USER = User_ID
                                     def devInput = input( id: 'devInput', message: 'Please check mail and approve if OK.')
                              }
                        }
			       // break;     
				  }
					else
					{
						 MAP['FE']['ENVIRONMENT'] = userInput
					}

				} // if( userInput == "Deploy" )
                    else
                  {
                      println("Recapturing artifacts")
			      } // else of if( userInput == "Deploy" )
			


                   }//while                    
                }
			}
		}

		stage ('RIT TA') {
            		when {
			       expression { hooktrigger == "Yes" && release_approved == "true" && bw_build_pipe.result == "SUCCESS" && bw_build_pipe.buildVariables.BP_ERROR_CODE.equals("200") && deploy_pipe.result == "SUCCESS" && deploy_pipe.buildVariables.DP_ERROR_CODE.equals("200") }
			    // expression { 1 == 0 }
			    }
			steps {
				script {
                    
                   println("RIT TA")
				   
				 while(1)
                   {
                    
		    //Deleting the existing downloaded code. In case of new config updates   
		    sh "rm -Rf CODE/"
		    checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/main']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "CODE"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/git-hook-test.git']]]
			
			sh(script: "chmod +x validate_release.sh; dos2unix validate_release.sh; ./validate_release.sh ${MAP['FE']['BRANCH']} ${MAP['DP']['ENGINE_NAME']};")
			MAP['RT']['BRANCH'] = sh (script: """cat RIT_release.tmp""",returnStdout: true).trim()
			repofound = sh (script: """cat RIT_repofound.tmp""",returnStdout: true).trim()

			println("RIT repe name = RIT_${MAP['DP']['ENGINE_NAME']} , Branch name =  ${MAP['RT']['BRANCH']}")
			//checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '${MAP['RT']['BRANCH']}']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "RITREPO"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/RIT_${MAP['DP']['ENGINE_NAME']}.git']]]
			
							
		    if( repofound == "false" )
		    {
                              error_decision = errorCodeDecide("516", "RIT Engine Not Available", BUILD_URL.replaceAll("[\\t\\n\\r]+","<br>"))
                              if(error_decision)
                              {
                                  break;
                              }
                              else
                              {
                                      //SUBMITTED_USER = currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId()
				     // SUBMITTED_USER = User_ID
                                      //def devInput = input( id: 'devInput', message: 'Please check mail and approve if OK.', submitterParameter: 'submitter', submitter: "${SUBMITTED_USER}")
									  userInput = input(id: 'userInput', message: 'Please select yes if you want to perform RIT TA',
             parameters: [
			 [$class: 'ChoiceParameterDefinition', defaultValue: 'YES',description:'describing choices', name:'nameChoice', choices: "YES\nNO"],
			 [$class: 'TextParameterDefinition', defaultValue: '',description:'comments', name:'RIT_comment']
             ])
			 
			 if("${userInput['nameChoice']}" == "NO")
			 {
					 rit_ta_pipe_skipped = "200";
					 println("${userInput['RIT_comment']}")				 
				     break;
			 }            
		    }
			}
		    else
		    {
			    
				GitClone("RIT_${MAP['DP']['ENGINE_NAME']}", "RITREPO", "${MAP['RT']['BRANCH']}")
			
			   sh(script: "chmod +x GetOperationsList.sh; dos2unix GetOperationsList.sh; ./GetOperationsList.sh ${MAP['DP']['ENGINE_NAME']};")
			   MAP['RT']['OPERATION_LIST'] = sh (script: """cat operation_list""",returnStdout: true).trim()
			   String[] operation_array;
			   operation_array = MAP['DP']['OPERATION_NAME'].split(';');
			   def flag_opr="false"
			   for( String values : operation_array )
			   {
				println(values);
				//MAP['RT']['OPERATION_NAME'] = MAP['DP']['OPERATION_NAME']
				if(!MAP['RT']['OPERATION_LIST'].contains(values.trim()))
				{
					//MAP['RT']['OPERATION_NAME'] = MAP['RT']['OPERATION_LIST']
					userInput = input(id: 'userInput', message: 'AntScript does not contains operation name ${values}. Please correct the RIT repo and select yes if you want to perform RIT TA',
					parameters: [[$class: 'ChoiceParameterDefinition', defaultValue: 'YES',description:'describing choices', name:'nameChoice', choices: "YES\nNO"],[$class: 'TextParameterDefinition', defaultValue: '',description:'comments', name:'RIT_comment']])
			 
					if("${userInput['nameChoice']}" == "NO")
					{
						rit_ta_pipe_skipped = "200";
						println("${userInput['RIT_comment']}")
						flag_opr="true"
						break;
					}
					flag_opr="true"
				}
			  }
			  if( rit_ta_pipe_skipped == "200")
			  {
			  	break;
			  }
			  if( flag_opr.equals("false"))
			  { // else operationName fount in the operation_list = true			
				
				if(MAP['FE']['ENVIRONMENT'] == "LNKTest14")
				{
					MAP['RT']['ENVIRONMENT']="LNKTEST14"
				}
				else if(MAP['FE']['ENVIRONMENT'] == "LNKTest15")
				{
					MAP['RT']['ENVIRONMENT']="LNKTEST15"
				}
				else if(MAP['FE']['ENVIRONMENT'] == "LinkTest")
				{
					MAP['RT']['ENVIRONMENT']="LNKTEST16"
				}
				else if(MAP['FE']['ENVIRONMENT'] == "LNKTst17")
				{
					MAP['RT']['ENVIRONMENT']="LNKTEST17"
				}
				else
				{
					MAP['RT']['ENVIRONMENT']=MAP['FE']['ENVIRONMENT']
				}
				
			     println("Operation list from GetOperList = START ${MAP['RT']['OPERATION_LIST']} END")
			
				rit_ta_pipe = build job: '/TestDrivenDeployment/TDD_Feature_Test_Automation', 
                    		parameters: [
	                                    string(name: 'RELEASE_NO', value: "${MAP['DP']['RELEASE']}"),
	                                    string(name: 'ENVIRONMENT', value: "${MAP['RT']['ENVIRONMENT']}"),
	                                    string(name: 'ENGINE_NAME', value: "${MAP['DP']['ENGINE_NAME']}"),
	                                    string(name: 'SEQ_NO', value: "${seq_no}"),
	                                    string(name: 'OPERATION_NAME', value: "${MAP['DP']['OPERATION_NAME']}"),
	                                    string(name: 'ENGINE_TYPE', value: "${MAP['DP']['ENGINE_TYPE']}"),
                                        string(name: 'TDD_ID', value: "${MAP['ORCH']['TDD_ID']}"),
	                                    string(name: 'BUILD_REQUESTOR', value: "${MAP['ORCH']['USER']}"),
                                        string(name: 'GIT_BRANCH', value: "${MAP['RT']['BRANCH']}")
	                                ], propagate:false 
	                        
	                        println(rit_ta_pipe.result + " : ${rit_ta_pipe.buildVariables.TA_ERROR_CODE}")
                        
	                        if( rit_ta_pipe.buildVariables.TA_ERROR_CODE.equals("200") )
	                        {	
	                              println("RIT TA Pipeline Success")
								  rit_ta_pipe_skipped == "201"
	                              break;
	                        }
	                        else
	                        {
	                              println("RIT TA Pipeline Failure Detected")
	                              println("${rit_ta_pipe.buildVariables.TA_ERROR_CODE}")
	                              println("${rit_ta_pipe.buildVariables.TA_ERROR_MSG}")
	                              error_decision = errorCodeDecide(rit_ta_pipe.buildVariables.TA_ERROR_CODE, rit_ta_pipe.buildVariables.TA_ERROR_MSG, rit_ta_pipe.buildVariables.PIPELINE_URL)
	                              if(error_decision)
	                              {	  
									  rit_ta_pipe_skipped == "201"
	                                  break;
	                              }
	                              else
	                              {
	                                      //SUBMITTED_USER=currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId()
	                                      def devInput = input( id: 'devInput', message: 'Please check mail and approve if OK.')
	                              }
	                        }
			} //if repofound
			}
                   } 
			 }    //while               
                }
		}
	   stage ('SIT RN') {
            when {
			    // expression { ta_rn == "true" && hooktrigger == "Yes" && release_approved == "true" && bw_build_pipe.result == "SUCCESS" && bw_build_pipe.buildVariables.BP_ERROR_CODE.equals("200") && deploy_pipe.result == "SUCCESS" && deploy_pipe.buildVariables.DP_ERROR_CODE.equals("200") && ( rit_ta_pipe_skipped == "200" || rit_ta_pipe.result == "SUCCESS" && rit_ta_pipe.buildVariables.TA_ERROR_CODE.equals("200")) }
			    expression { 1 == 0 }
			    }
			steps {
				script {
                    
                   println("SIT RN")
				   
                   while(1)
                   {
						
						if( rit_ta_pipe_skipped.equals("200"))
                        {	  
							 updateQuery = "INSERT INTO TDD_TA_SUMMARY ( SEQ_NO,  RELEASE_NO,  ENGINE_NAME, OPERATION, RIT_BRANCH, ENVIRONMENT, PROG_PASS, PROG_FAIL, REG_PASS, REG_FAIL, TOTAL_TC, TEST_STATUS, STATUS, CREATED_ON, CREATED_BY, APPROVED_BY, TESTCASE_REPORT_URL, BUILD_URL) VALUES ( '${MAP['ORCH']['SEQ_NO']}', '${MAP['DP']['RELEASE']}', '${MAP['DP']['ENGINE_NAME']}','${MAP['RT']['OPERATION_NAME']}', 'NA', 'NA', 0, 0, 0, 0, 0, 'Not executed via RIT TA', 'Active', sysdate, '${MAP['ORCH']['USER']}', '', 'NA', 'NA')"
							  tmp_skip_var = "Skipping RIT because of following comments ${userInput['RIT_comment']}"							  
                              dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: updateQuery
							  println("Skipped RIT TA updating in DB")                              
							  updateQuery = "UPDATE CICD_FB_RELEASES SET TEST_AUTOMATION_URL='${tmp_skip_var}' WHERE TDD_ID=${MAP['ORCH']['TDD_ID']}"
							  dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: updateQuery
                        }
						//GitClone("TIL_DevOps_Framework", "JENKINS_FILE", "master")						
						//DB_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/dbFunctions.groovy"
						updateQuery = "UPDATE CICD_FB_RELEASES SET POST_MANUAL_CHANGES= '${MAP['DP']['POST_MANUAL_CHANGES']}', SPECIAL_INSTRUCTIONS= '${MAP['DP']['SPECIAL_INSTRUCTIONS']}', TA_DETAIL= '${MAP['DP']['TA_DETAIL']}',FUNCTIONAL_DEPENDENCIES= '${MAP['DP']['FUNCTIONAL_DEPENDENCIES']}',PR_CONF_FILE= '${MAP['DP']['PR_CONF_FILE']}' WHERE TDD_ID=${MAP['ORCH']['TDD_ID']}"
						//DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: updateQuery
						dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: updateQuery
			
                        sit_rn_pipe = build job: '/TestDrivenDeployment/TDD_SIT_RELEASE_NOTES', 
                    	parameters: [
                                    string(name: 'TDD_ID', value: "${MAP['ORCH']['TDD_ID']}"),
                                    string(name: 'SEQ_NO', value: "${MAP['ORCH']['SEQ_NO']}"),
                                    string(name: 'BUILD_REQUESTOR', value: "${MAP['ORCH']['USER']}")
                                ], propagate:false 
                        
                        println(sit_rn_pipe.result + " : ${sit_rn_pipe.buildVariables.RN_ERROR_CODE}")
                        
                        if( sit_rn_pipe.buildVariables.RN_ERROR_CODE.equals("200"))
                        {
                              println("SIT RN Pipeline Success")
                              break;
                        }
                        else
                        {
                              println("SIT RN Pipeline Failure Detected")
                              println("${sit_rn_pipe.buildVariables.RN_ERROR_CODE}")
                              println("${sit_rn_pipe.buildVariables.RN_ERROR_MSG}")
                              error_decision = errorCodeDecide(sit_rn_pipe.buildVariables.RN_ERROR_CODE, sit_rn_pipe.buildVariables.RN_ERROR_MSG, sit_rn_pipe.buildVariables.PIPELINE_URL)
                              if(error_decision)
                              {
                                  break;
                              }
                              else
                              {
                                      
                                    // SUBMITTED_USER = User_ID				      
                                    // def devInput = input( id: 'devInput', message: 'Please check mail and approve if OK.', submitterParameter: 'submitter', submitter: "${SUBMITTED_USER}")
							        def devInput = input( id: 'devInput', message: 'Please check mail and approve if OK.')
                              }
                        }
                   }//while                    
                }
			}
		}		

	   	stage ('Clean-up') {
			steps {
				script {
                   			println("Clean-up")
					//cleanWs disableDeferredWipeout: true, deleteDirs: true
                		}
			}
		}
	}
}
