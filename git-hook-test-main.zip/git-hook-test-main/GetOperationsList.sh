#!/bin/bash

ls RITREPO/$1/Logical/AntScripts/|sed -e "s/^$1//" -e 's/Progression.xml$//' -e 's/Regression.xml$//' -e 's/^_//' -e 's/_$/;/'|
sort|uniq|grep [0-9a-zA-Z]| tr -d '\n'>operation_list
cp operation_list temp_oper_list
sed 's/;$//' temp_oper_list > operation_list
