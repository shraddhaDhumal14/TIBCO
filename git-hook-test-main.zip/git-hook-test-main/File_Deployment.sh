#!/bin/bash
if [[ -s file_deploy.tmp ]]
then 
	rm -v file_deploy.tmp
fi
i=0
seq=$1
Email="false"
Jar="false"
Xml="false"
email_url=""
jar_url=""
xml_url=""
while [ 1 ]
do
mess=`jq .[$i].commit.message commit_hist.tmp|cut -c2- | rev | cut -c2- | rev`
echo $mess

if [[ $mess =~ ^$seq.* ]]  
then
	commit_url=`jq .[$i].url commit_hist.tmp | cut -c2- | rev | cut -c2- |rev`
	file_name=`curl -H "Authorization: token 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" $commit_url | jq .files[].filename | cut -c2- | rev | cut -c2- |rev | xargs  basename`
	echo $file_name
	if [[ $Email == "false" ]] && [[ $file_name == "Email_Template.txt" ]]
	then		 
        Email="true"
        echo $commit_url > email_url_file_deploy.tmp
	elif  [[ $Xml == "false" ]] && [[ $file_name == "XML_Template.txt" ]]
	then
        Xml="true"
        xml_url=`jq .[$i].url commit_hist.tmp | cut -c2- | rev | cut -c2- |rev`
		echo $commit_url > xml_url_file_deploy.tmp
	elif [[ $Jar == "false" ]] && [[ $file_name == "Jar_Template.txt" ]]
	then
        Jar="true"
        jar_url=`jq .[$i].url commit_hist.tmp | cut -c2- | rev | cut -c2- |rev`
		echo $commit_url > jar_url_file_deploy.tmp
	fi
fi
if [[ $i -gt 29 ]]
then
        break;
fi
i=$((i+1))
echo $i

done

echo "email deployment: $Email"
echo "$email_url"
echo "Jar deployment: $Jar"
echo $jar_url
echo "Xml deploymet :$Xml"
echo $xml_url

touch file_deploy.tmp
if [[ $Jar == "true" ]]
then
	echo "JAR," >> file_deploy.tmp
fi
if [[ $Xml == "true" ]]
then
	echo "XML," >> file_deploy.tmp
fi
if [[ $Email == "true" ]]
then
	echo "EMAIL," >> file_deploy.tmp
fi
