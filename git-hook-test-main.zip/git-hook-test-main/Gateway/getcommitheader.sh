#!/bin/bash

jq .commit.message commitpayload.json|sed -e 's/.*\\n\\n//' -e 's/"$//' > commit_body

jq .commit.message commitpayload.json|sed -e 's/\\n\\n.*$//' -e 's/^"//' > commit_header_tmp

jq .files[0].filename  commitpayload.json|sed  -e 's/^"//' -e 's/\/.*$//' -e 's/"$//' > GW_Type

cut -d~ -f1 commit_header_tmp > commit_header
cut -d_ -f1 commit_header > sequence_no
seq_no=`cat sequence_no`
cut -d_ -f2 commit_header > release_approval
approval_status=`grep -i approved release_approval`
[[ ! -z "$approval_status" ]] && echo "true" > release_approval || echo "false" > release_approval 
PARTNERCONFIG=`curl -H "Authorization: token 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" https://github.vodafone.com/api/v3/repos/VFUK-INTEGRATION/TIL_Automation_Framework/commits?per_page=100 | grep "$seq_no" | grep message | wc -l`
    if [ "$PARTNERCONFIG" -gt 0 ]
        then
            echo "true" > PARTNERCONFIG_F.tmp
    else
	        echo "false" >PARTNERCONFIG_F.tmp			
    fi
