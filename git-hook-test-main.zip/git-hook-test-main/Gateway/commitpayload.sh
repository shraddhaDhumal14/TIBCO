#!/bin/bash

if [ -s /opt/tibco/.jenkins/jobs/Gateway_TestDrivenDeployment/jobs/$2/builds/$1/polling.log ]
then
  echo "Yes" > iswebhook
else
  echo "No" > iswebhook
  exit
fi

commithash=`grep 'git log --full-histor' /opt/tibco/.jenkins/jobs/Gateway_TestDrivenDeployment/jobs/$2/builds/$1/polling.log |tail -1| sed 's/\.\./ /'|awk '{print $10}'`

echo Commit hash is $commithash

grep "Fetching upstream changes" /opt/tibco/.jenkins/jobs/Gateway_TestDrivenDeployment/jobs/$2/builds/$1/polling.log|cut -d/ -f5|sed 's/.git//'|
while read repo
do
  curl -H "Authorization: token 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" https://github.vodafone.com/api/v3/repos/VFUK-INTEGRATION/$repo/commits/$commithash > commitpayload.json
  payloadsize=`wc -l commitpayload.json|awk '{print $1}'`
  echo Payload size is $payloadsize
  if [ "$payloadsize" -gt "10" ]
  then
    echo $repo > reponame
    break;
  fi
done

grep $commithash /opt/tibco/.jenkins/jobs/Gateway_TestDrivenDeployment/jobs/$2/builds/$1/log | cut -d/ -f2|cut -d\) -f1|head -1 > releaseno

cat releaseno
