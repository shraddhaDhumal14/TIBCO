//[CICD-476] Fix: import this package as part of the fix
import com.cwctravel.hudson.plugins.extended_choice_parameter.ExtendedChoiceParameterDefinition
import java.text.*
import groovy.time.*

//[CICD-727] Insert Deployment metadata to release notes DB.
import groovy.json.JsonOutput
import groovy.sql.*
import java.sql.Driver

import hudson.tasks.Mailer;
import hudson.model.User;

@NonCPS
def getUserEmail(String id=null) {
    User user = User.getById(id ?: currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId(), false)
    user?.getProperty(Mailer.UserProperty.class).getAddress()
}

@NonCPS
def getBuildUserID(){
    return currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId()
}

def get_approvers_list(String approver_group){
	approvers_list = sh (script: """cat /opt/tibco/.jenkins/config.xml | sed -n \'/role name=\"${approver_group}\"/,\$p\' | sed \'/role>/q\' | grep "sid" | cut -d \'>\' -f 2 | cut -d \'<\' -f 1 | paste -s -d, -""", returnStdout: true).trim()
    return """${approvers_list}"""           
}

def get_approvers_email_list(String approvers_list){
   approvers_email=""
   println("${approvers_list}")
	approvers_list.split(',').each { user ->
            if(approvers_email.length() != 0)
              {
                    approvers_email += ","
              }
              approvers_email += getUserEmail(user)  
        }
    return """${approvers_email}"""   
}

def displayDebug(strModule, strDebugMessage)
{
  def debug=1;
  if(debug == 1)
     {   
         println("***************************************")
         println("Module :" + strModule)
         println("Debug Message :" + strDebugMessage)
     }
}

def myGetDBConnect(deployParams) {     
     def mySQL = groovy.sql.Sql.newInstance(deployParams.dbURL,deployParams.dbUserName,deployParams.dbPassword,deployParams.dbDriver)
     return mySQL
}

def mySingleSelectQuery(selectQuery){
     def mySQL =  myGetDBConnect dbURL: env.dbURL, dbUserName: env.dbUserName, dbPassword: env.dbPassword, dbDriver: env.dbDriver
  	 def rowData = [:]
     displayDebug('mySingleSelectQuery',selectQuery)
     def rowResults = mySQL.rows(selectQuery)
     mySQL.close();
     if(rowResults.size() == 0)
         return rowData;
     def headerList = new ArrayList(rowResults[0].keySet())
     for(def rlcounter=0;rlcounter<rowResults.size();rlcounter++)
     {
         def row = rowResults[rlcounter];
         rowData = [:]
         for(def rwHeaderCnt=0;rwHeaderCnt<headerList.size();rwHeaderCnt++)
         { 
           rowData.put(headerList[rwHeaderCnt], row[rwHeaderCnt]!= null  ? row[rwHeaderCnt].toString() : "")
         }
     }
	rowResults = null;
	mySQL = null;
	headerList = null;
    return rowData;
}

def myMultipleSelectQuery(selectQuery){     
     def mySQL =  myGetDBConnect dbURL: env.dbURL, dbUserName: env.dbUserName, dbPassword: env.dbPassword, dbDriver: env.dbDriver
  	 def rowData = [:]
	 def resultList = []
     //displayDebug('myMultipleSelectQuery',selectQuery)
     def rowResults = mySQL.rows(selectQuery)
     mySQL.close()
     if(rowResults.size() == 0)
            return resultList;
     def headerList = new ArrayList(rowResults[0].keySet())
	 for(def rlcounter=0;rlcounter<rowResults.size();rlcounter++)
     {
         def row = rowResults[rlcounter];
         rowData = [:]
         for(def rwHeaderCnt=0;rwHeaderCnt<headerList.size();rwHeaderCnt++)
         { 
               rowData.put(headerList[rwHeaderCnt], row[rwHeaderCnt]!= null  ? row[rwHeaderCnt].toString() : "")
         }
		 resultList.add(rowData)
     }
	 headerList=null;
	rowResults = null;
	rowData = null;
	mySQL = null;
    return resultList;
}

	def email_test_result()
{
    def test_result_summary = ""
    
    strQuery = "select DISTINCT ENVIRONMENT, RIT_BRANCH, TEST_STATUS, APPROVED_BY, COMMENTS, TESTCASE_REPORT_URL from TDD_TA_SUMMARY where SEQ_NO='${params.SEQUENCE_NO}' and STATUS = 'Active'"
    rowList = myMultipleSelectQuery(strQuery);
    
     def headerList = new ArrayList(rowList[0].keySet())
     
     test_result_summary+="<table class='tg' style='table-layout: fixed; width: 100%'>\n"
     test_result_summary+="<tr>\n"
     for(def rwHeaderCnt=0;rwHeaderCnt<headerList.size();rwHeaderCnt++)
     { 
         test_result_summary+="<th class='tg-amwm'>${headerList[rwHeaderCnt]}</th>\n"
     } 
     test_result_summary+="</tr>\n"
	 for(def rlcounter=0;rlcounter<rowList.size();rlcounter++)
     {
         def row = rowList[rlcounter];
         test_result_summary+="<tr>\n"
         for(def rwHeaderCnt=0;rwHeaderCnt<headerList.size();rwHeaderCnt++)
         { 
             row_value = row[headerList[rwHeaderCnt]]!= null  ? row[headerList[rwHeaderCnt]].toString() : ""
             test_result_summary+="<td class='tg-1wig'>${row_value}</td>\n"             
         }
         test_result_summary+="</tr>\n"
     }
    
    test_result_summary+="</table>"
    return test_result_summary;
}

def email_test_result_operations()
{
    def test_result_summary = ""
    
    strQuery = "select OPERATION, TOTAL_TC, PROG_PASS, PROG_FAIL, REG_PASS, REG_FAIL, TO_CHAR(CREATED_ON, 'DD-MON-YY HH24:MI')  from TDD_TA_SUMMARY where SEQ_NO='${params.SEQUENCE_NO}' and STATUS = 'Active' order by TA_ID DESC"
    rowList = myMultipleSelectQuery(strQuery);
    
     def headerList = new ArrayList(rowList[0].keySet())
     
     test_result_summary+="<table class='tg' style='table-layout: fixed; width: 100%'>\n"
     test_result_summary+="<tr>\n"
     for(def rwHeaderCnt=0;rwHeaderCnt<headerList.size();rwHeaderCnt++)
     { 
         test_result_summary+="<th class='tg-amwm'>${headerList[rwHeaderCnt]}</th>\n"
     } 
     test_result_summary+="</tr>\n"
	 for(def rlcounter=0;rlcounter<rowList.size();rlcounter++)
     {
         def row = rowList[rlcounter];
         test_result_summary+="<tr>\n"
         for(def rwHeaderCnt=0;rwHeaderCnt<headerList.size();rwHeaderCnt++)
         { 
            row_value = row[headerList[rwHeaderCnt]]!= null  ? row[headerList[rwHeaderCnt]].toString() : ""
            test_result_summary+="<td class='tg-1wig'>${row_value}</td>\n"             
         }
         test_result_summary+="</tr>\n"
     }
    
    test_result_summary+="</table>"
    println test_result_summary
    return test_result_summary;
}

def GitClone(RepoName, TargetDirectory, BranchName )
{
    int retryCount = 0;
    def error = ""
    while (1) 
    {
       if( retryCount > 0 && retryCount % 3 ==0 )
       {
        input 'Proceed or Abort?'      
       }
       try 
	   {

            checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: "*/${BranchName}"]], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${TargetDirectory}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: "https://github.vodafone.com/VFUK-INTEGRATION/${RepoName}.git"]]]
            env.BP_ERROR_CODE = ""
			env.BP_ERROR_MSG = ""
            return true
       }
       catch(Exception ex) 
	   {
		    env.BP_ERROR_CODE = "203"
			env.BP_ERROR_MSG = "Github connection failed"
			println(env.BP_ERROR_CODE + " : " +  env.BP_ERROR_MSG)
			println("Github connection failed.")
			currentBuild.result = 'ABORTED'

            //println("Exception caught : " + ex + "while downloading Repo " +  RepoName); 
            //error = ex;
            //println("Sleeping for 5 seconds .... Will Retry "+ (retryCount+1))
            //println "Red Alert!! Inform CICD Team ++ Git Error ++ ${error}"
            sleep 5            
        }
        retryCount++
    }     
    return false       
}

def get_gateway_sit_release_notes_draft(deployParams){
	def date_format_report = new Date().format("dd/MM/yyy HH:mm")
	def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Times, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;width:150px;word-break:break-all;border-color:#9ABAD9;color:#444;background-color:#FFFF;}
		.tg th{font-family:Times, sans-serif;font-size:26px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:break-all;border-color:#9ABAD9;color:#1A0504;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		.tg .tg-pass{background-color:lightgreen;text-align:left;vertical-align:top}
		.tg .tg-fail{background-color:red;text-align:left;vertical-align:top}
		.tg .tg-notstarted{background-color:lightgrey;text-align:left;vertical-align:top}
		.tg .tg-notrequired{background-color:#E1E0A2;text-align:left;vertical-align:top}
		</style>
		<table class="tg" style="table-layout: fixed; width: 100%"">
		   <tr>
			<th class="tg-amwm" colspan="8">${deployParams.EMAIL_HEADING}</th>
		  </tr>
          <tr>
			<th class="tg-amwm" colspan="8">${deployParams.CRQ} | ${deployParams.PROJECT}</th>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">BUILD_REQUESTER</td>
			<td class="tg-0lax" colspan="2">${deployParams.BUILD_REQUESTER}</td>
			<td class="tg-1wig" colspan="2">PROJECT_NAME</td>
			<td class="tg-0lax" colspan="2">${deployParams.PROJECT}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">GATEWAY</td>
			<td class="tg-0lax" colspan="2">${deployParams.GATEWAY_TYPE}</td>
			<td class="tg-1wig" colspan="2">RELEASE</td>
			<td class="tg-0lax" colspan="2">${deployParams.RELEASE}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">JIRA/PBI/CRQ NO</td>
			<td class="tg-0lax" colspan="2">${deployParams.CRQ}</td>
			<td class="tg-1wig" colspan="2">ENVIRONMENT</td>
			<td class="tg-0lax" colspan="2">${deployParams.ENVIRONMENT}</td>
		  </tr>	
		  <tr>
			<td class="tg-1wig" colspan="2">ENGINE_NAME</td>
			<td class="tg-0lax" colspan="6">${deployParams.EngineName}</td>
		  </tr>		  
		  <tr>
			<td class="tg-1wig" colspan="2">BUILD_DESCRIPTION</td>
			<td class="tg-0lax" colspan="6">${deployParams.Description}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">BUILD_URL</td>
			<td class="tg-0lax" colspan="6">${BUILD_URL}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">GATEWAY_VERSION</td>
			<td class="tg-0lax" colspan="6">${deployParams.gatewayVersion}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">OPERATION_NAME</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${deployParams.operation}</div></td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">TA_DETAILS</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${deployParams.TA_DETAILS}</div></td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">PARTNER_DATA</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${deployParams.partnerData}</div></td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">TOKENS</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${deployParams.tokens}</div></td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">SPECIAL_INSTRUCTIONS</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${deployParams.specialInst}</div></td>
		  </tr>		  
 		  <tr>
			<td class="tg-1wig" colspan="2">LOG_URL</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${BUILD_URL}/console</div></td>
		  </tr>  
		</table>		
	"""
	return body_build_summary
}

def get_gateway_sit_release_notes(deployParams){
	def date_format_report = new Date().format("dd/MM/yyy HH:mm")
	def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Times, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;width:150px;word-break:break-all;border-color:#9ABAD9;color:#444;background-color:#FFFF;}
		.tg th{font-family:Times, sans-serif;font-size:26px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:break-all;border-color:#9ABAD9;color:#1A0504;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		.tg .tg-pass{background-color:lightgreen;text-align:left;vertical-align:top}
		.tg .tg-fail{background-color:red;text-align:left;vertical-align:top}
		.tg .tg-notstarted{background-color:lightgrey;text-align:left;vertical-align:top}
		.tg .tg-notrequired{background-color:#E1E0A2;text-align:left;vertical-align:top}
		</style>
		<table class="tg" style="table-layout: fixed; width: 100%"">
		   <tr>
			<th class="tg-amwm" colspan="8">${deployParams.EMAIL_HEADING}</th>
		  </tr>
          <tr>
			<th class="tg-amwm" colspan="8">${deployParams.CRQ} | ${deployParams.PROJECT}</th>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">BUILD_REQUESTER</td>
			<td class="tg-0lax" colspan="2">${deployParams.BUILD_REQUESTER}</td>
			<td class="tg-1wig" colspan="2">PROJECT_NAME</td>
			<td class="tg-0lax" colspan="2">${deployParams.PROJECT}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">GATEWAY</td>
			<td class="tg-0lax" colspan="2">${deployParams.GATEWAY_TYPE}</td>
			<td class="tg-1wig" colspan="2">RELEASE</td>
			<td class="tg-0lax" colspan="2">${deployParams.RELEASE}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">JIRA/PBI/CRQ NO</td>
			<td class="tg-0lax" colspan="2">${deployParams.CRQ}</td>
			<td class="tg-1wig" colspan="2">ENVIRONMENT</td>
			<td class="tg-0lax" colspan="2">${deployParams.ENVIRONMENT}</td>
		  </tr>	
		  <tr>
			<td class="tg-1wig" colspan="2">ENGINE_NAME</td>
			<td class="tg-0lax" colspan="6">${deployParams.EngineName}</td>
		  </tr>		  
		  <tr>
			<td class="tg-1wig" colspan="2">BUILD_DESCRIPTION</td>
			<td class="tg-0lax" colspan="6">${deployParams.Description}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">BUILD_URL</td>
			<td class="tg-0lax" colspan="6">${BUILD_URL}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">GATEWAY_VERSION</td>
			<td class="tg-0lax" colspan="6">${deployParams.gatewayVersion}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">OPERATION_NAME</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${deployParams.operation}</div></td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">TA_DETAILS</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${deployParams.TA_DETAILS}</div></td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">PARTNER_DATA</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${deployParams.partnerData}</div></td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">TOKENS</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${deployParams.tokens}</div></td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">SPECIAL_INSTRUCTIONS</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${deployParams.specialInst}</div></td>
		  </tr>	
		   <tr>
			<td class="tg-amwm" colspan="2">Role</td>
            <td class="tg-amwm" colspan="1">Status</td>
            <td class="tg-amwm" colspan="3">Comments</td>
			<td class="tg-amwm" colspan="1">User</td>
			<td class="tg-amwm" colspan="1">DATE</td>			
		  </tr> 
          <tr>
			<td class="tg-0lax" colspan="2">Developer</td>
            <td class="tg-0lax" colspan="1">SUBMITTED</td>
			<td class="tg-0lax" colspan="3"></td>
            <td class="tg-0lax" colspan="1">${SUBMITTED_USER}</td>
			<td class="tg-0lax" colspan="1">${SUBMITTED_DATE}</td>			
		  </tr> 
          <tr>
			<td class="tg-0lax" colspan="2">Team Lead Approval</td>
			<td class="tg-0lax" colspan="1">${Apvl_TL_Status}</td>
            <td class="tg-0lax" colspan="3">${Apvl_TL_Comments}</td>
            <td class="tg-0lax" colspan="1">${Apvl_TL_Name}</td>
            <td class="tg-0lax" colspan="1">${Apvl_TL_Date}</td>		
		  </tr>          
		  <tr>
			<td class="tg-1wig" colspan="2">LOG_URL</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${BUILD_URL}/console</div></td>
		  </tr>  
		</table>		
	"""
	return body_build_summary
}

def getBuildUserName(){
    return currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserName()
}

//[CICD-476] Fix: function to get elapsed time duration 
def elapsedTime(Closure closure){
    def timeStart = new Date()
    closure()
    def timeStop = new Date()
    return TimeCategory.minus(timeStop, timeStart).toMilliseconds()
}

def preparation_function() {
	SITReleaseTechLeadApprovers = get_approvers_list('SITReleaseTechLeadApprovers')
    checkout_git_repositories()
    load_groovy_files()
    buildRequestorMail = "${params.BUILDREQUESTER}"
    dev_mailRecipients = dev_mailRecipients + "," + buildRequestorMail
	SUBMITTED_USER = "${params.BUILDREQUESTER}"
    if ("${params.ENVIRONMENT}" == "LNKTest16"){
        TARGET_Env = "LinkTest" 
    } else if ("${params.ENVIRONMENT}" == "LNKTest17"){
        TARGET_Env = "LNKTst17"
    }else if ("${params.ENVIRONMENT}" == "LNKTest14"){
        TARGET_Env = "LinkTest14"
    }else if ("${params.ENVIRONMENT}" == "LNKTest15"){
        TARGET_Env = "LinkTest15"
    }else {
         TARGET_Env = "${params.ENVIRONMENT}"
    }
}

def load_groovy_files() {
	// This function is to load all groovy files, where in common functions will be kept.
	emailFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/emailFunctions.groovy"
	commonFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/commonFunctions.groovy"

	//[CICD-727] Insert Deployment metadata to release notes DB.
	DB_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/dbFunctions.groovy"	
}

def checkout_git_repositories() {
	// This function is to checkout all the required GIT repositories.
	checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'JENKINS_FILE']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_DevOps_Framework.git']]])
}

def validate_input_parameters() {
        
        def validationCheck = ""
        // Validate input parameters and fail the pipeline if the parameters are not in valid format.
        String regex = /(^CCS\d+\.\d+_[a-zA-Z0-9]+$)|(^CCS\d+\.\d+$)/
        if(RELEASENO == ""){
            println('Release Number is mandatory for Gateway Pipeline')
            validationCheck = "F"
        } else if(RELEASENO.indexOf(' ') != -1){
            println('Release Number parameter should not contain spaces in between')
            validationCheck = "F"
        } else if (!(RELEASENO ==~ regex)){
            println('Release Number parameter is not in standard format. Please input either in CCS20.12 or CCS20.12_x format')
            validationCheck = "F"
        }
        
        if(ENVIRONMENT == ""){
            println("ENVIRONMENT parameter to be specified for the Deployment")
            validationCheck = "F"
        }
        
        if(GATEWAYTYPE == ""){
            println("GATEWAYTYPE parameter to be specified for the Deployment")
            validationCheck = "F"
        }
        
        //if (! BUILD_REQUESTER.matches('^[a-zA-Z0-9._%+-]+@vodafone.com$')){
        //    println('Please enter Valid Vodafone email ID for Build Requester')
        //    validationCheck = "F"
        //}
        
        if (CHANGE_REF_ID == ""){
            println('CHANGE_REF_ID parameter to be specified for the Deployment')
            validationCheck = "F"
        }
        
        if (CHANGE_REF_ID.indexOf(' ') != -1){
            println('Parameter validation failed.CHANGE_REF_ID should not contain space in between.')
            validationCheck = "F"
        }
		
		if (ENGINE_NAME == ""){
            println("ENGINE_NAME parameter to be specified for the Deployment")
            validationCheck = "F"
        }
		
        if(DESCRIPTION == ""){
            println("DESCRIPTION parameter to be specified for the Deployment")
            validationCheck = "F"
        }
        //[CICD-1836]: Validating Description parameter against any symbols present in it.
        String regex_pattern = ".*[\\\\()\\[\\]\\?\\|\\%\\/\\\n]+.*"
        if (DESCRIPTION ==~ regex_pattern){
            println('ERROR: Description parameter has symbols or new line present in it. Please input plain text for description parameter')
            validationCheck = "F"
        }
        
        if(PROJECT_NAME == ""){
            println("PROJECT_NAME parameter to be specified for the Deployment")
            validationCheck = "F"
        }
        
        if(OPERATION_NAME == ""){
            println("OPERATION_NAME parameter to be specified for the Deployment")
            validationCheck = "F"
        }
        
        if(TOKENS == ""){
            println("TOKENS parameter to be specified for the Deployment")
            validationCheck = "F"
        }
        
        if(SPECIAL_INSTRUCTIONS == ""){
            println("SPECIAL_INSTRUCTIONS parameter to be specified for the Deployment")
            validationCheck = "F"
        }

        if(validationCheck == "F"){
			error("Pipeline Input parameter validation failed. Please check the errors in Console log.")
			currentBuild.result = 'ABORTED'
		}        
        
}

def get_build_num(){
	//This method returns the build number based on the previous build number for corresponding release.
	//String jobName = System.getenv('JOB_NAME')
	println (job_name)
	def seq_no
	def job = jenkins.model.Jenkins.instance.getItemByFullName(job_name)
	for (def build : job.builds){
		if (build.displayName.startsWith("${RELEASENO}")){
			//println build.properties.environment.BUILD_NUMBER.toString()
			if (build.displayName.contains('_')){
				seq_no = build.displayName.split("${RELEASENO}" + '_')[1].split('_')[0]
				if(seq_no.isInteger()){
				    seq_no = seq_no.toInteger() + 1
					//seq_no += 1
					return seq_no
					break;
				}
			}
		}	
	}
	if (seq_no == null || !seq_no.isInteger()){
		seq_no = 1
		return seq_no
	}
}

def getChangeString() {
	MAX_MSG_LEN = 100
	def changeString = ""

	echo "Gathering SCM changes"
	def changeLogSets = currentBuild.changeSets
	for (int i = 0; i < changeLogSets.size(); i++) {
		def entries = changeLogSets[i].items
		for (int j = 0; j < entries.length; j++) {
			def entry = entries[j]
			truncated_msg = entry.msg.take(MAX_MSG_LEN)
			changeString += "<br><br>${entry.commitId}      by    ${entry.author}    on    ${new Date(entry.timestamp)}:" + "<br>" + "${truncated_msg}" + "<br><br>" 
			def files = new ArrayList(entry.affectedFiles)
			for (int k = 0; k < files.size(); k++) {
				def file = files[k]
				if (file.path.contains("${params.GATEWAYTYPE}/")  || file.path.contains("Gateway_Configuration/${params.GATEWAYTYPE}/${TARGET_Env}/")) {
					changeString += "${file.editType.name} : ${file.path}" + "<br>"
				}
			}
		}
	}
	if (!changeString) {
		changeString = " - No new changes"
	}
	return changeString
}


def get_body_build_summary(deployParams){
	
	def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
		.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		</style>
		<table class="tg" style="undefined;table-layout: fixed; width: 900px">
		<colgroup>
		<col style="width: 100px">
		<col style="width: 350px">
		<col style="width: 100px">
		<col style="width: 350px">
		</colgroup>
		  <tr>
			<th class="tg-amwm" colspan="4">BUILD SUMMARY</th>
		  </tr>
		  <tr>
			<td class="tg-1wig">Submitted By</td>
			<td class="tg-0lax">${env.BUILDREQUESTER}</td>
			<td class="tg-1wig">Date</td>
			<td class="tg-0lax">${date_now}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">RELEASE NUMBER</td>
			<td class="tg-0lax">${env.RELEASENO}</td>
			<td class="tg-1wig">JIRA NUMBER</td>
			<td class="tg-0lax">${env.CHANGE_REF_ID}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">Engine Name</td>
			<td class="tg-0lax" colspan="3">${UpEngine_Name}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">Gateway Version</td>
			<td class="tg-0lax" colspan="3">${deployParams.artefactVersion}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">Description</td>
			<td class="tg-0lax" colspan="3">${env.DESCRIPTION}</td>
		  </tr>		  
		  <tr>
			<td class="tg-1wig">BUILD_URL</td>
			<td class="tg-0lax" colspan="3">${BUILD_URL}</td>
		  </tr>
		  <tr>
		</table>
		<br><br><br>
		<table class="tg" style="undefined;table-layout: fixed; width: 900px">
		<colgroup>
		<col style="width: 100px">
		<col style="width: 350px">
		<col style="width: 100px">
		<col style="width: 350px">
		</colgroup>
		  <tr>
			<td class="tg-1wig">CHANGES COMMITTED</td>
			<td class="tg-0lax" colspan="3">${getChangeString()}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">LOG_URL</td>
			<td class="tg-0lax" colspan="3">${BUILD_URL}/console</td>
		  </tr>  
		</table>
	"""
	emailBody = body_build_summary
	return body_build_summary
}

def RECAPTURE()
	{
	while(condition == "RECAPTURE")
					{	
						GatewayUsers = commonFunctions.get_approvers_list('GatewayUsers')
						def email_heading = "GATEWAY SIT Release Notes for ${params.RELEASENO} - Developers Draft"
						
					GitClone("TIL_Manual_Automation", "RN_Artifacts", "main")
					Special_Instructions = sh(script: """grep ${params.SEQUENCE_NO} RN_Artifacts/Gateway/SpecialInstruction.txt | cut -f2 -d~""",returnStdout: true).trim()
					Partner_Data = sh(script: """grep ${params.SEQUENCE_NO} RN_Artifacts/Gateway/PartnerData.txt | cut -f2 -d~""",returnStdout: true).trim()
					TA_Details = sh(script: """grep ${params.SEQUENCE_NO} RN_Artifacts/Gateway/TADetails.txt | cut -f2 -d~""",returnStdout: true).trim()
					Tokens = sh(script: """grep ${params.SEQUENCE_NO} RN_Artifacts/Gateway/Tokens.txt  | cut -f2 -d~""",returnStdout: true).trim()
	
						//DEVELOPERS DRAFT MAIL
					def emailContent = 	get_gateway_sit_release_notes_draft GATEWAY_TYPE: "${params.GATEWAYTYPE}",EMAIL_HEADING:"${email_heading}" , RELEASE: "${params.RELEASENO}", BUILD_REQUESTER: "${params.BUILDREQUESTER}", CRQ: "${params.CHANGE_REF_ID}", ENVIRONMENT: "${DC_ENV}", PROJECT:"${params.PROJECT_NAME}", EngineName:"${UpEngine_Name}", gatewayVersion: "${nextVersion}", Description: "${params.DESCRIPTION}", operation: OPERATION_NAME.replaceAll("[\\t\\n\\r]+","<br>"), TA_DETAILS:TA_Details.replaceAll("[\\t\\n\\r]+","<br>"), partnerData: Partner_Data.replaceAll("[\\t\\n\\r]+","<br>"), tokens: Tokens.replaceAll("[\\t\\n\\r]+","<br>"), specialInst: Special_Instructions.replaceAll("[\\t\\n\\r]+","<br>")
						
					emailContent += email_test_result()
					emailContent += email_test_result_operations()

					emailext mimeType: 'text/html',
						subject: "[Jenkins]:${currentBuild.fullDisplayName}:GATEWAY RELEASE NOTES FOR ${params.GATEWAYTYPE} for ${params.RELEASENO}",
						from:"TIL_GATEWAY@vodafone.com",
						to: "${dev_mailRecipients}",
						body: "${emailContent}"
						
						def userInput = input(id: 'userInput', message: 'Please review Developers Draft and proceed further accordingly',
					parameters: [
									[$class: 'ChoiceParameterDefinition', defaultValue: 'SUBMIT', 
					description:'Submit RN for TL approval', name:'choice', choices: "SUBMIT\nRECAPTURE\nDECLINE"]
					],
					submitterParameter: 'submitter',
					submitter: "${GatewayUsers}"
					)
					
					/*if(userInput.TA.length() != 0)
                    {
                        APPROVAL_COMMENTS = Apvl_TL_Name + "[" + Apvl_TL_Status + ": " + Apvl_TL_Date + "] : " + TLInput.Comments
                    }*/
					if(userInput.choice == "SUBMIT")
					{
						condition = "APPROVED"
					}
					if(userInput.choice == "DECLINE")
					{
						currentBuild.result = 'ABORTED'
						error("Stage : SIT_RN. Pipeline aborted by ${userInput.submitter}")
					}
					}
				}
				
def RIT()
{

	while(1)		
                   {

		    //Deleting the existing downloaded code. In case of new config updates   
		    sh "rm -Rf CODE/"
		    checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/main']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "CODE"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/git-hook-test.git']]]

			sh(script: "chmod +x CODE/validate_release.sh; dos2unix CODE/validate_release.sh; CODE/validate_release.sh ${params.RELEASENO} ${UpEngine_Name};")
			BRANCH = sh (script: """cat RIT_release.tmp""",returnStdout: true).trim()
			repofound = sh (script: """cat RIT_repofound.tmp""",returnStdout: true).trim()

			println("RIT repo name = RIT_${UpEngine_Name} , Branch name =  ${BRANCH}")
			//checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '${MAP['RT']['BRANCH']}']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "RITREPO"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/RIT_${MAP['DP']['ENGINE_NAME']}.git']]]


		    if( repofound == "false" )
		    {
                              echo "RIT Engine Not Available"
							  
						 def emailContent="Error Description : RIT setup for ${UpEngine_Name} is not present. Please check your engine.<BR>Pipeline : ${BUILD_URL}"

						emailext mimeType: 'text/html', 
						subject: "Action Required from Developer",
						from:"TIL_GATEWAY@vodafone.com",
						to: "${dev_mailRecipients}",
						body: "${emailContent}"
						
                               //SUBMITTED_USER = currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId()
									  userInput = input(id: 'userInput', message: 'RIT Engine Not Available. Please select yes if you want to perform RIT TA',
             parameters: [
			 [$class: 'ChoiceParameterDefinition', defaultValue: 'YES',description:'describing choices', name:'nameChoice', choices: "YES\nNO"],
			 [$class: 'TextParameterDefinition', defaultValue: '',description:'comments', name:'RIT_comment']
			 ,[$class: 'TextParameterDefinition', defaultValue: '',description:'Please provide correct EngineName Ex:TMF622_ProductOrdering', name:'RIT_EngineName']
             ])
				
				if (userInput['RIT_EngineName']?.trim()) {
					
					UpEngine_Name = "${userInput['RIT_EngineName']}"
				}
				
			 if("${userInput['nameChoice']}" == "NO")
			 {
					 rit_ta_pipe_skipped = "200";
					 println("${userInput['RIT_comment']}")	
					 
					def RIT_ins_query = """INSERT INTO TDD_TA_SUMMARY ( SEQ_NO,  RELEASE_NO,  ENGINE_NAME, OPERATION, RIT_BRANCH, ENVIRONMENT, PROG_PASS, PROG_FAIL, REG_PASS, REG_FAIL, TOTAL_TC, TEST_STATUS, STATUS, CREATED_ON, CREATED_BY, APPROVED_BY, TESTCASE_REPORT_URL, BUILD_URL) VALUES ( '${params.SEQUENCE_NO}', '${params.RELEASENO}', '${UpEngine_Name}','${params.OPERATION_NAME}', 'NA', 'NA', 0, 0, 0, 0, 0, 'Not executed via RIT TA', 'Active', sysdate, '${params.BUILDREQUESTER}', '', 'NA', 'NA')"""
								tmp_skip_var = "Skipping RIT because of following comments ${userInput['RIT_comment']}"
						
					DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: RIT_ins_query								
								
					println("Skipped RIT TA updating in DB") 								
					def RIT1_ins_query = """Update CICD_RELEASES SET ENGINE_NAME = ${UpEngine_Name} , TEST_AUTOMATION_URL='${tmp_skip_var}' WHERE TDD_ID = ${temp_TDD_ID}"""
						
					DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: RIT1_ins_query
						
				     break;
			 }            
		  
			}
		    else
		    { //else for repo found = true

				GitClone("RIT_${UpEngine_Name}", "RITREPO", "${BRANCH}")

			   sh(script: "chmod +x CODE/GetOperationsList.sh; dos2unix CODE/GetOperationsList.sh; CODE/GetOperationsList.sh ${UpEngine_Name};")
			   OPERATION_LIST = sh (script: """cat operation_list""",returnStdout: true).trim()
			   String[] operation_array;
			   operation_array = "${params.OPERATION_NAME}".split(';');
			   def flag_opr="false"
				for( String values : operation_array )
				{
					println("${values} - inside forloop");
					
					if(!OPERATION_LIST.contains(values.trim()))
					{    
						def emailContent1="Error Description : AntScript does not contain operation name ${values}. Please correct the RIT repo.<BR>Pipeline : ${BUILD_URL}"

						emailext mimeType: 'text/html', 
						subject: "Action Required from Developer",
						from:"TIL_GATEWAY@vodafone.com",
						to: "${dev_mailRecipients}",
						body: "${emailContent1}"
						
						userInput = input(id: 'userInput', message: "AntScript does not contain operation name ${values}. Please correct the RIT repo and select yes if you want to perform RIT TA",
						parameters: [[$class: 'ChoiceParameterDefinition', defaultValue: 'YES',description:'describing choices', name:'nameChoice', choices: "YES\nNO"],[$class: 'TextParameterDefinition', defaultValue: '',description:'comments', name:'RIT_comment']])

						if("${userInput['nameChoice']}" == "NO")
						{
							rit_ta_pipe_skipped = "200";
							println("${userInput['RIT_comment']}")
							flag_opr="true"
							
						def RIT_ins_query = """INSERT INTO TDD_TA_SUMMARY ( SEQ_NO,  RELEASE_NO,  ENGINE_NAME, OPERATION, RIT_BRANCH, ENVIRONMENT, PROG_PASS, PROG_FAIL, REG_PASS, REG_FAIL, TOTAL_TC, TEST_STATUS, STATUS, CREATED_ON, CREATED_BY, APPROVED_BY, TESTCASE_REPORT_URL, BUILD_URL) VALUES ( '${params.SEQUENCE_NO}', '${params.RELEASENO}', '${UpEngine_Name}','${params.OPERATION_NAME}', 'NA', 'NA', 0, 0, 0, 0, 0, 'Not executed via RIT TA', 'Active', sysdate, '${params.BUILDREQUESTER}', '', 'NA', 'NA')"""
									tmp_skip_var = "Skipping RIT because of following comments ${userInput['RIT_comment']}"
						
						DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: RIT_ins_query								
								
						println("Skipped RIT TA updating in DB") 								
						def RIT1_ins_query = """Update CICD_RELEASES SET ENGINE_NAME = ${UpEngine_Name} , TEST_AUTOMATION_URL='${tmp_skip_var}' WHERE TDD_ID = ${temp_TDD_ID}"""
						
						DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: RIT1_ins_query
						
							break;
						}
						flag_opr="true"
					}
			  }
			  if( rit_ta_pipe_skipped == "200")
			  {
			  	break;
			  }
			  if( flag_opr.equals("false"))
			  { // else operationName fount in the operation_list = true			
				
				if(DC_ENV == "LinkTest14")
				{
					RT_ENVIRONMENT = "LNKTEST14"
				}
				else if(DC_ENV == "LinkTest15")
				{
					RT_ENVIRONMENT = "LNKTEST15"
				}
				else if(DC_ENV == "LinkTest")
				{
					RT_ENVIRONMENT = "LNKTEST16"
				}
				else if(DC_ENV == "LNKTst17")
				{
					RT_ENVIRONMENT = "LNKTEST17"
				}
				else
				{
					RT_ENVIRONMENT = DC_ENV
				}
		
			     println("Operation list from GetOperList = START ${RT_ENVIRONMENT} END")

				rit_ta_pipe = build job: '/Gateway_TestDrivenDeployment/GW_TDD_Test_Automation', 
                    		parameters: [
	                                    string(name: 'RELEASE_NO', value: "${params.RELEASENO}"),
	                                    string(name: 'ENVIRONMENT', value: "${RT_ENVIRONMENT}"),
	                                    string(name: 'ENGINE_NAME', value: "${UpEngine_Name}"),
	                                    string(name: 'SEQ_NO', value: "${params.SEQUENCE_NO}"),
	                                    string(name: 'OPERATION_NAME', value: "${params.OPERATION_NAME}"),
	                                    string(name: 'ENGINE_TYPE', value: "UPDATED"),
                                        string(name: 'TDD_ID', value: "${temp_TDD_ID}"),
	                                    string(name: 'BUILD_REQUESTOR', value: "${params.BUILDREQUESTER}"),
                                        string(name: 'GIT_BRANCH', value: "${BRANCH}")
	                                ], propagate:false 

	                        println(rit_ta_pipe.result + " : ${rit_ta_pipe.buildVariables.TA_ERROR_CODE}")

	                        if( rit_ta_pipe.buildVariables.TA_ERROR_CODE.equals("200") )
	                        {	
	                              println("RIT TA Pipeline Success")
								  rit_ta_pipe_skipped == "201"
	                              break;
	                        }
	                        else
	                        {
	                              println("RIT TA Pipeline Failure Detected")
	                              println("${rit_ta_pipe.buildVariables.TA_ERROR_CODE}")
	                              println("${rit_ta_pipe.buildVariables.TA_ERROR_MSG}")
								  
						 def emailContent2="Error Description : RIT stage for ${UpEngine_Name} failed. Please check logs<BR>Pipeline : ${BUILD_URL}<BR>TEST_AUTOMATION_URL : ${rit_ta_pipe.buildVariables.PIPELINE_URL}"

						emailext mimeType: 'text/html', 
						subject: "Action Required from Developer",
						from:"TIL_GATEWAY@vodafone.com",
						to: "${dev_mailRecipients}",
						body: "${emailContent2}"
						
	                                   //SUBMITTED_USER=currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId()
	                                      def devInput = input( id: 'devInput', message: 'Please check logs and proceed further to recapture.')
	                              
	                        }
			} //if repofound
			}
                   } 
}
				
SIT_ENV = 'T1'
nextVersion = " "
displayName = " "
emailBody = " "

// Global Parameters to use in the stages.

date_now = new Date()

// Mail recipents for the individual stages.
dev_mailRecipients = "devops-vfuk-integration@vodafone.com"
lt_approvers_mailRecipents = "devops-vfuk-integration@vodafone.com"
sit_promote_mailRecipents = "DL-VESTibcoSupport@vodafone.com;devops-vfuk-integration@vodafone.com"
prod_prmotote_mailRecipents = "devops-vfuk-integration@vodafone.com"

// [CICD-727]: Push all the deployment details to Release notes DB. 

SITReleaseTechLeadApprovers=""
Apvl_TL_Name=""
Apvl_TL_Status=""
Apvl_TL_Date=""
Apvl_TL_Comments=""
condition = "RECAPTURE"
EMAIL_SUBJECT=""
Special_Instructions = ""
Tokens = ""
Partner_Data = ""
TA_Details = ""
SUBMITTED_USER=""
SUBMITTED_DATE=""
sitPromotedBy = ""
buildRequestorMail = ""
dev_deployment = "PENDING"
TL_APPROVAL = "PENDING"
DC_ENV = ""
temp_TDD_ID = ""
repofound = ""
rit_ta_pipe = ""
rit_ta_pipe_skipped = ""
RT_ENVIRONMENT = ""
UpEngine_Name = ""
build_result = ""
//ADO 623654 Add timeout to the pipeline 

pipeline {
    agent any
	options {
        preserveStashes(buildCount: 49)
        timeout(time: 20, unit: 'DAYS')
    }
/* 	parameters {
        string(name: 'RELEASENO', defaultValue: '', description: 'Release Number')
    	string(name: 'CHANGE_REF_ID', defaultValue: '', description: 'CHANGE_REF_ID')
    	text(name: 'DESCRIPTION', defaultValue: '', description: 'DESCRIPTION')
    } */
    environment {
		//SIT_ENV = "T1"
		GROUPID = "GATEWAY"
		// Moving Gateway type to input parameter
		//GATEWAYTYPE = "IGW02"
		REPO_URL = "195.233.197.150:8081"
		LT_REPO = "LINKTEST_REPO"
		SIT_REPO = "SIT_REPO"
		PROD_REPO = "PROD_REPO"
		STAGING_REPO = "STAGING_REPO"
		//[CICD-539] Insert Deployment metadata to release notes DB.
		dbURL = 'jdbc:oracle:thin:@195.233.199.13:33000:TIBTST1'
		dbUserName = 'CICD_OWN_DB01'
		dbPassword = 'TIL_CICD_DB'
		dbDriver = 'oracle.jdbc.driver.OracleDriver'
    }

    stages {
		stage('Preparation') {
			steps {
				
				script{
							UpEngine_Name = "${params.ENGINE_NAME}" 
							def emailContent = "Gateway pipeline got triggered successfully. <BR> Pipeline : ${BUILD_URL}"
					validate_input_parameters()
					preparation_function()
					//Checkout Framework Artefacts from automation repository
					echo "Gateway Type selected is:${params.GATEWAYTYPE}"
					echo "Release number selected is: ${params.RELEASENO}"
				
					displayName = "${params.RELEASENO}_${BUILD_NUMBER}_${params.CHANGE_REF_ID}"
					currentBuild.displayName = "${displayName}"
					
					emailext mimeType: 'text/html', 
						subject: "Successful Trigger",
						from:"TIL_GATEWAY@vodafone.com",
						to: "${dev_mailRecipients}",
						body: "${emailContent}"	
				}
				//checkout gateway build code to show commit message info
				git branch: "${params.RELEASENO}", credentialsId: 'GITHUBKEY', poll: false, url: 'https://github.vodafone.com/VFUK-INTEGRATION/Gateway.git'
                // git credentialsId: 'GITHUBKEY', poll: false, url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git'

				/*emailext mimeType: 'text/html',
						 subject: "[Jenkins]: ${currentBuild.fullDisplayName}  - " + "Build CHANGE LOG SUMMARY",
						 from:"TIL_GATEWAY@vodafone.com",
						 to: "${dev_mailRecipients}",
                         body: 	"${get_body_build_summary(artefactVersion:'')}"*/
			}			
		}
		stage("BUILD") {
			steps {
			    git credentialsId: 'GITHUBKEY', poll: false, url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git'
				script {
					
				SUBMITTED_USER = "${params.BUILDREQUESTER}"
				SUBMITTED_DATE = new Date().format("dd/MM/yyy HH:mm")
				def email_heading = "GATEWAY SIT Release Notes for ${params.RELEASENO} - Developers Draft"
				
			
					//DEVELOPERS DRAFT MAIL
					def emailContent = 	get_gateway_sit_release_notes_draft GATEWAY_TYPE: "${params.GATEWAYTYPE}",EMAIL_HEADING:"${email_heading}" , RELEASE: "${params.RELEASENO}", BUILD_REQUESTER: "${params.BUILDREQUESTER}", CRQ: "${params.CHANGE_REF_ID}", ENVIRONMENT: "${params.ENVIRONMENT}", PROJECT:"${params.PROJECT_NAME}", EngineName:"${params.ENGINE_NAME}", gatewayVersion: "NA", Description: "${params.DESCRIPTION}", operation: OPERATION_NAME.replaceAll("[\\t\\n\\r]+","<br>"), TA_DETAILS:"Provide TA details in repo TIL_Manual_Automation", partnerData: "Provide partnerData details in repo TIL_Manual_Automation", tokens: "Provide tokens details in repo TIL_Manual_Automation", specialInst: "Provide specialInst details in repo TIL_Manual_Automation"
										
					emailext mimeType: 'text/html',
						subject: "[Jenkins]:${currentBuild.fullDisplayName}:GATEWAY RELEASE NOTES FOR ${params.GATEWAYTYPE} for ${params.RELEASENO}",
						from:"TIL_GATEWAY@vodafone.com",
						to: "${dev_mailRecipients}",
						body: "${emailContent}"
					
						/*def userInput = input(id: 'userInput', message: 'Please check RNDraft',
					parameters: [
									[$class: 'ChoiceParameterDefinition', defaultValue: 'SUBMIT', 
					description:'Proceed with Build', name:'choice', choices: "SUBMIT\nDECLINE"]
					],
					submitterParameter: 'submitter',
					submitter: "${SUBMITTED_USER}"
					)
					
					if(userInput.TA.length() != 0)
                    {
                        APPROVAL_COMMENTS = Apvl_TL_Name + "[" + Apvl_TL_Status + ": " + Apvl_TL_Date + "] : " + TLInput.Comments
                    }
					if(userInput.choice == "DECLINE")
					{
						   currentBuild.result = 'ABORTED'
						   error("Stage : Developers Draft rejected. Pipeline aborted by ${userInput.submitter}")
					}*/
					
					sh label: '', script: 'chmod 755 ./Build/get_next_version.sh'
					nextVersion = sh(script:"./Build/get_next_version.sh ${params.RELEASENO} ${env.REPO_URL} ${env.LT_REPO} ${env.GROUPID} ${params.GATEWAYTYPE}" ,returnStdout: true).trim()
					echo "next Version is: ${nextVersion}"
					
					//Stash the important values so that these can be retrieved for stage restart.
					sh "mkdir -p DIR_STASH"
					sh "echo nextVersion:${nextVersion} >DIR_STASH/propfile"
					sh "echo displayName:${displayName} >>DIR_STASH/propfile"
					stash includes: 'DIR_STASH/propfile', name: 'stashProperties'

					// Tokenise the env specific variables,zip the config files, generate the build number, upload artefact to Nexus Linktest Repo
					try
					{ 
					bw_build_pipe = build job: 'Gateway_TestDrivenDeployment/GatewayJobs/Gateway_Build', parameters: [string(name: 'BranchName', value: "${params.RELEASENO}"), string(name: 'IRIS_NO', value: "${params.CHANGE_REF_ID}"), string(name: 'GroupId', value: "${env.GROUPID}"), string(name: 'Repository', value: "${LT_REPO}"), string(name: 'ArtifactId', value: "${params.GATEWAYTYPE}"), text(name: 'IRISDes', value: "${params.Description}"), string(name: 'GatewayType', value: "${params.GATEWAYTYPE}"), string(name: 'Version', value: "${nextVersion}"), string(name: 'Parent_Job_Workspace', value: "${WORKSPACE}")]
					
					echo "Build Job is completed"
					}
					
					catch(Exception ex)
					{
						def build_ins_query = """Insert into CICD_RELEASES(SEQ_NO,RELEASE_NO,ENGINE_NAME,DEPLOYMENT_TYPE,STATUS,STAGE_COMPLETED,PROJECT_NAME,OPERATION,CHANGE_REF_ID,CHANGE_REF_DESCRIPTION,SPECIAL_INSTRUCTIONS,TA_DETAIL,CREATED_ON,CREATED_BY,MODIFIED_ON,MODIFIED_BY,LT_ENV,SIT_ENV,LT_APPROVAL,SIT_APPROVAL,SIT_DEPLOYMENT_ON,ORCH_URL,BW_BUILD_URL,DEPLOYMENT_BUILD_URL,TEST_AUTOMATION_URL,SIT_RN_URL,SIT_URL,GW_VERSION,GW_TYPE,PARTNER_DATA,GATEWAY_TOKEN,ERROR_CODE,ERROR_DESCRIPTION) values ('${params.SEQUENCE_NO}','${params.RELEASENO}','${params.ENGINE_NAME}','GATEWAY','FAILURE','Build','${params.PROJECT_NAME}','${params.OPERATION_NAME}','${params.CHANGE_REF_ID}','${params.DESCRIPTION}','','',sysdate,'${params.BUILDREQUESTER}','','','${params.ENVIRONMENT}','','${Apvl_TL_Name}','','','${BUILD_URL}','','','','','','${nextVersion}','${params.GATEWAYTYPE}','','','501','Build failure')"""
						
					DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: build_ins_query
						
						
						build_result = "FAILURE"
					}
					
					if (build_result == "FAILURE")
					{
						def emailContent1="Error Description : Build stage failed. Please check logs.<BR>Pipeline : ${BUILD_URL}"

						emailext mimeType: 'text/html', 
						subject: "Action Required from Developer",
						from:"TIL_GATEWAY@vodafone.com",
						to: "${dev_mailRecipients}",
						body: "${emailContent1}"
							
						currentBuild.result = 'ABORTED'
					}
					
					def build_ins_query = """Insert into CICD_RELEASES(SEQ_NO,RELEASE_NO,ENGINE_NAME,DEPLOYMENT_TYPE,STATUS,STAGE_COMPLETED,PROJECT_NAME,OPERATION,CHANGE_REF_ID,CHANGE_REF_DESCRIPTION,SPECIAL_INSTRUCTIONS,TA_DETAIL,CREATED_ON,CREATED_BY,MODIFIED_ON,MODIFIED_BY,LT_ENV,SIT_ENV,LT_APPROVAL,SIT_APPROVAL,SIT_DEPLOYMENT_ON,ORCH_URL,BW_BUILD_URL,DEPLOYMENT_BUILD_URL,TEST_AUTOMATION_URL,SIT_RN_URL,SIT_URL,GW_VERSION,GW_TYPE,PARTNER_DATA,GATEWAY_TOKEN,ERROR_CODE,ERROR_DESCRIPTION) values ('${params.SEQUENCE_NO}','${params.RELEASENO}','${params.ENGINE_NAME}','GATEWAY','ACTIVE','Build','${params.PROJECT_NAME}','${params.OPERATION_NAME}','${params.CHANGE_REF_ID}','${params.DESCRIPTION}','','',sysdate,'${params.BUILDREQUESTER}','','','${params.ENVIRONMENT}','','${Apvl_TL_Name}','','','${BUILD_URL}','','','','','','${nextVersion}','${params.GATEWAYTYPE}','','','200','Build successful')"""
					
					DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: build_ins_query
				
					// get the updated email body.
						 emailext mimeType: 'text/html',
						 subject: "[Jenkins]: ${currentBuild.fullDisplayName}  - " + "Build CHANGE LOG SUMMARY- SUCCESSFUL BUILD",
						 from:"TIL_GATEWAY@vodafone.com",
						 to: "${dev_mailRecipients}",
                         body: 	"${get_body_build_summary(artefactVersion:nextVersion)}"
				}
			}
		}
		stage("LinkTest Notify Partner config Update") {
			when {
				expression { PARTNERCONFIG == "true" }                    
			}			
			steps {
				// When Partner config is selected, send an email to DEV team to approve the partner config changes.
				script {
					GatewayUsers = commonFunctions.get_approvers_list('GatewayUsers')
					
					emailext mimeType: 'text/html',
						 subject: "[Jenkins]:${currentBuild.fullDisplayName}:Approval email for Partner Config Check?",
						 from:"TIL_GATEWAY@vodafone.com",
						 to: "${dev_mailRecipients}",
						 body: 	"${emailBody}" + "<br>" + 
								"<br><br><p><b><font size='5' color='Black'>Approve Partner Config changes : <a href='${BUILD_URL}input'>${currentBuild.displayName}</a></font></b></p>"
					def testOptions = 'YES\nNO'
					def userInput = input(
					  id: 'userInput', message: 'Partner Config changes updated and checked-in?',
					  submitterParameter: 'submitter',
					  submitter: "${GatewayUsers}"
					)	
				}
			}
		}		
		stage("Deploy to LinkTest Environment") {
			steps {
				script {
					// If the following values are blank, it means we are starting from stage and need to retrive the values from stash.
					unstash "stashProperties"
					if (nextVersion == " ") {
						nextVersion = sh(script:"cat ./DIR_STASH/propfile | grep -e nextVersion | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						echo "nextVersion after stage restart is:${nextVersion}"
					}
					if (displayName == " ") {
						//[CICD-593]: Checkout required GIT repositories after stage restart.
						preparation_function()
                        
						displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						currentBuild.displayName = "${displayName}_restart"
						echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
					}
 					
						/*if (emailBody == " ") {
						emailBody = "${get_body_build_summary(artefactVersion:nextVersion)}"
						echo "emailBody after stage restart is:${emailBody}"
					}*/
				
						select_query = """select TDD_ID from CICD_RELEASES where ORCH_URL = '${BUILD_URL}' and ENGINE_NAME = '${params.ENGINE_NAME}'"""
                        rowList = mySingleSelectQuery(select_query);
                        temp_TDD_ID = (rowList["TDD_ID"] != null ) ? rowList["TDD_ID"].toString() : ""
						println("Value of TDD_ID : ${temp_TDD_ID}")
						
				DC_ENV = "${params.ENVIRONMENT}"
				
				while(dev_deployment == "PENDING")
				{
				try 
				{
					// Invoke Ansible for Deployment
				sleep 5
				build job: 'Gateway_TestDrivenDeployment/GatewayJobs/Gateway_Deployment', parameters: [string(name: 'Environment', value: "${DC_ENV}"), string(name: 'repo_group_id', value: "${env.GROUPID}"), string(name: 'repo_artifact_id', value: "${params.GATEWAYTYPE}"), string(name: 'repo_user', value: 'admin'), string(name: 'repo_repo_id', value: 'LINKTEST_REPO'), string(name: 'ArtefactVersion', value: "${nextVersion}"), string(name: 'GatewayType', value: "${params.GATEWAYTYPE}")]
				
				echo " ${DC_ENV} Deploy completed"
				dev_deployment = "SUCCESS"
					}
					
					catch(Exception ex)
					{
						GatewayUsers = commonFunctions.get_approvers_list('GatewayUsers')
						def emailContent="Error Description : Deployment stage failed. Please check logs or change the env.<BR>Pipeline : ${BUILD_URL}"

						emailext mimeType: 'text/html', 
						subject: "Action Required from Developer",
						from:"TIL_GATEWAY@vodafone.com",
						to: "${dev_mailRecipients}",
						body: "${emailContent}"
							
					def dev_ins_query = """Update CICD_RELEASES SET STATUS = 'FAILURE' , LT_ENV = ${DC_ENV} , STAGE_COMPLETED = 'DEPLOYMENT' , ERROR_CODE = '501' , ERROR_DESCRIPTION = 'Deployment failure' WHERE TDD_ID = ${temp_TDD_ID}"""
						
					DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: dev_ins_query
					
						def devInput = input( id: 'devInput', message: 'Please select env',
                                            parameters: 
											[
                                            [$class: 'ChoiceParameterDefinition',
											description:'Please choose correct env as per RIT', name:'choice', choices: "LinkTest14\nLNKTst17\nLinkTest\nLinkTest15\nTILLT1\nTILLT2\nTILLT3\nTILLT4"]
											],
                                            submitterParameter: 'submitter',
											submitter: "${GatewayUsers}"
                                           )
							DC_ENV = "${devInput['choice']}"										   
					}
				}
					
					def dev_ins_query = """Update CICD_RELEASES SET STATUS= 'SUCCESS' , LT_ENV = ${DC_ENV} , STAGE_COMPLETED = 'DEPLOYMENT', ERROR_CODE = '200' , ERROR_DESCRIPTION = 'Deployment successful' WHERE TDD_ID = ${temp_TDD_ID}"""
						
					DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: dev_ins_query
					
						emailext mimeType: 'text/html',
						 subject: "[Jenkins]:${currentBuild.fullDisplayName}:Deployment summary",
						 from:"TIL_GATEWAY@vodafone.com",
						 to: "${dev_mailRecipients}",
						 body: 	"${emailBody}" + "<br>" + 
								"<br><br><p><b><font size='5' color='Black'>Deployment Pipeline : <a href='${BUILD_URL}input'>${currentBuild.displayName}</a></font></b></p>"
	            
                // Invoke job to update dashboard
				// Update dashboard with status
				// CICD-573 fix
					build job: '/TIL_PIPELINES/Common_Jobs/Dashboard_Publish', parameters: [string(name: 'Environment', value: "${DC_ENV}"), string(name: 'Component', value: "${params.GATEWAYTYPE}"), string(name: 'ArtefactVersion', value: "${nextVersion}"), string(name: 'Pipeline', value: "${params.GATEWAYTYPE}_Pipeline"), string(name: 'Description', value: '')]
								
				}
			}
		}
		stage("Deployment Validation In LinkTest Environment") {
			steps{
				// Run Automated tests if we have
				build 'Gateway_TestDrivenDeployment/GatewayJobs/Gateway_SystemTesting'
				script{
					unstash "stashProperties"
					if (nextVersion == " ") {
						nextVersion = sh(script:"cat ./DIR_STASH/propfile | grep -e nextVersion | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						echo "nextVersion after stage restart is:${nextVersion}"
					}
					if (displayName == " ") {
						//[CICD-593]: Checkout required GIT repositories after stage restart.
						preparation_function()
                        
						displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						currentBuild.displayName = "${displayName}_restart"
						echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
					}
					if (emailBody == " ") {
						emailBody = "${get_body_build_summary(artefactVersion:nextVersion)}"
						echo "emailBody after stage restart is:${emailBody}"
					}
				
				}				
			}
		}
		stage ('RIT TA') {
			steps {
				script {
					println("RIT TA")
				RIT(); 
			 }    //while               
                }
		}
		stage ('SIT_RN') {
			steps {
			script {
					
			//	GatewayApprovers = commonFunctions.get_approvers_list('GatewayApprovers')
				def techLeadmails = get_approvers_email_list(SITReleaseTechLeadApprovers) 
				SUBMITTED_USER = "${params.BUILDREQUESTER}"
				SUBMITTED_DATE = new Date().format("dd/MM/yyy HH:mm")
				
			while(TL_APPROVAL == "PENDING")
			{
				RECAPTURE();
				
				//TL APPROVAL MAIL
				email_heading = "GATEWAY SIT Release Notes for ${params.RELEASENO} - TechLead Approval Request"
				
				def emailContent1 = get_gateway_sit_release_notes_draft GATEWAY_TYPE: "${params.GATEWAYTYPE}",EMAIL_HEADING:"${email_heading}" , RELEASE: "${params.RELEASENO}", BUILD_REQUESTER: "${params.BUILDREQUESTER}", CRQ: "${params.CHANGE_REF_ID}", ENVIRONMENT: "${DC_ENV}", PROJECT:"${params.PROJECT_NAME}", EngineName:"${UpEngine_Name}", gatewayVersion: "${nextVersion}", Description: "${params.DESCRIPTION}", operation: OPERATION_NAME.replaceAll("[\\t\\n\\r]+","<br>"), TA_DETAILS:TA_Details.replaceAll("[\\t\\n\\r]+","<br>"), partnerData: Partner_Data.replaceAll("[\\t\\n\\r]+","<br>"), tokens: Tokens.replaceAll("[\\t\\n\\r]+","<br>"), specialInst: Special_Instructions.replaceAll("[\\t\\n\\r]+","<br>")
				
				emailContent1 += email_test_result()
				emailContent1 += email_test_result_operations()
					
						emailext mimeType: 'text/html',
						subject: "[Jenkins]:${currentBuild.fullDisplayName}:GATEWAY RELEASE NOTES FOR ${params.GATEWAYTYPE} for ${params.RELEASENO} - TL Approval",
						from:"TIL_GATEWAY@vodafone.com",
						to: "${techLeadmails}",
						body: "${emailContent1}"
						
				def TLInput = input( id: 'TLInput', message: 'Do you want to Approve?',
                                            parameters: 
                                            [[$class: 'ChoiceParameterDefinition', defaultValue: 'REJECTED', 
                                            description:'Please provide your approval after validating Defect ID and JIRA NO', name:'choice', choices: "REJECTED\nAPPROVED"],
                                            [$class: 'TextParameterDefinition', defaultValue: '', 
                                            description:'Enter the comments here', name:'Comments']],
                                            submitterParameter: 'submitter',
                                            submitter: "${SITReleaseTechLeadApprovers}"
                                           )
										   
					Apvl_TL_Status = TLInput.choice
                    Apvl_TL_Name = TLInput.submitter
                    Apvl_TL_Date = new Date().format("dd/MM/yyy HH:mm")
                    Apvl_TL_Comments = TLInput.Comments
					
					if(TLInput.Comments.length() != 0)
                    {
                        APPROVAL_COMMENTS = Apvl_TL_Name + "[" + Apvl_TL_Status + ": " + Apvl_TL_Date + "] : " + TLInput.Comments
                    }
					
					if(TLInput.choice == "REJECTED")
					{
						def RN_ins_query = """Update CICD_RELEASES SET STATUS = 'FAILURE' , ENGINE_NAME = ${UpEngine_Name} , LT_ENV = ${DC_ENV} , STAGE_COMPLETED = 'SIT_RN' , ERROR_CODE = '501' , ERROR_DESCRIPTION = 'SIT_RN Stage failure' , LT_APPROVAL = ${Apvl_TL_Name} , SPECIAL_INSTRUCTIONS = ${Special_Instructions} , TA_DETAIL = ${TA_Details} , PARTNER_DATA = ${Partner_Data} , GATEWAY_TOKEN = ${Tokens} WHERE TDD_ID = ${temp_TDD_ID}"""
						
					DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: RN_ins_query
					
						   // RN Rejected by TL mail Rejection
						   email_heading = "GATEWAY SIT Release Notes for ${params.RELEASENO} - Approval Request Rejected"
				
					def emailContent2 = 	get_gateway_sit_release_notes GATEWAY_TYPE: "${params.GATEWAYTYPE}",EMAIL_HEADING:"${email_heading}" , RELEASE: "${params.RELEASENO}", BUILD_REQUESTER: "${params.BUILDREQUESTER}", CRQ: "${params.CHANGE_REF_ID}", ENVIRONMENT: "${DC_ENV}", PROJECT:"${params.PROJECT_NAME}", EngineName:"${UpEngine_Name}", gatewayVersion: "${nextVersion}", Description: "${params.DESCRIPTION}", operation: OPERATION_NAME.replaceAll("[\\t\\n\\r]+","<br>"), TA_DETAILS:TA_Details.replaceAll("[\\t\\n\\r]+","<br>"), partnerData: Partner_Data.replaceAll("[\\t\\n\\r]+","<br>"), tokens: Tokens.replaceAll("[\\t\\n\\r]+","<br>"), specialInst: Special_Instructions.replaceAll("[\\t\\n\\r]+","<br>")
						
				emailContent2 += email_test_result()
				emailContent2 += email_test_result_operations()
				
						emailext mimeType: 'text/html',
						subject: "[Jenkins]:${currentBuild.fullDisplayName}:GATEWAY RELEASE NOTES FOR ${params.GATEWAYTYPE} for ${params.RELEASENO} - TL Approval",
						from:"TIL_GATEWAY@vodafone.com",
						to: "${dev_mailRecipients};${techLeadmails}",
						body: "${emailContent2}"
						
						condition = "RECAPTURE"  
					}
			else
			{
				TL_APPROVAL = "APPROVED"
			}
			}
					// TL Approval Accepted 
					
				email_heading = "GATEWAY SIT RELEASE NOTES for ${params.RELEASENO}"
				
				def emailContent3 = get_gateway_sit_release_notes GATEWAY_TYPE: "${params.GATEWAYTYPE}",EMAIL_HEADING:"${email_heading}" , RELEASE: "${params.RELEASENO}", BUILD_REQUESTER: "${params.BUILDREQUESTER}", CRQ: "${params.CHANGE_REF_ID}", PROJECT:"${params.PROJECT_NAME}",ENVIRONMENT: "${DC_ENV}", EngineName:"${UpEngine_Name}", gatewayVersion: "${nextVersion}", Description: "${params.DESCRIPTION}", operation: OPERATION_NAME.replaceAll("[\\t\\n\\r]+","<br>"), TA_DETAILS:TA_Details.replaceAll("[\\t\\n\\r]+","<br>"), partnerData: Partner_Data.replaceAll("[\\t\\n\\r]+","<br>"), tokens: Tokens.replaceAll("[\\t\\n\\r]+","<br>"), specialInst: Special_Instructions.replaceAll("[\\t\\n\\r]+","<br>")
				
				emailContent3 += email_test_result()
				emailContent3 += email_test_result_operations()
				
				emailext mimeType: 'text/html',
						subject: "[Jenkins]:${currentBuild.fullDisplayName}:GATEWAY RELEASE NOTES FOR ${params.GATEWAYTYPE} for ${params.RELEASENO}",
						from:"TIL_GATEWAY@vodafone.com", 
						to: "${techLeadmails};${dev_mailRecipients};DL-VESTibcoSupport@vodafone.com;vfukintegrationadtil@vodafone.com",
						body: "${emailContent3}"

					def RN_ins_query = """Update CICD_RELEASES SET STATUS= 'SUCCESS' , ENGINE_NAME = ${UpEngine_Name} , LT_ENV = ${DC_ENV} , STAGE_COMPLETED = 'SIT_RN', ERROR_CODE = '200' , ERROR_DESCRIPTION = 'SIT_RN Stage successful' , LT_APPROVAL = ${Apvl_TL_Name} , SPECIAL_INSTRUCTIONS = ${Special_Instructions} , TA_DETAIL = ${TA_Details} , PARTNER_DATA = ${Partner_Data} , GATEWAY_TOKEN = ${Tokens}  WHERE TDD_ID = ${temp_TDD_ID}"""
						
					DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: RN_ins_query
					
					//Promote Artifact to SIT Repository.
					
					build job: 'Gateway_TestDrivenDeployment/GatewayJobs/Gateway_Artefact_Promotion', parameters: [string(name: 'GroupId', value: "${env.GROUPID}"), string(name: 'ArtifactId', value: "${params.GATEWAYTYPE}"), string(name: 'VersionNo', value: "${nextVersion}"), string(name: 'SourceRepo', value: "${LT_REPO}"), string(name: 'DestinationRepo', value: "${SIT_REPO}")]					
					
					//[CICD-727]: Push all the deployment details to Release notes DB.
                    user = "${params.BUILDREQUESTER}"
					
					/*def release_ins_query = """Insert into CICD_RELEASE_SUMMARY_GW (RELEASE_NO,PROJECT_NAME,JIRA_NO,CHANGE_DESCRIPTION,ENGINE_NAME,OPERATION,EAR_VERSION,EMS_VERSION,SQL_VERSION,COMPONENT_TYPE,STATUS,MASTER_GV,PROCESS_GV,ENGINE_TEMPLATE,APPEND_PREPEND,KNOWN_ERROR_INCLUSION,POST_MANUAL_CHANGES,PARTNER_DATA,GATEWAY_TOKEN,SPECIAL_INSTRUCTIONS,LINKTEST_RESULTS,CREATED_ON,GATEWAY_VERSION,GATEWAY_TYPE,CREATED_BY,FILE_CHANGES,TA_DETAILS,APPROVAL,MODIFIED_ON,MODIFIED_BY,RESTART_ENGINES,BUILD_ID,BUILD_URL) values ('${params.RELEASENO}','${params.PROJECT_NAME}','${params.CHANGE_REF_ID}','${params.DESCRIPTION}','${params.ENGINE_NAME}','${params.OPERATION_NAME}','','','','GATEWAY','Active','','','','','','','${params.PARTNER_DATA}','${params.TOKENS}','${params.SPECIAL_INSTRUCTIONS}','PASSED',sysdate,'${nextVersion}','${params.GATEWAYTYPE}','${user}','','${userInput.TA}','${Apvl_TL_Name}','','','','${BUILD_ID}','${BUILD_URL}')"""
	
					println("DEBUG: release notes Insert query is: " + release_ins_query)
					DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: release_ins_query*/
					
                    //[CICD-549] Insert Deployment metadata to deploment history database DB.
 					
					def insert_query = """Insert into CICD_DEPLOYMENT_HISTORY ("Release","DateTime","CRQ","ComponentType","Environment","EngineName","BwVersion","EmsVersion","SqlVersion","GatewayVersion","BwDeploymentType","DeploymentStatus","DeploymentTime","XmlFiles","JarFiles","EmailFiles","RF1Status","RBStatus","RF2Status","DVTStatus","BWConfigTag","ChangeDescription","User","FailureReason","updatedTimestamp","BUILD_ID","BUILD_URL") values ('${params.RELEASENO}',sysdate,'${params.CHANGE_REF_ID}','GATEWAY','${TARGET_Env}','${UpEngine_Name}','','','','${nextVersion}','','Active','','','','','','','','','','${params.Description}','${user}','PASSED',sysdate,'${BUILD_ID}','${BUILD_URL}')"""
		
					DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: insert_query
				
			}
		 }
		}
		stage("Promote to SIT") {
			steps {
				// Approval to move code to SIT
				//input "Promote Change ${CHANGE_REF_ID} to ${SIT_Environment} environment ?"
				script{
					unstash "stashProperties"
					if (nextVersion == " ") {
						nextVersion = sh(script:"cat ./DIR_STASH/propfile | grep -e nextVersion | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						echo "nextVersion after stage restart is:${nextVersion}"
					}
					if (displayName == " ") {
						//[CICD-593]: Checkout required GIT repositories after stage restart.
						preparation_function()
                        
						displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						currentBuild.displayName = "${displayName}_restart"
						echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
					}
					
						emailBody = "${get_body_build_summary(artefactVersion:nextVersion)}"
						echo "emailBody after stage restart is:${emailBody}"
					
					promoteSITApprovers = commonFunctions.get_approvers_list('promoteSITApprovers')
					emailext mimeType: 'text/html',
						 subject: "[Jenkins]${currentBuild.fullDisplayName}:Choose SIT Environment to Deploy",
						 from:"TIL_GATEWAY@vodafone.com",
						 to: "${sit_promote_mailRecipents}",
						 body: 	"${emailBody}" + "<br>" +
								"<br><br><p><b><font size='5' color='Black'>CHOOSE SIT ENVIRONMENT TO DEPLOY: <a href='${BUILD_URL}input'>${currentBuild.displayName}</a></font></b></p>"						 

					def deployOptions = 'T1\nT3\nT4\nT7\nSIT04\nT8\nTILSIT1\nTILSIT2\nTILSIT3\nTILSIT5'
                   			//def deployOptions = 'ABC'
					def userInput = input(
					    id: 'userInput',
						message: 'Can you approve this ??', 
						submitterParameter: 'submitter',
						submitter: "${promoteSITApprovers}",
						parameters: [
									[$class: 'TextParameterDefinition', defaultValue: '0000', description: 'CHANGE REQUEST NUMBER', name: 'CRNum'],
									[$class: 'ChoiceParameterDefinition', choices: deployOptions, description: 'SELECT SIT ENVIRONMNET TO DEPLOY', name: 'SELECT_SIT_ENVIRONMNET_TO_DEPLOY']
							])
					echo (" Selected Environment is:"+userInput['SELECT_SIT_ENVIRONMNET_TO_DEPLOY'])
					SIT_ENV = sh(script: "echo ${userInput['SELECT_SIT_ENVIRONMNET_TO_DEPLOY']}", returnStdout: true).trim()
					//env.SIT_ENV = userInput['SELECT_SIT_ENVIRONMNET_TO_DEPLOY']
					echo ("CR NUMBER: "+userInput['CRNum'])
					echo ("submitted by: "+userInput['submitter'])
					sitPromotedBy = userInput['submitter']
                    //echo ("ENVIRONMENT SELECTED IS:"+userInput['SITENVIRONMENT'])
					//jobs = jobs + userInput['SITENVIRONMENT']
				}								
				echo "Promotion to ${SIT_ENV} is chosen"
				sleep 5
			}
		}
		stage("SIT Notify Partner config Update") {
			when {
				expression { PARTNERCONFIG == "true" }                    
			}			
			steps {
				// When Partner config is selected, send an email to DEV team to approve the partner config changes.
				script {
					unstash "stashProperties"
					if (nextVersion == " ") {
						nextVersion = sh(script:"cat ./DIR_STASH/propfile | grep -e nextVersion | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						echo "nextVersion after stage restart is:${nextVersion}"
					}
					if (displayName == " ") {
						//[CICD-593]: Checkout required GIT repositories after stage restart.
						preparation_function()
                        
						displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						currentBuild.displayName = "${displayName}_restart"
						echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
					}
					
						emailBody = "${get_body_build_summary(artefactVersion:nextVersion)}"
						echo "emailBody after stage restart is:${emailBody}"
					
					promoteSITApprovers = commonFunctions.get_approvers_list('promoteSITApprovers')
					emailext mimeType: 'text/html',
						 subject: "[Jenkins]:${currentBuild.fullDisplayName}:Approval email for Partner Config Check?",
						 from:"TIL_GATEWAY@vodafone.com",
						 to: "${sit_promote_mailRecipents}",
						 body: 	"${emailBody}" + "<br>" + 
								"<br><br><p><b><font size='5' color='Black'>Approve Partner Config changes : <a href='${BUILD_URL}input'>${currentBuild.displayName}</a></font></b></p>"
					def testOptions = 'YES\nNO'
					def userInput = input(
					  id: 'userInput', message: 'Partner Config changes updated and checked-in?',
					  submitterParameter: 'submitter',
					  submitter: "${promoteSITApprovers}"
					)	
				}
			}
		}		
		stage("Deploy to SIT") {
			steps {
				// Deploy to SIT
				script {
					echo "Deploy to ${SIT_ENV} completed"
					unstash "stashProperties"
					if (nextVersion == " ") {
						nextVersion = sh(script:"cat ./DIR_STASH/propfile | grep -e nextVersion | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						echo "nextVersion after stage restart is:${nextVersion}"
					}
					if (displayName == " ") {
						//[CICD-593]: Checkout required GIT repositories after stage restart.
						preparation_function()
                        
						displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						currentBuild.displayName = "${displayName}_restart"
						echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
					}
				
						emailBody = "${get_body_build_summary(artefactVersion:nextVersion)}"
						echo "emailBody after stage restart is:${emailBody}"
					
				}
				build job: 'Gateway_TestDrivenDeployment/GatewayJobs/Gateway_Deployment', parameters: [string(name: 'Environment', value: "${SIT_ENV}"), string(name: 'repo_group_id', value: "${env.GROUPID}"), string(name: 'repo_artifact_id', value: "${params.GATEWAYTYPE}"), string(name: 'repo_user', value: 'admin'), string(name: 'repo_repo_id', value: 'SIT_REPO'), string(name: 'ArtefactVersion', value: "${nextVersion}"), string(name: 'GatewayType', value: "${params.GATEWAYTYPE}")]
				
				// Invoke job to update dashboard
				// Update dashboard with status
				// CICD-573 fix
					build job: '/TIL_PIPELINES/Common_Jobs/Dashboard_Publish', parameters: [string(name: 'Environment', value: "${SIT_ENV}"), string(name: 'Component', value: "${params.GATEWAYTYPE}"), string(name: 'ArtefactVersion', value: "${nextVersion}"), string(name: 'Pipeline', value: "${params.GATEWAYTYPE}_Pipeline"), string(name: 'Description', value: '')]
				
			}	
		}
		stage("Testing in SIT") {
			steps {
				//wait for Testing in SIT
				script {
					unstash "stashProperties"
					if (nextVersion == " ") {
						nextVersion = sh(script:"cat ./DIR_STASH/propfile | grep -e nextVersion | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						echo "nextVersion after stage restart is:${nextVersion}"
					}
					if (displayName == " ") {
						//[CICD-593]: Checkout required GIT repositories after stage restart.
						preparation_function()
                        
						displayName = sh(script:"cat ./DIR_STASH/propfile | grep -e displayName | cut -d ':' -f 2 | tr -d ' ' " ,returnStdout: true).trim()
						currentBuild.displayName = "${displayName}_restart"
						echo "currentBuild.displayName after stage restart is:${currentBuild.displayName}"
					}
					if (emailBody == " ") {
						emailBody = "${get_body_build_summary(artefactVersion:nextVersion)}"
						echo "emailBody after stage restart is:${emailBody}"
					}
				}
				echo "Testing in  ${SIT_ENV} completed"
				//input message: 'Promote change to Prod repositories if SIT Testing is Successful', ok: 'Success'
			}
		}			
		stage('Signoff'){
			steps {
				//Promote artefact to PROD Repo
				script{
					echo "INFO: Deployment is Successful."
					
					//[CICD-1524]: Getting user name for SIT deployment history
					user = currentBuild.rawBuild.causes[0].userId
					
					//[CICD-549] Insert Deployment metadata to deploment history database DB.
					
 					
					def insert_query = """Insert into CICD_DEPLOYMENT_HISTORY ("Release","DateTime","CRQ","ComponentType","Environment","EngineName","BwVersion","EmsVersion","SqlVersion","GatewayVersion","BwDeploymentType","DeploymentStatus","DeploymentTime","XmlFiles","JarFiles","EmailFiles","RF1Status","RBStatus","RF2Status","DVTStatus","BWConfigTag","ChangeDescription","User","FailureReason","updatedTimestamp","BUILD_ID","BUILD_URL") values ('${params.RELEASENO}', sysdate,'${params.CHANGE_REF_ID}','GATEWAY','${SIT_ENV}', '${params.GATEWAYTYPE}','','','','${nextVersion}','','Active','','','','','','','','','','${params.DESCRIPTION}','${user}','PASSED',sysdate,'${BUILD_ID}','${BUILD_URL}')"""
		
					println("DEBUG: Insert query is: " + insert_query)
		
					DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: insert_query					
				}					
			}
		}	

    }
}
