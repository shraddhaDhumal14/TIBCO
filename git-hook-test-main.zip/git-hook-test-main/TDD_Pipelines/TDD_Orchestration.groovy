def errorCodeDecide(error_code, error_desc, pipeline_url)
{
    if(error_code == "")
    {
        echo "No Error Code found"
        send_mail(error_code, error_desc, pipeline_url, devopsmail, "Action Required from ${ERROR_ACTIONEE}")
        return false;
    }
    
    cbuser = currentBuild.rawBuild.causes[0].userId
    sh(script: "line=`grep '${error_code}' CODE/Error_Codes`; echo \$line | awk -F~ '{print \$2}' > errdes; echo \$line | awk -F~ '{print \$3}' > erract; echo \$line | awk -F~ '{print \$4}' > erractne;");
    ERROR_DESC = sh(script: "cat errdes", returnStdout: true).trim()
    ERROR_ACTION = sh(script: "cat erract", returnStdout: true).trim()
    ERROR_ACTIONEE = sh(script: "cat erractne", returnStdout: true).trim()
    
    if(ERROR_ACTION == "Proceed") {
        return true;
    } else if(ERROR_ACTION == "HOLD" && ERROR_ACTIONEE == "Developer"){
        send_mail(error_code, error_desc, pipeline_url, cbuser, "Action Required from ${ERROR_ACTIONEE}")
        return false;
    } else if (ERROR_ACTION == "HOLD" && ERROR_ACTIONEE == "DevOps"){
        send_mail(error_code, error_desc, pipeline_url, devopsmail, "Action Required from ${ERROR_ACTIONEE}")
        return false;
    } else if(ERROR_ACTION == "Restart from Stage" && ERROR_ACTIONEE == "Developer"){
        send_mail(error_code, error_desc, pipeline_url, cbuser, "Action Required from ${ERROR_ACTIONEE}")
        return false;
    } else if (ERROR_ACTION == "Restart from Stage" && ERROR_ACTIONEE == "DevOps"){
        send_mail(error_code, error_desc, pipeline_url, devopsmail, "Action Required from ${ERROR_ACTIONEE}")
        return false;
    } else if(ERROR_ACTION == "Abort" && ERROR_ACTIONEE == "Developer"){
        send_mail(error_code, error_desc, pipeline_url, cbuser, "Action Required from ${ERROR_ACTIONEE}")
       return false;
    } else if(ERROR_ACTION == "Abort" && ERROR_ACTIONEE == "DevOps"){
        send_mail(error_code, error_desc, pipeline_url, devopsmail, "Action Required from ${ERROR_ACTIONEE}")
        return false;
    } else {
        echo "No Error Code found"
        send_mail(error_code, error_desc, pipeline_url, devopsmail, "Action Required from ${ERROR_ACTIONEE}")
        return false;
    } 
}

def send_mail(error_code, error_desc, pipeline_url, emailRecipents, emailSubject)
{
    emailContent="Error Code : ${error_code}<BR> Error Description${error_desc}<BR> Error Pipeline${pipeline_url} <BR> Current Pipeline ${BUILD_URL}"
    
    emailext mimeType: 'text/html', 
    subject: "${emailSubject}",  
    from:"BW_ORCHESTRATOR@vodafone.com", 
    to: "${emailRecipents}", 
    body: "${emailContent}"
}

devopsmail = "devops-vfuk-integration@vodafone.com"
bw_build_pipe = ""
MAP = [:]
pipeline{
agent any
	stages {
        
        stage ('Preparation') {
			steps {
			script {
				
                        MAP['BW'] = ['RELEASE':'', 'TIL_MODULENAME':'', 'TIL_ARCHIVEFILES':'', 'PROJECTNAME':'',  'TIL_TRAVERSION':'', 'BW_VERSION':'', 'BUILD_REQUESTER':'devops-vfuk-integration@vodafone.com', 'JIRA_NUMBER':'', 'JIRA_DESCRIPTION':'', 'SonarQube_Rules_Excluded':'', 'SonarQube_Exclude_Directories_or_Files':'']
                        MAP['DP'] = ['RELEASE':'', 'ENVIRONMENT':'', 'ENGINE_NAME':'', 'BW_VERSION':'',  'ONLY_GV':'', 'EMS_DEPLOYMENT':'', 'SQL_DEPLOYMENT':'', 'FILE_DEPLOYMENT':'', 'DESCRIPTION':'', 'OPERATION_NAME':'','PROJECT_NAME':'', 'ENGINE_TYPE':'']
                }
            }
        }
        
        stage ('BW_BUILD') {
			steps {
				script {
                   println("BW Build")
                   while(1)
                   {
                    checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/main']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "CODE"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/git-hook-test.git']]]    
			
		    sh(script: "line=`tail -1 CODE/BW_BUILD.config`; echo \$line > BW_BUILD.config")
		    MAP['BW']['RELEASE'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$1}'""",returnStdout: true).trim()
		    MAP['BW']['HAS_BW_BUILD'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$2}'""",returnStdout: true).trim()
		    MAP['BW']['TIL_MODULENAME'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$3}'""",returnStdout: true).trim()
		    MAP['BW']['TIL_ARCHIVEFILES'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$4}'""",returnStdout: true).trim()
		    MAP['BW']['PROJECTNAME'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$5}'""",returnStdout: true).trim()
		    MAP['BW']['TIL_TRAVERSION'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$6}'""",returnStdout: true).trim()
		    MAP['BW']['BW_VERSION'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$7}'""",returnStdout: true).trim()
		    MAP['BW']['JIRA_NUMBER'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$8}'""",returnStdout: true).trim()
		    MAP['BW']['JIRA_DESCRIPTION'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$9}'""",returnStdout: true).trim()
		    //MAP['BW']['SonarQube_Rules_Excluded'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$10}'""",returnStdout: true).trim()
		    //MAP['BW']['SonarQube_Exclude_Directories_or_Files'] = sh (script: """cat BW_BUILD.config | awk -F~ '{print \$11}'""",returnStdout: true).trim()
			
	            if(MAP['BW']['HAS_BW_BUILD'] == "true" || MAP['BW']['HAS_BW_BUILD'] == "TRUE")
		    {
			bw_build_pipe = build job: '/TestDrivenDeployment/TDD_BW_BUILD', 
                        parameters: [
                                    string(name: 'RELEASE', value: "${MAP['BW']['RELEASE']}"),
                                    string(name: 'TIL_MODULENAME', value: "${MAP['BW']['TIL_MODULENAME']}"),
                                    string(name: 'TIL_ARCHIVEFILES', value: "${MAP['BW']['TIL_ARCHIVEFILES']}"),
                                    string(name: 'PROJECTNAME', value: "${MAP['BW']['PROJECTNAME']}"),
                                    string(name: 'TIL_TRAVERSION', value: "${MAP['BW']['TIL_TRAVERSION']}"),
                                    string(name: 'BW_VERSION', value: "${MAP['BW']['BW_VERSION']}"),
                                    string(name: 'BUILD_REQUESTER', value: "${MAP['BW']['BUILD_REQUESTER']}"),
                                    string(name: 'JIRA_NUMBER', value: "${MAP['BW']['JIRA_NUMBER']}"),
                                    string(name: 'JIRA_DESCRIPTION', value: "${MAP['BW']['JIRA_DESCRIPTION']}") //,
                                    //string(name: 'SonarQube_Rules_Excluded', value: "${MAP['BW']['SonarQube_Rules_Excluded']}"),
                                    //string(name: 'SonarQube_Exclude_Directories_or_Files', value: "${MAP['BW']['SonarQube_Exclude_Directories_or_Files']}")
                                ], propagate:false
                        
                        println(bw_build_pipe.result + " : ${bw_build_pipe.buildVariables.BP_ERROR_CODE}")
                        }
			else
			{
				println("Skipping BW Build")
				break;
			}
			
                        if("${bw_build_pipe.buildVariables.BP_ERROR_CODE}".equals("200"))
                        {
                              println("BW Build Success")
                              break;
                        }
                        else
                        {
                              println("BW Build Failure Detected")
                              println("${bw_build_pipe.buildVariables.BP_ERROR_CODE}")
                              println("${bw_build_pipe.buildVariables.BP_ERROR_MSG}")
                              error_decision = errorCodeDecide(bw_build_pipe.buildVariables.BP_ERROR_CODE, bw_build_pipe.buildVariables.BP_ERROR_MSG, bw_build_pipe.buildVariables.PIPELINE_URL)
                              if(error_decision)
                              {
                                  break;
                              }
                              else
                              {
                                      SUBMITTED_USER = currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId()
                                      def devInput = input( id: 'devInput', message: 'Please check mail and approve if OK.', submitterParameter: 'submitter', submitter: "${SUBMITTED_USER}")
                              }
                        }
                   }//while
                   
                }
			}
		}
        
		stage ('BW_EMS_SQL') {
            when {
			     expression { ((MAP['BW']['HAS_BW_BUILD'] == "true" || MAP['BW']['HAS_BW_BUILD'] == "TRUE") && bw_build_pipe.result == "SUCCESS" && bw_build_pipe.buildVariables.BP_ERROR_CODE.equals("200")) || 
			     			(MAP['BW']['HAS_BW_BUILD'] == "false" || MAP['BW']['HAS_BW_BUILD'] == "FALSE") }
			    }
			steps {
				script {
                    
                   println("Deployment Pipeline")
                   while(1)
                   {
                    
		    //Deleting the existing downloaded code. In case of new config updates
		    sh "rm -Rf CODE/"
		    checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/main']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "CODE"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/git-hook-test.git']]]
			
		    sh(script: "line=`tail -1 CODE/DEPLOY_BUILD.config`; echo \$line > DEPLOY_BUILD.config")
                    MAP['DP']['RELEASE'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$1}'""",returnStdout: true).trim()
                    MAP['DP']['ENVIRONMENT'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$2}'""",returnStdout: true).trim()
                    MAP['DP']['ENGINE_NAME'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$3}'""",returnStdout: true).trim()
                    if(MAP['BW']['HAS_BW_BUILD'] == "false" || MAP['BW']['HAS_BW_BUILD'] == "FALSE")
		    	MAP['DP']['BW_VERSION'] = ""
	            else
		    	MAP['DP']['BW_VERSION'] = bw_build_pipe.buildVariables.BW_VERSION
                    MAP['DP']['ONLY_GV'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$5}'""",returnStdout: true).trim()
                    MAP['DP']['EMS_DEPLOYMENT'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$6}'""",returnStdout: true).trim()
                    MAP['DP']['SQL_DEPLOYMENT'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$7}'""",returnStdout: true).trim()
                    MAP['DP']['FILE_DEPLOYMENT'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$8}'""",returnStdout: true).trim()
                    MAP['DP']['DESCRIPTION'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$9}'""",returnStdout: true).trim()
                    MAP['DP']['OPERATION_NAME'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$10}'""",returnStdout: true).trim()
                    MAP['DP']['PROJECT_NAME'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$11}'""",returnStdout: true).trim()
                    MAP['DP']['ENGINE_TYPE'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$12}'""",returnStdout: true).trim()
                    MAP['DP']['CHANGE_REF_ID'] = sh (script: """cat DEPLOY_BUILD.config | awk -F~ '{print \$13}'""",returnStdout: true).trim()
			
			
			deploy_pipe = build job: '/TestDrivenDeployment/TDD_BW_DEPLOYMENT', 
                    	parameters: [
                                    string(name: 'RELEASE', value: "${MAP['DP']['RELEASE']}"),
                                    string(name: 'ENVIRONMENT', value: "${MAP['DP']['ENVIRONMENT']}"),
                                    string(name: 'ENGINE_NAME', value: "${MAP['DP']['ENGINE_NAME']}"),
                                    string(name: 'BW_VERSION', value: "${MAP['DP']['BW_VERSION']}"),
                                    booleanParam(name: 'ONLY_GV', value: "${MAP['DP']['ONLY_GV']}"),
                                    booleanParam(name: 'EMS_DEPLOYMENT', value: "${MAP['DP']['EMS_DEPLOYMENT']}"),
                                    booleanParam(name: 'SQL_DEPLOYMENT', value: "${MAP['DP']['SQL_DEPLOYMENT']}"),
                                    string(name: 'FILE_DEPLOYMENT', value: "${MAP['DP']['FILE_DEPLOYMENT']}"),
                                    string(name: 'DESCRIPTION', value: "${MAP['DP']['DESCRIPTION']}"),
                                    string(name: 'OPERATION_NAME', value: "${MAP['DP']['OPERATION_NAME']}"),
                                    string(name: 'PROJECT_NAME', value: "${MAP['DP']['PROJECT_NAME']}"),
                                    string(name: 'ENGINE_TYPE', value: "${MAP['DP']['ENGINE_TYPE']}"),
                                    string(name: 'CHANGE_REF_ID', value: "${MAP['DP']['CHANGE_REF_ID']}")
                                ], propagate:false 
                        
                        println(deploy_pipe.result + " : ${deploy_pipe.buildVariables.DP_ERROR_CODE}")
                        
                        if("${deploy_pipe.buildVariables.DP_ERROR_CODE}".equals("200"))
                        {
                              println("Deployment Pipeline Success")
                              break;
                        }
                        else
                        {
                              println("Deployment Pipeline Failure Detected")
                              println("${deploy_pipe.buildVariables.DP_ERROR_CODE}")
                              println("${deploy_pipe.buildVariables.DP_ERROR_MSG}")
                              error_decision = errorCodeDecide(deploy_pipe.buildVariables.DP_ERROR_CODE, deploy_pipe.buildVariables.DP_ERROR_MSG, deploy_pipe.buildVariables.PIPELINE_URL)
                              if(error_decision)
                              {
                                  break;
                              }
                              else
                              {
                                      SUBMITTED_USER = currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId()
                                      def devInput = input( id: 'devInput', message: 'Please check mail and approve if OK.', submitterParameter: 'submitter', submitter: "${SUBMITTED_USER}")
                              }
                        }
                   }//while                    
                }
			}
		}
     }
}
