// Global Parameters to use in the stages.
date_now = new Date().format( 'dd-MM-yyyy' )

//[CICD-507] Insert Deployment metadata to TIL_BUILD_HISTORY DB.
import com.cwctravel.hudson.plugins.extended_choice_parameter.ExtendedChoiceParameterDefinition
import hudson.tasks.Mailer
import hudson.model.User
import groovy.json.JsonOutput
import groovy.sql.*
import java.sql.Driver
import groovy.time.*
import jenkins.model.Jenkins

def dbInsertOrUpdate(deployParams)
{
    int retryCount = 0;
    def error = ""
    while (1) 
    {
       if( retryCount > 0 && retryCount % 3 ==0 )
       {
        input 'Proceed or Abort?'      
       }
       try 
	   {
            mySQL =  myGetDBConnect dbURL: deployParams.dbURL, dbUserName: deployParams.dbUserName, dbPassword: deployParams.dbPassword, dbDriver: deployParams.dbDriver
            mySQL.connection.autoCommit = false
            println("Executing Query :" + deployParams.insertQuery)
            int rowAffected = mySQL.executeUpdate(deployParams.insertQuery);
            mySQL.commit()
            mySQL.close()
            mySQL = null
            println("Insert/Update " + rowAffected + " row(s)")
            env.BP_ERROR_CODE = ""
			env.BP_ERROR_MSG = ""
            return true
        }
       catch(Exception ex) 
	   {
            println("Error in Executing Query :" + deployParams.insertQuery) 
            mySQL.rollback()
            mySQL.close()
            mySQL = null
			env.BP_ERROR_CODE = "206"
			env.BP_ERROR_MSG = "DB connection failed ++ ${deployParams.insertQuery} "
			//insert_errorcode('000002', '206')
			println(env.BP_ERROR_CODE + " : " +  env.BP_ERROR_MSG)
			error("DB insert failed.")
			currentBuild.result = 'ABORTED'
			
            sleep 5            
        }
        retryCount++
    }     
    return false       
}

def myGetDBConnect(deployParams) 
{     
     def mySQL = groovy.sql.Sql.newInstance(deployParams.dbURL,deployParams.dbUserName,deployParams.dbPassword,deployParams.dbDriver)
     return mySQL
}

def GitClone(RepoName, TargetDirectory, BranchName )
{
    int retryCount = 0;
    def error = ""
    while (1) 
    {
       if( retryCount > 0 && retryCount % 3 ==0 )
       {
        input 'Proceed or Abort?'      
       }
       try 
	   {
            
            checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: "*/${BranchName}"]], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${TargetDirectory}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: "https://github.vodafone.com/VFUK-INTEGRATION/${RepoName}.git"]]]
            env.BP_ERROR_CODE = ""
			env.BP_ERROR_MSG = ""
            return true
       }
       catch(Exception ex) 
	   {
		    env.BP_ERROR_CODE = "203"
			env.BP_ERROR_MSG = "Github connection failed"
			println(env.BP_ERROR_CODE + " : " +  env.BP_ERROR_MSG)
			println("Github connection failed.")
			currentBuild.result = 'ABORTED'
			
            //println("Exception caught : " + ex + "while downloading Repo " +  RepoName); 
            //error = ex;
            //println("Sleeping for 5 seconds .... Will Retry "+ (retryCount+1))
            //println "Red Alert!! Inform CICD Team ++ Git Error ++ ${error}"
            sleep 5            
        }
        retryCount++
    }     
    return false       
}

def checkout_git_repositories()
{

    GitClone("TIL_Automation_Framework", "TIL_AUTOMATION", "master")
    GitClone("TIL_DevOps_Framework", "JENKINS_FILE", "master")
    GitClone("${env.TIL_TYPE}_${TIL_MODULENAME}", "TIL_SOURCE_SonarQube", "${params.RELEASE}")
    GitClone("TIL_Devops_Java_Automation", "JAVA_SOURCE", "main")
}

def validate_parameter()
{
    def validationCheck = ""
    if (JIRA_NUMBER.indexOf(' ') != -1)
	{
	          println('Parameter validation failed.JIRA_NUMBER should not contain space in between.')
              validationCheck = "F"
	}
                        
    if (TIL_ARCHIVEFILES == "")
	{
             println('TIL_ARCHIVEFILES need to be specified for the build. It must be in config File')
             validationCheck = "F"
    }
    
    if (TIL_TRAVERSION == "")
	{						   
             println('TIL_TRAVERSION need to be specified for the build. It must be in config File')
             validationCheck = "F"
    }
    
    if (BW_VERSION == "")
	{						   
             println('BW_VERSION need to be specified for the build. It must be in config File')
             validationCheck = "F"
    }
    
    if (TIL_MODULENAME == "")
	{
           println('TIL_MODULENAME should be specified for the build')
           validationCheck = "F"
    }
    
    if (! BUILD_REQUESTER.matches('^[a-zA-Z0-9._%+-]+@vodafone.com$'))
	{
           println('Please enter Valid email ID for Build Requester')
           validationCheck = "F"
    }
    
    if (JIRA_DESCRIPTION == "")
	{
           println('JIRA_DESCRIPTION should be specified ')
           validationCheck = "F"
    }
	
    if (FEATURE_BRANCH == "")
	{
           println('FEATURE_BRANCH should be specified ')
           validationCheck = "F"
    }
    
    if(validationCheck == "F")
	{
			env.BP_ERROR_CODE = "500"
            env.BP_ERROR_MSG = "Pipeline Input parameter validation failed "
            //insert_errorcode('000002', '500')
			println(env.BP_ERROR_CODE + " : " +  env.BP_ERROR_MSG)
			error("Pipeline Input parameter validation failed. Please check the errors in Console log.")
			currentBuild.result = 'ABORTED'
    }
                        
}

def NexusUpload(artifactId, artifactfile, artifactfiletype, artifactGroup, artifactRepo, artifactVersion)
{                  
    int retryCount = 0;
    def nexusUrl = "195.233.197.150:8081"
    def error = ""
    def objURL 
    while (1) 
    {
        if( retryCount > 0 && retryCount % 3 ==0 )
        {
            input 'Proceed or Abort?'      
        }
        try 
		{ 
		    objURL = new URL("http://${nexusUrl}").getText()
            nexusArtifactUploader artifacts: [[artifactId: "${artifactId}", classifier: '', file: "${artifactfile}", type: "${artifactfiletype}"]], credentialsId: '74edde97-94e0-403c-93f6-cad6c46c45f8', groupId: "${artifactGroup}", nexusUrl: "${nexusUrl}", nexusVersion: 'nexus3', protocol: 'http', repository: "${artifactRepo}", version: "${artifactVersion}"
            env.BP_ERROR_CODE = ""
			env.BP_ERROR_MSG = ""
		    return true
        }
        catch(Exception ex) 
		{
			env.BP_ERROR_CODE = "205"
			env.BP_ERROR_MSG = "NEXUS connection failed"
			//insert_errorcode('000002', '205')
			println(env.BP_ERROR_CODE + " : " +  env.BP_ERROR_MSG)										
            println("Exception caught : " + ex); 
            println("Sleeping for 5 seconds .... Will Retry "+ (retryCount+1))
            println "Red Alert!! Inform CICD Team ++ Nexus Error ++ ${ex} ++ ${error} "
            objURL = null
            sleep 5    
            retryCount++                    
        } 
    }  
    return false       
}


def preparation_function()
{
		def releaseparamCheck = ""
		String regex = /(^CCS\d+\.\d+_[a-zA-Z0-9]+$)|(^CCS\d+\.\d+$)/
		if(RELEASE == ""){

			env.BP_ERROR_CODE = "500"
			env.BP_ERROR_MSG = "RELEASE is mandatory for BW BUILD Pipeline "
			releaseparamCheck = "False"
		} else if(RELEASE.indexOf(' ') != -1){

			env.BP_ERROR_CODE = "500"
			env.BP_ERROR_MSG = "RELEASE parameter should not contain spaces in between "
			releaseparamCheck = "False"
		} else if (!(RELEASE ==~ regex)){

			env.BP_ERROR_CODE = "500"
			env.BP_ERROR_MSG = "RELEASE parameter is not in standard format. Please input either in CCS20.12 or CCS20.12_x format "
			releaseparamCheck = "False"
		}
	//	if (JIRA_NUMBER.indexOf(' ') != -1){
	//		env.BP_ERROR_CODE = "500"
	//		env.BP_ERROR_MSG = "Parameter validation failed. JIRA_NUMBER should not contain space in between."
	//		releaseparamCheck = "False"
	//	}
		if(releaseparamCheck == "False")
		{
			env.BP_ERROR_CODE = "500"
			env.BP_ERROR_MSG = "Pipeline Input parameter validation failed. " +  env.BP_ERROR_CODE
			println(env.BP_ERROR_CODE + " : " +  env.BP_ERROR_MSG)
			error("Pipeline Input parameter validation failed. Please check the errors in Console log.")
			currentBuild.result = 'ABORTED'
		}
		
		DEV_TAG = RELEASE.split('CCS')[1] + '_DEV_' + "${get_build_num()}"
		currentBuild.displayName = "${DEV_TAG}"
						
		cleanWs disableDeferredWipeout: true, deleteDirs: true
						// checking out framework automation scripts
		checkout_git_repositories()
		                        

		validate_parameter()
		
		user = params.BUILD_REQUESTER
//		checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'JENKINS_FILE']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_DevOps_Framework.git']]])
						
//		checkout([$class: 'GitSCM', branches: [[name: "${params.FEATURE_BRANCH}"]], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: './TIL_SOURCE_SonarQube']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: "https://github.vodafone.com/VFUK-INTEGRATION/${env.TIL_TYPE}_${TIL_MODULENAME}.git"]]])
    
		DB_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/dbFunctions.groovy" 
		
		emailFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/UserFunctions.groovy"
		
		buildRequestorMail = params.BUILD_REQUESTER
		DevopsUsers = emailFunctions.get_approvers_list('DevOpsUsers')
        bw_mailRecipients = emailFunctions.get_approvers_email_list(DevopsUsers); 
		DEVLeads = emailFunctions.get_approvers_list('DEVLeads')
		bw_mailRecipients += "," + emailFunctions.get_approvers_email_list(DEVLeads) + "," + buildRequestorMail;
}

// This function is to print the build summary in email Body
def print_buildSummary() {
		
		def buildSummary = readFile "${BUILD_HISTORY_PATH}/${DEV_TAG}/DEV_${DEV_TAG}"
		buildSummary = buildSummary.replaceAll("\r\n|\n\r|\n|\r","<br/>")
		return buildSummary
}

def print_diff_url() {
		def urlString = earDiff_url.join("<br>")
		return urlString
}

def print_prod_diff_url() {
		def prod_urlString = prod_earDiff_url.join("<br>")
		return prod_urlString
}
def print_SonarQube_Report_url() {
		def Sonar_urlString = SonarQube_Report_url.join("<br>")
		return Sonar_urlString
}

def get_build_num(){
	//This method returns the build number based on the previous build number for corresponding release.
	//String jobName = System.getenv('JOB_NAME')
	println (job_name)
	def seq_no
	def max_search_builds=500
	def count=0	
	def job = jenkins.model.Jenkins.instance.getItemByFullName(job_name)
	for (def build : job.builds){
		count = count.toInteger() + 1
		if(count.toInteger() >= max_search_builds.toInteger()) {
			break;
		}		
		if (build.displayName.contains("${params.RELEASE}".split('CCS')[1].trim())){
			//println build.properties.environment.BUILD_NUMBER.toString()
			if (build.displayName.contains('_DEV_')){
				if(build.displayName.split('_DEV_')[1].isInteger()) { 
					seq_no = build.displayName.split('_DEV_')[1]
				} else {
					seq_no = build.displayName.split('_')[2]
				}
				if(seq_no.isInteger()){
				    seq_no = seq_no.toInteger() + 1
					//seq_no += 1
					return seq_no
					break;
				}
			}
		}	
	}
	if (seq_no == null || !seq_no.isInteger()){
		seq_no = 1
		return seq_no
	}
}


// SonarQube Execution and Properties file Modification.
def Sonar_exe() {

	
	sh "cp -r ./TIL_AUTOMATION/SonarQube/sonar-project.properties ./TIL_SOURCE_SonarQube"
	sh "mkdir ./Reports"
	sh "sed -i 's#sonar.report.path=.*#sonar.report.path=${WORKSPACE}/Reports#' ./TIL_SOURCE_SonarQube/sonar-project.properties"
	sh "sed -i 's#sonar.projectKey=.*#sonar.projectKey=${TIL_TYPE}_${TIL_MODULENAME}#' ./TIL_SOURCE_SonarQube/sonar-project.properties"
	sh "sed -i 's#sonar.projectName=.*#sonar.projectName=${TIL_TYPE}_${TIL_MODULENAME}#' ./TIL_SOURCE_SonarQube/sonar-project.properties"
	sh "sed -i 's#sonar.branch.target.name=.*#sonar.branch.target.name= ${FEATURE_BRANCH}#' ./TIL_SOURCE_SonarQube/sonar-project.properties"
	
	 script 
	{
        
        SonarQube_Rules_Excluded = sh (script: """grep '${TIL_MODULENAME}~' ./TIL_AUTOMATION/SonarQube/SonarQube_Rules_Excluded.txt | cut -f2 -d '~'""",returnStdout: true).trim()
        SonarQube_Exclude_Directories_or_Files = sh (script: """grep '${TIL_MODULENAME}~' ./TIL_AUTOMATION/SonarQube/SonarQube_Exclude_Directories_or_Files.txt | cut -f2 -d '~'""",returnStdout: true).trim()
		
	if (SonarQube_Rules_Excluded.length() !=0)
	{
		sh "sed -i 's#sonar.exclusions.rules=.*#sonar.exclusions.rules=${SonarQube_Rules_Excluded}#' ./TIL_SOURCE_SonarQube/sonar-project.properties"
	}
	
	if (SonarQube_Exclude_Directories_or_Files.length() !=0) 
	{
		sh "sed -i 's#sonar.exclusions=.*#sonar.exclusions=**/Interface/*,**/Interface/**/*,**/defaultVars/defaultVars.substvar,${SonarQube_Exclude_Directories_or_Files}#' ./TIL_SOURCE_SonarQube/sonar-project.properties"
	}
	
	}
	
	sh "sed -i 's#sonar.bw5.overriderules.file =.*#sonar.bw5.overriderules.file = ${WORKSPACE}/TIL_AUTOMATION/SonarQube/OverrideRules.xml#' ${SonarQube_Home}/conf/sonar.properties"
	sh "export SONAR_HOME=${SonarQube_Home} && ${SonarScanner_Home}/bin/sonar-scanner -D'sonar.log.console=true' -D'sonar.projectBaseDir=./TIL_SOURCE_SonarQube' > ./Sonar_Exe.out"
	sh "cp -r ./Reports/${TIL_TYPE}_${TIL_MODULENAME}*.xlsx ${WORKSPACE}/${TIL_TYPE}_${TIL_MODULENAME}.xlsx"
	sh "cat ./Sonar_Exe.out"
	SONAR_STATUS = "SUCCESS"
}




def get_body_build_summary(){
	
	def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
		.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		</style>
		<table class="tg" style="undefined;table-layout: fixed; width: 1200px">
		<colgroup>
		<col style="width: 100px">
		<col style="width: 500px">
		<col style="width: 100px">
		<col style="width: 500px">
		</colgroup>
		  <tr>
			<th class="tg-amwm" colspan="4">TIL BUILD SUMMARY</th>
		  </tr>
		  <tr>
			<td class="tg-1wig">Submitted By</td>
			<td class="tg-0lax">${user}</td>
			<td class="tg-1wig">Date</td>
			<td class="tg-0lax">${date_now}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">FEATURE BRANCH</td>
			<td class="tg-0lax">${env.FEATURE_BRANCH}</td>
			<td class="tg-1wig">IRIS NUMBER</td>
			<td class="tg-0lax">${env.JIRA_NUMBER}</td>
		  </tr>
		  <tr>	
			<td class="tg-1wig">SonarQube_Result</td>
			<td class="tg-0lax" colspan="3">${Status}</td>
		  </tr>
		   <tr>	
			 <td class="tg-1wig">SonarQube Rules Excluded</td>
			 <td class="tg-0lax" colspan="3">${SonarQube_Rules_Excluded}</td>
		   </tr>
		   <tr>	
		     <td class="tg-1wig">SonarQube Exclude Directories or Files</td>
			 <td class="tg-0lax" colspan="3">${SonarQube_Exclude_Directories_or_Files}</td>
		   </tr>
		  <tr>
			<td class="tg-1wig">BUILD_URL</td>
			<td class="tg-0lax" colspan="3">${BUILD_URL}</td>
		  </tr>
		  <tr>
		</table>
		<br><br><br>
		<table class="tg" style="undefined;table-layout: fixed; width: 1200px">
		<colgroup>
		<col style="width: 100px">
		<col style="width: 500px">
		<col style="width: 100px">
		<col style="width: 500px">
		</colgroup>
		  <tr>
			<td class="tg-1wig">BW BUILD SUMMARY</td>
			<td class="tg-0lax" colspan="3">${print_buildSummary()}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">LOG_URL</td>
			<td class="tg-0lax" colspan="3">${BUILD_URL}/console</td>
		  </tr> 
		  <tr>
			<td class="tg-1wig">EAR_DIFF_URL's</td>
			<td class="tg-0lax" colspan="3">${print_diff_url()}</td>
		  </tr> 
		  <tr>
			<td class="tg-1wig">PROD_EAR_DIFF_URL's</td>
			<td class="tg-0lax" colspan="3">${print_prod_diff_url()}</td>
		  </tr>
		   <tr>
			<td class="tg-1wig">SonarQube_Report_URL's</td>
			<td class="tg-0lax" colspan="3">${print_SonarQube_Report_url()}</td>
		  </tr>
		</table>
	"""
	return body_build_summary
}
DEV_TAG = " "
FINAL_VERSION = " "
CHANGE_STRING= " "
String[] COMMON_ENGINES_LIST = []
REPORT_PATH="/opt/tibco/DevOps_Reporting/Report/DevOps_report.txt"
//[CICD-507] Insert Deployment metadata to TIL_BUILD_HISTORY DB.
SONAR_STATUS=""
user = ""
til_build_status = ""

pipeline {
	agent any
	options {
        	timeout(time: 5, unit: 'DAYS')
	}
	environment {
		BUILD_HISTORY_PATH = "${WORKSPACE}/../BUILD_HISTORY"
		ENG_VERSIONS = " "
		NEXUS_URL="195.233.197.150:8081"
		DEV_REPO="DEV_REPO"
		LT_REPO="LINKTEST_REPO"
		SIT_REPO="SIT_REPO"
		PROD_REPO="PROD_REPO"
		TIL_GROUPID="TIL_BW"
		EMS_GROUPID="TIL_EMS_SQL"
		EMS_ARTIFACTID="EMS"		
		NEXUS_VERSION="nexus3"
		NEXUS_USERNAME="admin"
		NEXUS_PASSWORD="admin123"
		TIL_TYPE="TIL"
		bw_mailRecipients=""
		
		// Sonarqube
		Status = "Failed"
		SonarQube_Home = "/opt/tibco/devops/sonarqube/sonarqube-8.6.1.40680"
		SonarScanner_Home = "/opt/tibco/devops/sonarqube/sonar-scanner-4.5.0.2216-linux"
        
        //[CICD-507] Insert Deployment metadata to TIL_BUILD_HISTORY DB.
        dbURL = 'jdbc:oracle:thin:@195.233.199.13:33000:TIBTST1'
		dbUserName = 'CICD_OWN_DB01'
		dbPassword = 'TIL_CICD_DB'
		dbDriver = 'oracle.jdbc.driver.OracleDriver'
	}
	stages {
		stage('Preparation') {
			steps {
                script {
						
 					env.PIPELINE_URL = "$BUILD_URL"
					preparation_function()
				    echo "Preparation is done"
                }

			}
		}
		
		stage('SonarQube Execution') {
			steps {				
				script{
											
					Sonar_exe()
					 
					//echo "Sonar Execution Completed"
					if(fileExists("${WORKSPACE}/Sonar_Exe.out")) {

						def Content = sh "grep 'EXECUTION' Sonar_Exe.out"
												
							if(Content.equals("INFO: EXECUTION FAILURE")) {
							
								Status = "EXECUTION FAILURE"
							}else {
								Status = "EXECUTION SUCCESS"
							}
												
				    }               
				}						
			}
		}
		
   		stage('BW_Build') {
			when 
		{
			expression { SONAR_STATUS == "SUCCESS" }
		}
			steps {
				//build job: 'TIL/BW/BW_Build'
				script{
						
					def comEngines = sh(script:"cat ./TIL_AUTOMATION/TIL_Build/Common_Engines_List | grep ${TIL_ARCHIVEFILES} || exit 0", returnStdout: true).trim()
					echo "DEBUG: comEngines value is: ${comEngines}"
					if (comEngines != null && !comEngines.isEmpty()) {
						// Get the related engines list if it matches .
						COMMON_ENGINES_LIST = "${comEngines}".split("\n");
					} else {
						//
						COMMON_ENGINES_LIST = "${TIL_ARCHIVEFILES}".split(";");
					}
					
					// exceptions in the common engines list are hard coded as below , since there is no specific format to get.
					
					if(TIL_ARCHIVEFILES == "ServiceExposure-Scheduled" || TIL_ARCHIVEFILES == "ServiceExposure-NonScheduled" ) {
						COMMON_ENGINES_LIST = "ServiceExposure-NonScheduled, ServiceExposure-Scheduled".split(", "); 
					}
					
					if(TIL_ARCHIVEFILES == "ProvisioningAndFulfilment-MNP-FT-MVNO-TALKMOBILE" || TIL_ARCHIVEFILES == "ProvisioningAndFulfilment-MNP-FT-Postpay-VF-CONSUMER-1" || TIL_ARCHIVEFILES == "ProvisioningAndFulfilment-MNP-FT-Postpay-VF-Corp" ) {
						COMMON_ENGINES_LIST = "ProvisioningAndFulfilment-MNP-FT-MVNO-TALKMOBILE, ProvisioningAndFulfilment-MNP-FT-Postpay-VF-CONSUMER-1, ProvisioningAndFulfilment-MNP-FT-Postpay-VF-Corp".split(", ");
					}
					
					if(TIL_ARCHIVEFILES == "RiskAndCreditManagement-Gemini" || TIL_ARCHIVEFILES == "My191-CheckServiceEligibility" ) {
						COMMON_ENGINES_LIST = "RiskAndCreditManagement-Gemini, My191-CheckServiceEligibility".split(", "); 
					}
					
					echo "common engines list: ${COMMON_ENGINES_LIST}"
					COMMON_ENGINES_STRING = COMMON_ENGINES_LIST.join(", ")
					
					// calling BW_Build job - output will be copying ear, diff files and changelog  files to common location 
					bw_pipe = build job: '/TestDrivenDeployment/TDD_BW_DEV_BUILD', parameters: [string(name: 'TIL_TYPE', value: "${env.TIL_TYPE}"), string(name: 'PROJECTNAME', value: "${params.PROJECTNAME}"), string(name: 'TIL_ARCHIVEFILE', value: "${params.TIL_ARCHIVEFILES}"), string(name: 'TIL_TRAVERSION', value: "${params.TIL_TRAVERSION}"), string(name: 'DEV_TAG', value: "${DEV_TAG}"), string(name: 'BUILD_REQUESTER', value: "${params.BUILD_REQUESTER}"), string(name: 'RELEASE', value: "${RELEASE}"), string(name: 'FEATURE_BRANCH', value: "${params.FEATURE_BRANCH}"), string(name: 'NEXUS_URL', value: "${env.NEXUS_URL}"), string(name: 'LT_REPO', value: "${env.DEV_REPO}"), string(name: 'SIT_REPO', value: "${env.SIT_REPO}"), string(name: 'TIL_GROUPID', value: "${env.TIL_GROUPID}"), string(name: 'NEXUS_VERSION', value: "${env.NEXUS_VERSION}"), string(name: 'NEXUS_USERNAME', value: "${env.NEXUS_USERNAME}"), string(name: 'BW_VERSION', value: "${params.BW_VERSION}"), string(name: 'NEXUS_PASSWORD', value: "${env.NEXUS_PASSWORD}"), string(name: 'IRIS_NUMBER', value: "${params.JIRA_NUMBER}"), string(name: 'IRIS_DESCRIPTION', value: "${params.JIRA_DESCRIPTION}"), string(name: 'MODIFIED_FILES', value: "${params.MODIFIED_FILES}"), string(name: 'DELETED_FILES', value: "${params.DELETED_FILES}"), string(name: 'DEFECT_NUMBER', value: "${params.DEFECT_NUMBER}"), string(name: 'TIL_MODULE', value: "${params.TIL_MODULENAME}"), string(name: 'COMMON_ENGINES', value: "${COMMON_ENGINES_STRING}"), string(name: 'PIPELINE_WORKSPACE', value: "${env.WORKSPACE}")]
					
					
					if ( bw_pipe.result == "SUCCESS" )
					{	
						//pushing new version ears from common location to Nexus Repository
						script{
							String[] engineNames = "${TIL_ARCHIVEFILES}".split(";");
							earDiff_url = []
							prod_earDiff_url = []
							SonarQube_Report_url = []
							engine = "${TIL_ARCHIVEFILES}"
							for (String engine_common: COMMON_ENGINES_LIST) {
								echo "engine name is: ${engine_common}"
								//sh label: '', script: 'cat ${BUILD_HISTORY_PATH}/BUILD_${JIRA_NUMBER}_PROPERTIES | grep "til.${engine}.nextver" | cut -d \' \' -f 2 | tr -d \' \''
								def cv = sh(script:"cat ${BUILD_HISTORY_PATH}/${DEV_TAG}/BUILD_${DEV_TAG}_PROPERTIES | grep til.${engine}.nextver | cut -d \' \' -f 2 | tr -d \' \'", returnStdout: true).trim()
								echo "CV value is:${cv}"
								FINAL_VERSION = "${cv}"
								ENG_VERSIONS = ENG_VERSIONS.trim().concat("${engine}:${cv};")

								NexusUpload("${engine_common}", "${BUILD_HISTORY_PATH}/${DEV_TAG}/${engine}-${cv}.ear","ear","${TIL_GROUPID}", "${DEV_REPO}", "${cv}")

								NexusUpload("${engine_common}", "${BUILD_HISTORY_PATH}/${DEV_TAG}/${engine}-${cv}_diff","html","${TIL_GROUPID}", "${DEV_REPO}", "${cv}")
								
								NexusUpload("${engine_common}", "${BUILD_HISTORY_PATH}/${DEV_TAG}/DEV_${DEV_TAG}","txt","${TIL_GROUPID}", "${DEV_REPO}", "${cv}")
								
								NexusUpload("${engine_common}", "${BUILD_HISTORY_PATH}/${DEV_TAG}/${engine}-${cv}-PROD_diff","proddiff","${TIL_GROUPID}", "${DEV_REPO}", "${cv}")
								
								// upload pom file for each of the engine.
								NexusUpload("${engine_common}", "${BUILD_HISTORY_PATH}/${DEV_TAG}/${engine}.pom","pom","${TIL_GROUPID}", "${DEV_REPO}", "${cv}")
								
								// upload validation EAR Validation log file for each of the engine.
								NexusUpload("${engine_common}", "${BUILD_HISTORY_PATH}/${DEV_TAG}/Validation.log","ear_validation_log","${TIL_GROUPID}", "${DEV_REPO}", "${cv}")
								
								// upload Sonarqube Report file for each of the engine.
								NexusUpload("${engine_common}", "${WORKSPACE}/${TIL_TYPE}_${TIL_MODULENAME}.xlsx","xlsx","${TIL_GROUPID}", "${DEV_REPO}", "${cv}")
								
								// Upload appconf file to Nexus for each engine.
								NexusUpload("${engine_common}", "${BUILD_HISTORY_PATH}/${DEV_TAG}/${engine_common}.appconf","appconf","${TIL_GROUPID}", "${DEV_REPO}", "${cv}")
								// get the ear diff urls in nexus repository
								diff_url = "http://${NEXUS_URL}/repository/${DEV_REPO}/${TIL_GROUPID}/${engine_common}/${cv}/${engine_common}-${cv}.html"
								earDiff_url.push("${diff_url}")
								prod_diff_url = "http://${NEXUS_URL}/repository/${DEV_REPO}/${TIL_GROUPID}/${engine_common}/${cv}/${engine_common}-${cv}.proddiff"
								prod_earDiff_url.push("${prod_diff_url}")
								SonarQube_url = "http://${NEXUS_URL}/repository/${DEV_REPO}/${TIL_GROUPID}/${engine_common}/${cv}/${engine_common}-${cv}.xlsx"
								SonarQube_Report_url.push("${SonarQube_url}")
							}
							NexusUpload("BUILD_HISTORY", "${BUILD_HISTORY_PATH}/${DEV_TAG}/DEV_${DEV_TAG}","txt","${TIL_GROUPID}","${DEV_REPO}", "${DEV_TAG}_${date_now}")
							echo "Engine version variable is: ${ENG_VERSIONS}"
						}
					}
					else 
					{
						env.BP_ERROR_CODE = "501"
						env.BP_ERROR_MSG = "BW Build creation FAILED"
						//insert_errorcode('000002', '501')
					}
				
				}
				sleep 5
				script{
					// This is to compose an email to send the Build Summary along with EAR DIFF.
					emailext mimeType: 'text/html',
						subject: "[Jenkins]: ${currentBuild.fullDisplayName}  - " + "Dev Build CHANGE LOG SUMMARY",
						from:"TIL_BUILDS@vodafone.com",
						to: "${bw_mailRecipients}",
						body: "${get_body_build_summary()}" 
						
					sh label: '', script: 'rm -r ${BUILD_HISTORY_PATH}/${DEV_TAG}'
                    
				}						
			}
		}  
	}
	post {
        always {
				script {
					def date_print = new Date().format( 'yyyy/MM/dd hh:mm:ss' )
					def version_print = ""
					def updateQuery = ""
					def db_err_code = ""
					def db_err_msg = ""
					if ( "${currentBuild.currentResult}" == "SUCCESS" && bw_pipe.result == "SUCCESS" && SONAR_STATUS == "SUCCESS" ) {
						version_print="${FINAL_VERSION}"
						til_build_status = "ACTIVE"
						env.BW_VERSION = "${FINAL_VERSION}"
						
						updateQuery = "UPDATE CICD_FB_RELEASES SET BW_BUILD_URL='${BUILD_URL}', BW_VERSION='${FINAL_VERSION}', STAGE_COMPLETED='BUILD', PROJECT_NAME='${params.PROJECTNAME}', CHANGE_REF_ID='${params.JIRA_NUMBER}', CHANGE_REF_DESCRIPTION='${params.JIRA_DESCRIPTION}', ERROR_CODE='200', ERROR_DESCRIPTION='BW BUILD SUCCESS', STATUS='${til_build_status}'  WHERE TDD_ID=${params.TDD_ID}"
						println("DEBUG: Update query is: " + updateQuery)
						dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: updateQuery

						//[CICD-507] Insert Deployment metadata to TIL_BUILD_HISTORY DB.
						def insert_query = """
						Insert into CICD_TIL_BUILD_HISTORY (TIL_MODULENAME, TIL_ARCHIVEFILES, PROJECT_NAME, BUILD_REQUESTER, RELEASE_NO, JIRA_NUMBER, 
						DEFECT_NUMBER, JIRA_DESCRIPTION, BW_VERSION, STATUS, CREATED_ON, CREATED_BY) 
						values 
						('${params.TIL_MODULENAME}', '${params.TIL_ARCHIVEFILES}', '${params.PROJECTNAME}', '${params.BUILD_REQUESTER}', '${params.RELEASE}', '${params.JIRA_NUMBER}', '${params.JIRA_NUMBER}', '${params.JIRA_DESCRIPTION}', '${version_print}', '${til_build_status}', sysdate, '${user}')
						"""
						println("DEBUG: Insert query is: " + insert_query)
						dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: insert_query
						
	
						env.BP_ERROR_CODE = "200"
						env.BP_ERROR_MSG = "BW BUILD SUCCESS" 
						env.BW_VERSION = "${FINAL_VERSION}"

					} else {
					
						if(env.BP_ERROR_CODE == "" || env.BP_ERROR_CODE == null)
						{
							db_err_code = "501"
							db_err_msg = "BW BUILD FAILED"
						}
						else
						{
							db_err_code=env.BP_ERROR_CODE
							db_err_msg=env.BP_ERROR_MSG
						}

						version_print="0"
						til_build_status = "FAILURE"
					
						updateQuery = "UPDATE CICD_FB_RELEASES SET BW_BUILD_URL='${BUILD_URL}', BW_VERSION='${version_print}', STAGE_COMPLETED='BUILD', PROJECT_NAME='${params.PROJECTNAME}', CHANGE_REF_ID='${params.JIRA_NUMBER}', CHANGE_REF_DESCRIPTION='${params.JIRA_DESCRIPTION}', ERROR_CODE='${db_err_code}', ERROR_DESCRIPTION='${db_err_msg}', STATUS='${til_build_status}'  WHERE TDD_ID=${params.TDD_ID}"
						println("DEBUG: Update query is: " + updateQuery)
						dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: updateQuery
						
						
						//[CICD-507] Insert Deployment metadata to TIL_BUILD_HISTORY DB.
						def insert_query = """
						Insert into CICD_TIL_BUILD_HISTORY (TIL_MODULENAME, TIL_ARCHIVEFILES, PROJECT_NAME, BUILD_REQUESTER, RELEASE_NO, JIRA_NUMBER, 
						DEFECT_NUMBER, JIRA_DESCRIPTION, BW_VERSION, STATUS, CREATED_ON, CREATED_BY) 
						values 
						('${params.TIL_MODULENAME}', '${params.TIL_ARCHIVEFILES}', '${params.PROJECTNAME}', '${params.BUILD_REQUESTER}', '${params.RELEASE}', '${params.JIRA_NUMBER}', '${params.JIRA_NUMBER}', '${params.JIRA_DESCRIPTION}', '${version_print}', '${til_build_status}', sysdate, '${user}')
						"""
						println("DEBUG: Insert query is: " + insert_query)
						dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: insert_query
						
						env.BP_ERROR_CODE=db_err_code
						env.BP_ERROR_MSG=db_err_msg
	
						println("Error Code : "+env.BP_ERROR_CODE)
						if(env.BP_ERROR_CODE == "" || env.BP_ERROR_CODE == null)
						{
							env.BP_ERROR_CODE = "501"
							env.BP_ERROR_MSG = "BW BUILD FAILED "
							//insert_errorcode('000002', '501')
						}

					} 
					//sh label: '', script: "echo ${date_print},${params.RELEASE},BWBuild,${params.TIL_ARCHIVEFILES},Build,${currentBuild.currentResult},${currentBuild.duration},${version_print}>> ${REPORT_PATH}"
					statsFile = new File(REPORT_PATH)
					statsFile.append('\n' + date_print + ',' + params.FEATURE_BRANCH + ',' + "BWBuild" + ',' + params.TIL_ARCHIVEFILES + ',' + "Build" + ',' + currentBuild.currentResult + ',' + currentBuild.duration + ',' + version_print)
                    
				}
		}
    }
}
