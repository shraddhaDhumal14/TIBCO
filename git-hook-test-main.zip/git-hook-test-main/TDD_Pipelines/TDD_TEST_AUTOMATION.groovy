import java.text.*
import groovy.time.*
import hudson.tasks.Mailer;
import hudson.model.User;

//  Testing Related Email Body Preparation
def get_body_build_summary(){
    def date = new Date();
    def sdf = new SimpleDateFormat("dd-MM-yyyy");
    def submitted_date = sdf.format(date)
    
    def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
		.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		</style>
		</style>
		<table class="tg" style="undefined;table-layout: fixed; width: 1000px">
		<colgroup>
		<col style="width: 100px">
		<col style="width: 500px">
		<col style="width: 100px">
		<col style="width: 500px">
		</colgroup>
		  <tr>
			<th class="tg-amwm" colspan="2">TEST_AUTOMATION_SUMMARY</th>
		  </tr>
		  <tr>
			<td class="tg-1wig">Engine</td>
			<td class="tg-0lax">${ENGINE_NAME}</td>
		  </tr>
		  <tr>	
			<td class="tg-1wig">Test_Result</td>
			<td class="tg-0lax">${getMapResultTable()}</td>
		  </tr>            
          <tr>	
		   <td class="tg-1wig">TESTCASE Report</td>
		   <td class="tg-0lax">${TESTCASE_REPORT}</td>
		 </tr>
		 <tr>	
		   <td class="tg-1wig">Report url</td>
		   <td class="tg-0lax">${REPORT_URL}</td>
		 </tr>
         <tr>
			<td class="tg-1wig">Submitted By</td>
			<td class="tg-0lax">${params.BUILD_REQUESTOR}</td> 
		  </tr>
		  <tr>
			<td class="tg-1wig">Submitted On</td>
			<td class="tg-0lax">${submitted_date}</td>
		  </tr>
		</table>
		<br>
	"""
	emailBody = body_build_summary
	return body_build_summary
}

def getMapResultTable(){
    def MapTable = ""
    MapTable+= """
          <table>
		  <tr>
			<th class="tg-amwm">Operation</th>
            <th class="tg-amwm">Reg_Total</td> 
            <th class="tg-amwm">Reg_Pass</td> 
            <th class="tg-amwm">Reg_Fail</td>
            <th class="tg-amwm">Reg_Status</td> 
            <th class="tg-amwm">Prog_Total</td> 
            <th class="tg-amwm">Prog_Pass</td> 
            <th class="tg-amwm">Prog_Fail</td>
            <th class="tg-amwm">Prog_Status</td>
            <th class="tg-amwm">TEST_STATUS</td>
            <th class="tg-amwm">TOTAL_TC</td>
		  </tr>
          """
    
    for (operation in Operations){
      MapTable+= """   
		  <tr>
            <td class="tg-0lax">${operation}</td>
			<td class="tg-0lax">${TestMapResult[operation]['Reg_Total']}</td> 
            <td class="tg-0lax">${TestMapResult[operation]['Reg_Pass']}</td> 
            <td class="tg-0lax">${TestMapResult[operation]['Reg_Fail']}</td>
            <td class="tg-0lax">${TestMapResult[operation]['Reg_Status']}</td> 
            <td class="tg-0lax">${TestMapResult[operation]['Prog_Total']}</td> 
            <td class="tg-0lax">${TestMapResult[operation]['Prog_Pass']}</td> 
            <td class="tg-0lax">${TestMapResult[operation]['Prog_Fail']}</td>
            <td class="tg-0lax">${TestMapResult[operation]['Prog_Status']}</td>
            <td class="tg-0lax">${TestMapResult[operation]['TEST_STATUS']}</td>
            <td class="tg-0lax">${TestMapResult[operation]['TOTAL_TC']}</td>
		  </tr>
		  """
    }
    MapTable+= "</table>"
    return MapTable
}


def Preparation () {
	
    def date = new Date();
	def sdf = new SimpleDateFormat("yyyyMMddHHmmss");
	date_time = sdf.format(date)
    
    TESTCASE_REPORT = "http://${NEXUS_URL}/repository/TEST_AUTOMATION_REPO/RTCP_Reports/${ENGINE_NAME}/${RELEASE_NO}_${date_time}/${ENGINE_NAME}-${RELEASE_NO}_${date_time}.zip"
    REPORT_URL = "http://195.233.197.150:8081/#browse/browse:TEST_AUTOMATION_REPO:RTCP_Reports%2F${ENGINE_NAME}"
    
     TAApprovers = get_approvers_list('SITReleaseTechLeadApprovers')

	sh 'cp -r ${WORKSPACE}/Project/${ENGINE_NAME}  ${WORKSPACE}/${ENGINE_NAME}_RIT'
	sh 'cp -r ${WORKSPACE}/Script/Test_Automation_Scripts ${WORKSPACE}/Test_Automation_Scripts'
    sh 'cd ${WORKSPACE}'
	sh 'chmod 766 ${WORKSPACE}/${ENGINE_NAME}_RIT'
	sh 'chmod -f 766 ${WORKSPACE}/${ENGINE_NAME}_RIT/Logical/AntScripts/*.xml'
	
	    
	//Replaces the windows parameters Values to RTCP Box Values in Ant Files   
    
    sh '''
			AntFiles="${WORKSPACE}/${ENGINE_NAME}_RIT/Logical/AntScripts/*.xml"
			# Replaces the windows parameters Values to RTCP Box Values in Ant Files   
				   
			sed -i 's#name="install.dir" value=.*/>#name="install.dir" value="/opt/SP/tibco/IBM/RationalIntegrationTester"/>#g' ${AntFiles}
			sed -i 's#environment=.* project#environment="'${ENVIRONMENT}'" project#g' ${AntFiles}
			sed -i 's#basedir=.* default#basedir="./../.." default#g' ${AntFiles}
			sed -i 's#ghp"#ghp" securityToken="P:8647bc48-c250-4168-9855-b8379b057d1a"#g' ${AntFiles}
				
			cd ${WORKSPACE}
			# Coverting the Total Project into tar file
			tar -czvf ${ENGINE_NAME}_RIT.tar.gz ${ENGINE_NAME}_RIT
				
		'''        
}

def Test_Preparation()
{
    // Executing Ansible Scripts for RIT Project Deployment Preparation in RTCP Box

    ansiColor('xterm') {
        ansiblePlaybook (playbook: "${WORKSPACE}/Test_Automation_Scripts/Preparation.yml", colorized: true, extras: '', extraVars: [host: "RIT_TEST", Engine_Name: "${ENGINE_NAME}_RIT", date_time: "${date_time}", Workspace: "${WORKSPACE}"])
		 //Deleting the tar and engine_RIT to reduce the disk space after successful preparation,  in UKTILAHR box 
         sh '''
              rm -Rf ${ENGINE_NAME}_RIT
              rm ${ENGINE_NAME}_RIT.tar.gz
         '''
    }
}

// Ant File Execution for all Operations Progression
def Automation_Testing (testing_Type) {        
		println("Automation_Testing Map --> " + TestMapResult)
        for (operation in Operations){	 
			
            if((testing_Type == "Progression" && TestMapResult[operation]['Prog_Status'] != "XML MISSING") || (testing_Type == "Regression" && TestMapResult[operation]['Reg_Status'] != "XML MISSING"))    
            {
                // Executing Ansible Scripts for RIT Project Deploying in RTCP Box
                AntFile="${ENGINE_NAME}_${operation}_${testing_Type}.xml"
                ansiColor('xterm') {
                    ansiblePlaybook (playbook: "${WORKSPACE}/Test_Automation_Scripts/Test_Execution.yml", colorized: true, extras:'-v', extraVars: [host: "RIT_TEST", Ant_File: "${AntFile}", Engine_Name: "${ENGINE_NAME}_RIT", date_time: "${date_time}", Workspace: "${WORKSPACE}", Log_File: "${operation}_${testing_Type}_Result.log", file: "${operation}_${testing_Type}.log"])
			}
            }
            else
            {
                println("Skipping Testing for ${operation} for ${testing_Type}")                
            }
	   }
}

// Reports and Cleaning the Workspace
def Reporting_CleanUp () {
	
	//def date = new Date();
	//def sdf = new SimpleDateFormat("yyyy-MM-dd-HH:mm");
	//date_time = sdf.format(date)
	
	ansiColor('xterm') {
			ansiblePlaybook (playbook: "${WORKSPACE}/Test_Automation_Scripts/Reportin_And_Cleanup.yml", colorized: true, extras:'-v', extraVars: [host: "RIT_TEST", Engine_Name: "${ENGINE_NAME}_RIT", date_time: "${date_time}", Workspace: "${WORKSPACE}", Engine: "${ENGINE_NAME}", Workspace: "${WORKSPACE}"])
			
			// Uploading RTCP Reports in to NEXUS
			//nexusArtifactUploader artifacts: [[artifactId: "${ENGINE_NAME}", classifier: '', file: "${WORKSPACE}/${ENGINE_NAME}.zip", type: 'zip']], credentialsId: '74edde97-94e0-403c-93f6-cad6c46c45f8', groupId: "RTCP_Reports", nexusUrl: "${NEXUS_URL}", nexusVersion: "${NEXUS_VERSION}", protocol: 'http', repository: "${RTCP_REPO}", version: "${date_time}"
            
            sh "mv ${ENGINE_NAME}.zip ${ENGINE_NAME}_${date_time}.zip"
            
            nexusArtifactUploader artifacts: [[artifactId: "${ENGINE_NAME}", classifier: '', file: "${WORKSPACE}/${ENGINE_NAME}_${date_time}.zip", type: 'zip']], credentialsId: '74edde97-94e0-403c-93f6-cad6c46c45f8', groupId: "RTCP_Reports", nexusUrl: "${NEXUS_URL}", nexusVersion: "${NEXUS_VERSION}", protocol: 'http', repository: "${RTCP_REPO}", version: "${RELEASE_NO}_${date_time}"
										
	}
    
    for (operation in Operations)
	{
		TestMapResult[operation]['TOTAL_TC'] = 0
		TestMapResult[operation]['TEST_STATUS'] = ''
        
        if(TestMapResult[operation]['Prog_Status'] != "XML MISSING")
        {
            ta_result = sh(script:"grep 'tests executed' ${operation}_Progression_Result.log | tail -1 | cut -d ']' -f3 | xargs" ,returnStdout: true).trim()
            println("TA Result -->" + ta_result)
            
            if ( ta_result == "0 tests executed" ) 
            {
                TestMapResult[operation]['Prog_Total'] = '0'
                TestMapResult[operation]['Prog_Pass'] = '0'
                TestMapResult[operation]['Prog_Fail'] = '0'
                TestMapResult[operation]['Prog_Status'] = "FAILED"
            } 
            else if ( ta_result == "1 tests executed - passed" ) 
            {
                TestMapResult[operation]['Prog_Total'] = '1'
                TestMapResult[operation]['Prog_Pass'] = '1'
                TestMapResult[operation]['Prog_Fail'] = '0'
                TestMapResult[operation]['Prog_Status'] = "PASSED"
		TestMapResult[operation]['TEST_STATUS'] = "SUCCESS"
            } 
            else {
                TestMapResult[operation]['Prog_Total'] = ta_result.split('-')[0].split(' ')[0]
                
                pass_fail_msg = ta_result.split('-')[1]
                if ( "${pass_fail_msg}" == " all passed" ) {
                    TestMapResult[operation]['Prog_Fail'] = 0
                } 
                else if("${pass_fail_msg}".trim() == "failed")
                {
                    TestMapResult[operation]['Prog_Fail'] = 1
                }
                else {
                    TestMapResult[operation]['Prog_Fail'] = pass_fail_msg.split(' ')[1]
                }
                TestMapResult[operation]['Prog_Pass'] = TestMapResult[operation]['Prog_Total'].toInteger() - TestMapResult[operation]['Prog_Fail'].toInteger()
                statusFile = new File("${WORKSPACE}/${operation}_Progression_Result.log")
				TestMapResult[operation]['TOTAL_TC'] = ((TestMapResult[operation]['TOTAL_TC'] as Integer) + (TestMapResult[operation]['Prog_Total'] as Integer)).toString()
				
                statusContent = sh(script:"grep 'RunTests execution ended with code: 0' ${operation}_Progression_Result.log" ,returnStdout: true).trim()
                if (statusContent.contains('RunTests execution ended with code: 0')) {
                    TestMapResult[operation]['Prog_Status'] = "SUCCESS"
                }else {
                    TestMapResult[operation]['Prog_Status'] = "FAILED"
                } 
				
				if(TestMapResult[operation]['Prog_Status'] == 'SUCCESS')
				{
					TestMapResult[operation]['TEST_STATUS'] = 'SUCCESS'
				}
				else
				{
					TestMapResult[operation]['TEST_STATUS'] = 'FAILED'
				}
             }
        }

        if(TestMapResult[operation]['Reg_Status'] != "XML MISSING" && TestMapResult[operation]['Reg_Status'] != "NEW")
        {
            ta_result = sh(script:"grep 'tests executed' ${operation}_Regression_Result.log | tail -1 | cut -d ']' -f3 | xargs" ,returnStdout: true).trim()
            
            if ( ta_result == "0 tests executed" ) 
            {
                TestMapResult[operation]['Reg_Total'] = '0'
                TestMapResult[operation]['Reg_Pass'] = '0'
                TestMapResult[operation]['Reg_Fail'] = '0'
                TestMapResult[operation]['Reg_Status'] = "FAILED"
            }
	    else if ( ta_result == "1 tests executed - passed" ) 
            {
                TestMapResult[operation]['Reg_Total'] = '1'
                TestMapResult[operation]['Reg_Pass'] = '1'
                TestMapResult[operation]['Reg_Fail'] = '0'
                TestMapResult[operation]['Reg_Status'] = "PASSED"
		TestMapResult[operation]['TEST_STATUS'] = "SUCCESS"
            } 
            else {
                TestMapResult[operation]['Reg_Total'] = ta_result.split('-')[0].split(' ')[0]
                
                pass_fail_msg = ta_result.split('-')[1]
                if ( "${pass_fail_msg}" == " all passed" ) {
                    TestMapResult[operation]['Reg_Fail'] = 0
                }
                else if("${pass_fail_msg}".trim() == "failed")
                {
                    TestMapResult[operation]['Reg_Fail'] = 1
                }                
                else {
                    TestMapResult[operation]['Reg_Fail'] = pass_fail_msg.split(' ')[1]
                }
                TestMapResult[operation]['Reg_Pass'] = TestMapResult[operation]['Reg_Total'].toInteger() - TestMapResult[operation]['Reg_Fail'].toInteger()
                statusFile = new File("${WORKSPACE}/${operation}_Regression_Result.log")
				TestMapResult[operation]['TOTAL_TC'] = ((TestMapResult[operation]['TOTAL_TC'] as Integer) + (TestMapResult[operation]['Reg_Total'] as Integer)).toString()
                                         
                statusContent = sh(script:"grep 'RunTests execution ended with code: 0' ${operation}_Regression_Result.log" ,returnStdout: true).trim()                                        
                if (statusContent.contains('RunTests execution ended with code: 0')) {
                    TestMapResult[operation]['Reg_Status'] = "SUCCESS"
                }else {
                    TestMapResult[operation]['Reg_Status'] = "FAILED"
                } 
				if(TestMapResult[operation]['Reg_Status'] == 'SUCCESS' && TestMapResult[operation]['TEST_STATUS'] == 'SUCCESS')
				{
					TestMapResult[operation]['TEST_STATUS'] = 'SUCCESS'
				}
				else
				{
					TestMapResult[operation]['TEST_STATUS'] = 'FAILED'
				}
            }
        }
            
        
        /*
         if(TestMapResult[operation]['Prog_Status'] != "XML MISSING")
		{
		    result = sh(script:"sh getTestResultByOperation.sh ${operation} 'Progression'" ,returnStdout: true).trim()
			TestMapResult[operation]['Prog_Total'] = result.split('-')[0]
			TestMapResult[operation]['Prog_Fail'] = result.split('-')[1] 
			TestMapResult[operation]['Prog_Status'] = result.split('-')[2] 
			TestMapResult[operation]['Prog_Pass'] = ((TestMapResult[operation]['Prog_Total'] as Integer) - (TestMapResult[operation]['Prog_Fail'] as Integer)).toString()
			TestMapResult[operation]['TOTAL_TC'] = ((TestMapResult[operation]['TOTAL_TC'] as Integer) + (TestMapResult[operation]['Prog_Total'] as Integer)).toString()
			if(TestMapResult[operation]['Prog_Status'] == 'SUCCESS' && TestMapResult[operation]['TEST_STATUS'] == 'SUCCESS')
			{
				TestMapResult[operation]['TEST_STATUS'] = 'SUCCESS'
			}
			else
			{
				TestMapResult[operation]['TEST_STATUS'] = 'FAILED'
			}
		}
		println(TestMapResult)
		 if(TestMapResult[operation]['Reg_Status'] != "XML MISSING")
		{
			result = sh(script:"sh getTestResultByOperation.sh ${operation} 'Regression'" ,returnStdout: true).trim() 
			
			TestMapResult[operation]['Reg_Total'] = result.split('-')[0]
			TestMapResult[operation]['Reg_Fail'] = result.split('-')[1] 
			TestMapResult[operation]['Reg_Status'] = result.split('-')[2] 
			TestMapResult[operation]['Reg_Pass'] = ((TestMapResult[operation]['Reg_Total'] as Integer) - (TestMapResult[operation]['Reg_Fail'] as Integer)).toString()
			TestMapResult[operation]['TOTAL_TC'] = ((TestMapResult[operation]['TOTAL_TC'] as Integer) + (TestMapResult[operation]['Reg_Total'] as Integer)).toString()
			if(TestMapResult[operation]['Reg_Status'] == 'SUCCESS' && TestMapResult[operation]['TEST_STATUS'] == 'SUCCESS' )
			{
				TestMapResult[operation]['TEST_STATUS'] = 'SUCCESS'
			}
			else
			{
				TestMapResult[operation]['TEST_STATUS'] = 'FAILED'
			}
		}
        */	
	}//for loop ends
		
          
               
    println("TestMapResult  " +TestMapResult)
    
    string updateQuery="UPDATE TDD_TA_SUMMARY SET  STATUS='Inactive', MODIFIED_BY='New TA', MODIFIED_ON = sysdate where SEQ_NO = '${SEQ_NO}' and STATUS ='Active'" 
              	
    println("DEBUG: TDD_TA_SUMMARY query is: " + updateQuery)
    DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: updateQuery 
    
    //Insert into Table
     
     for (operation in Operations)
	 {
        
		string insert_query="INSERT INTO TDD_TA_SUMMARY ( SEQ_NO,  RELEASE_NO,  ENGINE_NAME, OPERATION, RIT_BRANCH, ENVIRONMENT, PROG_PASS, PROG_FAIL, REG_PASS, REG_FAIL, TOTAL_TC, TEST_STATUS, STATUS, CREATED_ON, CREATED_BY, APPROVED_BY, TESTCASE_REPORT_URL, BUILD_URL) VALUES ( '${SEQ_NO}', '${RELEASE_NO}',  ${ENGINE_NAME}, ${operation}, ${GIT_BRANCH}, ${ENVIRONMENT}, ${TestMapResult[operation]['Prog_Pass']}, ${TestMapResult[operation]['Prog_Fail']}, ${TestMapResult[operation]['Reg_Pass']}, ${TestMapResult[operation]['Reg_Fail']}, ${TestMapResult[operation]['TOTAL_TC']}, ${TestMapResult[operation]['TEST_STATUS']}, 'Active', sysdate, 'chithra', '', ${TESTCASE_REPORT}, ${BUILD_URL})" 
				
					
		println("DEBUG: TDD_TA_SUMMARY query is: " + insert_query)
		DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: insert_query 	
    }
}

def validate_parameter() {
        def validationCheck = ""
   
        
		//1. Validate Engine Name
        if(ENGINE_NAME == ""){
            println("Engine name is mandatory")
            validationCheck = "F"
        }
        
        //2. validate Operation_Name
        if(OPERATION_NAME == ""){
            println("Operation Name is mandatory")
            validationCheck = "F"
        }
        else if (OPERATION_NAME.indexOf(' ') != -1){
            println('Operation Name should not contain spaces in between')
            validationCheck = "F"
        }
        else
        {
             Operations = OPERATION_NAME.replaceAll(';',',').split(',')
             println("Operation List --> " + Operations) 
             Operations.each { id ->
                  TestMapResult[id] = ['Reg_Total':'','Reg_Pass':'', 'Reg_Fail':'', 'Reg_Status':'', 'Prog_Total':'','Prog_Pass':'', 'Prog_Fail':'', 'Prog_Status':'', 'TEST_STATUS':'', 'TOTAL_TC' : '']
             }
        }
        
        //3. Email is Mandatory
        if(BUILD_REQUESTOR == ""){
            println("Email is mandatory")
            validationCheck = "F"
        }  

        //4. GIT_BRANCH is Mandatory
        if(GIT_BRANCH == ""){
            println("GIT_BRANCH is mandatory")
            validationCheck = "F"
        }

        //5. Environments is Mandatory
        if(ENVIRONMENT == ""){
            println("Environments is mandatory")
            validationCheck = "F"
        }

        if(validationCheck == "F"){
            env.TA_ERROR_CODE = "501"
            env.TA_ERROR_MSG = "Pipeline Input parameter validation failed."
			error("Pipeline Input parameter validation failed. Please check the errors in Console log.")

		}  
  } 
def download_git_repo()
{
	//Checkout Rit Project
	try
	{
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/${GIT_BRANCH}']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Project"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/RIT_${ENGINE_NAME}.git']]]
    }
    catch(Exception Ex)
    {
        error("Repo (RIT_${ENGINE_NAME}) or Branch (${GIT_BRANCH}) not found")
    }
    
	//Checkout Ansible Scripts			
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Script"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
    
    //Checkout Common function Scripts	
	checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'JENKINS_FILE']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_DevOps_Framework.git']]])
 	
	DB_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/dbFunctions.groovy"
	
    //sh 'cp -R /opt/tibco/temp/Ram/* .'
    //sh 'cp /opt/tibco/temp/Ram/*.sh ./'
    //sh 'sleep 10'

}

@NonCPS
def getUserEmail(String id=null) {
    User user = User.getById(id ?: currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId(), false)  
    user?.getProperty(Mailer.UserProperty.class).getAddress()
}

def get_approvers_list(String approver_group){
	approvers_list = sh (script: """cat /opt/tibco/.jenkins/config.xml | sed -n \'/role name=\"${approver_group}\"/,\$p\' | sed \'/role>/q\' | grep "sid" | cut -d \'>\' -f 2 | cut -d \'<\' -f 1 | paste -s -d, -""", returnStdout: true).trim()
    return """${approvers_list}"""           
}

def get_approvers_email_list(String approvers_list){
   approvers_email=""
	approvers_list.split(',').each { user ->
            if(approvers_email.length() != 0)
              {
                    approvers_email += ","
              }
              approvers_email += getUserEmail(user)  
        }
    return """${approvers_email}"""   
}

def fileStructureCheck()
{
    
    //RIT Repo Exist
    RepoFolder = "${WORKSPACE}/Project"
	if (!fileExists(RepoFolder)) {	
	    env.TA_ERROR_CODE = "516"
        env.TA_ERROR_MSG = ("RIT_${ENGINE_NAME} Repo missing")
        error ("Repository RIT_${ENGINE_NAME} was not found")
    }
    
    //Engine name folder inside RIT Repo
    EngineFolder = "${RepoFolder}/${ENGINE_NAME}"
	if (!fileExists(EngineFolder)) {	
        
		env.TA_ERROR_CODE = "516"
        env.TA_ERROR_MSG = ("${ENGINE_NAME} folder missing inside RIT_${ENGINE_NAME} Repo")
		println ("${ENGINE_NAME} folder missing inside RIT_${ENGINE_NAME} Repo")
        error.result = 'No RIT Repo available'
		
    }
    
    //Logical folder inside RIT Repo
    LogicalFolder = "${EngineFolder}/Logical"
	if (!fileExists(LogicalFolder)) {	
        
		env.TA_ERROR_CODE = "516"
        env.TA_ERROR_MSG = ("Logical folder missing inside RIT_${ENGINE_NAME} Repo")
		error ("Logical folder missing inside RIT_${ENGINE_NAME} Repo")
        	
    }
    
    //Ant script folder inside RIT Repo
    AntFolder = "${LogicalFolder}/AntScripts"
	if (!fileExists(AntFolder)) {	
        
		env.TA_ERROR_CODE = "516"
        env.TA_ERROR_MSG = ("Ant script folder missing inside RIT_${ENGINE_NAME} Repo")
		error ("Ant script folder missing inside RIT_${ENGINE_NAME} Repo")
    }
    
    AntFilesCheck = true
    //All regression and Progression testcase available for all operation name
    for (operation in Operations) {
        Ant_File_Regression = "${AntFolder}/${ENGINE_NAME}_${operation}_Regression.xml"
        Ant_File_Progression = "${AntFolder}/${ENGINE_NAME}_${operation}_Progression.xml"
        
        TestMapResult[operation]['Reg_Total'] = "0"
        TestMapResult[operation]['Reg_Fail'] = "0"
        TestMapResult[operation]['Reg_Pass'] = "0" 
        TestMapResult[operation]['Reg_Status'] = "NA"        

        TestMapResult[operation]['Prog_Total'] = "0"
        TestMapResult[operation]['Prog_Fail'] = "0"
        TestMapResult[operation]['Prog_Pass'] = "0"
        TestMapResult[operation]['Prog_Status'] = "NA"
            
        if (!fileExists(Ant_File_Regression)) {	
            println("Regression Test xml file missing for operation ${operation}")
            AntFilesCheck = false
            TestMapResult[operation]['Reg_Status'] = "XML MISSING"             
        }
        
        if (ENGINE_TYPE == "NEW") {	
            println("Engine Type is New. So skipping Regression testing")
            TestMapResult[operation]['Reg_Status'] = "NEW"            
        }
        
        if (!fileExists(Ant_File_Progression)) {	
            println("Progression Test xml file missing for operation ${operation}")
            AntFilesCheck = false
            TestMapResult[operation]['Prog_Status'] = "XML MISSING"
        }
    }
    println("Initial Map --> "  + TestMapResult)
    if(!AntFilesCheck)
        
		//env.TA_ERROR_CODE = "517"
        //env.TA_ERROR_MSG = "Progression or Regression Test case xml file missing in Ant Script folder"
		println ("Progression or Regression Test case xml file missing in Ant Script folder")
    }


def getBuildUserID(){
    if(currentBuild.getBuildCauses('hudson.triggers.TimerTrigger$TimerTriggerCause'))
	{
	println ("time_triggered")
            return "time_triggered"
	}
    else if(currentBuild.getBuildCauses('hudson.model.Cause$UpstreamCause'))
    {
           println ("time_triggered")
		   def upstreamCause = currentBuild.rawBuild.getCause(Cause.UpstreamCause)
           def upstreamJob = Jenkins.getInstance().getItemByFullName(upstreamCause.getUpstreamProject(), hudson.model.Job.class)
           if (upstreamJob) {
                    def upstreamBuild = upstreamJob.getBuildByNumber(upstreamCause.getUpstreamBuild())
                    if (upstreamBuild) {
                            def realUpstreamCause = upstreamBuild.getCause(Cause.UserIdCause)
                            if (realUpstreamCause) {
                                    return realUpstreamCause.getUserId()
                            }
                    }
					else
					{
					println ("Unknown user")
					}
					
            }
			else 
			{
			println ("Unknown upstream job")
			}
            return "Upstream Triggered"
     }
    else
            return currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId()
}

def Operations= ""
def date_time= ""
REPORT_URL=""
TESTCASE_REPORT=""
Status =""
TestMapResult = [:]

        
pipeline {
	agent any
	options {
        	timeout(time: 5, unit: 'DAYS')
	}
	environment {	

        TA_ERROR_CODE = ""
        TA_ERROR_MSG = ""	


		NEXUS_URL="195.233.197.150:8081"
		NEXUS_VERSION="nexus3"
		RTCP_REPO="TEST_AUTOMATION_REPO"				
		
        RIT_Folder = "/opt/SP/tibco/IBM/RationalIntegrationTester"

        //[CICD-539] Insert Deployment metadata to release notes DB.
		dbURL = 'jdbc:oracle:thin:@195.233.199.13:33000:TIBTST1'
		dbUserName = 'CICD_OWN_DB01'
		dbPassword = 'TIL_CICD_DB'
		dbDriver = 'oracle.jdbc.driver.OracleDriver'
        
	}
	
	stages {
		stage('Preparation') {
		
			steps {
                script {
					cleanWs()
                    env.PIPELINE_URL = "$BUILD_URL"
                    validate_parameter() 
                    currentBuild.displayName = "${SEQ_NO}_${RELEASE_NO}_${Engine_Name}_${BUILD_NUMBER}"
                    download_git_repo()                        
                    fileStructureCheck ()
					Preparation ()					

				}
			}
		}
        
        stage('Test Preparation') {		
			steps {
                script {
                    echo "Test Preparation"
                    Test_Preparation()
                }
            }
        }
		
		stage('Progression Testing') {
            steps {
                script {
					echo "Progression_Testing"
                    Automation_Testing("Progression")	
				}
			}
		}
        
        stage('Regression Testing') {
            when { expression { ENGINE_TYPE == "Existing" || ENGINE_TYPE == "UPDATED" } }
            steps {
                script {
					echo "Regression_Testing"
                    Automation_Testing("Regression")
		
				}
			}
		}
        
		stage('Reporting & CleanUp') {			
			steps {
                script {	
	                Reporting_CleanUp ()
					println " ======>> Reporting & CleanUp <<======"
                }
            }
        }
        
        stage('Send Approval Mail') {
			steps {
                script {
			
						statusFile = new File("${WORKSPACE}/Result_Log.txt")
						statusContent = statusFile.readLines()
													
                      
                        if (statusContent[-1].contains(' RunTests execution ended with code: 0')) {
							Status = "SUCCESS"
						}else {
							Status = "FAILED"
						} 

					   
						/*
                        def content = "<br>Engine Name  : ${Engine_Name}"
                        content += "Operations : ${OPERATION_NAME}"
                        if(Status == "SUCCESS")
                        {
                            content += "Status : <font ='Blue'>Pass</font>"
                        }
                        else
                        {
                            content += "Status : <font ='Red'>Fail</font>"
                        }
                        */
                        
						emailext  mimeType: 'text/html', attachmentsPattern: '*.log,*.txt',
						subject: "[Jenkins]:${currentBuild.fullDisplayName}:Test_Results - Request Approval",
						from:"Test_Automation@vodafone.com",
						to: "${params.BUILD_REQUESTOR}",
						body: 	"${get_body_build_summary()}" + 
								"<br><p><b><font size='2' color='Black'>TEST_AUTOMATION_BUILDURL: <a href='${BUILD_URL}input'>${BUILD_URL}</a></font></b></p>"	
				}
			}
		}
        
        stage('Tech Lead Approval') {
            options {
                timeout(time: 2, unit: 'DAYS')
            }
			steps {
				script{					
                    def TLInput = input( id: 'TLInput', message: 'Do you want to Approve?',
                                            parameters: 
                                            [[$class: 'ChoiceParameterDefinition', defaultValue: 'REJECTED', 
                                            description:'Please provide your approval after validating test executions', name:'Approval', choices: "REJECTED\nAPPROVED"],
                                            [$class: 'TextParameterDefinition', defaultValue: '', 
                                            description:'Enter the comments here', name:'Comments']],
                                            submitterParameter: 'submitter',
                                            submitter: "${TAApprovers}"
                                           )
                    Apvl_TL_Status = TLInput.Approval
                    Apvl_TL_Name = TLInput.submitter
                    Apvl_TL_Date = new Date().format("dd/MM/yyy HH:mm")
                    Apvl_TL_Comments = TLInput.Comments
                    APPROVAL_COMMENTS = ""
					if(TLInput.Comments.length() != 0)
                    {
                        APPROVAL_COMMENTS = Apvl_TL_Name + "[" + Apvl_TL_Status + ": " + Apvl_TL_Date + "] : " + TLInput.Comments
                    }
                    println("DEBUG: Team Lead " + Apvl_TL_Status + " the request")  
                    
                    updateQuery = "UPDATE TDD_TA_SUMMARY SET  APPROVED_BY='${Apvl_TL_Name}', COMMENTS='${APPROVAL_COMMENTS}' where BUILD_URL ='${BUILD_URL}'"
                    println("DEBUG: TDD_TA_SUMMARY query is: " + updateQuery)
                    
					DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: updateQuery
                    
                    techLeadmails = get_approvers_email_list(TAApprovers) 
                    techLeadmails += ";devops-vfuk-integration@vodafone.com"
                    
                    emailext  mimeType: 'text/html', attachmentsPattern: '*.log,*.txt',
						subject: "[Jenkins]:${currentBuild.fullDisplayName}:Test_Results - ${Apvl_TL_Status}",
						from:"Test_Automation@vodafone.com",
						to: "${techLeadmails}", 
						body: 	"${get_body_build_summary()}" + 
								"<br><p><b><font size='2' color='Black'>TEST_AUTOMATION_BUILDURL: <a href='${BUILD_URL}input'>${BUILD_URL}</a></font></b></p>"
                    
					if(Apvl_TL_Status == "REJECTED")
                    {
                        env.TA_ERROR_CODE = "201"
                        env.TA_ERROR_MSG = "Test Automation - Rejected by Approver"
						error ("Test Automation Rejected by Approver")
                    }    
                }
			}			
		}//stage TL Approval
	}
post {
        always {
				script {
                    def updateQuery = ""
					if ( "${currentBuild.currentResult}" == "SUCCESS") 
                    {
						env.TA_ERROR_CODE = "200"
                        env.TA_ERROR_MSG = "Test Automation Completed"
                        updateQuery = "UPDATE CICD_RELEASES SET TEST_RESULT = '${Status}', TEST_SHEET_LOCATION = '${REPORT_URL}', TEST_AUTOMATION_URL= '${BUILD_URL}', MODIFIED_ON = sysdate, MODIFIED_BY='${params.BUILD_REQUESTOR}', STAGE_COMPLETED='TA', ERROR_CODE = '${env.TA_ERROR_CODE}', ERROR_DESCRIPTION = '${env.TA_ERROR_MSG}' WHERE TDD_ID=${params.TDD_ID}"                        
					} 
                    else 
                    {
                        if(env.TA_ERROR_CODE == "" || env.TA_ERROR_CODE == null)
                        {
                            env.TA_ERROR_CODE = "518"
                            env.TA_ERROR_MSG = "TA Execution Failure "
                        }
                        updateQuery = "UPDATE CICD_RELEASES SET TEST_AUTOMATION_URL= '${BUILD_URL}', MODIFIED_ON = sysdate, MODIFIED_BY='${params.BUILD_REQUESTOR}', ERROR_CODE = '${env.TA_ERROR_CODE}', ERROR_DESCRIPTION = '${env.TA_ERROR_MSG}' WHERE TDD_ID=${params.TDD_ID}"
 					}					 
					println("Error Code : "+env.TA_ERROR_CODE)
                    println("Error MSG : "+env.TA_ERROR_MSG)  

                    println("DEBUG: Update query is: " + updateQuery)                   
					DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: updateQuery
                                        
				}
		}    
    }
}
  
