// Calling global functions from shared libraries.
//@Library('myLibrary@master') _


//[CICD-476] Fix: import this package as part of the fix
import groovy.time.*

//[CICD-539] Insert Deployment metadata to release notes DB.
import groovy.json.JsonOutput
import groovy.sql.*
import java.sql.Driver
import hudson.tasks.Mailer;
import hudson.model.User;

@NonCPS
def getUserEmail(String id=null) {
    User user = User.getById(id ?: currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId(), false)
    user?.getProperty(Mailer.UserProperty.class).getAddress()
}

def validate_input_parameters(deployParams) {
		def validationCheck = ""
        def error_msg = ""
		//1. Validate RELEASE parameter
		if(deployParams.containsKey('RELEASE')) {
			String regex = /(^CCS\d+\.\d+_[A-Z0-9]+$)|(^CCS\d+\.\d+$)/
			if(deployParams.RELEASE == ""){
				println("Release is mandatory for Delivery Pipeline")
                error_msg += "Release is mandatory for Delivery Pipeline\n"
				validationCheck = "F"
			}
			if (deployParams.RELEASE.indexOf(' ') != -1){
				println('RELEASE parameter should not contain spaces in between')
                error_msg += "RELEASE parameter should not contain spaces in between\n"
				validationCheck = "F"
			}
			if (!(deployParams.RELEASE ==~ regex)){
				println('RELEASE parameter is not in standard format. Please input either in CCS20.12 or CCS20.12_xx format')
                error_msg += "RELEASE parameter is not in standard format. Please input either in CCS20.12 or CCS20.12_xx format\n"
				validationCheck = "F"
			}			
			
		}
		
		//2. Validate CRQ number
		if(deployParams.containsKey('CRQ')) {
			if(deployParams.CRQ == ""){
				println("CRQ Number should be specified for the Deployment")
                error_msg += "CRQ Number should be specified for the Deployment\n"
				validationCheck = "F"
			}
			if (deployParams.CRQ.indexOf(' ') != -1){
				println('CRQ parameter should not contain spaces in between')
                error_msg += "CRQ parameter should not contain spaces in between\n"
				validationCheck = "F"
			}			
		}
		
		//3. Validate Description parameter.
		if(deployParams.containsKey('DESCRIPTION')) {
			if(deployParams.DESCRIPTION == ""){
				println("DESCRIPTION parameter to be specified for the Deployment")
                error_msg += "CRQ parameter should not contain spaces in between\n"
				validationCheck = "F"
			}
			//[CICD-1836]: Validating Description parameter against any symbols present in it.
			String regex_pattern = ".*[\\\\()\\[\\]\\?\\|\\%\\/\\\n]+.*"
			if (deployParams.DESCRIPTION ==~ regex_pattern){
				println('ERROR: Description parameter has symbols or new line present in it. Please input plain text for description parameter')
                error_msg += "Description parameter has symbols or new line present in it. Please input plain text for description parameter\n"
				validationCheck = "F"
			}			
		}	
		
		//5. Validate Description parameter.
		if(deployParams.containsKey('OPERATION_NAME')) {
			if(deployParams.OPERATION_NAME == ""){
				println("OPERATION_NAME parameter to be specified for the Deployment")
                error_msg += "OPERATION_NAME parameter to be specified for the Deployment\n"
				validationCheck = "F"
			}
		}
		
		//6. Validate BW VERSION belongs to RELEASE or not.
		if(deployParams.containsKey('BW_VERSION') && deployParams.containsKey('RELEASE')) {
			if (deployParams.RELEASE.split('CCS')[1].split('_').join(".") != deployParams.BW_VERSION.split('_').init().join(".")){
				println("BW_VERSION should belong to Release Number provided")
                error_msg += "BW_VERSION should belong to Release Number provided\n"
				validationCheck = "F"
			}
		}

		//7. Validate EMS VERSION belongs to RELEASE or not.
		if(deployParams.containsKey('EMS_VERSION') && deployParams.containsKey('RELEASE')) {
			if (deployParams.RELEASE.split('CCS')[1].split('_').join(".") != deployParams.EMS_VERSION.split('_').init().join(".")){
				println("EMS_VERSION should belong to Release Number provided")
                error_msg += "EMS_VERSION should belong to Release Number provided\n"
				validationCheck = "F"
			}
		}
		
		//8. Validate SQL VERSION belongs to RELEASE or not.
		if(deployParams.containsKey('SQL_VERSION') && deployParams.containsKey('RELEASE')) {
			if (deployParams.RELEASE.split('CCS')[1].split('_').join(".") != deployParams.SQL_VERSION.split('_').init().join(".")){
				println("SQL_VERSION should belong to Release Number provided")
                error_msg += "SQL_VERSION should belong to Release Number provided\n"
				validationCheck = "F"
			}
		}
	

		
		if(validationCheck == "F"){	
            return error_msg            
		}
        else
        {   
            return ""
        }
}

def dbInsertOrUpdate(deployParams) {
	  
    int retryCount = 0;
    def error = ""
    def mySQL
    while (1) 
    {
       if( retryCount > 0 && retryCount % 3 ==0 )
       {
        input 'Proceed or Abort?'      
       }
       try {
            mySQL =  myGetDBConnect dbURL: deployParams.dbURL, dbUserName: deployParams.dbUserName, dbPassword: deployParams.dbPassword, dbDriver: deployParams.dbDriver
            mySQL.connection.autoCommit = false
            println("Executing Query :" + deployParams.insertQuery)
            int rowAffected = mySQL.executeUpdate(deployParams.insertQuery);
            mySQL.commit()
            mySQL.close()
            mySQL = null
            println("Insert/Update " + rowAffected + " row(s)")
            return true
        }
       catch(Exception ex) {
            println("Error in Executing Query :" + deployParams.insertQuery) 
            mySQL.rollback()
            mySQL.close()
            mySQL = null
            println("Exception caught : " + ex); 
            println("Sleeping for 5 seconds .... Will Retry "+ (retryCount+1))
            println "Red Alert!! Inform CICD Team ++ DB Error ++ ${ex} ++ ${deployParams.insertQuery}"
            sleep 5            
        }
        retryCount++
    }     
    return false       
}



def myGetDBConnect(deployParams) {     
     def mySQL = groovy.sql.Sql.newInstance(deployParams.dbURL,deployParams.dbUserName,deployParams.dbPassword,deployParams.dbDriver)
     return mySQL
}

def URLTest(strURL)
{                  
    int retryCount = 0;
    def error = ""
    def objURL 
    while (1) 
    {
           if( retryCount > 0 && retryCount % 3 ==0 )
           {
            input 'Proceed or Abort?'      
           }
            try {
                    objURL = new URL("http://${strURL}").getText()
                    println("Site Reachable")
                    return true
                }
            catch(Exception ex) {
                    println("Exception caught : " + ex); 
                    println("Sleeping for 5 seconds .... Will Retry "+ (retryCount+1))
                    println "Red Alert!! Inform CICD Team ++ Nexus Error ++ ${ex} ++ ${error} "
                    objURL = null
                    sleep 5    
                    retryCount++                    
            } 
    }  
    return false       
}


def GitClone(RepoName, TargetDirectory, BranchName )
{
    int retryCount = 0;
    def error = ""
    while (1) 
    {
       if( retryCount > 0 && retryCount % 3 ==0 )
       {
        input 'Proceed or Abort?'      
       }
       try {
            
            checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: "*/${BranchName}"]], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${TargetDirectory}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: "https://github.vodafone.com/VFUK-INTEGRATION/${RepoName}.git"]]]
            return true
       }
       catch(Exception ex) {
            println("Exception caught : " + ex + "while downloading Repo " +  RepoName); 
            error = ex;
            println("Sleeping for 5 seconds .... Will Retry "+ (retryCount+1))
            println "Red Alert!! Inform CICD Team ++ Git Error ++ ${error}"
            sleep 5            
        }
        retryCount++
    }     
    return false       
}

//[CICD-476] Fix: function to get elapsed time duration 
def elapsedTime(Closure closure){
    def timeStart = new Date()
    closure()
    def timeStop = new Date()
    return TimeCategory.minus(timeStop, timeStart).toMilliseconds()
}

def trigger_results_email(deployParams){
	// This function is to trigger an email for the provided map.
	emailext mimeType: 'text/html',
	subject: "[Jenkins]: ${currentBuild.fullDisplayName}  - " + "Deployment Results Summary",
	from:"TIL_LINKTEST_DEPLOYMENT@vodafone.com",
	to: "${dev_mailRecipients}",
	body: 	"${emailFunctions.get_lt_results_summary map: deployParams.map, REPORT_STAGE: deployParams.REPORT_STAGE, crq_num: deployParams.crq_num, release: deployParams.release}" 
}

def trigger_versions_email(deployParams){
	// This function is to trigger an email for the provided map.
	emailext mimeType: 'text/html',
	 subject: "[Jenkins]: Deployment Version Summary",
	 from:"TIL_LINKTEST_DEPLOYMENT@vodafone.com",
	 to: "${dev_mailRecipients}",
	 body: 	"${emailFunctions.get_engine_versions_summary map: deployParams.map, REPORT_STAGE: deployParams.REPORT_STAGE, Target_Env: TARGET_Env}" 
}

// Funcation to Get Email List
def get_approvers_list(String str){
	outlist = sh (script: """cat /opt/tibco/.jenkins/config.xml | sed -n \'/role name=\"${str}\"/,\$p\' | sed \'/role>/q\' | grep "sid" | cut -d \'>\' -f 2 | cut -d \'<\' -f 1 | paste -s -d, -""",
			returnStdout: true).trim()
	return """${outlist}"""
}

def email_gv_diff_report(deployParams) {
	// This function is to send GV diff report through an email.
	//[CICD-1112] : Attaching gv diff report as an html format in the same email.

	def gv_file_dir = "${WORKSPACE}/${deployParams.env}/BW_Deployment/GV_DIFF_SUMMARY"
	if(fileExists(gv_file_dir)){
		def gv_diff_path = new File("${WORKSPACE}/${deployParams.env}/BW_Deployment/GV_DIFF_SUMMARY")
		gv_diff_path.traverse{
			def eng_name = it.toString().split('/')[-1].split('_GV_DIFF.html')[0]
			def file_name = it.text
			emailext mimeType: 'text/html',
				subject: "[Jenkins]:${currentBuild.fullDisplayName}: GV DIFF REPORT for ${eng_name}",
				from:"TIL_DEPLOYMENTS@vodafone.com",
				to: "${dev_mailRecipients}",
				body: "${file_name}",
				attachmentsPattern: "**/${deployParams.env}/BW_Deployment/GV_DIFF_SUMMARY/*.html"
		}
	}	
}

def run_sql_generate_stage_function(){
		// SQL Build and generate stage function.
		println("DEBUG: Starting SQL BUILD")
		try
        {
		 
        // commonFunctions.checkAnsibleConnection host_list:"${TARGET_Env}_SQL", automation_dir:"AUTOMATION"
         
		//calling build SQL Job.
		def sql_version = SQL_Functions.build_sql RELEASE: "${params.RELEASE}", NEXUS_URL: "${env.NEXUS_URL}",  NEXUS_REPO: "${env.NEXUS_REPO}",  SQL_GROUPID: "${env.SQL_GROUPID}", NEXUS_USER: "${NEXUS_USER}",  NEXUS_PASSWD: "${NEXUS_PASSWD}", engine: "${ENGINE_NAME}", Environment: "${TARGET_Env}", Description: "${params.DESCRIPTION}", NEXUS_VERSION: "${env.NEXUS_VERSION}"
		
		println("DEBUG: SQL Version is: " + sql_version)
		
		// Update maps with SQL Version created in this step.
		ENGINE_MAP[ENGINE_NAME]['SQL_VERSION'] = sql_version
		 
		// Run SQL generate function to create workspace required for SQL Deployment.
		SQL_Functions.sql_generate_lower_env Environment:"${TARGET_Env}", nexus_group_id:"${env.SQL_GROUPID}", nexus_user:"${NEXUS_USER}", nexus_passwd:"${NEXUS_PASSWD}", nexus_repo_id:"${env.NEXUS_REPO}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CHANGE_REF_ID}", repo_artifact_ids:"${ENGINE_NAME}:${sql_version}", datetime:"${date_now}", release:"${params.RELEASE}" 
        }        
       catch(Exception ex) {
            ENGINE_MAP[ENGINE_NAME]['RESULT'] = "FAILED"
			env.DP_ERROR_CODE = "502"
            env.DP_ERROR_MSG = "SQL generate Failure"
       }
}


def run_ems_generate_stage_function(){
		// EMS Build and generate stage function.
		println("DEBUG: Starting EMS BUILD")
		try
        {
        //commonFunctions.checkAnsibleConnection host_list:"${TARGET_Env}_EMS", automation_dir:"AUTOMATION"
		//calling build EMS Job.
		def ems_version = EMS_Functions.build_ems RELEASE: "${params.RELEASE}", NEXUS_URL: "${env.NEXUS_URL}",  NEXUS_REPO: "${env.NEXUS_REPO}",  EMS_GROUPID: "${env.EMS_GROUPID}", NEXUS_USER: "${NEXUS_USER}",  NEXUS_PASSWD: "${NEXUS_PASSWD}", engine: "${ENGINE_NAME}", Environment: "${TARGET_Env}", Description: "${params.DESCRIPTION}", NEXUS_VERSION: "${env.NEXUS_VERSION}"
		
		println("DEBUG: EMS Version is: " + ems_version)
	
		// Update maps with EMS Version created in this step.
		ENGINE_MAP[ENGINE_NAME]['EMS_VERSION'] = ems_version
		 
		trigger_versions_email map: ENGINE_MAP, REPORT_STAGE: "EMS_BUILD"
		 
		//Run EMS generate function to create workspace required for EMS Deployment.
		
		EMS_Functions.ems_generate_lower_env Environment:"${TARGET_Env}", nexus_group_id:"${env.EMS_GROUPID}", nexus_user:"${NEXUS_USER}", nexus_passwd:"${NEXUS_PASSWD}", nexus_repo_id:"${env.NEXUS_REPO}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CHANGE_REF_ID}", repo_artifact_ids:"${ENGINE_NAME}:${ems_version}", datetime:"${date_now}", release:"${params.RELEASE}", emsIgnore:"${env.emsIgnore}" 
        }        
       catch(Exception ex) {
            ENGINE_MAP[ENGINE_NAME]['RESULT'] = "FAILED"
			env.DP_ERROR_CODE = "503"
            env.DP_ERROR_MSG = "EMS generate Failure"
       }
}



def load_groovy_files() {
	// This function is to load all groovy files, where in common functions will be kept.
	emailFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/emailFunctions.groovy"
	mapFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/mapFunctions.groovy"
	nexusFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/nexusFunctions.groovy"
	gitFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/gitFunctions.groovy"
	EMS_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/EMSFunctions.groovy"
	SQL_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/SQLFunctions.groovy"
	BW_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/BWFunctions.groovy"
	FILE_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/FileFunctions.groovy"
	commonFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/commonFunctions.groovy"
    
	
	//[CICD-539] Insert Deployment metadata to release notes DB.
	DB_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/dbFunctions.groovy"
    //
    CredentialFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/CredentialsFunctions.groovy"
}
def checkout_git_repositories() {	
    GitClone("TIL_TestEnv_Configurations", "ENV", "master")
    GitClone("TIL_Automation_Framework", "AUTOMATION", "master")
    GitClone("TIL_DevOps_Framework", "JENKINS_FILE", "master")
    GitClone("TIL_BW_Application_Configuration", "APPLICATION", "master")
}

def run_sql_deploy_stage_function(){
	// This function is for SQL deployment.
	// Call sql deploy function by providing environment Details and engines
	println("DEBUG: SQL VERSION IS: " + ENGINE_MAP[ENGINE_NAME]['SQL_VERSION'])
	
	SQL_Functions.sql_deploy_lower_env Environment:"${TARGET_Env}", nexus_group_id:"${env.SQL_GROUPID}", nexus_user:"${NEXUS_USER}", nexus_passwd:"${NEXUS_PASSWD}", nexus_repo_id:"${env.NEXUS_REPO}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CHANGE_REF_ID}", repo_artifact_ids: ENGINE_NAME + ':' + ENGINE_MAP[ENGINE_NAME]['SQL_VERSION'], datetime:"${date_now}", release:"${params.RELEASE}"
	
	def sql_deployment_success_file = "${WORKSPACE}/AUTOMATION/SQL_Deployment/sqlDeploy_success.txt"
	if(fileExists(sql_deployment_success_file)) {
		def sql_deployment_success_ouput = readFile("${WORKSPACE}/AUTOMATION/SQL_Deployment/sqlDeploy_success.txt")
		if (sql_deployment_success_ouput.size() != 0) {
			
			ENGINE_MAP[ENGINE_NAME]['SQL_Deployment'] = "PASSED"
		}
	}

	def sql_deployment_failed_file = "${WORKSPACE}/AUTOMATION/SQL_Deployment/sqlDeploy_failed.txt"
	if(fileExists(sql_deployment_failed_file)) {
		def sql_deployment_failed_ouput = readFile("${WORKSPACE}/AUTOMATION/SQL_Deployment/sqlDeploy_failed.txt")
		if (sql_deployment_failed_ouput.size() != 0) {
			ENGINE_MAP[ENGINE_NAME]['SQL_Deployment'] = "FAILED"
			ENGINE_MAP[ENGINE_NAME]['RESULT'] = "FAILED"
			env.DP_ERROR_CODE = "506"
            env.DP_ERROR_MSG = "SQL Deployment Failure"
		}
	}		
	echo "SQL_DEPLOYMENT stage completed"
	
}


def run_sql_rollback_function(){
	// This function runs the rollback for SQL.
	SQL_Functions.sql_explicit_rollback_lower_env Environment:"${TARGET_Env}", crq_no:"${params.CHANGE_REF_ID}", repo_artifact_ids: ENGINE_NAME + ':' + ENGINE_MAP[ENGINE_NAME]['SQL_VERSION'], datetime:"${date_now}", release:"${params.RELEASE}"
	echo "SQL Roll Back Completed"
}

def run_ems_deploy_stage_function(){
	// This function is for EMS deployment.
	
	// Call ems deploy function by providing Environment Details and engines
	EMS_Functions.ems_deployment_lower_env Environment:"${TARGET_Env}", crq_no:"${params.CHANGE_REF_ID}", ems_engines:ENGINE_NAME + ':' + ENGINE_MAP[ENGINE_NAME]['EMS_VERSION'], datetime:"${date_now}", release:"${params.RELEASE}", emsIgnore:"${env.emsIgnore}", rollbackBackup:false
	
	// Update Maps with Successful engines
	def ems_deployment_success_file = "${WORKSPACE}/AUTOMATION/EMS_Deployment/deploy_failure.txt"
	if(fileExists(ems_deployment_success_file)) {
		def ems_deployment_success_ouput = readFile("${WORKSPACE}/AUTOMATION/EMS_Deployment/deploy_failure.txt")
		if (ems_deployment_success_ouput.size() != 0) {
			
			ENGINE_MAP[ENGINE_NAME]['EMS_Deployment'] = "FAILED"
			ENGINE_MAP[ENGINE_NAME]['RESULT'] = "FAILED"
			env.DP_ERROR_CODE = "507"
            env.DP_ERROR_MSG = "EMS Deployment Failure"
		}
	}
	// Update Maps with failed engines
	def ems_deployment_failed_file = "${WORKSPACE}/AUTOMATION/EMS_Deployment/deploy_success.txt"
	if(fileExists(ems_deployment_failed_file)) {
		def ems_deployment_failed_ouput = readFile("${WORKSPACE}/AUTOMATION/EMS_Deployment/deploy_success.txt")
		if (ems_deployment_failed_ouput.size() != 0) {
			ENGINE_MAP[ENGINE_NAME]['EMS_Deployment'] = "PASSED"
		}
	}
	
		
}


def run_file_generate_stage_function(){
    
        //commonFunctions.checkAnsibleConnection host_list:"${TARGET_Env}_File", automation_dir:"AUTOMATION"
		// This function is to validate files for deployment and also to copy the files to workspace.
		//[CICD-1820]: Fix for the regression issue caused due to CICD-1783 changes.
		if(ENGINE_MAP[ENGINE_NAME]['XML_FILES'] != 'NA' && ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"){
			chk = FILE_Functions.validate_files_lt_env Host: "${TARGET_Env}", Deployment_Type: "XML_Files", engine_files: ENGINE_MAP[ENGINE_NAME]['XML_FILES'], RELEASE: "${params.RELEASE}", engine_name: ENGINE_NAME
			if(chk == "FAIL"){
				ENGINE_MAP[ENGINE_NAME]['XML_Deployment'] = "FAILED"
				ENGINE_MAP[ENGINE_NAME]['RESULT'] = "FAILED"
                env.DP_ERROR_CODE = "504"
                env.DP_ERROR_MSG = "File Generate Failure"
			}
		}

		if(ENGINE_MAP[ENGINE_NAME]['JAR_FILES'] != 'NA' && ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"){
			chk = FILE_Functions.validate_files_lt_env Host: "${TARGET_Env}", Deployment_Type: "JAR_Files", engine_files: ENGINE_MAP[ENGINE_NAME]['JAR_FILES'], RELEASE: "${params.RELEASE}", engine_name: ENGINE_NAME
			if(chk == "FAIL"){
				ENGINE_MAP[ENGINE_NAME]['JAR_Deployment'] = "FAILED"
				ENGINE_MAP[ENGINE_NAME]['RESULT'] = "FAILED"
                env.DP_ERROR_CODE = "504"
                env.DP_ERROR_MSG = "File Generate Failure"
			}
		}
		if(ENGINE_MAP[ENGINE_NAME]['EMAIL_FILES'] != 'NA' && ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"){
			chk = FILE_Functions.validate_files_lt_env Host: "${TARGET_Env}", Deployment_Type: "Email_Template", engine_files: ENGINE_MAP[ENGINE_NAME]['EMAIL_FILES'], RELEASE: "${params.RELEASE}", engine_name: ENGINE_NAME
			if(chk == "FAIL"){
				ENGINE_MAP[ENGINE_NAME]['EMAIL_Deployment'] = "FAILED"
				ENGINE_MAP[ENGINE_NAME]['RESULT'] = "FAILED"
                env.DP_ERROR_CODE = "504"
                env.DP_ERROR_MSG = "File Generate Failure"
			}
		}	
}

def run_file_deploy_stage_function() {
	// This function is to deploy files into LinkTest Environment.
		// This function is to validate files for deployment and also to copy the files to workspace.
		if(ENGINE_MAP[ENGINE_NAME]['XML_FILES'] != 'NA' && ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"){
			FILE_Functions.deploy_files_lower_env Host:"${TARGET_Env}", Deployment_Type: "XML_Files", engine_files: ENGINE_NAME + ':' + ENGINE_MAP[ENGINE_NAME]['XML_FILES'], crq_no:"${params.CHANGE_REF_ID}", datetime:"${date_now}" 
			ENGINE_MAP[ENGINE_NAME]['XML_Deployment'] = "PASSED"
		}
		
		if(ENGINE_MAP[ENGINE_NAME]['JAR_FILES'] != 'NA' && ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"){
			FILE_Functions.deploy_files_lower_env Host:"${TARGET_Env}", Deployment_Type: "JAR_Files", engine_files: ENGINE_NAME + ':' + ENGINE_MAP[ENGINE_NAME]['JAR_FILES'], crq_no:"${params.CHANGE_REF_ID}", datetime:"${date_now}"
			ENGINE_MAP[ENGINE_NAME]['JAR_Deployment'] = "PASSED"			
		}

		if(ENGINE_MAP[ENGINE_NAME]['EMAIL_FILES'] != 'NA' && ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"){
			FILE_Functions.deploy_files_lower_env Host:"${TARGET_Env}", Deployment_Type: "EMAIL_Files", engine_files: ENGINE_NAME + ':' + ENGINE_MAP[ENGINE_NAME]['EMAIL_FILES'], crq_no:"${params.CHANGE_REF_ID}", datetime:"${date_now}" 
			ENGINE_MAP[ENGINE_NAME]['EMAIL_Deployment'] = "PASSED"
		}

         if(ENGINE_MAP[ENGINE_NAME]['RESULT'] == "FAILED")
        {
             env.DP_ERROR_CODE = "508"
             env.DP_ERROR_MSG = "File Deployment Failure"   
        }
}

def getBuildUserID(){
    if(currentBuild.getBuildCauses('hudson.triggers.TimerTrigger$TimerTriggerCause'))
	{
	println ("time_triggered")
            return "time_triggered"
	}
    else if(currentBuild.getBuildCauses('hudson.model.Cause$UpstreamCause'))
    {
           println ("time_triggered")
		   def upstreamCause = currentBuild.rawBuild.getCause(Cause.UpstreamCause)
           def upstreamJob = Jenkins.getInstance().getItemByFullName(upstreamCause.getUpstreamProject(), hudson.model.Job.class)
           if (upstreamJob) {
                    def upstreamBuild = upstreamJob.getBuildByNumber(upstreamCause.getUpstreamBuild())
                    if (upstreamBuild) {
                            def realUpstreamCause = upstreamBuild.getCause(Cause.UserIdCause)
                            if (realUpstreamCause) {
                                    return realUpstreamCause.getUserId()
                            }
                    }
					else
					{
					println ("Unknown user")
					}
					
            }
			else 
			{
			println ("Unknown upstream job")
			}
            return "Upstream Triggered"
     }
    else
            return currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId()
}


def preparation_function() {
	   
	// This stage is to construct map and update values with the build input parameters
		date_now = new Date().format("YYYYMMddHHmmss")
		//[CICD-1524]: getting user here to use across the pipeline.
		
                
/* 		properties([parameters([
			string(defaultValue: 'CCS20.5', description: 'Please enter Release', name: 'RELEASE', trim: false), 
			string(defaultValue: 'Test', description: 'Please enter CRQ Number', name: 'CHANGE_REF_ID', trim: false), 
			choice(choices: ['LinkTest'], description: 'Please select environment', name: 'ENVIRONMENT'), 
			string(defaultValue: 'test', description: 'Please enter description', name: 'DESCRIPTION', trim: false)
		])]) */
		
		
        result = validate_input_parameters RELEASE: params.RELEASE, CRQ: params.CHANGE_REF_ID, DESCRIPTION: params.Description,  OPERATION_NAME: params.OPERATION_NAME, FILE_DEPLOYMENT: params.FILE_DEPLOYMENT, ONLY_GV: params.ONLY_GV
        if(result != "")
        {
            env.DP_ERROR_CODE = "500"
            env.DP_ERROR_MSG = result
            println(env.DP_ERROR_CODE + " : " +  env.DP_ERROR_MSG)
            error("Pipeline Input parameter validation failed. Please check the errors in Console log.")
			currentBuild.result = 'ABORTED'
        }
        
		if(params.BW_VERSION){
			result = validate_input_parameters RELEASE: params.RELEASE, BW_VERSION: params.BW_VERSION 
            if(result != "")
            {
                env.DP_ERROR_CODE = "500"
                env.DP_ERROR_MSG = result
                println(env.DP_ERROR_CODE + " : " +  env.DP_ERROR_MSG)
                error("Pipeline Input parameter validation failed. Please check the errors in Console log.")
                currentBuild.result = 'ABORTED'
            }
		}

        // Checkout required GIT repositories.
		checkout_git_repositories()

		//Load all functions files from GIT. point to exact source file
		load_groovy_files()
        
		user = params.EMAIL_REQUESTER
        //user = emailFunctions.getBuildUserID()
        EMAIL_REQUESTER = "${user}"
        dev_mailRecipients = "${EMAIL_REQUESTER}"
        
        NEXUS_USER = CredentialFunctions.getJenkinsCredentials group: "NEXUSKEY", key: "username"
        NEXUS_PASSWD = CredentialFunctions.getJenkinsCredentials group: "NEXUSKEY", key: "password"
        
        dbUserName = CredentialFunctions.getJenkinsCredentials group: "CICD_DBKEY", key: "username"
        dbPassword = CredentialFunctions.getJenkinsCredentials group: "CICD_DBKEY", key: "password"        
		
		//[CICD-321]: Automate Applications.txt file to get engines list from domain itself..
		//Disabling getting appslist from admin.
		//BW_Functions.get_domainAppsList Host: "${TARGET_Env}", environment: "${TARGET_Env}", datetime:"${date_now}" 
		
		bw_release_num = RELEASE.replace(".","_")

		majorVersion = RELEASE.split('CCS')[1].split('\\.')[0]
		minorVersion = RELEASE.split('CCS')[1].split('\\.')[1]	
	
		displayName = "${params.RELEASE}_${params.ENGINE_NAME}_${BUILD_NUMBER}"
		currentBuild.displayName = "${displayName}"		
	
		if ("${TARGET_Env}" == "T1" || "${TARGET_Env}" == "T3" || "${TARGET_Env}" == "T4" || "${TARGET_Env}" == "T7"){
			println("Setting value to Env Prefix to SIT")
			Env_Prefix = "SIT" 
		} else {
			println("Setting value to Env Prefix to Environment") 
			Env_Prefix = "${TARGET_Env}"
		}
		//[CICD-476] && [CICD-374] Fix: Added BW, EMS and SQL Duration fields to the map.
		if(ENGINE_NAME != " "){
			ENGINE_MAP[ENGINE_NAME] = ['BW_VERSION':'NA', 'BW_FOLDER_NAME':'NA', 'BW_ENGINE_TYPE':'NA', 'EMS_VERSION':'NA', 'SQL_VERSION':'NA', 'XML_FILES':'NA', 'JAR_FILES':'NA', 'EMAIL_FILES':'NA', 'RESULT':'NA', 'BW_Generation':'NOT_REQUIRED', 'SQL_Deployment':'NOT_REQUIRED', 'EMS_Deployment':'NOT_REQUIRED', 'XML_Deployment':'NOT_REQUIRED', 'JAR_Deployment':'NOT_REQUIRED', 'EMAIL_Deployment':'NOT_REQUIRED', 'BW_Deployment':'NOT_REQUIRED',  'BW_Restart':'NOT_REQUIRED', 'EMS_DURATION':'0', 'SQL_DURATION':'0', 'BW_DURATION':'0', 'FILE_DURATION':'0']
		}
		
        // CICD 1872 check all BW, SQL, File server ansible connectivity
        ansible_hosts=""
		// I fonly GV change required, then set the type as ONLY_GV.
		if(params.BW_VERSION) {
            ansible_hosts+= " " + "${TARGET_Env}_BW"
			//BW deployment required with given version. First validate this version is available in Nexus.
			version_check = nexusFunctions.validate_nexus_version REPO_URL: "${env.REPO_URL}", target_repo: "${env.NEXUS_REPO}", GROUPID: "${env.BW_GROUPID}", engine: ENGINE_NAME, version: params.BW_VERSION, extn: "ear"
			if(version_check.toInteger() != 0) {
				error("Given BW_VERSION is not exisis in NEXUS. Please Verify the version again.")
			}
			
			// Get the BW version for the engine given.
			bw_folder = gitFunctions.get_engine_bw_folder_name_from_gvconf engine: ENGINE_NAME
			if(bw_folder){
				ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME'] =  bw_folder
			} else {
				error("Check the engine name and Folder name in GV conf for proper format")
			}
			
			// get engine type from environment appconf file.
			def type_string = nexusFunctions.get_bw_deployment_type engines: ENGINE_NAME, target_env: "${TARGET_Env}"
			if(type_string){
				ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE'] =  type_string.split(':')[1]
			}

			ENGINE_MAP[ENGINE_NAME]['BW_VERSION'] =  "${params.BW_VERSION}"
			ENGINE_MAP[ENGINE_NAME]['BW_Generation'] =  'NOT_STARTED'
			ENGINE_MAP[ENGINE_NAME]['BW_Deployment'] =  'NOT_STARTED'
			ENGINE_MAP[ENGINE_NAME]['BW_Restart'] =  'NOT_STARTED'
			
		} else if (params.ONLY_GV){
			ansible_hosts+= " " + "${TARGET_Env}_BW"
			// Get the BW Folder name for the engine given.
			bw_folder = gitFunctions.get_engine_bw_folder_name_from_gvconf engine: ENGINE_NAME
			if(bw_folder){
				ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME'] =  bw_folder
			} else {
				error("Check the engine name and Folder name in GV conf for proper format")
			}
			
			ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE'] =  "OnlyGV"
			ENGINE_MAP[ENGINE_NAME]['BW_Generation'] =  'NOT_STARTED'
			ENGINE_MAP[ENGINE_NAME]['BW_Deployment'] =  'NOT_STARTED'
			ENGINE_MAP[ENGINE_NAME]['BW_Restart'] =  'NOT_STARTED'
			ENGINE_MAP[ENGINE_NAME]['BW_VERSION'] =  '0'
			
		} else {
			echo "DEBUG: NO BW Deployment selected."
		}
		
		if(params.EMS_DEPLOYMENT) {
                ansible_hosts+= " " + "${TARGET_Env}_EMS"
				ENGINE_MAP[ENGINE_NAME]['EMS_Deployment'] =  'NOT_STARTED'
		}		
		if(params.SQL_DEPLOYMENT) {
                ansible_hosts+= " " + "${TARGET_Env}_SQL"
                // BW added since after file deployment BW has to be restarted
                ansible_hosts+= " " + "${TARGET_Env}_BW"
				ENGINE_MAP[ENGINE_NAME]['SQL_Deployment'] =  'NOT_STARTED'
				if(ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE'] == 'NA') {
					ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE'] = 'RESTART'
					ENGINE_MAP[ENGINE_NAME]['BW_Restart'] =  'NOT_STARTED'
					ENGINE_MAP[ENGINE_NAME]['BW_VERSION'] =  '1'
					// Get the BW Folder name for the engine given.
					bw_folder = gitFunctions.get_engine_bw_folder_name_from_gvconf engine: ENGINE_NAME
					if(bw_folder){
						ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME'] =  bw_folder
					} else {
						error("Check the engine name and Folder name in GV conf for proper format")
					}
				}
		}
		if(params.FILE_DEPLOYMENT) {
			
			
			ansible_hosts+= " " + "${TARGET_Env}_File"
            // BW added since after file deployment BW has to be restarted
            ansible_hosts+= " " + "${TARGET_Env}_BW"
			// Set BW_ENGINE TYPE As RESTART only when any of the file deployment is selected.
			if(ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE'] == 'NA') {
					ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE'] = 'RESTART'
					ENGINE_MAP[ENGINE_NAME]['BW_Restart'] =  'NOT_STARTED'
					ENGINE_MAP[ENGINE_NAME]['BW_VERSION'] =  '1'
					// Get the BW Folder name for the engine given.
					bw_folder = gitFunctions.get_engine_bw_folder_name_from_gvconf engine: ENGINE_NAME
					if(bw_folder){
						ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME'] =  bw_folder
					} else {
						error("Check the engine name and Folder name in GV conf for proper format")
					}
			}
			FILE_DEPLOYMENT.split(',').each { type ->
			
				//[CICD-1820]: Fix for the regression issue caused due to CICD-1783 changes.
				if(type == "XML"){
					def XML_Files = gitFunctions.getEngineFiles_lt engines: ENGINE_NAME, type: "XML", env: "${TARGET_Env}", RELEASE: "${params.RELEASE}"
					if(XML_Files){
						echo "DEBUG: XML_Files are: ${XML_Files}"
						ENGINE_MAP[ENGINE_NAME]['XML_FILES'] =  XML_Files.split(':')[1]
						ENGINE_MAP[ENGINE_NAME]['XML_Deployment'] =  'NOT_STARTED'
					}
				}
				if(type == "JAR"){
					def JAR_Files = gitFunctions.getEngineFiles_lt engines: ENGINE_NAME, type: "Jar", env: "${TARGET_Env}", RELEASE: "${params.RELEASE}"
					if(JAR_Files){
						echo "DEBUG: JAR_Files are: ${JAR_Files}"
						ENGINE_MAP[ENGINE_NAME]['JAR_FILES'] =  JAR_Files.split(':')[1]
						ENGINE_MAP[ENGINE_NAME]['JAR_Deployment'] =  'NOT_STARTED'
					}
				}
				if(type == "EMAIL"){
					def Email_Files = gitFunctions.getEngineFiles_lt engines: ENGINE_NAME, type: "Email", env: "${TARGET_Env}", RELEASE: "${params.RELEASE}"
					if(Email_Files){
						ENGINE_MAP[ENGINE_NAME]['EMAIL_FILES'] =  Email_Files.split(':')[1]
						ENGINE_MAP[ENGINE_NAME]['EMAIL_Deployment'] =  'NOT_STARTED'
					}
				}				
			}
			
	}
    
    //commonFunctions.checkAnsibleConnection host_list:"${ansible_hosts}", automation_dir:"AUTOMATION"
    
    // Change the folder names for testing.
	
/* 	
	if(ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME'] == "SB01"){
			ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME'] = "ServiceBus1"
		}
	if(ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME'] == "SB02"){
			ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME'] = "ServiceBus2"
		} */	

}


def bw_generate_stage(){
	
	// Construct Description for engine
	
	//[CICD-539] Insert Deployment metadata to release notes DB. Changing user as global variable.
//[CICD-1524]: Commenting user assignment here, as it is populating only when BW_Generation is done. Moving to preparation function.
	
	//user = currentBuild.rawBuild.causes[0].userId
	//println(user);
	//def desc = "${params.DESCRIPTION}".trim() + "|" + "${user}"
	//[CICD-519]: Fix to handle special characters in DESCRIPTION part
    //ADO 630550 Single quotes issues when inserting into DB or unix script
	String desc = "${params.DESCRIPTION}".replaceAll("'","").replaceAll(/(!|"|'|@|#|\$|%|&|\\/|\(|\)|=|\?)/, /\\$0/)
	desc = desc + "|" + "${user}"	
	
	
		
		
			BW_type = ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE']
			echo "DEBUG: BW_type is: ${BW_type}"
			BW_Folder = ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME']
			echo "DEBUG: BW_Foldername is: ${BW_Folder}"
			group_id = 1
			patteren_string = BW_type+"_"+BW_Folder+"_"+group_id
			echo "DEBUG: Pattern string is: ${patteren_string}"
			
			def engines_versions = "${params.ENGINE_NAME}"+":"+"${params.BW_VERSION}"
			echo "DEBUG: Engine Name is: ${engines_versions}"
			
			def engines_list = "${params.ENGINE_NAME}"
			
		
        //commonFunctions.checkAnsibleConnection host_list:"${TARGET_Env}_BW", automation_dir:"AUTOMATION"
       
		
		if(BW_type == "Existing"){
			
			println("DEBUG:" + group_id + "Generate conf file for type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list + " and engine version string is: " + engines_versions)
			
			BW_Functions.generate_conf_files_existing_engines engines:engines_versions, Host:"${TARGET_Env}", ReleaseNumber:"${params.RELEASE}", folderName:BW_Folder, description:"${desc}", use_tag: "no"
			
			BW_Functions.generate_bw_deployment Host:"${TARGET_Env}", nexus_group_id:"${env.BW_GROUPID}", nexus_user:"${NEXUS_USER}", nexus_passwd:"${NEXUS_PASSWD}", nexus_repo_id:"${env.NEXUS_REPO}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CHANGE_REF_ID}", engines:engines_versions, datetime:"${date_now}", engines_list:engines_list, EnvPrefix:"${Env_Prefix}", deployment_type:"EXISTING", release:"${params.RELEASE}", onlyGVChange:false, folderName:BW_Folder, bw_folder_release:bw_release_num, engine_group:patteren_string
		} else if(BW_type == "New") {
			
			println("DEBUG:" + group_id + "Generate conf file for type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list + " and engine version string is: " + engines_versions)
			BW_Functions.generate_conf_files_new_engines engines:engines_versions, Host:"${TARGET_Env}", ReleaseNumber:"${params.RELEASE}", folderName:BW_Folder, description:"${desc}", instanceCount:"${env.BW_InstanceCount}", use_tag: "no"
			// Call generate function by passing details
			
			BW_Functions.generate_bw_deployment Host:"${TARGET_Env}", nexus_group_id:"${env.BW_GROUPID}", nexus_user:"${NEXUS_USER}", nexus_passwd:"${NEXUS_PASSWD}", nexus_repo_id:"${env.NEXUS_REPO}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CHANGE_REF_ID}", engines:engines_versions, datetime:"${date_now}", engines_list:engines_list, EnvPrefix:"${Env_Prefix}", deployment_type:"NEW", release:"${params.RELEASE}", onlyGVChange:false, folderName:BW_Folder, bw_folder_release:bw_release_num, engine_group:patteren_string
		} else if (BW_type == "OnlyGV") {
			
			println("DEBUG:" + group_id + "Generate conf file for type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list + " and engine version string is: " + engines_versions)
			BW_Functions.generate_conf_files_gv_change engines:engines_versions, Host:"${TARGET_Env}", ReleaseNumber:"${params.RELEASE}", folderName:BW_Folder, description:"${desc}", use_tag: "no"
			
			// Call generate function by passing details
			BW_Functions.generate_bw_deployment Host:"${TARGET_Env}", nexus_group_id:"${env.BW_GROUPID}", nexus_user:"${NEXUS_USER}", nexus_passwd:"${NEXUS_PASSWD}", nexus_repo_id:"${env.NEXUS_REPO}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CHANGE_REF_ID}", engines:engines_versions, datetime:"${date_now}", engines_list:engines_list, EnvPrefix:"${Env_Prefix}", deployment_type:"EXISTING", release:"${params.RELEASE}", onlyGVChange:true, folderName:BW_Folder, bw_folder_release:bw_release_num, engine_group:patteren_string
			
		} 
		else if (BW_type == "RESTART") {
			
			println("DEBUG:" + group_id + "Generate conf file for type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list)
			BW_Functions.generate_conf_files_restart engines:engines_versions, Host:"${TARGET_Env}", ReleaseNumber:"${params.RELEASE}", folderName:BW_Folder, description:"${desc}"
			
			// Call generate function by passing details
			BW_Functions.generate_bw_restart Host:"${TARGET_Env}", crq_no:"${params.CHANGE_REF_ID}", datetime:"${date_now}", engines_list:engines_list, deployment_type:"EXISTING", folderName:BW_Folder, bw_folder_release:bw_release_num, engine_group:patteren_string
			
		}
		else {
			println("DEBUG: Invalid Deployment type Identified. Please fix this issue")
		}
	
	
	// Update maps with failed engines from BW Generate
	def bw_generate_failed_file = "${WORKSPACE}/${TARGET_Env}/BW_Deployment/generate_failure.txt"
	if(fileExists(bw_generate_failed_file)) {
		def bw_generate_failed_ouput = readFile("${WORKSPACE}/${TARGET_Env}/BW_Deployment/generate_failure.txt")
		if (bw_generate_failed_ouput.size() != 0) {
			def failed_file = new File("${WORKSPACE}/${TARGET_Env}/BW_Deployment/generate_failure.txt")
			def failed_engines_list = failed_file.readLines().join(';')
			ENGINE_MAP[ENGINE_NAME]['BW_Generation'] = "FAILED"
			ENGINE_MAP[ENGINE_NAME]['RESULT'] = "FAILED"
			env.DP_ERROR_CODE = "505"
            env.DP_ERROR_MSG = "BW Generate Failure"
		}
	} 

	// Update maps with success engines from BW Generate
	def bw_generate_success_file = "${WORKSPACE}/${TARGET_Env}/BW_Deployment/generate_success.txt"
	if(fileExists(bw_generate_success_file)) {
		def bw_generate_success_ouput = readFile("${WORKSPACE}/${TARGET_Env}/BW_Deployment/generate_success.txt")
		if (bw_generate_success_ouput.size() != 0) {
			def success_file = new File("${WORKSPACE}/${TARGET_Env}/BW_Deployment/generate_success.txt")
			def success_engines_list = success_file.readLines().join(';')
			ENGINE_MAP[ENGINE_NAME]['BW_Generation'] = "PASSED"
		}
	}

}


// Function for BW Deployment
def bw_deployment_stage(){ 

			BW_type = ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE']
			echo "DEBUG: BW_type is: ${BW_type}"
			BW_Folder = ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME']
			echo "DEBUG: BW_Foldername is: ${BW_Folder}"
			group_id = 1
			patteren_string = BW_type+"_"+BW_Folder+"_"+group_id
			echo "DEBUG: Pattern string is: ${patteren_string}"
			
			def engines_versions = "${params.ENGINE_NAME}"+":"+"${params.BW_VERSION}"
			echo "DEBUG: Engine Name is: ${engines_versions}"
			
			def engines_list = "${params.ENGINE_NAME}"
		
        //[CICD-1760] Ability to ping the array of validate ssh connectivity to all bw engine machines from BW Admin before running BW deployment 
        if(BW_type == "Existing" ||  BW_type == "New" || BW_type == "OnlyGV" || BW_type == "RESTART"){
                //commonFunctions.checkAllSSHConnection Host:"${TARGET_Env}",  bw_folder_release:bw_release_num, crq_num:"${params.CHANGE_REF_ID}", datetime:"${date_now}", automation_dir:"AUTOMATION"
        }
        
        if(BW_type == "Existing"){
						
			println("DEBUG:" + group_id + "Deploy engines of type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list + " and engine version string is: " + engines_versions)
						
			// Run BW deploy function
			 BW_Functions.bw_deploy Host:"${TARGET_Env}", crq_no:"${params.CHANGE_REF_ID}", engines:engines_versions, datetime:"${date_now}", engines_list:engines_list, appDynamics:false, FolderName:BW_Folder, release:"${params.RELEASE}", onlyGVChange:false, deployment_type:"ExistingEngines", bw_folder_release:bw_release_num, engine_group:patteren_string, EnvironmentRepository: "${env.EnvironmentRepository}"
			
		} else if(BW_type == "New") {
			println("DEBUG:" + group_id + "Deploy engines of type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list + " and engine version string is: " + engines_versions)
						
			// Run BW deploy function
			BW_Functions.bw_deploy Host:"${TARGET_Env}", crq_no:"${params.CHANGE_REF_ID}", engines:engines_versions, datetime:"${date_now}", engines_list:engines_list, appDynamics:false, FolderName:BW_Folder, release:"${params.RELEASE}", onlyGVChange:false, deployment_type:"NewEngines", bw_folder_release:bw_release_num, engine_group:patteren_string, EnvironmentRepository: "${env.EnvironmentRepository}"
			
		
		} else if (BW_type == "OnlyGV") {
			println("DEBUG:" + group_id + "Deploy engines of type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list + " and engine version string is: " + engines_versions)
						
			// Run BW deploy function
			BW_Functions.bw_deploy Host:"${TARGET_Env}", crq_no:"${params.CHANGE_REF_ID}", engines:engines_versions, datetime:"${date_now}", engines_list:engines_list, appDynamics:false, FolderName:BW_Folder, release:"${params.RELEASE}", onlyGVChange:true, deployment_type:"ExistingEngines", bw_folder_release:bw_release_num, engine_group:patteren_string, EnvironmentRepository: "${env.EnvironmentRepository}"
			
						
		} else {
			println("DEBUG: Invalid Deployment type Identified. Nothing to deploy")
		}
	

	// Updating maps for failed engines
	def bw_deployment_failed_file = "${WORKSPACE}/${TARGET_Env}/BW_Deployment/deployment_failure.txt"
	if(fileExists(bw_deployment_failed_file)) {
		def bw_deployment_failed_ouput = readFile("${WORKSPACE}/${TARGET_Env}/BW_Deployment/deployment_failure.txt")
		if (bw_deployment_failed_ouput.size() != 0) {
			def failed_file = new File("${WORKSPACE}/${TARGET_Env}/BW_Deployment/deployment_failure.txt")
			ENGINE_MAP[ENGINE_NAME]['BW_Deployment'] = "FAILED"
			ENGINE_MAP[ENGINE_NAME]['RESULT'] = "FAILED"
            env.DP_ERROR_CODE = "509"
            env.DP_ERROR_MSG = "BW Deployment Failure"
			
		}
	}

 // Updating maps for engine engines

	def bw_deployment_success_file = "${WORKSPACE}/${TARGET_Env}/BW_Deployment/deployment_success.txt"
	if(fileExists(bw_deployment_success_file)) {
		def bw_deployment_success_ouput = readFile("${WORKSPACE}/${TARGET_Env}/BW_Deployment/deployment_success.txt")
		if (bw_deployment_success_ouput.size() != 0) {
			def success_file = new File("${WORKSPACE}/${TARGET_Env}/BW_Deployment/deployment_success.txt")
			ENGINE_MAP[ENGINE_NAME]['BW_Deployment'] = "PASSED"
		}
		
	// Sharing GV diff Report when deployement is successful
    
	email_gv_diff_report env: "${TARGET_Env}"
    // Calling Dashboard Publish job
	//[CICD-476] & [CICD-374] commenting following as we are calling common function to update dashboard and stats file.
	//build job: '/TIL_PIPELINES/Common_Jobs/Dashboard_Publish', parameters: [string(name: 'Environment', value: 'LinkTest'), string(name: 'Component', value: "${params.ENGINE_NAME}"), string(name: 'ArtefactVersion', value: "${params.BW_VERSION}"), string(name: 'Pipeline', value: 'TIL_BW_EMS_SQL_Pipeline'), string(name: 'Description', value: '')]	
	}
	// Trigger Result Email
	//trigger_results_email map: ENGINE_MAP, REPORT_STAGE: "BW_Deployment"

}


// Function for BW Restart

def bw_restart_stage(){ 
			
	BW_type = ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE']
	echo "DEBUG: BW_type is: ${BW_type}"
	BW_Folder = ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME']
	echo "DEBUG: BW_Foldername is: ${BW_Folder}"
	group_id = 1
	patteren_string = BW_type+"_"+BW_Folder+"_"+group_id
	def engines_list = "${params.ENGINE_NAME}"
	echo "DEBUG: Pattern string is: ${patteren_string}"
	// Calling Restart Function
    BW_Functions.bw_restart Host:"${TARGET_Env}", crq_no:"${params.CHANGE_REF_ID}", datetime:"${date_now}", bw_folder_release:bw_release_num, engine_group:patteren_string, folderName:BW_Folder, engines_list_restart:engines_list	

	  
	// Check if BW Restart file exists for Failures
	def bw_restart_failed_file = "${WORKSPACE}/${TARGET_Env}/BW_Deployment/restart_failure.txt"
	if(fileExists(bw_restart_failed_file)) {
		def bw_restart_failed_ouput = readFile("${WORKSPACE}/${TARGET_Env}/BW_Deployment/restart_failure.txt")
		if (bw_restart_failed_ouput.size() != 0) {
		    // Reading Restart Failure
			def failed_file = new File("${WORKSPACE}/${TARGET_Env}/BW_Deployment/restart_failure.txt")
			ENGINE_MAP[ENGINE_NAME]['BW_Restart'] = "FAILED"
			ENGINE_MAP[ENGINE_NAME]['RESULT'] = "FAILED"
			env.DP_ERROR_CODE = "510"
            env.DP_ERROR_MSG = "BW Restart Failure"
			
		}							
	}
	else{
		
		// Reading restart successful engines file 
		def bw_restart_success_file = "${WORKSPACE}/${TARGET_Env}/BW_Deployment/restart_success.txt"
	    if(fileExists(bw_restart_success_file)) {
			  def bw_restart_success_ouput = readFile("${WORKSPACE}/${TARGET_Env}/BW_Deployment/restart_success.txt")
			  def success_file = new File("${WORKSPACE}/${TARGET_Env}/BW_Deployment/restart_success.txt")
			  ENGINE_MAP[ENGINE_NAME]['BW_Restart'] = "PASSED"
			  ENGINE_MAP[ENGINE_NAME]['RESULT'] = "PASSED"
		}
	}
	
	
}

def run_ems_rollback_function(){
	
	
	

    // Call rollback function by providing environment Details and engines
	EMS_Functions.ems_rollback_lower_env Environment:"${TARGET_Env}", crq_no:"${params.CHANGE_REF_ID}", ems_engines:"${ENGINE_NAME}", datetime:"${date_now}", release:"${params.RELEASE}", emsIgnore:"${env.emsIgnore}", rollbackBackup:false
}

def run_bw_rollback_function(){
	
	BW_type = ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE']
	echo "DEBUG: BW_type is: ${BW_type}"
	BW_Folder = ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME']
	echo "DEBUG: BW_Foldername is: ${BW_Folder}"
	group_id = 1
	patteren_string = BW_type+"_"+BW_Folder+"_"+group_id
	echo "DEBUG: Pattern string is: ${patteren_string}"
	
	def engines_versions = "${params.ENGINE_NAME}"+":"+"${params.BW_VERSION}"
	echo "DEBUG: Engine Name is: ${engines_versions}"
	
	def engines_list = "${params.ENGINE_NAME}"	
	// Run BW RB Rollback function
	
	 BW_Functions.bw_rollback_RB Host:"${TARGET_Env}", crq_no:"${params.CHANGE_REF_ID}", datetime:"${date_now}", bw_folder_release:bw_release_num, engine_group:patteren_string, folderName:BW_Folder, EnvironmentRepository: "${env.EnvironmentRepository}", engines_list:engines_list

}

	
	

ENGINE_MAP = [:]
version_check = ""
ReleaseApprovers = ""
date_now = " "
emailBody = " "
displayName = ""
bw_release_num = ""
Env_Prefix = ""
bw_folder = ""
//[CICD-539] Insert Deployment metadata to release notes DB.
def BWConfigTag = ""
EMAIL_REQUESTER = ""
user = ""

// Pipeline parameters.
BW_Deployment_Required = ""
SQL_Deployment_Required = ""
EMS_Deployment_Required = ""
File_Deployment_Required = ""
BW_Deployment_Type = ""
BW_Engines = ""
FolderName = ""
AppDynamics_Update = ""
nexusFunc = ""
emailFunc = ""
mapFunc = ""
TARGET_Env = ""
Env_Prefix = ""
dev_mailRecipients = ""

NEXUS_USER = ""
NEXUS_PASSWD = ""
dbUserName = ""
dbPassword = ""
//ADO 623654 Add timeout to the pipeline 

pipeline {
    agent any
	options {
        preserveStashes(buildCount: 49)
        timeout(time: 5, unit: 'DAYS')
    }

    environment {
       
        REPO_URL = "http://195.233.197.150:8081/repository"
		NEXUS_URL = "195.233.197.150:8081"
		Promotion_Repo = "SIT_REPO"
		BW_GROUPID = "TIL_BW"
		EMS_GROUPID = "TIL_EMS"
		SQL_GROUPID="TIL_SQL"
		emsIgnore = "true"
		NEXUS_REPO = "LINKTEST_REPO"
		NEXUS_VERSION="nexus3"
		BW_InstanceCount = 2
        EnvironmentRepository = "TIL_TestEnv_Configurations"
		//[CICD-539] Insert Deployment metadata to release notes DB.        
		dbURL = 'jdbc:oracle:thin:@195.233.199.13:33000:TIBTST1'
		dbDriver = 'oracle.jdbc.driver.OracleDriver'
    }
    stages {
		stage('Preparation') {
			steps {
				script{
					deleteDir()
					env.PIPELINE_URL = "$BUILD_URL"
					// ALL ENV SHOULD FOLLOW SAME NAMING Like LNKTest16,LNKTest17 etc.,			
					if ("${params.ENVIRONMENT}" == "LNKTest16"){
						TARGET_Env = "LinkTest" 
					} else if ("${params.ENVIRONMENT}" == "LNKTest17"){
						TARGET_Env = "LNKTst17"
					} else {
						
						TARGET_Env = "${params.ENVIRONMENT}"
					}
					//Call the preparation function.
					preparation_function()
					echo "Preparation is done"
                    println(ENGINE_MAP)
                }				
			}			
		}
		
		stage('SQL Build and Generate') {
			when {
				expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"  && ENGINE_MAP[ENGINE_NAME]['SQL_Deployment'] == "NOT_STARTED" }
			}			
			steps {
				script{
					// Generate SQL Build and push the artefact to Nexus. And get SQL VERSION as return output.
					run_sql_generate_stage_function()
					echo "SQL Build is done"
                }				
			}			
		}
		
		stage('EMS Build and Generate') {
			when {
				expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"  && ENGINE_MAP[ENGINE_NAME]['EMS_Deployment'] == "NOT_STARTED" }
			}			
			steps {
				script{
					// Generate SQL Build and push the artefact to Nexus. And get SQL VERSION as return output.
					run_ems_generate_stage_function()
					echo "EMS Build is done"
                }				
			}			
		}
		stage('FILE Generate') {
			when {
				expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"  && params.FILE_DEPLOYMENT.length() != 0 }
			}			
			steps {
				script{
					run_file_generate_stage_function()
                }				
			}			
		}

		stage('BW Generate') {
		    when {
			     expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"  && ENGINE_MAP[ENGINE_NAME]['BW_VERSION'] != "NA" }
			    }
			steps {
				script {
					//Calling BW  Generate Function	
					bw_generate_stage()
                    trigger_versions_email map: ENGINE_MAP, REPORT_STAGE: "BW_Generate"					
				}
			}
		}		
		
		stage('SQL RF1') {
			when {
				expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"  && ENGINE_MAP[ENGINE_NAME]['SQL_VERSION'] != "NA" }
			}			
			steps {
				script{
						try
                        {
                        run_sql_deploy_stage_function()	
                        }
                        catch(Exception e)
                        {
                                ENGINE_MAP[ENGINE_NAME]['RESULT'] = "FAILED"
                                env.DP_ERROR_CODE = "506"
                                env.DP_ERROR_MSG = "SQL Deploy RF1 Failure"
                        }  
                        input 'Proceed or Abort?'                             
                }				
			}			
		}
        
        stage('SQL RB') {
			when {
				expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"  && ENGINE_MAP[ENGINE_NAME]['SQL_VERSION'] != "NA" }
			}			
			steps {
				script{
                        try
                        {
                        run_sql_rollback_function()
                        }
                        catch(Exception e)
                        {
                                ENGINE_MAP[ENGINE_NAME]['RESULT'] = "FAILED"
                                env.DP_ERROR_CODE = "506"
                                env.DP_ERROR_MSG = "SQL Deploy RB Failure"
                        }                          
                }				
			}			
		}
        
        stage('SQL RF2') {
			when {
				expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"  && ENGINE_MAP[ENGINE_NAME]['SQL_VERSION'] != "NA" }
			}			
			steps {
				script{
						try
                        {
                            run_sql_deploy_stage_function()	
                        }
                        catch(Exception e)
                        {
                                ENGINE_MAP[ENGINE_NAME]['RESULT'] = "FAILED"
                                env.DP_ERROR_CODE = "506"
                                env.DP_ERROR_MSG = "SQL Deploy RF2 Failure"
                        }                         
                }				
			}			
		}
        
		stage('EMS RF1') {
			when {
				expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"  && ENGINE_MAP[ENGINE_NAME]['EMS_VERSION'] != "NA" }
			}			
			steps {
				script{
						try
                        {
                            run_ems_deploy_stage_function()					
                        }
                        catch(Exception e)
                        {
                                ENGINE_MAP[ENGINE_NAME]['RESULT'] = "FAILED"
                                env.DP_ERROR_CODE = "507"
                                env.DP_ERROR_MSG = "EMS Deploy RF1 Failure"
                        }
                }				
			}			
		}
        
        stage('EMS RB') {
			when {
				expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"  && ENGINE_MAP[ENGINE_NAME]['EMS_VERSION'] != "NA" }
			}			
			steps {
				script{
						try
                        {
                        run_ems_rollback_function()	
                        }
                        catch(Exception e)
                        {
                                ENGINE_MAP[ENGINE_NAME]['RESULT'] = "FAILED"
                                env.DP_ERROR_CODE = "507"
                                env.DP_ERROR_MSG = "EMS Deploy RB Failure"
                        }                        
                }				
			}			
		}
        
        stage('EMS RF2') {
			when {
				expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"  && ENGINE_MAP[ENGINE_NAME]['EMS_VERSION'] != "NA" }
			}			
			steps {
				script{
						try
                        {
                            run_ems_deploy_stage_function()	
                        }
                        catch(Exception e)
                        {
                                ENGINE_MAP[ENGINE_NAME]['RESULT'] = "FAILED"
                                env.DP_ERROR_CODE = "507"
                                env.DP_ERROR_MSG = "EMS Deploy RF2 Failure"
                        } 
                    //trigger_results_email map: ENGINE_MAP, REPORT_STAGE: "EMS Deployment", crq_num: params.CHANGE_REF_ID, release: params.RELEASE
					echo "EMS Deployment is done"                        
                }				
			}			
		}
        stage('FILE Deployment') {
			when {
				expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"  && params.FILE_DEPLOYMENT.length() != 0 }
			}			
			steps {
				script{
					
					//[CICD-476] Fix: function to get elapsed time duration 
					fileDuration = elapsedTime {
						run_file_deploy_stage_function()
					}
					if(fileDuration){
						ENGINE_MAP[ENGINE_NAME]['FILE_DURATION'] = fileDuration
					}
					//trigger_results_email map: ENGINE_MAP, REPORT_STAGE: "FILE Deployment", crq_num: params.CHANGE_REF_ID, release: params.RELEASE
					echo "FILE Deployment is done"
                }				
			}			
		}
		
		stage('BW Deployment') {
		    when {
			     expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"  && ENGINE_MAP[ENGINE_NAME]['BW_VERSION'] != "NA" }
			    }
			steps {
				script {
					//[CICD-476] Fix: function to get elapsed time duration 
					bwDuration = elapsedTime {					
						bw_deployment_stage()
					}
					if(bwDuration){
						ENGINE_MAP[ENGINE_NAME]['BW_DURATION'] = "${bwDuration}"
					}
				}
			}
		}
		
		stage('BW Restart') {
		    when {
			     expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"  && ENGINE_MAP[ENGINE_NAME]['BW_VERSION'] != "NA" }
			    }
			steps {
				script {
					//input 'Proceed with BW Engine restart ?'
					//Calling BW Restart
					bw_restart_stage()
                    //trigger_versions_email map: ENGINE_MAP, REPORT_STAGE: "BW_Restart"
					if(ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED") {
						if(params.FILE_DEPLOYMENT || ENGINE_MAP[ENGINE_NAME]['BW_Deployment'] == "PASSED"){
							def file_status = ""
							if(params.FILE_DEPLOYMENT){
								file_status = "true"
							} else {
								file_status = "false"
							}
							echo "DEBUG: file status is: ${file_status}"
							// Once BW restart is done successfully, start applying GIT tag to BW Configurations repository with the tag constructed in preparation stage.
							//[CICD-539]: Insert Deployment metadata to release notes DB. Get BW TAG created.
							BWConfigTag = BW_Functions.create_tag ENGINE_NAME: ENGINE_NAME, RELEASE: params.RELEASE, ENGINE_TYPE: ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE'], BW_VERSION: params.BW_VERSION, FILE_DEPLOYMENT: file_status, REPO_NAME: "TIL_BW_Application_Configuration"
						}
					}
				}
			}
		}
		
		stage('Rollback EMS/ File/ SQL') {
             when {
			     expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] == "FAILED" }
			    }
		    steps {
				script {
					trigger_results_email map: ENGINE_MAP, REPORT_STAGE: "Rollback EMS/File/SQL", crq_num: params.CHANGE_REF_ID, release: params.RELEASE
					// This section contains rollback functions for all the passed stages if any of the above stage fails.
					if(ENGINE_MAP[ENGINE_NAME]['RESULT'] == "FAILED" && ENGINE_MAP[ENGINE_NAME]['BW_Deployment'] == "PASSED") {
						run_bw_rollback_function()
					}			
					if(ENGINE_MAP[ENGINE_NAME]['RESULT'] == "FAILED" && ENGINE_MAP[ENGINE_NAME]['SQL_Deployment'] == "PASSED") {
						// RUN SQL Rollback function.
						run_sql_rollback_function()
					}
					if(ENGINE_MAP[ENGINE_NAME]['RESULT'] == "FAILED" && ENGINE_MAP[ENGINE_NAME]['EMS_Deployment'] == "PASSED") {
						// RUN EMS Rollback function.
						run_ems_rollback_function()
					}
					if(ENGINE_MAP[ENGINE_NAME]['RESULT'] == "FAILED" && ENGINE_MAP[ENGINE_NAME]['XML_Deployment'] == "PASSED") {
						// RUN XML Rollback function.
						FILE_Functions.rollback_files_lower_env Host:"${TARGET_Env}", Deployment_Type: "XML_Files", engine_files: ENGINE_NAME + ':' + ENGINE_MAP[ENGINE_NAME]['XML_FILES'], crq_no:"${params.CHANGE_REF_ID}", datetime:"${date_now}" 
					}
					if(ENGINE_MAP[ENGINE_NAME]['RESULT'] == "FAILED" && ENGINE_MAP[ENGINE_NAME]['JAR_Deployment'] == "PASSED") {
						// RUN JAR Rollback function.
						FILE_Functions.rollback_files_lower_env Host:"${TARGET_Env}", Deployment_Type: "JAR_Files", engine_files: ENGINE_NAME + ':' + ENGINE_MAP[ENGINE_NAME]['JAR_FILES'], crq_no:"${params.CHANGE_REF_ID}", datetime:"${date_now}" 
					}
					if(ENGINE_MAP[ENGINE_NAME]['RESULT'] == "FAILED" && ENGINE_MAP[ENGINE_NAME]['EMAIL_Deployment'] == "PASSED") {
						// RUN EMAIL Rollback function.
						FILE_Functions.rollback_files_lower_env Host:"${TARGET_Env}", Deployment_Type: "EMAIL_Files", engine_files: ENGINE_NAME + ':' + ENGINE_MAP[ENGINE_NAME]['EMAIL_FILES'], crq_no:"${params.CHANGE_REF_ID}", datetime:"${date_now}" 
					}										
				}
			}
		}
        
        stage('RN Update') {
		    steps {
				script {
                    trigger_results_email map: ENGINE_MAP, REPORT_STAGE: "Deployment Status", crq_num: params.CHANGE_REF_ID, release: params.RELEASE
                    
                    //[CICD-476] Fix: call update function to populate stats into a file.
					//[CICD-374] Fix: Update dash board as well along with stats file.
					commonFunctions.update_report_stats map: ENGINE_MAP, Release: "${params.RELEASE}", environment: "${TARGET_Env}", statsFile: "/opt/tibco/DevOps_Reporting/Report/DevOps_report.txt", pipeline_name: 'TIL_BW_EMS_SQL_Pipeline'					
                    //[CICD-539] Insert Deployment metadata to release notes DB.
					def deployment_time = ENGINE_MAP[ENGINE_NAME]['SQL_DURATION'] + ENGINE_MAP[ENGINE_NAME]['EMS_DURATION'] + ENGINE_MAP[ENGINE_NAME]['BW_DURATION']
					println("DEBUG: Total Deployment duration is: " + deployment_time)
					
					//[CICD-1761]: Fix to insert BUILD_ID and BUILD_URL into the database"
 					// ADO 630550 Single quotes issues when inserting into DB
					str_DESCRIPTION = "${params.DESCRIPTION}".replaceAll("'","''")
										
		            def insert_query = """Insert into CICD_DEPLOYMENT_HISTORY ("Release","DateTime","CRQ","ComponentType","Environment","EngineName","BwVersion","EmsVersion","SqlVersion","GatewayVersion","BwDeploymentType","DeploymentStatus","DeploymentTime","XmlFiles","JarFiles","EmailFiles","RF1Status","RBStatus","RF2Status","DVTStatus","BWConfigTag","ChangeDescription","User","FailureReason","updatedTimestamp","BUILD_ID","BUILD_URL") values ('${params.RELEASE}', sysdate,'${params.CHANGE_REF_ID}','BW','${TARGET_Env}','${ENGINE_NAME}','${ENGINE_MAP[ENGINE_NAME]['BW_VERSION']}','${ENGINE_MAP[ENGINE_NAME]['EMS_VERSION']}','${ENGINE_MAP[ENGINE_NAME]['SQL_VERSION']}','','${ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE']}','Active','${deployment_time}','${ENGINE_MAP[ENGINE_NAME]['XML_FILES']}','${ENGINE_MAP[ENGINE_NAME]['JAR_FILES']}','${ENGINE_MAP[ENGINE_NAME]['EMAIL_FILES']}','','','','','${BWConfigTag}','${str_DESCRIPTION}','${user}','${ENGINE_MAP[ENGINE_NAME]['RESULT']}',sysdate,'${BUILD_ID}','${BUILD_URL}')"""
		
					println("DEBUG: Insert query is: " + insert_query)
		
					DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: insert_query
                    
                    if(ENGINE_MAP[ENGINE_NAME]['RESULT'] == "FAILED") {
						// Fail the pipeline
						 currentBuild.result = 'FAILURE'
                         if(env.DP_ERROR_CODE == "" || env.DP_ERROR_CODE == null)
                         {
                             println(env.DP_ERROR_CODE + "----"  + env.DP_ERROR_CODE + "-----" + env.DP_ERROR_CODE)
                             env.DP_ERROR_CODE = "515"
                             env.DP_ERROR_MSG = "Deployment Pipeline FAILED "
                         }
					}
					else {
						ENGINE_MAP[ENGINE_NAME]['RESULT'] = "PASSED"
                        env.DP_ERROR_CODE = "200"
                        env.DP_ERROR_MSG = "SUCCESS"
					}
                }
            }
        }
		
	}
    post {
        always {
				script {
					def updateQuery = "" 
                    if ( "${currentBuild.currentResult}" == "SUCCESS") {
						env.DP_ERROR_CODE = "200"
                        env.DP_ERROR_MSG = "Deployment SUCCESS" 
                        env.BW_VERSION = "${ENGINE_MAP[ENGINE_NAME]['BW_VERSION']}"
                        env.EMS_VERSION = "${ENGINE_MAP[ENGINE_NAME]['EMS_VERSION']}"
                        env.SQL_VERSION = "${ENGINE_MAP[ENGINE_NAME]['SQL_VERSION']}"
                       
                       updateQuery = "UPDATE CICD_RELEASES SET EMS_VERSION='${ENGINE_MAP[ENGINE_NAME]['EMS_VERSION']}', SQL_VERSION='${ENGINE_MAP[ENGINE_NAME]['SQL_VERSION']}', ONLY_GV='${params.ONLY_GV}', FILE_DEPLOYMENT='${params.FILE_DEPLOYMENT}', TECH_CHANGES_INVOLVED='', PROJECT_NAME = '${params.PROJECT_NAME}', OPERATION= '${params.OPERATION_NAME}',CHANGE_REF_ID= '${params.CHANGE_REF_ID}', CHANGE_REF_DESCRIPTION= '${params.DESCRIPTION}',ENGINE_TYPE= '${params.ENGINE_TYPE}', ENV_MASTER_CONF = '${params.MASTER_GV_UPDATE}',PROCESS_MASTER_CONF= '${params.PROCESS_GV_UPDATE}',LT_ENV= '${params.ENVIRONMENT}',DEPLOYMENT_TYPE='BW_EMS_SQL', FILE_CHANGES='',  MODIFIED_ON = sysdate, MODIFIED_BY='${params.EMAIL_REQUESTER}',  DEPLOYMENT_BUILD_URL='${BUILD_URL}', STAGE_COMPLETED='DEPLOYMENT', ERROR_CODE = '${env.DP_ERROR_CODE}', ERROR_DESCRIPTION = '${env.DP_ERROR_MSG}' WHERE TDD_ID=${params.TDD_ID}"
					} else {
 						println(env.DP_ERROR_CODE + "----"  + env.DP_ERROR_CODE + "-----" + env.DP_ERROR_CODE)
                         if(env.DP_ERROR_CODE == "" || env.DP_ERROR_CODE == null)
                        {
                            env.DP_ERROR_CODE = "515"
                            env.DP_ERROR_MSG = "Deployment Pipeline FAILED "                            
                        }
                        updateQuery = "UPDATE CICD_RELEASES SET MODIFIED_BY='${params.EMAIL_REQUESTER}', DEPLOYMENT_BUILD_URL='${BUILD_URL}', ERROR_CODE = '${env.DP_ERROR_CODE}', ERROR_DESCRIPTION = '${env.DP_ERROR_MSG}' WHERE TDD_ID=${params.TDD_ID}"
					}
                    
                    println("Error Code : "+env.DP_ERROR_CODE)
                    println("Error MSG : "+env.DP_ERROR_MSG)
                    println("BW  : "+env.BW_VERSION)
                    println("EMS  : "+env.EMS_VERSION)
                    println("SQL  : "+env.SQL_VERSION)

                    
                    println("DEBUG: Update query is: " + updateQuery)

                    
					dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: updateQuery
                    
				}
		}
    }	
}	
