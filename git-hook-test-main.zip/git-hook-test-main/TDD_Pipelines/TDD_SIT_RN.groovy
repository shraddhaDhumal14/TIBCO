import com.cwctravel.hudson.plugins.extended_choice_parameter.ExtendedChoiceParameterDefinition
import hudson.tasks.Mailer;
import hudson.model.User;

@NonCPS
def getUserEmail(String id=null) {
    User user = User.getById(id ?: currentBuild.rawBuild.getCause(Cause.UserIdCause).getUserId(), false)
    user?.getProperty(Mailer.UserProperty.class).getAddress()
}

def get_approvers_list(String approver_group){
	approvers_list = sh (script: """cat /opt/tibco/.jenkins/config.xml | sed -n \'/role name=\"${approver_group}\"/,\$p\' | sed \'/role>/q\' | grep "sid" | cut -d \'>\' -f 2 | cut -d \'<\' -f 1 | paste -s -d, -""", returnStdout: true).trim()
    return """${approvers_list}"""           
}

def get_approvers_email_list(String approvers_list){
   approvers_email=""
	approvers_list.split(',').each { user ->
            if(approvers_email.length() != 0)
              {
                    approvers_email += ","
              }
              approvers_email += getUserEmail(user)  
        }
    return """${approvers_email}"""   
}


def myGetDBConnect() {     
     def dbURL = 'jdbc:oracle:thin:@aukshocr.dc-dublin.de:33000:TIBTST1'
     def dbUserName = 'CICD_OWN_DB01'
     def dbPassword = 'TIL_CICD_DB'
     def dbDriver = 'oracle.jdbc.driver.OracleDriver'
     //displayDebug('myGetDBConnect','Establishing DB Connectivity')
     def mySQL = groovy.sql.Sql.newInstance(dbURL,dbUserName,dbPassword,dbDriver)
     return mySQL                   
}

def mySingleSelectQuery(selectQuery){
     def mySQL =  myGetDBConnect()
  	 def rowData = [:]
     //displayDebug('mySingleSelectQuery',selectQuery)
     def rowResults = mySQL.rows(selectQuery)
     mySQL.close();
     if(rowResults.size() == 0)
         return rowData;
     def headerList = new ArrayList(rowResults[0].keySet())
     for(def rlcounter=0;rlcounter<rowResults.size();rlcounter++)
     {
         def row = rowResults[rlcounter];
         rowData = [:]
         for(def rwHeaderCnt=0;rwHeaderCnt<headerList.size();rwHeaderCnt++)
         { 
           rowData.put(headerList[rwHeaderCnt], row[rwHeaderCnt]!= null  ? row[rwHeaderCnt].toString() : "")
         }
     }
	rowResults = null;
	mySQL = null;
	headerList = null;
    return rowData;
}

def myMultipleSelectQuery(selectQuery){     
     def mySQL =  myGetDBConnect()
  	 def rowData = [:]
	 def resultList = []
     //displayDebug('myMultipleSelectQuery',selectQuery)
     def rowResults = mySQL.rows(selectQuery)
     mySQL.close()
     if(rowResults.size() == 0)
            return resultList;
     def headerList = new ArrayList(rowResults[0].keySet())
	 for(def rlcounter=0;rlcounter<rowResults.size();rlcounter++)
     {
         def row = rowResults[rlcounter];
         rowData = [:]
         for(def rwHeaderCnt=0;rwHeaderCnt<headerList.size();rwHeaderCnt++)
         { 
               rowData.put(headerList[rwHeaderCnt], row[rwHeaderCnt]!= null  ? row[rwHeaderCnt].toString() : "")
         }
		 resultList.add(rowData)
     }
	 headerList=null;
	rowResults = null;
	rowData = null;
	mySQL = null;
    return resultList;
}

def preparation_function() {

        SUBMITTED_DATE = new Date().format("dd/MM/yyy HH:mm")
       
        checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'JENKINS_FILE']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_DevOps_Framework.git']]])

        commonFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/commonFunctions.groovy"
        DB_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/dbFunctions.groovy"
        echo "Preparation is done"   

        RELEASE_DATA = ['TDD_ID':'', 'SEQ_NO':'', 'RELEASE_NO':'', 'ENGINE_NAME':'', 'BW_VERSION':'', 'EMS_VERSION':'', 'SQL_VERSION':'', 'ONLY_GV':'', 'FILE_DEPLOYMENT':'', 'DEPLOYMENT_TYPE':'', 'TECH_CHANGES_INVOLVED':'', 'STATUS':'', 'STAGE_COMPLETED':'', 'PROJECT_NAME':'', 'OPERATION':'', 'CHANGE_REF_ID':'', 'CHANGE_REF_DESCRIPTION':'', 'ENGINE_TYPE':'', 'FILE_CHANGES':'', 'TEST_RESULT':'', 'ENGINE_TEMPLATE':'', 'APPEND_PREPEND':'', 'KNOWN_ERROR_INCLUSION':'', 'POST_MANUAL_CHANGES':'', 'SPECIAL_INSTRUCTIONS':'', 'RESTART_ENGINES':'', 'FUNCTIONAL_DEPENDENCIES':'', 'ROLLBACK_INSTRUCTION':'', 'ENV_MASTER_CONF':'', 'PROCESS_MASTER_CONF':'', 'APP_CONF_FILE':'', 'APP_CONF_FILE_2':'', 'APP_CONF_FILE_3':'', 'GV_CONF_FILE':'', 'GV_CONF_FILE_2':'', 'GV_CONF_FILE_3':'', 'PR_CONF_FILE':'', 'PR_CONF_FILE_2':'', 'PR_CONF_FILE_3':'', 'CONF_FILE_PATH':'', 'CONFIG_CHANGES':'', 'CLASS_PATH':'', 'TA_DETAIL':'', 'TEST_SHEET_LOCATION':'', 'ARTIFACT_LOCATION':'', 'LOG_LOCATION':'', 'SUPPLIMENT_DOC_LOCATION':'', 'DESIGN_PPT_LOCATION':'', 'LLD_LOCATION':'', 'CREATED_ON':'', 'CREATED_BY':'', 'MODIFIED_ON':'', 'MODIFIED_BY':'', 'LT_ENV':'', 'SIT_ENV':'', 'LT_APPROVAL':'', 'SIT_APPROVAL':'', 'SIT_DEPLOYMENT_ON':'', 'ORCH_URL':'', 'BW_BUILD_URL':'', 'DEPLOYMENT_BUILD_URL':'', 'TEST_AUTOMATION_URL':'', 'SIT_RN_URL':'', 'SIT_URL':'', 'GW_VERSION':'', 'GW_TYPE':'', 'PARTNER_DATA':'', 'GATEWAY_TOKEN':'', 'ERROR_CODE':'', 'ERROR_DESCRIPTION':'']
                        
     
}

def getcssContent(){
    def css = """
        <style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Times, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;width:150px;word-break:break-all;border-color:#9ABAD9;color:#444;}
		.tg th{font-family:Times, sans-serif;font-size:26px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:break-all;border-color:#9ABAD9;color:#1A0504;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		.tg .tg-pass{background-color:lightgreen;text-align:left;vertical-align:top}
		.tg .tg-fail{background-color:red;text-align:left;vertical-align:top}
		.tg .tg-notstarted{background-color:lightgrey;text-align:left;vertical-align:top}
		.tg .tg-notrequired{background-color:#E1E0A2;text-align:left;vertical-align:top}
		</style>
        """
     return css
}

def ApprovalemailContent(subjectSuffix){
  
	def body_build_summary = """
		<table class="tg" style="table-layout: fixed; width: 100%"">
		  <tr>
			<th class="tg-amwm" colspan="8">SIT RELEASE NOTES ${subjectSuffix}</th>
		  </tr>
          <tr>
			<td class="tg-1wig" colspan="2">RELEASE</td>
			<td class="tg-0lax" colspan="6">${RELEASE_DATA['RELEASE_NO']} </td>
		  </tr>
          <tr>
			<td class="tg-1wig" colspan="2">ENGINE NAME</td>
			<td class="tg-0lax" colspan="6">${RELEASE_DATA['ENGINE_NAME']}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">BW_VERSION</td>
			<td class="tg-0lax" colspan="6">${RELEASE_DATA['BW_VERSION']}</td>
		  </tr>
 		  <tr>
			<td class="tg-1wig" colspan="2">EMS_VERSION</td>
            <td class="tg-0lax" colspan="6">${RELEASE_DATA['EMS_VERSION']}</td>
		  </tr>
   		  <tr>
			<td class="tg-1wig" colspan="2">SQL_VERSION</td>
			<td class="tg-0lax" colspan="6">${RELEASE_DATA['SQL_VERSION']}</td>
		  </tr>
          <tr>
            <td class="tg-1wig" colspan="1">ONLY_GV</td>
            <td class="tg-0lax" colspan="3">${RELEASE_DATA['ONLY_GV']}</td>
            <td class="tg-1wig" colspan="1">FILE DEPLOYMENT</td>
            <td class="tg-0lax" colspan="3">${RELEASE_DATA['FILE_DEPLOYMENT']}</td>
          </tr>
          <tr>
			<td class="tg-1wig" colspan="1">PROJECT_NAME</td>
			<td class="tg-0lax" colspan="3">${RELEASE_DATA['PROJECT_NAME']}</td>
            <td class="tg-1wig" colspan="1">PBI/JIRA/ADO/DEFECT</td>
            <td class="tg-0lax" colspan="3">${RELEASE_DATA['CHANGE_REF_ID']}</td>
		  </tr>
          <tr>
			<td class="tg-1wig" colspan="2">TA DETAIL</td>
			<td class="tg-0lax" colspan="6">${RELEASE_DATA['TA_DETAIL']}</td>
		  </tr>
  		  <tr>
			<td class="tg-amwm" colspan="2">Role</td>
            <td class="tg-amwm" colspan="1">Status</td>
            <td class="tg-amwm" colspan="3">Comments</td>
			<td class="tg-amwm" colspan="1">User</td>
			<td class="tg-amwm" colspan="1">DATE</td>			
		  </tr> 
          <tr>
			<td class="tg-0lax" colspan="2">Developer</td>
            <td class="tg-0lax" colspan="1">SUBMITTED</td>
			<td class="tg-0lax" colspan="3"></td>
            <td class="tg-0lax" colspan="1">${params.BUILD_REQUESTOR}</td>
			<td class="tg-0lax" colspan="1">${SUBMITTED_DATE}</td>			
		  </tr> 
          <tr>
			<td class="tg-0lax" colspan="2">Team Lead Approval</td>
			<td class="tg-0lax" colspan="1">${Apvl_TL_Status}</td>
            <td class="tg-0lax" colspan="3">${Apvl_TL_Comments}</td>
            <td class="tg-0lax" colspan="1">${Apvl_TL_Name}</td>
            <td class="tg-0lax" colspan="1">${Apvl_TL_Date}</td>			
		  </tr>          
          <tr>
			<td class="tg-1wig" colspan="2">Tech Leads</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${SITReleaseTechLeadApprovers}</div></td>
		  </tr>
          <tr>
			<td class="tg-1wig" colspan="2">ARTIFACTS LOCATION</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${RELEASE_DATA['ARTIFACT_LOCATION'].replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
		  </tr>	
          <tr>
			<td class="tg-1wig" colspan="2">Approval Link</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${BUILD_URL}console</div></td>
		  </tr>	          
		</table>		
	"""    
	return body_build_summary
}

def email_body_release_bw_short()
{
    def body_build_summary = """
		<table class="tg" style="table-layout: fixed; width: 100%"">
		  <tr>
			<th class="tg-amwm" colspan="8">SIT RELEASE NOTES - BW_EMS_SQL Deployment</th>
		  </tr>
          <tr>
			<td class="tg-1wig" colspan="2">RELEASE</td>
			<td class="tg-0lax" colspan="6">${RELEASE_DATA['RELEASE_NO']} </td>
		  </tr>
          <tr>
			<td class="tg-1wig" colspan="2">ENGINE NAME</td>
			<td class="tg-0lax" colspan="6">${RELEASE_DATA['ENGINE_NAME']}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">BW_VERSION</td>
			<td class="tg-0lax" colspan="6">${RELEASE_DATA['BW_VERSION']}</td>
		  </tr>
 		  <tr>
			<td class="tg-1wig" colspan="2">EMS_VERSION</td>
            <td class="tg-0lax" colspan="6">${RELEASE_DATA['EMS_VERSION']}</td>
		  </tr>
   		  <tr>
			<td class="tg-1wig" colspan="2">SQL_VERSION</td>
			<td class="tg-0lax" colspan="6">${RELEASE_DATA['SQL_VERSION']}</td>
		  </tr>
          <tr>
            <td class="tg-1wig" colspan="1">ONLY_GV</td>
            <td class="tg-0lax" colspan="3">${RELEASE_DATA['ONLY_GV']}</td>
            <td class="tg-1wig" colspan="1">FILE DEPLOYMENT</td>
            <td class="tg-0lax" colspan="3">${RELEASE_DATA['FILE_DEPLOYMENT']}</td>
          </tr>
          <tr>
			<td class="tg-1wig" colspan="1">PROJECT_NAME</td>
			<td class="tg-0lax" colspan="3">${RELEASE_DATA['PROJECT_NAME']}</td>
            <td class="tg-1wig" colspan="1">PBI/JIRA/ADO/DEFECT</td>
            <td class="tg-0lax" colspan="3">${RELEASE_DATA['CHANGE_REF_ID']}</td>
		  </tr>
           <tr>
            <td class="tg-1wig" colspan="1">Description of Change</td>
            <td class="tg-0lax" colspan="7">${RELEASE_DATA['CHANGE_REF_DESCRIPTION']}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">Impacted TIL Operation(s)</td>
            <td class="tg-0lax" colspan="7">${RELEASE_DATA['OPERATION']}</td>
          </tr>
		  <tr>
            <td class="tg-1wig" colspan="1">Impacted Engine</td>
            <td class="tg-0lax" colspan="3">${RELEASE_DATA['RESTART_ENGINES']}</td>
           <td class="tg-1wig" colspan="1">Engine Type</td>
            <td class="tg-0lax" colspan="3">${RELEASE_DATA['ENGINE_TYPE']}</td>
          </tr>          
          <tr>
            <td class="tg-1wig" colspan="1">TECH_CHANGES_INVOLVED</td>
            <td class="tg-0lax" colspan="7"><div class="multiline">${RELEASE_DATA['TECH_CHANGES_INVOLVED'].replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
          </tr>
          <tr>
			<td class="tg-1wig" colspan="2">TA DETAIL</td>
			<td class="tg-0lax" colspan="6">${RELEASE_DATA['TA_DETAIL']}</td>
		  </tr>
  		  <tr>
			<td class="tg-1wig" colspan="2">ARTIFACTS LOCATION</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${RELEASE_DATA['ARTIFACT_LOCATION'].replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
		  </tr>	      
          
		</table>		
	"""
    return body_build_summary;
}

def email_body_release_common_short()
{
    def body_build_summary = """		
		<table class="tg" style="table-layout: fixed; width: 100%"">
		  <tr>
			<th class="tg-amwm" colspan="8">SIT RELEASE NOTES - Common SQL Changes</th>
		  </tr>
          <tr>
			<td class="tg-1wig" colspan="2">RELEASE</td>
			<td class="tg-0lax" colspan="6">${RELEASE_DATA['RELEASE_NO']} </td>
		  </tr>
          <tr>
			<td class="tg-1wig" colspan="2">ENGINE NAME</td>
			<td class="tg-0lax" colspan="6">${RELEASE_DATA['ENGINE_NAME']}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">SQL_VERSION</td>
			<td class="tg-0lax" colspan="6">${RELEASE_DATA['SQL_VERSION']}</td>
		  </tr>
          <tr>
			<td class="tg-1wig" colspan="1">PROJECT_NAME</td>
			<td class="tg-0lax" colspan="3">${RELEASE_DATA['PROJECT_NAME']}</td>
            <td class="tg-1wig" colspan="1">PBI/JIRA/ADO/DEFECT</td>
            <td class="tg-0lax" colspan="3">${RELEASE_DATA['CHANGE_REF_ID']}</td>
		  </tr>
          <tr>
            <td class="tg-1wig" colspan="1">Description of Change</td>
            <td class="tg-0lax" colspan="7">${RELEASE_DATA['CHANGE_REF_DESCRIPTION']}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">Impacted Engines</td>
            <td class="tg-0lax" colspan="7">${RELEASE_DATA['RESTART_ENGINES']}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">TECH_CHANGES_INVOLVED</td>
            <td class="tg-0lax" colspan="7"><div class="multiline">${RELEASE_DATA['TECH_CHANGES_INVOLVED'].replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
          </tr>
          <tr>
			<td class="tg-1wig" colspan="2">TA DETAIL</td>
			<td class="tg-0lax" colspan="6">${RELEASE_DATA['TA_DETAIL']}</td>
		  </tr>
  		  <tr>
			<td class="tg-1wig" colspan="2">ARTIFACTS LOCATION</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${RELEASE_DATA['ARTIFACT_LOCATION'].replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
		  </tr>	                   
		</table>		
	"""
    return body_build_summary;
}

def email_body_release_gateway_short()
{
    def body_build_summary = """
		<table class="tg" style="table-layout: fixed; width: 100%"">
		  <tr>
			<th class="tg-amwm" colspan="8">SIT RELEASE NOTES - Gateway Deployment</th>
		  </tr>
          <tr>
			<td class="tg-1wig" colspan="2">RELEASE</td>
			<td class="tg-0lax" colspan="6">${RELEASE_DATA['RELEASE_NO']} </td>
		  </tr>
          <tr>
			<td class="tg-1wig" colspan="2">GATEWAY TYPE</td>
			<td class="tg-0lax" colspan="6">${RELEASE_DATA['GW_TYPE']}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="2">GATEWAY VERSION</td>
			<td class="tg-0lax" colspan="6">${RELEASE_DATA['GW_VERSION']}</td>
		  </tr>
          <tr>
			<td class="tg-1wig" colspan="1">PROJECT_NAME</td>
			<td class="tg-0lax" colspan="3">${RELEASE_DATA['PROJECT_NAME']}</td>
            <td class="tg-1wig" colspan="1">PBI/JIRA/ADO/DEFECT</td>
            <td class="tg-0lax" colspan="3">${RELEASE_DATA['CHANGE_REF_ID']}</td>
		  </tr>
          <tr>
            <td class="tg-1wig" colspan="1">Description of Change</td>
            <td class="tg-0lax" colspan="7">${RELEASE_DATA['CHANGE_REF_DESCRIPTION']}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">TECH_CHANGES_INVOLVED</td>
            <td class="tg-0lax" colspan="7"><div class="multiline">${RELEASE_DATA['TECH_CHANGES_INVOLVED'].replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
          </tr>
          <tr>
			<td class="tg-1wig" colspan="2">TA DETAIL</td>
			<td class="tg-0lax" colspan="6">${RELEASE_DATA['TA_DETAIL']}</td>
		  </tr>
  		  <tr>
			<td class="tg-1wig" colspan="2">ARTIFACTS LOCATION</td>
			<td class="tg-0lax" colspan="6"><div class="multiline">${RELEASE_DATA['ARTIFACT_LOCATION'].replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
		  </tr>	                   
		</table>		
	"""
    return body_build_summary;
}

def email_body_release_detailed() {
    
    def body_build_summary = """
    <table class="tg" style="table-layout: fixed; width: 100%">        
		         
         <tr>
			<th class="tg-amwm" colspan="8">Updates to Master Conf File. Replace with Env specific values where required</th>
		  </tr>       
        <tr>
            <td class="tg-1wig" colspan="1">Env MasterGV Conf </td>
            <td class="tg-0lax" colspan="7">${RELEASE_DATA['ENV_MASTER_CONF']}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">Process GVs</td>
            <td class="tg-0lax" colspan="7">${RELEASE_DATA['PROCESS_MASTER_CONF']}</td>
          </tr>

          <tr>
            <td class="tg-1wig" colspan="1">App Conf File</td>
            <td class="tg-0lax" colspan="7">${RELEASE_DATA['APP_CONF_FILE']}${RELEASE_DATA['APP_CONF_FILE_2']}${RELEASE_DATA['APP_CONF_FILE_3']}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">GV Conf File</td>
            <td class="tg-0lax" colspan="7">${RELEASE_DATA['GV_CONF_FILE']}${RELEASE_DATA['GV_CONF_FILE_2']}${RELEASE_DATA['GV_CONF_FILE_3']}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">CONF_FILE_PATH</td>
            <td class="tg-0lax" colspan="7">${RELEASE_DATA['CONF_FILE_PATH']}</td>
          </tr> 
          <tr>
            <td class="tg-1wig" colspan="1">PR Conf File</td>
            <td class="tg-0lax" colspan="7">${RELEASE_DATA['PR_CONF_FILE']}${RELEASE_DATA['PR_CONF_FILE_2']}${RELEASE_DATA['PR_CONF_FILE_3']}</td>
          </tr>          
          <tr>
            <td class="tg-1wig" colspan="1">RESTART_ENGINES</td>
            <td class="tg-0lax" colspan="7">${RELEASE_DATA['RESTART_ENGINES']}</td>
          </tr> 
          <tr>
            <td class="tg-1wig" colspan="1">CONFIG_CHANGES</td>
            <td class="tg-0lax" colspan="7">${RELEASE_DATA['CONFIG_CHANGES']}</td>
          </tr> 
          <tr>
            <td class="tg-1wig" colspan="1">CLASS_PATH</td>
            <td class="tg-0lax" colspan="7">${RELEASE_DATA['CLASS_PATH']}</td>
          </tr> 
          <tr>
            <td class="tg-1wig" colspan="1">ROLLBACK_INSTRUCTION</td>
            <td class="tg-0lax" colspan="7">${RELEASE_DATA['ROLLBACK_INSTRUCTION']}</td>
          </tr>           
          <tr>
			<th class="tg-amwm" colspan="8">File Deployments & Other Configurations</th>
		  </tr>
          <tr>
            <td class="tg-1wig" colspan="1">FILE Deployment Type</td>
            <td class="tg-0lax" colspan="7">${RELEASE_DATA['FILE_DEPLOYMENT']}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">File Changes</td>
            <td class="tg-0lax" colspan="7">${RELEASE_DATA['FILE_CHANGES']}</td>
          </tr>

          <tr>
            <td class="tg-1wig" colspan="1">EngineTemplate</td>
            <td class="tg-0lax" colspan="7">${RELEASE_DATA['ENGINE_TEMPLATE']}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">AppendPrependPath</td>
            <td class="tg-0lax" colspan="7">${RELEASE_DATA['APPEND_PREPEND']}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">KnownErrors</td>
            <td class="tg-0lax" colspan="7">${RELEASE_DATA['KNOWN_ERROR_INCLUSION']}</td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="1">PostManualChanges</td>
            <td class="tg-0lax" colspan="7">${RELEASE_DATA['POST_MANUAL_CHANGES']}</td>
          </tr>
          <tr> 
            <td class="tg-1wig" colspan="1">Special Instructions</td>
            <td class="tg-0lax" colspan="7">${RELEASE_DATA['SPECIAL_INSTRUCTIONS']}</td>
          </tr>
           <tr> 
            <td class="tg-1wig" colspan="1">Restart Engines</td>
            <td class="tg-0lax" colspan="7">${RELEASE_DATA['RESTART_ENGINES']}</td>
          </tr>
          <tr>
			<td class="tg-1wig" colspan="1">ARTIFACTS LOCATION</td>
			<td class="tg-0lax" colspan="7"><div class="multiline">${RELEASE_DATA['ARTIFACT_LOCATION'].replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
		  </tr>
          <tr>
			<td class="tg-1wig" colspan="1">Build Pipeline URL</td>
			<td class="tg-0lax" colspan="7"><div class="multiline">${RELEASE_DATA['BW_BUILD_URL'].replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
		  </tr>
          <tr>
			<td class="tg-1wig" colspan="1">Deployment Pipeline URL</td>
			<td class="tg-0lax" colspan="7"><div class="multiline">${RELEASE_DATA['DEPLOYMENT_BUILD_URL'].replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
		  </tr>
          <tr>
			<td class="tg-1wig" colspan="1">TA Pipeline URL</td>
			<td class="tg-0lax" colspan="7"><div class="multiline">${RELEASE_DATA['TEST_AUTOMATION_URL'].replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="1">SIT RN URL</td>
			<td class="tg-0lax" colspan="7"><div class="multiline">${BUILD_URL}console</div></td>
		  </tr>
		  <tr>
			<td class="tg-1wig" colspan="1">ORCHESTRATOR URL</td>
			<td class="tg-0lax" colspan="7"><div class="multiline">${RELEASE_DATA['ORCH_URL'].replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
		  </tr>
		</table>
    """
	return body_build_summary
}

def email_getLinks()
{
    def linkSummary = """
        <table class="tg" style="table-layout: fixed; width: 100%">        
		  <tr>
			<th class="tg-amwm" colspan="8">Links</th>
		  </tr>
          <tr>
            <td class="tg-1wig" colspan="2">TA_DETAIL</td>
            <td class="tg-0lax" colspan="6"><div class="multiline">${RELEASE_DATA['TA_DETAIL'].replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="2">TECH_CHANGES_INVOLVED</td>
            <td class="tg-0lax" colspan="6"><div class="multiline">${RELEASE_DATA['TECH_CHANGES_INVOLVED'].replaceAll("[\\t\\n\\r]+","<br>")}</div></td>            
          </tr>          
          <tr>
            <td class="tg-1wig" colspan="2">TEST_SHEET_LOCATION</td>
            <td class="tg-0lax" colspan="6"><div class="multiline">${RELEASE_DATA['TEST_SHEET_LOCATION'].replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="2">LOG_LOCATION</td>
            <td class="tg-0lax" colspan="6"><div class="multiline">${RELEASE_DATA['LOG_LOCATION'].replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="2">ARTIFACT_LOCATION</td>
            <td class="tg-0lax" colspan="6"><div class="multiline">${RELEASE_DATA['ARTIFACT_LOCATION'].replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="2">SUPPLIMENT_DOC_LOCATION</td>
            <td class="tg-0lax" colspan="6"><div class="multiline">${RELEASE_DATA['SUPPLIMENT_DOC_LOCATION'].replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="2">DESIGN_PPT_LOCATION</td>
            <td class="tg-0lax" colspan="6"><div class="multiline">${RELEASE_DATA['DESIGN_PPT_LOCATION'].replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
          </tr>
          <tr>
            <td class="tg-1wig" colspan="2">LLD_LOCATION</td>
            <td class="tg-0lax" colspan="6"><div class="multiline">${RELEASE_DATA['LLD_LOCATION'].replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
          </tr>      
          <tr>
            <td class="tg-1wig" colspan="2">FUNCTIONAL_DEPENDENCIES</td>
            <td class="tg-0lax" colspan="6"><div class="multiline">${RELEASE_DATA['FUNCTIONAL_DEPENDENCIES'].replaceAll("[\\t\\n\\r]+","<br>")}</div></td>
          </tr>          
		</table>		
	"""
    return linkSummary;
}

def email_test_result()
{
    def test_result_summary = ""
    
    strQuery = "select DISTINCT ENVIRONMENT, RIT_BRANCH, TEST_STATUS, APPROVED_BY, COMMENTS, TESTCASE_REPORT_URL from TDD_TA_SUMMARY where SEQ_NO='${SEQ_NO}' and STATUS = 'Active'"
    rowList = myMultipleSelectQuery(strQuery);
    
     def headerList = new ArrayList(rowList[0].keySet())
     
     test_result_summary+="<table class='tg' style='table-layout: fixed; width: 100%'>\n"
     test_result_summary+="<tr>\n"
     for(def rwHeaderCnt=0;rwHeaderCnt<headerList.size();rwHeaderCnt++)
     { 
         test_result_summary+="<th class='tg-amwm'>${headerList[rwHeaderCnt]}</th>\n"
     } 
     test_result_summary+="</tr>\n"
	 for(def rlcounter=0;rlcounter<rowList.size();rlcounter++)
     {
         def row = rowList[rlcounter];
         test_result_summary+="<tr>\n"
         for(def rwHeaderCnt=0;rwHeaderCnt<headerList.size();rwHeaderCnt++)
         { 
             row_value = row[headerList[rwHeaderCnt]]!= null  ? row[headerList[rwHeaderCnt]].toString() : ""
             test_result_summary+="<td class='tg-1wig'>${row_value}</td>\n"             
         }
         test_result_summary+="</tr>\n"
     }
    
    test_result_summary+="</table>"
    return test_result_summary;
}

def email_test_result_operations()
{
    def test_result_summary = ""
    
    strQuery = "select OPERATION, TOTAL_TC, PROG_PASS, PROG_FAIL, REG_PASS, REG_FAIL, TO_CHAR(CREATED_ON, 'DD-MON-YY HH24:MI')  from TDD_TA_SUMMARY where SEQ_NO='${SEQ_NO}' and STATUS = 'Active' order by TA_ID DESC"
    rowList = myMultipleSelectQuery(strQuery);
    
     def headerList = new ArrayList(rowList[0].keySet())
     
     test_result_summary+="<table class='tg' style='table-layout: fixed; width: 100%'>\n"
     test_result_summary+="<tr>\n"
     for(def rwHeaderCnt=0;rwHeaderCnt<headerList.size();rwHeaderCnt++)
     { 
         test_result_summary+="<th class='tg-amwm'>${headerList[rwHeaderCnt]}</th>\n"
     } 
     test_result_summary+="</tr>\n"
	 for(def rlcounter=0;rlcounter<rowList.size();rlcounter++)
     {
         def row = rowList[rlcounter];
         test_result_summary+="<tr>\n"
         for(def rwHeaderCnt=0;rwHeaderCnt<headerList.size();rwHeaderCnt++)
         { 
            row_value = row[headerList[rwHeaderCnt]]!= null  ? row[headerList[rwHeaderCnt]].toString() : ""
            test_result_summary+="<td class='tg-1wig'>${row_value}</td>\n"             
         }
         test_result_summary+="</tr>\n"
     }
    
    test_result_summary+="</table>"
    println test_result_summary
    return test_result_summary;
}

def sendEmail(approval, subjectSuffix, mailRecipients)
{
    def body_build_summary = ""
    def EMAIL_SUBJECT = ""
    
    if(subjectSuffix != "")
    {
        subjectSuffix = "- " + subjectSuffix
    }
    
    
    body_build_summary += getcssContent()
    if(approval)
    {
        body_build_summary += ApprovalemailContent(subjectSuffix)
    }
    if("${RELEASE_DATA['DEPLOYMENT_TYPE']}" == "BW_EMS_SQL")
    {
        body_build_summary += email_body_release_bw_short()
    }
    else if("${RELEASE_DATA['DEPLOYMENT_TYPE']}" == "Common_SQL_Changes")
    {        
        body_build_summary += email_body_release_common_short()
    }
    else
    {       
        body_build_summary += email_body_release_gateway_short()
    }
    body_build_summary += email_test_result()
    body_build_summary += email_test_result_operations()    
    body_build_summary += email_body_release_detailed()
    body_build_summary += email_getLinks()
        
    if("${RELEASE_DATA['RELEASE_NO']}" != "")
        EMAIL_SUBJECT = "[${RELEASE_DATA['RELEASE_NO']}]" + "-" + "${RELEASE_DATA['DEPLOYMENT_TYPE']}" + " SIT Release Notification for ${RELEASE_DATA['ENGINE_NAME']} " + "[" + "${RELEASE_DATA['CHANGE_REF_ID']}" + "-"  + "${RELEASE_DATA['PROJECT_NAME']}" + "]"
    else
        EMAIL_SUBJECT = "[${RELEASE_DATA['RELEASE_NO']}]" + "-" + "${RELEASE_DATA['DEPLOYMENT_TYPE']}" + " SIT Release Notification for ${RELEASE_DATA['GW_TYPE']} " + "[" + "${RELEASE_DATA['CHANGE_REF_ID']}" + "-"  + "${RELEASE_DATA['PROJECT_NAME']}" + "]"
        
    emailext mimeType: 'text/html',
    subject: "[Jenkins]: ${EMAIL_SUBJECT} SIT - Release Notes ${subjectSuffix}",
	from:"TIL_SIT_RN_NEW@vodafone.com",
	to: "${mailRecipients}",
	body: "${body_build_summary}" 
}

def validate() {
        //1. Validate Engine Name
        //if(RELEASE_SUMMARY_ID == ""){
        //    println("RELEASE_SUMMARY_ID is mandatory")
        //    validationCheck = "F"
       // }
        
        //if(validationCheck == "F"){
		//	error("Pipeline Input parameter validation failed. Please check the errors in Console log.")
		//	currentBuild.result = 'ABORTED'
		//} 
}

def fetchvalues(tdd_no)
{
    strQuery = "SELECT TDD_ID, SEQ_NO, RELEASE_NO, ENGINE_NAME, BW_VERSION, EMS_VERSION, SQL_VERSION, ONLY_GV, FILE_DEPLOYMENT, DEPLOYMENT_TYPE, TECH_CHANGES_INVOLVED, STATUS, STAGE_COMPLETED, PROJECT_NAME, OPERATION, CHANGE_REF_ID, CHANGE_REF_DESCRIPTION, ENGINE_TYPE, FILE_CHANGES, TEST_RESULT, ENGINE_TEMPLATE, APPEND_PREPEND, KNOWN_ERROR_INCLUSION, POST_MANUAL_CHANGES, SPECIAL_INSTRUCTIONS, RESTART_ENGINES, FUNCTIONAL_DEPENDENCIES, ROLLBACK_INSTRUCTION, ENV_MASTER_CONF, PROCESS_MASTER_CONF, APP_CONF_FILE, APP_CONF_FILE_2, APP_CONF_FILE_3, GV_CONF_FILE, GV_CONF_FILE_2, GV_CONF_FILE_3, PR_CONF_FILE, PR_CONF_FILE_2, PR_CONF_FILE_3, CONF_FILE_PATH, CONFIG_CHANGES, CLASS_PATH, TA_DETAIL, TEST_SHEET_LOCATION, ARTIFACT_LOCATION, LOG_LOCATION, SUPPLIMENT_DOC_LOCATION, DESIGN_PPT_LOCATION, LLD_LOCATION, CREATED_ON, CREATED_BY, MODIFIED_ON, MODIFIED_BY, LT_ENV, SIT_ENV, LT_APPROVAL, SIT_APPROVAL, SIT_DEPLOYMENT_ON, ORCH_URL, BW_BUILD_URL, DEPLOYMENT_BUILD_URL, TEST_AUTOMATION_URL, SIT_RN_URL, SIT_URL, GW_VERSION, GW_TYPE, PARTNER_DATA, GATEWAY_TOKEN, ERROR_CODE, ERROR_DESCRIPTION FROM CICD_RELEASES where TDD_ID='" + tdd_no + "'"
    strQuery = strQuery.toString()
    rowList = myMultipleSelectQuery(strQuery);
    
    def headerList = new ArrayList(rowList[0].keySet())
	 for(def rlcounter=0;rlcounter<rowList.size();rlcounter++)
     {
         def row = rowList[rlcounter];
         for(def rwHeaderCnt=0;rwHeaderCnt<headerList.size();rwHeaderCnt++)
         { 
             RELEASE_DATA[headerList[rwHeaderCnt]] = row[headerList[rwHeaderCnt]]!= null  ? row[headerList[rwHeaderCnt]].toString() : ""
         }
     }
}

RELEASE_DATA = [:]
SITReleaseTechLeadApprovers = ""
TLapprovers_mailRecipients = "balaji.sukhadevghadage@vodafone.com, monika.gupta1@vodafone.com, murali.manam@vodafone.com, devops-vfuk-integration@vodafone.com, varun.kulkarni@vodafone.com, rachit.gargava@vodafone.com"
SIT_mailRecipients = "vfukintegrationadtil@vodafone.com, madhu.bshivanna@vodafone.com, monika.gupta1@vodafone.com, amol.belsare@vodafone.com, kartik.namjoshi@vodafone.com, nitisha.tambe@vodafone.com"


Apvl_TL_Name=""
Apvl_TL_Status=""
Apvl_TL_Date=""
Apvl_TL_Comments=""
SUBMITTED_DATE = ""

pipeline {
    agent any
    options {
       	timeout(time: 5, unit: 'DAYS')
    }
environment {
    
        //RN_ERROR_CODE = ""
        //RN_ERROR_MSG = ""
                        
        REPO_URL = "http://195.233.197.150:8081/repository"
		NEXUS_URL = "http://195.233.197.150:8081"
		NEXUS_USER = "admin"
		NEXUS_PASSWD = "admin123"
		BW_GROUPID = "TIL_BW"
		EMS_GROUPID = "TIL_EMS"
		SQL_GROUPID="TIL_SQL"
        SOURCE_REPO="LINKTEST_REPO"
		TARGET_REPO = "SIT_REPO"
        dbURL = 'jdbc:oracle:thin:@195.233.199.13:33000:TIBTST1'
		dbUserName = 'CICD_OWN_DB01'
		dbPassword = 'TIL_CICD_DB'
		dbDriver = 'oracle.jdbc.driver.OracleDriver'
    }
    
    stages {
		stage('Preparation') {
			steps {
				script{
					env.PIPELINE_URL = "$BUILD_URL"
                    preparation_function()
                    SITReleaseTechLeadApprovers = get_approvers_list('SITReleaseTechLeadApprovers')
                    }
            }
        }        
     
        stage('Fetch values')
        {
        steps {
				script{
					fetchvalues("${params.TDD_ID}")
                    }
            }
        }
        
        /*
        stage('Validate') {
			steps {
				script{
					validate()
                    }
            }
        }
        */
        
        stage('Approval Mail'){
			steps {
				script{
					techLeadmails = get_approvers_email_list(SITReleaseTechLeadApprovers) 
                    techLeadmails += "," + TLapprovers_mailRecipients
                    println(techLeadmails)
                    sendEmail(true, "Tech Lead Approval Request",techLeadmails)
                    }
            }
        }
        
         stage('Tech Lead Approval') {
			steps {
				script{					
                    techLeadmails = get_approvers_email_list(SITReleaseTechLeadApprovers) 
                    techLeadmails += "," + TLapprovers_mailRecipients
                    techLeadmails += "," + "${params.BUILD_REQUESTOR}"
                    println(techLeadmails)
                    def TLInput = input( id: 'TLInput', message: 'Do you want to Approve?',
                                            parameters: 
                                            [[$class: 'ChoiceParameterDefinition', defaultValue: 'REJECTED', 
                                            description:'Please provide your approval after validating Defect ID and JIRA NO', name:'Approval', choices: "REJECTED\nAPPROVED"],
                                            [$class: 'TextParameterDefinition', defaultValue: '', 
                                            description:'Enter the comments here', name:'Comments']],
                                            submitterParameter: 'submitter',
                                            submitter: "${SITReleaseTechLeadApprovers}"
                                           )
                    Apvl_TL_Status = TLInput.Approval
                    Apvl_TL_Name = TLInput.submitter
                    Apvl_TL_Date = new Date().format("dd/MM/yyy HH:mm")
                    Apvl_TL_Comments = TLInput.Comments
                    if(TLInput.Comments.length() != 0)
                    {
                        APPROVAL_COMMENTS = Apvl_TL_Name + "[" + Apvl_TL_Status + ": " + Apvl_TL_Date + "] : " + TLInput.Comments
                    }
                    
                    println("DEBUG: Team Lead " + Apvl_TL_Status + " the request")  
                   
                    if(Apvl_TL_Status == "REJECTED")
                    {
                        sendEmail(true, "Approval Rejected", techLeadmails)
                        currentBuild.result = 'ABORTED'
                    } 
                }
			}			
		}//stage TL Approval
        
        stage('Nexus Promotion') {
            when {
				expression { Apvl_TL_Status == "APPROVED"}
			}
			steps {
            script{					
                
                ENGINE_NAME = RELEASE_DATA['ENGINE_NAME']
                BW_VERSION = RELEASE_DATA['BW_VERSION']
                EMS_VERSION = RELEASE_DATA['EMS_VERSION']
                SQL_VERSION = RELEASE_DATA['SQL_VERSION']

                echo "Artefact Will be promoted"
                if(BW_VERSION.trim() != "NA"){
                    bw_eng = "${ENGINE_NAME}"
					bw_ver = "${BW_VERSION}".trim()
									
                    artifactPromotion artifactId: bw_eng, classifier: '', debug: true, extension: 'ear', groupId: "${env.BW_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.TARGET_REPO}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.SOURCE_REPO}", stagingUser: "${env.NEXUS_USER}", version: bw_ver
                    artifactPromotion artifactId: bw_eng, classifier: '', debug: true, extension: 'appconf', groupId: "${env.BW_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.TARGET_REPO}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.SOURCE_REPO}", stagingUser: "${env.NEXUS_USER}", version: bw_ver
                    artifactPromotion artifactId: bw_eng, classifier: '', debug: true, extension: 'html', groupId: "${env.BW_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.TARGET_REPO}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.SOURCE_REPO}", stagingUser: "${env.NEXUS_USER}", version: bw_ver
                    artifactPromotion artifactId: bw_eng, classifier: '', debug: true, extension: 'proddiff', groupId: "${env.BW_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.TARGET_REPO}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.SOURCE_REPO}", stagingUser: "${env.NEXUS_USER}", version: bw_ver
                    artifactPromotion artifactId: bw_eng, classifier: '', debug: true, extension: 'txt', groupId: "${env.BW_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.TARGET_REPO}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.SOURCE_REPO}", stagingUser: "${env.NEXUS_USER}", version: bw_ver
                }
                if(EMS_VERSION.trim() != "NA"){
                    ems_eng = "${ENGINE_NAME}"
                    ems_ver = "${EMS_VERSION}".trim()
                    
                    artifactPromotion artifactId: ems_eng, classifier: '', debug: true, extension: 'tar.gz', groupId: "${env.EMS_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.TARGET_REPO}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.SOURCE_REPO}", stagingUser: "${env.NEXUS_USER}", version: ems_ver
                    artifactPromotion artifactId: ems_eng, classifier: '', debug: true, extension: 'txt', groupId: "${env.EMS_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.TARGET_REPO}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.SOURCE_REPO}", stagingUser: "${env.NEXUS_USER}", version: ems_ver
                }
                if(SQL_VERSION.trim() != "NA"){
                    sql_eng = "${ENGINE_NAME}"
                    sql_ver = "${SQL_VERSION}".trim()
                    
                    artifactPromotion artifactId: sql_eng, classifier: '', debug: true, extension: 'tar.gz', groupId: "${env.SQL_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.TARGET_REPO}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.SOURCE_REPO}", stagingUser: "${env.NEXUS_USER}", version: sql_ver
                    artifactPromotion artifactId: sql_eng, classifier: '', debug: true, extension: 'txt', groupId: "${env.SQL_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.TARGET_REPO}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.SOURCE_REPO}", stagingUser: "${env.NEXUS_USER}", version: sql_ver
                }
            }				
            }			
		}//stage Nexus Promotion
        
        stage('Email'){
			when {
				expression { Apvl_TL_Status == "APPROVED"}
			}
            steps {
				script{
                    SIT_mailRecipients += ", " + "${params.BUILD_REQUESTOR}"
                    sendEmail(false,"",SIT_mailRecipients)
                    }
            }
        }
    }

post {
        always {
				script {
                    def updateQuery = ""
					if ( "${currentBuild.currentResult}" == "SUCCESS" && Apvl_TL_Status == "APPROVED") {
						env.RN_ERROR_CODE = "200"
                        env.RN_ERROR_MSG = "SIT RN SUCCESS"
                        updateQuery = "UPDATE CICD_RELEASES SET MODIFIED_BY='${params.BUILD_REQUESTOR}', SIT_RN_URL='${BUILD_URL}', ERROR_CODE = '${env.RN_ERROR_CODE}', ERROR_DESCRIPTION = '${env.RN_ERROR_MSG}', STAGE_COMPLETED='SIT_RN' WHERE TDD_ID=${params.TDD_ID}"
                        println("Success Scenario")                                               
					} 
                    else if (Apvl_TL_Status != "APPROVED")
                    {   
                        env.RN_ERROR_CODE = "610"
                        env.RN_ERROR_MSG = "SIT RN REJECTED"
                        updateQuery = "UPDATE CICD_RELEASES SET MODIFIED_BY='${params.BUILD_REQUESTOR}', SIT_RN_URL='${BUILD_URL}', ERROR_CODE = '${env.RN_ERROR_CODE}', ERROR_DESCRIPTION = '${env.RN_ERROR_MSG}' WHERE TDD_ID=${params.TDD_ID}"
                        println("Rejected")
                    }                        
                    else {
 						env.RN_ERROR_CODE = "609"
                        env.RN_ERROR_MSG = "SIT RN Generation FAILED " 
                        updateQuery = "UPDATE CICD_RELEASES SET MODIFIED_BY='${params.BUILD_REQUESTOR}', SIT_RN_URL='${BUILD_URL}', ERROR_CODE = '${env.RN_ERROR_CODE}', ERROR_DESCRIPTION = '${env.RN_ERROR_MSG}' WHERE TDD_ID=${params.TDD_ID}"  
                        println("Other Failure")                        
                        }
                    println("Error Code : "+env.RN_ERROR_CODE)
                    println("Error MSG : "+env.RN_ERROR_MSG)

                    println("DEBUG: Update query is: " + updateQuery)

                    
					DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: updateQuery                    
					} 
					
				}
		}
}	                    
