// Calling global functions from shared libraries.
//@Library('myLibrary@master') _


//[CICD-476] Fix: import this package as part of the fix
import groovy.time.*

//[CICD-539] Insert Deployment metadata to release notes DB.
import groovy.json.JsonOutput
import groovy.sql.*
import java.sql.Driver
import hudson.tasks.Mailer;
import hudson.model.User;
        

def dbInsertOrUpdate(deployParams) {
	  
    int retryCount = 0;
    def error = ""
    def mySQL
    while (1) 
    {
       if( retryCount > 0 && retryCount % 3 ==0 )
       {
        input 'Proceed or Abort?'      
       }
       try {
            mySQL =  myGetDBConnect dbURL: deployParams.dbURL, dbUserName: deployParams.dbUserName, dbPassword: deployParams.dbPassword, dbDriver: deployParams.dbDriver
            mySQL.connection.autoCommit = false
            println("Executing Query :" + deployParams.insertQuery)
            int rowAffected = mySQL.executeUpdate(deployParams.insertQuery);
            mySQL.commit()
            mySQL.close()
            mySQL = null
            println("Insert/Update " + rowAffected + " row(s)")
            return true
        }
       catch(Exception ex) {
            println("Error in Executing Query :" + deployParams.insertQuery) 
            mySQL.rollback()
            mySQL.close()
            mySQL = null
            println("Exception caught : " + ex); 
            println("Sleeping for 5 seconds .... Will Retry "+ (retryCount+1))
            println "Red Alert!! Inform CICD Team ++ DB Error ++ ${ex} ++ ${deployParams.insertQuery}"
            sleep 5            
        }
        retryCount++
    }     
    return false       
}


pipeline {
	agent any
	options {
        	timeout(time: 5, unit: 'DAYS')
	}
	environment {	

        	REPO_URL = "http://195.233.197.150:8081/repository"
		NEXUS_URL = "195.233.197.150:8081"
		Promotion_Repo = "SIT_REPO"
		BW_GROUPID = "TIL_BW"
		EMS_GROUPID = "TIL_EMS"
		SQL_GROUPID="TIL_SQL"
		emsIgnore = "true"
		NEXUS_REPO = "LINKTEST_REPO"
		NEXUS_VERSION="nexus3"
		BW_InstanceCount = 2
		//[CICD-539] Insert Deployment metadata to release notes DB.
        	EnvironmentRepository = "TIL_TestEnv_Configurations"
		dbURL = 'jdbc:oracle:thin:@195.233.199.13:33000:TIBTST1'
		dbDriver = 'oracle.jdbc.driver.OracleDriver'
		
	}
	
	stages {
		stage('Preparation') {
			steps {
                		script {
					println("Hellow World");
		            		//def insert_query = """Insert into CICD_RELEASES ("SEQ_NO","RELEASE_NO","ENGINE_NAME","BW_VERSION","EMS_VERSION","SQL_VERSION","ONLY_GV","FILE_DEPLOYMENT","PROJECT_NAME","OPERATION","CHANGE_REF_ID","CHANGE_REF_DESCRIPTION","ENGINE_TYPE","FILE_CHANGES","APPEND_PREPEND","SPECIAL_INSTRUCTIONS","ENV_MASTER_CONF","PROCESS_MASTER_CONF","LT_ENV","BW_BUILD_URL","STATUS") values ('${params.SEQ_NO}','${params.RELEASE}','${params.ENGINE_NAME}','${params.BW_VERSION}','${ENGINE_MAP[ENGINE_NAME]['EMS_VERSION']}','${ENGINE_MAP[ENGINE_NAME]['SQL_VERSION']}','${params.ONLY_GV}','${FILE_Deploy}','${params.PROJECT_NAME}','${params.OPERATION_NAME}','${params.CHANGE_REF_ID}','${params.DESCRIPTION}','${params.ENGINE_TYPE}','${params.DEPLOYMENT_FILES}','${APPEND_PREPEND_V}','${params.SPECIAL_INSTRUCTIONS}','${params.MASTER_GV_UPDATE}','${params.PROCESS_GV_UPDATE}','${params.ENVIRONMENT}','${BUILD_URL}','Active')"""
					def insert_query = """Hello"""
					println("DEBUG: Insert query is: " + insert_query)
					//dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: insert_query 

				}
			}
		}
	}
}
  
