pipeline {
    agent any
    stages {
		stage('Preparation') {
					steps {
						script{
							//Call the preparation function.
							echo "Preparation is done2"
						}				
					}		
		}
    }
}
