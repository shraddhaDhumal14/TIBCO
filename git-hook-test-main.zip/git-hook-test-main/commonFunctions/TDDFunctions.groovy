
/*********************************************************************************************************************
Author: Ram Shankar
Date: 04/07/2022
/*********************************************************************************************************************
This file holds all the functions related to TDD Development
Below are the functions listed in this file.


*********************************************************************************************************************/

def myGetDBConnect(deployParams) {     
     def mySQL = groovy.sql.Sql.newInstance(deployParams.dbURL,deployParams.dbUserName,deployParams.dbPassword,deployParams.dbDriver)
     return mySQL
}

def dbInsertOrUpdate(deployParams) {
	  
    int retryCount = 0;
    while (1) 
    {
       if( retryCount > 0 && retryCount % 3 ==0 )
       {
        input 'Proceed or Abort?'      
       }
       try {
            mySQL =  myGetDBConnect dbURL: deployParams.dbURL, dbUserName: deployParams.dbUserName, dbPassword: deployParams.dbPassword, dbDriver: deployParams.dbDriver
            mySQL.connection.autoCommit = false
            println("Executing Query :" + deployParams.insertQuery)
            int rowAffected = mySQL.executeUpdate(deployParams.insertQuery);
            mySQL.commit()
            mySQL.close()
            mySQL = null
            println("Insert/Update " + rowAffected + " row(s)")
            return true
        }
       catch(Exception ex) {
            println("Error in Executing Query :" + deployParams.insertQuery) 
            mySQL.rollback()
            mySQL.close()
            mySQL = null
            println("Sleeping for 60 seconds .... Will Retry "+ (retryCount+1)) 
            //println "Red Alert!! Inform CICD Team ++ DB Insert Error ++ ${ex}" 			
            sleep 60         
        }
        retryCount++
    }     
    return false       
}

def GitClone(RepoName, TargetDirectory, BranchName )
{
    int retryCount = 0;
    def error = ""
    while (1) 
    {
       if( retryCount > 0 && retryCount % 3 ==0 )
       {
        input 'Proceed or Abort?'      
       }
       try {
            
            checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: "*/${BranchName}"]], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${TargetDirectory}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: "https://github.vodafone.com/VFUK-INTEGRATION/${RepoName}.git"]]]
            return true
       }
       catch(Exception ex) 
	   {
		    println("Exception caught : " + ex + "while downloading Repo " +  RepoName);
            println("Sleeping for 60 seconds .... Will Retry "+ (retryCount+1)) 
            //println "Red Alert!! Inform CICD Team ++ Git Error ++ ${ex}"   
            sleep 60
                        
            //env.BP_ERROR_CODE = "203"
			//env.BP_ERROR_MSG = "Github connection failed"
			//println(env.BP_ERROR_CODE + " : " +  env.BP_ERROR_MSG)
			//println("Github connection failed.")
			//currentBuild.result = 'ABORTED'                      
        }
        retryCount++
    }     
    return false       
}

def NexusUpload(artifactId, artifactfile, artifactfiletype, artifactGroup, artifactRepo, artifactVersion)
{                  
    int retryCount = 0;
    def nexusUrl = "195.233.197.150:8081"
    def error = ""
    def objURL 
    while (1) 
    {
           if( retryCount > 0 && retryCount % 3 ==0 )
           {
            input 'Proceed or Abort?'      
           }
            try {
                    objURL = new URL("http://${nexusUrl}").getText()
                    nexusArtifactUploader artifacts: [[artifactId: "${artifactId}", classifier: '', file: "${artifactfile}", type: "${artifactfiletype}"]], credentialsId: '74edde97-94e0-403c-93f6-cad6c46c45f8', groupId: "${artifactGroup}", nexusUrl: "${nexusUrl}", nexusVersion: 'nexus3', protocol: 'http', repository: "${artifactRepo}", version: "${artifactVersion}"
								
                    return true
                }
            catch(Exception ex) {
                    objURL = null
                    println("Exception caught : " + ex); 
                    println("Sleeping for 60 seconds .... Will Retry "+ (retryCount+1))
                    println "Red Alert!! Inform CICD Team ++ Nexus Error ++ ${ex} ++ ${error} "                    
                    sleep 60
                                      
					
                    //env.BP_ERROR_CODE = "205"
					//env.BP_ERROR_MSG = "NEXUS connection failed } "
					//insert_errorcode('000002', '205')
					//println(env.BP_ERROR_CODE + " : " +  env.BP_ERROR_MSG)
            }
            retryCount++              
    }  
    return false       
}

def errorCodeDecide(error_code, error_desc, pipeline_url)
{
    if(error_code == "")
    {
        echo "No Error Code found"
        sendEmail_ErrorNotification(error_code, error_desc, pipeline_url, devopsmail, "Action Required from ${ERROR_ACTIONEE}")
        return false;
    }
    
    cbuser = currentBuild.rawBuild.causes[0].userId
    sh(script: "line=`grep '${error_code}' CODE/Error_Codes`; echo \$line | awk -F~ '{print \$2}' > errdes; echo \$line | awk -F~ '{print \$3}' > erract; echo \$line | awk -F~ '{print \$4}' > erractne;");
    ERROR_DESC = sh(script: "cat errdes", returnStdout: true).trim()
    ERROR_ACTION = sh(script: "cat erract", returnStdout: true).trim()
    ERROR_ACTIONEE = sh(script: "cat erractne", returnStdout: true).trim()
    
    if(ERROR_ACTION == "Proceed") {
        return true;
    } else if(ERROR_ACTION == "HOLD" && ERROR_ACTIONEE == "Developer"){
        sendEmail_ErrorNotification(error_code, error_desc, pipeline_url, cbuser, "Action Required from ${ERROR_ACTIONEE}")
        return false;
    } else if (ERROR_ACTION == "HOLD" && ERROR_ACTIONEE == "DevOps"){
        sendEmail_ErrorNotification(error_code, error_desc, pipeline_url, devopsmail, "Action Required from ${ERROR_ACTIONEE}")
        return false;
    } else if(ERROR_ACTION == "Restart from Stage" && ERROR_ACTIONEE == "Developer"){
        sendEmail_ErrorNotification(error_code, error_desc, pipeline_url, cbuser, "Action Required from ${ERROR_ACTIONEE}")
        return false;
    } else if (ERROR_ACTION == "Restart from Stage" && ERROR_ACTIONEE == "DevOps"){
        sendEmail_ErrorNotification(error_code, error_desc, pipeline_url, devopsmail, "Action Required from ${ERROR_ACTIONEE}")
        return false;
    } else if(ERROR_ACTION == "Abort" && ERROR_ACTIONEE == "Developer"){
        sendEmail_ErrorNotification(error_code, error_desc, pipeline_url, cbuser, "Action Required from ${ERROR_ACTIONEE}")
       return false;
    } else if(ERROR_ACTION == "Abort" && ERROR_ACTIONEE == "DevOps"){
        sendEmail_ErrorNotification(error_code, error_desc, pipeline_url, devopsmail, "Action Required from ${ERROR_ACTIONEE}")
        return false;
    } else {
        echo "No Error Code found"
        sendEmail_ErrorNotification(error_code, error_desc, pipeline_url, devopsmail, "Action Required from ${ERROR_ACTIONEE}")
        return false;
    } 
}

def sendEmail_ErrorNotification(error_code, error_desc, pipeline_url, emailRecipents, emailSubject)
{
    emailContent="Error Code : ${error_code}<BR> Error Description${error_desc}<BR> Error Pipeline${pipeline_url} <BR> Current Pipeline ${BUILD_URL}"
    
    emailext mimeType: 'text/html', 
    subject: "${emailSubject}",  
    from:"BW_ORCHESTRATOR@vodafone.com", 
    to: "${emailRecipents}", 
    body: "${emailContent}"
}

return this