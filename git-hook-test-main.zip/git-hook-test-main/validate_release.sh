#!/bin/bash

curl -H "Authorization: token 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" https://github.vodafone.com/api/v3/repos/VFUK-INTEGRATION/RIT_$2/branches?per_page=100 >RIT_branches.tmp

echo "true" >RIT_repofound.tmp

if [[ "`jq .message RIT_branches.tmp 2>/dev/null`" == '"Not Found"' ]]
then
  echo "RIT_$2 Repo not found" > RIT_release.tmp
  echo "false" >RIT_repofound.tmp
        exit;
fi

jq .[].name RIT_branches.tmp >tmp_RIT_branches.tmp
mv tmp_RIT_branches.tmp RIT_branches.tmp

grep \"$1\" RIT_branches.tmp|head -1|cut -c2- | rev | cut -c2- | rev >RIT_release.tmp
grep "main" RIT_branches.tmp>RIT_main.tmp
grep "master" RIT_branches.tmp>RIT_master.tmp

if [[ -s RIT_release.tmp ]]
then
        :
elif [[ -s RIT_main.tmp ]]
then
        echo "main" >RIT_release.tmp
elif [[ -s RIT_master.tmp ]]
then
        echo "master" >RIT_release.tmp
fi
