#!/bin/bash
# To get all the commit data for the Repo


tmp_commit=$1   # $1 can be passed from yml file
#echo "Starting the loop"

clear_files()
{
    if [ -s $1'_Process_GV_Added.txt' ];
	then
        rm -v $1'_Process_GV_Added.txt'
	fi

	if [ -s $1'_Process_GV_Removed.txt' ];
	then
        rm -v $1'_Process_GV_Removed.txt'
	fi

	if [ -s $1'_Env_GV_Added.txt' ];
	then
        rm -v $1'_Env_GV_Added.txt'
	fi
	
	if [ -s $1'_Env_GV_Removed.txt' ];
	then
        rm -v $1'_Env_GV_Removed.txt'
	fi
	if [[ $1 == "BW_Config" ]]
	then
		 > master_gv_update.tmp	    
         > process_gv_update.tmp
		 > Prconf_Added.txt
		 > Prconf_Removed.txt
		 > pr_conf_file.tmp
		 > BW_Config_Env_GV_Modified.txt
		 > BW_Config_Process_GV_Modified.txt
	else
		 > special_instructions.tmp
		 > Prepend_Added.txt
		 > Append_Added.txt
		 > Prepend_Removed.txt
		 > Append_Removed.txt
		 > TestEnv_Env_GV_Modified.txt
		 > TestEnv_Process_GV_Modified.txt
	fi	
}
clear_files $2
gv_commit_url=""
j=0
k=0
l=0
tmp_count=0
declare -a url_counter_arr
declare -a ap_counter_arr
Parsing_GV(){
# Getting all the information for the commit
echo "$gv_commit_url"
curl -H "Authorization: token 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" "$gv_commit_url" > gv_commit_result.tmp

#Store the changes
tmp_gv_name=$(jq .files[].patch "gv_commit_result.tmp" | cut -c2- | rev | cut -c2- |rev)

echo "$tmp_gv_name"
gvarr=()
delimiter="\n"
tmp_string=$tmp_gv_name$delimiter
while [[ $tmp_string ]];
do
        gvarr+=( "${tmp_string%%"$delimiter"*}" )
        tmp_string=${tmp_string#*"$delimiter"}
done
echo "${gvarr[@]}"
for itr in "${gvarr[@]}"
do
echo "itr in for loop $itr"
if [[  $itr =~ ^\+Processes.* ]]
then
        #echo "$itr"|grep ^+ |cut -c2- |sed 's/\\r//g' | grep ^Processes >> $1'_Process_GV_Added.txt'
		itr=$(echo "$itr"|grep ^+ |cut -c2- |sed 's/\\r//g')
        echo itr
        if [[ -s $1'_Process_GV_Removed.txt' ]] && grep -Fxq "$itr" $1'_Process_GV_Removed.txt'
        then
                #sed -i '/"${itr}"/d' Process_GV_Added.txt
                grep -v "${itr}" $1'_Process_GV_Removed.txt' > tmpfile
				mv tmpfile $1'_Process_GV_Removed.txt'
        else
                echo "$itr" >> $1'_Process_GV_Added.txt'
        fi
elif [[ $itr =~ ^\-Processes.* ]]
then
        itr=$(echo "$itr"|grep ^- |cut -c2- |sed 's/\\r//g')
        echo itr
        if [[ -s $1'_Process_GV_Added.txt' ]] && grep -Fxq "$itr" $1'_Process_GV_Added.txt'
        then
                #sed -i '/"${itr}"/d' Process_GV_Added.txt
                grep -v "${itr}" $1'_Process_GV_Added.txt' > tmpfile
				mv tmpfile $1'_Process_GV_Added.txt'
        else
                echo "$itr" >> $1'_Process_GV_Removed.txt'
        fi
elif [[ $itr =~ ^\+.* ]]
then
        #echo "$itr"|grep ^+ |cut -c2- |sed 's/\\r//g' | grep -v ^Processes >> $1'_Env_GV_Added.txt'
		itr=$(echo "$itr"|grep ^+ |cut -c2- |sed 's/\\r//g')
		echo "irt for env values : $itr"
        if [[ -s $1'_Env_GV_Removed.txt' ]] && grep -Fxq "$itr" $1'_Env_GV_Removed.txt'
        then
                #sed -i '/"${itr}"/d' Env_GV_Added.txt
                grep -v "${itr}" $1'_Env_GV_Removed.txt' > tmpfile
				mv tmpfile $1'_Env_GV_Removed.txt'
        else
                echo "$itr" >> $1'_Env_GV_Added.txt'
        fi
elif [[ $itr =~ ^-.* ]]
then
        itr=$(echo "$itr"|grep ^- |cut -c2- |sed 's/\\r//g')
		echo "irt for env values : $itr"
        if [[ -s $1'_Env_GV_Added.txt' ]] && grep -Fxq "$itr" $1'_Env_GV_Added.txt'
        then
                #sed -i '/"${itr}"/d' Env_GV_Added.txt
                grep -v "${itr}" $1'_Env_GV_Added.txt' > tmpfile
				mv tmpfile $1'_Env_GV_Added.txt'
        else
                echo "$itr" >> $1'_Env_GV_Removed.txt'
        fi
fi
done
}

Parsing_Append_Prepend()
{
	echo "$gv_commit_url"
	curl -H "Authorization: token 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" "$gv_commit_url" > gv_commit_result.tmp

#Store the changes
tmp_gv_name=$(jq .files[].patch "gv_commit_result.tmp" | cut -c2- | rev | cut -c2- |rev)

echo "$tmp_gv_name"
gvarr=()
delimiter="\n"
tmp_string=$tmp_gv_name$delimiter
while [[ $tmp_string ]];
do
        gvarr+=( "${tmp_string%%"$delimiter"*}" )
        tmp_string=${tmp_string#*"$delimiter"}
done
for itr in "${gvarr[@]}"
do
if [[  $itr =~ ^\+Prepend.* ]]
then
        echo "$itr"|grep ^+ |cut -c2- |sed 's/\\r//g' | grep ^Prepend >> Prepend_Added.txt
		itr=$(echo "$itr"|grep ^+ |cut -c2- |sed 's/\\r//g')
        echo itr
        if [[ -s Prepend_Removed.txt ]] && grep -Fxq "$itr" Prepend_Removed.txt
        then
                #sed -i '/"${itr}"/d' Process_GV_Added.txt
                grep -v "${itr}" Prepend_Removed.txt > tmpfile
				mv tmpfile Prepend_Removed.txt
        else
                echo "$itr" >> Prepend_Added.txt
        fi
		
elif [[ $itr =~ ^\-Prepend.* ]]
then
        itr=$(echo "$itr"|grep ^- |cut -c2- |sed 's/\\r//g')
        echo itr
        if [[ -s Prepend_Added.txt ]] && grep -Fxq "$itr" Prepend_Added.txt
        then
                #sed -i '/"${itr}"/d' Process_GV_Added.txt
                grep -v "${itr}" Prepend_Added.txt > tmpfile
				mv tmpfile Prepend_Added.txt
        else
                echo "$itr" >> Prepend_Removed.txt
        fi
elif [[ $itr =~ ^\+Append.* ]]
then
        echo "$itr"|grep ^+ |cut -c2- |sed 's/\\r//g' | grep ^Append >> Append_Added.txt
		itr=$(echo "$itr"|grep ^+ |cut -c2- |sed 's/\\r//g')
        if [[ -s Append_Removed.txt ]] && grep -Fxq "$itr" Append_Removed.txt
        then
                #sed -i '/"${itr}"/d' Env_GV_Added.txt
                grep -v "${itr}" Append_Removed.txt > tmpfile
				mv tmpfile Append_Removed.txt
        else
                echo "$itr" >> Append_Added.txt
        fi
elif [[ $itr =~ ^\-Append.* ]]
then
        itr=$(echo "$itr"|grep ^- |cut -c2- |sed 's/\\r//g')
        if [[ -s Append_Added.txt ]] && grep -Fxq "$itr" Append_Added.txt
        then
                #sed -i '/"${itr}"/d' Env_GV_Added.txt
                grep -v "${itr}" Append_Added.txt > tmpfile
				mv tmpfile Append_Added.txt
        else
                echo "$itr" >> Append_Removed.txt
        fi
fi
done
}

Parsing_Prconf()
{
	echo "$gv_commit_url"
	curl -H "Authorization: token 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" "$gv_commit_url" > gv_commit_result.tmp

#Store the changes
tmp_gv_name=$(jq .files[].patch "gv_commit_result.tmp" | cut -c2- | rev | cut -c2- |rev)

echo "$tmp_gv_name"
prarr=()
delimiter="\n"
tmp_string=$tmp_gv_name$delimiter
while [[ $tmp_string ]];
do
        prarr+=( "${tmp_string%%"$delimiter"*}" )
        tmp_string=${tmp_string#*"$delimiter"}
done
for itr in "${prarr[@]}"
do
if [[  $itr =~ ^\+.* ]]
then
        #echo "$itr"|grep ^+ |cut -c2- |sed 's/\\r//g' >> Prconf_Added.txt
		itr=$(echo "$itr"|grep ^+ |cut -c2- |sed 's/\\r//g')
        echo itr
        if [[ -s Prconf_Removed.txt ]] && grep -Fxq "$itr" Prconf_Removed.txt
        then
                #sed -i '/"${itr}"/d' Process_GV_Added.txt
                grep -v "${itr}" Prconf_Removed.txt > tmpfile
				mv tmpfile Prconf_Removed.txt
        else
                echo "$itr" >> Prconf_Added.txt
        fi
elif [[ $itr =~ ^\-.* ]]
then
        itr=$(echo "$itr"|grep ^- |cut -c2- |sed 's/\\r//g')
        echo itr
        if [[ -s Prconf_Added.txt ]] && grep -Fxq "$itr" Prconf_Added.txt
        then
                #sed -i '/"${itr}"/d' Process_GV_Added.txt
                grep -v "${itr}" Prconf_Added.txt > tmpfile
				mv tmpfile Prconf_Added.txt
        else
                echo "$itr" >> Prconf_Removed.txt
        fi
fi
done

}

#GV_Values Process Added
GV_Values(){

gv_file="BW_Config_${1}_GV_${2}.txt"
while read f1
do
if [[ $f1 =~ ^.*=$ ]]
then
echo "if condition is working"
gv_count=$(cat "${1}_gv.conf" | grep  "^${f1}" | wc -l)
if [[ $gv_count -eq 1 ]];
then
        cat "${1}_gv.conf" | grep  "^${f1}" >> tmp_gv_file.txt
else
        echo $f1 >> tmp_gv_file.txt
fi
else
        echo $f1 >> tmp_gv_file.txt
fi
done < "${gv_file}"

cp -f tmp_gv_file.txt "${gv_file}"
rm -v tmp_gv_file.txt
}

GV_Commit_Call() {
i=0
tmp_count=0
while read f1
do
         echo "$f1 "
        echo "inside loop iteration number $i";
   #if [ "$f1" =~ ^${$1}.* ]
        if [[ $f1 =~ ^$tmp_commit ]];
        then
			commit_url=`jq .[$i].url commit_hist.tmp | cut -c2- | rev | cut -c2- |rev`
			file_name=`curl -H "Authorization: token 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" $commit_url | jq .files[].filename | cut -c2- | rev | cut -c2- |rev | xargs  basename`
			if [[ $file_name =~ \.'gvconf'$ ]]
			then
				echo "Inside commit file check if condition"
                url_counter_arr[tmp_count]=$i
				tmp_count=$(($tmp_count+1))
			fi
        fi
        i=$(($i +1))
done < commit_message.tmp

for (( arr_i=${#url_counter_arr[@]}-1 ; arr_i>=0 ; arr_i-- )) ; 
do  
    # tmp_sha=$(jq .[$i].sha commit_hist.tmp);
    echo "${url_counter_arr[arr_i]}"
	gv_commit_url=`jq .[${url_counter_arr[arr_i]}].url commit_hist.tmp | cut -c2- | rev | cut -c2- |rev`
	echo "GV_Commit values before calling the function $gv_commit_url"
	Parsing_GV $1
done
}

Test_GV_Commit_Call() {
i=0
tmp_count=0
while read f1
do
         echo "$f1 "
        echo "inside loop iteration number $i";
   #if [ "$f1" =~ ^${$1}.* ]
        if [[ $f1 =~ ^$tmp_commit ]];
        then
			commit_url=`jq .[$i].url commit_hist.tmp | cut -c2- | rev | cut -c2- |rev`
			file_name=`curl -H "Authorization: token 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" $commit_url | jq .files[].filename | cut -c2- | rev | cut -c2- |rev | xargs  basename`
			if [[ $file_name =~ ^'LT_'$2.*\.'gvconf'$ ]]
			then
				echo "Inside commit file check if condition"
                url_counter_arr[tmp_count]=$i
				tmp_count=$(($tmp_count+1))
			fi
        fi
        i=$(($i +1))
done < commit_message.tmp

for (( arr_i=${#url_counter_arr[@]}-1 ; arr_i>=0 ; arr_i-- )) ; 
do  
    # tmp_sha=$(jq .[$i].sha commit_hist.tmp);
    echo "${url_counter_arr[arr_i]}"
	gv_commit_url=`jq .[${url_counter_arr[arr_i]}].url commit_hist.tmp | cut -c2- | rev | cut -c2- |rev`
	echo "GV_Commit values before calling the function $gv_commit_url"
	Parsing_GV $1
done
}

Append_Prepend() {
i=0
tmp_count=0
while read f1
do
         echo "$f1 "
        echo "inside loop iteration number $i";
   #if [ "$f1" =~ ^${$1}.* ]
        if [[ $f1 =~ ^$tmp_commit ]]
        then
			commit_url=`jq .[$i].url commit_hist.tmp | cut -c2- | rev | cut -c2- |rev`
			file_name=`curl -H "Authorization: token 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" $commit_url | jq .files[].filename | cut -c2- | rev | cut -c2- |rev | xargs  basename`
			if [[ $file_name == "AppendPrependConfiguration.conf" ]]
			then
				echo "Inside commit check if condition"
                ap_counter_arr[tmp_count]=$i
				tmp_count=$(($tmp_count+1))
			fi
        fi
        i=$(($i +1))
done < commit_message.tmp

for (( arr_i=${#ap_counter_arr[@]}-1 ; arr_i>=0 ; arr_i-- )) ; 
do  
    # tmp_sha=$(jq .[$i].sha commit_hist.tmp);
    echo "${url_counter_arr[arr_i]}"
	gv_commit_url=`jq .[${ap_counter_arr[arr_i]}].url commit_hist.tmp | cut -c2- | rev | cut -c2- |rev`
	echo "GV_Commit values before calling the function $gv_commit_url"
	Parsing_Append_Prepend
done
}

Prconf() {
i=0
tmp_count=0
while read f1
do
         echo "$f1 "
        echo "inside loop iteration number $i";
   #if [ "$f1" =~ ^${$1}.* ]
        if [[ $f1 =~ ^$tmp_commit ]]
        then
			commit_url=`jq .[$i].url commit_hist.tmp | cut -c2- | rev | cut -c2- |rev`
			file_name=`curl -H "Authorization: token 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" $commit_url | jq .files[].filename | cut -c2- | rev | cut -c2- |rev | xargs  basename`
			if [[ $file_name =~ \.'prconf'$ ]]
			then
				echo "Inside commit check if condition"
                pr_counter_arr[tmp_count]=$i
				tmp_count=$(($tmp_count+1))
			fi
        fi
        i=$(($i +1))
done < commit_message.tmp

for (( arr_i=${#pr_counter_arr[@]}-1 ; arr_i>=0 ; arr_i-- )) ; 
do  
    # tmp_sha=$(jq .[$i].sha commit_hist.tmp);
    echo "${pr_counter_arr[arr_i]}"
	gv_commit_url=`jq .[${pr_counter_arr[arr_i]}].url commit_hist.tmp | cut -c2- | rev | cut -c2- |rev`
	echo "GV_Commit values before calling the function $gv_commit_url"
	Parsing_Prconf
done
}

TestEnv_GV_Values(){
gv_file="BW_Config_${1}_GV_${2}.txt"
testenv_gv_file="TestEnv_${1}_GV_${2}.txt"
if [ -s 'BW_Config_'${1}'_GV_'${2}'.txt' ];
	then
       grep -v -f "${gv_file}" "${testenv_gv_file}" > tmp_gv_file.txt
	   cp -f tmp_gv_file.txt "${testenv_gv_file}"
	   rm -v tmp_gv_file.txt
	else
	 echo "BW_Config file is not present"
fi
}

GV_add_modify(){
	
	> modified_file.tmp
	
	if [ -s ${1}'_'${2}'_GV_Removed.txt' ]
	then
		cp -f  ${1}'_'${2}'_GV_Added.txt' tmp_gv_file.txt
		while read f1
		do
         echo "$f1"
		 GV_Value=`echo "$f1"|cut -d= -f1`
         if grep "$GV_Value" ${1}'_'${2}'_GV_Removed.txt'
		 then
                #sed -i '/"${itr}"/d' Env_GV_Added.txt
				grep -v "${f1}" tmp_gv_file.txt > tmpfile
				grep "${f1}" tmp_gv_file.txt >> modified_file.tmp
				mv tmpfile tmp_gv_file.txt
				grep -v "${GV_Value}" ${1}'_'${2}'_GV_Removed.txt' > tmpfile
				mv tmpfile ${1}'_'${2}'_GV_Removed.txt'         
         fi
       done < ${1}'_'${2}'_GV_Added.txt'
	   mv tmp_gv_file.txt ${1}'_'${2}'_GV_Added.txt'
	   mv modified_file.tmp ${1}'_'${2}'_GV_Modified.txt'
	   rm -v tmp_gv_file.txt
	   rm -v modified_file.tmp 
	else
		echo "No GV is removed or modified"
	fi
}

# To fetch values from Test_ENV repo for enviroment specific and engine specific
if [ "$2" == "BW_Config" ]
then
	echo "In BW_Config function"
	curl -H "Authorization: token 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" https://github.vodafone.com/api/v3/repos/VFUK-INTEGRATION/TIL_BW_Application_Configuration/commits?per_page=100 > commit_hist.tmp
	jq .[].commit.message commit_hist.tmp | cut -c2- | rev | cut -c2- |rev  > commit_message.tmp   # to store commit message so we can get URL to fetch changes as part of that commit
	
	GV_Commit_Call $2

	if [ -s $2'_Process_GV_Added.txt' ];
	then
        GV_Values Process Added
	else
        rm -v $2'_Process_GV_Added.txt'
	fi

	if [ -s $2'_Process_GV_Removed.txt' ];
	then
        echo "File is present"
	else
        rm -v $2'_Process_GV_Removed.txt'
	fi

	if [ -s $2'_Env_GV_Added.txt' ];
	then
        GV_Values Env Added
	else
        rm -v $2'_Env_GV_Added.txt'
	fi

	if [ -s $2'_Env_GV_Removed.txt' ];
	then
        echo "File is present"
	else
        rm -v $2'_Env_GV_Removed.txt'
	fi
	
	if [ -s BW_Config_Env_GV_Added.txt ];
	then
		GV_add_modify "BW_Config" "Env"		
	fi
	
	if [ -s BW_Config_Env_GV_Added.txt ];
	then
        echo -e "Master GVs added\n`cat BW_Config_Env_GV_Added.txt`\n" >> master_gv_update.tmp		
	fi
	
	if [ -s BW_Config_Env_GV_Modified.txt ]
	then
		echo -e "Master GVs  modified\n`cat BW_Config_Env_GV_Modified.txt`\n" >> master_gv_update.tmp
	fi
	
	if [ -s BW_Config_Env_GV_Removed.txt ];
	then
        echo -e "Master GVs removed\n`cat BW_Config_Env_GV_Removed.txt`" >> master_gv_update.tmp
	fi
	
	if [ -s BW_Config_Process_GV_Added.txt ];
	then
		GV_add_modify "BW_Config" "Process"
	fi
	
	if [ -s BW_Config_Process_GV_Added.txt ];
	then
        echo -e "Process GVs added\n`cat BW_Config_Process_GV_Added.txt`\n" >> process_gv_update.tmp
	fi
	
	if [ -s BW_Config_Process_GV_Modified.txt ]
	then
		echo -e "Process GVs  modified\n`cat BW_Config_Process_GV_Modified.txt`\n" >> process_gv_update.tmp
	fi	
	
	if [ -s BW_Config_Process_GV_Removed.txt ];
	then
        echo -e "Process GVs removed\n`cat BW_Config_Process_GV_Removed.txt`" >> process_gv_update.tmp
	fi

	
	Sql_Count=`curl -H "Authorization: token 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" https://github.vodafone.com/api/v3/repos/VFUK-INTEGRATION/TIL_SQL/commits?per_page=60 | grep $1 | grep message | wc -l` 

    if [ "$Sql_Count" -gt 0 ]
        then
            echo "true" > sql_deploy.tmp
    else
	        echo "false" > sql_deploy.tmp
    fi  

	Ems_Count=`curl -H "Authorization: token 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" https://github.vodafone.com/api/v3/repos/VFUK-INTEGRATION/TIL_EMS/commits?per_page=60 | grep $1 | grep message | wc -l`

    if [ "$Ems_Count" -gt 0 ]
        then
            echo "true" > ems_deploy.tmp
    else
	        echo "false" > ems_deploy.tmp			
    fi
  
  echo "false" > gv_deploy.tmp
  Prconf
  	if [ -s Prconf_Added.txt ];
	then
        echo -e "PRConf Added\n`cat Prconf_Added.txt`\n" >> pr_conf_file.tmp
	fi
	if [ -s Prconf_Removed.txt ];
	then
        echo -e "PRConf removed\n`cat Prconf_Removed.txt`" >> pr_conf_file.tmp
	fi
  
else
	echo "In TestEnv Function"
	curl -H "Authorization: token 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" https://github.vodafone.com/api/v3/repos/VFUK-INTEGRATION/TIL_TestEnv_Configurations/commits?per_page=100 > commit_hist.tmp
	jq .[].commit.message commit_hist.tmp | cut -c2- | rev | cut -c2- |rev  > commit_message.tmp   # to store commit message so we can get URL to fetch changes as part of that commit
	Test_GV_Commit_Call $2 $3
   
	if [ -s TestEnv_Process_GV_Added.txt ];
	then
        TestEnv_GV_Values Process Added
	else
        rm -v TestEnv_Process_GV_Added.txt
	fi

	if [ -s TestEnv_Process_GV_Removed.txt ];
	then
        echo "File is present"
	else
        rm -v TestEnv_Process_GV_Removed.txt
	fi

	if [ -s TestEnv_Env_GV_Added.txt ];
	then
        TestEnv_GV_Values Env Added
	else
        rm -v TestEnv_Env_GV_Added.txt
	fi

	if [ -s TestEnv_Env_GV_Removed.txt ];
	then
        echo "File is present"
	else
        rm -v TestEnv_Env_GV_Removed.txt
	fi
	
	if [ -s TestEnv_Env_GV_Added.txt ];
	then
		GV_add_modify "TestEnv" "Env"
	fi
	
	if [ -s TestEnv_Env_GV_Added.txt ];
	then
        echo -e "Master GVs value added \n`cat TestEnv_Env_GV_Added.txt`\n" >> special_instructions.tmp
	fi
	
	if [ -s TestEnv_Env_GV_Modified.txt ]
	then
		echo -e "Master GVs  modified\n`cat TestEnv_Env_GV_Modified.txt`\n" >> special_instructions.tmp
	fi
	
	if [ -s TestEnv_Env_GV_Removed.txt ];
	then
        echo -e "Master GVs removed\n`cat TestEnv_Env_GV_Removed.txt`\n" >> special_instructions.tmp
	fi
	
	if [ -s TestEnv_Process_GV_Added.txt ];
	then
		GV_add_modify "TestEnv" "Process"
	fi
	
	if [ -s TestEnv_Process_GV_Added.txt ];
	then
        echo -e "Process GVs added or modified\n`cat TestEnv_Process_GV_Added.txt`\n" >> special_instructions.tmp
	fi
	
	if [ -s TestEnv_Process_GV_Modified.txt ]
	then
		echo -e "Process GVs  modified\n`cat TestEnv_Process_GV_Modified.txt`\n" >> special_instructions.tmp
	fi
	
	if [ -s TestEnv_Process_GV_Removed.txt ];
	then
        echo -e "Process GVs removed\n`cat TestEnv_Process_GV_Removed.txt`" >> special_instructions.tmp
	fi
	
	Append_Prepend
	
	echo -e "`cat Prepend_Added.txt`\n`cat Append_Added.txt`" > append_prepend_paths.tmp
fi
