#!/bin/bash

dos2unix ENV_RELEASE_MAPPING.txt
touch FEATURE_ENV FEATURE_RELNO

while read line
do
 release=`echo $line | awk -F~ '{print $1}'`
 relmatch=`grep ^$release[^0-9] releaseno`
 if [ ! -z $relmatch  ]
 then
  echo $line | awk -F~ '{print $2}' > FEATURE_ENV
  echo $release > FEATURE_RELNO
  echo Feature env below
  cat FEATURE_ENV
  echo Feature relno below
  cat FEATURE_RELNO
  break;
 fi
done < ENV_RELEASE_MAPPING.txt
