#!/bin/sh
#
# This software is copyrighted.  Under the copyright laws, this software
# may not be copied, in whole or in part, without prior written consent
# of Vodafone Group. This software is provided under the terms of a
# license between Vodafone Group and the recipient, and its use is subject
# to the terms of that license.
#
# Description : This script is useful to disable and enable the crontab entry for gateway monitoring script
# Source the profile - this script doesn't require to call from CRON
# Commands Description:   1. ./gateway_cronjob.sh Precutover    -- Comment the Crontab entry for Gateway Monitoring Script
#                         2. ./gateway_cronjob.sh Cutover       -- Uncomment the Crontab entry for Gateway Monitoring Script
#
# Scripts to be commented : Will be loaded from the Confoguration repository depending upon the environment
# 20201206 V 1.1 - Bhargav Sutapalli
# 20220923 V 1.2 - Ram Shankar
###################################################################################################################################################

#To load the $TIBCO_HOME
source ~/.bashrc
SCRIPT_HOME="$TIBCO_HOME/scripts"
SCRIPT_BACKUP="$SCRIPT_HOME/backup"
CRONFILE_BKP="$SCRIPT_BACKUP/cronfile_backup"
CRONFILE_EDIT="$SCRIPT_BACKUP/cronfile_edit"
CRON_SCRIPTLIST="$TIBCO_HOME/scripts/crontab_scripts.txt"

mkdir -p $SCRIPT_HOME 
chmod 755 $SCRIPT_HOME
mkdir -p $SCRIPT_BACKUP
chmod 755 $CRONFILE_EDIT $CRONFILE_BKP

if [[ $1 = "Precutover" ]]
then
    echo "Debug: Inside Precutover"
    `/usr/bin/crontab -l > $CRONFILE_BKP`
    cat $CRONFILE_BKP > $CRONFILE_EDIT
    cat $CRON_SCRIPTLIST | grep -v '#' | while read ScriptName
    do
        if [[ `grep ".*$ScriptName" $CRONFILE_EDIT | wc -l` -eq 0 ]]
        then
            echo "INFO: $ScriptName script not found in Crontab"
        else
            echo "INFO: $ScriptName script found in Crontab"            
            if [[ `grep ".*$ScriptName" $CRONFILE_EDIT | grep "^#.*$ScriptName" | wc -l` -eq 0 ]]
            then
                sed -i /.*${ScriptName}/s/^/#/ $CRONFILE_EDIT
                /usr/bin/crontab $CRONFILE_EDIT
                echo "INFO: Crontab is updated by commenting script $ScriptName in `hostname`"
            else
                echo "INFO: Crontab is not updated in `hostname` for script $ScriptName. May be the $ScriptName already commented"
            fi
        fi
    done
elif [[ $1 = "Cutover" ]]
then
    echo "Debug: Inside Cutover"
    `/usr/bin/crontab -l > $CRONFILE_EDIT`
    cat $CRON_SCRIPTLIST|grep -v '#'|while read ScriptName
    do
        if [[ `grep "^#.*$ScriptName" $CRONFILE_EDIT | wc -l` -eq 0 ]]
        then
            echo "INFO: Crontab is not updated in `hostname` for script $ScriptName. May be the $ScriptName not commented"        
        else
            echo "INFO: $ScriptName script found in Crontab commented"
            sed -i /#.*${ScriptName}/s/^#// $CRONFILE_EDIT
            /usr/bin/crontab $CRONFILE_EDIT
            echo "INFO: Crontab is updated by uncommenting script $ScriptName in `hostname`"
        fi
    done
else
        echo "INFO: Improper choice provided"
fi
