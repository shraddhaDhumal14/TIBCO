import java.text.*
           
def date = new Date();
def sdf = new SimpleDateFormat("yyyyMMddHHmmss");
def date_time = sdf.format(date)
def Ant_File
def bal
def file
def mailRecipients = "${Email}"
def Status



def Git_Checkout(){

//Checkout Rit Project
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "SOURCECODE"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/RIT_TestAutomation.git']]]
//Checkout Ansible Scripts			
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Script"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
			}
			
			
// Email Body Preparation		
def get_body_build_summary(){
			def date = new Date();
            def sdf = new SimpleDateFormat("dd-MM-yyyy");
            def date_time = sdf.format(date)
          def statusFile = new File("${WORKSPACE}/Status.txt")
           def statusContent = statusFile.readLines() 
		def vesr = readFile "${WORKSPACE}/Status.txt"
				//println vesr
				String[] str;
                    str = vesr.split(']');
                    def lol = str.length
                    lol = lol-1
                    //def loll = lol-3
                     bal = str[lol]
					// print bal
					
                       if(statusContent[-1].contains('failed')){
                           Status = "FAILED"
                          }
					else if(statusContent[-1].contains(' 0 tests exe')){
                           Status = "FAILED"
                          }					  
				   else {
                         Status = "SUCCESS"
                     }
					
				//	 println Status
					
		def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
		.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		</style>
		</style>
		<table class="tg" style="undefined;table-layout: fixed; width: 1000px">
		<colgroup>
		<col style="width: 100px">
		<col style="width: 500px">
		<col style="width: 100px">
		<col style="width: 500px">
		</colgroup>
		  <tr>
			<th class="tg-amwm" colspan="2">TEST_AUTOMATION_SUMMARY</th>
		  </tr>
		  <tr>
			<td class="tg-1wig">Submitted By</td>
			<td class="tg-0lax">${currentBuild.getRawBuild().getCauses()[0].getUserId()}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">Date</td>
			<td class="tg-0lax">${date_time}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">Engine</td>
			<td class="tg-0lax">${Engine_Name}</td>
		  </tr>
		  <tr>
		  <td class="tg-1wig">Operation</td>
			<td class="tg-0lax">${Operation}</td>
		  </tr>
		  <td class="tg-1wig">Type</td>
			<td class="tg-0lax">${Type}</td>
		  </tr>
		  <tr>	
			<td class="tg-1wig">Test_Result</td>
			<td class="tg-0lax">${bal}</td>
		  </tr>	
         <tr>	
		   <td class="tg-1wig">Status</td>
		   <td class="tg-0lax">${Status}</td>
		 </tr>
		</table>
		
		<br><br><br>
	"""
	emailBody = body_build_summary
	return body_build_summary
}

			
pipeline {
	agent any
	
	stages {
		stage('Rit Ant Exexution') {
			steps {
                script {
					
// cleaning workspace in Jenkins box
                     cleanWs()
// calling Git Function		 
              Git_Checkout()
						
		 	sh '''
			cp -r ${WORKSPACE}/SOURCECODE/${Engine_Name}  ${WORKSPACE}/${Engine_Name}
			cp -r ${WORKSPACE}/Script/Test_Automation_Scripts ${WORKSPACE}/Test_Automation_Scripts
	        cd ${WORKSPACE}
            rm -R SOURCECODE*
            rm -R Script*		
            chmod 766 ${WORKSPACE}/${Engine_Name}
			''' 
// Ant File Construction with or without  operation 
		if (Operation == "")
			{
				Ant_File = "${Engine_Name}" + "_" + "${Type}" + "." + "xml"
				
			}
			else {
			    Ant_File = "${Engine_Name}" + "_" + "${Operation}" + "_" + "${Type}" + "." + "xml"
			}
	 file = "${WORKSPACE}" + "/" + "${Engine_Name}" + "/" + "Logical" + "/" + "AntScripts" + "/" + "${Ant_File}" 
			//println file
			
// if Ant file Exists Test Execution will start in Rtcp Box
			
			if (fileExists(file)) {
			sh '''
			file1="${WORKSPACE}/${Engine_Name}/Logical/AntScripts/*.xml"
			
# Replaces the windows parameters Values to RTCP Box Values in Ant Files   
			   
			sed -i 's#name="install.dir" value=.*/>#name="install.dir" value="/opt/SP/tibco/IBM/RationalIntegrationTester"/>#g' ${file1}
 			sed -i 's#environment=.* project#environment="'${Environments}'" project#g' ${file1}
			sed -i 's#basedir=.* default#basedir="./../.." default#g' ${file1}

			cd ${WORKSPACE}
# Coverting the Total Project into tar file
		
			tar -czvf ${Engine_Name}.tar.gz ${Engine_Name}
				
			'''

// Executing Ansible Scripts for RIT Project Deploying in RTCP Box

				ansiColor('xterm') {
				ansiblePlaybook(playbook: "${WORKSPACE}/Test_Automation_Scripts/Test_Automation.yml", colorized: true, extras:'', extraVars: [host: "RIT_TEST", Ant_File: "${Ant_File}", Engine_Name: "${Engine_Name}", date_time: "${date_time}", Workspace: "${WORKSPACE}"])
				}
			       
					 
// Final Result will sent via Email with Test execited Log

				emailBody = "${get_body_build_summary()}"
				emailext  mimeType: 'text/html', attachmentsPattern: 'Test_Exection.log',
				subject: "[Jenkins]:RIT_Testing:Email for Test Automation Report",
				from:"RIT_Automation",
				to: "${mailRecipients}",
				body: 	"${emailBody}" + "<br>" + 
				"<br><br><p><b><font size='2' color='Black'>TEST_AUTOMATION_BUILDURL: <a href='${BUILD_URL}input'>${BUILD_URL}</a></font></b></p>"		
             
               
					def statusFile = new File("${WORKSPACE}/Status.txt")
                     def statusContent = statusFile.readLines()
                       if(statusContent[-1].contains('failed')){
                           Status = "FAILED"
                          }
						if(statusContent[-1].contains(' 0 tests exe')){
                           Status = "FAILED"
                          }
                         						
				   if (Status == "FAILED"){
					error("Test Execution Failed ")
				}
			}
				else {
				   // println Ant_File + ' - not found in the Project'
				error("${Ant_File} - not found in the Project")
				
	
			}
		}	
	}

}
}
}
