#!/bin/bash

deploymentStart=$2
host=`uname -n`
echo $deploymentStart
DEPLOY_LOG_FILE=$1/logs/$1_Deployment.log
DOMAIN_LOG_FILE="$(dirname $4)"/domain/$3/logs/ApplicationManagement.log
echo $DOMAIN_LOG_FILE
echo $host
APP_DEPLOY_LOG=$1/logs/ApplicationManagement.log
ls -lrt $1/*.appconf |awk '{print $9}' >engine.tmp
summary_file=$1/logs/$1_Deployment_summary.txt
summary=""
#echo `grep -n "$deploymentStart" $DOMAIN_LOG_FILE`
#line_number=`grep -n "$deploymentStart" $DOMAIN_LOG_FILE|cut -d: -f1|head -1`
line_number=$2
echo $line_number
max_line=`cat $DOMAIN_LOG_FILE|wc -l`
#echo $max_line,$max_line
#echo $max_line
echo ssh -q $host 'sed -n '$line_number','$max_line'p '$DOMAIN_LOG_FILE
#`sed -n 4316,6960p $DOMAIN_LOG_FILE > $APP_DEPLOY_LOG`
#sed -n $line_number','$max_line'p '$DOMAIN_LOG_FILE > $APP_DEPLOY_LOG
echo 'tail -n +'$line_number $DOMAIN_LOG_FILE
tail -n +$line_number $DOMAIN_LOG_FILE > $APP_DEPLOY_LOG

cat engine.tmp| while read eg1
do
        summary=""
        engine=`echo $eg1|cut -d'.' -f 1`
        engine=${engine##*/}
        summary=$engine
#echo EngineName:$engine        
#echo `grep $engine" ]: Failed. Please check log file" $APP_DEPLOY_LOG|grep -v grep|wc -l`
        #echo `grep failed $APP_DEPLOY_LOG|grep $engine|grep -v grep|wc -l`
        if [ `grep $engine" ]: Finished successfully" $APP_DEPLOY_LOG|grep -v grep|wc -l` -ge 1 ]
        then
                time=`grep $engine" ]: Finished successfully" $APP_DEPLOY_LOG|grep -v grep|tail -1|cut -f-4 -d' '|awk '{print $3"-"$2"-"$1" "$4}'`
                summary=$summary"|"$time"|Success"
        elif [ `grep $engine" ]: Failed. Please check log file" $APP_DEPLOY_LOG|grep -v grep|wc -l` -ge 1 ]
        then
                 time=`grep $engine" ]: Failed. Please check log file" $APP_DEPLOY_LOG|grep -v grep|tail -1|cut -d' ' -f-4|awk '{print $3"-"$2"-"$1" "$4}'`
                summary=$summary"|"$time"|Failed"
        elif [ `grep failed $APP_DEPLOY_LOG|grep $engine|grep -v grep|wc -l` -ge 1 ]
        then
                time=`grep failed $APP_DEPLOY_LOG|grep $engine|grep -v grep|tail -1|cut -d' ' -f-4|awk '{print $3"-"$2"-"$1" "$4}'`
                 summary=$summary"|"$time"|Failed"
		elif [ `grep "$engine\" has been undeployed" $APP_DEPLOY_LOG|grep -v grep|wc -l` -ge 1 ]
        then
                time=`grep "$engine\" has been undeployed" $APP_DEPLOY_LOG|grep -v grep|tail -1|cut -d' ' -f-4|awk '{print $3"-"$2"-"$1" "$4}'`
                 summary=$summary"|"$time"|Success"	 
        fi
        echo $summary >> $summary_file
done
