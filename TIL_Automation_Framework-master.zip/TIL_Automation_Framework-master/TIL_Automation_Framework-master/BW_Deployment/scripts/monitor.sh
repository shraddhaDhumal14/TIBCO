#!/bin/bash
### Execute with CRQ# as input. example: ./restart.sh CRQ1234 ###########################################
#########################################################################################################
#   Function to capture logs
#######################################################################################################
captureLogs()
{
dt=$2
loglocation=$3
logfile=$4
server=$5
#echo "Inside the function:::"$dt
`ssh -q $server 'grep  "'$dt'" '$loglocation/$logfile >> $1/temp/$logfile`
}
###########################################################################################################

##############################################################################################################
#     Main Script
############################################################################################################
IFS="|"
MONITOR_LOG_FILE=$1/logs/$1_Monitor.log
MONITOR_SUMMARY=$1/logs/$1_monitoring_summary.txt
`>${MONITOR_LOG_FILE}`
declare -i line=1
loglocation="$(dirname $2)"/domain/$3/application/logs
declare -i hours=0
declare -i mduration=$4
#echo "Monitor Interval:::"$mduration
rm $1/temp/*.log
cat $1/Instance_Details.txt | while read f1 f2 f3 f4 f5
do
  #      echo "Application::::"$f1
  #      echo $f2
 #       echo $f3
        ex_count=`grep "<$f1>" $1/restart_exceptions.txt|wc -l`
#echo ${f1:0:1}
        if [[ ! ${f1:0:1} == "#" ]]
        then
#       echo $line":::ex_count::"$ex_count
        if [ "$ex_count" == "       0" ] || [ "$ex_count" == "0" ] && [ $line -gt 2 ]
        then
#       echo Inside excount IF
                 IFS=", "
       #if [[ `grep "<$f1>" $1/restart_exceptions.txt|wc -l` ]]
       #then
#       echo Inside Exception IF
       read -r -a instances <<< $f3
        hours=0
#echo "Log file Name::::::"${instances[@]}
       for i in ${instances[@]}
       do
                echo $i

                server=${i##*@}
                instanceName=${i%%@*}
                appName=${f1##*/}
                summary=$f1"|"$i
                start_time=""
                end_time=""
                #echo "Instace Name::::" $instanceName"          Server Name:::"$server
                hours=0
                if [[ ! ${instanceName:0:1} == "#" ]]
                then
                while [ $hours -lt $mduration ]
                do
                        dt=`date --date="$hours"' hour ago' "+%Y %b %d %H:"`
                        logfile=$f4-$instanceName.log
                        if [[ $hours -eq 0 ]]
                        then
                         end_time=`date "+%Y %b %d %H:%M"`
                        else
                         start_time=$dt"00:00"
                        fi
#echo $dt
#pid=`ssh -q tibco@$server 'grep  "'$dt'" '$loglocation/$logfile >> $1/temp/$logfile`
                pid=`./captureLogs.sh $1 "$dt" $loglocation $logfile $server >> ${MONITOR_LOG_FILE} &`
#pid=$!
echo $pid
                        #sleep 10s
#echo `ssh -q $server 'grep  "'$dt'" '$loglocation/$logfile >> $1/temp/$logfile`
                ((hours+=1))
                done
                summary=$summary"|"$start_time" to "$end_time
                keyword="F"
                excl_string=""
excl_flag="F"
#echo $1/temp/$logfile
while read log_line
do
#echo "Insde Main Loop:::" $log_file
     while read error_line
        do
    #         echo "Inside Error Line Loop"
                   if [[ $log_line == *$error_line* ]]

                then
                        excl_flag="F"
#                       echo ":::::"$log_line"::::"$error_line
                        while read excl_line
                        do
 #                               echo "Inside ExclLine Loop"
                                if [[ $log_line == *$excl_line* ]]
                                then
#                               echo "#############################"$log_line"#################"$excl_line
                                excl_flag="T"

                                fi
                        done < MasterConfiguration/Known_Errors_exclusion.txt
                  if [[ $excl_flag == "F" ]]
                  then
                        echo "Below are the errors in the log file:::"$1/temp/$logfile  >> $1/logs/$1_Errors_List.txt
                        echo $log_line >> $1/logs/$1_Errors_List.txt
                        keyword="T"
                  fi
                        #       echo $log_line >> $1/logs/$1_Errors_List.txt
                        #       keyword="T"

                fi
        done < MasterConfiguration/Known_Errors.txt
done < $1/temp/$logfile
#echo  $1/temp/$logfile
if [[ $keyword == "T" ]]
then
echo "====================================================================================================================================================================" >> $1/logs/$1_Errors_List.txt
fi

                summary=$summary"|"$keyword
                operations_summary=""
                read -r -a operations <<< $f5
                for i in ${operations[@]}
                do
                        total_req_count=`grep $i $1/temp/$logfile|grep "TIL Audit started successfully"|wc -l`
                        exception_count=`grep $i $1/temp/$logfile|grep "TIL Service Exception Handler started successfully"|wc -l`
                        if [[ "$operations_summary" = "" ]]
                        then
                                operations_summary=$i"*"$total_req_count"*"$exception_count
                        else
                                operations_summary=$operations_summary","$i"*"$total_req_count"*"$exception_count
                        fi
                done
                summary=$summary"|"$operations_summary
                echo $summary >> ${MONITOR_SUMMARY}
        fi
       done
        else
        if [ $line -ge 2 ]
        then
            echo "The Application "$f1 " is not being restarted as it is present in the Exception List"
        fi
fi
        IFS="|"
((line += 1))
fi
IFS="|"
done
#done < $1/Instance_Details.txt
