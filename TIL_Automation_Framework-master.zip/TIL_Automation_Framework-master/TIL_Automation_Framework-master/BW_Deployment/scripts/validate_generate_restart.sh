#!/bin/bash
# Thsi script try to validate generate option as part of BW deployment.
# Input1: engine names with ; sepaarted. Also when giving the parameter for engine names we need toenclose in ""
# input2: CRQ Number
# input3: Deployment type . NEW | EXISTING

# engine names with validation failure will be written to "generate_failed" file
# engine names with validation success will be written to "generate_success" file

ENGINE=$1
CRQ=$2
DEPLOY_TYPE=$3
WORK_DIR=`pwd`


# If deployment typeis ESISTING, validate backup.
>${WORK_DIR}/generate_success
>${WORK_DIR}/generate_failed



while read -r eng; do
        echo "engine name is: ${eng}"
        if [[ "${DEPLOY_TYPE}" == "EXISTING" ]]; then
				flag="fail"
                # Check for EAR file in backup folder.
                if [[ -f ${WORK_DIR}/${CRQ}/backup/${eng}.ear ]] && [[ -f ${WORK_DIR}/${CRQ}/backup/${eng}.xml ]]; then
                        echo "BACKUP is successfully completed for ${eng}"
                        echo "${eng}" >> ${WORK_DIR}/generate_success
					   flag="pass"
                        
				fi
				
				if [[ "${flag}" == "fail" ]]; then 
					echo "${eng}" >> ${WORK_DIR}/generate_failed
				fi

        else
                echo "ERROR: Please provide valid option for DEPLOY_TYPE."
        fi
done <<< "$(echo "$ENGINE" | tr ';' '\n')"


