#!/bin/bash
UTIL_HOME=`pwd`
IFS="="
while read f1 f2
do
if [ "$f1" = "Domain" ]
then
dName="$f2"
elif [ "$f1" = "Environment" ]
then
env="$f2"
elif [ "$f1" = "Site" ]
then
site="$f2"
fi
done < $UTIL_HOME/Deployment.properties
echo $env
echo $site
echo $dName
REPORT_NAME=$1/logs/$1_report.html
#echo "Inside Report script..............."
echo "To:"$2 > ${REPORT_NAME}
reportTime=`date "+%d-%b-%Y %H:%M"`
echo "Subject:$env-$site-$dName| Deployment Summary Report for "$1" @"$reportTime >>${REPORT_NAME}
echo "Content-Type: text/html" >>${REPORT_NAME}
#if [[ ! -f $1/logs/$1_restart_summary.txt ]]
#then
#       "">>$1/logs/$1_restart_summary.txt
#fi
echo '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">' >>${REPORT_NAME}
echo '<html>' >>${REPORT_NAME}
echo '<head><title>'$env'-'$site'-'$dName'|Deployment Report for '$1'</title>' >>${REPORT_NAME}
echo '<style> table, th, td{ border: 1px solid black; } th, td{ padding: 5px; text-align: left; } </style>' >>${REPORT_NAME}
echo '</head>' >>${REPORT_NAME}
echo '<body style="font-family:calibri;font-size:16px">' >>${REPORT_NAME}
echo '<p>Hi All,</p> '>>${REPORT_NAME}
echo '<p>Please find the below update for application Deployment.</p>' >>${REPORT_NAME}
echo '<p>CRQ Number:'$1'</p>' >>${REPORT_NAME}
release=`grep "Release Nam" $1/Instance_Details.txt`
echo '<p>'$release'</p>' >>${REPORT_NAME}
echo '<p><strong>Note: The Operations Stats format is <Operation NAme>*<Total request count>*<exceptions count> within the monitoring interval</strong></p>' >>${REPORT_NAME}
echo '<table style="height: 157px; width: 655px;border=1">' >>${REPORT_NAME}
echo '<tbody style="font-family:Calibri ;font-size:16px">' >>${REPORT_NAME}
echo '<tr style="background-color: blue;">' >>${REPORT_NAME}
echo '<td><strong>Application Name</strong></td>' >>${REPORT_NAME}
echo '<td><strong>Binding (Instance Name@server)</strong></td>' >>${REPORT_NAME}
echo '<td><strong>Deployment Status</strong></td>' >>${REPORT_NAME}
echo '<td><strong>Log Verification Status</strong></td>' >>${REPORT_NAME}
echo '<td><strong>Live Traffic Verification status</strong></td>' >>${REPORT_NAME}
echo '<td><strong>Live Verification Interval</strong></td>' >>${REPORT_NAME}
echo '<td><strong>Operation Stats while Monitoring</strong></td>' >>${REPORT_NAME}
echo '<td><strong>Deployment Completion Time</strong></td>' >>${REPORT_NAME}
#echo '<td><strong>Binding (Instance Name@server)</strong></td>' >>${REPORT_NAME}
echo '<td><strong>Instance shutdown Complete time</strong></td>' >>${REPORT_NAME}
echo '<td><strong>Restart Completed Time</strong></td>' >>${REPORT_NAME}
#echo '<td><strong>Log Verification Status</strong></td>' >>${REPORT_NAME}
echo '<td><strong>Log Verification Time</strong></td>' >>${REPORT_NAME}
echo '<td><strong>Instance shutdown start time</strong></td>' >>${REPORT_NAME}
#echo '<td><strong>Restart initiate time</strong></td>' >>${REPORT_NAME}
echo '<td><strong>Old unix Process ID</strong></td>' >>${REPORT_NAME}
echo '<td><strong>New unix Process ID</strong></td>' >>${REPORT_NAME}
echo '</tr>' >>${REPORT_NAME}
#echo '<tr>' >>${REPORT_NAME}

#############################################################################################
#       The Body of the Table Geos Here
#############################################################################################
IFS="|"
if [[ ! -f $1/logs/$1_restart_summary.txt ]]
then
`sort $1/logs/$1_Deployment_summary.txt > $1/logs/$1_Deployment_summary_sort.txt`
files=$1/*.appconf
for file in $files
do
engine=`echo $file|cut -d'.' -f 1`
engine=${engine##*/}
echo $engine
dtime=`grep "$engine" $1/logs/$1_Deployment_summary_sort.txt|cut -f2 -d'|'|tail -1`
dstatus=`grep "$engine" $1/logs/$1_Deployment_summary_sort.txt|cut -f3 -d'|'|tail -1`
if [ "$dstatus" = "Success" ]
then
dcolor=lightgreen
elif [ "$dstatus" = "Failed" ]
then
dcolor=red
else
dstatus="No Deployment"
dcolor=white
fi
#echo '<td style="background-color: '$log_status_color';">'$f9'</td>'
echo '<tr>' >>${REPORT_NAME}
echo '<td>'$engine'</td>' >>${REPORT_NAME}
echo '<td></td>' >>${REPORT_NAME}

echo '<td style="background-color: '$dcolor';">'$dstatus'</td>' >>${REPORT_NAME}

echo '<td></td>' >>${REPORT_NAME}
#echo grep "$f1|$f2" $1/logs/$1_monitoring_summary_sort.txt
#echo $f1":::::"$1"::::"$ltperiod
echo '<td></td>' >>${REPORT_NAME}
echo '<td></td>' >>${REPORT_NAME}

echo '<td></td>' >>${REPORT_NAME}
#echo '<td>'$ltperiod'</td>' >>${REPORT_NAME}
#echo

echo '<td>'$dtime'</td>' >>${REPORT_NAME}

#echo '<td></td>' >>${REPORT_NAME}
echo '<td></td>' >>${REPORT_NAME}
echo '<td></td>' >>${REPORT_NAME}
#echo '<td style="background-color: orange;"></td>' >>${REPORT_NAME}
echo '<td></td>' >>${REPORT_NAME}
echo '<td></td>' >>${REPORT_NAME}
#echo '<td>'$f6'</td>' >>${REPORT_NAME}
echo '<td></td>' >>${REPORT_NAME}
echo '<td></td>' >>${REPORT_NAME}
echo '</tr>' >>${REPORT_NAME}
done
else
`sort $1/logs/$1_restart_summary.txt > $1/logs/$1_restart_summary_sort.txt`
if [[  -f $1/logs/$1_monitoring_summary.txt ]]
then
`sort $1/logs/$1_monitoring_summary.txt > $1/logs/$1_monitoring_summary_sort.txt`
fi
if [[  -f $1/logs/$1_Deployment_summary.txt ]]
then
`sort $1/logs/$1_Deployment_summary.txt > $1/logs/$1_Deployment_summary_sort.txt`
fi
declare -i line=1
declare -i count=0
previousApp=""
while read f1 f2 f3 f4 f5 f6 f7 f8 f9
do
count=`grep -n "$f1|$f2" $1/logs/$1_restart_summary_sort.txt|cut -f1 -d:|tail -1`
#echo grep -n "$f1|$f2" CRQ9999/logs/CRQ9999_restart_summary_sort.txt|cut -f1 -d:|tail -1

#count=`grep -n "$f1|$f2" CRQ9999/logs/CRQ9999_restart_summary_sort.txt|cut -f1 -d:|tail -1`
instancecount=`grep "$f1" $1/logs/$1_restart_summary_sort.txt|cut -f2 -d'|'|sort|uniq|wc -l`
#echo $line"::::::"$count"::::::::"$instanceCount
if [ $line -eq $count ]
then
if [ "$f8" = "Started with No Errors" ]
then
log_status_color=lightgreen
else
log_status_color=red
fi
#engine=`echo $f1|cut -d'.' -f 1`
engine=${f1##*/}
echo $engine
if [[  -f $1/logs/$1_Deployment_summary_sort.txt ]]
then
dtime=`grep "$engine" $1/logs/$1_Deployment_summary_sort.txt|cut -f2 -d'|'|tail -1`
dstatus=`grep "$engine" $1/logs/$1_Deployment_summary_sort.txt|cut -f3 -d'|'|tail -1`
fi
if [ "$dstatus" = "Success" ]
then
dcolor=lightgreen
elif [ "$dstatus" = "Failed" ]
then
dcolor=red
else
dstatus="No Deployment"
dcolor=white
fi
#echo '<td style="background-color: '$log_status_color';">'$f9'</td>'
echo '<tr>' >>${REPORT_NAME}
if [ "$previousApp" = "$f1" ]
then
echo""
else
echo '<td rowspan="'$instancecount'">'$f1'</td>' >>${REPORT_NAME}
fi
echo '<td>'$f2'</td>' >>${REPORT_NAME}
if [ "$previousApp" = "$f1" ]
then
echo ""
else
echo '<td rowspan="'$instancecount'" style="background-color: '$dcolor';">'$dstatus'</td>' >>${REPORT_NAME}
fi
echo '<td style="background-color: '$log_status_color';">'$f8'</td>' >>${REPORT_NAME}
if [[  -f $1/logs/$1_monitoring_summary_sort.txt ]]
then

ltstatus=`grep "$f1|$f2" $1/logs/$1_monitoring_summary_sort.txt|cut -f4 -d'|'|tail -1`
#echo $ltstatus ::: $f1 ::: $f2
if [[ $ltstatus = "T" ]]
then
ltcolor=red
ltmessage="Errors found in the log file"
elif [[ $ltstatus = "F" ]]
then
ltcolor=lightgreen
ltmessage="No Errors Found in the log file"
else
ltcolor=white
ltmessage=""
fi
#echo grep "$f1|$f2" $1/logs/$1_monitoring_summary_sort.txt
ltperiod=`grep "$f1|$f2" $1/logs/$1_monitoring_summary_sort.txt|cut -f3 -d'|'|tail -1`
ltopstats=`grep "$f1|$f2" $1/logs/$1_monitoring_summary_sort.txt|cut -f5 -d'|'|tail -1`
#echo $f1":::::"$1"::::"$ltperiod
fi
echo '<td style="background-color: '$ltcolor';">'$ltmessage'</td>' >>${REPORT_NAME}
echo '<td>'$ltperiod'</td>' >>${REPORT_NAME}
IFS=" ,"
echo '<td> <p>' >>${REPORT_NAME}
read -r -a opstats <<< $ltopstats
for i in ${opstats[@]}
do
echo $i >>${REPORT_NAME}
done
echo '</p></td>' >>${REPORT_NAME}
#echo '<td>'$ltperiod'</td>' >>${REPORT_NAME}
#echo
if [ "$previousApp" = "$f1" ]
then
echo ""
else
echo '<td rowspan="'$instancecount'">'$dtime'</td>' >>${REPORT_NAME}
fi
#echo '<td>'$f2'</td>' >>${REPORT_NAME}
echo '<td>'$f5'</td>' >>${REPORT_NAME}
echo '<td>'$f7'</td>' >>${REPORT_NAME}
#echo '<td style="background-color: orange;">'$f9'</td>' >>${REPORT_NAME}
echo '<td>'$f9'</td>' >>${REPORT_NAME}
echo '<td>'$f3'</td>' >>${REPORT_NAME}
#echo '<td>'$f6'</td>' >>${REPORT_NAME}
echo '<td>'$f4'</td>' >>${REPORT_NAME}
echo '<td>'$f6'</td>' >>${REPORT_NAME}
echo '</tr>' >>${REPORT_NAME}
previousApp="$f1"

fi
((line += 1))
IFS="|"
done < $1/logs/$1_restart_summary_sort.txt

fi

#############################################################################################
#   End of the Body
#############################################################################################
echo '</tr>' >>${REPORT_NAME}
echo '</tbody>' >>${REPORT_NAME}
echo '</table>' >>${REPORT_NAME}
if [[  -f $1/logs/$1_Errors_List.txt ]]
then
echo '<p>'`cat $1/logs/$1_Errors_List.txt`'</p>' >>${REPORT_NAME}
fi
echo '</body>' >>${REPORT_NAME}
echo '</html>' >>${REPORT_NAME}

#echo 'EOL' >>${REPORT_NAME}






#/usr/sbin/sendmail -t < "${REPORT_NAME}"
