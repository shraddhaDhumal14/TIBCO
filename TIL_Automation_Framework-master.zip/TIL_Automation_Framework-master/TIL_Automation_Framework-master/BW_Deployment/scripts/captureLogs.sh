dt=$2
loglocation=$3
logfile=$4
server=$5
`ssh -q $server 'grep  "'$dt'" '$loglocation/$logfile >> $1/temp/$logfile`
