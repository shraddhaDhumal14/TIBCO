#!/bin/bash
#
# Copyright (c) Hewlett Packard Ltd 2015.
#
# This software is copyrighted.  Under the copyright laws, this software
# may not be copied, in whole or in part, without prior written consent
# of Hewlett Packard Ltd. This software is provided under the terms of a
# license between Hewlett Packard and the recipient, and its use is subject
# to the terms of that license.
#
# Placing Script to update manual properties automatically for ISTIL engines after deployment.
#
#
# Source the profile - this script doesn't require to call from CRON
# 2017Aug08 V 1.0-Bhargav Sutapalli
# 2021Jan26 V 1.1 - Updated the logic to support the multiple engines which has same naming extension
###################################################################################################################################################

#!/bin/bash
dt=`date +"%b %d %H:%M"`

## Change the below varialbles as per environment(Staging/Production)
######################################################################
##Staging

#AUTO_CONFIG=/opt/tibco/tools/DeploymentAutomation_IRSTG05
#TRA_PATH=/opt/tibco/tra/domain/IRSTG05/application
#GC_PATH=/opt/tibco/tra/domain/IRSTG05/application/logs/GCLogs
#POST_PATH=/opt/tibco/tools/DeploymentAutomation_IRSTG05/PostDeploymentChanges
#host="auktltnr"
#host_appdy="auktltnr,auktltpr"
#CONF_FILE=ManualChangesConfiguration.conf
## Proudction

AUTO_CONFIG=$2
TRA_PATH="$(dirname $3)"/domain/$4/application
GC_PATH="$(dirname $3)"/domain/$4/application/logs/GCLogs
POST_PATH=$2/PostDeploymentChanges
host="uk2752yr uk2753yr uk2754yr uk2755yr"
CONF_FILE=$POST_PATH/ManualChangesConfiguration.conf
host_appdy="uk2752yr,uk2753yr,uk2754yr,uk2755yr"
######################################################################

CRQ_CONFIG=$AUTO_CONFIG/$1
BKP_CONFIG=$CRQ_CONFIG/backup
CRQ_NME=$1
usr=tibco
cr_c=`grep "$CRQ_CONFIG" $POST_PATH/AutomationCRQNumbers_Repository.txt |wc -l`
crq_chk=`ls -lrt $AUTO_CONFIG/$1/*.appconf|wc -l`
if [ $crq_chk -gt 0 ]
   then
       echo "Verifying $1 in Deployment Automation Folder..."
#            if [ $cr_c -eq 0 ]
#                then
#                    echo "$dt-$CRQ_CONFIG" >>$POST_PATH/AutomationCRQNumbers_Repository.txt
                    ls -lrt ${CRQ_CONFIG}/*.appconf |awk '{print $9}' >engine.tmp
                      cat engine.tmp| while read eg1
                          do
                             engine=`echo $eg1|cut -d'.' -f 1`
                             engine=${engine##*/}

##########################
### Backup of TRA Files Logic starts from here ##
##########################
                             #engine1=`grep -w $engine $CONF_FILE| head -1 |awk -F'|' '{print $1}'`
                             echo "${host_appdy//,/$'\n'}" > usr1.tmp
                             e1=`echo $engine|grep -v '^$'|wc -l`
                             #echo "engine::$engine engine1::$engine1 e1::$e1"
                             if [ $e1 -eq 1 ] ; then cat usr1.tmp| while read ur1; do ssh -q $usr@$ur1 "ls -lrt $TRA_PATH" | awk '{print $9}' > engineapp_$ur1.tmp; done; engine1=`grep -w $engine engineapp_*.tmp| head -1`; fi
                                         eng_val=`grep $engine $CRQ_CONFIG/bw/AppManage.batch |grep -v '^$' |wc -l`
                                       if [ $eng_val -ne 0 ]
                                                 then
                                                   echo "Checking $engine in AppManage.batch file"
                                    for ht in $host
                                      do
                                                         echo "$engine tra backup started for $ht"
                                         #if [ `ls -lrt $BKP_CONFIG/*$ht*$engine*|grep tra|wc -l` -gt 0 ]
                                          #  then
                                          #        echo "Backup is not required as already been taken"
                                         #  else
                                                  scp -q tibco@$ht:$TRA_PATH/$engine1/$engine1*.tra $BKP_CONFIG
                                                  ls -lrt $BKP_CONFIG/$engine1*.tra |awk '{print $9}'|awk -F'/' '{print $NF}' > move.tmp
                                                  cat move.tmp | while read line; do mv $BKP_CONFIG/$line $BKP_CONFIG/"$ht"_$line;done
                                                  echo "$engine tra files backup successfully completed under $BKP_CONFIG for $ht"
                                        # fi
                                      done
### BackUp Logic END ###


                              ############### PLEASE DO NOT UPDATE BELOW UNTIL THERE IS A REQUIREMENT #####################################


              cat $CONF_FILE | grep "$engine|"|while read line
               do
                 echo "$line" > post.tmp
                 appName=''
                 command=''
                 property=''
                 source=''
                 destination=''
                 sourcePath=''
                 destinationPath=''
                         appName_admin=''
                     destination_folder=''
                 user=''
                 cmd=''
                 IFS="|"
                 while read f1 f2 f3 f4 f5 f6 f7 f8 f9 f10
                   do
                    echo $f1
                    appName=$f1
                    command=$f2
                    property=$f3
                    sourcePath=$f4
                    destinationPath=$f5
                    source=$f6
                    destination=$f7
                    user=$f8
                        appName_admin=$f9
                            destination_folder=$f10
                    echo $1"::::"$appName
                    echo $command
                    echo "doing for $line"
                          if [[ $1 = $CRQ_NME ]]
                                then
                                  if [[ $command == "update" ]]
                                        then
                                           IFS=", "
                                        echo "appName=$appName"
                                        echo "command=$command"
                                        echo "property=$property"
                                        echo "destinationPath=$destinationPath"
                                        echo "destination=$destination"
                                        echo "user=$user"
                                        echo "destination_folder=$destination_folder"
                                        echo "${destination//,/$'\n'}" > usr.tmp
                                               cat usr.tmp |while read i
                                               do
                                                {
                                                 cmd=`ssh -q $usr@$i "echo $property |/usr/bin/tee -a $destinationPath"`
                                                  echo "$property property successfully updated. Please check the $destinationPath on $i to validate the changes."
                                                        ls -lrt $BKP_CONFIG/*.tra| awk '{print $9}'|grep $i|grep $appName| awk -F'/' '{print $NF}'|cut -d"_" -f2- > ta.tmp
                                                        scp -q $usr@$i:$TRA_PATH/$engine1/$engine1*.tra $POST_PATH
                                                         cat ta.tmp|while read ta
                                                          do
                                                          chk=`grep -w $property $POST_PATH/$ta| grep -v '^#'|wc -l`
                                                           if [ $chk -ne 0 ]
                                                                                       then
                                                                echo "$CRQ_NME|$dt|$property Property successfully updated in $ta file in $i" >> $CRQ_CONFIG/PostDeployment_Manualchanges.log
                                                                else
                                                                                            echo "$CRQ_NME|$dt|$property Property successfully NOT updated in $ta file in $i" >> $CRQ_CONFIG/PostDeployment_Manualchanges.log
                                                                                        fi
                                                                                  done
                                                                                 } < /dev/null
                                              done
                                          IFS="|"
                                elif [[ $command == "remotecopy" ]]
                                        then
                                        echo " Inside Remote Copy"
                                        echo "command=$command"
                                        echo "sourcePath=$sourcePath"
                                        echo "destinationPath=$destinationPath"
                                        echo "source=$source"
                                        echo "destination=$destination"
                                        echo "user=$user"
                                        echo "destination_folder=$destination_folder"
                                        IFS=", "
                                        echo "${destination//,/$'\n'}" > usr.tmp
                                        cat usr.tmp |while read i
                                            do
                                            {
                                            cmd=`scp -q $usr@$source:$sourcePath $usr@$i:$destinationPath`
                                             echo "$destinationPath successfully updated. Please check the $destinationPath on $i to validate the changes."
                                             if ssh -q $i  "test -e $destinationPath"; then echo "$CRQ_NME|$dt|$destinationPath successfully updated in $i"; else echo "$CRQ_NME|$dt|$destinationPath not successfully updated in $i"; fi >> $CRQ_CONFIG/PostDeployment_Manualchanges.log
                                           } < /dev/null
                                           done
                                         IFS="|"

                               elif [[ $command == "remove" ]]
                                        then
                                        echo "Inside Remove"
                                        echo "appName=$appName"
                                        echo "command=$command"
                                        echo "destinationPath=$destinationPath"
                                        echo "destination=$destination"
                                        echo "destination_folder=$destination_folder"
                                        echo "user=$user"
                                          IFS=", "
                                          echo "${destination//,/$'\n'}" > usr.tmp
                                          cat usr.tmp |while read i
                                          do
                                          {
                                          cmd=`ssh -q $usr@$i rm $destinationPath`
                                          echo "$destinationPath successfully removed. Please check the $destinationPath on $i to validate the changes."
                                          if ssh -q $i  "test -e $destinationPath"; then echo "$CRQ_NME|$dt|$destinationPath not successfully removed in $i"; else echo "$CRQ_NME|$dt|$destinationPath successfully removed in $i"; fi >> $CRQ_CONFIG/PostDeployment_Manualchanges.log
                                        } < /dev/null
                                         done
                                        IFS="|"

                                        elif [[ $command == "comment" ]]
                                        then
                                        echo "Comment Property"
                                        echo "appName=$appName"
                                        echo "command=$command"
                                        echo "Property=$property"
                                        echo "destinationPath=$destinationPath"
                                        echo "destination=$destination"
                                        echo "destination_folder=$destination_folder"
                                        echo "user=$user"
                                        IFS=", "
                                        echo "${destination//,/$'\n'}" > usr.tmp
                                        cat usr.tmp |while read i
                                            do
                                            {
                                              cmd=`ssh -q $usr@$i "sed 's/$property/#$property/g' $destinationPath > test.tmp && mv test.tmp $destinationPath"`
                                                 echo "$property property successfully commented in $appName. Please check the $destinationPath on $i to validate the changes."
                                             echo "$CRQ_NME|$dt|$property Property successfully updated in $destinationPath files in $i" >> $CRQ_CONFIG/PostDeployment_Manualchanges.log
                                           } < /dev/null
                                           done
                                         IFS="|"
                        fi
                  fi

                done < post.tmp
            done

######################################################
                                                     #
### Applying AppDynamics Property#################   #
                                                     #
######################################################

                                chkcount=`grep $engine1 /opt/SP/tibco/AppDExclusion/ExclusionList_AppD.txt | wc -l`
                                chkcount1=0
                                if [ $chkcount -eq $chkcount1 ]
                                then
                                        for ht1 in $host
                                                do
                                                        #eng1=`echo $engine1|awk -F'-' '{print $(NF-1)}'`
                                                        ls -lrt $BKP_CONFIG/*.tra|grep "_$engine1-$engine1" |awk '{print $9}'|awk -F'/' '{print $NF}'|awk -F'.' '{print $1}' > appd.tmp
                                                        cat appd.tmp|while read appd
                                                                do
                                                                        echo "$appd" |grep "$ht1"| cut -d"_" -f2- > serv.tmp
                                                                        cat serv.tmp |while read line1
                                                                                do
                                                                                        appdy=appdynamics.agent
                                                                                        #tier=`echo $engine|awk -F'-' '{print $NF}'`
                                                                                        tier=`echo $engine`
                                                                                        prop="java.extended.properties=-Xincgc -XX:NewSize=192M -XX:MaxNewSize=192M -XX:PermSize=27m -XX:MaxPermSize=512m -XX:+UseParNewGC -XX:+UseConcMarkSweepGC -XX:MaxGCPauseMillis=150 -XX:+CMSIncrementalMode -XX:+CMSIncrementalPacing -XX:+UseCMSCompactAtFullCollection -XX:CMSFullGCsBeforeCompaction=2 -XX:+DisableExplicitGC -XX:+UseTLAB -XX:+UseSpinning -XX:+UseFastAccessorMethods-XX\:+PrintGCDetails -XX:+PrintGCTimeStamps -XX:+PrintGCDateStamps -Xloggc:$GC_PATH/$line1.log -javaagent:/opt/SP/tibco/tools/AppDynamics/AppDynamicsServerAgent/javaagent.jar -Dappdynamics.agent.uniqueHostId=$ht1 -Dappdynamics.agent.tierName=$tier -Dappdynamics.agent.nodeName=$ht1-$line1"
                                                                                        cmd2=`ssh -q tibco@$ht1 "echo $prop |/usr/bin/tee -a $TRA_PATH/$engine1/$line1.tra"`
                                                                                        echo $cmd2" property successfully updated. Please check the $TRA_PATH/$engine1/$line1.tra on $ht1 to validate the changes."
                                                                                        ssh -q tibco@$ht1 "grep -F '$appdy' $TRA_PATH/$engine1/$line1.tra" > cmd.tmp
                                                                                        echo "$CRQ_NME|$dt|$host|AppDynamic Property successfully updated to $line1.tra file in $ht1" >> $CRQ_CONFIG/PostDeployment_Manualchanges.log
                                                                                done
                                                                done
                                                done
                                fi
### AppDynamics Property logic ends here###

else
echo "$engine is not available in AppManage.batch file. Hence NOT applying Post Manual Changes." >> $CRQ_CONFIG/PostDeployment_Manualchanges.log
fi
done
else
     echo "PostManual Changes are already applied for $CRQ_CONFIG. If you still want to do the changes again ,remove $1 entry from AutomationCRQNumbers_Repository.txt"
fi
cat $CRQ_CONFIG/PostDeployment_Manualchanges.log >> PostDeployment_Manualchanges_History.log

ct=`ls -lrt *tmp | wc -l`
if [ $ct -gt 0 ]
then
rm *.tmp
rm *.tra
echo "                                          ***** END OF SCRIPT EXECUTION ****"
else
echo " Please Enter the valid CRQ Number!! . Make sure you are entering the CRQ Number available under $AUTO_CONFIG "
fi
