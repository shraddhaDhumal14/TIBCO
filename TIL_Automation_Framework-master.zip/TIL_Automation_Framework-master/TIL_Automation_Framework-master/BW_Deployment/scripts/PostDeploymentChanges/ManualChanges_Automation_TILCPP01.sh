#!/bin/bash
#
# Copyright (c) Hewlett Packard Ltd 2015.
#
# This software is copyrighted.  Under the copyright laws, this software
# may not be copied, in whole or in part, without prior written consent
# of Hewlett Packard Ltd. This software is provided under the terms of a
# license between Hewlett Packard and the recipient, and its use is subject
# to the terms of that license.
#
# Placing Script to update manual properties automatically for ISTIL engines after deployment.
#
#
# Source the profile - this script doesn't require to call from CRON
# 2017Aug08 V 1.0-Bhargav Sutapalli 
###################################################################################################################################################

#!/bin/bash
dt=`date +"%b %d %H:%M"`
host_name=`hostname`
echo $host_name
if [ `uname -a | grep Linux|grep "$host_name"|grep -v "vodafone"|wc -l` -eq 1 ]
then
## Change the below varialbles as per environment(Staging/Production)
######################################################################
##Staging

AUTO_CONFIG=$2
TRA_PATH="$(dirname $3)"/domain/$4/application
GC_PATH="$(dirname $3)"/domain/$4/application/logs/GCLogs
POST_PATH=$2/PostDeploymentChanges
host="til-bw01-cpp1 til-bw02-cpp1"
host_appdy="til-bw01-cpp1,til-bw02-cpp1"
CONF_FILE=$POST_PATH/ManualChangesConfiguration.conf
## Proudction

#AUTO_CONFIG=/opt/tibco/tools/DeploymentAutomation_IRPR05
#TRA_PATH=/opt/tibco/tra/domain/IRPR05/application
#GC_PATH=/opt/tibco/tra/domain/IRPR05/application/logs/GCLogs/
#POST_PATH=/opt/tibco/tools/DeploymentAutomation_IRPR05/PostDeploymentChanges
#host="auktlpqr auktlprr auktlpsr auktlptr"
#CONF_FILE=ManualChangesConfiguration_IS.conf
#host_appdy="auktlpqr,auktlpsr"
######################################################################
CRQ_CONFIG=$AUTO_CONFIG/$1
BKP_CONFIG=$CRQ_CONFIG/backup
CRQ_NME=$1
usr=tibco
echo "$CRQ_CONFIG"
cr_c=`grep "$CRQ_CONFIG" $POST_PATH/AutomationCRQNumbers_Repository.txt |wc -l`
echo " CR_C : $cr_c"
crq_chk=`ls -lrt $AUTO_CONFIG/$1/*.appconf|wc -l`
echo "CRQ_CHK : $crq_chk"
if [ $crq_chk -gt 0 ]
   then
       echo "Verifying $1 in Deployment Automation Folder..."
            if [ $cr_c -eq 0 ]
                then
                    echo "$dt-$CRQ_CONFIG" >>$POST_PATH/AutomationCRQNumbers_Repository.txt
                     echo "debug step"
                      pwd
                      chmod 777 .
                      ls -lrt
                    ls -lrt ${CRQ_CONFIG}/*.appconf |awk '{print $9}' >engine.tmp
                      cat engine.tmp| while read eg1
                          do
                             engine=`echo $eg1|cut -d'.' -f 1` 
                              echo "engine : $engine"
                             engine=${engine##*/}
                             echo "engine : $engine"
                             echo "Conf : $CONF_FILE"
			   
##########################
### Backup of TRA Files Logic starts from here ##
##########################
                             #engine1=`grep $engine $CONF_FILE| head -1 |awk -F'|' '{print $1}'`
                             #echo "engine1 before $engine1"
                             echo "${host_appdy//,/$'\n'}"
                             echo "${host_appdy//,/$'\n'}" > usr1.tmp
                             #e1=`echo $engine1|grep -v '^$'|wc -l`
                             #echo "e1 : $e1"
                             
                             cat usr1.tmp| while read ur1; do ls -lrt $TRA_PATH | awk '{print $9}' > engineapp_$ur1.tmp; done; engine1=`grep -h $engine engineapp_*.tmp| tail -1`; 
			     eng_val=`grep $engine $CRQ_CONFIG/bw/AppManage.batch |grep -v '^$' |wc -l`
		             echo "engine1 after : $engine1"
                              if [ $eng_val -ne 0 ]
				  then
				    echo "Checking $engine in AppManage.batch file"
                                    for ht in $host
                                      do
				         echo "$engine tra backup started for $ht"
                                         echo "Actual $host_name"
                                         if [ "${ht}" = "${host_name}" ]; 
                                            then 
                                               echo "if condition"
                                               cp $TRA_PATH/$engine1/$engine*.tra $BKP_CONFIG
                                            else
                                              echo "else condition"
                                              scp $usr@$ht:$TRA_PATH/$engine1/$engine*.tra $BKP_CONFIG
                                          fi
                                         
                                         ls -lrt $BKP_CONFIG/$engine*.tra |awk '{print $9}'|awk -F'/' '{print $NF}' > move.tmp
                                         cat move.tmp | while read line; do mv $BKP_CONFIG/$line $BKP_CONFIG/"$ht"_$line;done
                                         echo "$engine tra files backup successfully completed under $BKP_CONFIG for $ht"
                                      done
### BackUp Logic END ###

                     
                              ############### PLEASE DO NOT UPDATE BELOW UNTIL THERE IS A REQUIREMENT #####################################
	          

              cat $CONF_FILE | grep "$engine|"|while read line
               do
                 echo "$line" > post.tmp
                 appName=''
                 command=''
                 property=''
                 source=''
                 destination=''
                 sourcePath=''
                 destinationPath=''
		 appName_admin=''
	         destination_folder=''
                 user=''
                 cmd=''
                 IFS="|"
                 while read f1 f2 f3 f4 f5 f6 f7 f8 f9 f10
                   do
                    echo $f1
                    appName=$f1
                    command=$f2
                    property=$f3
                    sourcePath=$f4
                    destinationPath=$f5
                    source=$f6
                    destination=$f7
                    user=$f8
	            appName_admin=$f9
		    destination_folder=$f10
                    echo $1"::::"$appName
                    echo $command
                    echo "doing for $line"
                          if [[ $1 = $CRQ_NME ]]
                                then
                                  if [[ $command == "update" ]]
                                        then
                                           IFS=", "
                                        echo "appName=$appName"
					echo "command=$command"
                                        echo "property=$property"
                                        echo "destinationPath=$destinationPath"
                                        echo "destination=$destination"
                                        echo "user=$user"
					echo "destination_folder=$destination_folder"
                                        echo "${destination//,/$'\n'}" > usr.tmp
                                               cat usr.tmp |while read i
                                               do
                                                {
                                                echo "user raghu from update $usr"
                                                 echo "iam from update $i"
												 if [ "${i}" = "${host_name}" ];
												  then 
												    echo "if condition for update property"
                                                    echo $property |/usr/bin/tee -a $destinationPath
													 echo "$property property successfully updated. Please check the $destinationPath on $i to validate the changes."
                                                     ls -lrt $BKP_CONFIG/*.tra| awk '{print $9}'|grep $i|grep $appName| awk -F_ '{print $NF}' > ta.tmp
                                                     cp $TRA_PATH/$engine1/$engine*.tra $POST_PATH
												   else
												    echo "else condition for update property"
												    cmd=`ssh -q $usr@$i "echo $property |/usr/bin/tee -a $destinationPath"`
													echo "$property property successfully updated. Please check the $destinationPath on $i to validate the changes."
                                                    ls -lrt $BKP_CONFIG/*.tra| awk '{print $9}'|grep $i|grep $appName| awk -F_ '{print $NF}' > ta.tmp
                                                    scp $usr@$i:$TRA_PATH/$engine1/$engine*.tra $POST_PATH
												   fi
                                                    
                                                   cat ta.tmp|while read ta
                                                    do
                                                      echo $ta
                                                      chk=`grep -w $property $POST_PATH/$ta| grep -v '^#'|wc -l`
                                                       if [ $chk -ne 0 ]
						                                     then
                                                                echo "$CRQ_NME|$dt|$property Property successfully updated in $ta file in $i" >> $CRQ_CONFIG/PostDeployment_Manualchanges.log
                                                             else
							                                    echo "$CRQ_NME|$dt|$property Property NOT successfully updated in $ta file in $i" >> $CRQ_CONFIG/PostDeployment_Manualchanges.log
							                             fi
						                            done
						                               } < /dev/null                                              
                                              done
                                          IFS="|"
                                elif [[ $command == "remotecopy" ]]
                                        then
                                        echo " Inside Remote Copy"
                                        echo "command=$command"
                                        echo "sourcePath=$sourcePath"
                                        echo "destinationPath=$destinationPath"
			                echo "source=$source"
                                        echo "destination=$destination"
                                        echo "user=$user"
				        echo "destination_folder=$destination_folder"
                                        IFS=", "
                                        echo "${destination//,/$'\n'}" > usr.tmp
                                        cat usr.tmp |while read i                                           
                                            do
                                            {
                                             if [ "${i}" = "${host_name}" ]; 
                                                then 
                                                   echo "if condition for remote copy"
                                                   cp $sourcePath $destinationPath
												   echo "$destinationPath successfully updated. Please check the $destinationPath on $i to validate the changes."
                                                   if [ -f "$destinationPath" ]; then echo "$CRQ_NME|$dt|$destinationPath successfully updated in $i"; else echo "$CRQ_NME|$dt|$destinationPath NOT successfully updated in $i"; fi >> $CRQ_CONFIG/PostDeployment_Manualchanges.log

                                                 else
                                                    echo "else condition"
                                                    cmd=`scp $usr@$source:$sourcePath $usr@$i:$destinationPath`
													echo "$destinationPath successfully updated. Please check the $destinationPath on $i to validate the changes."
                                                    if ssh -q $i  "test -e $destinationPath"; then echo "$CRQ_NME|$dt|$destinationPath successfully updated in $i"; else echo "$CRQ_NME|$dt|$destinationPath NOT successfully updated in $i"; fi >> $CRQ_CONFIG/PostDeployment_Manualchanges.log
                                          
                                                  fi

                                            } < /dev/null
                                           done
                                         IFS="|"

                               elif [[ $command == "remove" ]]
                                        then
                                        echo "Inside Remove"
                                        echo "appName=$appName"
                                        echo "command=$command"
                                        echo "destinationPath=$destinationPath"
                                        echo "destination=$destination"
					echo "destination_folder=$destination_folder"
                                        echo "user=$user"
                                          IFS=", "
                                          echo "${destination//,/$'\n'}" > usr.tmp
                                          cat usr.tmp |while read i
                                          do
                                          {
                                          
                                           if [ "${i}" = "${host_name}" ]; 
                                                         then 
                                                           echo "if condition"
                                                           rm $destinationPath
                                                         else
                                                            echo "else condition"
                                                            cmd=`ssh $usr@$i rm $destinationPath`
                                                           fi

                                          echo "$destinationPath successfully removed. Please check the $destinationPath on $i to validate the changes."
                                          if ssh -q $i  "test -e $destinationPath"; then echo "$CRQ_NME|$dt|$destinationPath NOT successfully removed in $i"; else echo "$CRQ_NME|$dt|$destinationPath successfully removed in $i"; fi >> $CRQ_CONFIG/PostDeployment_Manualchanges.log
                                        } < /dev/null
                                         done
                                        IFS="|"

			              elif [[ $command == "comment" ]]
                                        then
                                        echo "Comment Property"
					echo "appName=$appName"
                                        echo "command=$command"
                                        echo "Property=$property"
                                        echo "destinationPath=$destinationPath"
                                        echo "destination=$destination"
                                        echo "destination_folder=$destination_folder"
                                        echo "user=$user"
                                        IFS=", "
                                        echo "${destination//,/$'\n'}" > usr.tmp
                                        cat usr.tmp |while read i
                                            do
                                            {
                                              cmd=`ssh $usr@$i "sed 's/$property/#$property/g' $destinationPath > test.tmp && mv test.tmp $destinationPath"` 
	                                      echo "$property property successfully commented in $appName. Please check the $destinationPath on $i to validate the changes."
                                             echo "$CRQ_NME|$dt|$property Property successfully updated in $destinationPath files in $i" >> $CRQ_CONFIG/PostDeployment_Manualchanges.log
                                           } < /dev/null
                                           done
                                         IFS="|"
                        fi
                  fi

                done < post.tmp 
            done

######################################################
                                                     #
### Applying AppDynamics Property#################   #
                                                     #
######################################################

              for ht1 in $host
               do
	        ls -lrt $BKP_CONFIG/*.tra|grep "$engine" |awk '{print $9}'|awk -F'/' '{print $NF}'|awk -F'.' '{print $1}' > appd.tmp
		cat appd.tmp|while read appd
                   do
				     if [ "${ht1}" = "${host_name}" ]; 
                           then 
								echo "$appd" |grep "$ht1"| cut -d"_" -f2- > serv.tmp
								cat serv.tmp |while read line1
								do
									  appdy=appdynamics.agent
									  prop="java.extended.properties=-Xincgc -XX:NewSize=192M -XX:MaxNewSize=192M -XX:PermSize=27m -XX:MaxPermSize=512m -XX:+UseParNewGC -XX:+UseConcMarkSweepGC -XX:MaxGCPauseMillis=150 -XX:+CMSIncrementalMode -XX:+CMSIncrementalPacing -XX:+UseCMSCompactAtFullCollection -XX:CMSFullGCsBeforeCompaction=2 -XX:+DisableExplicitGC -XX:+UseTLAB -XX:+UseSpinning -XX:+UseFastAccessorMethods-XX\:+PrintGCDetails -XX:+PrintGCTimeStamps -XX:+PrintGCDateStamps -Xloggc:$GC_PATH/${line1}.log -javaagent:/opt/tibco/tools/AppDynamics/ICCIR4PERF04/AppServerAgent/latest/javaagent.jar -Dappdynamics.agent.applicationName=CPP -Dappdynamics.agent.tierName=TIL -Dappdynamics.agent.uniqueHostId=$ht1 -Dappdynamics.agent.ssl.protocol=TLSv1.1 -Dappdynamics.agent.nodeName=$ht1-${line1}"
									  # removing the app dynamis property update as per discussion
									  echo $prop |/usr/bin/tee -a $TRA_PATH/$engine1/${line1}.tra
				#                     echo $cmd2" property successfully updated. Please check the $TRA_PATH/$engine1/${line1}.tra on $ht1 to validate the changes.
									  grep -F '$appdy' $TRA_PATH/$engine1/${line1}.tra > cmd.tmp
									  echo "$CRQ_NME|$dt|$host|AppDynamic Property successfully updated to ${line1}.tra file in $ht1" >> $CRQ_CONFIG/PostDeployment_Manualchanges.log
								done
						else
						     echo "$appd" |grep "$ht1"| cut -d"_" -f2- > serv.tmp 
								cat serv.tmp |while read line1
								  do
								  appdy=appdynamics.agent
								  prop="java.extended.properties=-Xincgc -XX:NewSize=192M -XX:MaxNewSize=192M -XX:PermSize=27m -XX:MaxPermSize=512m -XX:+UseParNewGC -XX:+UseConcMarkSweepGC -XX:MaxGCPauseMillis=150 -XX:+CMSIncrementalMode -XX:+CMSIncrementalPacing -XX:+UseCMSCompactAtFullCollection -XX:CMSFullGCsBeforeCompaction=2 -XX:+DisableExplicitGC -XX:+UseTLAB -XX:+UseSpinning -XX:+UseFastAccessorMethods-XX\:+PrintGCDetails -XX:+PrintGCTimeStamps -XX:+PrintGCDateStamps -Xloggc:$GC_PATH/$line1.log -javaagent:/opt/tibco/tools/AppDynamics/ICCIR4PERF04/AppServerAgent/latest/javaagent.jar -Dappdynamics.agent.applicationName=CPP -Dappdynamics.agent.tierName=TIL -Dappdynamics.agent.uniqueHostId=$ht1 -Dappdynamics.agent.ssl.protocol=TLSv1.1 -Dappdynamics.agent.nodeName=$ht1-$5-$line1"
								  # removing the app dynamis property update as per discussion
								  #echo $prop |/usr/bin/tee -a $TRA_PATH/$engine1/$line1.tra
								  cmd2=`ssh -q tibco@$ht1 "echo $prop |/usr/bin/tee -a $TRA_PATH/$engine1/$line1.tra"`
								  ssh -q tibco@$ht1 "grep -F '$appdy' $TRA_PATH/$engine1/$line1.tra" > cmd.tmp
								  
			#                     echo $cmd2" property successfully updated. Please check the $TRA_PATH/$engine1/$line1.tra on $ht1 to validate the changes.
								#  grep -F '$appdy' $TRA_PATH/$engine1/$line1.tra > cmd.tmp
								  echo "$CRQ_NME|$dt|$host|AppDynamic Property successfully updated to $line1.tra file in $ht1" >> $CRQ_CONFIG/PostDeployment_Manualchanges.log
								  done
						   fi
                   
                 done
             done
### AppDynamics Property logic ends here###

else
echo "$engine is not available in AppManage.batch file. Hence NOT applying Post Manual Changes." >> $CRQ_CONFIG/PostDeployment_Manualchanges.log
fi
done
else
echo "PostManual Changes are already applied for $CRQ_CONFIG. If you still want to do the changes again ,remove $1 entry from AutomationCRQNumbers_Repository.txt"
fi
cat $CRQ_CONFIG/PostDeployment_Manualchanges.log >> PostDeployment_Manualchanges_History.log

ct=`ls -lrt *tmp | wc -l`
if [ $ct -gt 0 ]
then
##rm *.tmp
##rm *.tra
echo "                                          ***** END OF SCRIPT EXECUTION ****"
fi
else
echo " Please Enter the valid CRQ Number!! . Make sure you are entering the CRQ Number available under $AUTO_CONFIG "
fi

############################################################# Logic for Solaris #############################################

elif [ `uname -a |grep SPARC|grep "$host_name"|wc -l` -eq 1 ]
then
## Change the below varialbles as per environment(Staging/Production)
######################################################################
##Staging

AUTO_CONFIG=/opt/tibco/tools/DeploymentAutomation_TSSTG07
TRA_PATH=/opt/tibco/tra/domain/TSSTG07/application
POST_PATH=/opt/tibco/tools/DeploymentAutomation_TSSTG07/PostDeploymentChanges
host="uk-ph-tstil-bw02 uk-ph-tstil-bw01"
usr=tibbin
CONF_FILE=ManualChangesConfiguration_TS.conf
## Proudction

#AUTO_CONFIG=/opt/tibco/tools/DeploymentAutomation_TSPR04
#TRA_PATH=/opt/tibco/tra/domain/TSPR04/application
#GC_PATH=/opt/tibco/tra/domain/TSPR04/application/logs/GCLogs/
#POST_PATH=/opt/tibco/tools/DeploymentAutomation_TSPR04/PostDeploymentChanges
#usr=tibbin

### MS Site##

#host="uk-ms-tstil-bw03 uk-ms-tstil-bw04 uk-ms-tstil-bw05 uk-ms-tstil-bw06"
#CONF_FILE=ManualChangesConfiguration_TS_MS.conf

##if it is BE site

#host="uk-be-tstil-bw03 uk-be-tstil-bw04 uk-be-tstil-bw05 uk-be-tstil-bw06"
#CONF_FILE=ManualChangesConfiguration_TS_BE.conf

######################################################################

CRQ_CONFIG=$AUTO_CONFIG/$1
BKP_CONFIG=$CRQ_CONFIG/backup
CRQ_NME=$1
cr_c=`grep "$CRQ_CONFIG" $POST_PATH/AutomationCRQNumbers_Repository.txt |wc -l`
crq_chk=`ls -lrt $AUTO_CONFIG/$1/*.appconf|wc -l`
if [ $crq_chk -gt 0 ]
  then
  echo "Verifying $1 in Deployment Automation Folder..."
  if [ $cr_c -eq 0 ]
    then
      echo "$dt-$CRQ_CONFIG" >>$POST_PATH/AutomationCRQNumbers_Repository.txt
      ls -lrt ${CRQ_CONFIG}/*.appconf |awk '{print $9}' >engine.tmp
      cat engine.tmp| while read eg1
               do
               engine=`echo $eg1|cut -d'.' -f 1`
               engine=${engine##*/}

##########################
### Backup of TRA Files Logic starts from here ##
##########################
                 engine1=`grep $engine $CONF_FILE| head -1 |awk -F'|' '{print $1}'`
                 eng_val=`grep $engine $CRQ_CONFIG/bw/AppManage.batch |grep -v '^$' |wc -l`
                 if [ $eng_val -ne 0 ]
                    then
                     echo "Checking $engine in AppManage.batch file"
                      for ht in $host
                       do
                         echo "$engine tra backup started for $ht"
                         scp $usr@$ht:$TRA_PATH/$engine1/$engine*.tra $BKP_CONFIG
                         ls -lrt $BKP_CONFIG/$engine*.tra |awk '{print $9}'|awk -F'/' '{print $8}' > move.tmp
                         cat move.tmp | while read line; do mv $BKP_CONFIG/$line $BKP_CONFIG/"$ht"_$line;done
                         echo "$engine tra files backup successfully completed under $BKP_CONFIG for $ht"
                       done

### BackUp Logic END ###


                                      ############### PLEASE DO NOT UPDATE BELOW UNTIL THERE IS A REQUIREMENT #####################################

          cat $CONF_FILE | grep "$engine|"|while read line
              do
                 echo "$line" > post.tmp
                 appName=''
                 command=''
                 property=''
                 source=''
                 destination=''
                 sourcePath=''
                 destinationPath=''
                 user=''
                 cmd=''
                 appName_admin=''
                 destination_folder=''
                 IFS="|"
                 while read f1 f2 f3 f4 f5 f6 f7 f8 f9 f10
                   do
                    echo $f1
                    appName=$f1
                    command=$f2
                    property=$f3
                    sourcePath=$f4
                    destinationPath=$f5
                    source=$f6
                    destination=$f7
                    user=$f8
                    appName_admin=$f9
                    destination_folder=$f10
                    echo $1"::::"$appName
                    echo $command
                    echo "doing for $line"
                          if [[ $1 = $CRQ_NME ]]
                                then
                                  if [[ $command == "update" ]]
                                        then
                                           IFS=", "
                                        echo "appName=$appName"
                                        echo "command=$command"
                                        echo "property=$property"
                                        echo "destinationPath=$destinationPath"
                                        echo "destination=$destination"
                                        echo "user=$user"
                                        echo "destination_folder=$destination_folder"
                                        echo "$destination"> usr.tmp
                                        perl -pi -e 's/,/\n/g' usr.tmp
                                        cat usr.tmp |while read i
                                          do
                                                {
                                                 cmd=`ssh -q $usr@$i "echo $property |/usr/bin/tee -a $destinationPath"`
                                                  echo "$property successfully updated. Please check the $destinationPath on $i to validate the changes."
                                                  ls -lrt $BKP_CONFIG/*.tra| awk '{print $9}'|grep $i|grep $appName| cut -d"_" -f3- > ta.tmp
                                                  scp $usr@$i:$TRA_PATH/$engine1/$engine*.tra $POST_PATH
                                                  cat ta.tmp|while read ta
                                                     do
                                                          chk=`grep -w $property $POST_PATH/$ta| grep -v '^#'|wc -l`
                                                           if [ $chk -ne 0 ]
                                                                then
                                                                echo "$CRQ_NME|$dt|$property Property successfully updated in $ta file in $i" >> $CRQ_CONFIG/PostDeployment_Manualchanges.log
                                                                else
                                                                echo "$CRQ_NME|$dt|$property Property successfully NOT updated in $ta file in $i" >> $CRQ_CONFIG/PostDeployment_Manualchanges.log
                                                           fi
                                                     done
                                                } < /dev/null
                                              done
                                          IFS="|"
                                elif [[ $command == "remotecopy" ]]
                                        then
                                        echo " Inside Remote Copy"
                                        echo "command=$command"
                                        echo "sourcePath=$sourcePath"
                                        echo "destinationPath=$destinationPath"
                                        echo "source=$source"
                                        echo "destination=$destination"
                                        echo "destination_folder=$destination_folder"
                                        echo "user=$user"
                                        IFS=", "
                                        echo "$destination"> usr.tmp
                                        perl -pi -e 's/,/\n/g' usr.tmp
                                        cat usr.tmp |while read i
                                            do
                                            {
                                            cmd=`scp $usr@$source:$sourcePath $usr@$i:$destination_folder`
                                             echo "$destinationPath successfully updated. Please check the $destinationPath on $i to validate the changes."
                                             if ssh -q $i  "test -e $destinationPath"; then echo "$CRQ_NME|$dt|$destinationPath successfully updated in $i"; else echo "$CRQ_NME|$dt|$destinationPath not successfully updated in $i"; fi >> $CRQ_CONFIG/PostDeployment_Manualchanges.log
                                           } < /dev/null
                                           done
                                         IFS="|"

                               elif [[ $command == "remove" ]]
                                        then
                                        echo "Inside Remove"
                                        echo "appName=$appName"
                                        echo "command=$command"
                                        echo "destinationPath=$destinationPath"
                                        echo "destination=$destination"
                                        echo "user=$user"
                                          IFS=", "
                                         echo "$destination"> usr.tmp
                                         perl -pi -e 's/,/\n/g' usr.tmp
                                          cat usr.tmp |while read i
                                          do
                                          {
                                          cmd=`ssh $usr@$i rm $destinationPath`
                                          echo "$destinationPath successfully removed. Please check the $destinationPath on $i to validate the changes."
                                          if ssh -q $i  "test -e $destinationPath"; then echo "$CRQ_NME|$dt|$destinationPath not successfully removed in $i"; else echo "$CRQ_NME|$dt|$destinationPath removed successfully in $i"; fi >> $CRQ_CONFIG/PostDeployment_Manualchanges.log
                                        } < /dev/null
                                         done
                                        IFS="|"
                              elif [[ $command == "comment" ]]
                                        then
                                        echo "Comment Property"
                                        echo "appName=$appName"
                                        echo "command=$command"
                                        echo "Property=$property"
                                        echo "destinationPath=$destinationPath"
                                        echo "destination=$destination"
                                        echo "destination_folder=$destination_folder"
                                        echo "user=$user"
                                        echo "$destination"> usr.tmp
                                        IFS=", "
                                        perl -pi -e 's/,/\n/g' usr.tmp
                                        cat usr.tmp |while read i
                                            do
                                            {
                                             scp $usr@$i:$destinationPath $POST_PATH
                                             echo "$cmd was exeucted . Tra Files copied into $POST_PATH"
                                             ls -lrt $POST_PATH/*.tra |awk '{print $9}' > tra.tmp
                                             cat tra.tmp| awk -F'/' '{print $7}' | while read line
                                             do
                                             perl -pi -e 's/'$property'/'#$property'/g' $line
                                             done
                                             scp $POST_PATH/*.tra $usr@$i:$destination_folder
                                             rm $POST_PATH/*.tra
                                             echo "$property property successfully commented in $appName. Please check the $destinationPath on $i to validate the changes."
                                             echo "$CRQ_NME|$dt|$property Property successfully updated in $destinationPath files in $i" >> $CRQ_CONFIG/PostDeployment_Manualchanges.log
                                           } < /dev/null
                                           done
                                         IFS="|"
                        fi
                  fi

                done < post.tmp
            done
else
echo "$engine is not available in AppManage.batch file. Hence NOT applying Post Manual Changes." >> $CRQ_CONFIG/PostDeployment_Manualchanges.log
fi
    done

else
     echo "PostManual Changes are already applied for $CRQ_CONFIG. If you still want to do the changes again ,remove CRQ entry from AutomationCRQNumbers_Repository.txt"
fi
cat $CRQ_CONFIG/PostDeployment_Manualchanges.log >> PostDeployment_Manualchanges_History.log

ct=`ls -lrt *tmp | wc -l`
if [ $ct -gt 0 ]
then
echo ""
rm *.tra
rm *.tmp
echo "                                          ***** END OF SCRIPT EXECUTION ****"
fi
else
echo " Please Enter the valid CRQ Number!! . Make sure you are entering the CRQ Number available under $AUTO_CONFIG "
fi

#################################################################################### Logic For RIG #############################################################################

elif [ `uname -a |grep Linux|grep "$host_name"|grep 'vodafone'|wc -l` -eq 1 ]
then
## Change the below varialbles as per environment
######################################################################
##Staging

AUTO_CONFIG=/opt/tibco/tools/DeploymentAutomation_ph_stg01_rig
TRA_PATH=/opt/tibco/tra/domain/ph_stg01_rig/application
POST_PATH=/opt/tibco/tools/DeploymentAutomation_ph_stg01_rig/PostDeploymentChanges
host="uk-ph-rig-02"
usr=tibbin
CONF_FILE=ManualChangesConfiguration_RIG.conf
## Proudction- BE:

#AUTO_CONFIG=/opt/tibco/tools/DeploymentAutomation_be_prod_rig
#TRA_PATH=/opt/tibco/tra/domain/be_prod_rig/application
#GC_PATH=/opt/tibco/tra/domain/be_prod_rig/application/logs/GCLogs/
#POST_PATH=/opt/tibco/tools/DeploymentAutomation_be_prod_rig/PostDeploymentChanges
#host="uk-be-rig-02 uk-be-rig-01 uk-be-rig-03 uk-be-rig-04"
#usr=tibbin
#CONF_FILE=ManualChangesConfiguration_RIG_BE.conf
### Production-MS:

##if MS site
#AUTO_CONFIG=/opt/tibco/tools/DeploymentAutomation_ms_prod_rig
#TRA_PATH=/opt/tibco/tra/domain/ms_prod_rig/application
#GC_PATH=/opt/tibco/tra/domain/ms_prod_rig/application/logs/GCLogs/
#POST_PATH=/opt/tibco/tools/DeploymentAutomation_ms_prod_rig/PostDeploymentChanges
#host="uk-ms-rig-02 uk-ms-rig-01 uk-ms-rig-03 uk-ms-rig-04"
#usr=tibbin
#CONF_FILE=ManualChangesConfiguration_RIG_MS.conf
######################################################################

CRQ_CONFIG=$AUTO_CONFIG/$1
BKP_CONFIG=$CRQ_CONFIG/backup
CRQ_NME=$1
cr_c=`grep "$CRQ_CONFIG" $POST_PATH/AutomationCRQNumbers_Repository.txt |wc -l`
crq_chk=`ls -lrt $AUTO_CONFIG/$1/*.appconf|wc -l`
ls -lrt $AUTO_CONFIG|awk '{print $9}' > crq.tmp
crq_chk1=`grep $1 crq.tmp|wc -l`
if [ $cr_c -eq 0 ]
 then
 echo "Verifying $1 in Deployment Automation Folder..."
  if [ $crq_chk1 -eq 1 ]
    then
      echo "..."
         if [ $crq_chk -eq 0 ]
             then
               echo "$dt-$CRQ_CONFIG" >>$POST_PATH/AutomationCRQNumbers_Repository.txt
               echo "Do you want to apply Manual changes to all RIG cacheagents"
               echo "1         [YES]"
               echo "2          [NO]"
               echo -n "Press [ENTER] to continue,...: "
               read num
               case "$num" in
               YES)
                 echo "Applying Manual changes for ALL RIG Cacheagents"
                 cp $AUTO_CONFIG/RIG_ApplicationList/*.appconf $CRQ_CONFIG
               ;;
               NO)
                 echo "Provide the Cacheagents name with COMMA seperated"
                 echo -n "Press [ENTER] to continue,...: "
                 read agent
                 echo "
                 "
                 echo "Applying Manual changes for $agent"
                 echo "${agent//,/$'\n'}" > agent.tmp
                 cat $POST_PATH/agent.tmp
                 cat $POST_PATH/agent.tmp | while read line; do cp $AUTO_CONFIG/RIG_ApplicationList/$line*.appconf $CRQ_CONFIG;done
              ;;
              *)
              echo "Please Enter either YES/NO"
              exit
              ;;
              esac
              mkdir $CRQ_CONFIG/backup
              ls -lrt ${CRQ_CONFIG}/*.appconf |awk '{print $9}' >engine.tmp
              cat engine.tmp| while read eg1
                 do
                   engine=`echo $eg1|cut -d'.' -f 1`
                   engine=${engine##*/}
##########################
### Backup of TRA Files Logic starts from here ##
##########################
                   engine1=`grep $engine $CONF_FILE| head -1 |awk -F'|' '{print $1}'`
                   for ht in $host
                      do
                        scp $usr@$ht:$TRA_PATH/$engine1/$engine*.tra $BKP_CONFIG
                        ls -lrt $BKP_CONFIG/$engine*.tra |awk '{print $9}'|awk -F'/' '{print $8}' > move.tmp
                        cat move.tmp | while read line; do mv $BKP_CONFIG/$line $BKP_CONFIG/"$ht"_$line;done
                        echo "$engine tra files backup has been taken successfully under $BKP_CONFIG"
                     done

### BackUp Logic END ###

                                ############### PLEASE DO NOT UPDATE BELOW UNTIL THERE IS A REQUIREMENT #####################################

          cat $CONF_FILE | grep $engine|while read line
               do
                 echo "$line" > post.tmp
                 appName=''
                 command=''
                 property=''
                 source=''
                 destination=''
                 sourcePath=''
                 destinationPath=''
                 user=''
                 cmd=''
                 appName_admin=''
                 destination_folder=''
                 IFS="|"
                 while read f1 f2 f3 f4 f5 f6 f7 f8 f9 f10
                   do
                    echo $f1
                    appName=$f1
                    command=$f2
                    property=$f3
                    sourcePath=$f4
                    destinationPath=$f5
                    source=$f6
                    destination=$f7
                    user=$f8
                    appName_admin=$f9
                    destination_folder=$f10
                    echo $1"::::"$appName
                    echo $command
                    echo "doing for $line"
                          if [[ $1 = $CRQ_NME ]]
                                then
                                  if [[ $command == "update" ]]
                                        then
                                           IFS=", "
                                        echo "appName=$appName"
                                                            echo "command=$command"
                                        echo "property=$property"
                                        echo "destinationPath=$destinationPath"
                                        echo "destination=$destination"
                                        echo "user=$user"
                                            echo "${destination//,/$'\n'}" > usr.tmp
                                               cat usr.tmp |while read i
                                               do
                                                {
                                                 cmd=`ssh -q $usr@$i "echo $property |/usr/bin/tee -a $destinationPath"`
                                                  echo "$cmd property successfully updated. Please check the $destinationPath on $i to validate the changes."
                                                   ls -lrt $BKP_CONFIG/*.tra| awk '{print $9}'|grep $i|grep $appName| cut -d"_" -f5- > ta.tmp
                                                    scp $usr@$i:$TRA_PATH/$engine/$engine*.tra $POST_PATH
                                                     cat ta.tmp|while read ta
                                                          do
                                                          chk=`grep -w $property $POST_PATH/$ta| grep -v '^#'|wc -l`
                                                           if [ $chk -ne 0 ]
                                                                then
                                                                echo "$CRQ_NME|$dt|$property Property successfully updated in $ta file in $i" >> $CRQ_CONFIG/PostDeployment_Manualchanges.log
                                                                else
                                                                echo "$CRQ_NME|$dt|$property Property successfully NOT updated in $ta file in $i" >> $CRQ_CONFIG/PostDeployment_Manualchanges.log
                                                            fi
                                                          done
                                                } < /dev/null
                                                 done
                                          IFS="|"
                                elif [[ $command == "remotecopy" ]]
                                        then
                                        echo " Inside Remote Copy"
                                        echo "command=$command"
                                        echo "sourcePath=$sourcePath"
                                        echo "destinationPath=$destinationPath"
                                        echo "source=$source"
                                        echo "destination=$destination"
                                        echo "destination_folder=$destination_folder"
                                        echo "user=$user"
                                        IFS=", "
                                        echo "$destination"> usr.tmp
                                        perl -pi -e 's/,/\n/g' usr.tmp
                                        cat usr.tmp |while read i
                                            do
                                            {
                                            cmd=`scp $usr@$source:$sourcePath $usr@$i:$destination_folder`
                                             echo "$destinationPath successfully updated. Please check the $destinationPath on $i to validate the changes."
                                             if ssh -q $i  "test -e $destinationPath"; then echo "$CRQ_NME|$dt|$destinationPath updated successfully $i"; else echo "$CRQ_NME|$dt|$destinationPath not updated successfully in $i"; fi >> $CRQ_CONFIG/PostDeployment_Manualchanges.log
                                           } < /dev/null
                                           done
                                         IFS="|"

                               elif [[ $command == "remove" ]]
                                        then
                                        echo "Inside Remove"
                                        echo "appName=$appName"
                                        echo "command=$command"
                                        echo "destinationPath=$destinationPath"
                                        echo "destination=$destination"
                                        echo "user=$user"
                                          IFS=", "
                                         echo "$destination"> usr.tmp
                                         perl -pi -e 's/,/\n/g' usr.tmp
                                          cat usr.tmp |while read i
                                          do
                                          {
                                          cmd=`ssh $usr@$i rm $destinationPath`
                                          echo "$destinationPath successfully removed. Please check the $destinationPath on $i to validate the changes."
                                          if ssh -q $i  "test -e $destinationPath"; then echo "$CRQ_NME|$dt|$destinationPath not removed successfully $i "; else echo "$CRQ_NME|$dt|$destinationPath removed successfully in $i"; fi >> $CRQ_CONFIG/PostDeployment_Manualchanges.log
                                        } < /dev/null
                                         done
                                        IFS="|"
                              elif [[ $command == "comment" ]]
                                        then
                                        echo "Comment Property"
                                        echo "appName=$appName"
                                        echo "command=$command"
                                        echo "Property=$property"
                                        echo "destinationPath=$destinationPath"
                                        echo "destination=$destination"
                                        echo "destination_folder=$destination_folder"
                                        echo "user=$user"
                                        IFS=", "
                                        echo "${destination//,/$'\n'}" > usr.tmp
                                        cat usr.tmp |while read i
                                            do
                                            {

                                              cmd=`ssh $usr@$i "sed 's/$property/#$property/g' $destinationPath > test.tmp && mv test.tmp $destinationPath"`
                                              echo "$property property successfully commented in $appName. Please check the $destinationPath on $i to validate the changes."
                                              echo "$CRQ_NME|$dt|$property Property successfully commented in $destinationPath file in $i" >> $CRQ_CONFIG/PostDeployment_Manualchanges.log
                                           } < /dev/null
                                           done
                                         IFS="|"
                        fi
                  fi

                done < post.tmp
            done
                done

#### Adding GC Property to all RIG cacheagents
ls -lrt $BKP_CONFIG/*.tra| awk '{print $9}'|awk -F'/' '{print $8}'|awk -F'.' '{print $1}' > $POST_PATH/apptra.tmp
ls -lrt ${CRQ_CONFIG}/*.appconf |awk '{print $9}' >engine.tmp
   cat engine.tmp| while read eg
     do
         engine=`echo $eg|cut -d'.' -f 1`
         engine=${engine##*/}
           cat $POST_PATH/apptra.tmp |grep "$engine"|while read line
              do
                for ht1 in $host
                   do
                   echo "$line" |grep "$ht1"|awk -F'_' '{print $2"_"$3"_"$4}' > serv.tmp
                   cat serv.tmp |while read line1
                      do
                      prop="java.extended.properties=-server -d64 -javaagent:%BE_HOME%/lib/cep-instrumentation.jar -XX:MaxPermSize=256m -XX:+UseParNewGC -XX:+UseConcMarkSweepGC -XX:MaxGCPauseMillis=150 -XX:+CMSIncrementalMode -XX:+CMSIncrementalPacing -XX:+UseCMSCompactAtFullCollection -XX:CMSFullGCsBeforeCompaction=2 -XX:+DisableExplicitGC -XX:+UseTLAB -XX:+UseSpinning -XX:+UseFastAccessorMethods -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -XX:+PrintGCDateStamps -Xloggc:/logstore/GClogs/$line1.log"
                      cmd2=`ssh tibbin@$ht1 "echo $prop |/usr/bin/tee -a $TRA_PATH/$engine/$line1.tra"`
                      echo "$cmd2 successfully updated. Please check the $TRA_PATH/$engine/$line1.tra on $ht1 to validate the changes."
                      ssh tibbin@$ht1 "grep -F '$line' $TRA_PATH/$engine/$line1.tra" > cmd.tmp
                      echo "$CRQ_NME|$dt|$host|GC Property successfully updated to $line1.tra file in $ht1" >> $CRQ_CONFIG/PostDeployment_Manualchanges.log
                      done
                 done
             done
    done
else
     echo "Please Enter the valid CRQ Number!! . Make sure you are entering the CRQ Number available under $AUTO_CONFIG "
fi
cat $CRQ_CONFIG/PostDeployment_Manualchanges.log >> PostDeployment_Manualchanges_History.log

ct=`ls -lrt *tmp | wc -l`
if [ $ct -gt 0 ]
then
echo ""
rm *.tmp
echo "END OF SCRIPT EXECUTION..."
rm ${CRQ_CONFIG}/*.appconf
rm *.tra
fi
fi
else
echo "PostManual Changes are already applied for $CRQ_CONFIG. Please do recheck the CRQ number. if you still want to do the changes again ,remove CRQ entry from AutomationCRQNumbers_Repository.txt"
fi
fi
