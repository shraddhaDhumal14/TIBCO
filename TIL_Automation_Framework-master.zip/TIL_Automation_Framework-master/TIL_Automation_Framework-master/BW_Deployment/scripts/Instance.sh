# ./Instance.sh "PromotionAndOrderNotification-Misc;ProvisioningAndFulfilment-Carisma;EventHandling-SWMS;ProvisioningAndFulfilment-SIM"  /opt/tibco/Test/Certificate_Deployment auktlpqr auktlprr

Engine_List=$1
Server1=$3 
Path=$2
Server2=$4

#cp -r Instance_Details_bkp.txt Instance_Details.txt
if [ ! -d ${Path}/Instance_backup ]; then
	
	mkdir ${Path}/Instance_backup
	chmod 766 ${Path}/Instance_backup
	cp -r ${Path}/Instance_Details.txt ${Path}/Instance_backup/Instance_Details_bkp.txt
	chmod 766 ${Path}/Instance_backup/Instance_Details_bkp.txt
	rm -r ${Path}/Instance_Details.txt
	grep "CRQ" ${Path}/Instance_backup/Instance_Details_bkp.txt >> "${Path}/Instance_backup/Singal_Instance.txt"
	grep "Release" ${Path}/Instance_backup/Instance_Details_bkp.txt >> "${Path}/Instance_backup/Singal_Instance.txt"
	cp -r ${Path}/Instance_backup/Instance_Details_bkp.txt ${Path}/Instance_backup/Multi_Instance.txt
	chmod 766 ${Path}/Instance_backup/Singal_Instance.txt
	chmod 766 ${Path}/Instance_backup/Multi_Instance.txt
	

	for var in ${Engine_List//;/ }
	do
		Ins1="$(cat ${Path}/Instance_backup/Instance_Details_bkp.txt |  grep $var |  rev |  cut -d'|' -f1 | rev)"
		Ins2="$(cat ${Path}/Instance_backup/Instance_Details_bkp.txt |  grep $var |  rev |  cut -d'|' -f2 | rev)"
		Ins3="$(cat ${Path}/Instance_backup/Instance_Details_bkp.txt |  grep $var |  rev |  cut -d'|' -f3 | rev)"
		Ins4="$(cat ${Path}/Instance_backup/Instance_Details_bkp.txt |  grep $var |  rev |  cut -d'|' -f4 | rev)"
		Ins5="$(cat ${Path}/Instance_backup/Instance_Details_bkp.txt |  grep $var |  rev |  cut -d'|' -f5 | rev)"
		#echo "${Ins3}"
		
		for i in ${Ins3//,/ }
		do	
			#echo "${i}"

			if [[ "$i" == *"${Server1}"* ]] || [[ "$i" == *"${Server2}"* ]] ; then

				echo ${Ins5}"|"${Ins4}"|"${i}"|"${Ins2}"|"${Ins1} >> "${Path}/Instance_backup/Singal_Instance.txt"
				echo \ >> "${Path}/Instance_backup/Singal_Instance.txt"
				
				sed -e s/${i},//g -i ${Path}/Instance_backup/Multi_Instance.txt 
				
				break;
			
			fi
			
		done
	done
	cp -r ${Path}/Instance_backup/Singal_Instance.txt ${Path}/Instance_Details.txt
	chmod 766 ${Path}/Instance_Details.txt
else
	
	if [ ! -f "${Path}/Instance_backup/Multi_Instance.txt" ]; then
	
		rm -r ${Path}/Instance_Details.txt
		cp -r ${Path}/Instance_backup/Instance_Details_bkp.txt ${Path}/Instance_Details.txt
		chmod 766 ${Path}/Instance_Details.txt
	else	
		rm -r ${Path}/Instance_Details.txt
		cp -r ${Path}/Instance_backup/Multi_Instance.txt ${Path}/Instance_Details.txt
		chmod 766 ${Path}/Instance_Details.txt
		rm -r ${Path}/Instance_backup/Multi_Instance.txt
	fi
fi
