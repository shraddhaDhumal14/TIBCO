#!/bin/bash

outputfile="output.csv"

echo "Developer,Rule,Vulnerability" > $outputfile

jq -c '.[]' output.json | while read -r line; do
  email=$(echo $line | jq -r '.Email')
  ruleID=$(echo $line | jq -r '.RuleID')
  fingerprint=$(echo $line | jq -r '.Fingerprint')

  line="$email,$ruleID,$fingerprint"

  echo $line >> $outputfile
done
