#!/bin/bash
# Thsi script try to validate generate option as part of BW deployment.
# Input1: engine names with ; sepaarted. Also when giving the parameter for engine names we need toenclose in ""
# input2: CRQ Number
# input3: Deployment type . NEW | EXISTING

# engine names with validation failure will be written to "generate_failed" file
# engine names with validation success will be written to "generate_success" file

ENGINE=$1
CRQ=$2
DEPLOY_TYPE=$3
WORK_DIR=`pwd`

if [[ ! -z "$4" ]]; then
	bw_var="${4}/Failed_Engines/Failed_Generate_engine_artefacts/bw"
	backup_var="${4}/Failed_Engines/Failed_Generate_engine_artefacts/backup"
	appconf_var="${4}/Failed_Engines/Failed_Generate_engine_artefacts"
else
	bw_var="${WORK_DIR}/Failed_Generate_engine_artefacts/bw"
	backup_var="${WORK_DIR}/Failed_Generate_engine_artefacts/backup"
	appconf_var="${WORK_DIR}/Failed_Generate_engine_artefacts"
fi

# If deployment typeis ESISTING, validate backup.
>${WORK_DIR}/generate_success
>${WORK_DIR}/generate_failed





do_backup() {

        # This function is to take backup of failed artefacts depending on the option.
        engine=$1
        crq_num=$2
		
		mkdir -p "${bw_var}"
		mkdir -p "${backup_var}"

		[[ -d "${WORK_DIR}/${crq_num}/bw" ]] && mv ${WORK_DIR}/${crq_num}/bw/${engine}*.* "${bw_var}"
		[[ -d "${WORK_DIR}/${crq_num}/backup" ]] && mv ${WORK_DIR}/${crq_num}/backup/${engine}*.* "${backup_var}"
		[[ -f "${WORK_DIR}/${crq_num}/${engine}.appconf" ]] && mv ${WORK_DIR}/${crq_num}/${engine}.appconf "${appconf_var}"
		[[ -f "${WORK_DIR}/${crq_num}/${engine}.gvconf" ]] && mv ${WORK_DIR}/${crq_num}/${engine}.gvconf "${appconf_var}"
		[[ -f "${WORK_DIR}/${crq_num}/${engine}.prconf" ]] && mv ${WORK_DIR}/${crq_num}/${engine}.prconf "${appconf_var}"

		sed -i "/.*${engine}.*/d" "${WORK_DIR}/${crq_num}/bw/AppManage.batch"
		[[ -d "${WORK_DIR}/${crq_num}/backup" ]] && sed -i "/.*${engine}.*/d" "${WORK_DIR}/${crq_num}/backup/AppManage.batch"
		[[ -d "${WORK_DIR}/${crq_num}/backup" ]] && sed -i "/.*${engine}.*/d" "${WORK_DIR}/${crq_num}/backup/NewApplications.txt"
		sed -i "/.*${eng}.*/d" "${WORK_DIR}/${crq_num}/Instance_Details.txt"
}


while read -r eng; do
        echo "engine name is: ${eng}"
        if [[ "${DEPLOY_TYPE}" == "EXISTING" ]]; then
				flag="fail"
                # Check for EAR file in backup folder.
                if [[ -f ${WORK_DIR}/${CRQ}/backup/${eng}.ear ]] && [[ -f ${WORK_DIR}/${CRQ}/backup/${eng}.xml ]]; then
                        echo "BACKUP is successfully completed for ${eng}"
                        # check for XML file generation in BW folder.
                        if [[ -f ${WORK_DIR}/${CRQ}/bw/${eng}.xml ]] && [[ `cat ${WORK_DIR}/${CRQ}/bw/${eng}.xml | wc -l` -ge "10" ]]; then
                                echo "XML validation is successful in BW Folder"
                                echo "${eng}" >> ${WORK_DIR}/generate_success
								flag="pass"
                        else
                                echo "ERROR: XML validation Failed for engine ${eng} in BW Folder. Please check for more details."
                        fi
				fi
				
				if [[ "${flag}" == "fail" ]]; then 
					do_backup "${eng}" "${CRQ}"
					echo "${eng}" >> ${WORK_DIR}/generate_failed
				fi

        elif [[ "${DEPLOY_TYPE}" == "NEW" ]]; then
                # check for XML file generation in BW folder.
                if [[ -f ${WORK_DIR}/${CRQ}/bw/${eng}.xml ]] && [[ `cat ${WORK_DIR}/${CRQ}/bw/${eng}.xml | wc -l` -ge "10" ]]; then
                        echo "XML validation is successful in BW Folder"
                        echo "${eng}" >> ${WORK_DIR}/generate_success
                else
                        echo "ERROR: XML validation Failed for engine ${eng} in BW Folder. Please check for more details."
                        do_backup "${eng}" "${CRQ}"
                        echo "${eng}" >> ${WORK_DIR}/generate_failed
                fi
        else
                echo "ERROR: Please provide valid option for DEPLOY_TYPE."
        fi
done <<< "$(echo "$ENGINE" | tr ';' '\n')"


