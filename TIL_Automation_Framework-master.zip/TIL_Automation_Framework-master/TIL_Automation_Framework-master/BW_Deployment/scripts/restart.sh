#!/bin/bash
### Execute with CRQ# as input. example: ./restart.sh CRQ1234 ###########################################

IFS="|"
RESTART_LOG_FILE=$1/logs/$1_Restart.log
ex_count=0
OS_NAME=`uname -s`
`>${RESTART_LOG_FILE}`
declare -i line=1

while read f1 f2 f3 f4 f5
do
	flag="F"
	if [ -f $1/restart_exceptions.txt ]; then
		ex_count=`grep "<$f1>" $1/restart_exceptions.txt|wc -l`
	fi
	echo "ex_count::"$ex_count
	if [[ ! ${f1:0:1} = "#" ]]; then
		if [ "$ex_count" == "       0" ] || [ "$ex_count" == "0" ] && [ $line -gt 2 ]; then
			./restartApp.sh $f1 $f2 $f3 $f4 $1 $2 $3 $4 $5 >> ${RESTART_LOG_FILE} &
			pid=$!
			if [[ ! -z "${pid}" ]]; then
				pid_list+=("$pid")
				echo "DEBUG: PID is: ${pid}"
			else
				echo "Not able to get PID for the process started"
				#exit 1
			fi
        else
            echo "The Application "$f1 " is not being restarted as it is present in the Exception List"
        fi
		IFS="|"
		((line += 1))
	fi
done < $1/Instance_Details.txt

# Print PID's created for restartAPP script

for processID in ${pid_list[@]}
do
  echo $processID
done

#echo "Outside loop ###########################################################################################################################"

echo "DEBUG: Restart is initiated. Now need to verify all the processes completed or not?"

unset IFS
declare -i pcount=0
if [[ $OS_NAME == "Linux" ]]
then
	counter=0
	while [[ "${counter}" -le 15 ]]; do
		pcount=0
		for processID in ${pid_list[@]}
		do
			echo "DEBUG: Searching for PID: ${processID}"
			echo "DEBUG: $(ps -p ${processID})"
			if ps -p "${processID}" > /dev/null; then
				echo "DEBUG: Incrementing counter"
				pcount=$((pcount+1))
			fi
		done	
		if [[ "${pcount}" -ne 0 ]]; then
			counter=$((counter+1))
			echo "DEBUG: Counter value is: ${counter}"
			sleep 60
		else
			break
		fi
	done
	if [[ "${pcount}" -ne 0 ]]; then
			echo "ENgine restart failed. Please check logs for the failed engine"
			#exit 1
	fi

elif [[ $OS_NAME == "SunOS" ]]
then
	serverUser=`who am i|awk '{print $1}'`
	counter=0
	while [[ "${counter}" -le 15 ]]; do
		pcount=0
		for processID in ${pid_list[@]}
		do
			echo "DEBUG: Searching for PID: ${processID}"		
			p_num=$(/usr/ucb/ps -auxww | grep $serverUser | grep ${processID} | grep -v grep | wc -l)
			if [[ "${p_num}" -ne 0 ]]; then 
				echo "DEBUG: Incrementing counter"
				pcount=$((pcount+1))
			fi
		done	
		if [[ "${pcount}" -ne 0 ]]; then
			counter=$((counter+1))
			echo "DEBUG: Counter value is: ${counter}"
			sleep 60
		else
			break
		fi
	done
	if [[ "${pcount}" -ne 0 ]]; then
			echo "Engine restart failed. Please check logs for the failed engine"
			#exit 1
	fi
else
        echo "Sorry, The script currently supports only Linux and Solaris OS."
fi

