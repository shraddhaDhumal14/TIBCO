hosts=$1
hosts=`echo $hosts | xargs`
if [[ -z "${hosts}" ]]; then
	echo "No Ansible host Provided ---> FAILURE"
fi
IFS=' ' read -ra ansible_host_list <<< "${hosts}"
for ansible_host in "${ansible_host_list[@]}"
do
	pingresult=`ansible ${ansible_host} -m ping | grep 'SUCCESS' | wc -l`
	if [ "${pingresult}" -eq "1" ]; then
 		echo "Ansible ping to ${ansible_host}  ---> SUCCESS"
	else
		echo "Ansible ping to ${ansible_host}  ---> FAILURE"
	fi
done
