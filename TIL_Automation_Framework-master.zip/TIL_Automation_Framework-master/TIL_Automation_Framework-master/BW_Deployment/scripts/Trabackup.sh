#!/bin/bash
dt=`date +"%b %d %H:%M"`
host_name=`hostname`
if [ `uname -a | grep Linux|grep "$host_name"|grep -v "vodafone"|wc -l` -eq 1 ]
then
dName=""
envName=""
host=""
host_appdy=""
TRA_HOME=""
AUTO_CONFIG=`pwd`
source ~/.bashrc
chmod 777 .
chmod 777 $1/.
# Making a dir to keep the predeployment TRA backup
if [ ! -d $1/predeploymentbackup ]; then
mkdir $1/predeploymentbackup
fi

echo "present working dir is $AUTO_CONFIG"
     #pwd (/opt/tibco/bw_deployment/CCS22_6_A/bw_EMS_Test_20220720113351/ServiceBus2/Existing_ServiceBus2_1)
###################################################################################################################################################
#
#  Reading The Properties file
#
###################################################################################################################################################
IFS='='
while read f1 f2
do
if [ "$f1" = "Domain" ]
then
dName="$f2"
elif [ "$f1" = "TRA_HOME" ]
then
TRA_HOME="$f2"
fi
done < $AUTO_CONFIG/Deployment.properties

echo "domain name for this is $dName"
###################################################################################################################################################
#
#  Reading The Host file to get hostname
#
###################################################################################################################################################
envName=$2
if [[ "$envName" == "LNKTest14" ]] || [[ "$envName" == "LNKTest15" ]] || [[ "$envName" == "LinkTest" ]] || [[ "$envName" == "LNKTest17" ]] || [[ "$envName" == "NPP" ]] || [[ "$envName" == "TILCPP01" ]] || [[ "$envName" == "SIT" ]] || [[ "$envName" == "TILLT1" ]] || [[ "$envName" == "UnitTest" ]];
then
echo "If condition run successfully"
host=$host_name
host_appdy=$host_name
else
IFS='='
while read f1 f2
do
if [ "$f1" = "$envName" ]
then
temphost="$f2"
fi
done < $AUTO_CONFIG/Hostfile.txt

echo "Host names are $temphost"
IFS=':'
read -a hostarr <<<"$temphost"
host="${hostarr[0]}"
host_appdy="${hostarr[1]}"
fi
echo "host value $host"
echo "host_appdy value $host_appdy"

IFS=' '
TRA_PATH="$(dirname $TRA_HOME)"/domain/$dName/application
POST_PATH=$AUTO_CONFIG/PostDeploymentChanges
CONF_FILE=$POST_PATH/ManualChangesConfiguration.conf
CRQ_CONFIG=$AUTO_CONFIG/$1
BKP_CONFIG=$CRQ_CONFIG/predeploymentbackup
CRQ_NME=$1
usr=tibco

crq_chk=`ls -lrt $AUTO_CONFIG/$1/*.appconf|wc -l`
if [ $crq_chk -gt 0 ]
   then
       echo "Verifying $1 in Deployment Automation Folder..."
                    ls -lrt ${CRQ_CONFIG}/*.appconf |awk '{print $9}' >engine.tmp
                      cat engine.tmp| while read eg1
                          do
                             engine=`echo $eg1|cut -d'.' -f 1`
                             engine=${engine##*/}

##########################
### Backup of TRA Files Logic starts from here ##
##########################
##########################
                             engine1=`grep $engine $CONF_FILE| head -1 |awk -F'|' '{print $1}'`
                                                         echo "engine  value is $engine"
                             echo "${host_appdy//,/$'\n'}" > usr1.tmp
                             e1=`echo $engine1|grep -v '^$'|wc -l`
                             if [ $e1 -eq 0 ] ; then cat usr1.tmp| while read ur1; do ssh $usr@$ur1 "ls -lrt $TRA_PATH" | awk '{print $9}' > engineapp_$ur1.tmp; done; engine1=`grep $engine engineapp_*.tmp| head -1 |cut -d : -f2`; fi
                                                         echo "engine  value is $engine1"
                             # eng_val=`grep $engine $CRQ_CONFIG/bw/AppManage.batch |grep -v '^$' |wc -l`
                             echo "grep $engine $CRQ_CONFIG/bw/AppManage.batch" > outtest.tmp
                             ls -l $CRQ_CONFIG/bw/ >> outtest.tmp
                             echo "engine  value is $engine engine one value is $engine1 engine count value is $eng_val" >> outtest.tmp
                                    for ht in $host
                                      do
                                         echo "$engine tra backup started for $ht"
                                         if [ `ls -lrt $BKP_CONFIG/*$engine*|grep tra|wc -l` -gt 0 ]
                                            then
                                                  echo "Backup is not required as already been taken" > test.tmp
                                         else
                                                scp tibco@$ht:$TRA_PATH/$engine1/$engine*.tra $BKP_CONFIG
                                                ls -lrt $BKP_CONFIG/$engine*.tra |awk '{print $9}'|awk -F'/' '{print $NF}' > move.tmp
                                                cat move.tmp | while read line; do mv $BKP_CONFIG/$line $BKP_CONFIG/"$ht"_$line;done
                                                echo "$engine tra files backup successfully completed under $BKP_CONFIG for $ht"
                                         fi
                                      done

### BackUp Logic END ###
done

else
echo " Please Enter the valid CRQ Number!! . Make sure you are entering the CRQ Number available under $AUTO_CONFIG "
fi
fi
