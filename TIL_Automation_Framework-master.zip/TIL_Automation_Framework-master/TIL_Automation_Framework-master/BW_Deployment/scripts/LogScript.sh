#!/bin/bash

#This function checks for the file created exists and its not empty
#The function will return False if any of the above conditions are satisfied
#function_CheckFilevalid "$timestamp" "$loglocation" "$logfile" "$Engine_name"
#Checks for any of the search words like start/terminateed/terminating
#If any of the key words are found it will retun True
#If no keyswords are found the function will wait for 30 seconds and call function_Extractsnippetfile to regenerate the file
#It is assumed after the first wait the above condition will be satisfied and key words are found
hme_path=`pwd`
host_name=`hostname`
function_CheckFilevalid ()
{
 timestamp="$1"
 loglocation="$2"
 logfile="$3"
 Engine_name="$4"
        if [ -f "$Engine_name.log" ]
        then
          if [ -s "$Engine_name.log" ]
          then
            #echo The Log Snippet created for $Engine_name is not empty
                snippetfile=$Engine_name.log
                echo Snippet File Name:$snippetfile
                fileexist="T"
          else
          #      echo "$Engine_name.log created but its empty"
           #     echo "Since created Log Snippet is empty skipping further checking of logs..."
                fileexist="F"
          fi
        else
          echo "$Engine_name.log Snippet is not created"
        fi
}
#This function will search for the keywors from the text file
#This will return True if any one of the key word matches
#Search for Keywords from file
#$1 will be the location of the file to be searched
#$2 will be True if Started key word is found in previous search
#The Function will return True if any one of the keywords are found and False if nothing is found
function_SearchErrorKeyWords ()
{
 #       rm -rf ./temp/KeywordsCopy.txt
#        cp ./temp/Keywords.txt ./temp/KeywordsCopy.txt
#       count=0
 #                       while read error_line
 #                       do
 #                               keyword_name=$error_line
#$(awk '/./{line=$0} END{print line}' ./temp/KeywordsCopy.txt)
                          #      echo "Searching for keyword: $keyword_name"
  #                              sed -i '$d' ./temp/KeywordsCopy.txt  #Deletes last line of the file
  #                              keyword_found="$(grep -r -oh -m 1 "$keyword_name" $3/logs/$1 | tail -n 10)"
   #                                     if [ "$keyword_found" = "$keyword_name" ]
    #                                    then
     #                                           Matchkeyword=$(grep -n "$keyword_name" $3/logs/$1 | cut -f1 -d: | tail -1)
      #                                          keyword="T"
                                                # print the search result individually into a file inside CR12345
                                              #  echo "Match found for $keyword_name in line $Matchkeyword"
#                                               if [ $count = 0 ];
#                                               then
#                                                       echo "Instance Name:::::::"$1 >> $3/logs/$3_Errors_List.txt


#                                               fi
#                                               grep "$keyword_name" $3/logs/$1 >> $3/logs/$3_Errors_List.txt
                                        #       count=count+1
                         #                       break
                                       # else
                                       #         keyword="F"
                                        #        echo "No match found for $keyword_name"
                                     #   fi
                      #  done < MasterConfiguration/Known_Errors.txt
#if [ "$keyword" = "T" ]
#then
#echo "###################################################################################################################################################################################" >>  $3/logs/$3_Errors_List.txt
#fi
keyword="F"
excl_string=""
echo $3/logs/$1
echo "Below are the errors in the log file:::"$1  >> $3/logs/$3_Errors_List.txt
echo ""  >> $3/logs/$3_Errors_List.txt

start_token_A=""
start_token_B="terminating"
end_token_A="\-SB\-"
end_token_B="TIL Audit started successfully\."

nooflines=`wc -l < $3/logs/$1`
start_lineno=`grep -n "${start_token_A}.*${start_token_B}" $3/logs/$1 | head -1  | cut -f1 -d:`
if [[ -z "${start_lineno}" ]]; then
    start_lineno=1
    echo "DEBUG: Start Token not found. Setting to starting line of file"
fi
end_lineno=`sed -n "${start_lineno},${nooflines}p" $3/logs/$1 | grep -n "${end_token_A}.*${end_token_B}" | head -1  | cut -f1 -d:`
if [[ -z "${end_lineno}" ]]; then
    end_lineno=`wc -l < $3/logs/$1`
    echo "DEBUG: End Token not found. Setting to endding line of file"
else
    end_lineno=$((start_lineno+end_lineno-1))
fi
echo "DEBUG: ${start_token_A}*${start_token_B} is @ Line no ${start_lineno} and ${end_token_A}*${end_token_B} is @ Line no ${end_lineno}"
echo "=========================================Start of Error checking in Log================================="

sed -n "${start_lineno},${end_lineno}p" $3/logs/$1 | while read log_line
#while read log_line
do
echo $log_line 
        while read error_line
        do
                if [[ $log_line == *$error_line* ]]

                then
                        excl_flag="F"
                        while read excl_line
                        do
                                if [[ $log_line == *$excl_line* ]]
                                then
				echo "DEBUG: Picked error line from exclusion file is: ${excl_line}"
				echo "DEBUG: Picked log line from log file is: ${log_line}"
                                excl_flag="T"
                        #       if [[ $keyword == "F" ]]
                        #       then
                        #                echo "Below are the errors in the log file:::"$1  >> $3/logs/$3_Errors_List.txt
                        #       fi
                        #       echo $log_line >> $3/logs/$3_Errors_List.txt
                        #       keyword="T"
                                fi
			done <<< "$(cat MasterConfiguration/Known_Errors_exclusion.txt | egrep -v '^$' | egrep -v "^#" | sed 's/^ //')"
                  if [[ $excl_flag == "F" ]]
                  then
                        #echo "Below are the errors in the log file:::"$1  >> $3/logs/$3_Errors_List.txt
						echo "${log_line}" >> $3/logs/$3_Errors_List.txt
                        keyword="T"
                  fi
                        #       echo $log_line >> $3/logs/$3_Errors_List.txt
                        #       keyword="T"

                fi
        done < MasterConfiguration/Known_Errors.txt
#done < $3/logs/$1
done
echo "=========================================End of Error checking in Log================================="
if [ $keyword == "T" ]
then
echo "====================================================================================================================================================================" >> $3/logs/$3_Errors_List.txt
fi
}
#This function will search for the keywors from the text file
#Search for terminated or terminating Keywords from file
#If any one matches will copy the temp folder file to Scripts folder
function_SearchforFailures ()
{
   #     rm -rf ./temp/FailuresCopy.txt
    #    cp ./temp/Failures.txt ./temp/FailuresCopy.txt
                        #while [ -s  ./temp/FailuresCopy.txt ]
                        #do
                                failure_name="terminat"
#$(awk '/./{line=$0} END{print line}' ./temp/FailuresCopy.txt)
              #                  echo Searching for keyword: $failure_name
                         #       sed -i '$d' ./temp/FailuresCopy.txt  #Deletes last line of the file
                                keyword_found=`grep "$failure_name" $3/logs/$1 | tail -n 10`
                                if [ "$keyword_found" = "$failure_name" ]
                                then
                                        Matchfail=`grep -n "$failure_name" $3/logs/$1 | cut -f1 -d: | tail -1`
             #                           echo Failure match $Matchfail
                                        Failure="T"
                                        #mkdir "$3"
                                      #  mv $3/temp/$1 "$3"/logs/"$1"
                                    #cp ../temp/$1 "$3"/logs/"$1"
                                       # break
                                else
                                        Failure="F"
               #                         echo "No match found for $failure_name"
                                fi
                        #done <
}
#The below function will Search for engine started keyword in the temp folder file
#If it matches will copy the temp folder file to Scripts folder
function_SearchforStarted ()
{

                search_condition="Engine $2 started"

                #echo $search_condition"::::::::::::" `grep -qn  "$search_condition" $3/logs/$1`
                if grep -n "$search_condition" $3/logs/$1 ;
                 then
                        Matchstart=`grep -n "$search_condition" $3/logs/$1 | cut -f1 -d: | tail -1`
                #        echo Seraching for keyword :$search_condition
                 #       echo start match $Matchstart
                        started="T"
                        # move temp ../temp/$1 to .././$crnumber/logs/$1
                        #mkdir "$3"
                     #   mv $3/temp/$1 "$3"/logs/"$1"
                  #      echo Match found for : $search_condition
                        #cp ../temp/$1 "$3"/"$1"

                else
                        started="F"
                   #     echo No match found for the keyword: $search_condition
                fi
}
#The below function extracts snippetfile from Logfile in the server
#If matching timestamp is the last line of the file there will be a sleep for 30 seconds. This will be in loop until matching line is not equal to the last line
#If matching timestamp is not found in current file logfile it searches in previous file logfile.1
#It is assumed that the timestamp will match n the previous verion of the file.
function_Extractsnippetfile ()
{
timestamp="$1"
loglocation="$2"
logfile="$3"
echo $loglocation/$logfile
	    if [ "$server" = "${host_name}"  ];
		   then
		      echo "same host"
              MaxLineCount=`cat "$loglocation/$logfile"|wc -l` 
			  echo $MaxLineCount
			  MaxLineCount=`expr $MaxLineCount + 1`
			  echo $MaxLineCount
		      echo $timestamp":::"$loglocation/$logfile
              echo grep -n "$timestamp" "$loglocation/$logfile"
			  sample=`grep -n "$timestamp" "$loglocation/$logfile"`
                          sleep 90;
			  if grep -n "$timestamp" "$loglocation/$logfile"
			  then 
			    while [ 1 -eq 1 ]
		        do
			     #echo ssh -q $server 'grep -n "'$timestamp'" $loglocation/$logfile | cut -f1 -d: | head -1'
                  MaxLineCount=`cat "$loglocation/$logfile"|wc -l`
                  MaxLineCount=`expr $MaxLineCount + 1` 
				  MatchingLine=`grep -n "$timestamp" "$loglocation/$logfile" | cut -f1 -d: | head -1`
				  echo "MaxLines in "$logfile" is :::"$MaxLineCount
                  echo "Matchine Line in "$logfile" is::"$MatchingLine
				  if [ $MatchingLine -eq $MaxLineCount ]
                  then
                    echo "No updates on the log file yet"
                    sleep 30;
                    MaxLineCount=`cat $loglocation/"$logfile"|wc -l`
                    MaxLineCount=`expr $MaxLineCount + 1`
				  else
   #                 echo Starting Line for snippetfile $MatchingLine
                     MatchingLine=$((MatchingLine + 1))
                     echo sed -n "$MatchingLine","$MaxLineCount"p "$loglocation"/"$logfile"
                     echo "$crnumber"
                     echo "$logfile"
                    `sed -n "$MatchingLine","$MaxLineCount"p "$loglocation"/"$logfile" > "$crnumber"/temp/"$logfile"`
                     
		     if egrep "Engine $Engine_name started|Engine $Engine_name terminated|Engine $Engine_name terminating" $crnumber/temp/"$logfile" ;
                        then
				echo "grep -n "Engine $Engine_name terminat" $loglocation/$logfile | cut -f1 -d: |tail -1"
                          terminate_line=`grep -n "Engine $Engine_name terminat" $loglocation/$logfile | tail -1 | cut -d':' -f1 | tr -d ''`
                         echo "Termination Line Number:::"${terminate_line}"::::"$MaxLineCount
                          if [ $terminate_line -eq $MaxLineCount ]
                           then
                                  mv $crnumber/temp/$logfile $crnumber/logs/$logfile
                                  echo "Log file $logfile created"
                                  break
                          elif  egrep "Engine $Engine_name started" $crnumber/temp/"$logfile" ;
                           then
                                mv $crnumber/temp/$logfile $crnumber/logs/$logfile
                                 echo "Log file $logfile created"
                                 break

                          else
                                echo "No Terminate Line Found at the end...waiting for 60 seconds"
                                sleep 60
                          fi

                      else
                          echo "No Start or Terminating string found....waiting for 60 seconds"
                          sleep 60
                      fi 
			       fi
                done
	         else
                MatchingLine=`grep -n "$timestamp" "$loglocation"/"$logfile".1 | cut -f1 -d: | head -1`
                `sed -n "$MatchingLine","$MaxLineCount"p "$loglocation"/"$logfile".1 > $crnumber/temp/$logfile`
                `cat "$loglocation"/"$logfile" >> $crnumber/temp/$logfile`
                echo "went to false statement"
                echo "File created from previous logs"
             fi
             MaxLineCount="$MaxLineCount"
		else
              MaxLineCount=`ssh -q $server "cat $loglocation/$logfile|wc -l"`
			  MaxLineCount=`expr $MaxLineCount + 1`
			  #echo $timestamp":::"$loglocation/$logfile
              echo ssh -q $server 'grep -n "'$timestamp'" '$loglocation/$logfile
              sample=`ssh -q $server 'grep -n "'$timestamp'" '$loglocation/$logfile`
              echo "::::::::::::::::::::::::"$sample
              #echo "Max Lines::"$MaxLineCount
			   sleep 90;
			  if ssh -q $server 'grep -n "'$timestamp'" '$loglocation/$logfile
			  then
			    while [ 1 -eq 1 ]
			    do
				                   #echo ssh -q $server 'grep -n "'$timestamp'" $loglocation/$logfile | cut -f1 -d: | head -1'
                  MaxLineCount=`ssh -q $server "cat $loglocation/$logfile|wc -l"`
                  MaxLineCount=`expr $MaxLineCount + 1`

                  MatchingLine=`ssh -q $server 'grep -n "'$timestamp'" '$loglocation/$logfile' | cut -f1 -d: | head -1'`
                  echo "MaxLines in "$logfile" is :::"$MaxLineCount
                  echo "Matchine Line in "$logfile" is::"$MatchingLine
			      if [ $MatchingLine -eq $MaxLineCount ]
                  then
                     echo "No updates on the log file yet"
                     sleep 30;
                      MaxLineCount=`ssh -q $server "cat $loglocation/$logfile|wc -l"`
                      MaxLineCount=`expr $MaxLineCount + 1`
			       else
   #                 echo Starting Line for snippetfile $MatchingLine
                     MatchingLine=$((MatchingLine + 1)) 
                     echo ssh -q $server "sed -n $MatchingLine,$MaxLineCount"p $loglocation/$logfile
                     `ssh -q $server 'sed -n '$MatchingLine','$MaxLineCount'p '$loglocation/$logfile > $crnumber/temp/$logfile`
                      if egrep "Engine $Engine_name started|Engine $Engine_name terminated|Engine $Engine_name terminating" $crnumber/temp/"$logfile" ;
                       then
                           terminate_line=`ssh -q $server 'grep -n "'Engine $Engine_name terminat'" '$loglocation/$logfile | cut -f1 -d: |tail -1`
                           #       echo "Termination Line Number:::"$terminate_line"::::"$MaxLineCount
                           if [ $terminate_line -eq $MaxLineCount ]
                             then
                                 mv $crnumber/temp/$logfile $crnumber/logs/$logfile
                                  # `ssh -q $server 'sed -n '$MatchingLine','$MaxLineCount'p '$loglocation/$logfile > $crnumber/temp/$logfile`
                                 echo "Log file $logfile created"
                                 break
                            elif  egrep "Engine $Engine_name started" $crnumber/temp/"$logfile" ;
                              then
                                mv $crnumber/temp/$logfile $crnumber/logs/$logfile
                                 # `ssh -q $server 'sed -n '$MatchingLine','$MaxLineCount'p '$loglocation/$logfile > $crnumber/temp/$logfile`
                                 echo "Log file $logfile created"
                                 break

                            else
                                echo "No Terminate Line Found at the end...waiting for 60 seconds"
                                sleep 60
                            fi

                       else
                          echo "No Start or Terminating string found....waiting for 60 seconds"
                          sleep 60
                       fi

                    fi
               done
			 else
                MatchingLine=`ssh -q $server 'grep -n "'$timestamp'" '$loglocation/$logfile.1 | cut -f1 -d: | head -1`
                `ssh -q $server 'sed -n '$MatchingLine','$MaxLineCount'p '$loglocation/$logfile.1 > $crnumber/temp/$logfile`
                `ssh -q $server 'cat '$loglocation/$logfile >> $crnumber/temp/$logfile`
                cp ../temp/"$logfile" "$logfile"
                echo "File created from previous logs"
            fi
           MaxLineCount="$MaxLineCount"
			  
		fi
}
#Function to search key words in the file and validate the contents of the file
function_checksearchwordsexists()
{
Engine_name=$1
MaxLineCount=$2
EndLineCount=$MaxLineCount
logfile=$3
        while [ 1 -eq 1 ]
        do
          if egrep "Engine $Engine_name started|Engine $Engine_name terminated|Engine $Engine_name terminating" $crnumber/temp/"$logfile" ;
            then
                 mv $crnumber/temp/$logfile $crnumber/logs/$logfile
                break
          else
                  echo "File is created but no matching search"
                  echo "Waiting for 30 seconds and append lines to the file"
                  sleep 30;
                  `ssh -q $server 'sed -n '$MatchingLine','$MaxLineCount'p '$loglocation/$logfile.1 > $crnumber/logs/$logfile`
                  EndLineCount=`ssh -q $server 'cat '$loglocation/$logfile' | wc -l'`
                  MaxLineCount=`expr $EndLineCount + 1`
          fi
        done
}
#The below function will search for bit success and failure, Identify the latest entry and decide it's success or failed.
#Input parameters are logfile
#if last success entry is in line number 50 and the last failure entry is in line number 45 function will return "F" stating engine start is success
#if last success entry is in line number 50 and the last failure entry is in line number 55 function will return "T" stating engine start is success
function_IsFailedlatest ()
{
        logfile=$1
        Engine_name=$2
        crnumber=$3
        if grep -n "Engine $Engine_name terminated"/"Engine $Engine_name terminating" "$crnumber/logs/$logfile" ;
        then
                Matchfail=`grep -n "Engine $Engine_name terminated"/"Engine $Engine_name terminating" "$crnumber/logs/$logfile" | cut -f1 -d: | tail -1`
                if $Matchfail
                then
                        Matchfail=0
                fi
        fi
        if grep -n "Engine $Engine_name started" "$crnumber/logs/$logfile" ;
        then
                Matchstart=`grep -n "Engine $Engine_name started" "$crnumber/logs/$logfile" | cut -f1 -d: | tail -1`
        fi
        if [ $Matchfail -gt $Matchstart ]
        then
                FailLatest="T"
        fi
}
#Main script
#Input parameters
logpath=$1
server=$2
timestamp="$3"
crnumber="$4"
#loglocation=`echo $logpath|cut -f-8 -d '/'`
loglocation=${logpath%/*} 
echo $loglocation
logfile=${logpath##*/}
#logfile=`echo $logpath|cut -f9 -d'/'`
echo "Logfile =$logfile"
#Engine_name=${logfile%.*}
Engine_name=`echo $logfile|cut -f-1 -d '.'`
echo $Engine_name
mkdir -p "$crnumber/logs"
mkdir -p "$crnumber/temp"
#rm $hme_path/$crnumber/logs/$logfile
function_Extractsnippetfile "$timestamp" "$loglocation" "$logfile"

#  function_checksearchwordsexists "$Engine_name" "$MaxLineCount" "$logfile"
   function_SearchforFailures "$logfile" "$Engine_name" "$crnumber"
      #  echo "Match failure status $Failure"
        function_SearchforStarted "$logfile" "$Engine_name" "$crnumber"
     #           echo "Match started status $started"


#                if [ "$started" = "T" ] && [ "$Failure" = "T" ]
 #               then
    #               function_IsFailedlatest "$logfile" "$Engine_name" "$crnumber"
     #              echo "Match isfailed status $FailLatest"
                        if [ "$FailLatest" = "T" ] || [ "$Failure" = "T" ]
                        then
                                status="2"
                                echo "Engine status is $status"
                        fi
     #           elif [ "$started" = "T" ]
      #            then
                         function_SearchErrorKeyWords "$logfile"  "$Engine_name" "$crnumber"
                        if [ "$started" = "T" ]
                        then
    #                     echo "keyword status $keyword"
                                if [ "$keyword" = "T" ]
                                   then
                                         status="1"
                                         echo "Engine status is $status"
                                        else
                                          status="0"
                                          echo "Engine status is $status"
                                fi
                 fi
# return $status
echo $status >> $crnumber/logs/$logfile
