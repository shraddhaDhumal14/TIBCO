#!/bin/bash
##############################################################################################################
#    This script will restart given application's instance one after other.
#    Arguments for this script will be below
#          1. Application Name
#          2. Service Name (par Name)
#          3. Listof all Instance names for the application seperated by ","
#          4. Repo Instance Name of the application
#          5. CRQ#
#          6. TRA_HOME
#          7. Domain Name
#          8. Domain User
#          9. Domain password
################################################################################################################################
DATE=$(date +%Y%m%d)
UTIL_HOME=`pwd`
host_name=`hostname`
LOGS_DIR=$UTIL_HOME/$5/logs
LOG_FILE="${LOGS_DIR}/log_error..log1.${DATE}"
lOG_FILE1="${LOGS_DIR}/log_error.log.${DATE}"

function log_message
{
   echo "`date`: INFO - $1"
}

[ ! -d $LOGS_DIR ] && mkdir -p  $LOGS_DIR

touch ${LOG_FILE}
if [[ $? -ne 0 ]] ; then
        echo "ERROR: Unable to create logfile ${LOG_FILE}.. Aborting"
        exit 1
fi
exec >>${LOG_FILE} 2>&1

log_message "INFO: *** RestartApp script execution Starting ***"

TRA_HOME=$6
user=$8
password=$9
serverUser=`who am i|awk '{print $1}'`
#echo "ServerUserName:::"$serverUser
#serverPw=t1bb1n
domain=$7
#echo $domain"::::::"$6
LOG_HOME="$(dirname $TRA_HOME)"/domain/$domain/application/logs
#echo "LOG Home :::::::::::::::::::::::::::"$LOG_HOME
wait_time=30
#echo $1"     "$2"       "$3
app=$1
par=$2
repoName=$4
OS_NAME=`uname -s`
instancelist=$3
#echo $3
SUMMARY_FILE=$5/logs/$5_restart_summary.txt
RESTART_LOG_FILE=$5/logs/$5_Restart.log
#echo "Restart Summary File::::"${RESTART_LOG_FILE}
summary=$app
IFS=", "
read -r -a instances <<< $instancelist
#echo "Print"${instances[@]}
for i in ${instances[@]}
do
     #   echo $i
        summary=$app"|"$i
        server=${i##*@}
        instanceName=${i%%@*}
        appName=${app##*/}
        echo "Instace Name::::" $instanceName"          Server Name:::"$server"                    Repo Instance Name::::::"$repoName


if [[ ! ${instanceName:0:1} == "#" ]]; then 
	log_message "INFO: *** Getting PID for the existing BW process ***"

	##############################Getting PID for the existing BW Process###################################
     if [[ $OS_NAME == "Linux" ]]; then 
		if [ "$server" = "${host_name}"  ]; then 
			echo "same host"
			echo "Getting process id for existing process on Linux OS"
			echo "ps -ef|grep $repoName/$repoName-$instanceName.tra|grep -v grep|awk '{print $2}'"
			pid=`ps -ef | grep -e "$repoName/$repoName-$instanceName.tra" | grep "${domain}" | grep -v grep | awk '{print $2}'` #>> ${RESTART_LOG_FILE}
			echo "PID for "$repoName/$repoName-$instanceName.tra" is : "$pid 
		else
			echo "Getting process id for existing process on Linux OS"
			pid=`ssh -q "$server" ps -ef|grep "$repoName/$repoName-$instanceName.tra"|grep "${domain}" |grep -v grep|awk '{print $2}'` #>> ${RESTART_LOG_FILE}
			echo "PID for "$repoName/$repoName-$instanceName.tra" is : "$pid
		fi
     elif [[ $OS_NAME == "SunOS" ]]; then 
		echo "Getting process id for existing process on Solaris"
		pid=`exec ssh -q $server "/usr/ucb/ps -auwwx|grep $serverUser|grep $repoName/$repoName-$instanceName.tra|grep "${domain}"|grep -v grep"|awk '{print $2}'`>> ${RESTART_LOG_FILE}
		echo "PID for "$repoName/$repoName-$instanceName.tra" is : "$pid
     else
        echo "Sorry, The script currently supports only Linux and Solaris OS."
     fi
	 
	 
	#summary=$summary"|"$pid
	#echo `ssh $server ps -p $pid|grep -v grep`
	#echo  `ssh $server ps -p $pid|grep -v grep|wc -l`

	###################################Stopping the Instance##################################

	log_message "INFO: *** RestartApp script is stopping the Instance ***"
	if [[ ! -z "${pid}" ]]; then 
		now=`date "+%d-%b-%Y %H:%M:%S"`
		#echo $now"   Initiating Shutdown the instance " $appName/$appName-$instanceName >> ${SUMMARY_FILE}
		${TRA_HOME}/bin/AppManage --propFile ${TRA_HOME}/bin/AppManage.tra -stop -app $app -service $par -binding $instanceName -user $user -pw $password -domain $domain >> ${RESTART_LOG_FILE}
		summary=$summary"|"$now"|"$pid
		###################################checking if Previous process is still running################################
		pcount=0
		while [[ $pcount > 1 ]]
		do
			now=`date "+%d-%m-%Y %H:%M:%S"`
			echo $now"   process with PID "$pid" for "$appName/$appName-$instanceName.tra" is still running"
			#echo `ssh -q $server "ps -p $pid|grep $user|grep -v grep|wc -l"`
			if [[ $OS_NAME == "Linux" ]]; then 
				sleep $wait_time"s" 
				pcount=`ssh -q $server "ps -p $pid|grep -v grep|wc -l"`
			elif [[ $OS_NAME == "SunOS" ]]; then 
				sleep $wait_time 
				pcount=`exec ssh -q $server "/usr/ucb/ps $pid|wc -l"`
			else
				echo "Sorry, The script currently supports only Linux and Solaris OS."
			fi
		done
	else 
		echo "CICD-DEBUG: There is no process existing to stop."
	fi

	now=`date "+%d-%b-%Y %H:%M:%S"`
	#echo $now"   Shutdown of instance "$appName/$appName-$instanceName.tra" Completed successfully....." >> ${SUMMARY_FILE}
	summary=$summary"|"$now
		##################################Starting the Instnce##########################################################

	log_message "INFO: *** RestartApp script starting the instance ***"

	now=`date "+%d-%b-%Y %H:%M:%S"`
	#echo $now"   Starting the instance "$appName/$appName-$instanceName >> ${SUMMARY_FILE}
	${TRA_HOME}/bin/AppManage --propFile ${TRA_HOME}/bin/AppManage.tra -start -app $app -service $par -binding $instanceName -user $user -pw $password -domain $domain >> ${RESTART_LOG_FILE}
	#summary=$summary"|"$now
	#start_time=`date "+%Y %b %d %H:%M"`
	#start_time=$(tail -1 "$LOG_HOME/$repoName-$instanceName.log" | cut -d ':' -f 1-2)

	if [ "$server" = "${host_name}"  ]; then
		start_time=$(tail -1 "$LOG_HOME/$repoName-$instanceName.log" | cut -d ':' -f 1-2)
	else
		start_time=$(ssh -q $server "tail -1 $LOG_HOME/$repoName-$instanceName.log | cut -d ':' -f 1-2")
	fi
 

####################################Checking if the restart of the instance is complete###################################

	if [[ $OS_NAME == "Linux" ]]; then 
		if [ "$server" = "${host_name}"  ]; then 
			echo "same host"
			echo "Getting process id for existing process on Linux OS"
			start_pid=`ps -ef|grep "$repoName/$repoName-$instanceName.tra"|grep "${domain}" |grep -v grep|awk '{print $2}'`  
			echo "Starting status PID for $repoName/$repoName-$instanceName.tra is : ${start_pid}"
		else
			echo "different host"
			echo "Getting process id for existing process on Linux OS"
			start_pid=`ssh -q $server "ps -ef|grep $repoName/$repoName-$instanceName.tra|grep "${domain}" |grep -v grep"|awk '{print $2}'`
			echo "Starting status PID for $repoName/$repoName-$instanceName.tra is : ${start_pid}"
		fi
		log_message "INFO: *** RestartApp script check if the restart of the instance is complete or not***"
	elif [[ $OS_NAME == "SunOS" ]]; then 
		echo "Getting process id for existing process on Solaris"
		start_pid=`exec ssh -q $server "/usr/ucb/ps -auwwx|grep $serverUser|grep $repoName/$repoName-$instanceName.tra|grep "${domain}"|grep -v grep"|awk '{print $2}'`
		echo "PID for $repoName/$repoName-$instanceName.tra is : ${start_pid}"
	else
		echo "Sorry, The script currently supports only Linux and Solaris OS."
	fi

	now=`date "+%d-%b-%Y %H:%M:%S"`
	#summary=$summary"|"$pid"|"$now

	log_message "INFO: *** RestartApp script executing log verification script ***"

	if [[ ! -z "${start_pid}" ]]; then 
		#####################################Executing Log Verification script here####################################################
		echo "./LogScript.sh $LOG_HOME/$repoName-$instanceName.log $server $start_time $5 "
		`./LogScript.sh $LOG_HOME/$repoName-$instanceName.log $server "$start_time" $5 >> ${RESTART_LOG_FILE}`
		log_status_check=`tail -1 $5/logs/$repoName-$instanceName.log`
		echo "logstats check : $log_status_check"
		#echo "Log statu for :"$5/log/$repoName-$instanceName".log for timestamp::::::"$start_time" is :::::"$log_status_check

		log_message "INFO: *** RestartApp script executing log verification script Completed ***"

		#########################Checking if log verification status is success############################################################## 
	else
		echo "CICD-DEBUG: Failed to get process ID for $repoName/$repoName-$instanceName.tra starting"
		log_status_check=2
	fi


	if [[ "$log_status_check" == "0" ]]; then 
			now=`date "+%d-%b-%Y %H:%M:%S"`
			start_time=`grep "Engine "$repoName"-"$instanceName" started" $5/logs/$repoName-$instanceName.log|cut -f-4 -d' '|awk '{print $3"-"$2"-"$1" "$4}'`
	#       start_time="date -d "$start_time" +%d-%m-%Y %H:%M:%S"
			echo Start Time for $repoName-$instanceName.log is $start_time
	#        summary=$summary"|"$pid"|"$start_time"|Started with No Errors|"$now
	#        summary=$app"|"$pid"|"$start_time"|Started with No Errors|"$now
			 summary=$app"|"$i"|Started with No Errors"   
			`echo $summary >> ${SUMMARY_FILE}`
	elif [[ "$log_status_check" == "1" ]]; then 
			now=`date "+%d-%b-%Y %H:%M:%S"`
			start_time=`grep "Engine "$repoName"-"$instanceName" started" $5/logs/$repoName-$instanceName.log|cut -f-4 -d' '|awk '{print $3"-"$2"-"$1" "$4}'`
	#       start_time="date -d "$start_time" +%d-%m-%Y %H:%M:%S"

			#summary=$app"|"$pid"|"$start_time"|Started with Errors|"$now
			summary=$app"|"$i"|Started with Errors"
			`echo $summary >> ${SUMMARY_FILE}`
			break
	elif [[ "$log_status_check" == "2" ]]; then 
			now=`date "+%d-%b-%Y %H:%M:%S"`i
			  start_time=`grep "Engine "$repoName"-"$instanceName" started" $5/logs/$repoName-$instanceName.log|cut -f-4 -d' '|awk '{print $3"-"$2"-"$1" "$4}'`
			#summary=$app"|"$pid"|"$start_time"|Failed to start or terminated|"$now
			summary=$app"|"$i"|Failed to start or terminated"
			`echo $summary >> ${SUMMARY_FILE}`
			break
	fi
fi
#`echo $summary >> ${SUMMARY_FILE}`
done
log_message "INFO: Finish script execution"