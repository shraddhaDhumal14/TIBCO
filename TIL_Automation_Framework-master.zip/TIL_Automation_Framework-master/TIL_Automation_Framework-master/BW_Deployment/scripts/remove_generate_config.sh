#!/bin/bash
# Thsi script removes succesfully generated configs from CRQ folder
# Input1: engine names with ; sepaarted. Also when giving the parameter for engine names we need toenclose in ""
# input2: CRQ Number


ENGINE=$1
CRQ=$2
WORK_DIR=`pwd`

# If deployment typeis ESISTING, validate backup.

bw_var="${WORK_DIR}/Failed_engine_artefacts/bw"
backup_var="${WORK_DIR}/Failed_engine_artefacts/backup"


do_backup() {

        # This function is to take backup of failed artefacts depending on the option.
        engine=$1
        crq_num=$2
		mkdir -p ${WORK_DIR}/Failed_engine_artefacts
		mkdir -p ${bw_var}
		mkdir -p ${backup_var}

		[[ -d "${WORK_DIR}/${crq_num}/bw" ]] && mv ${WORK_DIR}/${crq_num}/bw/${engine}*.* "${bw_var}"
		[[ -d "${WORK_DIR}/${crq_num}/backup" ]] && mv ${WORK_DIR}/${crq_num}/backup/${engine}*.* "${backup_var}"
		[[ -f "${WORK_DIR}/${crq_num}/${engine}.appconf" ]] && mv ${WORK_DIR}/${crq_num}/${engine}.appconf ${WORK_DIR}/Failed_engine_artefacts
		[[ -f "${WORK_DIR}/${crq_num}/${engine}.gvconf" ]] && mv ${WORK_DIR}/${crq_num}/${engine}.gvconf ${WORK_DIR}/Failed_engine_artefacts
		[[ -f "${WORK_DIR}/${crq_num}/${engine}.prconf" ]] && mv ${WORK_DIR}/${crq_num}/${engine}.prconf ${WORK_DIR}/Failed_engine_artefacts

		sed -i "/.*${engine}.*/d" "${WORK_DIR}/${crq_num}/bw/AppManage.batch"
		[[ -d "${WORK_DIR}/${crq_num}/backup" ]] && sed -i "/.*${engine}.*/d" "${WORK_DIR}/${crq_num}/backup/AppManage.batch"
		sed -i "/.*${eng}.*/d" "${WORK_DIR}/${crq_num}/Instance_Details.txt"
}


while read -r eng; do
        echo "engine name is: ${eng}" 
		do_backup "${eng}" "${CRQ}"
done <<< "$(echo "$ENGINE" | tr ';' '\n')"


