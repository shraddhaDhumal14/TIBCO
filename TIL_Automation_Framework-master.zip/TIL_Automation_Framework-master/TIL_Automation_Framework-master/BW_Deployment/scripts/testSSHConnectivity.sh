testuser=$1
hostname=$2
infodisplay=$3
allConnection="true"

IFS=' ' read -ra host_array <<< "${hostname}"
for host in "${host_array[@]}"
do
        ip_address=""
        if [[ "$host" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
               ip_address="$host"
        elif [[ "$host" =~ .*hostname.* || "$host" =~ .*host_name.* ]]; then
               ip_address=$(hostname -i)
        else
               ip_address=`nslookup ${host} | grep 'Address' | sed -n 2p |cut -d ':' -f 2 | xargs`
        fi

        if [ "$ip_address" = "" ]; then
                if [ "$infodisplay" = "true" ]; then
                        echo "$host   not available in network"
                        allConnection="false"
                fi
        else
                #my_ip=`hostname -i`
                #if [ "$ip_address" = "$my_ip" ]; then
                #        if [ "$infodisplay" = "true" ]; then
                #              echo "$host      Same machine"
                #              continue;
                #        fi
                #fi
                if ssh -o BatchMode=yes -o ConnectTimeout=10 $testuser@$ip_address true 2>/dev/null; then
#                if ssh -o BatchMode=yes $testuser@$ip_address true 2>/dev/null; then
                    if [ "$infodisplay" = "true" ]; then
                         echo "${testuser}@${host}    ${ip_address}      Connection          SUCCESS"
                    fi
                else
                    if [ "$infodisplay" = "true" ]; then
                         echo "${testuser}@${host}    ${ip_address}      Connection          FAILURE"
                    else
                      allConnection="false"
                    fi
                fi
        fi
done
if [ "$infodisplay" = "false" ]; then
        echo "${allConnection}"
fi
