#!/bin/bash
###################################################################################################################################################
#
# History
# 23/06/2020:Raghuram:CICD-481: When deploying/undeploying applications via AppManage, Internal error: Subscription context is null occurs.Fixed by adding -serialise
# 08/07/2020: Bhargav Sutapalli: Updating the tibco home path as generic to make sure the automation tool works in all enviornments
#                                 dependency check: .bashrc in tibco BW admin server should be updated with 'export $TIBCO_HOME=<path>'
# option to appmanage command
#
###################################################################################################################################################
IFS="="
dName=""
dusr=""
dPw=""
UTIL_HOME=`pwd`
source ~/.bashrc
CONFIG_HOME=$UTIL_HOME/$2
chmod 777 .
chmod 777 $2/.
if [ ! -d $2/logs ]; then
mkdir $2/logs
fi
if [ ! -d $2/backup ]; then
mkdir $2/backup
fi
backupPath=$UTIL_HOME/$2/backup
bwPath=$UTIL_HOME/$2/bw
TRA_HOME=""
LOG_FILE=$UTIL_HOME/$2/logs/$2_Deployment.log
emailTo=""
DOMAIN_LOG_FILE=""
##################################################################################################################################################
# CICD-1711 Java path condition

if [ -f "$TIBCO_HOME/tibcojre64/1.6.0/bin/java" ]; then
	JavaPath=$TIBCO_HOME/tibcojre64/1.6.0/bin/java
elif [ -f "$TIBCO_HOME/tibcojre64/1.8.0/bin/java" ]; then
	JavaPath=$TIBCO_HOME/tibcojre64/1.8.0/bin/java
else
	echo "ERROR: Java 1.6 & 1.8 Versioins couldnot be found on the server"
fi


###################################################################################################################################################
#
#  Reading The Properties file
#
###################################################################################################################################################
while read f1 f2
do
if [ "$f1" = "Domain" ]
then
dName="$f2"
elif [ "$f1" = "DomainUser" ]
then
dusr="$f2"
elif [ "$f1" = "DomainPwd" ]
then
dPw="$f2"
elif [ "$f1" = "TRA_HOME" ]
then
TRA_HOME="$f2"
elif [ "$f1" = "AutoStart" ]
then
noStart="$f2"
elif [ "$f1" = "emailTo" ]
then
emailTo="$f2"
elif [ "$f1" = "monitorInterval" ]
then
monitorInterval=$f2
fi
done < $UTIL_HOME/Deployment.properties
DOMAIN_LOG_FILE="$(dirname $TRA_HOME)"/domain/$dName/logs/ApplicationManagement.log
#echo $backupPath
#echo $bwPath
#echo "Deployment being attempted into Domain "$dName" using User "$dusr
#echo $dusr
#echo $dPw

##################################################################################################################################################
#
# Function to take backup. This function will read all .appconf under current folder and will create backup of ear file and configuration XML file
# for e3ach application.
#
##################################################################################################################################################
Backup()
{
echo "Invoking Backup function"
echo "################################################################################################################################################" > ${LOG_FILE}
echo "Creating back up for applications..." >> ${LOG_FILE}
files=${CONFIG_HOME}/*.appconf
app=""
line=""
appName=""
folder=""
for file in $files
do
        app=""
                IFS='= '
        #        echo $file
                fold=`grep FolderName $file`

                read -r -a folder <<< $fold

#               echo ${folder[0]}"::::::::::::::"${folder[1]}
                #folder=`echo $folder|cut -d' ' -f 2`
#echo "Folder Name in Appl Conf file:::"${folder[1]}
        while read line
        do
                f=""
flag="True"
#               IFS='= '
        #        echo $file
#               fold=`grep FolderName $file`

#               read -r -a folder <<< $fold

                #folder=`echo $folder|cut -d' ' -f 2`
                f=$f${folder[1]}
#echo $f
                folder2=${folder[1]}
                appName=`echo $file|cut -d'.' -f 1`
                 appName=${appName##*/}
               # folder1=${line%%/*}
                if [[ $line == */* ]]
                then
                appName1=${line##*/}
                folder1=${line%%/*}
                else
                appName1=$line
                folder1=""
                fi
#               echo ":folder:"$folder1":::"${folder[1]}
                appFolder=${folder[1]}
#               echo $appName":AppNAme:"$appName1
                if [[ $appName1 == $appName ]]
                then
# echo ":folder:"$folder1":::"$folder2
                if [[ "$folder1" == "$folder2" ]]
                then
if [[ $folder1 == "" ]]
then
#               echo  $folder2":::folders:::"$folder1
                        app=$appName
                        echo "Inside folder compare failure::"$app
                flag="False"
                        else
                        echo "Line:::"$line
                #       echo ""
#                       if [[ $appName1 == $appName ]]

                        flag="False"
                        app=$line
#                       echo "app::"$app
                        fi
fi
 if [[ $flag == "False" ]]
        then
                echo "Creating backup for the application "$app >> ${LOG_FILE}
                echo "Exporting configuration for "$app
options=" -user ${dusr} -pw ${dPw} -domain ${dName}"
xml=${backupPath}/${appName}.xml
ear=${backupPath}/${appName}.ear
${TRA_HOME}/bin/AppManage --propFile ${TRA_HOME}/bin/AppManage.tra -export -exportDeployed -out ${backupPath}/${appName}.xml -genEar -ear ${backupPath}/${appName}.ear -app $app -user ${dusr} -pw ${dPw} -domain ${dName} >> ${LOG_FILE}
        else
                echo ${folder[1]}/$appName " is a new application. Hence No backup will be created"
        fi

        fi
        done < Applications.txt

#i      if [[ $flag == "False" ]]
#       then
#               echo "Creating backup for the application "$app >> ${LOG_FILE}
#               echo "Exporting configuration for "$app
#options=" -user ${dusr} -pw ${dPw} -domain ${dName}"
#xml=${backupPath}/${appName}.xml
#ear=${backupPath}/${appName}.ear

#               ${TRA_HOME}/bin/AppManage --propFile ${TRA_HOME}/bin/AppManage.tra -export -out ${backupPath}/${appName}.xml -genEar -ear ${backupPath}/${appName}.ear -app $app -user ${dusr} -pw ${dPw} -domain ${dName} >> ${LOG_FILE}
#       else
#               echo ${folder[1]}/$appName " is a new application. Hence No backup will be created"
#       fi
echo `date`>$backupPath/Date.txt
done
}


#####################################################################################################################################################
#
#    Generate the updated Configuration XML files for the applications
#    1.This requires CRQ# as input
#
#####################################################################################################################################################

if [ $1 = "-generate" ]
then
echo "Invoking the Utility to Generate Deployment Configurations..."
echo "####################################################################################################################################################"
echo "Generating the Deployment Configuration..." >> ${LOG_FILE}
Backup
$JavaPath -jar ./DeploymentAutomation.jar -generate $2 >> ${LOG_FILE}
############Exporting SQL tables###################
#echo "Exporting SQL tables to creating backup..."
#if [ ! -d $2/backup/sql ]; then
#mkdir $2/backup/sql
#fi
#$JavaPath -jar ./DeploymentAutomation.jar -exportsql $2
############Exporting and validating EMS Configurations############################
#echo "Validating EMS scripts..."
#if [ ! -d $2/backup/ems ]; then
#mkdir $2/backup/ems
#fi
#./emsDeploy.sh -validate $2 > $UTIL_HOME/$2/logs/$2"_EMSValidation.log"
######################################################################################################################################################
#
#  Deploy Appllications using AppManage batchDeploy option. This includes taking export of ear and configuration xml if the previous backup is older than
#  1 day. After Deployment will update the Applications.txt file with list of new applications deployed as part of the Deployment
#  1. This requires CRQ# as input
#
#####################################################################################################################################################
elif [ $1 = "-deploy" ]
then
emsDeployStatus="false"
SQLDeployStatus="false"
if [ ! -d $2/ems/rollforward ]; then
echo "#####################################################################################################################################################" >> ${LOG_FILE}
echo "Starting EMS Deployment" >> ${LOG_FILE}
emsDeployStatus=`./emsDeploy.sh -deploy $2`
fi
if [[ $emsDeployStatus == "false" ]]
then
echo "Starting SQL Deployment" >> $UTIL_HOME/$2/logs/$2"_SQL.log"
`$JavaPath -jar ./DeploymentAutomation.jar -sql -rollforward $2` >> $UTIL_HOME/$2/logs/$2"_SQL.log"
tempStatus=`tail -1 $UTIL_HOME/$2/logs/$2"_SQL.log"`
IFS='='
read -r -a SQLStatus <<< $tempStatus
SQLDeployStatus=${SQLStatus[1]}
else
echo "SQL deployment cannot continue until EMS deployment is completed successfully"
fi
if [[ $SQLDeployStatus == "true" ]]
then
echo "BW Deployment cannot progress because of errors/failures while SQL deployment. Please check and fix the SQL deployment issues and retry deployment"
echo "Rolling back the EMS scripts as the SQL deployment failed..."
emsDeploStatus=`./emsDeploy.sh -rollback $2`
exit
fi
echo "Starting deployment of Applications using AppManage -batchExport..." >> ${LOG_FILE}
#currDate=`echo date --date='1 days ago'`
currDate=`date`
#echo "Current Date"$currDate
if [[ ! -f ${backupPath}/Date.txt ]]
then
echo ""
else
recDate=`cat ${backupPath}/Date.txt`
fi
if [[ ! -f  ${bwPath}/Date.txt ]]
then
echo ""
else
deployDate=`cat ${bwPath}/Date.txt`
fi
#if [ "`date --date='1 days ago'`" > "`cat ${backupPath}/Date.txt`" ]
if [[ -f $bwPath/AppManage.batch ]]
then
if [[ ( ${date} > ${recDate} ) || ( ${deployDate} == "" ) ]]
then
echo "Taking backup for applications again as the backup seems to be older than a day"
Backup
else
echo "No Backup required as the backup is not older than a day"
fi
echo "Deploying............"
echo "Deploying Application using AppManage -batchDeploy option" >> ${LOG_FILE}
start_time=`cat $DOMAIN_LOG_FILE|wc -l`
#echo "${TRA_HOME}/bin/AppManage --propFile ${TRA_HOME}/bin/AppManage.tra -batchDeploy -user ${dusr} -pw ${dPw} -domain ${dName} -dir ${bwPath} -serialize"
# if [ $noStart == 1 ]
 #       then
  #      ${TRA_HOME}/bin/AppManage --propFile ${TRA_HOME}/bin/AppManage.tra -batchDeploy -user ${dusr} -pw ${dPw} -domain ${dName} -dir ${bwPath} -serialize>> ${LOG_FILE}
#else
 ${TRA_HOME}/bin/AppManage --propFile ${TRA_HOME}/bin/AppManage.tra -batchDeploy -user ${dusr} -pw ${dPw} -domain ${dName} -dir ${bwPath} -nostart -nostop -serialize >> ${LOG_FILE}

fi
#${TRA_HOME}/bin/AppManage --propFile ${TRA_HOME}/bin/AppManage.tra -batchDeploy -user ${dusr} -pw ${dPw} -domain ${dName} -dir ${bwPath} -nostart -nostop -serialize>> ${LOG_FILE}

echo `date` > ${bwPath}/Date.txt
str=""
        while read newline
        do
                str=`grep $newline Applications.txt`
                echo $str
                if [[ $str == "" ]]
                then
                echo $newline >> Applications.txt
                str=""
                fi
        done <  ${backupPath}/NewApplications.txt
echo "" >> Applications.txt
#cat ${backupPath}/NewApplications.txt >> Applications.txt
#echo "Performing Post Deployment Configurations...."
#files=${CONFIG_HOME}/*.appconf
#for file in $files
#do
#engine=`echo $file|cut -d'.' -f 1`
#engine=${engine##*/}

#PostDeploymentChanges/ManualChanges_Automation.sh $2 $UTIL_HOME $TRA_HOME $dName >> ${LOG_FILE}

#done
#fi
./createDeploymentSummary.sh $2 "$start_time" $dName $TRA_HOME
./generateReport.sh $2 $emailTo
#> ${backupPath}/NewApplications.txt
#$TIBCO_HOME/tra/5.7/bin/AppManage -batchDeploy -user "$dusr" -pw "$dPw" -domain "$dName" -dir "$batchConfigPath" -nostop
#echo "Moving Config files into completed folder..."
#mv $deplolymentConfiguration/working/*.appconf $deplolymentConfiguration/completed
#mv $deplolymentConfiguration/working/*.gvconf $deplolymentConfiguration/completed
#mv $deplolymentConfiguration/working/*.prconf $deplolymentConfiguration/completed

######################################################################################################################################################
#
#  Deploy only BW and Adapter Applications using AppManage batchDeploy option. This includes taking export of ear and configuration xml if the previous backup is older than
#  1 day. After Deployment will update the Applications.
# file with list of new applications deployed as part of the Deployment
#  1. This requires CRQ# as input
#
#####################################################################################################################################################
elif [ $1 = "-deployBW" ]
then
echo "Starting deployment of Applications using AppManage -batchExport..." >> ${LOG_FILE}
#currDate=`echo date --date='1 days ago'`
currDate=`date`
#echo "Current Date"$currDate
if [[ ! -f ${backupPath}/Date.txt ]]
then
echo ""
else
recDate=`cat ${backupPath}/Date.txt`
fi
if [[ ! -f  ${bwPath}/Date.txt ]]
then
echo ""
else
deployDate=`cat ${bwPath}/Date.txt`
fi
#if [ "`date --date='1 days ago'`" > "`cat ${backupPath}/Date.txt`" ]
if [[ -f $bwPath/AppManage.batch ]]
then
if [[ ( ${date} > ${recDate} ) || ( ${deployDate} == "" ) ]]
then
echo "Taking backup for applications again as the backup seems to be older than a day"
Backup
else
echo "No Backup required as the backup is not older than a day"
fi
echo "Deploying............"
echo "Deploying Application using AppManage -batchDeploy option" >> ${LOG_FILE}

start_time=`cat $DOMAIN_LOG_FILE|wc -l`
start_time=$((start_time+1))
#echo "${TRA_HOME}/bin/AppManage --propFile ${TRA_HOME}/bin/AppManage.tra -batchDeploy -user ${dusr} -pw ${dPw} -domain ${dName} -dir ${bwPath} -serialize"
 #if [ $noStart == 1 ]
  #      then
 #       ${TRA_HOME}/bin/AppManage --propFile ${TRA_HOME}/bin/AppManage.tra -batchDeploy -user ${dusr} -pw ${dPw} -domain ${dName} -dir ${bwPath} -serialize>> ${LOG_FILE}
#else
 ${TRA_HOME}/bin/AppManage --propFile ${TRA_HOME}/bin/AppManage.tra -batchDeploy -user ${dusr} -pw ${dPw} -domain ${dName} -dir ${bwPath} -nostart -nostop -serialize>> ${LOG_FILE}

fi
#${TRA_HOME}/bin/AppManage --propFile ${TRA_HOME}/bin/AppManage.tra -batchDeploy -user ${dusr} -pw ${dPw} -domain ${dName} -dir ${bwPath} -nostart -nostop -serialize>> ${LOG_FILE}

echo `date` > ${bwPath}/Date.txt
str=""
        while read newline
        do
                str=`grep $newline Applications.txt`
                echo $str
                if [[ $str == "" ]]
                then
                echo $newline >> Applications.txt
                str=""
                fi
        done <  ${backupPath}/NewApplications.txt
echo "" >> Applications.txt

echo "./createDeploymentSummary.sh $2 "$start_time" $dName $TRA_HOME"
./createDeploymentSummary.sh $2 "$start_time" $dName $TRA_HOME

# CICD FIX: Apply post deployment manual changes only when BW deployment is SUCCESS

#if [[ -f $UTIL_HOME/$2/logs/$2_Deployment_summary.txt ]] && [[ `cat $UTIL_HOME/$2/logs/$2_Deployment_summary.txt | cut -d '|' -f 3 | tr -d ' '` == "Success"  ]]; then
	PostDeploymentChanges/ManualChanges_Automation.sh $2 $UTIL_HOME $TRA_HOME $dName $3 >> ${LOG_FILE}
#else 
#	echo "CICD Fix: Post Deployment Manual changes are not done , since deployment status is unknown or failed." 2>&1 >> ${LOG_FILE} 
#fi

#./generateReport.sh $2 $emailTo
######################################################################################################################################################
#
#  Deploy SQL changes only
#
#####################################################################################################################################################
elif [ $1 = "-deploySQL" ]
then

SQLDeployStatus="false"
echo "#####################################################################################################################################################" >> ${LOG_FILE}


echo "Starting SQL Deployment" >> $UTIL_HOME/$2/logs/$2"_SQL.log"
`$JavaPath -jar ./DeploymentAutomation.jar -sql -rollforward $2` >> $UTIL_HOME/$2/logs/$2"_SQL.log"
tempStatus=`tail -1 $UTIL_HOME/$2/logs/$2"_SQL.log"`
IFS='='
read -r -a SQLStatus <<< $tempStatus
SQLDeployStatus=${SQLStatus[1]}
echo "SQL Deployment Status::"$SQLDeployStatus


######################################################################################################################################################
#
#  Deploy Only EMS changes .
#
#####################################################################################################################################################
elif [ $1 = "-deployEMS" ]
then
emsDeployStatus="false"
SQLDeployStatus="false"
echo "#####################################################################################################################################################" >> ${LOG_FILE}
echo "Starting EMS Deployment" >> ${LOG_FILE}
emsDeployStatus=`./emsDeploy.sh -deploy $2`
echo "EMS Deployment Status::"$emsDeployStatus

######################################################################################################################################################
#
#  Deploy SQL changes only
#
#####################################################################################################################################################
elif [ $1 = "-rollbackSQL" ]
then

SQLDeployStatus="false"
echo "#####################################################################################################################################################" >> ${LOG_FILE}


echo "Starting SQL Deployment" >> $UTIL_HOME/$2/logs/$2"_SQL.log"
`$JavaPath -jar ./DeploymentAutomation.jar -sql -rollback $2` >> $UTIL_HOME/$2/logs/$2"_SQL.log"
tempStatus=`tail -1 $UTIL_HOME/$2/logs/$2"_SQL.log"`
IFS='='
read -r -a SQLStatus <<< $tempStatus
SQLDeployStatus=${SQLStatus[1]}
echo "SQL Deployment Status::"$SQLDeployStatus


######################################################################################################################################################
#
#  Deploy Only EMS changes .
#
#####################################################################################################################################################
elif [ $1 = "-rollbackEMS" ]
then
emsDeployStatus="false"
SQLDeployStatus="false"
echo "#####################################################################################################################################################" >> ${LOG_FILE}
echo "Starting EMS Deployment" >> ${LOG_FILE}
emsDeployStatus=`./emsDeploy.sh -rollback $2`
echo "EMS Deployment Status::"$emsDeployStatus

########################################################################################################################################################
#
# Rollback the BW and Adapter changes by deploying the applications with ear and configuration XML from <CRQ#>/backup folder with AppManage -batchDeploy.
# This will also undeploy the new applications created if the applications are created as part of CRQ#. This also supports partial rollback.
# This requires CRQ# as input
#
#########################################################################################################################################################

elif [[ $1 = "-rollbackBW" ]]
then
echo "Starting rollback of changes..."
echo "################################################################################################################################################" >> ${LOG_FILE}

start_time=`cat $DOMAIN_LOG_FILE|wc -l`
start_time=$((start_time+1))
echo "Invoking Rollback scripts to rollback the changes deployed..." >> ${LOG_FILE}

${TRA_HOME}/bin/AppManage --propFile ${TRA_HOME}/bin/AppManage.tra -batchDeploy -user ${dusr} -pw ${dPw} -domain ${dName} -dir ${backupPath} -nostop -nostart -serialize>>  ${LOG_FILE}

while read line
do
        echo "UnDeploying the application "$line >> ${LOG_FILE}
#echo " ${TRA_HOME}/bin/AppManage --propFile ${TRA_HOME}/bin/AppManage.tra -undeploy -app $line -user ${dusr} -pw ${dPw} -domain ${dName}"
        ${TRA_HOME}/bin/AppManage --propFile ${TRA_HOME}/bin/AppManage.tra -undeploy -app $line -user ${dusr} -pw ${dPw} -domain ${dName} -serialize>>  ${LOG_FILE}
done < ${backupPath}/NewApplications.txt
#echo "" > temp.txt
exist="false"
while read line
do
        while read newline
        do
                if [[ $line == $newline ]]
                then
                exist="true"
                #echo $line >> temp.txt
                fi
        done <  ${backupPath}/NewApplications.txt
if [[ $exist == "false" ]]
then
echo $line >> temp.txt
fi
exist="false"
done < Applications.txt
if [[ `cat temp.txt|wc -l` > 1 ]]
then
echo "cleaning Applications.txt...."
mv temp.txt Applications.txt
fi


echo "./createDeploymentSummary.sh $2 "$start_time" $dName $TRA_HOME"
./createDeploymentSummary.sh $2 "$start_time" $dName $TRA_HOME

# CICD FIX: Apply post deployment manual changes only when BW deployment is SUCCESS

#if [[ -f $UTIL_HOME/$2/logs/$2_Deployment_summary.txt ]] && [[ `cat $UTIL_HOME/$2/logs/$2_Deployment_summary.txt | cut -d '|' -f 3 | tr -d ' '` == "Success"  ]]; then
	PostDeploymentChanges/ManualChanges_Automation.sh $2 $UTIL_HOME $TRA_HOME $dName $3 >> ${LOG_FILE}
#else 
#	echo "CICD Fix: Post Deployment Manual changes are not done , since deployment status is unknown or failed." 2>&1 >> ${LOG_FILE} 
#fi

#PostDeploymentChanges/ManualChanges_Automation.sh $2 $UTIL_HOME $TRA_HOME $dName >> ${LOG_FILE}

#done

#./emsDeploy.sh $1 $2 >> ${LOG_FILE}

#echo "Starting rollback for SQL Deployment" >> $UTIL_HOME/logs/$2"_SQL.log"
#$JavaPath -jar ./DeploymentAutomation.jar -sql -rollback $2 >> $UTIL_HOME/logs/$2"_SQL.log"

#######################################################################################################################################################
#
#  Retry Deployment for applications failed in previous attempt.
#  1. if CRQ# and AppName as input, only the application specified will be retried for deployment
#
#######################################################################################################################################################
elif [[ $1 = "-retry" ]]
then
echo "Test#"
######Command to deploy the individual applications to be here

#######################################################################################################################################################
#
#  To Generate Master Configuration file from domain export
#
#######################################################################################################################################################
elif [[ $1 = "-masterconf" ]]
then
$JavaPath -jar ./DeploymentAutomation.jar -masterconf 1 $2 >> MasterFileGeneration.log
elif [[ $1 = "-appmaster" ]]
then

  ${TRA_HOME}/bin/AppManage --propFile ${TRA_HOME}/bin/AppManage.tra -batchExport -user ${dusr} -pw ${dPw} -domain ${dName} -dir ./NewAPP
  if [[ $? -ne 0 ]]; then
     echo
     echo "******* ERROR: The AppMaster export failed with.  Please investigate... *******"
         echo
     exit 1
  fi
  $JavaPath -jar ./DeploymentAutomation.jar -appmaster NewAPP


#$JavaPath -jar ./DeploymentAutomation.jar -appmaster $2

elif [[ $1 = "-restart" ]]
then
echo /restart.sh $2 $TRA_HOME $dName $dusr $dPw
./restart.sh $2 $TRA_HOME $dName $dusr $dPw >> $2/logs/$2_Restart.log
./generateReport.sh $2 $emailTo
elif [[ $1 = "-monitor" ]]
then

./monitor.sh $2 $TRA_HOME $dName $monitorInterval
./generateReport.sh $2 $emailTo
else

echo "invalid argument $1. Expected -deploy or -generate..."
fi
