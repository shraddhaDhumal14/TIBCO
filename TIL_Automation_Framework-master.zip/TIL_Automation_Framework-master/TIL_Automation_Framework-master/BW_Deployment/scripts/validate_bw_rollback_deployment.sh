#!/bin/bash
# Thsi script try to validate bw deployment status from Deployment_summary.txt
# Input1: CRQ Number

# engine names with validation failure will be written to "deployment_failed" file
# engine names with validation success will be written to "deployment_success" file

CRQ=$1
WORK_DIR=`pwd`

if [[ ! -z "$2" ]]; then
	bw_var="${2}/Failed_Engines/Failed_Rollback_engine_artefacts/bw"
	backup_var="${2}/Failed_Engines/Failed_Rollback_engine_artefacts/backup"
	appconf_var="${2}/Failed_Engines/Failed_Rollback_engine_artefacts"
else
	bw_var="${WORK_DIR}/Failed_Rollback_engine_artefacts/bw"
	backup_var="${WORK_DIR}/Failed_Rollback_engine_artefacts/backup"
	appconf_var="${WORK_DIR}/Failed_Rollback_engine_artefacts"
fi

# If deployment typeis ESISTING, validate backup.
>${WORK_DIR}/RB_deploy_success
>${WORK_DIR}/RB_deploy_failed



do_backup() {

        # This function is to take backup of failed artefacts depending on the option.
        engine=$1
        crq_num=$2
		mkdir -p ${WORK_DIR}/Failed_RB_deployment_engine_artefacts/bw
		mkdir -p ${WORK_DIR}/Failed_RB_deployment_engine_artefacts/backup
		
		[[ -d "${WORK_DIR}/${crq_num}/bw" ]] && mv ${WORK_DIR}/${crq_num}/bw/${engine}*.* "${bw_var}"
		[[ -d "${WORK_DIR}/${crq_num}/backup" ]] && mv ${WORK_DIR}/${crq_num}/backup/${engine}*.* "${backup_var}"
		[[ -f "${WORK_DIR}/${crq_num}/${engine}.appconf" ]] && mv ${WORK_DIR}/${crq_num}/${engine}.appconf "${appconf_var}"
		[[ -f "${WORK_DIR}/${crq_num}/${engine}.gvconf" ]] && mv ${WORK_DIR}/${crq_num}/${engine}.gvconf "${appconf_var}"
		[[ -f "${WORK_DIR}/${crq_num}/${engine}.prconf" ]] && mv ${WORK_DIR}/${crq_num}/${engine}.prconf "${appconf_var}"

		sed -i "/.*${engine}.*/d" "${WORK_DIR}/${crq_num}/bw/AppManage.batch"
		[[ -d "${WORK_DIR}/${crq_num}/backup" ]] && sed -i "/.*${engine}.*/d" "${WORK_DIR}/${crq_num}/backup/AppManage.batch"
		[[ -d "${WORK_DIR}/${crq_num}/backup" ]] && sed -i "/.*${engine}.*/d" "${WORK_DIR}/${crq_num}/backup/NewApplications.txt"
		sed -i "/.*${engine}.*/d" "${WORK_DIR}/${crq_num}/Instance_Details.txt"
}


if [[ `ls ${WORK_DIR}/${CRQ}/logs/${CRQ}_Deployment_summary.txt` ]]; then
        cat ${WORK_DIR}/${CRQ}/logs/${CRQ}_Deployment_summary.txt | while read -r line; do
                engine_name=$(echo $line | cut -d '|' -f 1 | tr -d ' ')
                engine_status=$(echo $line | cut -d '|' -f 3 | tr -d ' ')
                echo "${engine_name}: ${engine_status}"

                if [[ "${engine_status}" == "Success" ]]; then
                        echo "INFO: ${engine_name} is successfully deployed."
                        echo "${engine_name}" >> ${WORK_DIR}/RB_deploy_success
                else
                        echo "INFO: ${engine_name} deploymnet failed. Proceeding with backup"
                        do_backup "${engine_name}" "${CRQ}"
                        echo "${engine_name}" >> ${WORK_DIR}/RB_deploy_failed
                fi
        done
else
        echo "ERROR: There is no Deployment summary file exists"
fi

