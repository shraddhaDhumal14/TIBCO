#!/bin/sh
CRQ_NUM=$1
UTIL_HOME=`pwd`
source ~/.bashrc
GVDIFF_BACKUP=""
post_xml_path="${UTIL_HOME}/${CRQ_NUM}/post_deployment_xml"
mkdir -p "${UTIL_HOME}/${CRQ_NUM}/post_deployment_xml"
# CICD-1852 , supporting both java 1.6 nd 1.8
#JAVA_PATH="${TIBCO_HOME}/tibcojre64/1.6.0/bin/java"
 
if [ -f "$TIBCO_HOME/tibcojre64/1.6.0/bin/java" ]; then
	JAVA_PATH=$TIBCO_HOME/tibcojre64/1.6.0/bin/java
elif [ -f "$TIBCO_HOME/tibcojre64/1.8.0/bin/java" ]; then
	JAVA_PATH=$TIBCO_HOME/tibcojre64/1.8.0/bin/java
else
	echo "ERROR: Java 1.6 & 1.8 Versioins couldnot be found on the server"
fi

if [[ ! -z "$2" ]]; then
	GVDIFF_BACKUP="$2/GV_DIFF_SUMMARY"
else
	GVDIFF_BACKUP="${UTIL_HOME}/GV_DIFF_SUMMARY"
fi

if [[ -z "$1" ]]; then
        echo "USAGE: ./gv_diff.sh CRQ_NUM"
        exit 0
fi

# Get deploymnet properties for the domain from Deployment.properties file.
if [[ -f "./Deployment.properties"  ]]; then
	TRA_HOME=$(cat ${UTIL_HOME}/Deployment.properties | grep "TRA_HOME" | cut -d '=' -f 2 | tr -d ' ')
	DomainUser=$(cat ${UTIL_HOME}/Deployment.properties | grep "DomainUser" | cut -d '=' -f 2 | tr -d ' ')
	DomainPwd=$(cat ${UTIL_HOME}/Deployment.properties | grep "DomainPwd" | cut -d '=' -f 2 | tr -d ' ')
	Domain=$(cat ${UTIL_HOME}/Deployment.properties | grep "Domain=" | cut -d '=' -f 2 | tr -d ' ')
else
	echo "Not able to find Deployment.properties file."
	exit
fi

# Generate post deployment XML's for each of the appconf file present in CRQ directory.

ls ${UTIL_HOME}/${CRQ_NUM}/*.appconf | while read -r appconf_file; do
	echo "DEBUG: appconf file is: ${appconf_file}"
	folder_name=$(cat ${appconf_file} | grep -i "FolderName" | cut -d '=' -f 2 | tr -d ' ')
	echo "DEBUG: folder name is: ${folder_name}"
	appconf_file_name=$(basename ${appconf_file} | cut -d '.' -f 1)
	
	#construct command for backup.
	if [[ ! -z ${folder_name} ]]; then 
		backup_cmd="${TRA_HOME}/bin/AppManage --propFile ${TRA_HOME}/bin/AppManage.tra -export -exportDeployed -out ${post_xml_path}/${appconf_file_name}.xml -app ${folder_name}/${appconf_file_name} -user ${DomainUser} -pw ${DomainPwd} -domain ${Domain}"
	else
		backup_cmd="${TRA_HOME}/bin/AppManage --propFile ${TRA_HOME}/bin/AppManage.tra -export -exportDeployed -out ${post_xml_path}/${appconf_file_name}.xml -app ${appconf_file_name} -user ${DomainUser} -pw ${DomainPwd} -domain ${Domain}"
	fi
	echo "DEBUG: backup_cmd is: ${backup_cmd}"
	eval "${backup_cmd}" >/dev/null 2>&1
done 

table_header(){
		engine=$1
		old_version=$2
		new_version=$3
        echo "<style type="text/css">"
        echo ".tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;} "
        echo ".tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;width:150px;word-break:break-all;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}"
        echo ".tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:break-all;border-color:#9ABAD9;color:#fff;background-color:#409cff;}"
        echo ".tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}"
        echo ".tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}"
        echo ".tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}"
        echo ".tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}"
        echo ".tg .tg-0lax{text-align:left;vertical-align:top}"
        echo ".tg .tg-PASSED{background-color:lightgreen;text-align:left;vertical-align:top}"
        echo ".tg .tg-FAILED{background-color:red;text-align:left;vertical-align:top}"
        echo ".tg .tg-NOT_STARTED{background-color:lightgrey;text-align:left;vertical-align:top}"
        echo ".tg .tg-NOT_REQUIRED{background-color:#E1E0A2;text-align:left;vertical-align:top}"
        echo "</style>"
        echo "<table class=\"tg\" style=\"undefined; width: 100%\">"
        echo "<colgroup>"
        echo "<col style=\"width: 90px\">"
        echo "<col style=\"width: 90px\">"
        echo "<col style=\"width: 90px\">"
        echo "<col style=\"width: 90px\">"
        echo "</colgroup>"
        echo "<tr>"
        echo "<th class=\"tg-amwm\" colspan=\"5\">${engine} GV DIFF REPORT</th>"
        echo "</tr>"
        echo "<tr>"
        echo "<td class=\"tg-1wig\" colspan=\"1\">ENGINE_NAME</td>"
        echo "<td class=\"tg-0lax\" colspan=\"1\">${engine}</td> "
        echo "<td class=\"tg-1wig\" colspan=\"1\">Date</td>"
        echo "<td class=\"tg-0lax\" colspan=\"2\">$(date)</td> "
        echo "</tr>"
        echo "<tr>"
        echo "<td class=\"tg-1wig\" colspan=\"1\">OLD_GV_VERSION</td>"
        echo "<td class=\"tg-0lax\" colspan=\"1\">${old_version}</td> "
        echo "<td class=\"tg-1wig\" colspan=\"1\">NEW_GV_VERSION</td>"
        echo "<td class=\"tg-0lax\" colspan=\"2\">${new_version}</td> "
        echo "</tr>"		
        echo "</table>"
}
sub_table_gv_diff_header(){
        Type=$1
        echo "<br><br><br>"
        echo "<table class=\"tg\" style=\"undefined; width: 100%\">"
        echo "<colgroup>"
                echo "<col style=\"width: 20%\">"
                echo "<col style=\"width: 20%\">"
                echo "<col style=\"width: 20%\">"
                echo "<col style=\"width: 20%\">"
                echo "<col style=\"width: 20%\">"
        echo "</colgroup>"
        echo "<tr>"
        echo "<th class=\"tg-amwm\" colspan=\"5\">${Type}</th>"
        echo "</tr>"
        echo "<tr>"
        echo "<td style=\"color:333300\" class=\"tg-amwm\" colspan=\"1\">GV NAME</td>"
        echo "<td style=\"color:333300\" class=\"tg-amwm\" colspan=\"1\">OLD GV VALUE</td> "
        echo "<td style=\"color:333300\" class=\"tg-amwm\" colspan=\"3\">CURRENT GV VALUE</td>"
        echo "</tr>"
}

sub_table_header(){
        Type=$1
        echo "<br><br><br>"
        echo "<table class=\"tg\" style=\"undefined; width: 100%\">"
        echo "<colgroup>"
                echo "<col style=\"width: 20%\">"
                echo "<col style=\"width: 20%\">"
                echo "<col style=\"width: 20%\">"
                echo "<col style=\"width: 20%\">"
                echo "<col style=\"width: 20%\">"
        echo "</colgroup>"
        echo "<tr>"
        echo "<th class=\"tg-amwm\" colspan=\"5\">${Type}</th>"
        echo "</tr>"
        echo "<tr>"
        echo "<td style=\"color:333300\" class=\"tg-amwm\" colspan=\"1\">GV NAME</td>"
        echo "<td style=\"color:333300\" class=\"tg-amwm\" colspan=\"4\">GV VALUE</td> "
        echo "</tr>"
}

sub_table_footer(){
        echo "</table>"
}

decrypt_passwords() {

	# This function is to decrypt paswords in the XML given.
	#Input1: XML file
	#Input 2: Outputfile

	decrypt_input_file=$1
	decrypt_output_file=$2
	if [[ -f ./DecryptGV.jar ]]; then 
		"${JAVA_PATH}" -jar ./DecryptGV.jar "${decrypt_input_file}"
                mv $(dirname "${decrypt_input_file}")/${engine_name}_Decrypt.xml "${decrypt_output_file}"
 ### Workaorund of Fixing the Empty Value tag issue after the decrypt jar file execution
                sed -i 's|<\(.*\)\/>|<\1><\/\1>|g' "${decrypt_output_file}"
	else
		echo "ERROR: There is no DecryptGV.jar file in the present path"
		exit 1
	fi
        
}


format_xml_file(){
        passed_xml_file=$1
        output_file=$2

        cmd="cat ${passed_xml_file} | sed -ne '/NVPairs name=\\\"Global Variables\\\"/,\$p' | sed -ne '1,/<\/NVPairs>/p' | grep \"<NameValuePair>\" -A 2 | grep -v \"<NameValuePair>\" | grep -v \"\-\-\" | paste -d \" \"  - - | sed -e 's/<\/name>\(.*\)<value>/=/' | sed -e 's/<name>\(.*\)<\/value>/\1/' | sed -e 's/^[ \t]*//'"
        eval ${cmd} >"${output_file}"

        cmd="cat ${passed_xml_file} | sed -ne '/NVPairs name=\\\"Global Variables\\\"/,\$p' | sed -ne '1,/<\/NVPairs>/p' | grep \"<NameValuePairBoolean>\" -A 2 | grep -v \"<NameValuePairBoolean>\" | grep -v \"\-\-\" | paste -d \" \"  - - | sed -e 's/<\/name>\(.*\)<value>/=/' | sed -e 's/<name>\(.*\)<\/value>/\1/' | sed -e 's/^[ \t]*//'"
        eval ${cmd} >>"${output_file}"

        cmd="cat ${passed_xml_file} | sed -ne '/NVPairs name=\\\"Global Variables\\\"/,\$p' | sed -ne '1,/<\/NVPairs>/p' | grep \"<NameValuePairInteger>\" -A 2 | grep -v \"<NameValuePairInteger>\" | grep -v \"\-\-\" | paste -d \" \"  - - | sed -e 's/<\/name>\(.*\)<value>/=/' | sed -e 's/<name>\(.*\)<\/value>/\1/' | sed -e 's/^[ \t]*//'"
        eval ${cmd} >>"${output_file}"

        cmd="cat ${passed_xml_file} | sed -ne '/NVPairs name=\\\"Global Variables\\\"/,\$p' | sed -ne '1,/<\/NVPairs>/p' | grep \"<NameValuePairPassword>\" -A 2 | grep -v \"<NameValuePairPassword>\" | grep -v \"\-\-\" | paste -d \" \"  - - | sed -e 's/<\/name>\(.*\)<value>/=/' | sed -e 's/<name>\(.*\)<\/value>/\1/' | sed -e 's/^[ \t]*//'"
        eval ${cmd} >>"${output_file}"
}


ls ${UTIL_HOME}/${CRQ_NUM}/*.appconf | while read -r appconf_file; do
	engine_name=$(basename ${appconf_file} | cut -d '.' -f 1)
	unset old_xml
	unset new_xml
	unset old_xml_version
	unset new_xml_version
	old_xml="${UTIL_HOME}/${CRQ_NUM}/backup/${engine_name}.xml"
	new_xml="${post_xml_path}/${engine_name}.xml"

	old_xml_version=$(grep -i "<description>" ${old_xml} | cut -d '>' -f 2 | cut -d '|' -f 1-3)
	new_xml_version=$(grep -i "<description>" ${new_xml} | cut -d '>' -f 2 | cut -d '|' -f 1-3)




	# Call function to get formatted output for Old XML.
	if [[ -f "${old_xml}" ]] && [[ $(cat "${old_xml}" | wc -l) -gt 10 ]]; then
			# First decrypt passwords in XML file 
			decrypt_passwords "${old_xml}" "${engine_name}_old_decrypt.xml"
			format_xml_file "${engine_name}_old_decrypt.xml" "${engine_name}_old_formatted.out"
	else
			echo "DEBUG: There is no BACKUP XML or less no of lines in XML  in backup directory. Not proceeding for GV DIFF"
			break
	fi

	# Call function to get formatted output for new XML.
	if [[ -f "${new_xml}" ]] && [[ $(cat "${new_xml}" | wc -l) -gt 10 ]]; then
			# First decrypt passwords in XML file
			decrypt_passwords "${new_xml}" "${engine_name}_new_decrypt.xml"
			format_xml_file "${engine_name}_new_decrypt.xml" "${engine_name}_new_formatted.out"
	else
			echo "DEBUG: There is no latest XML or less no of lines in XML in post_xml Folder. Not proceeding for GV DIFF"
			break
	fi

	# Empty all the output files.
	>changed_gv_value
	>added_gv_to_new_xml
	>removed_gv_from_new_xml

	# get GV diff for all the GV's present in new XML file.
	if [[ -f "${engine_name}_old_formatted.out" ]] && [[ -f "${engine_name}_new_formatted.out" ]] ; then 
			while read -r line; do
							line=$(echo ${line} | sed $'s/\r//')
					if [[ ! -z "${line}" ]];then
							key=$(echo ${line} | cut -d '=' -f 1)
											value=$(echo ${line} | cut -d '=' -f 2- | sed -e 's/[[:space:]]*$//' )
											# Search for the same key in Old XML file and if present get value for that.
											if [[ `grep "${key}=" "${engine_name}_old_formatted.out"` ]]; then
													value_old=$(grep "${key}=" "${engine_name}_old_formatted.out" | cut -d '=' -f 2- | sed -e 's/[[:space:]]*$//')
##													if [[ "^${value}$" = "^${value_old}$" ]]; then
                                                                                                        if [[ "${value}" == "${value_old}" ]]; then
														continue
													else
															echo "<tr>" >>changed_gv_value
															echo "<td colspan=\"1\"><small>${key}</small></td>" >>changed_gv_value
															echo "<td colspan=\"1\"><small>${value_old}</small></td> ">>changed_gv_value
															echo "<td colspan=\"3\"><small>${value}</small></td>" >>changed_gv_value
															echo "</tr>" >>changed_gv_value
													fi
											else
													#echo "${key}=${value}" >added_gv_to_new_xml
													echo "<tr>" >>added_gv_to_new_xml
													echo "<td colspan=\"1\"><small>${key}</small></td>" >>added_gv_to_new_xml
													echo "<td colspan=\"4\"><small>${value}</small></td>" >>added_gv_to_new_xml
													echo "</tr>" >>added_gv_to_new_xml
											fi
							fi
#			done <<< "$(cat ${engine_name}_new_formatted.out | egrep '\S' | egrep -v '#' | sed 's/^ //')"
                        done <<< "$(cat ${engine_name}_new_formatted.out | grep -v RvDaemon|egrep -v '#' | sed 's/^ //')"

			# get GV diff for all the GV's present in OLD XML file. Ignore if it is already present in new XML.

			while read -r line; do
							line=$(echo ${line} | sed $'s/\r//')
					if [[ ! -z "${line}" ]];then
							key=$(echo ${line} | cut -d '=' -f 1)
											value=$(echo ${line} | cut -d '=' -f 2-)
											# Search for the same key in Old XML file and if present get value for that.
											if [[ ! `grep "${key}=" "${engine_name}_new_formatted.out"` ]]; then
													#echo "${key}=${value}" >>removed_gv_from_old_xml
													echo "<tr>" >>removed_gv_from_new_xml
													echo "<td colspan=\"1\"><small>${key}</small></td>" >>removed_gv_from_new_xml
													echo "<td colspan=\"4\"><small>${value}</small></td>" >>removed_gv_from_new_xml
													echo "</tr>" >>removed_gv_from_new_xml
											fi
							fi
#			done <<< "$(cat ${engine_name}_old_formatted.out | egrep '\S' | egrep -v '#' | sed 's/^ //')"
                        done <<< "$(cat ${engine_name}_old_formatted.out | grep -v RvDaemon|egrep -v '#' | sed 's/^ //')"
			# construct report.
			>"${engine_name}_GV_DIFF.html"
			table_header "${engine_name}" "${old_xml_version}" "${new_xml_version}" >"${engine_name}_GV_DIFF.html"

			sub_table_gv_diff_header "GV DIFF Report for the changed GV's" >>"${engine_name}_GV_DIFF.html"
			cat changed_gv_value >>"${engine_name}_GV_DIFF.html"
			sub_table_footer >>"${engine_name}_GV_DIFF.html"

			sub_table_header "GV DIFF Report for the newly added GV's" >>"${engine_name}_GV_DIFF.html"
			cat added_gv_to_new_xml >>"${engine_name}_GV_DIFF.html"
			sub_table_footer >>"${engine_name}_GV_DIFF.html"

			sub_table_header "GV DIFF Report for the removed GV's " >>"${engine_name}_GV_DIFF.html"
			cat removed_gv_from_new_xml >>"${engine_name}_GV_DIFF.html"
			sub_table_footer >>"${engine_name}_GV_DIFF.html"
			
			# Move GV_DIFF Folder into separate folder in remote work directory.
			mkdir -p "${GVDIFF_BACKUP}"
			if [[ -f "${engine_name}_GV_DIFF.html" ]]; then
					mv ./"${engine_name}_GV_DIFF.html" "${GVDIFF_BACKUP}"
			fi
			
			# Clean up all the unwanted files.
			rm changed_gv_value added_gv_to_new_xml removed_gv_from_new_xml
			rm "${engine_name}_old_formatted.out"
			rm "${engine_name}_new_formatted.out"
	else
		echo "For engine ${engine_name} either old XML or new XML is not present"
	fi
done

echo "GV DIFF UTILITY Execution completed"

