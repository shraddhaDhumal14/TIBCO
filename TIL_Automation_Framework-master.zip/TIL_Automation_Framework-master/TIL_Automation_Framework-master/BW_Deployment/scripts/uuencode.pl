#! /usr/bin/perl
use strict;

# Usage inputFile ....      = file to uuencode

die "Usage: $0 inputFile .... \n" if @ARGV < 1;

foreach my $inputFile (@ARGV)
{
    my $INPUT_FD;

    open($INPUT_FD, $inputFile) or die "$inputFile: $!\n";

    my $mode = 0644;
    my $text = "";
    printf "begin %o $inputFile\n", $mode;

    while (read($INPUT_FD, $text, 45)) {
        print pack('u', $text);
    }

    print "`\nend\n";

    close($INPUT_FD);
}

exit 0;


