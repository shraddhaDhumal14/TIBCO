#!/bin/bash
# Thsi script try to validate bw deployment status from Deployment_summary.txt
# Input1: CRQ Number

# engine names with validation failure will be written to "deployment_failed" file
# engine names with validation success will be written to "deployment_success" file

CRQ=$1
ENGINES=$2
WORK_DIR=`pwd`

if [[ ! -z "$3" ]]; then
                bw_var="${3}/Failed_Engines/Failed_Restart_engine_artefacts/bw"
                backup_var="${3}/Failed_Engines/Failed_Restart_engine_artefacts/backup"
                appconf_var="${3}/Failed_Engines/Failed_Restart_engine_artefacts"
else
                bw_var="${WORK_DIR}/Failed_Restart_engine_artefacts/bw"
                backup_var="${WORK_DIR}/Failed_Restart_engine_artefacts/backup"
                appconf_var="${WORK_DIR}/Failed_Restart_engine_artefacts"
fi


# If deployment typeis ESISTING, validate backup.
>${WORK_DIR}/restart_success
>${WORK_DIR}/restart_failed



do_backup() {

        # This function is to take backup of failed artefacts depending on the option.
        engine=$1
        crq_num=$2
                                  mkdir -p "${bw_var}"
		                  mkdir -p "${backup_var}"                

                [[ -d "${WORK_DIR}/${crq_num}/bw" ]] && mv ${WORK_DIR}/${crq_num}/bw/${engine}*.* "${bw_var}"
                [[ -d "${WORK_DIR}/${crq_num}/backup" ]] && mv ${WORK_DIR}/${crq_num}/backup/${engine}*.* "${backup_var}"
                [[ -f "${WORK_DIR}/${crq_num}/${engine}.appconf" ]] && mv ${WORK_DIR}/${crq_num}/${engine}.appconf "${appconf_var}"
                                                                [[ -f "${WORK_DIR}/${crq_num}/${engine}.gvconf" ]] && mv ${WORK_DIR}/${crq_num}/${engine}.gvconf "${appconf_var}"
                                                                [[ -f "${WORK_DIR}/${crq_num}/${engine}.prconf" ]] && mv ${WORK_DIR}/${crq_num}/${engine}.prconf "${appconf_var}"

                sed -i "/.*${engine}.*/d" "${WORK_DIR}/${crq_num}/bw/AppManage.batch"
                [[ -d "${WORK_DIR}/${crq_num}/backup" ]] && sed -i "/.*${engine}.*/d" "${WORK_DIR}/${crq_num}/backup/AppManage.batch"
                                                                [[ -d "${WORK_DIR}/${crq_num}/backup" ]] && sed -i "/.*${engine}.*/d" "${WORK_DIR}/${crq_num}/backup/NewApplications.txt"
                sed -i "/.*${engine}.*/d" "${WORK_DIR}/${crq_num}/Instance_Details.txt"
}




if [[ ! -z "${ENGINES}" ]] && [[ -f "${WORK_DIR}/${CRQ}/logs/${CRQ}_restart_summary_sort.txt" ]]; then
                echo "${ENGINES}" | tr ";" "\n" | while read -r engine_name; do
                                chk=$(grep ${engine_name} ${WORK_DIR}/${CRQ}/logs/${CRQ}_restart_summary_sort.txt | egrep "Started with Errors|Failed to start or terminated")
                                if [[ -z "${chk}" ]]; then
                                                echo "INFO: ${engine_name} is successfully deployed."
                                                echo "${engine_name}" >> ${WORK_DIR}/restart_success
                                else
                                                echo "INFO: ${engine_name} deploymnet failed. Proceeding with backup"
                                                #do_backup "${engine_name}" "${CRQ}"
                                                echo "${engine_name}" >> ${WORK_DIR}/restart_failed
                                fi
                done
fi
