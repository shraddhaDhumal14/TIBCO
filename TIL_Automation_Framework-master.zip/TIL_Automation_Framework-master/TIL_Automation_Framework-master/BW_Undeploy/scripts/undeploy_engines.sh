#!/bin/sh
if [[ "$#" -ne 5 ]]; then
        echo "All options are not passed to the script. Please pass the valid values."
        exit 1
fi

TRA_HOME=$1
domainName=$2
domainUser=$3
domainPW=$4
engines_list=$5

# Generate Applications.txt file for all the engines present in given domain.
echo "${engines_list}"  | tr ";" "\n" | while IFS=' ' read -r engineString
do
	appName=$(echo ${engineString} | cut -d ':' -f 1)
	engineName=$(echo ${appName} | cut -d '/' -f 2)
	cmd="${TRA_HOME}/bin/AppManage --propFile ${TRA_HOME}/bin/AppManage.tra -undeploy -app ${appName} -domain ${domainName} -user ${domainUser} -pw ${domainPW}"
	echo "DEBUG command is: ${cmd}"
	eval "${cmd}" >temp_log 2>&1
	chk=`cat ./temp_log | grep "Finished undeploying application" -A 2 | grep "Finished successfully" | wc -l`
	if [[ "${chk}" == 1 ]]; then
		echo "${engineName}" >> undeploy_success.txt
	else
		echo "${engineName}" >> undeploy_failure.txt
	fi

	# Push all the undeploy logs to consolidated file for reference.
	cat ./temp_log >>undeploy_log
done
	

