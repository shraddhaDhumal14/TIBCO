// Global Parameters to use in the stages.
date_now = new Date().format( 'dd-MM-yyyy' )

// Mail recipents for the individual stages.
def sit_mailRecipients = "raghuram.koripalli@vodafone.com"

def get_build_num(){
	//This method returns the build number based on the previous build number for corresponding release.
	//String jobName = System.getenv('JOB_NAME')
	println (job_name)
	def seq_no
	def job = jenkins.model.Jenkins.instance.getItemByFullName(job_name)
	for (def build : job.builds){
		if (build.displayName.contains("${params.RELEASE}")){
			//println build.properties.environment.BUILD_NUMBER.toString()
			if (build.displayName.contains('_')){
				seq_no = build.displayName.split('_')[1]
				if(seq_no.isInteger()){
				    seq_no = seq_no.toInteger() + 1
					//seq_no += 1
					return seq_no
					break;
				}
			}
		}	
	}
	if (seq_no == null || !seq_no.isInteger()){
		seq_no = 1
		return seq_no
	}
}

def sql_deploy(deployParams) {
	script{
			
			// Checkout Automation files from GITHUB repository.
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Environment}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
			
			
			
			// Delete all unwanted folders from ${deployParams.Environment} folder.
			sh "ls | grep -v ./${deployParams.Environment}/SQL* | xargs rm -rf"
			
			//Checkout Environment specic configurations (tokens, properties files)
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "SQL_COMMON_CONFIG"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_TestEnv_Configurations.git']]]
			
			// Copy SQL Common configuration folder to ${deployParams.Environment} folder.
			sh "cp -r ./SQL_COMMON_CONFIG/SQL_Common_Configuration ./${deployParams.Environment}/"
			
			// Remove SQL_COMMON_CONFIG directory from the current directory
			sh "rm -rf ./SQL_COMMON_CONFIG"

			// Copy properties files based on environment.
			sh "mkdir -p ./${deployParams.Environment}/SQL_Deployment/conf_properties"
			sh "cp -r ./${deployParams.Environment}/SQL_Common_Configuration/${deployParams.Environment}/${deployParams.Environment}_*.properties ./${deployParams.Environment}/SQL_Deployment/conf_properties"
						
			//Copy host_vars file to target location.
			sh "cp -r ./${deployParams.Environment}/SQL_Common_Configuration/${deployParams.Environment} ./${deployParams.Environment}/SQL_Deployment/host_vars"
			
			//Run ansible playbook to deploy artefacts into environment
  		    ansiColor('xterm') {
				
				ansiblePlaybook(playbook: "./${deployParams.Environment}/SQL_Deployment/deploy_Engies_SQL.yml", colorized: true, extras:'-v', extraVars: [host: "${deployParams.Environment}_SQL", repo_group_id: "${deployParams.nexus_group_id}", repo_artifact_ids:"${deployParams.repo_artifact_ids}", repo_user:"${deployParams.nexus_user}", repo_pw:"${deployParams.nexus_passwd}", repo_repo_id:"${deployParams.nexus_repo_id}", repo_url:"${deployParams.nexus_url}", Release:"${deployParams.Release}", Environment:"${deployParams.Environment}", datetime: "${deployParams.datetime}", CRQ_Num:"${deployParams.crq_no}"])
	
		    }
    }
}
// Get Configuration files required for Engine Restart

def get_conf_files_restart(deployParams) {
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}_Conf"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_BW_Application_Configuration.git']]]
    // make a directory with conf
	sh "mkdir -p ./${deployParams.Host}_Conf/conf"
    echo "${deployParams.engines}"
	echo "${deployParams.folderName}"
    def engine_list = deployParams.engines.split(';')
		for (txt in engine_list) {
			echo "${txt}"
			def eng_conf = txt
			echo eng_conf
			// check if engine input has folder name associated 
			if(eng_conf.contains('/')){
				def engine_params = eng_conf.split('/')
				def folderName = engine_params[0]
				def engine_name = engine_params[1]
				// copy appconf file from master repository
				sh "cp ./${deployParams.Host}_Conf/Restart_Configurations/Restart_Template.appconf ./${deployParams.Host}_Conf/conf/${engine_name}.appconf"
			
				// update values of appconf with Folder name provided during deployment
				sh  "sed -i '/FolderName=/ s/=.*/=${folderName}/'  ./${deployParams.Host}_Conf/conf/${engine_name}.appconf"
		  
				
			}
			else{
				
				// copy appconf file from master repository
			sh "cp ./${deployParams.Host}_Conf/Restart_Configurations/Restart_Template.appconf ./${deployParams.Host}_Conf/conf/${eng_conf}.appconf"
			
			}	

			
			// create directory if does not exist
		   // sh "mkdir -p ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}"
			// copy appconf file from master repository
			//sh "mv ./${deployParams.Host}_Conf/Restart_Configurations/Restart_Template.appconf ./${deployParams.Host}_Conf/conf/${eng_conf}.appconf"
			
			// update values of appconf with Folder name provided during deployment
			//sh  "sed -i '/FolderName=/ s/=.*/=${deployParams.folderName}/'  ./${deployParams.Host}_Conf/conf/${eng_conf}.appconf"
	   }
}




def deploy_restart_bw(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
			
			//Checkout Environment specic configurations (tokens, properties files)
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "RESTART_ENV"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_TestEnv_Configurations.git']]]
			
			
			// create directory with name conf to copy config files
			sh "mkdir -p ./${deployParams.Host}/BW_Deployment/conf"
			
			// Copy deployment conf files  to conf directory in deployment script 
			
			sh "cp -r ./${deployParams.Host}_Conf/conf/* ./${deployParams.Host}/BW_Deployment/conf"
       
           	sh "mkdir -p ./${deployParams.Host}/BW_Deployment/host_vars/${deployParams.Host}_BW"

			// Copy Environment specififc files to Ansible Host Vars 
			sh "cp -r ./RESTART_ENV/BW_Configuration/${deployParams.Host}/* ./${deployParams.Host}/BW_Deployment/host_vars/${deployParams.Host}_BW"
			
			
		
			//Run ansible playbook to deploy artefacts into environment
			 ansiColor('xterm') {
    	     ansiblePlaybook(playbook: "./${deployParams.Host}/BW_Deployment/restartBW.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Host}_BW", engines: "${deployParams.engines}", datetime: "${deployParams.datetime}", crq_num: "${deployParams.crq_no}", bwDeployment: "${deployParams.bwDeployment}", bwRestart: "${deployParams.bwRestart}"])
	
		    }
    }
}






def get_body_build_summary(){
	
	def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
		.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		</style>
		<table class="tg" style="undefined;table-layout: fixed; width: 1200px">
		<colgroup>
		<col style="width: 100px">
		<col style="width: 500px">
		<col style="width: 100px">
		<col style="width: 500px">
		</colgroup>
		  <tr>
			<th class="tg-amwm" colspan="4">SQL Deployment SUMMARY</th>
		  </tr>
		  <tr>
			<td class="tg-1wig">Submitted By</td>
			<td class="tg-0lax">${currentBuild.getRawBuild().getCauses()[0].getUserId()}</td>
			<td class="tg-1wig">Date</td>
			<td class="tg-0lax">${date_now}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">RELEASE NUMBER</td>
			<td class="tg-0lax">${params.RELEASE}</td>
			<td class="tg-1wig">CRQ NUMBER</td>
			<td class="tg-0lax">${params.CRQ_NUMBER}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">Deployment_VERSION</td>
			<td class="tg-0lax">${params.SQL_VERSION}</td>
			<td class="tg-1wig"></td>
			<td class="tg-0lax"></td>
		  </tr>
		  <tr>
			<td class="tg-1wig">BUILD_URL</td>
			<td class="tg-0lax" colspan="3">${BUILD_URL}</td>
		  </tr>
		  <tr>
		</table>
		<br><br><br>
		<table class="tg" style="undefined;table-layout: fixed; width: 1200px">
		<colgroup>
		<col style="width: 100px">
		<col style="width: 500px">
		<col style="width: 100px">
		<col style="width: 500px">
		</colgroup>
		  <tr>
			<td class="tg-1wig">LOG_URL</td>
			<td class="tg-0lax" colspan="3">${BUILD_URL}/console</td>
		  </tr> 
		</table>
	"""
	return body_build_summary
} 

displayName = " "
pipeline {
	agent any
	environment {
		NEXUS_URL="195.233.197.150:8081"
		REPO_URL = "http://195.233.197.150:8081/repository"
		LT_REPO="LINKTEST_REPO"
		SIT_REPO="SIT_REPO"
		STAGING_REPO="STAGING_REPO"
		PROD_REPO="PROD_REPO"
		SQL_GROUPID="TIL_SQL"
		NEXUS_USERNAME="admin"
		NEXUS_PASSWORD="admin123"
		NEXUS_VERSION="nexus3"
		ENGINE_NAME="Common_SQL_Changes"
	}
	stages {
		stage('Preparation') {
			steps {
                script {
						cleanWs disableDeferredWipeout: true, deleteDirs: true
						if (RELEASE == ""){
						    currentBuild.result = 'ABORTED'
                            error('RELEASE should be specified for the build / deployment')
						}
						if (SQL_VERSION == ""){
						    currentBuild.result = 'ABORTED'
                            error('SQL version should be specified for the deployment')
						}
						if (CRQ_NUMBER.indexOf(' ') != -1){
						    currentBuild.result = 'ABORTED'
                            error('Parameter validation failed.CRQ_NUMBER should not contain space in between.')
						}

                         DEV_TAG = "${params.RELEASE}_${get_build_num()}"
						currentBuild.displayName = "${DEV_TAG}"						
						
						// checking out framework automation scripts
						checkout([$class: 'GitSCM', doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: './TIL_AUTOMATION']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]])
                 				
                }

			}
		}

		stage('SQL Deployment') {
			steps {
				script {
					
					
					sql_deploy Environment:"${params.Environment}", Release: "${params.RELEASE}", nexus_group_id: "${env.SQL_GROUPID}", nexus_url: "${env.REPO_URL}", nexus_repo_id: "${env.SIT_REPO}", nexus_user: "${env.NEXUS_USERNAME}", nexus_passwd: "${env.NEXUS_PASSWORD}", crq_no: "${params.CRQ_NUMBER}", repo_artifact_ids: "${env.ENGINE_NAME}:${params.SQL_VERSION}", datetime: "${date_now}"
					
					echo "SQL Deployment completed"
				}

			}
		}
		stage('Engine Restart') {
			steps {
				script{
					// Get BW engines with SQL changes listed in CRQ Number. These need to be restarted once after SQL deployment is successful.
					//sh label: '', script: 'ansible-playbook ./TIL_AUTOMATION/SQL_Deployment/get_BW_EngineList.yml -i ./TIL_AUTOMATION/SQL_Deployment/hosts -f 5 -e host=${params.Environment} -e CRQ_Num="${params.CRQ_NUMBER}" -e WORKSPACE="${WORKSPACE}" -v'
					//def engines_restart = sh(script: 'cat ./engineList.out' ,returnStdout: true).trim()
                    get_conf_files_restart engines:"${params.Engines_List}", Host:'LinkTest' 	
					           					
					echo "Engines to restart are: ${params.Engines_List}"
					deploy_restart_bw Host:"${params.Environment}", crq_no:"${params.CRQ_NUMBER}", engines:"${params.Engines_List}", datetime:"${date_now}"
				}
			}
		}
		stage('Signoff SIT') {
			steps {
				script{
					 
					echo "Signoff ${params.Environment}"

					// Send Approval Email and wait for Signoff   
					
					SITBWApprovers = get_approvers_list('SITBWApprovers')
				
					
					
					if (emailBody == " ") {
						emailBody = "${get_body_build_summary()}"
					}										
					emailext mimeType: 'text/html',
					 subject: "[Jenkins]:${currentBuild.fullDisplayName}:Approval email for promote Artefact to STAGING",
					 from:"TIL_SQL_DEPLOYMENTS",
					 to: "${sit_mailRecipients}",
					 body: 	"${emailBody}" + "<br>" + 
							"<br><br><p><b><font size='5' color='Black'>Signoff SIT Changes for deploying into Staging: <a href='${BUILD_URL}input'>${currentBuild.displayName}</a></font></b></p>"
					
					//def testOptions = 'YES\nNO'
					def userInput = input(
					   id: 'userInput', 
					   message: 'Do you want to promote Artefact to STAGING?',
					   //parameters: [
						//	[$class: 'ChoiceParameterDefinition', choices: testOptions, description: 'Select Promote Artefact', name: 'promoteArtefact']
					   //],
					   submitterParameter: 'submitter',
					   submitter: "${SITBWApprovers}"
					)

					echo "Promoting SQL Artefact version: ${SQL_VERSION}"
					
					// Call Promote artefact step to promote by providing source and target repo details along with engine & Version
					artifactPromotion artifactId: "${env.ENGINE_NAME}", classifier: '', debug: true, extension: 'tar.gz', groupId: "${env.SQL_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWORD}", releaseRepository: "${env.REPO_URL}/${env.STAGING_REPO}", releaseUser: "${env.NEXUS_USERNAME}", stagingPW: "${env.NEXUS_PASSWORD}", stagingRepository: "${env.REPO_URL}/${env.SIT_REPO}", stagingUser: "${env.NEXUS_USERNAME}", version: "${SQL_VERSION}"
					
					artifactPromotion artifactId: "${env.ENGINE_NAME}", classifier: '', debug: true, extension: 'txt', groupId: "${env.SQL_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWORD}", releaseRepository: "${env.REPO_URL}/${env.STAGING_REPO}", releaseUser: "${env.NEXUS_USERNAME}", stagingPW: "${env.NEXUS_PASSWORD}", stagingRepository: "${env.REPO_URL}/${env.SIT_REPO}", stagingUser: "${env.NEXUS_USERNAME}", version: "${SQL_VERSION}"
				}
			}
		}
		
	}

}
