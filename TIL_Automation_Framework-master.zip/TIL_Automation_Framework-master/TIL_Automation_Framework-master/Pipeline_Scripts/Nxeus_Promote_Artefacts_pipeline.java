
pipeline {
    agent any
    environment {
		REPO_URL = "http://195.233.197.150:8081/repository"
		NEXUS_URL = "http://195.233.197.150:8081"
		NEXUS_USER = "admin"
		NEXUS_PASSWD = "admin123"
		BW_GROUPID = "TIL_BW"
		EMS_GROUPID = "TIL_EMS"
		SQL_GROUPID="TIL_SQL"
    }
    stages {
		stage('PROMOTE_ARTEFACTS') {
			steps {
				script{
					if(BW_PROMOTE_ARTEFACTS.length() != 0){
							BW_PROMOTE_ARTEFACTS.split(';').each { BW_ENTRY ->
								bw_eng = BW_ENTRY.split(':')[0]
								bw_ver = BW_ENTRY.split(':')[1]
								
								artifactPromotion artifactId: bw_eng, classifier: '', debug: true, extension: 'ear', groupId: "${env.BW_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.TARGET_REPO}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.SOURCE_REPO}", stagingUser: "${env.NEXUS_USER}", version: bw_ver
								
								artifactPromotion artifactId: bw_eng, classifier: '', debug: true, extension: 'appconf', groupId: "${env.BW_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.TARGET_REPO}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.SOURCE_REPO}", stagingUser: "${env.NEXUS_USER}", version: bw_ver
								
								artifactPromotion artifactId: bw_eng, classifier: '', debug: true, extension: 'html', groupId: "${env.BW_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.TARGET_REPO}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.SOURCE_REPO}", stagingUser: "${env.NEXUS_USER}", version: bw_ver
								
								artifactPromotion artifactId: bw_eng, classifier: '', debug: true, extension: 'proddiff', groupId: "${env.BW_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.TARGET_REPO}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.SOURCE_REPO}", stagingUser: "${env.NEXUS_USER}", version: bw_ver
								
								artifactPromotion artifactId: bw_eng, classifier: '', debug: true, extension: 'txt', groupId: "${env.BW_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.TARGET_REPO}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.SOURCE_REPO}", stagingUser: "${env.NEXUS_USER}", version: bw_ver
						}
					}
					if(EMS_PROMOTE_ARTEFACTS.length() != 0){
							EMS_PROMOTE_ARTEFACTS.split(';').each { EMS_ENTRY ->
								ems_eng = EMS_ENTRY.split(':')[0]
								ems_ver = EMS_ENTRY.split(':')[1]
								
								artifactPromotion artifactId: ems_eng, classifier: '', debug: true, extension: 'tar.gz', groupId: "${env.EMS_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.TARGET_REPO}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.SOURCE_REPO}", stagingUser: "${env.NEXUS_USER}", version: ems_ver
								
								artifactPromotion artifactId: ems_eng, classifier: '', debug: true, extension: 'txt', groupId: "${env.EMS_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.TARGET_REPO}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.SOURCE_REPO}", stagingUser: "${env.NEXUS_USER}", version: ems_ver
						}
					}
					if(SQL_PROMOTE_ARTEFACTS.length() != 0){
							SQL_PROMOTE_ARTEFACTS.split(';').each { SQL_ENTRY ->
								sql_eng = SQL_ENTRY.split(':')[0]
								sql_ver = SQL_ENTRY.split(':')[1]
								
								artifactPromotion artifactId: sql_eng, classifier: '', debug: true, extension: 'tar.gz', groupId: "${env.SQL_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.TARGET_REPO}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.SOURCE_REPO}", stagingUser: "${env.NEXUS_USER}", version: sql_ver
								
								artifactPromotion artifactId: sql_eng, classifier: '', debug: true, extension: 'txt', groupId: "${env.SQL_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.TARGET_REPO}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.SOURCE_REPO}", stagingUser: "${env.NEXUS_USER}", version: sql_ver
						}
					}
				}
			}
		}
	}
}


