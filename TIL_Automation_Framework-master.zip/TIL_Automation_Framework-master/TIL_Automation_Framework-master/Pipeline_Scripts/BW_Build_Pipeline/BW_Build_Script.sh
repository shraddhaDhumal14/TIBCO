##################################################################################
# Variable Declaration
#BUILD_HISTORY="/opt/tibco/.jenkins/workspace/TIL_PIPELINES/BUILD_HISTORY"
BUILD_HISTORY="${WORKSPACE}/../BUILD_HISTORY"
#AUTOMATION_PATH="/opt/tibco/.jenkins/workspace/TIL_PIPELINES/BW/BW_PIPELINE/TIL_AUTOMATION/TIL_Build"
AUTOMATION_PATH="${WORKSPACE}/../BW_PIPELINE/TIL_AUTOMATION/TIL_Build"

echo "DEBUG: DEV_TAG Passed is:${DEV_TAG}"

sleep 60

# Cleanup TIL_SCRUM Folder if it exists.
[[ -d "${WORKSPACE}/TIL_SCRUM" ]] && rm -rf "${WORKSPACE}/TIL_SCRUM"

if [ -d "${WORKSPACE}/../BW_PIPELINE/TIL_SCRUM" ]; then
	cp -r ${WORKSPACE}/../BW_PIPELINE/TIL_SCRUM ${WORKSPACE}/
	#rsync -qah --exclude '${WORKSPACE}/TIL_SCRUM/.git'  ${WORKSPACE}/TIL_SCRUM/ ${WORKSPACE}/TIL_SOURCE/
	cd ./TIL_SCRUM
	rm -rf `find . -name CVS`
	# Copy all the modified / added files to Main module from Scrum Module.
	if [ ! -z "${MODIFIED_FILES}" ];then 
		echo "${MODIFIED_FILES}" | while IFS= read -r line
		do
			[[ -f "${line}" ]] && cp --parents --remove-destination "${line}" ${WORKSPACE}/TIL_SOURCE/ || { echo "ERROR: ${line} does not exist in Feature Branch. Please check."; exit 1; }
		done
	fi

	# Change the direcory to TIL_SOURCE before deleting files.
	cd "${WORKSPACE}/TIL_SOURCE"

	# Remove all the deleted files from Main module.
	if [ ! -z "${DELETED_FILES}" ];then 
		echo "${DELETED_FILES}" | while IFS= read -r line
		do
			[[ -f "${line}" ]] && rm  "${WORKSPACE}/TIL_SOURCE/${line}" || { echo "ERROR: ${line} does not exist in TIL MAIN Module. Please check."; exit 1; }
		done
	fi
fi

cd ${WORKSPACE}
#rm -rf `find  ${WORKSPACE}/TIL_SOURCE/ -name CVS`

##################################################################################

# Copy all the dependency folders to projlib folder
cp -r ${AUTOMATION_PATH}/* ${WORKSPACE}/
chmod 755 *.sh

##################################################################################

# Validate engine archive file existence in Build directory for source directory.
if ! sh validate_parameters.sh;then
	exit 1
fi
##################################################################################

cp ./generate_tag_file.sh ./TIL_SOURCE/
cd ${WORKSPACE}/TIL_SOURCE

if ! sh generate_tag_file.sh;then
	exit 1
fi

#./generate_tag_file.sh
cd ${WORKSPACE}

##################################################################################

# Remove all the unwanted files from Project folder till EAR build

mkdir -p ${WORKSPACE}/TEMP
cp -r ${WORKSPACE}/TIL_SOURCE/.git ${WORKSPACE}/TEMP
rm -rf ${WORKSPACE}/TIL_SOURCE/.git
rm -rf ${WORKSPACE}/TIL_SOURCE/generate_tag_file.sh
##################################################################################

# Download all previous ear files for the engines from Nexus
#cp /opt/tibco/.jenkins/workspace/TIL_PIPELINES/BUILD_HISTORY/"${RELEASE}"_BuildHistory ${WORKSPACE}/
mkdir ./PREV_EARS

if ! sh get_previous_version.sh;then
	exit 1
fi

ls -lrt ./PREV_EARS/

##################################################################################

echo -e "Generate tilbuild.properties file"

if ! sh generate_buildproperties.sh;then
	exit 1
fi

(($? != 0)) && { printf '%s\n' "Command exited with non-zero"; exit 1; }

##################################################################################

#echo -e "Create buildprojlib.properties file from designtimelibs and checkout projlib files from CVS."
#mkdir -p ${WORKSPACE}/projlib
#./CreateBuildProp.sh

if ! sh getProjLibs.sh;then
	exit 1
fi

#. ./getProjLibs.sh
#(($? != 0)) && { printf '%s\n' "Command exited with non-zero"; exit 1; }

#rm -rf `find  ${WORKSPACE}/projlib/ -name CVS`

##################################################################################
echo -e "Set Environment"
. ./setenv.sh
#if ! sh . ./setenv.sh;then
#	exit 1
#fi

echo -e "Start XWindows"
. ./startXvfb.sh
#if ! sh startXvfb.sh;then
#	exit 1
#fi


echo "Run ANT Script"
#./run_ant.sh
. ./run_ant.sh
(($? != 0)) && { printf '%s\n' "Command exited with non-zero"; exit 1; }

##################################################################################

#echo -e "Validate EAR Files"
#./EARValidator.sh
if ! sh EARValidator.sh;then
	cat errorlog
	exit 1
fi

echo -e " Generate EAR DIFF with previous EAR Files"
if ! sh generate_eardiff.sh;then
	exit 1
fi

##################################################################################

echo -e " Copy EAR files to common location so that pipeline stage will push them to nexus."
mkdir -p ${BUILD_HISTORY}
mkdir -p ${BUILD_HISTORY}/${DEV_TAG}
cp -r ${WORKSPACE}/EAR_BUILD/* ${BUILD_HISTORY}/${DEV_TAG}
cp ${WORKSPACE}/*_diff ${BUILD_HISTORY}/${DEV_TAG}
cp DEV_${DEV_TAG} ${BUILD_HISTORY}/${DEV_TAG}
cp ${WORKSPACE}/*appconf ${BUILD_HISTORY}/${DEV_TAG}
cp ${WORKSPACE}/*pom ${BUILD_HISTORY}/${DEV_TAG}
cp ${WORKSPACE}/Validation.log ${BUILD_HISTORY}/${DEV_TAG}

######################${WORKSPACE}/############################################################

#Update Build History with current build details.
cp ${WORKSPACE}/tilbuild.properties ${BUILD_HISTORY}/${DEV_TAG}/BUILD_${DEV_TAG}_PROPERTIES

######################${WORKSPACE}/############################################################

cp -r ${WORKSPACE}/TEMP/.git ${WORKSPACE}/TIL_SOURCE/
rm -rf ${WORKSPACE}/TEMP


######################commit changes to remote repository############################################################

cd ${WORKSPACE}/TIL_SOURCE/
#git add --all .
echo `git add -A . && git commit -m "${IRIS_DESCRIPTION}"`
#git commit -m "${IRIS_DESCRIPTION}"