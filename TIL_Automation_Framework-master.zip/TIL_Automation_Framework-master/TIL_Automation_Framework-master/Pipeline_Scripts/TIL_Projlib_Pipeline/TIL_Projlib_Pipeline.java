// Global Parameters to use in the stages.
date_now = new Date().format( 'dd-MM-yyyy' )

// Mail recipents for the individual stages.
def bw_mailRecipients = "tssiukintegrationdevleads@vodafone.com, satish.muranal@vodafone.com, integrationad_buildteam@vodafone.com, ${params.BUILD_REQUESTER}, rajesh.amarnath@vodafone.com, rajesh.amarnath1@vodafone.com, avatansh.sharma@vodafone.com, avatansh.sharma1@vodafone.com, pratibha.bhimraoalande@vodafone.com"
def get_build_num(){
	//This method returns the build number based on the previous build number for corresponding release.
	//String jobName = System.getenv('JOB_NAME')
	println (job_name)
	def seq_no
	def max_search_builds=500
	def count=0	
	def job = jenkins.model.Jenkins.instance.getItemByFullName(job_name)
	for (def build : job.builds){
		count = count.toInteger() + 1
		if(count.toInteger() >= max_search_builds.toInteger()) {
			break;
		}		
		if (build.displayName.contains("${TIL_MODULENAME}")){
			//println build.properties.environment.BUILD_NUMBER.toString()
			if (build.displayName.contains('_')){
				seq_no = build.displayName.split('_')[1]
				if(seq_no.isInteger()){
				    seq_no = seq_no.toInteger() + 1
					//seq_no += 1
					return seq_no
					break;
				}
			}
		}	
	}
	if (seq_no == null || !seq_no.isInteger()){
		seq_no = 1
		return seq_no
	}
}
// This function is to print the build summary in email Body
def print_buildSummary() {
	
		def buildSummary = readFile "LIB_${params.PROJLIB_NAME}_DETAILS"
		buildSummary = buildSummary.replaceAll("\r\n|\n\r|\n|\r","<br/>")
		return buildSummary
}
def get_body_build_summary(){
	
	def body_build_summary = """
		<style type="text/css">
		.tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
		.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
		.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
		.tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
		.tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
		.tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
		.tg .tg-0lax{text-align:left;vertical-align:top}
		</style>
		<table class="tg" style="undefined;table-layout: fixed; width: 1200px">
		<colgroup>
		<col style="width: 100px">
		<col style="width: 500px">
		<col style="width: 100px">
		<col style="width: 500px">
		</colgroup>
		  <tr>
			<th class="tg-amwm" colspan="4">TIL PROJLIB BUILD SUMMARY</th>
		  </tr>
		  <tr>
			<td class="tg-1wig">Submitted By</td>
			<td class="tg-0lax">${currentBuild.getRawBuild().getCauses()[0].getUserId()}</td>
			<td class="tg-1wig">Date</td>
			<td class="tg-0lax">${date_now}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">TIL_MODULENAME</td>
			<td class="tg-0lax">${params.TIL_MODULENAME}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">BUILD_URL</td>
			<td class="tg-0lax" colspan="3">${BUILD_URL}</td>
		  </tr>
		  <tr>
		</table>
		<br><br><br>
		<table class="tg" style="undefined;table-layout: fixed; width: 1200px">
		<colgroup>
		<col style="width: 100px">
		<col style="width: 500px">
		<col style="width: 100px">
		<col style="width: 500px">
		</colgroup>
		  <tr>
			<td class="tg-1wig">PROJLIB BUILD SUMMARY</td>
			<td class="tg-0lax" colspan="3">${print_buildSummary()}</td>
		  </tr>
		  <tr>
			<td class="tg-1wig">LOG_URL</td>
			<td class="tg-0lax" colspan="3">${BUILD_URL}/console</td>
		  </tr> 
		  <tr>
			<td class="tg-1wig">PROJLIB_DIFF_REPORT</td>
			<td class="tg-0lax" colspan="3">${diff_url}</td>
		  </tr>		  
		</table>
	"""
	return body_build_summary
}
pipeline {
	agent any
	environment {
		NEXUS_URL="195.233.197.150:8081"
		NEXUS_VERSION="nexus3"
		NEXUS_USERNAME="admin"
		NEXUS_PASSWD="admin123"
		REPO_NAME="TIL_FRAMEWORK"
		def PWD = pwd();
	}
	stages {
		stage('Preparation') {
			steps {
                script {
                        
                        if (! BUILD_REQUESTER.matches('^[a-zA-Z0-9._%+-]+@vodafone.com$')){
						   currentBuild.result = 'ABORTED'
						   error('Please enter Valid email ID for Build Requester')
						}
						
						cleanWs disableDeferredWipeout: true, deleteDirs: true
						DEV_TAG = TIL_MODULENAME + '_' + "${get_build_num()}"
						currentBuild.displayName = "${DEV_TAG}"

						// checking out framework automation scripts
						checkout([$class: 'GitSCM', doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: './TIL_AUTOMATION']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]])
						
						// checking out Main Module from GIT.
						checkout([$class: 'GitSCM', doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: './${TIL_TYPE}_${TIL_MODULENAME}']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/${TIL_TYPE}_${TIL_MODULENAME}.git']]])


						// checking out Feature branch from GIT. All the modified files are updated in feature branch.
						if (FEATURE_BRANCH != "") {
							checkout([$class: 'GitSCM', branches: [[name: "${params.FEATURE_BRANCH}"]], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: './${TIL_TYPE}_${TIL_MODULENAME}_FB/${TIL_TYPE}_${TIL_MODULENAME}']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/${TIL_TYPE}_${TIL_MODULENAME}.git']]])	
						}

						

						//CHANGE_STRING = sh(script:"git --git-dir=./TIL_SCRUM/.git/ log -1 --name-status --pretty=format:\"author: %cn; date: %ci; subject:%s; %h\"", returnStdout: true).trim()
						//echo "Change String is:${CHANGE_STRING}"
						
						// Copy Automation script to main workspace to start execution.
						sh label: '', script: 'cp -r ./TIL_AUTOMATION/TIL_PROJLIB/* ./'
						sh label: '', script: 'chmod 755 ./generate_projlib.sh'
						// Remove .git folder from Project Module.
						sh label: '', script: 'rm -rf `find ./${TIL_TYPE}_${TIL_MODULENAME} -name .git`'
						
                }
			}
		}
		stage('GenerateProjlib') {
			steps{
				
				script {
					// If feature branch exists, then sync the changes to main module.
					if (FEATURE_BRANCH != "") {
						sh label: '', script: "chmod 755 ./sync_fb_main_branch.sh"
						//def statusCode = sh script:script, returnStatus:true
						//def statusCode = sh(returnStderr: true, script: "./sync_fb_main_branch.sh \"${env.PWD}\" \"${TIL_TYPE}_${TIL_MODULENAME}\" \"${TIL_TYPE}_${TIL_MODULENAME}_FB\" \"${MODIFIED_FILES}\" \"${DELETED_FILES}\"")
						
						def status = sh(script: "./sync_fb_main_branch.sh \"${env.PWD}\" \"${TIL_TYPE}_${TIL_MODULENAME}\" \"${TIL_TYPE}_${TIL_MODULENAME}_FB\" \"${MODIFIED_FILES}\" \"${DELETED_FILES}\"", returnStdout: true)
						echo "status is: ${status}"
						if (status.contains("ERROR"))
						{
							currentBuild.result = 'FAILURE'
							error('Please fix erros shown above')
						}						
						//sh label: '', script: "./sync_fb_main_branch.sh \"${env.PWD}\" \"${TIL_TYPE}_${TIL_MODULENAME}\" \"${TIL_TYPE}_${TIL_MODULENAME}_FB\" \"${MODIFIED_FILES}\" \"${DELETED_FILES}\""
					}
				}				
				sleep 5
				script {
					sh label: '', script: "./generate_projlib.sh -m ${params.TIL_MODULENAME} -l \"${params.PROJLIB_NAME}\" -s \"${params.PROJLIB_SUMMARY}\" -a \"${MODIFIED_FILES}\" -d \"${DELETED_FILES}\" -r \"${env.REPO_NAME}\" -u \"${env.NEXUS_USERNAME}\" -p \"${env.NEXUS_PASSWD}\" -z \"${env.NEXUS_URL}\" -b \"${params.BUILD_REQUESTER}\" -t \"${params.TIL_TYPE}\" -x \"${params.PROJLIB_PATH}\" -f \"${params.FOLDER_NAME}\""
				}
				sleep 5
				script{
					// Get the projlib diff location along with the name.
					def diff_loc = sh(script:"cat LIB_${params.PROJLIB_NAME}_DETAILS | grep \"PROJLIB DIFF File\" | cut -d \':\' -f 2 | tr -d \' \'", returnStdout: true).trim()
					echo "diff_loc is: ${diff_loc}"
					diff_url = "http://${NEXUS_URL}/repository/${REPO_NAME}/${diff_loc}"					
					// This is to compose an email to send the Projlib build Summary along with Projlib DIFF.
					emailext mimeType: 'text/html',
						subject: "[Jenkins]: ${currentBuild.fullDisplayName}  - " + "PROJLIB Build LOG SUMMARY",
						from:"TIL_PROJLIBS@vodafone.com",
						to: "${bw_mailRecipients}",
						body: "${get_body_build_summary()}" 
				}
			}
		}
		
		stage('pushtoGit') {
			when {
		        expression { FEATURE_BRANCH != "" }
			}
			steps{
				script {
					build job: 'TIL_PIPELINES/LinkTest/push_to_git', parameters: [string(name: 'GIT_REPO_NAME', value: "${params.TIL_TYPE}_${params.TIL_MODULENAME}"), string(name: 'SOURCE_DIR', value: "${env.PWD}/${params.TIL_TYPE}_${params.TIL_MODULENAME}"), string(name: 'DEV_TAG', value: "${DEV_TAG}")]
				}
			}
		}
		
	}
}
