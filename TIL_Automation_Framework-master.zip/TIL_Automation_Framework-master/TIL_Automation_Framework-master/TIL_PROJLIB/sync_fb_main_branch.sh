#! /bin/sh
SOURCE_BASE_DIR="${1}"
SOURCE_DIR="${2}"
SOURCE_DIR_FB="${3}"
MODIFIED_FILES="${4}"
DELETED_FILES="${5}"


sleep 60

if [ -d "${SOURCE_BASE_DIR}/${SOURCE_DIR_FB}" ]; then
	cd "${SOURCE_BASE_DIR}/${SOURCE_DIR_FB}"
	rm -rf `find . -name CVS`
	# Copy all the modified / added files to Main module from Scrum Module.
	if [ ! -z "${MODIFIED_FILES}" ];then 
		echo "${MODIFIED_FILES}" | grep -v ^$ | while IFS= read -r line
		do
			[[ -f "${line}" ]] && cp --parents --remove-destination "${line}" "${SOURCE_BASE_DIR}"/ || { echo "ERROR: ${line} does not exist in Feature Branch. Please check."; exit 1; }
		done
	fi

	# Remove all the deleted files from Main module.
	cd -
	if [ ! -z "${DELETED_FILES}" ];then 
		echo "${DELETED_FILES}" | grep -v ^$ | while IFS= read -r line
		do
			[[ -f "${line}" ]] && rm  "${SOURCE_BASE_DIR}/${line}" || { echo "ERROR: ${line} does not exist in TIL MAIN Module. Please check."; exit 1; }
		done
	fi
	cd -
fi
