#! /bin/sh
PRESENT_PATH=`pwd`
# PROJECT_MODULE=$1
# PROJLIB=$2
# PROJLIB_SUMMARY=$3
# MODIFIED_FILES=$4
# DELETED_FILES=$5
# REPO_NAME=$6
# NEXUS_USER=$7
# NEXUS_PASSWD=$8
# NEXUS_URL=$9

while getopts 'm:l:s:a:d:r:u:p:z:b:t:x:f:' OPTION; do
  case "$OPTION" in
    m)
      PROJECT_MODULE="$OPTARG"
      ;;

    l)
      PROJECT_NAME="$OPTARG"
      ;;

    s)
      PROJLIB_SUMMARY="$OPTARG"
      ;;

    a)
      MODIFIED_FILES="$OPTARG"
      ;;

    d)
      DELETED_FILES="$OPTARG"
      ;;

    r)
      REPO_NAME="$OPTARG"
      ;;

    u)
      NEXUS_USER="$OPTARG"
      ;;

    p)
      NEXUS_PASSWD="$OPTARG"
      ;;

    z)
      NEXUS_URL="$OPTARG"
      ;;

    b)
      BUILD_REQUESTER="$OPTARG"
      ;;

    t)
      TIL_TYPE="$OPTARG"
      ;;

    x)
      NEW_PROJLIB_PATH="$OPTARG"
      ;;
	  
    f)
      FOLDER_NAME="$OPTARG"
      ;;	  

    ?)
      echo "Usage: $0 [ -m PROJECT_MODULE ] [ -l PROJLIB ] [ -s PROJLIB_SUMMARY ] [ -a MODIFIED_FILES ] [ -d DELETED_FILES ] [ -r REPO_NAME ] [ -u NEXUS_USER ] [ -p NEXUS_PASSWD ] [ -z NEXUS_URL ] [ -b BUILD_REQUESTER ] [ -t TIL_TYPE ] [ -x NEW_PROJLIB_PATH ] [ -f FOLDER_NAME ]" >&2
      exit 1
      ;;
  esac
done
shift "$(($OPTIND -1))"

download_resource() {
                unset resource_url
                resource_url=$1
                out_location=$2
                check_resource_cmd="curl -o /dev/null --silent -Iw '%{http_code}' -u admin:admin123 ${resource_url}"
                get_resource_cmd="curl -X GET -u ${NEXUS_USER}:${NEXUS_PASSWD} ${resource_url}"
                if [ `eval ${check_resource_cmd}` != 200 ]; then
                        echo "ERROR: ${resource_url} is not available. Please check for errors."
                        exit 1
                else
                        eval ${get_resource_cmd} >"${out_location}"
                        [[ "$?" -eq 0 ]] && echo "${out_location} downloaded from NEXUS successfully" || { echo "ERROR: ${out_location} download failed from NEXUS. Please check for errors."; exit 1; }
                fi
}


# Chane the string parameters to unix format line endings.

#MY_NEW_VAR=$(echo $testVar | sed -e 's/\r//g')

PROJLIB_SUMMARY=$(echo ${PROJLIB_SUMMARY} | sed -e 's/\r//g')
#MODIFIED_FILES=$(echo ${MODIFIED_FILES} | sed -e 's/\r//g')
DELETED_FILES=$(echo ${DELETED_FILES} | sed -e 's/\r//g')

PROJLIB="LIB_${PROJECT_NAME}"
# Download projlib.properties from Nexus

resource_url="${NEXUS_URL}/repository/${REPO_NAME}/TIL_DELIVERY01/designer/projlib.properties"
download_resource "${resource_url}" "${PRESENT_PATH}/projlib.properties"
echo "Anil"
# Convert windows style EOL characters to unix style
sed -i 's/\r//g' "${PRESENT_PATH}"/projlib.properties


# if PROJLIB exists in projlib.properties file , then get the latest version and download PROJLIB.txt and PROJLIB.xml files from nexus respository.
chk=`grep ${PROJLIB}_ ${PRESENT_PATH}/projlib.properties`

if [[ ! -z "${chk}" ]];then
        projlib_version=`grep ${PROJLIB}_ ${PRESENT_PATH}/projlib.properties | sed -e 's/^[[:space:]]*//' | sort -V | tail -1 | cut -d '=' -f 1 | cut -d '.' -f 3 | rev | cut -d '_' -f 1-3 | rev`
        echo "projlib version is: ${projlib_version}"

        # Download projlib file from nexus for latest version.
        projlib_file_path=`grep ${PROJLIB}_ ${PRESENT_PATH}/projlib.properties | sed -e 's/^[[:space:]]*//' | sort -V | tail -1 | cut -d '=' -f 2 | tr -d ''`
                projlib_file_path=$(echo ${projlib_file_path} | sed -e 's/\r//g')
        echo "projlib_file_path is : ${projlib_file_path}"
        projlib_dir=$(dirname "${projlib_file_path}")
        mkdir -p "${projlib_dir}"
        projlib_proj_file=$(basename "${projlib_file_path}")
		projlib_url="${NEXUS_URL}/repository/${REPO_NAME}/${projlib_file_path}"
		download_resource "${projlib_url}" "${PRESENT_PATH}/${projlib_dir}/${projlib_proj_file}"


        # Download txt file and xml file for latest version.
        txt_file_path=`grep ${PROJLIB}_ ${PRESENT_PATH}/projlib.properties | sed -e 's/^[[:space:]]*//' | sort -V | tail -1 | cut -d '=' -f 2 | sed -e 's/.projlib$/.txt/'`
        echo "txt_file_path is : ${txt_file_path}"
        projlib_dir=$(dirname "${txt_file_path}")
        mkdir -p "${projlib_dir}"
        projlib_txt_file=$(basename "${txt_file_path}")
		projlib_txt_url="${NEXUS_URL}/repository/${REPO_NAME}/${txt_file_path}"
		download_resource "${projlib_txt_url}" "${PRESENT_PATH}/${projlib_dir}/${projlib_txt_file}"
		if [[ `command -v dos2unix` ]]; then
			dos2unix "${PRESENT_PATH}/${projlib_dir}/${projlib_txt_file}"
		fi		

        # Download xml file for latest version
        xml_file_path=`echo "${txt_file_path}" | sed -e 's/.txt$/.xml/'`
        projlib_xml_file=$(basename "${xml_file_path}")
		projlib_xml_url="${NEXUS_URL}/repository/${REPO_NAME}/${xml_file_path}"
		download_resource "${projlib_xml_url}" "${PRESENT_PATH}/${projlib_dir}/${projlib_xml_file}"
else
        echo "DEBUG: NEW PROJLIB. Code yet to be implemented.";
		update_version="1_0_1"
		update_projlib_name="${PROJLIB}_${update_version}"
		projlib_xml_file="${update_projlib_name}.xml"
		projlib_txt_file="${update_projlib_name}.txt"

		projlib_dir="${NEW_PROJLIB_PATH}/${PROJECT_NAME}"
		mkdir -p "${projlib_dir}"


		xml_file_path="${PRESENT_PATH}/${projlib_dir}/${projlib_xml_file}"
		txt_file_path="${PRESENT_PATH}/${projlib_dir}/${projlib_txt_file}"

		# Download projlib.txt file from template directory.

		resource_url="${NEXUS_URL}/repository/${REPO_NAME}/TIL_DELIVERY01/templates/LIB_XXX_1_0_0.txt"
		download_resource "${resource_url}" "${PRESENT_PATH}/${projlib_dir}/${projlib_txt_file}"
		if [[ `command -v dos2unix` ]]; then
			dos2unix "${PRESENT_PATH}/${projlib_dir}/${projlib_txt_file}"
		fi		

		# Download projlib.xml file from template directory.

		resource_url="${NEXUS_URL}/repository/${REPO_NAME}/TIL_DELIVERY01/templates/LIB_XXX_1_0_1.xml"
		download_resource "${resource_url}" "${PRESENT_PATH}/${projlib_dir}/${projlib_xml_file}"

		# Update module name in xml file.

		sed -i "s/TIL_<YYY>/TIL_${PROJECT_MODULE}/"  "${PRESENT_PATH}/${projlib_dir}/${projlib_xml_file}"
		sed -i "s/LIB_<XXX>_1_0_0/${update_projlib_name}/" "${PRESENT_PATH}/${projlib_dir}/${projlib_xml_file}"
		sed -i "s/project name=\"<XXX>\"/project name=\"${PROJECT_NAME}\"/" "${PRESENT_PATH}/${projlib_dir}/${projlib_xml_file}"
fi


# Validate given MODULE_NAME is same in XML file as well. If not , fail the build.

mod_name=`cat ${xml_file_path} | grep "property name=\"MODULE\"" | awk -F 'value=' '{print $2}' | cut -d '"' -f 2 | cut -d '"' -f 1 | tr -d ''`
echo "MODULE_NAME in XML file is: ${mod_name}"
[[ "${mod_name}" == "${TIL_TYPE}_${PROJECT_MODULE}" ]] && echo "Given Module name and module name in XML file is same." || { echo "ERROR: Given Module name is different from XML file."; exit 1; }


if [[ -z "${update_version}" ]]; then
        update_version=`echo ${projlib_version} | awk 'BEGIN { FS="_" } { $3++;  if ($3 > 99) { $3=0; $2++; if ($2 > 99) { $2=0; $1++ } } } { printf "%d_%d_%d\n", $1, $2, $3 }'`
        update_projlib_name=`echo ${PROJLIB} | sed "s/$/_${update_version}/"`
fi
echo "update_projlib_name is: ${update_projlib_name}"

# update txt file with latest version and changes to the file.
echo "# ${update_projlib_name}:" >PROJLIB_SUMMARY
echo "# [ ${BUILD_REQUESTER} ] ${PROJLIB_SUMMARY}" >>PROJLIB_SUMMARY

# Add SUMMARY of this version
echo "File to modify is: ${txt_file_path}"
sed -i $'/$Header:/{e cat PROJLIB_SUMMARY\n}' "${txt_file_path}"
sed -i "s|Header:.*|Header: ${projlib_txt_file}, v 1.1 |" "${txt_file_path}"

# Update file with details from MODIFIED_FILES.
# for each line in changefiles go line by line and if line exists ignore, else , append it.
if [ ! -z "${MODIFIED_FILES}" ] ;then
        echo "${MODIFIED_FILES}" | while IFS=' ' read -r line
                        do
                if grep -q "^[[:blank:]]*$line" "${txt_file_path}";then
                        echo "$line found in ${txt_file_path}. Please ignore it"
                else
                        echo "DEBUG: $line NOT found in file."
                        line_dir=$(dirname "${line}")
                        echo "line_dir is:${line_dir}"
                        echo "line is:$line"
                        line_num=`grep -n ${line_dir} ${txt_file_path} | tail -1 | cut -d ':' -f 1`
                        eof_num=`grep -n "END OF FILE" ${txt_file_path} | tail -1 | cut -d ':' -f 1`
                        eof_num=$((eof_num - 2))
                        echo "line number is: ${line_num}"
                        [[ ! -z ${line_num} ]] && sed -i "${line_num} a\# ${update_version}:\n${line}" "${txt_file_path}" || sed -i "${eof_num} a\ ${line}" "${txt_file_path}"
                fi
                        done
fi
# Update file with details from DELETED_FILES file.
# for each line in DELETED_FILES go line by line and if line exists comment that line, else ignore it.
if [ ! -z "${DELETED_FILES}" ];then
        echo "${DELETED_FILES}" | tr " " "\n" | while IFS=' ' read -r line
                do
                if grep -q "^[[:blank:]]*$line" "${txt_file_path}";then
                        echo "line is:$line"
                        delete_num=`grep -n ${line}$ ${txt_file_path} | tail -1 | cut -d ':' -f 1`
                        sed -i "${delete_num} s/^/#${update_version}:\n#/" "${txt_file_path}"
                fi
        done
fi

# Copy Project Module to Projlib directory.

#cmd="cp -r ${PRESENT_PATH}/${TIL_TYPE}_${PROJECT_MODULE} ${PRESENT_PATH}/${projlib_dir}/"
#eval $cmd
#[[ "$?" -eq 0 ]] && echo -e "Project Module is copied to Projlib directory." || { echo -e "ERROR: Project Module is not copied to Projlib directory. Please check for errors"; exit 1; }

#-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# ${PRESENT_PATH}/${TIL_TYPE}_${PROJECT_MODULE} to ${PRESENT_PATH}/${projlib_dir}/

mkdir -p "${PRESENT_PATH}/${projlib_dir}/${TIL_TYPE}_${PROJECT_MODULE}"
echo "txt_file_path is :${txt_file_path}"

while read -r line; do
		line=$(echo ${line} | sed $'s/\r//')
        echo "${line}"
        if [[ ! -z "${line}" ]];then
                [[ -f "${PRESENT_PATH}/${line}" ]] && cp --parents "${line}" "${PRESENT_PATH}/${projlib_dir}/" || { echo "ERROR: ${line} file does not exist"; exit 1; }
        fi
done <<< "$(cat "${txt_file_path}" | egrep '\S' | egrep -v "#" | sed 's/^ //')"
# escape space in file names
#done <<< "$(sed -e "s/ /\ /g" < "${txt_file_path}" | egrep '\S' | egrep -v "#" | sed 's/^ //')"

#-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# Copy templates folder to TIL_DELIVERY01 location.
manifest_location=$(echo "${projlib_dir}" | awk -F "/" '{print $1}')
cmd="cp -r ${PRESENT_PATH}/templates ${PRESENT_PATH}/${manifest_location}/"
eval $cmd
[[ "$?" -eq 0 ]] && echo -e "templates folder is copied to ${PRESENT_PATH}/${manifest_location} directory." || { echo -e "ERROR: templates folder is not copied to ${PRESENT_PATH}/${manifest_location} directory. Please check for errors"; exit 1; }

#-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


# Update XML file with correct details.
# Replace old projlib version with correct version in XML file as well.

[[ ! -z "${projlib_version}" ]] && sed -i "s/${projlib_version}/${update_version}/"  "${xml_file_path}"
sed -i '/cvs command=\"export/d' "${xml_file_path}"
sed -i '/delete dir=/d' "${xml_file_path}"

# rename both .txt file and .xml file with current version.
if [[ ! -z "${projlib_version}" ]]; then
        mv "${PRESENT_PATH}"/"${projlib_dir}"/"${projlib_txt_file}"  "${PRESENT_PATH}"/"${projlib_dir}"/"${update_projlib_name}".txt
        mv "${PRESENT_PATH}"/"${projlib_dir}"/"${projlib_xml_file}"  "${PRESENT_PATH}"/"${projlib_dir}"/"${update_projlib_name}".xml
fi

txt_file_path="${PRESENT_PATH}/${projlib_dir}/${update_projlib_name}.txt"
xml_file_path="${PRESENT_PATH}/${projlib_dir}/${update_projlib_name}.xml"

echo "txt_file_path is: ${txt_file_path}"
echo "xml_file_path is: ${xml_file_path}"

# Run ant script to generate projlib file.

[[ ! -z "${FOLDER_NAME}" ]] && cmd="/opt/tibco/tmp/TIL_TEMP/tpcl/5.7/ant/1.6/bin/ant -f ${xml_file_path} -DFOLDER=\"${FOLDER_NAME}\"" || cmd="/opt/tibco/tmp/TIL_TEMP/tpcl/5.7/ant/1.6/bin/ant -f ${xml_file_path}"
#cmd="/opt/tibco/tmp/TIL_TEMP/tpcl/5.7/ant/1.6/bin/ant -f ${xml_file_path}"
eval $cmd
[[ "$?" -eq 0 ]] && echo -e "PROJLIB SUCCESSFULLY GENERATED" || { echo -e "ERROR: PROJLIB Generation failed. Please check for erros."; exit 1; }

# Update latest version for projlib in projlib.properties file
add_line="tibco.alias.${update_projlib_name}=${projlib_dir}/${update_projlib_name}.projlib"
[[ -f "${PRESENT_PATH}/${projlib_dir}/${update_projlib_name}.projlib" ]] && echo "projlib exists in the path: ${projlib_dir}" || { echo "ERROR: Projlib does not exists. Please check for error"; exit 1; }


if [[ ! -z "${projlib_version}" ]];then
        line_num=`grep -n ${PROJLIB}_${projlib_version} ${PRESENT_PATH}/projlib.properties | tail -1 | cut -d ':' -f 1`
fi
[[ ! -z ${line_num} ]] && sed -i "${line_num} a\ ${add_line}" "${PRESENT_PATH}/projlib.properties" || echo ${add_line} >>${PRESENT_PATH}/projlib.properties

# copy projlib.properties to TIL_DELIVERY01/designer folder.

cmd="mkdir -p ${PRESENT_PATH}/TIL_DELIVERY01/designer/ && cp ${PRESENT_PATH}/projlib.properties ${PRESENT_PATH}/TIL_DELIVERY01/designer/"
eval $cmd
[[ "$?" -eq 0 ]] && echo -e "projlib.properties file copied to TIL_DELIVERY01/designer/ location" || { echo -e "ERROR: Failed to copy projlib.properties file to TIL_DELIVERY01/designer/ location. Please check for errors"; exit 1; }


# Generate Projlib diff report from the previous projlib.

if [ -f "${PRESENT_PATH}/${projlib_dir}/${projlib_proj_file}" ]; then
        diff_cmd="java -cp ${PRESENT_PATH}/EARDiff/EARDiff.jar:${PRESENT_PATH}/EARDiff/commons-cli-1.0.jar:${PRESENT_PATH}/EARDiff/tibBWDetailedDiff.jar com.hp.ear.utils.eardiff.DetailedDiff -firstfile ${PRESENT_PATH}/${projlib_dir}/${projlib_proj_file} -secondfile ${projlib_dir}/${update_projlib_name}.projlib -outputfile ${PRESENT_PATH}/${projlib_dir}/${update_projlib_name}_DIFF.html"

        eval ${diff_cmd}
        [[ "$?" -eq 0 ]] && echo -e "PROJLIB DIFF generated successfully and can be accessed from ${update_projlib_name}_DIFF.html file" || { echo -e "ERROR: Failed to generate PROJLIB DIFF report. Please check logs."; exit 1; }
else
        echo " There is no previous projlib exists for generating PROJLIB DIFF report" >"${PRESENT_PATH}/${projlib_dir}/${update_projlib_name}_DIFF.html"
fi

# Push all the artefacts to Nexus Repository.
cmd="ls -lrt"
eval ${cmd}

# push projlib to NEXUS
cmd="curl -X POST \"${NEXUS_URL}/service/rest/v1/components?repository=${REPO_NAME}\" -u ${NEXUS_USER}:${NEXUS_PASSWD} -H \"accept: application/json\" -H \"Content-Type: multipart/form-data\" -F \"raw.directory=${projlib_dir}/\" -F \"raw.asset1=@${projlib_dir}/${update_projlib_name}.projlib\" -F \"raw.asset1.filename=${update_projlib_name}.projlib\""
eval ${cmd}
[[ "$?" -eq 0 ]] && echo -e "${update_projlib_name}.projlib successfully pushed to NEXUS to ${projlib_dir} location" || { echo -e "ERROR: Failed to push projlib to NEXUS. Please check for errors"; exit 1; }

# push projlib zip file  to NEXUS
if [[ -f "${projlib_dir}/${update_projlib_name}.zip" ]]; then
	cmd="curl -X POST \"${NEXUS_URL}/service/rest/v1/components?repository=${REPO_NAME}\" -u ${NEXUS_USER}:${NEXUS_PASSWD} -H \"accept: application/json\" -H \"Content-Type: multipart/form-data\" -F \"raw.directory=${projlib_dir}/\" -F \"raw.asset1=@${projlib_dir}/${update_projlib_name}.zip\" -F \"raw.asset1.filename=${update_projlib_name}.zip\""
	eval ${cmd}
	[[ "$?" -eq 0 ]] && echo -e "${update_projlib_name}.zip successfully pushed to NEXUS to ${projlib_dir} location" || { echo -e "ERROR: Failed to push projlib to NEXUS. Please check for errors"; }
else 
	echo " ${update_projlib_name}.zip file does not exist in workspace "
fi


# Push txt file to NEXUS
cmd="curl -X POST \"${NEXUS_URL}/service/rest/v1/components?repository=${REPO_NAME}\" -u ${NEXUS_USER}:${NEXUS_PASSWD} -H \"accept: application/json\" -H \"Content-Type: multipart/form-data\" -F \"raw.directory=${projlib_dir}/\" -F \"raw.asset1=@${projlib_dir}/${update_projlib_name}.txt\" -F \"raw.asset1.filename=${update_projlib_name}.txt\""

eval ${cmd}
[[ "$?" -eq 0 ]] && echo -e "${update_projlib_name}.txt successfully pushed to NEXUS to ${projlib_dir} location" || { echo -e "ERROR: Failed to push ${update_projlib_name}.txt to NEXUS. Please check for errors"; exit 1; }

# Push xml file to NEXUS
cmd="curl -X POST \"${NEXUS_URL}/service/rest/v1/components?repository=${REPO_NAME}\" -u ${NEXUS_USER}:${NEXUS_PASSWD} -H \"accept: application/json\" -H \"Content-Type: multipart/form-data\" -F \"raw.directory=${projlib_dir}/\" -F \"raw.asset1=@${projlib_dir}/${update_projlib_name}.xml\" -F \"raw.asset1.filename=${update_projlib_name}.xml\""

eval ${cmd}
[[ "$?" -eq 0 ]] && echo -e "${update_projlib_name}.xml successfully pushed to NEXUS to ${projlib_dir} location" || { echo -e "ERROR: Failed to push ${update_projlib_name}.xml to NEXUS. Please check for errors"; exit 1; }

# Push projlib.properties file to NEXUS
cmd="curl -X POST \"${NEXUS_URL}/service/rest/v1/components?repository=${REPO_NAME}\" -u ${NEXUS_USER}:${NEXUS_PASSWD} -H \"accept: application/json\" -H \"Content-Type: multipart/form-data\" -F \"raw.directory=TIL_DELIVERY01/designer/\" -F \"raw.asset1=@TIL_DELIVERY01/designer/projlib.properties\" -F \"raw.asset1.filename=projlib.properties\""
echo "DEBUG: command is: ${cmd}"

eval ${cmd}
[[ "$?" -eq 0 ]] && echo -e "projlib.properties successfully pushed to NEXUS to TIL_DELIVERY01/designer location" || { echo -e "ERROR: Failed to push projlib.properties to NEXUS. Please check for errors"; exit 1; }

# Push projlib diff file to NEXUS
cmd="curl -X POST \"${NEXUS_URL}/service/rest/v1/components?repository=${REPO_NAME}\" -u ${NEXUS_USER}:${NEXUS_PASSWD} -H \"accept: application/json\" -H \"Content-Type: multipart/form-data\" -F \"raw.directory=${projlib_dir}/\" -F \"raw.asset1=@${projlib_dir}/${update_projlib_name}_DIFF.html\" -F \"raw.asset1.filename=${update_projlib_name}_DIFF.html\""
echo "DEBUG: command is: ${cmd}"

eval ${cmd}
[[ "$?" -eq 0 ]] && echo -e "Projlib diff file successfully pushed to NEXUS to ${projlib_dir} location" || { echo -e "ERROR: Failed to push projlib DIFF file to NEXUS. Please check for errors"; exit 1; }


# create a build summary file along with Projlib Diff report.
echo "PROJLIB NAME: ${PROJLIB}" >${PROJLIB}_DETAILS
echo "PROJECT_MODULE: ${TIL_TYPE}_${PROJECT_MODULE}" >>${PROJLIB}_DETAILS
echo "PROJLIB_SUMMARY: ${PROJLIB_SUMMARY}" >>${PROJLIB}_DETAILS
[[ ! -z "${MODIFIED_FILES}" ]] && echo -e "MODIFIED_FILES:\n${MODIFIED_FILES}" >>${PROJLIB}_DETAILS
[[ ! -z "${DELETED_FILES}" ]] && echo -e "DELETED_FILES:\n${DELETED_FILES}" >>${PROJLIB}_DETAILS
echo "GENERATED PROJLIB NAME: ${update_projlib_name}.projlib" >>${PROJLIB}_DETAILS
echo "GENERATED TXT FILE NAME: ${update_projlib_name}.txt" >>${PROJLIB}_DETAILS
echo "GENERATED XML FILE NAME: ${update_projlib_name}.xml" >>${PROJLIB}_DETAILS
echo "PROJLIB DIFF File:${projlib_dir}/${update_projlib_name}_DIFF.html" >>${PROJLIB}_DETAILS


echo "---------------------------------------------------------------------------------------------------------------------"
echo "                                                   END OF THE SCRIPT                                                 "
echo "---------------------------------------------------------------------------------------------------------------------"



