#! /bin/sh
environment=$1
export JAVA_HOME=/opt/tibco/tmp/TIL_TEMP/java/jdk1.7.0_80
exit_state=0

for sqlFile in ${WORKSPACE}/*.sql; do
	# Validate for special symbols in sql Files.
	echo "Processing file: ${sqlFile}"
        cmd="java -jar ValidateScripts.jar ${sqlFile}"
        eval ${cmd} 2>&1 | tee sql_validation.log
		
		# Ignore lines matching the lines in ignorefile.
		cat ignorefile | grep -v '^$' | while read line
		do
				grep -vF "${line}" sql_validation.log >temp
				mv temp sql_validation.log
				#sed -i "/${line}/Id" errorlog
		done
		
	#if [ $(grep -axvn '.*' ${sqlFile} | wc -l) -ge 1 ]
        #       then
        #       echo "ERROR: Invalid Unprintable UTF-8 characters present in ${sqlFile}. Please verify logs."
        #       echo $(grep -axvn '.*' ${sqlFile})
        #       #grep -axvn '.*' ${sqlFile} >> sql_validation.log
        #       #cat sql_validation.log
        #       exit_state=1
	#elif
	if [ $(grep "Analyzing file - ${sqlFile}" sql_validation.log | wc -l) -eq 1 ] && [ $(cat sql_validation.log | wc -l) -lt 3 ]
		then
                echo "${sqlFile} validation for special symbols successful"
        else
                echo "ERROR: Special symbols present in ${sqlFile}. Please verify logs."
                cat sql_validation.log
                exit_state=1
        fi
	echo "exit_State=$exit_state"	
done
exit $exit_state
