#! /bin/sh
environment=$1
export JAVA_HOME=/opt/tibco/tmp/TIL_TEMP/java/jdk1.7.0_80

for sqlFile in ${WORKSPACE}/*.sql; do
		# Validate for special symbols in sql Files.
	echo "##Executing validate_sql.sh##"
        cmd="java -jar ValidateScripts.jar ${sqlFile}"
        eval ${cmd} 2>&1 | tee sql_validation.log
		
		# Ignore lines matching the lines in ignorefile.
		cat ignorefile | grep -v '^$' | while read line
		do
				grep -vF "${line}" sql_validation.log >temp
				mv temp sql_validation.log
				#sed -i "/${line}/Id" errorlog
		done
		
		
        if [ $(grep "Analyzing file - ${sqlFile}" sql_validation.log | wc -l) -eq 1 ] && [ $(cat sql_validation.log | wc -l) -lt 3 ]; then
                echo "${sqlFile} validation for special symbols successful"
        else
                echo "ERROR: Special symbols present in ${sqlFile}. Please verify logs."
                cat sql_validation.log
                exit 1
        fi
		
		# Validate SQL file naming convention
        chk=`echo ${sqlFile} | grep -i "DB_roll.*.sql"`
		if [[ -z "$chk" ]];then
			echo "ERROR: ${sqlFile} file name is not as per standard. Please check"
            exit 1
        fi
		
		# Validate DB configuration exists in environment configurations		
		dbName=$(echo ${sqlFile} | sed 's/_/\n/g' | grep "DB")
        if [[ ! -f "`pwd`/TIL_CONFIG/SQL_Common_Configuration/${environment}/${environment}_${dbName}.properties" ]];then
                echo "ERROR: ${environment}_${dbName}.properties file does not exist. Please check"
				exit 1
        fi
		unset chk
		unset dbName
done
