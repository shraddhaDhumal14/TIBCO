NO_OF_LINES=$(ps -ef | grep Xvfb | wc -l)
if [ $NO_OF_LINES == 2 ]
then
	echo "Xvfb already running"

else
	cd /opt/tibco/tmp/TIL_TEMP/Xvfb/bin/
	./startX  > /dev/null 2>&1 &
	cd -
fi
