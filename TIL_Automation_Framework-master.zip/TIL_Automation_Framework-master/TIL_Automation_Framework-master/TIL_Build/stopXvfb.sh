PR_NO=$(ps -ef | grep Xvfb | head -1 | awk -F" " '{print $2}')
kill -9 $PR_NO
