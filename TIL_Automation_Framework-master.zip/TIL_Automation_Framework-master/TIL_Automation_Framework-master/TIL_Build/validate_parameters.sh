#! /bin/sh
# This script is to validate input parameters for valid inputs. Fail the build if any invalid parameter is passed.
#TIL_ARCHIVEFILE="ContactChannelManagement-Misc;CustomerContactManagement-LegacyWrapper;PaymentMethodsManagement"
# Validate engine names.
for engine in $(echo ${TIL_ARCHIVEFILE} | tr ";" "\n")
do
        file="${engine}.archive"
        if [ ! -f "./TIL_SOURCE/Build/$file" ];then
                echo "ERROR: ${engine} not in Project Build Directory. Please check for valid build name"
                exit 1
        fi
done
