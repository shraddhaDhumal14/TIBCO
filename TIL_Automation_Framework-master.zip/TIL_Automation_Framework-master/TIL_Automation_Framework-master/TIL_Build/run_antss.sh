#! /bin/sh +x
./setenvs.sh
#/opt/tibco/tpcl/5.10/ant/1.6/bin/ant -f tilbuildpatch_Unix.xml
/opt/tibco/tmp/TIL_TEMP/tpcl/5.12/ant/1.10/bin/ant -f tilbuildpatch_Unix.xml -logfile EAR_BUILD.log
awk '!/BUILD SUCCESSFUL/' EAR_BUILD.log > temp && mv temp EAR_BUILD.log
cat EAR_BUILD.log
#/opt/tibco/tmp/TIL_TEMP/tpcl/5.10/ant/1.6/bin/ant -f tilbuildpatch_Unix.xml
