rm buildprojlib.properties
echo "In CreateBuildProp.sh"
cd ./projlib
cvs -d :pserver:sseernam:qaz_1234@10.33.53.170:/cvs checkout TIL_DELIVERY01/designer/projlib.properties
cd -
sed -i 's/C\\:\\\\cvsdir\\\\//g' ./projlib/TIL_DELIVERY01/designer/projlib.properties
sed -i 's/c\\:\\\\cvsdir\\\\//g' ./projlib/TIL_DELIVERY01/designer/projlib.properties
sed -i 's/\\\\/\//g' ./projlib/TIL_DELIVERY01/designer/projlib.properties
#dos2unix TIL_DELIVERY01/designer/projlib.properties
#echo "HOMEDIR $1"
#echo "$2 Checkout Tag"
PRESENT_PATH=`pwd`
echo "Present PATH is:${PRESENT_PATH}"
#cvs co -r $2 -p $1/.designtimelibs > /opt/tibco/build_script/DesigntimeLibs_Temp/.designtimelibs
#dos2unix /opt/tibco/build_script/DesigntimeLibs_Temp/.designtimelibs
cat ${PRESENT_PATH}/TIL_SOURCE/.designtimelibs | egrep -v "#" | while read line
do
        p2=$(echo $line | awk -F"=" '{print $2}')
        path=$(grep $p2"=" ./projlib/TIL_DELIVERY01/designer/projlib.properties | awk -F"=" '{print $2}')
        echo $p2"="$path >>buildprojlib.properties
        cd ./projlib/
        echo "cvs -d :pserver:sseernam:qaz_1234@10.33.53.170:/cvs checkout $path" > temp.sh
        chmod +x temp.sh
        #dos2unix temp.sh
        sh temp.sh
        cd -
done

#sed -i 's/=/=\/opt\/tibco\/.jenkins\/workspace\/test_tilBuild\/projlib\//g' buildprojlib.properties
sed -i "s|=|=${PRESENT_PATH}\/projlib\/|g" buildprojlib.properties