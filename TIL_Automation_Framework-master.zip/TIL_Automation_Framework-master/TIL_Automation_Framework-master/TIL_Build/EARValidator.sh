#! /bin/sh +x
#########DO NOT MODIFY THIS SCRIPT########

for engine in $(echo "${TIL_ARCHIVEFILE}" | tr ";" "\n")
do	
	chk=""
	ignore_chk="false"
	if [[ -f ./Ignore_Validation_Engines ]]; then 
		chk=$(grep -w "^${engine}$" Ignore_Validation_Engines)
		[[ ! -z "${chk}" ]] && ignore_chk="true"
	fi
	
	if [[ "${ignore_chk}" == "true" ]]; then 
		echo "INFO: Engine ${engine} is presnet in Ignore_Validation_Engines file and skipping EAR Validation."
	else
		export PATH=/opt/tibco/designer/5.10/bin/:$PATH
		export DISPLAY=uktilahr:1.0
		export CLASSPATH=${WORKSPACE}/EARValidator/ValidateEAR.jar:$CLASSPATH

		/opt/tibco/tpcl/5.7/ant/1.6/bin/ant -f EARValidator.xml >> Validation.log
		date >> Validation.log
		echo "Validation Done" >> Validation.log

		#echo "Deleting the temporary directory" >> Validation.log
		#cd ${WORKSPACE}/EARValidation
		#rm -rf ./*
		#echo "Temporary Directory Deleted" >> Validation.log
		#cd -

		# Now validate EAR log for unknown errors.

		cat Validation.log | egrep -i "error |errors |ERROR: |ERRORS: "  >errorlog
		count_init=`cat errorlog | wc -l`
		cat ignorefile | while read line
		do
				grep -vF "${line}" errorlog >temp
				mv temp errorlog
				#sed -i "/${line}/Id" errorlog
		done
		count_final=`cat errorlog | wc -l`
		if [ "${count_final}" != 0 ];then
			echo "ERROR: EAR Validation failed. Please Validate erros in validation log"
			echo "ERROR: Validation log path: ${WORKSPACE}/Validation.log"
			exit 1
		else
			echo "EAR Validation successful"
			exit 0
		fi
	fi
done
