#! /bin/sh
for engine in $(echo "${TIL_ARCHIVEFILE}" | tr ";" "\n")
do
	
	prev_ear_version=`cat tilbuild.properties | grep -e "til.${engine}.curver" | cut -d ' ' -f 2 | tr -d ' '`
	cur_ear_version=`cat tilbuild.properties | grep -e "til.${engine}.nextver" | cut -d ' ' -f 2 | tr -d ' '`
	prod_ear_version=`cat tilbuild.properties | grep -e "til.${engine}.prodver" | cut -d ' ' -f 2 | tr -d ' '`
	
	current_ear_name=`ls "${WORKSPACE}"/EAR_BUILD | grep -e "${engine}-${cur_ear_version}"`
	if [ "${current_ear_name}" = "" ]; then
		echo "ERROR: There is no current EAR version. Exiting..."
		exit 1
	fi
	
	echo "current_ear_name is:${current_ear_name}"
	if [ "${prev_ear_version}" != "NONE" ]; then 
			previous_ear_name=`ls "${WORKSPACE}"/PREV_EARS | grep -e "${engine}-${prev_ear_version}"`
			echo "previous_ear_name is:${previous_ear_name}"
	fi
	
	if [ "${prod_ear_version}" != "NONE" ];then
		prod_ear_name=`ls "${WORKSPACE}"/PREV_EARS | grep -e "${engine}-${prod_ear_version}"`
		echo "prod_ear_name is:${prod_ear_name}"
	fi
	
	if [ ! -z ${previous_ear_name} ];then
		diff_cmd="./EARDiff_Run.sh ${WORKSPACE}/PREV_EARS/${previous_ear_name} ${WORKSPACE}/EAR_BUILD/${current_ear_name} ${WORKSPACE}/${engine}-${cur_ear_version}_diff"
		eval "${diff_cmd}"
	else
		echo -e "INFO: Previous EAR file for ${engine} is not present" >>"${WORKSPACE}"/"${engine}"-"${cur_ear_version}"_diff
	fi
	
	if [ ! -z ${prod_ear_name} ];then
		diff_cmd="./EARDiff_Run.sh ${WORKSPACE}/PREV_EARS/${prod_ear_name} ${WORKSPACE}/EAR_BUILD/${current_ear_name} ${WORKSPACE}/${engine}-${cur_ear_version}-PROD_diff"
		eval "${diff_cmd}"
	else
		echo -e "INFO: PROD EAR file for ${engine} is not present" >>"${WORKSPACE}"/"${engine}"-"${cur_ear_version}"-PROD_diff
	fi	
done
