#! /bin/sh
echo "--------------------------------------------------------------------------------------------------------------------------" 
filename="DEV_${DEV_TAG}"
echo "Filename is:$filename"
touch "${WORKSPACE}/${filename}"
echo "--------------------------------------------------------------------------------------------------------------------------"  >${WORKSPACE}/${filename}
echo "			                       BUILD DETAILS		                         " >>${WORKSPACE}/${filename}
echo "--------------------------------------------------------------------------------------------------------------------------"  >>${WORKSPACE}/${filename}
echo "DEV_${DEV_TAG}: [ ${TIL_BUILDTYPE} ]" >>${WORKSPACE}/${filename}
echo "DEV_TAG: ${DEV_TAG}" >>${WORKSPACE}/${filename}
echo "JIRA_NUMBER: ${IRIS_NUMBER}" >>${WORKSPACE}/${filename}
if [ ! -z "${DEFECT_NUMBER}" ];then
	echo "DEFECT_NUMBER: ${DEFECT_NUMBER}" >>${WORKSPACE}/${filename}
fi
echo "TIL_TYPE: ${TIL_TYPE}" >>${WORKSPACE}/${filename}
if [ ! -z "${TIL_MODULE}" ];then
	echo "MODULE_NAME: ${TIL_MODULE}" >>${WORKSPACE}/${filename}
fi
echo "PROJECTNAME: ${PROJECTNAME}" >>${WORKSPACE}/${filename}
echo "TIL_BUILDTYPE: ${TIL_BUILDTYPE}" >>${WORKSPACE}/${filename}
echo "Requested By: ${BUILD_REQUESTER}" >>${WORKSPACE}/${filename}
echo "Engine: ${TIL_ARCHIVEFILE}" >>${WORKSPACE}/${filename}
echo "TIL_TRAVERSION: ${TIL_TRAVERSION}" >>${WORKSPACE}/${filename}

echo "--------------------------------------------------------------------------------------------------------------------------"  >>${WORKSPACE}/${filename}
#git log --name-status --pretty=format:"%h; author: %cn; date: %ci; subject:%s" v1.2...v1.0
# To show git log from previous commit
#git log -1 --name-status --pretty=format:"%h; author: %cn; date: %ci; subject:%s"
echo "                                         CHANGE LOG                                     " >>${WORKSPACE}/${filename}
echo "JIRA_DESCRIPTION: ${IRIS_DESCRIPTION}" >>${WORKSPACE}/${filename}
echo "--------------------------------------------------------------------------------------------------------------------------"  >>${WORKSPACE}/${filename}
if [ ! -z "${MODIFIED_FILES}" ];then
	echo "--------------------" >>${WORKSPACE}/${filename}
	echo "Modified Files List:" >>${WORKSPACE}/${filename}
	echo "--------------------" >>${WORKSPACE}/${filename}
	echo "${MODIFIED_FILES}" >>${WORKSPACE}/${filename}
fi

if [ ! -z "${DELETED_FILES}" ];then
	echo "--------------------" >>${WORKSPACE}/${filename}
	echo "DELETED Files List:" >>${WORKSPACE}/${filename}
	echo "--------------------" >>${WORKSPACE}/${filename}
	echo "${DELETED_FILES}" >>${WORKSPACE}/${filename}
fi

#PREV_DEV_TAG=`git tag | sort -n | sed "/${DEV_TAG}/q" | tail -2 | head -1`
#echo "Previous Dev tag is: DEV_${RELEASE}_${PREV_DEV_TAG}"
#git --git-dir=${WORKSPACE}/TIL_SCRUM/.git/ log -1 --name-status --pretty=format:"author: %cn; date: %ci; subject:%s; %h" >>${WORKSPACE}/${filename}

echo "--------------------------------------------------------------------------------------------------------------------------"  >>${WORKSPACE}/${filename}
echo "ENGINE NAME: PREVIOUS VERSION: CURRENT VERSION: PRODUCTION VERSION" >>${WORKSPACE}/${filename}
echo "--------------------------------------------------------------------------------------------------------------------------"  >>${WORKSPACE}/${filename}