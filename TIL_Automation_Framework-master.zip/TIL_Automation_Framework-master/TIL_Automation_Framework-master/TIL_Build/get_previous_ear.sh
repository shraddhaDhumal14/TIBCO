#! /bin/sh +x
BRANCH="${RELEASE}"
ENGINES="${TIL_ARCHIVEFILE}"

#BRANCH="CCS18.1"
#ENGINES="ContactChannelManagement-Misc;EventHandling-AS;CustomerManagement-EDGE-QAS;DataCollection-Misc;TechnologyResourceProvisioning-Misc;LeadAndProspectManagement-Misc"

for engine in $(echo ${ENGINES} | tr ";" "\n")
do
	echo "Engine name is:${engine}"
	PREV_IRIS_NUMBER=`cat "/opt/tibco/.jenkins/workspace/TIL_PIPELINES/BUILD_HISTORY/${BRANCH}_BuildHistory" | grep -e "${engine}" -B 6 | grep -e "IRIS_NUMBER" | tail -1 | cut -d ':' -f 2 | tr -d ' '`
	if [ ! -z ${PREV_IRIS_NUMBER} ];then
		echo "PREV_IRIS_NUMBER for ${engine} is: ${PREV_IRIS_NUMBER}"
		ANSIBLE_CMD="/usr/bin/ansible-playbook get_nexus_artefact.yml --extra-vars='engine=${engine}_${DEV_TAG} IRIS_NUM=${PREV_IRIS_NUMBER}'"
		echo "Ansible command is: ${ANSIBLE_CMD}"
		eval "${ANSIBLE_CMD}"
	else
		echo "Previous EAR file for ${engine} is not existing."
	fi
done  
