#! /bin/sh
# Variable declaration and initialization
PRESENT_PATH=`pwd`
REPO_NAME="TIL_FRAMEWORK"

rm -rf buildprojlib.properties
rm -rf projlib

# Create projlib designer directory to fetch projlib.properties file.

if [ ! -d "${PRESENT_PATH}/projlib/TIL_DELIVERY01/designer" ];then
                        mkdir -p "${PRESENT_PATH}/projlib/TIL_DELIVERY01/designer"
fi

# Get projlib.properties file from NEXUS initially

cmd="curl -X GET -u admin:admin123 http://195.233.197.150:8081/repository/${REPO_NAME}/TIL_DELIVERY01/designer/projlib.properties"
eval ${cmd} >"${PRESENT_PATH}"/projlib/TIL_DELIVERY01/designer/projlib.properties
missing_projlibs="False"
#cat "${PRESENT_PATH}"/TIL_SOURCE/.designtimelibs | egrep -v "#" | while read line
while read line
do
        p2=$(echo $line | awk -F"=" '{print $2}')
        path=$(grep $p2"=" "${PRESENT_PATH}/projlib/TIL_DELIVERY01/designer/projlib.properties" | tail -1 | awk -F"=" '{print $2}')
        if [[ -z $path ]];then
                echo "ERROR: Projlib for $p2 is not present in Nexus Framework. Please update Framework with latest Projlibs"
                exit 1
        fi
        echo $p2"="$path >>buildprojlib.properties


                projlib_dir=$(dirname "${path}")
                projlib_file=$(basename "${path}")

                # First check whether the projlib exists in Nexus repository. If not fail the build with error.
                chk_cmd="curl -o /dev/null --silent -Iw '%{http_code}' -u admin:admin123 http://195.233.197.150:8081/repository/${REPO_NAME}/${path}"
                if [[ `eval ${chk_cmd}` != 200 ]]; then
                                echo "ERROR: projlib is not available at http://195.233.197.150:8081/repository/${REPO_NAME}/${path}. Please check for errors."
                                missing_projlibs="True"
                else
                                cmd="curl -X GET -u admin:admin123 http://195.233.197.150:8081/repository/${REPO_NAME}/${path}"
                                if [ ! -d "${PRESENT_PATH}/projlib/${projlib_dir}" ];then
                                                mkdir -p "${PRESENT_PATH}/projlib/${projlib_dir}"
                                fi
                                eval ${cmd} > "${PRESENT_PATH}/projlib/${projlib_dir}/${projlib_file}"
                                if [ $? -ne 0 ]; then
                                                 echo "ERROR: Projlib is not present in Nexus Framework: http://195.233.197.150:8081/repository/${REPO_NAME}/${path}"
                                                 missing_projlibs="True"
                                fi
                fi

done <<< "$(cat "${PRESENT_PATH}"/TIL_SOURCE/.designtimelibs | egrep -v "#")"
#done
echo "DEBUG: Missing projlibs status is: ${missing_projlibs}"
[[ "${missing_projlibs}" != "False" ]] && { echo "ERROR: Some projlibs are missing in Nexus. Please see the logs for missing projlibs"; exit 1; }
sed -i "s|=|=${PRESENT_PATH}\/projlib\/|g" buildprojlib.properties
