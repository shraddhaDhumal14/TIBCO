#! /bin/sh

echo "DEBUG: Common Engines are: ${COMMON_ENGINES}"
touch tilbuild.properties
echo "til.type ${TIL_TYPE}" >tilbuild.properties
echo "til.projectname ${TIL_PROJECTNAME}" >>tilbuild.properties
echo "til.archivefile ${TIL_ARCHIVEFILE}" >>tilbuild.properties
echo "til.buildtype ${TIL_BUILDTYPE}" >>tilbuild.properties
echo "til.traversion ${TIL_TRAVERSION}" >>tilbuild.properties
echo "til.workspace ${WORKSPACE}" >>tilbuild.properties
echo "til.devtag ${DEV_TAG}" >>tilbuild.properties
echo "til.bwversion ${BW_VERSION}" >>tilbuild.properties
for engine in $(echo ${TIL_ARCHIVEFILE} | tr ";" "\n")
do
		curver=`cat DEV_${DEV_TAG} | grep -e "${engine}:" | tail -1 | cut -d ':' -f 2 | tr -d ' '`
		nextver=`cat DEV_${DEV_TAG} | grep -e "${engine}:" | tail -1 | cut -d ':' -f 3 | tr -d ' '`
		prodver=`cat DEV_${DEV_TAG} | grep -e "${engine}:" | tail -1 | cut -d ':' -f 4 | tr -d ' '`
		
		if [ -z "${nextver}" ];then
			echo "ERROR: Failed to get next version for ${engine}. So, Failing the build"
			exit 1
		fi
		
		echo "til.${engine}.curver ${curver}" >>tilbuild.properties
		echo "til.${engine}.nextver ${nextver}" >>tilbuild.properties
		if [ "${prodver}" != "NONE" ];then
				echo "til.${engine}.prodver ${prodver}" >>tilbuild.properties
		else
				echo "til.${engine}.prodver NONE" >>tilbuild.properties
		fi
		
		#Generate pom file for each engine.
		touch ${engine}.pom
		
		for common_engine in $(echo ${COMMON_ENGINES} | tr ',' '\n')
		do 
			#Generate DEV APPCONF file for each engine.
			echo "earFileName=${common_engine}-${nextver}.ear" >${common_engine}.appconf
			echo "AppType=BW${BW_VERSION//.}" >>${common_engine}.appconf
			echo "CVSVersion=${nextver}" >>${common_engine}.appconf
			echo "description=${PROJECT_DESCRIPTION}" >>${common_engine}.appconf
			echo "FolderName=" >>${common_engine}.appconf
			echo "releaseName=Release ${RELEASE}" >>${common_engine}.appconf
			echo "${engine}.par.MaxHeapSize=" >>${common_engine}.appconf
			echo "${engine}.par.LogfileCount=" >>${common_engine}.appconf
			echo "${engine}.par.LogfileSize=" >>${common_engine}.appconf
			echo "${engine}.par.threadCount=" >>${common_engine}.appconf
			echo "${engine}.par.appendClasspath=" >>${common_engine}.appconf
			echo "${engine}.par.prependClasspath=" >>${common_engine}.appconf
			echo "${engine}.par.initHeapSize=" >>${common_engine}.appconf
			echo "${engine}.par.threadStackSize=" >>${common_engine}.appconf
			echo "${engine}.par.enablePar=true" >>${common_engine}.appconf
			echo "${engine}.par.isFT=false" >>${common_engine}.appconf
			echo "${engine}.par.FTWeight=" >>${common_engine}.appconf
			echo "${engine}.par.FTHeartbeatInterval=" >>${common_engine}.appconf
			echo "${engine}.par.FTActivationInterval=" >>${common_engine}.appconf
			echo "${engine}.par.FTPreperationDelay=" >>${common_engine}.appconf
			echo "${engine}.par.instanceCount=4" >>${common_engine}.appconf
		done
done
