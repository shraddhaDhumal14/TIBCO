#! /bin/sh
BRANCH="${RELEASE}"
ENGINES="${TIL_ARCHIVEFILE}"
URL="${NEXUS_URL}"
REPO="${LT_REPO}"
PROD_REPO="${PROD_REPO}"
GROUPID="${TIL_GROUPID}"
NEXUS_UNAME="${NEXUS_USERNAME}"
NEXUS_PWORD="${NEXUS_PASSWORD}"
majorVersion=`echo "${BRANCH}" | awk -F 'CCS' '{print $2}' | cut -d '.' -f 1 | tr -d ' '`
minorVersion=`echo "${BRANCH}" | awk -F 'CCS' '{print $2}' | cut -d '.' -f 2 | tr -d ' '`
echo "Minor Version is:${minorVersion}"

get_prod_version(){

	#Function to get PROD_VERSION for the engine given.
	engine=$1
	ver="0"
	majv=$2
	minv=$3
	minv_sub=$4
	base_maj="19"
	while (( ${majv} >= ${base_maj} ))
	do
		while (( ${minv_sub} >= 0 ))
		do
			cmd="curl -s -X GET \"http://${URL}/service/rest/v1/search?repository=${PROD_REPO}&name=${GROUPID}/${engine}/${majv}_${minv}_*/${engine}-${majv}_*.ear\""
			eval ${cmd} >nex_output
			# [CICD-349: Fix] Fixed pagination error.
			continuationToken=$(grep 'continuationToken' nex_output | tail -1 | cut -d ':' -f 2 | tr -d ' ' | sed 's/\"//g')
			
			while [[ "${continuationToken}" != "null" ]]
			do
				cmd="curl -s -X GET \"http://${URL}/service/rest/v1/search?repository=${PROD_REPO}&name=${GROUPID}/${engine}/${majv}_${minv}_*/${engine}-${majv}_*.ear&continuationToken=${continuationToken}\""
				eval ${cmd} >>nex_output
				continuationToken=$(grep 'continuationToken' nex_output | tail -1 | cut -d ':' -f 2 | tr -d ' ' | sed 's/\"//g')
			done			
	
			if [[ "${majv}" == "${majorVersion}" ]] && [[ "${minv}" == "${minorVersion}" ]]; then 
				ver=`cat nex_output | grep -e "name" | grep "${engine}.*-${majv}_${minv}_[0-9]*.ear\"" | sort -V | tail -1 | cut -d '/' -f 3 | tr -d ' '`
			else
				ver=`cat nex_output | grep -e "name" | grep "${engine}.*.ear\"" | sort -V | tail -1 | cut -d '/' -f 3 | tr -d ' '`
			fi
			
			if [[ $ver ]]; then
				break;
			elif [[ "${minv}" == *_* ]]; then
				minv="${minv_sub}"
			else
				minv=$(( minv-1 ))
				minv_sub=$(( minv_sub-1 ))
			fi
			
		done
		[[ $ver ]] && break || { minv="12"; minv_sub="12"; majv=$(( majv-1 )); }
	done
	[[ $ver ]] && echo "$ver" || echo "NONE"
}


get_version(){

# Function to get current version in Nexus Repository.
        engine=$1
        majv=$2
        minv=$3
        minv_sub=$4
	    base_maj="19"
		ver="0"
		while (( ${majv} >= ${base_maj} ))
		do
			while (( ${minv_sub} >= 0 ))
			do
				cmd="curl -s -X GET \"http://${URL}/service/rest/v1/search?repository=${REPO}&name=${GROUPID}/${engine}/${majv}_${minv}_*/${engine}-${majv}_*.ear\""
				eval ${cmd} >nex_output
				
				# [CICD-349: Fix] Fixed pagination error.
				continuationToken=$(grep 'continuationToken' nex_output | tail -1 | cut -d ':' -f 2 | tr -d ' ' | sed 's/\"//g')
				
				while [[ "${continuationToken}" != "null" ]]
				do
					cmd="curl -s -X GET \"http://${URL}/service/rest/v1/search?repository=${REPO}&name=${GROUPID}/${engine}/${majv}_${minv}_*/${engine}-${majv}_*.ear&continuationToken=${continuationToken}\""
					eval ${cmd} >>nex_output
					continuationToken=$(grep 'continuationToken' nex_output | tail -1 | cut -d ':' -f 2 | tr -d ' ' | sed 's/\"//g')
				done				
				
				if [[ "${majv}" == "${majorVersion}" ]] && [[ "${minv}" == "${minorVersion}" ]]; then 
					ver=`cat nex_output | grep -e "name" | grep "${engine}.*-${majv}_${minv}_[0-9]*.ear\"" | sort -V | tail -1 | cut -d '/' -f 3 | tr -d ' '`
				else
					ver=`cat nex_output | grep -e "name" | grep "${engine}.*.ear\"" | sort -V | tail -1 | cut -d '/' -f 3 | tr -d ' '`
				fi
				
				if [[ $ver ]]; then
						break;
				elif [[ "${minv}" == *_* ]]; then
					minv="${minv_sub}"
				else
					minv=$(( minv-1 ))
					minv_sub=$(( minv_sub-1 ))
				fi
			done
			[[ $ver ]] && break || { minv="12"; minv_sub="12"; majv=$(( majv-1 )); }
		done
		[[ $ver ]] && echo "$ver" || echo "NONE"
}

#BRANCH="CCS18.1"
#ENGINES="ContactChannelManagement-Misc;EventHandling-AS;CustomerManagement-EDGE-QAS;DataCollection-Misc;TechnologyResourceProvisioning-Misc;LeadAndProspectManagement-Misc"

for engine in $(echo ${ENGINES} | tr ";" "\n")
do
        echo "Engine name is:${engine}"
		minv_trim=$(echo ${minorVersion} | cut -d '_' -f 1 | tr -d ' ')
        cur_version=$(get_version "$engine" "$majorVersion" "$minorVersion" "${minv_trim}")
        echo "DEBUG: cur_version in NEXUS is: ${cur_version}"
		cur_prod_ver=$(get_prod_version "$engine" "$majorVersion" "$minorVersion" "${minv_trim}")
		echo "DEBUG: cur_prod_version in NEXUS is: ${cur_prod_ver}"
        # If current version is other than Major version, and minorVersion then for next version reset to majorVersion_minorVersion_0
        seq_num=(`echo ${cur_version} | sed 's/_/\n/g' | tail -1 | tr -d ' '`)
		if [[ "${cur_version}" == "${majorVersion}_${minorVersion}"_* ]] ; then
                next_version="${majorVersion}_${minorVersion}_$(( seq_num + 1))"
        else
                next_version="${majorVersion}_${minorVersion}_1"
        fi
        echo "${engine}: ${cur_version}: ${next_version}: ${cur_prod_ver}" >>DEV_${DEV_TAG}

        # Get current latest version from nexus compared to major and minor version.

        if [ "${cur_version}" != "NONE" ];then
                echo "previous latest version for ${engine} in nexus is: ${cur_version}"
                ANSIBLE_CMD="/usr/bin/ansible-playbook get_nexus_artefact.yml --extra-vars='GROUPID=${GROUPID} ENGINE=${engine} VERSION=${cur_version} REPO_URL=http://${URL}/repository/${REPO} UNAME=${NEXUS_UNAME} PWORD=${NEXUS_PWORD}'"
                echo "Ansible command is: ${ANSIBLE_CMD}"
                eval "${ANSIBLE_CMD}"
        else
                echo "Previous EAR file for ${engine} is not existing."
        fi

                #Get current PROD version from nexus.

        if [ "${cur_prod_ver}" != "NONE" ];then
                echo "Previous PRODUCTION version for ${engine} in nexus is: ${cur_prod_ver}"
                ANSIBLE_CMD="/usr/bin/ansible-playbook get_nexus_artefact.yml --extra-vars='GROUPID=${GROUPID} ENGINE=${engine} VERSION=${cur_prod_ver} REPO_URL=http://${URL}/repository/${PROD_REPO} UNAME=${NEXUS_UNAME} PWORD=${NEXUS_PWORD}'"
                echo "Ansible command is: ${ANSIBLE_CMD}"
                eval "${ANSIBLE_CMD}"
        else
                echo "Previous PROD EAR file for ${engine} is not existing."
        fi
done

