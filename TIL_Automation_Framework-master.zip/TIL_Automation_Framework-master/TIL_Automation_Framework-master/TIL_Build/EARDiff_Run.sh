file1=$1
file2=$2
outputfile=$3

##java -cp /d01/tibco/EARDiff/EARDiff.jar:/d01/tibco/EARDiff/commons-cli-1.0.jar zipdiff/Main -file1 $file1 -file2 $file2 -outputfile $outputfile
diff_cmd="java -cp ${WORKSPACE}/EARDiff/EARDiff.jar:${WORKSPACE}/EARDiff/commons-cli-1.0.jar:${WORKSPACE}/EARDiff/tibBWDetailedDiff.jar com.hp.ear.utils.eardiff.DetailedDiff -firstfile $file1 -secondfile $file2 -outputfile $outputfile"

#java -cp ./EARDiff/EARDiff.jar:./EARDiff/commons-cli-1.0.jar:./EARDiff/tibBWDetailedDiff.jar com.hp.ear.utils.eardiff.DetailedDiff -firstfile $file1 -secondfile $file2 -outputfile $outputfile

eval "${diff_cmd}"
echo "EARDiff Done"
