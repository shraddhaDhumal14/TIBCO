#!/bin/bash
Bus=''
EMSDetails=`cat ems.properties`
propFile=`pwd`/ems.properties
abortFlag="false"
emsUser=""
emsPwd=""
EMS_HOME=""
EMS_PREFIX=""
if [[ -f   logs/$2"_EMS.log" ]]
then
	echo "###############################################################################################################################################################################################" >> logs/$2"_EMS-1.log"
	date >> logs/$2"_EMS-1.log"
	echo "###############################################################################################################################################################################################" >>  logs/$2"_EMS-1.log"

	`cat logs/$2"_EMS.log" >> logs/$2"_EMS-1.log"`
	`>  logs/$2"_EMS.log"`
fi

while read line
do
	name=`echo $line|awk 'BEGIN { FS = "=" }{ print $1 }'`
	value=`echo $line|awk 'BEGIN { FS = "=" }{ print $2 }'`
	if [ "$name" = "emsUser" ]
	then
		emsUser="$value"
	elif [ "$name" = "emsPwd" ]
	then
		emsPwd="$value"
	elif [ "$name" = "EMS_HOME" ]
	then
		EMS_HOME="$value"
	elif [ "$name" = "EMS_PREFIX" ]
	then
		EMS_PREFIX="VOD.UK."$value
	fi
done < $propFile


if [[ $1 == "-validate" ]]
then
	echo "validation ignored"

elif [[ $1 == "-deploy" ]]
then
        filePrefix="PR"
	scriptsPath=`pwd`/data
        dos2unix $scriptsPath/*.ems
elif [[ $1 == "-rollback" ]]
then
        filePrefix="Rollback"
	scriptsPath=`pwd`/data
        dos2unix $scriptsPath/*.ems
fi

URL=''
abortFlag="false"
for file in `ls $scriptsPath/$filePrefix*.ems`
do
	if [ $abortFlag == "false" ]
	then
		URL=''
		fName=file
		temp=${file##*-}
		Bus=${temp%.*}
		#echo "BusName from FileName:"$Bus
		while read line
		do
			BusName=`echo $line|awk 'BEGIN { FS = "=" }{ print $1 }'`
			if [ "$BusName" == "$Bus" ]
			then
				#echo "Line22:::"$Bus
				URL=`echo $line|awk 'BEGIN { FS = "=" }{ print $2 }'`
			fi
		done < $propFile
		
		#########################Get the Active EMS Instance from FT URL#######################

		IFS=", "
		read -r -a URLs<<< "$URL"
		ActiveInstance=''
		Flag="false"
		for ems in ${URLs[@]}
		do
		
			Status=`echo i|$EMS_HOME/bin/tibemsadmin $ems -user $emsUser -password $emsPwd|egrep 'State'|awk '{print $2}'`
			echo $Status
			if [[ "$Status" == "active" && "$Flag" == "false" ]]
			then
				ActiveInstance=$ems
				echo "Active Instance is "$ActiveInstance >>  logs/$2"_EMS.log"
				echo "################################################################################################################################################################################" >> logs/$2"_EMS.log"
				echo  "Starting Execution of Script "$file  >> logs/$2"_EMS.log"
				$EMS_HOME/bin/tibemsadmin -script $file -user $emsUser -password $emsPwd -server $ems >> logs/$2"_EMS.log"
				#`dos2unix logs/$2"_EMS.log logs/$2"_EMS.log`
				test=`tail -2 logs/$2"_EMS.log"|head -1`
				IFS='\r'
				read -r -a successlog <<< $test
				#echo "Line0:"${successlog[0]}
				IFS=''
				successlog[1]=`tail -1 logs/$2_"EMS.log"`
				#echo "Line1:"${successlog[1]}

				if [[ ${successlog[0]} == "Command: commit" && ${successlog[1]} == "Configuration has been saved" ]]
				then
					echo "################################################################################################################################################################################" >> logs/$2"_EMS.log"
					echo "Execution of Script "$file" is completed successfully" >> logs/$2"_EMS.log"
					abortFlag=false
				else
					#echo "################################################################################################################################################################################" >> logs/$2"_EMS.log"
					if [[ $1 == "-deploy" ]]
					then
					    #echo "Execution of Script "$file" has failed with Errors." >> logs/$2"_EMS.log"
						
						abortFlag=true
						
						echo "Execution of Script "$file" has failed with Errors. Please execute corresponding rollback scripts and then retry deployment after fixing the issue"
						
						Flag="true"
					  
					elif [[ $1 == "-rollback" ]]
					then
					
					   echo "Execution of Roll backScript "$file" failed. Ignore this failure since it is running rollback "
						
					fi
                
				fi
        
			fi
		done

	else
		if [[ $1 == "-deploy" ]]
		then
			echo "Aborting the EMS execution as one previous script failed with errors...." >> logs/$2"_EMS.log"
                        cat logs/$2"_EMS.log"
			exit 1
		elif [[ $1 == "-rollback" ]]
		then
                        
			exit 0
		fi
	fi
done

# Added by KS - if one file to deploy - then errors can pass through down here and we exit with a zero return code - so this fixes that bug
if [ $abortFlag == "true" ]
then
   exit 1
fi

cat logs/$2"_EMS.log"
