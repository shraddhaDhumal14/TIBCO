#!/bin/bash

redis_home=$1
tibco_home=$2
Ports=$3
ip_address=$4
cluster_command=""
> redis_config_logs
> clusterlogs
mkdir -p $redis_home/Cluster
chmod 777 $redis_home/Cluster

while IFS=':' read -ra p;
do
    for i in "${p[@]}";
    do
     echo "port number is $i"
	 mkdir -p $redis_home/Cluster/$i
	 chmod 766 $redis_home/Cluster/$i
	 cp $tibco_home/redis.conf $redis_home/Cluster/$i/redis.conf
	 sed -i "s|port_number|$i|g" $redis_home/Cluster/$i/redis.conf
	 sed -i "s|Redis_Home|$redis_home|g" $redis_home/Cluster/$i/redis.conf
	 if [[ "$i" == "7179" ]]
	 then
	    echo "save 900 1   # Snapshot every 900 seconds if at least 1 key changed" >> $redis_home/Cluster/$i/redis.conf
	    echo "dbfilename \"dump.rdb\" " >> $redis_home/Cluster/$i/redis.conf
	 fi
	 chmod 766 $redis_home/Cluster/$i/redis.conf
	 echo "redis.conf for port $i is created"
    done	
done <<< "$Ports"

while IFS=':' read -ra p;
do
    for i in "${p[@]}";
    do
     echo "port number is $i" >> redis_config_logs
	 cd $redis_home/Cluster/$i
	 pwd
	 redis-server ./redis.conf >> $tibco_home/redis_config_logs &
	 cd
    done
done <<< "$Ports"
