#!/bin/sh
if [[ "$#" -ne 4 ]]; then
	echo "All options are not passed to the script. Please pass the valid values."
	exit 1
fi

TRA_HOME=$1
domainName=$2
domainUser=$3
domainPW=$4

# Generate Applications.txt file for all the engines present in given domain.
cmd="${TRA_HOME}/bin/AppStatusCheck --propFile ${TRA_HOME}/bin/AppStatusCheck.tra -domain ${domainName} -user ${domainUser} -pw ${domainPW}"
echo "DEBUGL command is: ${cmd}"
eval "${cmd}" >temp_app_list 2>&1
if [[ -f ./temp_app_list ]]; then 
	cat ./temp_app_list | grep "Deployment Status: Success" -B 3 | grep "Application Name:" | cut -d ':' -f 2 | tr -d ' ' >Applications.txt
else 
	echo "DEBUG: Not able to generate applist file. please check"
	exit 1
fi

# Fail the script and pipeline if Applications.txt file is not generated properly. Assume there is admin issue if this fails.
if [[ ! -s "Applications.txt" ]]; then
	echo "DEBUG: Applications.txt file is not generated properly. Please check admin status"
	exit 1
fi


