domain=$1
echo "" > "${domain}.html"
style=true
for file in Stub_Status_${domain}_*.html;do
      if $style
      then
          style=false
          sed -n '/<head/,/\/thead>/p' $file >> "${domain}.html"
      fi
      sed -n '/<tbody/,/tbody>/p' $file >> "${domain}.html"
done
echo "</body></table>" >> "${domain}.html"
