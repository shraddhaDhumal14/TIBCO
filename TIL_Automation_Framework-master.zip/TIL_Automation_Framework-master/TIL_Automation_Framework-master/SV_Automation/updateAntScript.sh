base_dir=`echo "$1" | sed "s,/,\\\\\/,g"`
environment=$2
for file in *.xml;
do
    grep -q 'environment=\".*\" project' ${file} && sed -i "s/environment=\".*\" project/environment=\"${environment}\" project/g" ${file}
    grep -q 'basedir=\".*\" ' ${file} && sed -i "s/basedir=\".*\" /basedir=\"${base_dir}\" /g" ${file}
    echo "Updated Ant Script ${file}";
done
