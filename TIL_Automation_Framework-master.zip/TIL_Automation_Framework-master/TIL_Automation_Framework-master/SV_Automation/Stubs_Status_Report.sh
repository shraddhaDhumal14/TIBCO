base_dir=$1
ant_dir=$2
for line in $(cat envlist.txt)
do
    sh updateAntScript.sh $base_dir $line
    $ant_dir/ant -f Stubs_Status_Report_ByEnvironment.xml
done

