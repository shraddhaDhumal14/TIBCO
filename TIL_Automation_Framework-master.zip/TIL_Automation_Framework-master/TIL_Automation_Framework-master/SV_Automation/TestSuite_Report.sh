file=$1
status=`grep 'BUILD' "$file".output | tail -1 | cut -f2 -d " "`
test=`grep 'tests executed' "$file".output | cut -f3 -d"]"`
error=`grep 'Buildfile:.*does not exist!' "$file".output`
if [ -z "$status" ]
then
    echo "$file --> $test$error"  >> TestSuite_Summary.log
else
    echo "$file($status) --> $test$error"  >> TestSuite_Summary.log
fi
