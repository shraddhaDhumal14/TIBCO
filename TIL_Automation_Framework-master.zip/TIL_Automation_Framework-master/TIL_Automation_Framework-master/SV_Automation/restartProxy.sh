cd /home/tibco/IBM/RationalTestControlPanel/httptcp/

PROCESS_NAME="ghproxy.jar"
PR_NO=$(ps -ef | grep $PROCESS_NAME | grep -v grep | awk '{print $2}')
echo "$PR_NO"
if [ -z "$PR_NO" ]; then
   echo "Proxy is not running……"
else
   kill -9 $PR_NO
   echo "Proxy was stopped successfully…."
fi

echo "Starting the proxy …."
nohup sh /home/tibco/IBM/RationalTestControlPanel/httptcp/startup.sh &

sleep 30
PR_NO=$(ps -ef | grep $PROCESS_NAME | grep -v grep | awk '{print $2}')
echo "$PR_NO"
if [ -z "$PR_NO" ]; then
    echo "Proxy is not running, Please validate the registration.xml file for correctness and restart manually…"
else
    echo "Proxy was started successfully and it is running…."
fi
