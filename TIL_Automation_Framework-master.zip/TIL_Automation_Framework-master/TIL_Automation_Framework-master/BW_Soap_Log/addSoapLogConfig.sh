# config_file = Engine Config file
# log_config_file = config to add to engine config file to generate log
engine_config_file=$1   
extra_config_file=$2
cicd_comments=true
while IFS= read -r line
do
   #echo "$line"
   if grep -qFx "$line" "$engine_config_file";
   then
       #echo "$line : Config Exist so skipping"              
       :
   else
       echo "$line :Config doesnot exist"
       config=`echo $line | cut -d "=" -f1`
       echo "$config"
       if grep -q "^$config=" "$engine_config_file"; 
       then 
            echo "Config exist with Different value"
            sed -ie "s/^${config}=*/#&/" "$engine_config_file"
       fi
       if [ "$cicd_comments" = true ]; then
             #echo "Adding Comments line to engine config file"
             echo " " >> "$engine_config_file"
             echo "#JENKINS: Adding lines for BW Logs " >> "$engine_config_file"
             echo " " >> "$engine_config_file"
             cicd_comments=false
       fi
       #echo "Adding Line to engine config file"
       echo "$line" >> "$engine_config_file"
   fi  
done < "$extra_config_file"
cat "$engine_config_file"
