DEPLOY_FILE=$1
CONFIG_NAME=$2
CONFIG_VALUE=""
IFS="="
while read f1 f2
do
 if [ "$f1" = "$CONFIG_NAME" ]
 then
    CONFIG_VALUE="$f2"
 fi
done < $DEPLOY_FILE
echo "$CONFIG_VALUE"
