import java.text.*
import groovy.time.*


def elapsedTime(Closure closure){
    def timeStart = new Date()
    closure()
    def timeStop = new Date()
    return TimeCategory.minus(timeStop, timeStart).toMilliseconds()
}
	
def Git_Checkout (){

//Checkout Ansible Scripts for Job
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Scripts"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]

//Checkout Scripts for Job
			
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Certificates"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_TestEnv_Configurations.git']]]
}


def  Preparation ()	{
	
	
	displayName = "Cert_Deploy_${CRQ}_${BUILD_NUMBER}"
	currentBuild.displayName = "${displayName}"
	
	Git_Checkout ()
	
	sh '''
	
		cp -r ${WORKSPACE}/Certificates/Certificate_Configuration ${WORKSPACE}/Certificate_Configuration
		cp -r ${WORKSPACE}/Scripts/Certificate_Deployment ${WORKSPACE}/Certificate_Deployment
		rm -R ${WORKSPACE}/Certificates ${WORKSPACE}/Scripts
		
		
	'''
	
	if(fileExists("${WORKSPACE}/Certificate_Configuration/${Server_Type}/${ENV}/${Server_Type}_Certificateconfig.txt")) {		
		
		sh '''		 
			cat ${WORKSPACE}/Certificate_Configuration/${Server_Type}/${ENV}/${Server_Type}_Certificateconfig.txt | grep ${Client_Name} | grep ${Certificate_Type} >> ${WORKSPACE}/data.txt

		'''	
		def File = "${WORKSPACE}/data.txt"
		def readFile = new File("${File}")
		def FileContent = readFile.readLines()
		Content = "${FileContent}".split('\\|')
			
	}
	
	sh '''
	cd ${WORKSPACE}/Certificate_Configuration/${Server_Type}/${ENV}/Certs/${Client_Name}/${Certificate_Type}
	ls * > ${WORKSPACE}/FileList.txt
	'''
	File_list= ""
	def File1 = "${WORKSPACE}/FileList.txt"
	def readFile1 = new File("${File1}")
	def FileContent1 = readFile1.readLines()
	String[] FileList
	FileList = "${FileContent1}".split(', ')
		
	for (List in FileList) {
		if (File_list.length() != 0) {
			File_list = "${File_list}" + "," + Content[3] + List			
		}	else {
			def first = List.split('\\[')
	 		File_list = "${Client_Name}" + ":" + Content[3] + first[1]
			}
	}
	cert_snap = "${File_list}".split('\\]')
	
}

pipeline {
    agent any
	environment {
	//	Content = ""
		cert_snap = ""
		FileList= ""
		File_list = ""
		Src_Path = "${WORKSPACE}/Certificate_Configuration/${Server_Type}/${ENV}/Certs/${Client_Name}/${Certificate_Type}"
	}
    stages {
        stage ('Preparation') {
            steps {
                script {
                  cleanWs()  
                  Preparation ()
                    
                }
            }
        }
        stage ('Cert_Deploy') {
            steps {
                script {
					def date = new Date();
					def sdf = new SimpleDateFormat("yyyyMMddHHmmss");
					def date_time = sdf.format(date)
                    
                    
					Deploy_Duration = elapsedTime {
						ansiColor('xterm') {
							ansiblePlaybook (playbook: "${WORKSPACE}/Certificate_Deployment/certsDeploy.yml", colorized: true, extras: '', extraVars: [host: "Cert", cert_snap: cert_snap[0], datetime: "${date_time}", crq_num: "${CRQ}", Src_Path: "${Src_Path}"])
						}
					}
					Deploy_Duration = Deploy_Duration*0.001
					println("Deploy Duration in Sec: " + Deploy_Duration)
					println "Certificates Deployment Completed"
                }
            }
        }        
    }
}