logfile=$1
ignorefile=$2
WORKSPACE=`pwd`
# First check for the "The ASG configuration status is OK"
check=`cat ${logfile} | grep 'The ASG configuration status is' | grep -oE '[^ ]+$' | grep OK | wc -l`

if [ "$check" -ne "0" ]; then
        echo "Gateway deployment validation is successful"
        exit 0
else
        sed -n '/The ASG configuration status/,$p' ${logfile} | tail -n +2 | grep -i "error" >errorlog1
        cat ${ignorefile} | while read line
        do
                line="$(<<< "$line" sed -e 's`[][\\/.*^$]`\\&`g')"
                sed -i "/${line}/d" errorlog1
				#grep -v "$line" errorlog1 >errorlog2
				echo "DEBUG: ------------------------------------------------\n"
				cat errorlog1
				echo "DEBUG: ------------------------------------------------\n"
        done
        grep -v "Error while creating SSL context for endpoint" errorlog1 >errorlog2
        grep -v "ErrorMapFile" errorlog2 >errorlog 
        count_final=`cat errorlog | wc -l`
		echo "DEBUG: count_final is: $count_final"
        if [ "${count_final}" != 0 ];then
                echo "ERROR: GATEWAY Deployment failed."
                echo "ERROR: Validation log path: ${WORKSPACE}/${logfile}"
                rm $WORKSPACE/errorlog1
                rm $WORKSPACE/errorlog2
                exit 1
        else
                echo "Gateway deployment validation is successful"
                rm $WORKSPACE/errorlog1
                rm $WORKSPACE/errorlog2
                exit 0
        fi
fi
rm $WORKSPACE/errorlog1
rm $WORKSPACE/errorlog2
