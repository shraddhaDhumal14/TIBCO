#!/bin/bash
# Author: Ram Shankar
# ------------------------------------------
new_file=$1
old_file=$2
report_file=$3

filename=$(basename ${new_file})

if [ ! -r $new_file ]
then
   #echo "----->File:$new_file not found" 
   exit 1
fi

if [ ! -r $old_file ]
then
   #echo "----->File:$old_file not found"
   echo "<tr><td colspan='2' style=\"text-align: center;font-weight:bold\" >$filename</td></tr>" >> "${report_file}"   
   echo "<tr> <td></td><td>{{New File Added}}</td></tr>" >> "${report_file}"
   exit 1
fi

rm -f Added.diff Matched.diff Updated.diff Deleted.diff

while read -r line; do
        line=$(echo ${line} | sed $'s/\r//')
        noofslashes=`echo "${line}" | grep "|" -o |wc -l`
        
        key=""
        value=""
        keystart=1
        keyend=2
        valuestart=3
        if [[ ! -z "${line}" ]] && [[ "${line:0:1}" != "#" ]] && [[ ${line##*( )} != "#"* ]] && [[ $line != "#"* ]] && [[ $noofslashes -gt 1 ]] ; then 
                
                
                keystart=1
                keyend=2
                valuestart=3
                
                key=$(echo ${line} | cut -d '|' -f ${keystart}-${keyend} | sed -e 's/[[:space:]]*$//') 
                value=$(echo ${line} | cut -d '|' -f ${valuestart}- | sed -e 's/[[:space:]]*$//')
                              
                loop=0
                while [ `grep -oc "^${key}|" "${old_file}"` -gt 1 ]
                do 
                    loop=$(($loop+1))
                    keyend=$(($loop+2))
                    valuestart=$(($loop+3))
                    
                    key=$(echo ${line} | cut -d '|' -f ${keystart}-${keyend} | sed -e 's/[[:space:]]*$//') 
                    value=$(echo ${line} | cut -d '|' -f ${valuestart}- | sed -e 's/[[:space:]]*$//')
                 done                
               
        elif [[ ! -z "${line}" ]] && [[ "${line:0:1}" != "#" ]] && [[ ${line##*( )} != "#"* ]] && [[ $line != "#"* ]] && [[ $noofslashes -eq 1 ]] ; then
                key=$(echo ${line} | cut -d '|' -f 1 | sed -e 's/[[:space:]]*$//') 
                value=$(echo ${line} | cut -d '|' -f 2 | sed -e 's/[[:space:]]*$//')
                keystart=1
                keyend=1
                valuestart=2
        elif [[ ! -z "${line}" ]] && [[ "${line:0:1}" != "#" ]] && [[ ${line##*( )} != "#"* ]] && [[ $line != "#"* ]] && [[ $noofslashes -eq 0 ]] ; then
                key=$(echo ${line} | sed -e 's/[[:space:]]*$//') 
        fi
        
       
        if [[ ! -z "${line}" ]] && [[ "${line:0:1}" != "#" ]] && [[ ${line##*( )} != "#"* ]] && [[ $line != "#"* ]] && [[ $noofslashes -eq 0 ]] ; then
            if [[ `grep -o "^${key}" "${old_file}"` ]]; then
                :
            else
                echo "<tr><td></td><td>$key</td></tr>" >> Added.diff
            fi
        elif [[ ! -z "${line}" ]] && [[ "${line:0:1}" != "#" ]] && [[ ${line##*( )} != "#"* ]] && [[ $line != "#"* ]] && [[ ! -z "${key}" ]] ; then
            if [[ `grep -o "^${key}|" "${old_file}"` ]]; then
                    
                    value_old=$(grep "^${key}|" "${old_file}" | cut -d '|' -f ${valuestart}- | sed -e 's/[[:space:]]*$//')
                    value=`echo $value` 
                    value_old=`echo $value_old` 
                    
                    if [[ -z "${value}" && -z "${value_old}" ]] || [[ "${value}" == "${value_old}" ]] ; then
                           :
                    else
                           echo "<tr><td>$key|${value_old}</td><td>$key|${value}</td></tr>" >> Updated.diff                           
                    fi
                else
                      echo "<tr><td></td><td>$key|${value}</td></tr>" >> Added.diff
                fi
        fi
        
done < ${new_file} 

while read -r line; do
        line=$(echo ${line} | sed $'s/\r//')
        noofslashes=`echo "${line}" | grep "|" -o |wc -l`
        
        key=""
        value=""
        keystart=1
        keyend=2
        valuestart=3
        if [[ ! -z "${line}" ]] && [[ "${line:0:1}" != "#" ]] && [[ ${line##*( )} != "#"* ]] && [[ $line != "#"* ]] && [[ $noofslashes -gt 1 ]] ; then 
                
                
                keystart=1
                keyend=2
                valuestart=3
                
                key=$(echo ${line} | cut -d '|' -f ${keystart}-${keyend} | sed -e 's/[[:space:]]*$//') 
                value=$(echo ${line} | cut -d '|' -f ${valuestart}- | sed -e 's/[[:space:]]*$//')
                              
                loop=0
                while [ `grep -oc "^${key}|" "${old_file}"` -gt 1 ]
                do 
                    loop=$(($loop+1))
                    keyend=$(($loop+2))
                    valuestart=$(($loop+3))
                    
                    key=$(echo ${line} | cut -d '|' -f ${keystart}-${keyend} | sed -e 's/[[:space:]]*$//') 
                    value=$(echo ${line} | cut -d '|' -f ${valuestart}- | sed -e 's/[[:space:]]*$//')
                 done                
               
        elif [[ ! -z "${line}" ]] && [[ "${line:0:1}" != "#" ]] && [[ ${line##*( )} != "#"* ]] && [[ $line != "#"* ]] && [[ $noofslashes -eq 1 ]] ; then
                key=$(echo ${line} | cut -d '|' -f 1 | sed -e 's/[[:space:]]*$//') 
                value=$(echo ${line} | cut -d '|' -f 2 | sed -e 's/[[:space:]]*$//')
                keystart=1
                keyend=1
                valuestart=2
        elif [[ ! -z "${line}" ]] && [[ "${line:0:1}" != "#" ]] && [[ ${line##*( )} != "#"* ]] && [[ $line != "#"* ]] && [[ $noofslashes -eq 0 ]] ; then
                key=$(echo ${line} | sed -e 's/[[:space:]]*$//') 
        fi
        
       
        if [[ ! -z "${line}" ]] && [[ "${line:0:1}" != "#" ]] && [[ ${line##*( )} != "#"* ]] && [[ $line != "#"* ]] && [[ $noofslashes -eq 0 ]] ; then
            if [[ `grep -o "^${key}" "${new_file}"` ]]; then
                :
            else
                echo "<tr><td>$key|${old_value} </td><td></td></tr>" >> Deleted.diff
            fi
        elif [[ ! -z "${line}" ]] && [[ "${line:0:1}" != "#" ]] && [[ ${line##*( )} != "#"* ]] && [[ $line != "#"* ]] && [[ ! -z "${key}" ]] ; then
            if [[ `grep -o "^${key}|" "${new_file}"` ]]; then
                :  
            else
                  echo "<tr><td>$key|${old_value} </td><td></td></tr>" >> Deleted.diff
            fi
        fi

done < ${old_file}
    
if [[ -s Added.diff ]] || [[ -s Updated.diff ]]  || [[ -s Deleted.diff ]]; then

    echo "<tr><td colspan='2' style=\"text-align: center;font-weight:bold\" >$filename</td></tr>" >> "${report_file}"
    
    if [[ -s Updated.diff ]]; then
        cat Updated.diff >> "${report_file}"
    fi
    
    if [[ -s Added.diff ]]; then
        cat Added.diff >> "${report_file}"
    fi
    
    if [[ -s Deleted.diff ]]; then       
        cat Deleted.diff >> "${report_file}"
    fi
    
else
    :
    #echo "<tr style='text-align:center'><td colspan='2'>$filename {{No changes}}</td></tr>" >> "${report_file}"    
fi

rm -f Added.diff Matched.diff Updated.diff Deleted.diff
