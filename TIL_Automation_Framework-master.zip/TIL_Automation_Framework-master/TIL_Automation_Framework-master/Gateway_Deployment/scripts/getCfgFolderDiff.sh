#! /bin/sh
# Author: Ram Shankar
# ------------------------------------------

new_folder=$1
old_folder=$2
report_file=$3


diff_table_header(){
        echo "<br><br><br>"  
                echo "<style type="text/css">"
        echo ".tg_summary  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;} "
        echo ".tg_summary td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;width:48%;word-break:break-all;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}"
        echo ".tg_summary th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:break-all;border-color:#9ABAD9;color:#fff;background-color:#409cff;}"
        echo ".tg_summary .tg_summary-1wig{font-weight:bold;text-align:left;vertical-align:top}"
        echo ".tg_summary .tg_summary-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}"
        echo ".tg_summary .tg_summary-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}"
        echo ".tg_summary .tg_summary-amwm{font-weight:bold;text-align:center;vertical-align:top}"
        echo ".tg_summary .tg_summary-0lax{text-align:left;vertical-align:top}"
        echo ".tg_summary .tg_summary-PASSED{background-color:lightg_summaryreen;text-align:left;vertical-align:top}"
        echo ".tg_summary .tg_summary-FAILED{background-color:red;text-align:left;vertical-align:top}"
        echo ".tg_summary .tg_summary-NOT_STARTED{background-color:lightg_summaryrey;text-align:left;vertical-align:top}"
        echo ".tg_summary .tg_summary-NOT_REQUIRED{background-color:#E1E0A2;text-align:left;vertical-align:top}"
        echo "</style>"
        echo "<table class=\"tg_summary\" style=\"undefined; width: 100%\">"
        echo "<colgroup>"
        echo "<col style=\"width: 50%\">"
        echo "<col style=\"width: 50%\">"
        echo "</colgroup>"
        echo "<tr>"
        echo "<th class=\"tg_summary-amwm\">OLD_VALUE ( ${old_folder} )</td>"
        echo "<th class=\"tg_summary-amwm\">NEW_VALUE ( ${new_folder} )</td> "
        echo "</tr>"
}



if [[ $(diff -qr $1 $2 | wc -l) = "0" ]]; then
       echo "<h3>No Configuration change</h3>" >> "${report_file}"
       exit 1
else
       :
       #echo "Configuration file differs"
fi


diff_table_header >> "${report_file}"

for file in $new_folder/*.cfg;
do
     filename=$(basename ${file})
     new_file="${new_folder}/${filename}"
     old_file="${old_folder}/${filename}"
     echo "${filename}"
     sh $(dirname "$0")/cfgDiff.sh $new_file $old_file  $report_file   
done;

for file in $old_folder/*.cfg;
do
     filename=$(basename ${file})
     new_file="${new_folder}/${filename}"
     old_file="${old_folder}/${filename}"
     if [ ! -r $new_file ]
     then
       echo "<tr><td colspan='2' style=\"text-align: center;font-weight:bold\" >$filename</td></tr>" >> "${report_file}"
       echo "<tr> <td></td><td>{{Old File Deleted}}</td></tr>" >> "${report_file}"
    fi   
done;


echo "</table>" >> "${report_file}"
rm -f Added.diff Matched.diff Updated.diff Deleted.diff
