#! /bin/sh
updated_entries_file=$1
source_file=$2
while read -r line; do
        line=$(echo ${line} | sed $'s/\r//')
        throttle_name=$(echo ${line} | cut -d '|' -f 1-2)
        if [[ ! -z "${line}" ]];then
              [[ `grep ${throttle_name} ${source_file}` ]] && sed -i "s/^$(echo ${line} | cut -d '|' -f 1-2).*/${line}/" ${source_file} || echo "${line}" >>"${source_file}"
        fi
done <<< "$(cat "${updated_entries_file}" | egrep '\S' | sed 's/^ //' | egrep -v "^#")"
