#!/bin/sh

rm *.pem
rm Server-Private-CAs.jks
rm Server-Public-CAs.jks

#
keytool -genkeypair -v -keystore Server-Private-CAs.jks -storepass password -keypass password -storetype jks -keyalg RSA -keysize 2048 -sigalg SHA256WithRSA -validity 5475 -alias server-root-ca -dname "CN=server-root-ca, OU=IT, O=Acme Corporation Inc, L=Palo Alto, ST=California, C=US, CN=John Smith, emailAddress=john.smith@acme.com" -ext BC:c -ext KeyUsage=keyCertSign,cRLSign -ext ExtendedkeyUsage=OCSPSigning 
keytool -genkeypair -v -keystore Server-Private-CAs.jks -storepass password -keypass password -storetype jks -keyalg RSA -keysize 2048 -sigalg SHA256WithRSA -validity 5475 -alias server-intermediate-ca -dname "CN=server-intermediate-ca, OU=IT, O=Acme Corporation Inc, L=Palo Alto, ST=California, C=US, CN=Eric Smith, emailAddress=eric.smith@acme.com" 
keytool -genkeypair -v -keystore Server-Private-CAs.jks -storepass password -keypass password -storetype jks -keyalg RSA -keysize 2048 -sigalg SHA256WithRSA -validity 5475 -alias server-service-ca -dname "CN=server-service-ca, OU=IT, O=Acme Corporation Inc, L=Palo Alto, ST=California, C=US, CN=API Smith, emailAddress=api.smith@acme.com" 
keytool -genkeypair -v -keystore Server-Private-CAs.jks -storepass password -keypass password -storetype jks -keyalg RSA -keysize 2048 -sigalg SHA256WithRSA -validity 365  -alias server-expired-ca -dname "CN=server-expired-ca, OU=IT, O=Acme Corporation Inc, L=Palo Alto, ST=California, C=US, CN=Dead Smith, emailAddress=dead.smith@acme.com" -startdate "1999/12/31 00:00:00" 
keytool -genkeypair -v -keystore Server-Private-CAs.jks -storepass password -keypass password -storetype jks -keyalg RSA -keysize 2048 -sigalg SHA256WithRSA -validity 5475 -alias server-private-ca -dname "CN=server-private-ca, OU=IT, O=Acme Corporation Inc, L=Palo Alto, ST=California, C=US, CN=Bob Smith, emailAddress=bob.smith@acme.com" 

keytool -exportcert -v -keystore Server-Private-CAs.jks -storepass password -storetype jks -file Server-Root-CA.pem -alias server-root-ca -rfc 
keytool -importcert -v -keystore Server-Private-CAs.jks -storepass password -storetype jks -file server-root-ca.pem -alias server-root-ca-trusted -noprompt
keytool -importcert -v -keystore Server-Public-CAs.jks -storepass password -storetype jks -file server-root-ca.pem -alias server-root-ca-trusted -noprompt

keytool -certreq -v -keystore Server-Private-CAs.jks -storepass password -keypass password -storetype jks -alias server-intermediate-ca | keytool -gencert -v -keystore Server-Private-CAs.jks -storepass password -keypass password -storetype jks -alias server-root-ca -validity 3650 -ext BasicConstraints:critical=ca:true,pathlen:1 -ext KeyUsage=keyCertSign,cRLSign -ext ExtendedkeyUsage=OCSPSigning |  keytool -importcert -v -keystore Server-Private-CAs.jks -storepass password -keypass password -storetype jks -alias server-intermediate-ca
keytool -exportcert -v -keystore Server-Private-CAs.jks -storepass password -storetype jks -file Server-Intermediate-CA.pem -alias server-intermediate-ca -rfc 
keytool -importcert -v -keystore Server-Private-CAs.jks -storepass password -storetype jks -file server-Intermediate-CA.pem -alias server-intermediate-ca-trusted -noprompt
keytool -importcert -v -keystore Server-Public-CAs.jks -storepass password -storetype jks -file server-root-ca.pem -alias server-intermediate-ca-trusted -noprompt

keytool -certreq -v -keystore Server-Private-CAs.jks -storepass password -keypass password -storetype jks -alias server-service-ca | keytool -gencert -v -keystore Server-Private-CAs.jks -storepass password -keypass password -storetype jks -validity 1825 -alias server-intermediate-ca -ext BasicConstraints:critical=ca:true,pathlen:0 -ext KeyUsage=keyCertSign,cRLSign -ext ExtendedkeyUsage=OCSPSigning |   keytool -importcert -v -keystore Server-Private-CAs.jks -storepass password -keypass password -storetype jks -alias server-service-ca 
keytool -exportcert -alias server-service-ca -keystore Server-Private-CAs.jks -storepass password -storetype jks -rfc -v -file Server-Service-CA.pem
keytool -importcert -v -keystore Server-Private-CAs.jks -storepass password -storetype jks -file Server-Service-CA.pem -alias server-service-ca-trusted -noprompt
keytool -importcert -v -keystore Server-Public-CAs.jks -storepass password -storetype jks -file server-root-ca.pem -alias server-service-ca-trusted -noprompt

keytool -exportcert -v -keystore Server-Private-CAs.jks -storepass password -storetype jks -file Server-Expired-CA.pem -alias server-expired-ca -rfc 
keytool -importcert -v -keystore Server-Private-CAs.jks -storepass password -storetype jks -file server-Expired-CA.pem -alias server-expired-ca-trusted -noprompt
keytool -importcert -v -keystore Server-Public-CAs.jks -storepass password -storetype jks -file server-root-ca.pem -alias server-expired-ca-trusted -noprompt

keytool -exportcert -v -keystore Server-Private-CAs.jks -storepass password -storetype jks -file Server-Private-CA.pem -alias server-private-ca -rfc 
keytool -importcert -v -keystore Server-Private-CAs.jks -storepass password -storetype jks -file server-Private-CA.pem -alias server-private-ca-trusted -noprompt
