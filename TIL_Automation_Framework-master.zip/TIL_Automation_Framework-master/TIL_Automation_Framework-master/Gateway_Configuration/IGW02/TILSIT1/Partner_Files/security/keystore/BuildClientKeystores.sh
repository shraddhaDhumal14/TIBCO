#!/bin/sh

rm *.pem
rm Client-Private-CAs.jks
rm Client-Public-CAs.jks

keytool -genkeypair -v -keystore Client-Private-CAs.jks -storepass password -keypass password -storetype jks -keyalg RSA -keysize 2048 -sigalg SHA256WithRSA -validity 5475 -alias client-root-ca -dname "CN=client-root-ca, OU=IT, O=Acme Corporation Inc, L=Palo Alto, ST=California, C=US, CN=Jane Doe, emailAddress=jane.doe@acme.com" -ext BC:c -ext KeyUsage=keyCertSign,cRLSign -ext ExtendedkeyUsage=OCSPSigning
keytool -genkeypair -v -keystore Client-Private-CAs.jks -storepass password -keypass password -storetype jks -keyalg RSA -keysize 2048 -sigalg SHA256WithRSA -validity 5475 -alias client-intermediate-ca -dname "CN=client-intermediate-ca, OU=IT, O=Acme Corporation Inc, L=Palo Alto, ST=California, C=US, CN=Eric Doe, emailAddress=eric.doe@acme.com" 
keytool -genkeypair -v -keystore Client-Private-CAs.jks -storepass password -keypass password -storetype jks -keyalg RSA -keysize 2048 -sigalg SHA256WithRSA -validity 5475 -alias client-service-ca -dname "CN=client-service-ca, OU=IT, O=Acme Corporation Inc, L=Palo Alto, ST=California, C=US, CN=API Doe, emailAddress=api.doe@acme.com" 
keytool -genkeypair -v -keystore Client-Private-CAs.jks -storepass password -keypass password -storetype jks -keyalg RSA -keysize 2048 -sigalg SHA256WithRSA -validity 365  -alias client-expired-ca -dname "CN=client-expired-ca, OU=IT, O=Acme Corporation Inc, L=Palo Alto, ST=California, C=US, CN=Dead Doe, emailAddress=dead.doe@acme.com" -startdate "1999/12/31 00:00:00" 
keytool -genkeypair -v -keystore Client-Private-CAs.jks -storepass password -keypass password -storetype jks -keyalg RSA -keysize 2048 -sigalg SHA256WithRSA -validity 5475 -alias client-private-ca -dname "CN=client-private-ca, OU=IT, O=Acme Corporation Inc, L=Palo Alto, ST=California, C=US, CN=Alice Doe, emailAddress=alice.doe@acme.com" 

keytool -exportcert -v -keystore Client-Private-CAs.jks -storepass password -storetype jks -file Client-Root-CA.pem -alias client-root-ca -rfc 
keytool -importcert -v -keystore Client-Private-CAs.jks -storepass password -storetype jks -file client-root-ca.pem -alias client-root-ca-trusted -noprompt
keytool -importcert -v -keystore Client-Public-CAs.jks -storepass password -storetype jks -file client-root-ca.pem -alias client-root-ca-trusted -noprompt

keytool -certreq -v -keystore Client-Private-CAs.jks -storepass password -keypass password -storetype jks -alias client-intermediate-ca | keytool -gencert -v -keystore Client-Private-CAs.jks -storepass password -keypass password -storetype jks -alias client-root-ca -validity 3650 -ext BasicConstraints:critical=ca:true,pathlen:1 -ext KeyUsage=keyCertSign,cRLSign -ext ExtendedkeyUsage=OCSPSigning |  keytool -importcert -v -keystore Client-Private-CAs.jks -storepass password -keypass password -storetype jks -alias client-intermediate-ca
keytool -exportcert -v -keystore Client-Private-CAs.jks -storepass password -storetype jks -file Client-Intermediate-CA.pem -alias client-intermediate-ca -rfc 
keytool -importcert -v -keystore Client-Private-CAs.jks -storepass password -storetype jks -file client-Intermediate-CA.pem -alias client-intermediate-ca-trusted -noprompt
keytool -importcert -v -keystore Client-Public-CAs.jks -storepass password -storetype jks -file client-root-ca.pem -alias client-intermediate-ca-trusted -noprompt

keytool -certreq -v -keystore Client-Private-CAs.jks -storepass password -keypass password -storetype jks -alias client-service-ca | keytool -gencert -v -keystore Client-Private-CAs.jks -storepass password -keypass password -storetype jks -validity 1825 -alias client-intermediate-ca -ext BasicConstraints:critical=ca:true,pathlen:0 -ext KeyUsage=keyCertSign,cRLSign -ext ExtendedkeyUsage=OCSPSigning |   keytool -importcert -v -keystore Client-Private-CAs.jks -storepass password -keypass password -storetype jks -alias client-service-ca 
keytool -exportcert -alias client-service-ca -keystore Client-Private-CAs.jks -storepass password -storetype jks -rfc -v -file Client-Service-CA.pem
keytool -importcert -v -keystore Client-Private-CAs.jks -storepass password -storetype jks -file Client-Service-CA.pem -alias client-service-ca-trusted -noprompt
keytool -importcert -v -keystore Client-Public-CAs.jks -storepass password -storetype jks -file client-root-ca.pem -alias client-service-ca-trusted -noprompt

keytool -exportcert -v -keystore Client-Private-CAs.jks -storepass password -storetype jks -file Client-Expired-CA.pem -alias client-expired-ca -rfc 
keytool -importcert -v -keystore Client-Private-CAs.jks -storepass password -storetype jks -file client-Expired-CA.pem -alias client-expired-ca-trusted -noprompt
keytool -importcert -v -keystore Client-Public-CAs.jks -storepass password -storetype jks -file client-root-ca.pem -alias client-expired-ca-trusted -noprompt

keytool -exportcert -v -keystore Client-Private-CAs.jks -storepass password -storetype jks -file Client-Private-CA.pem -alias client-private-ca -rfc 
keytool -importcert -v -keystore Client-Private-CAs.jks -storepass password -storetype jks -file client-Private-CA.pem -alias client-private-ca-trusted -noprompt

keytool -importkeystore -srckeystore Client-Private-CAs.jks -destkeystore Client-Private-CAs.p12 -srcstoretype JKS -deststoretype PKCS12 -srcstorepass password -deststorepass password -srcalias client-service-ca -destalias client-service-ca -srckeypass password -destkeypass password -noprompt

