This document describes how to create a self-signed keystore using the JDK Keytool.
For details on how to use the Keytool, refer to:
http://docs.oracle.com/javase/7/docs/technotes/tools/windows/keytool.html

The steps to create self-signed keystores:
1. Generate self-signed key.
2. Export certificate for use in truststore.
3. Import certificate into a truststore.

The following are examples for the steps above:
1. Generate self-signed key.
keytool -genkeypair -keystore keystore.jks -storetype jks -storepass password -v \
   -dname "CN=myhost,O=example company,C=Lalaland" -alias hostname -keypass password \
   -validity 365 -keyalg RSA -keysize 2048 -sigalg SHA256WithRSA

2. Export certificate for use in trustore.
keytool -export -keystore keystore.jks -storetype jks -storepass password -v \
   -alias hostname -rfc -file certificate.pem

3. Import certificate into a trustore.
keytool -import -keystore truststore.jks -storetype jks -storepass password -v \
  -alias hosts_cert -noprompt -file certificate.pem

To view what is in a keystore, use the list option as follows:
keytool -list -keystore keystore.jks -v -storepass password
