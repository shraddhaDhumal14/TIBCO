#! /bin/sh
build=$1
env=$2
release=$3
eng=$4
majv=$(echo $release | cut -d '.' -f 1)
minv=$(echo $release | cut -d '.' -f 2)
cmd="ansible-playbook ./get_ansible_fact.yml -e type=\"${build}\" -e env=\"${env}\" -e majv=\"${majv}\" -e minv=\"${minv}\" -e eng=\"${eng}\""
eval $cmd >ansible_log
installed_version=`cat ansible_log | grep "MSG" -A 2 | tail -1 | tr -d ' '`
echo "${installed_version}"
