#!/bin/sh

earExport_xml=$1
envExport_xml=$2
envConfiguration=$3
PRESENT_PATH=`pwd`



#engine_conf="SubscriptionLifecycleManagement-Misc.xml"
#global_conf="LT_LNKTest16_Env_gv_Config.gvconf"

# Generate formatted output for earExport_xml

cmd="cat ${earExport_xml} | sed -ne '/NVPairs name=\\\"Global Variables\\\"/,\$p' | sed -ne '1,/<\/NVPairs>/p' | grep \"<NameValuePair>\" -A 2 | grep -v \"<NameValuePair>\" | grep -v \"\-\-\" | paste -d \" \"  - - | sed -e 's/<\/name>\(.*\)<value>/=/' | sed -e 's/<name>\(.*\)<\/value>/\1/' | sed -e 's/^[ \t]*//'"
eval ${cmd} >earExport_xml_formatted

cmd="cat ${earExport_xml} | sed -ne '/NVPairs name=\\\"Global Variables\\\"/,\$p' | sed -ne '1,/<\/NVPairs>/p' | grep \"<NameValuePairBoolean>\" -A 2 | grep -v \"<NameValuePairBoolean>\" | grep -v \"\-\-\" | paste -d \" \"  - - | sed -e 's/<\/name>\(.*\)<value>/=/' | sed -e 's/<name>\(.*\)<\/value>/\1/' | sed -e 's/^[ \t]*//'"
eval ${cmd} >>earExport_xml_formatted

cmd="cat ${earExport_xml} | sed -ne '/NVPairs name=\\\"Global Variables\\\"/,\$p' | sed -ne '1,/<\/NVPairs>/p' | grep \"<NameValuePairInteger>\" -A 2 | grep -v \"<NameValuePairInteger>\" | grep -v \"\-\-\" | paste -d \" \"  - - | sed -e 's/<\/name>\(.*\)<value>/=/' | sed -e 's/<name>\(.*\)<\/value>/\1/' | sed -e 's/^[ \t]*//'"
eval ${cmd} >>earExport_xml_formatted

cmd="cat ${earExport_xml} | sed -ne '/NVPairs name=\\\"Global Variables\\\"/,\$p' | sed -ne '1,/<\/NVPairs>/p' | grep \"<NameValuePairPassword>\" -A 2 | grep -v \"<NameValuePairPassword>\" | grep -v \"\-\-\" | paste -d \" \"  - - | sed -e 's/<\/name>\(.*\)<value>/=/' | sed -e 's/<name>\(.*\)<\/value>/\1/' | sed -e 's/^[ \t]*//'"
eval ${cmd} >>earExport_xml_formatted



# Generate formatted output for envExport_xml

cmd="cat ${envExport_xml} | sed -ne '/NVPairs name=\\\"Global Variables\\\"/,\$p' | sed -ne '1,/<\/NVPairs>/p' | grep \"<NameValuePair>\" -A 2 | grep -v \"<NameValuePair>\" | grep -v \"\-\-\" | paste -d \" \"  - - | sed -e 's/<\/name>\(.*\)<value>/=/' | sed -e 's/<name>\(.*\)<\/value>/\1/' | sed -e 's/^[ \t]*//'"
echo "command is: $cmd"
eval ${cmd} >envExport_xml_formatted

cmd="cat ${envExport_xml} | sed -ne '/NVPairs name=\\\"Global Variables\\\"/,\$p' | sed -ne '1,/<\/NVPairs>/p' | grep \"<NameValuePairBoolean>\" -A 2 | grep -v \"<NameValuePairBoolean>\" | grep -v \"\-\-\" | paste -d \" \"  - - | sed -e 's/<\/name>\(.*\)<value>/=/' | sed -e 's/<name>\(.*\)<\/value>/\1/' | sed -e 's/^[ \t]*//'"
eval ${cmd} >>envExport_xml_formatted

cmd="cat ${envExport_xml} | sed -ne '/NVPairs name=\\\"Global Variables\\\"/,\$p' | sed -ne '1,/<\/NVPairs>/p' | grep \"<NameValuePairInteger>\" -A 2 | grep -v \"<NameValuePairInteger>\" | grep -v \"\-\-\" | paste -d \" \"  - - | sed -e 's/<\/name>\(.*\)<value>/=/' | sed -e 's/<name>\(.*\)<\/value>/\1/' | sed -e 's/^[ \t]*//'"
eval ${cmd} >>envExport_xml_formatted


cmd="cat ${envExport_xml} | sed -ne '/NVPairs name=\\\"Global Variables\\\"/,\$p' | sed -ne '1,/<\/NVPairs>/p' | grep \"<NameValuePairPassword>\" -A 2 | grep -v \"<NameValuePairPassword>\" | grep -v \"\-\-\" | paste -d \" \"  - - | sed -e 's/<\/name>\(.*\)<value>/=/' | sed -e 's/<name>\(.*\)<\/value>/\1/' | sed -e 's/^[ \t]*//'"
eval ${cmd} >>envExport_xml_formatted


# delete the common entries in "envExport_xml_formatted" from "earExport_xml_formatted" and "envExport_xml_formatted"
grep -vxFf earExport_xml_formatted envExport_xml_formatted >envExport_commonOut


# delete values for the gv's in "envExport_xml_formatted" which are matched in "envConfiguration" file

>envExport_conf
while IFS=' ' read -r line; do
        #echo "line is: $line"
        var_name=`echo $line | cut -d '=' -f 1`
        [[ `grep ^${var_name}= ${envConfiguration}` ]] && echo "${var_name}=" >>envExport_conf || echo "$line" >>envExport_conf
done <envExport_commonOut


echo "-------------------------------------------------------"
echo "Final envExport_conf is: ${PRESENT_PATH}/envExport_conf"
echo "-------------------------------------------------------"
