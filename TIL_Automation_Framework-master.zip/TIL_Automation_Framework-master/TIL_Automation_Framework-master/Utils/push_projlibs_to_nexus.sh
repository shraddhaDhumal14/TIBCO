PRESENT_PATH=`pwd`
REPO_NAME="TIL_FRAMEWORK"
DESIGNTIMELIBS_PATH=$1
#TIL_MODULE=$1

# Cleanup the previous projlib directory first in the current folder.
[[ -f buildprojlib.properties ]] && rm -f buildprojlib.properties
[[ -d projlib ]] && rm -rf projlib


# Get projlib.properies file from CVS
# rm buildprojlib.properties
mkdir projlib
cd ./projlib

cvs -d :pserver:sseernam:qaz_1234@10.33.53.170:/cvs checkout TIL_DELIVERY01/designer/projlib.properties
sed -i 's/C\\:\\\\cvsdir\\\\//g' TIL_DELIVERY01/designer/projlib.properties
sed -i 's/c\\:\\\\cvsdir\\\\//g' TIL_DELIVERY01/designer/projlib.properties
sed -i 's/\\\\/\//g' TIL_DELIVERY01/designer/projlib.properties

# Push projlib.properties to Nexus
cmd1="curl -X POST \"http://195.233.197.150:8081/service/rest/v1/components?repository=TIL_FRAMEWORK\" -u admin:admin123 -H \"accept: application/json\" -H \"Content-Type: multipart/form-data\" -F \"raw.directory=/TIL_DELIVERY01/designer/\" -F \"raw.asset1=@TIL_DELIVERY01/designer/projlib.properties\" -F \"raw.asset1.filename=projlib.properties\""
eval ${cmd1}


cd -

# CVS Checkout designtimelibs from project folder.
cmd="cvs -d :pserver:sseernam:qaz_1234@10.33.53.170:/cvs checkout ${DESIGNTIMELIBS_PATH}"
eval ${cmd}



# #cvs co -r $2 -p $1/.designtimelibs > /opt/tibco/build_script/DesigntimeLibs_Temp/.designtimelibs
# #dos2unix /opt/tibco/build_script/DesigntimeLibs_Temp/.designtimelibs

cat "${PRESENT_PATH}"/"${DESIGNTIMELIBS_PATH}" | egrep -v "#" | while read line
do
         p2=$(echo $line | awk -F"=" '{print $2}')
         path=$(grep $p2"=" "${PRESENT_PATH}"/projlib/TIL_DELIVERY01/designer/projlib.properties | awk -F"=" '{print $2}')
         echo $p2"="$path >>buildprojlib.properties
         cd ./projlib/
	echo "path is: $path"
         echo "cvs -d :pserver:sseernam:qaz_1234@10.33.53.170:/cvs checkout $path" > temp.sh
	 txt_path=`echo "$path" | sed -e 's/projlib/txt/'`
	 echo "txt_path is: ${txt_path}"
	  echo "cvs -d :pserver:sseernam:qaz_1234@10.33.53.170:/cvs checkout ${txt_path}" >>temp.sh
	 xml_path=`echo "$path" | sed -e 's/projlib/xml/'`
 	  echo "cvs -d :pserver:sseernam:qaz_1234@10.33.53.170:/cvs checkout ${xml_path}" >>temp.sh
         chmod +x temp.sh
         #dos2unix temp.sh
                 sh temp.sh
         cd -
done

sed -i "s|=|=${PRESENT_PATH}\/projlib\/|g" buildprojlib.properties


# Now push all the files from TIL_DELIVERY01 and TIL_SOURCE files to nexus.
cd ./projlib
find . -name "*.projlib" | while read line
do
#./TIL_SOURCE/tools/delivery/ConnectivityServices/SMTP/LIB_SMTP_1_0_1.projlib
        line=${line#?}
        echo "line is: $line"
        projlib_dir=$(dirname "${line}")
        projlibfile=$(basename "${line}")
		line=${line#?}
        cmd="curl -X POST \"http://195.233.197.150:8081/service/rest/v1/components?repository=${REPO_NAME}\" -u admin:admin123 -H \"accept: application/json\" -H \"Content-Type: multipart/form-data\" -F \"raw.directory=${projlib_dir}/\" -F \"raw.asset1=@${line}\" -F \"raw.asset1.filename=${projlibfile}\""
        echo "command is: ${cmd}"
        eval ${cmd}
done
find . -name "*.txt" | while read line
do
#./TIL_SOURCE/tools/delivery/ConnectivityServices/SMTP/LIB_SMTP_1_0_1.projlib
        line=${line#?}
        echo "line is: $line"
        projlib_dir=$(dirname "${line}")
        projlibfile=$(basename "${line}")
                line=${line#?}
        cmd="curl -X POST \"http://195.233.197.150:8081/service/rest/v1/components?repository=${REPO_NAME}\" -u admin:admin123 -H \"accept: application/json\" -H \"Content-Type: multipart/form-data\" -F \"raw.directory=${projlib_dir}/\" -F \"raw.asset1=@${line}\" -F \"raw.asset1.filename=${projlibfile}\""
        echo "command is: ${cmd}"
        eval ${cmd}
done
find . -name "*.xml" | while read line
do
#./TIL_SOURCE/tools/delivery/ConnectivityServices/SMTP/LIB_SMTP_1_0_1.projlib
        line=${line#?}
        echo "line is: $line"
        projlib_dir=$(dirname "${line}")
        projlibfile=$(basename "${line}")
                line=${line#?}
        cmd="curl -X POST \"http://195.233.197.150:8081/service/rest/v1/components?repository=${REPO_NAME}\" -u admin:admin123 -H \"accept: application/json\" -H \"Content-Type: multipart/form-data\" -F \"raw.directory=${projlib_dir}/\" -F \"raw.asset1=@${line}\" -F \"raw.asset1.filename=${projlibfile}\""
        echo "command is: ${cmd}"
        eval ${cmd}
done


