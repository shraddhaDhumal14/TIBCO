#!/bin/sh
engine_name=$1
CRQ_NUM=$2
new_xml="./${CRQ_NUM}/bw/${engine_name}.xml"
old_xml="./${CRQ_NUM}/backup/${engine_name}.xml"

table_header(){
	echo "<style type="text/css">" 
	echo ".tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;} "
	echo ".tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;width:150px;word-break:break-all;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}"
	echo ".tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:break-all;border-color:#9ABAD9;color:#fff;background-color:#409cff;}"
	echo ".tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}"
	echo ".tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}"
	echo ".tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}"
	echo ".tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}"
	echo ".tg .tg-0lax{text-align:left;vertical-align:top}"
	echo ".tg .tg-PASSED{background-color:lightgreen;text-align:left;vertical-align:top}"
	echo ".tg .tg-FAILED{background-color:red;text-align:left;vertical-align:top}"
	echo ".tg .tg-NOT_STARTED{background-color:lightgrey;text-align:left;vertical-align:top}"
	echo ".tg .tg-NOT_REQUIRED{background-color:#E1E0A2;text-align:left;vertical-align:top}"
	echo "</style>"
	echo "<table class=\"tg\" style=\"undefined; width: 100%\">" 
	echo "<colgroup>"
	echo "<col style=\"width: 90px\">" 
	echo "<col style=\"width: 90px\">" 
	echo "<col style=\"width: 90px\">"
	echo "<col style=\"width: 90px\">"
	echo "</colgroup>"
	echo "<tr>"
	echo "<th class=\"tg-amwm\" colspan=\"100%\">${engine_name} GV DIFF REPORT</th>"
	echo "</tr>"
	echo "<tr>"
	echo "<td class=\"tg-1wig\" colspan=\"10%\">ENGINE_NAME</td>"
	echo "<td class=\"tg-0lax\" colspan=\"50%\">${engine_name}</td> "
	echo "<td class=\"tg-1wig\" colspan=\"20%\">Date</td>"
	echo "<td class=\"tg-0lax\" colspan=\"20%\">${date}</td> "
	echo "</tr>"
	echo "</table>"
}
sub_table_gv_diff_header(){
	Type=$1
	echo "<br><br><br>"
	echo "<table class=\"tg\" style=\"undefined; width: 100%\">"
	echo "<colgroup>"
		echo "<col style=\"width: 20%\">"
		echo "<col style=\"width: 20%\">"
		echo "<col style=\"width: 20%\">"
		echo "<col style=\"width: 20%\">"
		echo "<col style=\"width: 20%\">"
	echo "</colgroup>"
	echo "<tr>"
	echo "<th class=\"tg-amwm\" colspan=\"100%\">${Type}</th>"
	echo "</tr>"
	echo "<tr>"
	echo "<td style=\"color:333300\" class=\"tg-amwm\" colspan=\"1\">GV NAME</td>"
	echo "<td style=\"color:333300\" class=\"tg-amwm\" colspan=\"1\">OLD GV VALUE</td> "
	echo "<td style=\"color:333300\" class=\"tg-amwm\" colspan=\"3\">CURRENT GV VALUE</td>"
	echo "</tr>"
}



sub_table_header(){
	Type=$1
	echo "<br><br><br>"
	echo "<table class=\"tg\" style=\"undefined; width: 100%\">"
	echo "<colgroup>"
		echo "<col style=\"width: 20%\">"
		echo "<col style=\"width: 20%\">"
		echo "<col style=\"width: 20%\">"
		echo "<col style=\"width: 20%\">"
		echo "<col style=\"width: 20%\">"
	echo "</colgroup>"
	echo "<tr>"
	echo "<th class=\"tg-amwm\" colspan=\"100%\">${Type}</th>"
	echo "</tr>"
	echo "<tr>"
	echo "<td style=\"color:333300\" class=\"tg-amwm\" colspan=\"1\">GV NAME</td>"
	echo "<td style=\"color:333300\" class=\"tg-amwm\" colspan=\"4\">GV VALUE</td> "
	echo "</tr>"	
}

sub_table_footer(){
	echo "</table>"
}



PRESENT_PATH=`pwd`

format_xml_file(){
	passed_xml_file=$1
	output_file=$2
	
	cmd="cat ${passed_xml_file} | sed -ne '/NVPairs name=\\\"Global Variables\\\"/,\$p' | sed -ne '1,/<\/NVPairs>/p' | grep \"<NameValuePair>\" -A 2 | grep -v \"<NameValuePair>\" | grep -v \"\-\-\" | paste -d \" \"  - - | sed -e 's/<\/name>\(.*\)<value>/=/' | sed -e 's/<name>\(.*\)<\/value>/\1/' | sed -e 's/^[ \t]*//'"
	eval ${cmd} >"${output_file}"

	cmd="cat ${passed_xml_file} | sed -ne '/NVPairs name=\\\"Global Variables\\\"/,\$p' | sed -ne '1,/<\/NVPairs>/p' | grep \"<NameValuePairBoolean>\" -A 2 | grep -v \"<NameValuePairBoolean>\" | grep -v \"\-\-\" | paste -d \" \"  - - | sed -e 's/<\/name>\(.*\)<value>/=/' | sed -e 's/<name>\(.*\)<\/value>/\1/' | sed -e 's/^[ \t]*//'"
	eval ${cmd} >>"${output_file}"

	cmd="cat ${passed_xml_file} | sed -ne '/NVPairs name=\\\"Global Variables\\\"/,\$p' | sed -ne '1,/<\/NVPairs>/p' | grep \"<NameValuePairInteger>\" -A 2 | grep -v \"<NameValuePairInteger>\" | grep -v \"\-\-\" | paste -d \" \"  - - | sed -e 's/<\/name>\(.*\)<value>/=/' | sed -e 's/<name>\(.*\)<\/value>/\1/' | sed -e 's/^[ \t]*//'"
	eval ${cmd} >>"${output_file}"

	cmd="cat ${passed_xml_file} | sed -ne '/NVPairs name=\\\"Global Variables\\\"/,\$p' | sed -ne '1,/<\/NVPairs>/p' | grep \"<NameValuePairPassword>\" -A 2 | grep -v \"<NameValuePairPassword>\" | grep -v \"\-\-\" | paste -d \" \"  - - | sed -e 's/<\/name>\(.*\)<value>/=/' | sed -e 's/<name>\(.*\)<\/value>/\1/' | sed -e 's/^[ \t]*//'"
	eval ${cmd} >>"${output_file}"	
}

# Call function to get formatted output for Old XML.
format_xml_file "${old_xml}" "${engine_name}_old_formatted.out"


# Call function to get formatted output for new XML.
format_xml_file "${new_xml}" "${engine_name}_new_formatted.out"


# Empty all the output files.
>changed_gv_value
>added_gv_to_new_xml
>removed_gv_from_new_xml

# get GV diff for all the GV's present in new XML file.

while read -r line; do
		line=$(echo ${line} | sed $'s/\r//')
        if [[ ! -z "${line}" ]];then
                key=$(echo ${line} | cut -d '=' -f 1)
				value=$(echo ${line} | cut -d '=' -f 2-)
				# Search for the same key in Old XML file and if present get value for that.
				if [[ `grep "${key}=" "${engine_name}_old_formatted.out"` ]]; then
					value_old=$(grep "${key}=" "${engine_name}_old_formatted.out" | cut -d '=' -f 2-)
					if [[ "${value}" != "${value_old}" ]]; then
						echo "<tr>" >>changed_gv_value
						echo "<td colspan=\"1\"><small>${key}</small></td>" >>changed_gv_value
						echo "<td colspan=\"1\"><small>${value_old}</small></td> ">>changed_gv_value
						echo "<td colspan=\"3\"><small>${value}</small></td>" >>changed_gv_value
						echo "</tr>" >>changed_gv_value
					
						#echo "${key}=${value_old}" >>changed_gv_value
						#echo "${key}=${value}" >>changed_gv_value
					fi
				else
					#echo "${key}=${value}" >added_gv_to_new_xml
					echo "<tr>" >>added_gv_to_new_xml
					echo "<td colspan=\"1\"><small>${key}</small></td>" >>added_gv_to_new_xml
					echo "<td colspan=\"4\"><small>${value}</small></td>" >>added_gv_to_new_xml
					echo "</tr>" >>added_gv_to_new_xml
				fi
		fi
done <<< "$(cat ${engine_name}_new_formatted.out | egrep '\S' | egrep -v "#" | sed 's/^ //')"


# get GV diff for all the GV's present in OLD XML file. Ignore if it is already present in new XML.

while read -r line; do
		line=$(echo ${line} | sed $'s/\r//')
        if [[ ! -z "${line}" ]];then
                key=$(echo ${line} | cut -d '=' -f 1)
				value=$(echo ${line} | cut -d '=' -f 2-)
				# Search for the same key in Old XML file and if present get value for that.
				if [[ ! `grep "${key}=" "${engine_name}_new_formatted.out"` ]]; then
					#echo "${key}=${value}" >>removed_gv_from_old_xml
					echo "<tr>" >>removed_gv_from_new_xml
					echo "<td colspan=\"1\"><small>${key}</small></td>" >>removed_gv_from_new_xml
					echo "<td colspan=\"4\"><small>${value}</small></td>" >>removed_gv_from_new_xml
					echo "</tr>" >>removed_gv_from_new_xml
				fi
		fi
done <<< "$(cat ${engine_name}_old_formatted.out | egrep '\S' | egrep -v "#" | sed 's/^ //')"






# construct report.
>"${engine_name}_GV_DIFF.html"
table_header >"${engine_name}_GV_DIFF.html"

sub_table_gv_diff_header "GV DIFF Report for the changed GV's" >>"${engine_name}_GV_DIFF.html"
cat changed_gv_value >>"${engine_name}_GV_DIFF.html"
sub_table_footer >>"${engine_name}_GV_DIFF.html"

sub_table_header "GV DIFF Report for the newly added GV's" >>"${engine_name}_GV_DIFF.html"
cat added_gv_to_new_xml >>"${engine_name}_GV_DIFF.html"
sub_table_footer >>"${engine_name}_GV_DIFF.html"

sub_table_header "GV DIFF Report for the removed GV's " >>"${engine_name}_GV_DIFF.html"
cat removed_gv_from_new_xml >>"${engine_name}_GV_DIFF.html"
sub_table_footer >>"${engine_name}_GV_DIFF.html"


# >"${engine_name}_GV_Diff_Report.txt"
# # Consolidate in a report.
# echo "--------------------------------------------------------------------------------------------------------------------------" > "${engine_name}_GV_Diff_Report.txt"
# echo "                                     ${engine_name} GV DIFF REPORT                                                        " >> "${engine_name}_GV_Diff_Report.txt"
# echo "--------------------------------------------------------------------------------------------------------------------------" >> "${engine_name}_GV_Diff_Report.txt"
# echo " DATE: $(date)" >> "${engine_name}_GV_Diff_Report.txt"
# echo "--------------------------------------------------------------------------------------------------------------------------" >> "${engine_name}_GV_Diff_Report.txt"
# echo "							GV DIFF Report for the changed GV's                                                             " >> "${engine_name}_GV_Diff_Report.txt"
# echo "--------------------------------------------------------------------------------------------------------------------------" >> "${engine_name}_GV_Diff_Report.txt"
# cat changed_gv_value  >> "${engine_name}_GV_Diff_Report.txt"
# echo "--------------------------------------------------------------------------------------------------------------------------" >> "${engine_name}_GV_Diff_Report.txt"
# echo "--------------------------------------------------------------------------------------------------------------------------" >> "${engine_name}_GV_Diff_Report.txt"
# echo "							GV DIFF Report for the newly added GV's                                                             " >> "${engine_name}_GV_Diff_Report.txt"
# echo "--------------------------------------------------------------------------------------------------------------------------" >> "${engine_name}_GV_Diff_Report.txt"
# cat added_gv_to_new_xml  >> "${engine_name}_GV_Diff_Report.txt"
# echo "--------------------------------------------------------------------------------------------------------------------------" >> "${engine_name}_GV_Diff_Report.txt"
# echo "--------------------------------------------------------------------------------------------------------------------------" >> "${engine_name}_GV_Diff_Report.txt"
# echo "							GV DIFF Report for the removed GV's                                                             " >> "${engine_name}_GV_Diff_Report.txt"
# echo "--------------------------------------------------------------------------------------------------------------------------" >> "${engine_name}_GV_Diff_Report.txt"
# cat removed_gv_from_old_xml  >> "${engine_name}_GV_Diff_Report.txt"
# echo "--------------------------------------------------------------------------------------------------------------------------" >> "${engine_name}_GV_Diff_Report.txt"




