NEXUS_USER="admin"
NEXUS_PASSWD="admin123"
NEXUS_URL="http://195.233.197.150:8081"
REPO_NAME="TIL_FRAMEWORK"
[[ ! -z "$1" ]] && DESIGNTIMELIBS_FILE=$1 || { echo "ERROR: Please provide designtimelibs path"; exit 1; }

echo "passed file is: ${DESIGNTIMELIBS_FILE}"

# Get projlib.properies file from CVS
# rm buildprojlib.properties
mkdir -p ./projlib/TIL_DELIVERY01/designer
cp ${DESIGNTIMELIBS_FILE} ./projlib
cd ./projlib
PRESENT_PATH=`pwd`

PRESENT_PATH=$(echo ${PRESENT_PATH/\/c\//c:\/})
#echo "pwd is: ${PRESENT_PATH}"

# get projlib.properties from nexus. if download fails, fail the build and exit
cmd="curl -X GET -u ${NEXUS_USER}:${NEXUS_PASSWD} ${NEXUS_URL}/repository/${REPO_NAME}/TIL_DELIVERY01/designer/projlib.properties"
eval ${cmd} >"${PRESENT_PATH}"/TIL_DELIVERY01/designer/projlib.properties
[[ "$?" -eq 0 ]] && echo "projlib.properties downloaded from NEXUS successfully" || { echo "ERROR: projlib.properties download failed from NEXUS. Please check for errors."; exit 1; }

#cd -

        # Get projlib name from designtimelibs
cat "${DESIGNTIMELIBS_FILE}" | egrep -v "#" | while read line
do
                PROJLIB=$(echo $line | awk -F"=" '{print $2}')
                # Download projlib from Nexus given projlib name.
                if [ ! -z "${PROJLIB}" ]; then
                        chk=`grep ${PROJLIB} ${PRESENT_PATH}/TIL_DELIVERY01/designer/projlib.properties`
                        if [[ ! -z "${chk}" ]];then

                                        # Download projlib file from nexus for latest version.
                                        projlib_file_path=`grep "${PROJLIB}=" ${PRESENT_PATH}/TIL_DELIVERY01/designer/projlib.properties | sort -V | tail -1 | cut -d '=' -f 2 | tr -d ''`
                                        echo "projlib_file_path is : ${projlib_file_path}"
                                        projlib_dir=$(dirname "${projlib_file_path}")
                                        echo "projlib directory is:${projlib_dir}"
                                        mkdir -p "${projlib_dir}"
                                        projlib_proj_file=$(basename "${projlib_file_path}")
                                        cmd="curl -X GET -u ${NEXUS_USER}:${NEXUS_PASSWD} ${NEXUS_URL}/repository/${REPO_NAME}/${projlib_file_path}"
                                        echo "cmd is:$cmd"
                                        eval ${cmd} >"${projlib_dir}"/"${projlib_proj_file}"
                                        [[ "$?" -eq 0 ]] && echo "${projlib_proj_file} downloaded from NEXUS successfully" || { echo "ERROR: ${projlib_proj_file} download failed from NEXUS. Please check for errors."; exit 1; }


                                        # Download txt file and xml file for latest version.
                                        txt_file_path=`grep "${PROJLIB}=" ${PRESENT_PATH}/TIL_DELIVERY01/designer/projlib.properties | sort -V | tail -1 | cut -d '=' -f 2 | sed -e 's/.projlib$/.txt/'`
                                        echo "txt_file_path is : ${txt_file_path}"
                                        projlib_dir=$(dirname "${txt_file_path}")
                                        mkdir -p "${projlib_dir}"
                                        projlib_txt_file=$(basename "${txt_file_path}")
                                        cmd="curl -X GET -u ${NEXUS_USER}:${NEXUS_PASSWD} ${NEXUS_URL}/repository/${REPO_NAME}/${txt_file_path}"
                                        echo "cmdis:$cmd"
                                        eval ${cmd} >"${projlib_dir}"/"${projlib_txt_file}"
                                        [[ "$?" -eq 0 ]] && echo "${projlib_txt_file} downloaded from NEXUS successfully" || { echo "ERROR: ${projlib_txt_file} download failed from NEXUS. Please check for errors."; exit 1; }

                                        # Download xml file for latest version
                                        xml_file_path=`echo "${txt_file_path}" | sed -e 's/.txt$/.xml/'`
                                        echo "xml_file_path is : ${xml_file_path}"
                                        projlib_xml_file=$(basename "${xml_file_path}")
                                        cmd="curl -X GET -u ${NEXUS_USER}:${NEXUS_PASSWD} ${NEXUS_URL}/repository/${REPO_NAME}/${xml_file_path}"
                                        eval ${cmd} >"${projlib_dir}"/"${projlib_xml_file}"
                                        [[ "$?" -eq 0 ]] && echo "${xml_file_path} downloaded from NEXUS successfully" || { echo "ERROR: ${xml_file_path} download failed from NEXUS. Please check for errors."; exit 1; }
                        else
                                        echo "DEBUG: NEW PROJLIB. Code yet to be implemented."; exit 1
                        fi
                fi
done
# Append present path to each of the line as /c/Users/KolliA/Desktop/Temp/Projlib_Utility

sed -i "s~=~=${PRESENT_PATH}\/~" "${PRESENT_PATH}"/TIL_DELIVERY01/designer/projlib.properties
#sed -i 's~/~\\~g' "${PRESENT_PATH}"/TIL_DELIVERY01/designer/projlib.properties
