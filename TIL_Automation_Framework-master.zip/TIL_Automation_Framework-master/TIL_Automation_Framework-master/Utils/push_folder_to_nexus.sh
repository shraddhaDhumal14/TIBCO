# This script tries to push all the folder content to Nexus with the directory structure intact.
# Step 1: Copy the directory which you want to push to nexus in local directory and also copy this script in the same location.
# Step 2: open GIT BASH and change permissions to 755(chmod 755 ./push_folder_to_nexus.sh)
# Usage: ./push_folder_to_nexus.sh "REPO_NAME" "SOURCE_DIR"
# REPO_NAME is the repository name in which we need to copy this directory.
# SOURCE_DIR is the folder which we need to push to Nexus. 


PRESENT_PATH=`pwd`
REPO_NAME=$1
SOURCE_DIR=$2

# Get projlib.properies file from CVS
# rm buildprojlib.properties


# CVS Checkout designtimelibs from project folder.
#cmd="cvs -d :pserver:sseernam:qaz_1234@10.33.53.170:/cvs checkout ${DESIGNTIMELIBS_PATH}"
#eval ${cmd}



# Now push all the files from TIL_DELIVERY01 and TIL_SOURCE files to nexus.
find "${SOURCE_DIR}" -type f | while read line
do
#./TIL_SOURCE/tools/delivery/ConnectivityServices/SMTP/LIB_SMTP_1_0_1.projlib
        line=${line#?}
        echo "line is: $line"
        target_dir=$(dirname "${line}")
        target_file=$(basename "${line}")
		line=${line#?}
        cmd="curl -X POST \"http://195.233.197.150:8081/service/rest/v1/components?repository=${REPO_NAME}\" -u admin:admin123 -H \"accept: application/json\" -H \"Content-Type: multipart/form-data\" -F \"raw.directory=${target_dir}/\" -F \"raw.asset1=@${line}\" -F \"raw.asset1.filename=${target_file}\""
        echo "command is: ${cmd}"
        eval ${cmd}
done
