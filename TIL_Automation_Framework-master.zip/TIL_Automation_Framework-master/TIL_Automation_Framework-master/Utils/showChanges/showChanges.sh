#!/bin/bash

echo Comparing master branch $1 with $2
echo 

if [ -e change.txt ];then
   rm change.txt
fi 

find Gateway-master | xargs -t -L1  ./diff_showallchanges.sh $1 $2  > /dev/null 

echo
echo "All changes saved in change.txt"
