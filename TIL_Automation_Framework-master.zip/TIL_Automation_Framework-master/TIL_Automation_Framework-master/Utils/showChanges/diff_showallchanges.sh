#!/bin/bash
set -e 

# if directory then ignore
if [ -d $3 ]; then
   exit 0
fi

# Params: Master branch root dir, Comparison branch root dir, Filename in repo

basefile=$(echo $3 | sed "s|$1/||g")
sourceFile=$3
targetFile=$2/$basefile

# add newline to end of file if not there to avoid spurious changes showing up
sed -i -e '$a\' $sourceFile
sed -i -e '$a\' $targetFile

lines=$(diff $sourceFile $targetFile | wc -l)

if [ $lines -gt 0 ]; then
   echo "************************************ CHANGES FOUND *****************************************" >&2
   echo "$sourceFile has changed in the new branch: adding changes to change.txt" >&2 
   echo >&2
   diff  $sourceFile $targetFile >&2 || true
   echo "$sourceFile - Changes found: " >> change.txt
   echo "-------------------------------------------------------------------------" >> change.txt
   diff $sourceFile $targetFile >> change.txt || true
   echo >> change.txt
   echo >&2
   echo "************************************ CHANGES FOUND *****************************************" >&2
   exit 0 
fi

