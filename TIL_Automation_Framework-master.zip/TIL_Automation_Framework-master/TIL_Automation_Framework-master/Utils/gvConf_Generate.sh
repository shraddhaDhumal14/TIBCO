#!/bin/sh
engine_name=$1
engine_name_ear_xml=$2
engine_name_env_xml=$3
env_gv_conf=$4
env_pr_conf=$5
PRESENT_PATH=`pwd`

dos2unix "${engine_name_ear_xml}"
dos2unix "${engine_name_env_xml}"
dos2unix "${env_gv_conf}"
dos2unix "${env_pr_conf}"

# Generate formatted output for engine_name_ear_xml

cmd="cat ${engine_name_ear_xml} | sed -ne '/NVPairs name=\\\"Global Variables\\\"/,\$p' | sed -ne '1,/<\/NVPairs>/p' | grep \"<NameValuePair>\" -A 2 | grep -v \"<NameValuePair>\" | grep -v \"\-\-\" | paste -d \" \"  - - | sed -e 's/<\/name>\(.*\)<value>/=/' | sed -e 's/<name>\(.*\)<\/value>/\1/' | sed -e 's/^[ \t]*//'"
eval ${cmd} >"${engine_name}_ear_xml_formatted"

cmd="cat ${engine_name_ear_xml} | sed -ne '/NVPairs name=\\\"Global Variables\\\"/,\$p' | sed -ne '1,/<\/NVPairs>/p' | grep \"<NameValuePairBoolean>\" -A 2 | grep -v \"<NameValuePairBoolean>\" | grep -v \"\-\-\" | paste -d \" \"  - - | sed -e 's/<\/name>\(.*\)<value>/=/' | sed -e 's/<name>\(.*\)<\/value>/\1/' | sed -e 's/^[ \t]*//'"
eval ${cmd} >>"${engine_name}_ear_xml_formatted"

cmd="cat ${engine_name_ear_xml} | sed -ne '/NVPairs name=\\\"Global Variables\\\"/,\$p' | sed -ne '1,/<\/NVPairs>/p' | grep \"<NameValuePairInteger>\" -A 2 | grep -v \"<NameValuePairInteger>\" | grep -v \"\-\-\" | paste -d \" \"  - - | sed -e 's/<\/name>\(.*\)<value>/=/' | sed -e 's/<name>\(.*\)<\/value>/\1/' | sed -e 's/^[ \t]*//'"
eval ${cmd} >>"${engine_name}_ear_xml_formatted"

cmd="cat ${engine_name_ear_xml} | sed -ne '/NVPairs name=\\\"Global Variables\\\"/,\$p' | sed -ne '1,/<\/NVPairs>/p' | grep \"<NameValuePairPassword>\" -A 2 | grep -v \"<NameValuePairPassword>\" | grep -v \"\-\-\" | paste -d \" \"  - - | sed -e 's/<\/name>\(.*\)<value>/=/' | sed -e 's/<name>\(.*\)<\/value>/\1/' | sed -e 's/^[ \t]*//'"
eval ${cmd} >>"${engine_name}_ear_xml_formatted"



# Generate formatted output for engine_name_env_xml

cmd="cat ${engine_name_env_xml} | sed -ne '/NVPairs name=\\\"Global Variables\\\"/,\$p' | sed -ne '1,/<\/NVPairs>/p' | grep \"<NameValuePair>\" -A 2 | grep -v \"<NameValuePair>\" | grep -v \"\-\-\" | paste -d \" \"  - - | sed -e 's/<\/name>\(.*\)<value>/=/' | sed -e 's/<name>\(.*\)<\/value>/\1/' | sed -e 's/^[ \t]*//'"
echo "command is: $cmd"
eval ${cmd} >"${engine_name}_env_xml_formatted"

cmd="cat ${engine_name_env_xml} | sed -ne '/NVPairs name=\\\"Global Variables\\\"/,\$p' | sed -ne '1,/<\/NVPairs>/p' | grep \"<NameValuePairBoolean>\" -A 2 | grep -v \"<NameValuePairBoolean>\" | grep -v \"\-\-\" | paste -d \" \"  - - | sed -e 's/<\/name>\(.*\)<value>/=/' | sed -e 's/<name>\(.*\)<\/value>/\1/' | sed -e 's/^[ \t]*//'"
eval ${cmd} >>"${engine_name}_env_xml_formatted"

cmd="cat ${engine_name_env_xml} | sed -ne '/NVPairs name=\\\"Global Variables\\\"/,\$p' | sed -ne '1,/<\/NVPairs>/p' | grep \"<NameValuePairInteger>\" -A 2 | grep -v \"<NameValuePairInteger>\" | grep -v \"\-\-\" | paste -d \" \"  - - | sed -e 's/<\/name>\(.*\)<value>/=/' | sed -e 's/<name>\(.*\)<\/value>/\1/' | sed -e 's/^[ \t]*//'"
eval ${cmd} >>"${engine_name}_env_xml_formatted"


cmd="cat ${engine_name_env_xml} | sed -ne '/NVPairs name=\\\"Global Variables\\\"/,\$p' | sed -ne '1,/<\/NVPairs>/p' | grep \"<NameValuePairPassword>\" -A 2 | grep -v \"<NameValuePairPassword>\" | grep -v \"\-\-\" | paste -d \" \"  - - | sed -e 's/<\/name>\(.*\)<value>/=/' | sed -e 's/<name>\(.*\)<\/value>/\1/' | sed -e 's/^[ \t]*//'"
eval ${cmd} >>"${engine_name}_env_xml_formatted"


# delete the common entries in "engine_name_ear_xml_formatted" from "engine_name_ear_xml_formatted" and "engine_name_env_xml_formatted"
grep -vxFf "${engine_name}_env_xml_formatted" "${engine_name}_ear_xml_formatted" >"${engine_name}_ear_xml_formatted_commonout"


# Now replace all the values with production exported xml values.
>"${engine_name}_ear_xml_formatted_gvconf"
while IFS=' ' read -r line; do
        key_name=`echo $line | cut -d '=' -f 1`
        value=$( grep ${key_name}= ${engine_name}_env_xml_formatted | cut -d '=' -f 2)
        echo "${key_name}=${value}" >>"${engine_name}_ear_xml_formatted_gvconf"
done <"${engine_name}_ear_xml_formatted_commonout"



# delete values for the gv's in "engine_name_env_xml_formatted" which are matched in "env_gv_conf" file
mkdir -p "${PRESENT_PATH}/CONF_OUT"
>"${PRESENT_PATH}/CONF_OUT/${engine_name}.gvconf"
while IFS=' ' read -r line; do
        #echo "line is: $line"
        var_name=`echo $line | cut -d '=' -f 1`
        [[ `grep ^${var_name}= ${env_gv_conf}` ]] && echo "${var_name}=" >>"${PRESENT_PATH}/CONF_OUT/${engine_name}.gvconf" || echo "$line" >>"${PRESENT_PATH}/CONF_OUT/${engine_name}.gvconf"
done <"${engine_name}_ear_xml_formatted_gvconf"


#----------------------------------------------------------------------------------
# Clean up all the temporary files created.
rm -rf "${engine_name}_ear_xml_formatted"
rm -rf "${engine_name}_env_xml_formatted"
rm -rf "${engine_name}_ear_xml_formatted_commonout"
#---------------------------------------------------------------------------------

# Copy all process related properties to a separate file.
grep -i '^Processes/*' "${PRESENT_PATH}/CONF_OUT/${engine_name}.gvconf" | while IFS=' ' read -r prconf; do
        key_name=$(echo ${prconf}  | cut -d '=' -f 1)
        [[ $(grep ^${key_name}= ${env_pr_conf}) ]] && echo "${key_name}=" >>"${PRESENT_PATH}/CONF_OUT/${engine_name}.prconf" || echo "${prconf}" >>"${PRESENT_PATH}/CONF_OUT/${engine_name}.prconf"
done

# Delete Process key value pairs from gv conf file.
sed -i '/^Processes\/*/d' "${PRESENT_PATH}/CONF_OUT/${engine_name}.gvconf"

# Merge process key value pairs got from ${engine_name}.prconf to ${engine_name}.gvconf file
cat "${PRESENT_PATH}/CONF_OUT/${engine_name}.prconf" >>"${PRESENT_PATH}/CONF_OUT/${engine_name}.gvconf"

# Remove prconf file from CONF_OUT directory
rm -rf "${PRESENT_PATH}/CONF_OUT/${engine_name}.prconf"

echo "-------------------------------------------------------------------------------------------"
echo "Final engine_name_env.conf is: ${PRESENT_PATH}/CONF_OUT/${engine_name}.gvconf"
echo "-------------------------------------------------------------------------------------------"

