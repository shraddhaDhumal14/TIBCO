#!/bin/bash

if [ -e error.txt ];then
   rm error.txt
fi

echo Comparing master branch $1 with $2
echo 

find Gateway-master | xargs -t -L1  ./1diff.sh $1 $2  > /dev/null 

if [ -e error.txt ];then
   echo
   echo "*******************************************************************************************************************"
   echo "****************** ERROR: Files in the release branch have existing lines which have been modified! ***************"
   echo "*******************************************************************************************************************"
   
   exit -1
fi

