#!/bin/bash
set -e

# if directory then ignore
if [ -d $3 ]; then
   exit 0
fi

# Params: Master branch root dir, Comparison brnach root dir, Filename in repo

basefile=$(echo $3 | sed "s|$1/||g")
sourceFile=$3
targetFile=$2/$basefile

# add newline to end of file if not there to avoid spurious changes showing up
sed -i -e '$a\' $sourceFile
sed -i -e '$a\' $targetFile

lines=$(diff --changed-group-format='%<' --unchanged-group-format='' $sourceFile $targetFile | wc -l) || true

if [ $lines -gt 0 ]; then
   echo "************************************ ERROR *************************************************" >&2
   echo "ERROR: $sourceFile has changed in the new branch" >&2
   echo >&2
   diff  $sourceFile $targetFile >&2 || true
   echo "File Changed: $sourceFile"
   echo "------------------------------------------------------------------------------------------"
   diff  $sourceFile $targetFile > error.txt || true
   echo "************************************ ERROR *************************************************" >&2
   exit 0 
fi
