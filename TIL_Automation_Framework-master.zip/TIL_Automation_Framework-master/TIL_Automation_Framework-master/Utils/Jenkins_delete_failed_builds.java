pipeline {
	agent any
	stages {
		stage('DELETE_BUILDS') {
			steps {
                script {	
					def job_name = "${params.JOB_TO_DELETE}"
					def status_del = "${params.STATUS_TO_DELETE}"
					echo "JOB Name is: ${job_name}"
					echo "STATUS_TO_DELETE is: ${status_del}"
					jenkins.model.Jenkins.instance.getItemByFullName(job_name).builds.findAll { it.result == Result."${status_del}"}.each { it.delete() }
				}
			}
		}
	}
}