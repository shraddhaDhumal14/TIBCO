#! /bin/sh

#! /bin/sh

# This script downloads latest EAR from mexus for each of the engine listed in input file 
# Also, this would export XML for each of the engine from EAR and keep in separate folder.
# PREREQUISITES:
# 1. All the required engines list is updated in "engine_list" file in current directory.
# Usage: sh ./generate_ear_xml.sh "inputfile"
# OUTPUT:
# ./DOWNLOAD_EARS: In this directory, all the EAR's will be downloaded for the engines listed in input file engine_list
# ./EAR_VERSIONS: Engine names and versions downloaded will be updated in this file
# 
# ./missed_download: All the engines missed to download will be listed in this file.

BRANCH="CCS19.12"
ENGINES="ApplicationIntegration-Misc"
URL="195.233.197.150:8081"
REPO="LINKTEST_REPO"
#PROD_REPO="${PROD_REPO}"
GROUPID="TIL_BW"
NEXUS_UNAME="admin"
NEXUS_PWORD="admin123"
engine_list=$1
majorVersion=`echo "${BRANCH}" | awk -F 'CCS' '{print $2}' | cut -d '.' -f 1 | tr -d ' '`
minorVersion=`echo "${BRANCH}" | awk -F 'CCS' '{print $2}' | cut -d '.' -f 2 | tr -d ' '`
PRESENT_PATH=`pwd`
appmanage_bin_path="/opt/tibco/tra/5.10/bin"
echo "Minor Version is:${minorVersion}"

>missed_download
rm -rf ./DOWNLOAD_EARS
mkdir -p ${PRESENT_PATH}/DOWNLOAD_EARS
mkdir -p ${PRESENT_PATH}/EAR_XMLS
touch ${PRESENT_PATH}/EAR_VERSIONS

get_version(){

# Function to get current version in Nexus Repository.
        engine=$1
        majv=$2
        minv=$3
        cmd="curl -X GET \"http://${URL}/service/rest/v1/search?repository=${REPO}&name=${GROUPID}/${engine}/${majv}_${minv}_*/${engine}-${majv}_*.ear\""
        eval ${cmd} >nex_output
        ver=`cat nex_output | grep -e "name" | grep "${engine}.*.ear\"" | sort -V | tail -1 | cut -d '/' -f 3 | tr -d ' '`
        [[ $ver ]] && echo "$ver" || echo "0"
}

#for engine in $(echo ${ENGINES} | tr ";" "\n")
while read -r engine; do
        echo "Engine name is:${engine}"
        cur_version=$(get_version "$engine" "$majorVersion" "$minorVersion")
        rm -rf nex_output

        # Get current latest version from nexus.
        if [ "${cur_version}" != "0" ];then
                echo "${engine}: ${cur_version}" >>./EAR_VERSIONS

				# Construct a comamnd to download EAR from nexus and execute.
				run_cmd="curl -X GET -u admin:admin123 \"${URL}/repository/${REPO}/${GROUPID}/${engine}/${cur_version}/${engine}-${cur_version}.ear\""
				eval "${run_cmd}" >./DOWNLOAD_EARS/${engine}-${cur_version}.ear
				
				# Construct a command to export XML from EAR generated above and run the command.
				if [[ -f "${PRESENT_PATH}/DOWNLOAD_EARS/${engine}-${cur_version}.ear" ]];then 
					xml_export_cmd="${appmanage_bin_path}/AppManage -export -out ${PRESENT_PATH}/EAR_XMLS/${engine}-${cur_version}.xml -ear ${PRESENT_PATH}/DOWNLOAD_EARS/${engine}-${cur_version}.ear"
					cd /opt/tibco/tra/5.10/bin/
					echo "DEBUG: ${xml_export_cmd}"
					eval "${xml_export_cmd}"
					cd -
				else
					echo "DEBUG: EAR is not generated for the engine ${engine}. Please check."
				fi
        else
                echo "EAR file for ${engine} is not existing." >>missed_download
        fi
done <<< "$(cat "${engine_list}" | egrep '\S' | egrep -v "#" | sed 's/^ //')"


