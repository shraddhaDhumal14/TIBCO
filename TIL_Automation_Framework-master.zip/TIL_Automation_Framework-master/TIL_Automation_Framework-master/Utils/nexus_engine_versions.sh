#! /bin/sh +x
#Pulls the list of versions for a specific engine in Nexus

URL=$1
ENGINE=$2
REPO=$3
GROUPID=$4
majv=$5
minv=$6

#URL="http://195.233.197.150:8081"
#ENGINE="ApplicationIntegration-Misc"
#REPO="LINKTEST_REPO"
#GROUPID="TIL_SQL"
#majv="21"
#minv="6"

cmd="curl -sX GET \"${URL}/service/rest/v1/search?repository=${REPO}&name=${GROUPID}/${ENGINE}/${majv}_*/${ENGINE}-${majv}_${minv}_*.pom\""
eval ${cmd} > eng_lists
cmd="grep '\"group\"' eng_lists | cut -d ':' -f 2 | tr -d ' ' | sed 's/,//g' | sed 's/\"//g' | cut -d '/' -f 4 | xargs | sed -e 's/ /, /g'"
eval ${cmd} > nex_output
cat nex_output

