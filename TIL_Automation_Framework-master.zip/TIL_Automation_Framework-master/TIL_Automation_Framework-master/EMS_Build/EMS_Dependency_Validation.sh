#!/bin/sh
#
#
# This software is copyrighted.  Under the copyright laws, this software
# may not be copied, in whole or in part, without prior written consent
# of Vodafone Group. This software is provided under the terms of a
# license between Vodafone Group and the recipient, and its use is subject
# to the terms of that license.
#
# Description : This script generates a report of pending message count on all the queues/topics on EMS Buses
# Source the profile - this script doesn't require to call from CRON
# Commands Description:   1. -convertToEnv          -- Converts the ems topic/queue from .PR. to .STG02.
#                         2. -emsBackup             -- Generates backup of EMS buses impacted in the CRQ Folder
#                         3. -syntaxCheck           -- Performs the Syntax checks of ems buses but these checks are not included with the dependencies of RF and RB
#                         4. -dependencyCheck       -- performs the dependency checks of rollforward and rollback ems commands
#                         4. -deployEMSRollForward  -- Deploys the RollForward EMS scripts.
#                         5. -deployEMSRollback     -- Deploys the RollBack EMS scripts.
## PreRequisites:
# 1. Make sure all file names should be with your EMS Bus names. For example if it is CB02 related EMS bus, make sure ems script filename contains CB02
# Example: PR-03-deploy-NewDublin-CB02.ems
# 2. Create ems,rollback folders under the CRQ folder and place the required artifacts respectively.
# 3. Make sure your environment details are verified before proceeding with Automation tool.
#
#
# 2020Mar23 V 1.1 - Bhargav Sutapalli - EMS Deployment Automation Script as per requirement with CICD
###################################################################################################################################################

dt=`perl -e 'print scalar(localtime(time - 600)), "\n"'|awk '{if($3<9) print $1" "$2" "0$3" "$4" "$5 ; else print $0}'|awk '{if ($3<10) print $5" "$2" "$3" "substr($4,1,5); else print $5" "$2" "$3" "$4}'`
dt1=`date +"%Y%m%d%H%M"`
HOME_PATH=`pwd`
EMSBUS_SOURCEFILE="$HOME_PATH/Emsbuslist.txt"
EMS_ENV="$HOME_PATH/Ems_Environmentvariables.txt"
EMS_SYNTAX_FILE="/opt/tibco/tools/EMSAutomation"
CRQ_NUMBER=$2
ENGINE_NAME=$3
EMS_SCRIPT_PATH="$HOME_PATH/$CRQ_NUMBER/$ENGINE_NAME"
EMS_SCRIPT_ROLLBACK_PATH="$EMS_SCRIPT_PATH/rollback"
EMS_LOG_PATH="$EMS_SCRIPT_PATH/logs"
EMS_BACKUP_PATH="$EMS_SCRIPT_PATH/backup"
EMS_ROLLBACK_BACKUP_PATH="$EMS_SCRIPT_ROLLBACK_PATH/backup"
EMS_SYNTAX_ERRORFILE="$HOME_PATH/$CRQ_NUMBER/SyntaxError.txt"
EMS_OUTPUT="$EMS_LOG_PATH/emsoutput.txt"
EMS_Final_OUTPUT="$EMS_LOG_PATH/emsoutput_final.txt"
EMS_BACKUP_PATH_BKP="$EMS_SCRIPT_PATH/backup_$dt1"
EMS_ROLLBACK_BACKUP_PATH_BKP="$EMS_SCRIPT_ROLLBACK_PATH/backup_$dt1"
EMS_PROP_FILEPATH="$HOME_PATH/EMSProperties.txt"



#=================================================================
cd $EMS_SCRIPT_PATH

#======================================================
### Convert the Production pack to Staging pack.
#=======================================================
if [[ $1 = "-convertToEnv" ]]
  then
       grep -rl "UK.PR." ./ | xargs sed -i "s/UK.PR./UK.$ENV_VALUE./g" 2>/dev/null
       grep -rl "$SB01PRODROUTE" ./ | xargs sed -i "s/$SB01PRODROUTE/$SB01ENVROUTE/g" 2>/dev/null
       grep -rl "$SB02PRODROUTE" ./ | xargs sed -i "s/$SB02PRODROUTE/$SB02ENVROUTE/g" 2>/dev/null
       grep -rl "$SB03PRODROUTE" ./ | xargs sed -i "s/$SB03PRODROUTE/$SB03ENVROUTE/g" 2>/dev/null
       grep -rl "$PBPRODROUTE" ./ | xargs sed -i "s/$PBPRODROUTE/$PBENVROUTE/g" 2>/dev/null
       echo "
              Successfully Converted the EMS scripts w.r.to staging environment.
       "

#=========================================================================================================
# Backup of ems Configurations
## 
#=========================================================================================================

elif [[ $1 = "-emsBackup" ]]
  then
        sed -i '/^[[:space:]]*$/d' $EMS_SCRIPT_ROLLBACK_PATH/* 2>/dev/null
        sed -i '/^[[:space:]]*$/d' $EMS_SCRIPT_PATH/PR* 2>/dev/null

#===============================================================
## Backup Logic Starts from here
#===============================================================
          echo "converting EMS Files to dos2unix..."
          dos2unix $EMS_SCRIPT_PATH/*.ems
          dos2unix $EMS_SCRIPT_ROLLBACK_PATH/*.ems
          echo "
                 Generating the EMS CONFIG backup for all EMS buses impacted as part of $CRQ_NUMBER...
               "
          if [[ -f $EMS_SYNTAX_ERRORFILE ]]
             then
                  rm $EMS_SYNTAX_ERRORFILE
          fi
          if [[ ! -d $EMS_BACKUP_PATH ]]
             then
                  mkdir -p $EMS_BACKUP_PATH
          else
                  mv $EMS_BACKUP_PATH $EMS_BACKUP_PATH_BKP
                  mkdir -p $EMS_BACKUP_PATH
          fi
          if [[ ! -d $EMS_LOG_PATH ]]
             then
                  mkdir -p $EMS_LOG_PATH
          fi
          ls -lrt | awk '{print $9}'|grep '.ems'|awk -F'.' '{print $1}'|awk -F'-' '{print $NF}'|grep -v '^$' > $EMS_SCRIPT_PATH/emsbus.tmp
          cat $EMS_SCRIPT_PATH/emsbus.tmp |while read line
              do
                      if [[ ! -d $EMS_BACKUP_PATH/$line ]]
                        then
                            mkdir -p $EMS_BACKUP_PATH/$line
                      fi
                      t=`echo ${line}Server`
                      r=`echo ${line}ServerA`
                      c=`echo ${line}CONFIG`
                      p=`echo ${line}Port`
                      eval "echo \${$t}" > $EMS_SCRIPT_PATH/s.tmp
                      eval "echo \${$c}" > $EMS_SCRIPT_PATH/c.tmp
                      eval "echo \${$p}" > $EMS_SCRIPT_PATH/p.tmp
                      eval "echo \${$r}" > $EMS_SCRIPT_PATH/r.tmp
                      server=`cat $EMS_SCRIPT_PATH/s.tmp`
                      config=`cat $EMS_SCRIPT_PATH/c.tmp`
                      port=`cat $EMS_SCRIPT_PATH/p.tmp`
                      ServerA=`cat $EMS_SCRIPT_PATH/r.tmp`
                      chk=`ssh -q $server "ps -ef |grep $port|grep tibemsd|grep -v grep|wc -l" </dev/null`
                      if [[ $chk -ne 1 ]]
                         then
                                 echo "$line is not running on $server. Please check.."
                      fi
                      get_configpath=`echo show config|$EMS_PATH/tibemsadmin $ServerA -user $USR -password $PSWD|grep users|awk -F 'users' '{print $(NF-1)}'|awk -F'=' '{print $NF}'|tr -d '[[:blank:]]'`
                      scp -q $server:$get_configpath*.conf $EMS_BACKUP_PATH/$line
          done
          rm $EMS_SCRIPT_PATH/*.tmp
          echo "
                  Backup of EMS Bus configurations has been completed under $EMS_BACKUP_PATH
                "
#=============================================================================
#### Backup logic is completed
#=============================================================================

#=========================================================================================================
# Syntax checks of EMS pack- Option is more useful for LT & SIT
#=========================================================================================================
elif [[ $1 = "-dependencyCheck" ]]
  then
          echo "
                   Checking For RollForward & RollBack scripts Basic dependency Checks..

               "
          ls -lrt|awk '{print $9}'|grep ".ems"|while read line
             do
                cat $line | grep -v '#'|grep -v selector| while read cmd
                      do
                            bus=`echo $line|awk -F'.' '{print $1}'|awk -F'-' '{print $5}'|grep -v '^$'`
                            ver=( $cmd )
                            t=`echo ${ver[1]}s`
                            if [[ $t == factorys ]]
                                 then
                                      t=factories
                            fi
                            rbfile=`ls -lrt $EMS_SCRIPT_ROLLBACK_PATH/*$bus.ems |awk '{print $9}'`
#===============================================================
### Topic/Queue/bridge/Factory Creation validation Checks-START
#==============================================================

                            if [[ ${ver[0]} == create ]] && [[ ${ver[1]} != bridge ]] &&  [[ ${ver[1]} != factory ]] && [[ `grep ${ver[2]} $rbfile|grep "delete ${ver[1]}" |wc -l` -eq 0 ]]
                                then
                                     echo " $dt|${ver[2]} ${ver[1]} deletion command not provided in $bus RollBack script." >> $EMS_SYNTAX_ERRORFILE
                                     continue

                            elif [[ ${ver[0]} == create ]] && [[ ${ver[1]} != bridge ]] && [[ ${ver[1]} != factory ]] && [[ `grep ${ver[2]} $rbfile|grep create |wc -l` -eq 1 ]]
                                then
                                     echo " $dt|RollForward & RollBack scripts for having same commands ${ver[2]} for ${ver[0]} creation ." >> $EMS_SYNTAX_ERRORFILE
                                     continue
                            elif [[ ${ver[0]} == create ]] && [[ ${ver[1]} == factory ]] && [[ `grep ${ver[4]} $rbfile|grep create |wc -l` -ge 1 ]]
                                then
                                       echo " $dt|RollForward & RollBack scripts for having same commands for ${ver[1]} creation ." >> $EMS_SYNTAX_ERRORFILE
                                       continue
                            elif [[ ${ver[0]} == create ]] && [[ ${ver[1]} == factory ]] && [[ `grep ${ver[2]} $EMS_BACKUP_PATH/$bus/factories.conf |wc -l` -eq 1 ]]
                                then
                                       if [[ `grep ${ver[2]} $line |grep delete|wc -l` -ne 1 ]]
                                         then
                                               echo " $dt| ${ver[2]} deletion command not given in $bus rollword script and trying to create the same which is already exisits " >> $EMS_SYNTAX_ERRORFILE
                                       fi
                                       continue
                            elif [[ ${ver[0]} == create ]] && [[ `echo "${ver[2]}"|awk -F':' '{print $1}'` == source=topic ]] && [[ `echo "${ver[3]}"|awk -F':' '{print $1}'` == target=queue ]]
                                then
                                      t1=`echo ${ver[2]}|awk -F':' '{print $NF}'`
                                      if [[ `grep "${ver[2]}" $rbfile|grep delete |grep ${ver[3]}|wc -l` -ne 1 ]]
                                          then
                                               echo "$dt |Bridge deletion for $t1 is not provided in $rbfile script." >> $EMS_SYNTAX_ERRORFILE
                                      fi

                            fi
#==============================================================
### Topic/queue/bridge Creation validation Checks-END
#=============================================================
#======================================================
### Topic/Queue/bridge Deletion validation Checks-START
#=====================================================
                            if [[ ${ver[0]} == delete ]] && [[ ${ver[1]} != bridge ]] &&  [[ ${ver[1]} != factory ]] && [[ `grep ${ver[2]} $rbfile|grep "create ${ver[1]}" |wc -l` -ne 1 ]]
                                then
                                      echo " $dt|${ver[1]} creation command not provided in $bus RollBack script." >> $EMS_SYNTAX_ERRORFILE
                                      continue
                            elif [[ ${ver[0]} == delete ]] && [[ ${ver[1]} != bridge ]] &&[[ ${ver[1]} != factory ]] && [[ `grep ${ver[2]} $rbfile|grep delete|grep -v bridge|wc -l` -eq 1 ]]
                                then
                                      echo " $dt|RollForward & RollBack scripts for having same commands ${ver[2]} for $bus " >> $EMS_SYNTAX_ERRORFILE
                            fi
#===============================================================
### Topic/Queue/bridge Deletion validation Checks-END
#==============================================================
done
done
           echo "
                   Basic Validations for RollForward and RollBack scripts are completed.
                "
           if [[ `cat $EMS_SYNTAX_ERRORFILE 2>/dev/null |wc -l` -gt 0  ]]
               then
                     echo "
                             Please see below Syntax Errors observed from the EMS pack provided.
                          "
                     cat $EMS_SYNTAX_ERRORFILE
					 exit 1
           else
           echo "
                   There are no basic Syntax errors observed from the EMS pack provided. Please proceed with deployment of EMS pack
                 "
           fi


elif [[ $1 = "-syntaxCheck" ]]
   then
          echo "
                   Checking For RollForward & RollBack scripts Basic Syntax Checks..

               "
          ls -lrt|awk '{print $9}'|grep ".ems"|while read line
             do
                cat $line | grep -v '#'|grep -v selector| while read cmd
                      do
                            bus=`echo $line|awk -F'.' '{print $1}'|awk -F'-' '{print $5}'|grep -v '^$'`
                            ver=( $cmd )
                            t=`echo ${ver[1]}s`
                            if [[ $t == factorys ]]
                                 then
                                      t=factories
                            fi
                            rbfile=`ls -lrt $EMS_SCRIPT_ROLLBACK_PATH/*$bus.ems |awk '{print $9}'`
#===============================================================
### Topic/Queue/bridge/Factory Creation validation Checks-START
#==============================================================
#===============================================================
### Topic/Queue/bridge/Factory Creation validation Checks-START
#==============================================================
                            if [[ ${ver[0]} == create ]] && [[ ${ver[1]} != bridge ]] && [[ ${ver[1]} != factory ]] &&  [[ `grep ${ver[2]} $EMS_BACKUP_PATH/$bus/$t.conf |wc -l` -eq 1 ]]
                                then
                                     echo " $dt| ${ver[2]} is already exists in $bus ${ver[1]}s file " >> $EMS_SYNTAX_ERRORFILE
                                     continue
                                      if [[ `grep $t1 $EMS_SCRIPT_PATH/*$bus.ems|grep "create topic"|wc -l` -ne 1 ]] && [[ `grep $t1 $EMS_SCRIPT_PATH/*$bus.ems|grep "create queue"|wc -l` -ne 1 ]]
                                          then
                                               echo "$dt |$t1 is not available in topics/queues file in $bus" >> $EMS_SYNTAX_ERRORFILE
                                               if [[ `grep $t1 $EMS_BACKUP_PATH/$bus/topics.conf|wc -l` -ne 1 ]] || [[ `grep $t1 $EMS_BACKUP_PATH/$bus/queues.conf|wc -l` -ne 1 ]]
                                                 then
                                                      echo "$dt |$t1 is not available in topics/queues file in $bus" >> $EMS_SYNTAX_ERRORFILE
                                               fi
                                      fi
                                      continue
                            elif [[ ${ver[0]} == create ]] && [[ ${ver[1]} == queue ]]
                                then
##Handling Retry queues properties
                                     cat $EMS_PROP_FILEPATH|grep ${ver[1]}|awk -F'|' '{print $NF}'|awk -v RS='[,\n]' '{print}'|while read prop
                                         do
                                            if [[ `echo ${ver[3]}|grep $prop|wc -l` -ne 1 ]] && [[ `echo ${ver[2]}|grep Retry|wc -l` -ne 1 ]]
                                               then
                                                    echo $prop >> $EMS_SCRIPT_PATH/qprop.tmp
                                            fi
                                     done
                                      cat $EMS_PROP_FILEPATH|grep ${ver[1]} |awk -F'|' '{print $NF}'|awk -v RS='[,\n]' '{print}'|while read prop|grep maxRedelivery
                                         do
                                            if [[ `echo ${ver[3]}|grep $prop|wc -l` -ne 1 ]]
                                               then
                                                    echo $prop >> $EMS_SCRIPT_PATH/qprop.tmp
                                            fi

                                     done
                                     if [[ `cat $EMS_SCRIPT_PATH/qprop.tmp 2>/dev/null|wc -l` -ge 1 ]]
                                      then
                                          qprop1=`cat $EMS_SCRIPT_PATH/qprop.tmp |tr '\n' ','`
                                           echo "$dt | $qprop1 property is not provided for Queue creaton of ${ver[2]} in $bus Ems Script " >> $EMS_SYNTAX_ERRORFILE
                                           rm $EMS_SCRIPT_PATH/qprop.tmp 2>/dev/null
                                     fi
                                     continue
                            elif [[ $bus == SB* ]] && [[ ${ver[0]} == create ]] && [[ ${ver[1]} == topic ]]
                                then
                                     cat $EMS_PROP_FILEPATH|grep ${ver[1]}|awk -F'|' '{print $NF}'|awk -v RS='[,\n]' '{print}'|while read prop|grep -v secure
                                         do
                                            if [[ `echo ${ver[3]}|grep $prop|wc -l` -ne 1 ]]
                                               then
                                                    echo $prop >> $EMS_SCRIPT_PATH/tprop.tmp
                                            fi
                                     done
                                     if [[ `cat $EMS_SCRIPT_PATH/tprop.tmp 2>/dev/null|wc -l` -ge 1 ]]
                                      then
                                          tprop1=`cat $EMS_SCRIPT_PATH/tprop.tmp|tr '\n' ','`
                                           echo "$dt | $tprop1 property is not provided for Topic creaton of ${ver[2]} in $bus Ems script " >> $EMS_SYNTAX_ERRORFILE
                                           rm $EMS_SCRIPT_PATH/tprop.tmp 2>/dev/null
                                     fi
                                     continue
                            elif [[ $bus != SB* ]] && [[ ${ver[0]} == create ]] && [[ ${ver[1]} == topic ]]
                               then
                                     cat $EMS_PROP_FILEPATH|grep ${ver[1]}|awk -F'|' '{print $NF}'|awk -v RS='[,\n]' '{print}'|while read prop
                                         do
                                            if [[ `echo ${ver[3]}|grep $prop|wc -l` -ne 1 ]]
                                               then
                                                    echo $prop >> $EMS_SCRIPT_PATH/tprop1.tmp
                                            fi
                                     done
                                     if [[ `cat $EMS_SCRIPT_PATH/tprop1.tmp 2>/dev/null|wc -l` -ge 1 ]]
                                      then
                                            tprop2=`cat $EMS_SCRIPT_PATH/tprop1.tmp|tr '\n' ','`
                                            echo "$dt | $tprop2 property is not provided for Topic creaton of ${ver[2]} in $bus Ems script " >> $EMS_SYNTAX_ERRORFILE
                                            rm $EMS_SCRIPT_PATH/tprop1.tmp 2>/dev/null
                                     fi
                           elif [[ ${ver[0]} == create ]] && [[ `echo "${ver[2]}"|awk -F':' '{print $1}'` == source=topic ]] && [[ `echo "${ver[3]}"|awk -F':' '{print $1}'` == target=queue ]]
                                      then
                                      t1=`echo ${ver[2]}|awk -F':' '{print $NF}'`
                                      if [[ `echo "${ver[2]}"|awk -F':' '{print $2}'` == `echo "${ver[3]}"|awk -F':' '{print $2}'` ]]
                                          then
                                                 if [[ `grep $t1 $EMS_SCRIPT_PATH/*$bus.ems|grep "create topic"|wc -l` -eq 0 ]] && [[ `grep $t1 $EMS_SCRIPT_PATH/*$bus.ems|grep "create queue"|wc -l` -eq 0 ]]
                                                     then
                                                           #echo "$dt |$t1 is not available in topics/queues file in $bus" >> $EMS_SYNTAX_ERRORFILE
                                                           #continue
                                                           #echo " "
                                                           if [[ `grep $t1 $EMS_BACKUP_PATH/$bus/topics.conf|wc -l` -eq 0 ]] || [[ `grep $t1 $EMS_BACKUP_PATH/$bus/queues.conf|wc -l` -eq 0 ]]
                                                              then
                                                                   echo "$dt |$t1 is not available in topics/queues file in $bus" >> $EMS_SYNTAX_ERRORFILE
                                                           fi
                                                  fi
                                      else
                                            t2=`echo ${ver[3]}|awk -F':' '{print $NF}'`
                                             if [[ `grep $t1 $EMS_SCRIPT_PATH/*$bus.ems|grep "create topic"|wc -l` -eq 0 ]] && [[ `grep $t2 $EMS_SCRIPT_PATH/*$bus.ems|grep "create queue"|wc -l` -eq 0 ]]
                                                 then
                                                       if [[ `grep $t1 $EMS_BACKUP_PATH/$bus/topics.conf|wc -l` -eq 0 ]] && [[ `grep $t2 $EMS_BACKUP_PATH/$bus/queues.conf|wc -l` -eq 1 ]]
                                                          then
                                                                echo "$dt |$t1 is not available in topics file in $bus" >> $EMS_SYNTAX_ERRORFILE
                                                       elif [[ `grep $t2 $EMS_BACKUP_PATH/$bus/queues.conf|wc -l` -ne 1 ]] && [[ `grep $t1 $EMS_BACKUP_PATH/$bus/topics.conf|wc -l` -eq 1 ]]
                                                           then
                                                                 echo "$dt |$t2 is not available in queues file in $bus" >> $EMS_SYNTAX_ERRORFILE
                                                       fi
                                             fi
                                       fi
                            fi

#==============================================================
### Topic/queue/bridge Creation validation Checks-END
#=============================================================

#======================================================
### Topic/Queue/bridge Deletion validation Checks-START
#=====================================================

                            if [[ ${ver[0]} == delete ]] && [[ ${ver[1]} != bridge ]] && [[ ${ver[1]} != factory ]] && [[ `grep ${ver[2]} $EMS_BACKUP_PATH/$bus/$t.conf |wc -l` -eq 0 ]]
                                then
                                      echo "$dt|${ver[2]} is not exists in $bus ${ver[1]}s file which you are trying to delete " >> $EMS_SYNTAX_ERRORFILE
                                      continue
                            elif [[ ${ver[0]} == delete ]] && [[ ${ver[1]} == factory ]] &&  [[ `grep ${ver[2]} $EMS_BACKUP_PATH/$bus/factories.conf |wc -l` -eq 0 ]]
                               then
                                      echo "$dt|${ver[2]} is not exists in $bus ${ver[1]}s file which you are trying to delete " >> $EMS_SYNTAX_ERRORFILE
                                      continue
                            elif [[ ${ver[0]} == delete ]] && [[ `echo ${ver[2]}|awk -F':' '{print $1}'` == source=topic ]] && [[ `echo ${ver[3]}|awk -F':' '{print $1}'` == source=queue ]]
                                then
                                      t1=`echo ${ver[2]}|awk -F':' '{print $NF}'`
                                      if [[ `grep $t1 $EMS_BACKUP_PATH/$bus/topics.conf|grep -A 1 ${ver[1]}|grep queue|wc -l` -ne 1 ]]
                                          then
                                                 echo "$dt |Bridge is not available between topic and queue for $t1" >> $EMS_SYNTAX_ERRORFILE
                                      fi
                                      if [[ `grep $t1 $EMS_BACKUP_PATH/$bus/topics.conf|wc -l` -ne 1 ]] || [[ `grep $t1 $EMS_BACKUP_PATH/$bus/queues.conf|wc -l` -ne 1 ]]
                                          then
                                                 echo "$dt |${ver[2]} is not available in topics/queues file in $bus" >> $EMS_SYNTAX_ERRORFILE
                                      fi
                            fi

#===============================================================
### Topic/Queue/bridge Deletion validation Checks-END
#==============================================================
#===========================================================
### Grant command Validation checks -START
#============================================================

                            if [[ ${ver[0]} == grant ]] &&  [[ `grep ${ver[2]} $EMS_BACKUP_PATH/$bus/acl.conf |wc -l` -eq 0 ]]
                                then
                                     usr=`echo ${ver[3]}|awk -F'=' '{print $2}'`
                                     if [[ `grep ${ver[2]} $EMS_BACKUP_PATH/$bus/topics.conf |wc -l` -eq 1 ]]
                                       then
                                            if [[ `grep ${ver[2]} $EMS_BACKUP_PATH/$bus/topics.conf|wc -l` -eq 0 ]]
                                              then
                                                    echo "$dt|${ver[2]} topic creation command not provided $bus ems script for $usr you are trying to give permission " >> $EMS_SYNTAX_ERRORFILE
                                            fi
                                     fi
                                     continue
                            elif [[ ${ver[0]} == grant ]] && [[ `grep ${ver[2]} $EMS_BACKUP_PATH/$bus/acl.conf|wc -l` -ge 1 ]]
                                then
                                      usr=`echo "${ver[3]}" | awk -F'=' '{print $2}'`
                                      if [[ `grep ${ver[2]} $EMS_BACKUP_PATH/$bus/acl.conf|grep $usr|wc -l` -eq 1 ]]
                                          then
                                                echo "$dt|Permissions are already given to $usr for ${ver[2]} " >> $EMS_SYNTAX_ERRORFILE
                                      fi
                                      continue
                            elif [[ ${ver[0]} == grant ]] && [[ `grep $usr $EMS_BACKUP_PATH/$bus/users.conf|wc -l` -ne 1 ]]
                                then
                                      echo "$dt|$usr doesn't exists in $bus " >> $EMS_SYNTAX_ERRORFILE
                            fi

#===========================================================
### Grant command Validation checks -END
#============================================================

#============================================================
## Set command validation checks Starts
#============================================================

                            if [[ ${ver[0]} == setprop ]] && [[ ${ver[1]} == queue ]] &&  [[ `cat $EMS_BACKUP_PATH/$bus/queues.conf|grep ${ver[2]}|wc -l` -ne 1 ]]
                                 then
                                       echo "$dt | ${ver[2]} is not exists in $bus " >> $EMS_SYNTAX_ERRORFILE
                            fi
#============================================================
## Set command validation checks END
#============================================================


#============================================================
## Addprop command validation checks Starts
#============================================================

                            if [[ ${ver[0]} == addprop ]] && [[ ${ver[1]} == queue ]] &&  [[ `cat $EMS_BACKUP_PATH/$bus/queues.conf|grep ${ver[2]}|wc -l` -ne 1 ]]
                                 then
                                       echo "$dt | ${ver[2]} is not exists in $bus " >> $EMS_SYNTAX_ERRORFILE
                            fi
#============================================================
## Addprop command validation checks END
#============================================================
done
done
#============================================================
## Checking for Selectors command validation checks START
#============================================================

           ls -lrt|awk '{print $9}'|grep ".ems"|while read line1
               do
                   cat $line1 | grep -v '#'|grep selector| while read cmd1
                      do
                          bus=`echo $line1|awk -F'.' '{print $1}'|awk -F'-' '{print $5}'|grep -v '^$'`
                          ver=( $cmd1 )
                          rbfile=`ls -lrt $EMS_SCRIPT_ROLLBACK_PATH/*$bus.ems |awk '{print $9}'`
                          selc=`echo "$cmd1"|awk -F 'selector=' '{print $NF}'`
                          t1=`echo ${ver[2]}|awk -F':' '{print $NF}'`
                          #grep -A 3 $t1 backup/$bus/bridges.conf > $EMS_SCRIPT_PATH/brdg.tmp
                          grep -B 3 -e "$selc" backup/$bus/bridges.conf > $EMS_SCRIPT_PATH/brdg.tmp
                          if [[ `cat $EMS_SCRIPT_PATH/brdg.tmp 2>/dev/null|wc -l` -ge 1 ]]
                            then
                                 echo "$dt|Selectors are already available of $selc for ${ver[2]} bridge creation" >> $EMS_SYNTAX_ERRORFILE
                          fi
                          rm $EMS_SCRIPT_PATH/brdg.tmp 2>/dev/null
           done
           done
#============================================================
## Checking for Selectors command validation checks END
#============================================================

           echo "
                   Basic Validations for RollForward and RollBack scripts are completed.
                "

     if [[ `cat $EMS_SYNTAX_ERRORFILE 2>/dev/null |wc -l` -gt 0  ]]
         then
              echo "
                     Please see below Syntax Errors observed from the EMS pack provided.
              "
              cat $EMS_SYNTAX_ERRORFILE
     else
            echo "
                   There are no basic Syntax errors observed from the EMS pack provided. Please proceed with deployment of EMS pack
                 "
     fi
#=========================================================================================================
# Syntax checks of EMS Pack given logic ENDs here
#=========================================================================================================

#========================================================
## DeployEMS logic starts from here
#=======================================================

elif [[ $1 = '-deployEMSRollForward' ]]
   then
		               echo "
				       "
		               echo "Executing RollForward for EMS scripts present in $EMS_SCRIPT_PATH"
		               echo "====== $dt RollForward Output:===========" >> $EMS_OUTPUT
		               ls -lrt|awk '{print $9}'|grep ".ems"|while read line
		                  do  
				       bus=`echo $line|awk -F'.' '{print $1}'|awk -F'-' '{print $NF}'|grep -v '^$'`
			               echo "$bus -- EMS Execution is STARTED.."
			               echo "====== $dt RollForward Output for $bus:===========" >> $EMS_OUTPUT
                                       b1=`echo ${bus}ServerA`
			               b2=`echo ${bus}ServerB`
				       p=`echo ${bus}Port`
                                       b3=`echo ${bus}Server`
			               eval "echo \${$b1}" > $EMS_SCRIPT_PATH/s.tmp
			               eval "echo \${$b2}" > $EMS_SCRIPT_PATH/c.tmp
				       eval "echo \${$p}" > $EMS_SCRIPT_PATH/p.tmp
                                       eval "echo \${$b3}" > $EMS_SCRIPT_PATH/m.tmp
			               ServerA=`cat $EMS_SCRIPT_PATH/s.tmp`
			               ServerB=`cat $EMS_SCRIPT_PATH/c.tmp`
				       port=`cat $EMS_SCRIPT_PATH/p.tmp`
                                       Server=`cat $EMS_SCRIPT_PATH/m.tmp`
				       cd $EMS_PATH
				       #chk=`ssh -q $Server "ps -ef |grep $port|grep tibemsd|grep -v grep|wc -l" </dev/null`
				       chk=1
					   if [[ $chk -eq 1 ]]
			                 then
					      state_check=`echo i|$EMS_PATH/tibemsadmin $ServerA -user $USR -password $PSWD|grep State|awk '{print $2}'`
					      if [[ $state_check == active ]]
						 then
						      ./tibemsadmin -script $EMS_SCRIPT_PATH/$line -user $USR -password $PSWD -server "$ServerA" >> $EMS_OUTPUT
					      else
					              ./tibemsadmin -script $EMS_SCRIPT_PATH/$line -user $USR -password $PSWD -server "$ServerB" >> $EMS_OUTPUT
					      fi
				       else
					      echo "$bus is not running on primary Server $server"
                                              continue
				       fi
									 
				       if [[ `cat $EMS_OUTPUT |egrep "Error|Failed|not found" | wc -l` -ge 1 ]]
		                        then
				              echo "$bus -- EMS Execution is COMPLETED with Errors . Please check below"
				              cat $EMS_OUTPUT |egrep "Error|Failed|not found"
					      echo "
					      "
					      echo "If any Issues , please do contact for DL-TSSC-AO2-UK-Integration_TIL-RIG_L2@vodafone.com for quick assistance."									  
				       else
				              echo "$bus -- EMS Execution is COMPLETED Successfully."
					      echo "
					      "
				       fi
				       cat $EMS_OUTPUT >> $EMS_Final_OUTPUT
				       rm $EMS_OUTPUT
				       rm $EMS_SCRIPT_PATH/*.tmp
							  
			       done
                               echo " 
                                      Please review the overall EMS Output captured in $EMS_Final_OUTPUT
                               "
                               echo "
                                     If any Issues , please do contact for DL-TSSC-AO2-UK-Integration_TIL-RIG_L2@vodafone.com for quick assistance.
                               "
elif [[ $1 = '-deployEMSRollBack' ]]
      then
	     if [[ $4 = 'true' ]]; then
#===============================================================
## Backup Logic Starts from here for RollBack
#===============================================================
                       echo "converting RollBack EMS Files to dos2unix..."
	               dos2unix $EMS_SCRIPT_ROLLBACK_PATH/*.ems
                       echo "
	                      Generating the EMS CONFIG backup for all RollBack EMS buses impacted as part of $CRQ_NUMBER...
		       "
	               if [[ ! -d $EMS_ROLLBACK_BACKUP_PATH ]]
	                 then
		               mkdir -p $EMS_ROLLBACK_BACKUP_PATH
		       else
		             mv $EMS_ROLLBACK_BACKUP_PATH $EMS_ROLLBACK_BACKUP_PATH_BKP
		             mkdir -p $EMS_ROLLBACK_BACKUP_PATH
	               fi
	               if [[ ! -d $EMS_LOG_PATH ]]
	                  then
		               mkdir -p $EMS_LOG_PATH
	               fi
		       cd $EMS_SCRIPT_ROLLBACK_PATH
	               ls -lrt | awk '{print $9}'|grep '.ems'|awk -F'.' '{print $1}'|awk -F'-' '{print $NF}'|grep -v '^$' > $EMS_SCRIPT_PATH/emsbus.tmp
                       cat $EMS_SCRIPT_PATH/emsbus.tmp |while read line
	                 do
		             if [[ ! -d $EMS_ROLLBACK_BACKUP_PATH/$line ]]
			         then
				       mkdir -p $EMS_ROLLBACK_BACKUP_PATH/$line
			     fi
			     t=`echo ${line}Server`
			     c=`echo ${line}CONFIG`
			     p=`echo ${line}Port`
                             r=`echo ${line}ServerA`
			     eval "echo \${$t}" > $EMS_SCRIPT_PATH/s.tmp
			     eval "echo \${$c}" > $EMS_SCRIPT_PATH/c.tmp
			     eval "echo \${$p}" > $EMS_SCRIPT_PATH/p.tmp
                             eval "echo \${$r}" > $EMS_SCRIPT_PATH/r.tmp
			     server=`cat $EMS_SCRIPT_PATH/s.tmp`
                             ServerA=`cat $EMS_SCRIPT_PATH/r.tmp`
			     config=`cat $EMS_SCRIPT_PATH/c.tmp`
			     port=`cat $EMS_SCRIPT_PATH/p.tmp`
			     chk=`ssh -q $server "ps -ef |grep $port|grep tibemsd|grep -v grep|wc -l" </dev/null`
			     if [[ $chk -ne 1 ]]
			        then
			              echo "$line is not running on $server. Please check.."
                             fi					 
			     get_configpath=`echo show config|$EMS_PATH/tibemsadmin $ServerA -user $USR -password $PSWD|grep users|awk -F 'users' '{print $(NF-1)}'|awk -F'=' '{print $NF}'|tr -d '[[:blank:]]'`
		             scp -q $server:$get_configpath*.conf $EMS_ROLLBACK_BACKUP_PATH/$line
		      done
                      rm $EMS_SCRIPT_PATH/*.tmp
	              echo "
	                     Backup of RollBack EMS Bus configurations has been completed under $EMS_ROLLBACK_BACKUP_PATH.
                      "
        fi
#=============================================================================
#### Backup logic is completed for RollBack
#=============================================================================		
		      echo "Executing RollBack for EMS scripts present in $EMS_ROLLBACK_PATH"
		      echo "=========$dt RollBack Output:==============" >> $EMS_OUTPUT
		      cd $EMS_SCRIPT_ROLLBACK_PATH
		      ls -lrt|awk '{print $9}'|grep ".ems"|while read line
		         do  
		             bus=`echo $line|awk -F'.' '{print $1}'|awk -F'-' '{print $6}'|grep -v '^$'`
		             echo "$bus -- EMS Execution is STARTED.."	
		             echo "====== $dt RollBack Output for $bus:===========" >> $EMS_OUTPUT
                             b1=`echo ${bus}ServerA`
	                     b2=`echo ${bus}ServerB`
                             b3=`echo ${bus}Server`
                             p=`echo ${bus}Port`
			     eval "echo \${$b1}" > $EMS_SCRIPT_PATH/s.tmp
			     eval "echo \${$b2}" > $EMS_SCRIPT_PATH/c.tmp
                             eval "echo \${$b3}" > $EMS_SCRIPT_PATH/m.tmp
                             eval "echo \${$p}" > $EMS_SCRIPT_PATH/p.tmp
			     ServerA=`cat $EMS_SCRIPT_PATH/s.tmp`
			     ServerB=`cat $EMS_SCRIPT_PATH/c.tmp`
                             Server=`cat $EMS_SCRIPT_PATH/m.tmp`
                             port=`cat $EMS_SCRIPT_PATH/p.tmp`
		             cd $EMS_PATH
			     #chk=`ssh -q $Server "ps -ef |grep $port|grep tibemsd|grep -v grep|wc -l" </dev/null`
				 chk=1
			     if [[ $chk -eq 1 ]]
			        then
			              state_check=`echo i|$EMS_PATH/tibemsadmin $ServerA -user $USR -password $PSWD|grep State|awk '{print $2}'`									   
			             if [[ $state_check == active ]]
			                then
				              ./tibemsadmin -script $EMS_SCRIPT_ROLLBACK_PATH/$line -user $USR -password $PSWD -server "$ServerA" >> $EMS_OUTPUT
			             else
			                     ./tibemsadmin -script $EMS_SCRIPT_ROLLBACK_PATH/$line -user $USR -password $PSWD -server "$ServerB" >> $EMS_OUTPUT
			             fi
			     else
			         echo "$bus is not running on primary Server $server"
                                 continue
			    fi												 
			    if [[ `cat $EMS_OUTPUT |egrep "Error|Failed|not found"|wc -l` -ge 1 ]]
		               then
			             echo "$bus -- EMS Execution is Completed with ERRORS . Please check below"
			             cat $EMS_OUTPUT |egrep "Error|Failed|not found"
			    else
		                     echo "$bus -- EMS Execution is COMPLETED Successfully. "
		            	     echo "
					  "
   			     fi
	                     cat $EMS_OUTPUT >> $EMS_Final_OUTPUT
			     rm $EMS_OUTPUT
			      rm $EMS_SCRIPT_PATH/*.tmp
		done
                echo " Please review the overall EMS Output captured in $EMS_Final_OUTPUT
                     "
                echo "
                       If any Issues , please do contact for DL-TSSC-AO2-UK-Integration_TIL-RIG_L2@vodafone.com for quick assistance.
                    "

#========================================================
## DeployEMS logic ENDs  here
#=======================================================
else
     echo " 
	        Please provide the valid argument like -convertToEnv, -emsBackup, -syntaxCheck, -deployEMSRollForward, -deployEMSRollBack
	 "
fi
