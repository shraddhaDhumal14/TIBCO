BRANCH=$1 # CCS19.12
URL=$2 # 195.233.197.150:8081
REPO=$3 # LINKTEST_REPO
GROUPID=$4 # TIL_EMS
NEXUS_UNAME=$5 # admin
NEXUS_PWORD=$6 # admin123
engineName=$7 # Common_SQL_Changes

majv=`echo "${BRANCH}" | awk -F 'CCS' '{print $2}' | cut -d '.' -f 1 | tr -d ' '`
minv=`echo "${BRANCH}" | awk -F 'CCS' '{print $2}' | cut -d '.' -f 2- | tr '.' '_' | tr -d ' '`


cmd="curl -X GET \"http://${URL}/service/rest/v1/search?repository=${REPO}&name=${GROUPID}/${engineName}/${majv}_*/${engineName}-${majv}_${minv}_*.tar.gz\""
eval ${cmd} >nex_output
ver=`cat nex_output | grep -e "name" | grep "${engineName}.*.tar.gz\"" | grep "${majv}_${minv}_[0-9]*.tar.gz" | sort -V | tail -1 | cut -d '/' -f 3 | tr -d ' '`
if [ ! -z $ver ];then
   patch_number=`echo ${ver} | rev | cut -d '_' -f 1 | rev | tr -d ' '`
   trial_number=`echo ${ver} | rev | cut -d '_' -f 2- | rev | tr -d ' '`
   if [ "${trial_number}" == "${majv}_${minv}" ];then
                   nextEMSVersion="${trial_number}_$((patch_number + 1))"
   else
                   nextEMSVersion="${majv}_${minv}_1"
   fi
else
   nextEMSVersion="${majv}_${minv}_1"
fi

echo "${nextEMSVersion}"

