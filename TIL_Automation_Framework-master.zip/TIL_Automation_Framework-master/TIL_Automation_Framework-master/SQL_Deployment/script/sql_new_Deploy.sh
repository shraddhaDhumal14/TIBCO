#!/usr/bin/env bash
option=$1
environment=$2
flag=$3
CMD_LOG=""
sub_option1=`echo ${option} | cut -d '_' -f 1`
sub_option2=`echo ${option} | cut -d '_' -f 2`

###############################################################
sql_path=""
sql_username=""
sql_password=""
sql_host=""
sql_port=""
sql_servicename=""
###############################################################


load_parameters(){
        propDB=$1
        sql_path=`cat ${environment}_${propDB}.properties | grep "sql_path" | cut -d '=' -f2 | tr -d ' '`
        sql_username=`cat ${environment}_${propDB}.properties | grep "sql_username" | cut -d '=' -f2 | tr -d ' '`
        sql_password=`cat ${environment}_${propDB}.properties | grep "sql_password" | cut -d '=' -f2 | tr -d ' '`
        sql_host=`cat ${environment}_${propDB}.properties | grep "sql_host" | cut -d '=' -f2 | tr -d ' '`
        sql_port=`cat ${environment}_${propDB}.properties | grep "sql_port" | cut -d '=' -f2 | tr -d ' '`
        sql_servicename=`cat ${environment}_${propDB}.properties | grep "sql_servicename" | cut -d '=' -f2 | tr -d ' '`
        oracle_home=`cat ${environment}_${propDB}.properties | grep "ORACLE_HOME" | cut -d '=' -f2 | tr -d ' '`
}
for sqlFile in $(ls sql_${sub_option1}/data | grep -i ${sub_option2}.*.sql); do
        dbName=$(echo ${sqlFile} | sed 's/_/\n/g' | grep "DB")
        if [[ -f "`pwd`/${environment}_${dbName}.properties" ]];then
                load_parameters "${dbName}"
        else
                echo "ERROR: ${environment}_${dbName}.properties file does not exist. Please check"
				exit 1
        fi
        # Construct command to execute

        # Initialize log files.

        if [[ -f logs/SQL_Deployment.log ]]
        then
                echo "###########################################################################################################################" >> logs/SQL_Deployment-1.log
                date >> logs/SQL_Deployment-1.log
                echo "###########################################################################################################################" >> logs/SQL_Deployment-1.log
                `cat "logs/SQL_Deployment.log" >> "logs/SQL_Deployment-1.log"`
                `>  "logs/SQL_Deployment.log"`
        fi
        CMD_LOG="logs/sql_command.log"
        DEPLOYMENT_LOG="logs/SQL_Deployment.log"

		[[ ! -z "${oracle_home}" ]] && export ORACLE_HOME="${oracle_home}" || { echo "oracle_home path is not able to get from conf file."; exit 1; }
        
		set_chr="export NLS_LANG=AMERICAN_AMERICA.WE8ISO8859P1"
		echo "DEBUG: set_chr command is: ${set_chr}"
		eval ${set_chr}
		echo "NLS_LANG character set is: $NLS_LANG"
		env
		
        if [ ! -z "${sql_path}" ]; then
			CMD="echo exit | ${sql_path} -L \"${sql_username}/${sql_password}@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=${sql_host})(PORT=${sql_port}))(CONNECT_DATA=(SID=${sql_servicename})))\" @sql_${sub_option1}/data/${sqlFile}"
		else 
			echo "ERROR: Not able to get SQL_PATH from conf file."
			exit 1
		fi
		
        echo "DEBUG: command is: $CMD"
		echo $CMD >>${CMD_LOG}
        eval $CMD 2>&1 | tee ${CMD_LOG}
        cat ${CMD_LOG} >>${DEPLOYMENT_LOG}
        if [[ "${flag}" == "ignore" ]];then
                chk_cmd="cat ${CMD_LOG} | grep \"ORA\" | cut -d ':' -f 1 | egrep -v \"`cat ignorefile | tr '\n' '|'`\""
                echo "chk_cmd is: ${chk_cmd}"
                chk=`eval ${chk_cmd}`
                [[ ! -z "${chk}" ]] && { echo "ERROR: ${option} failed. Please check log files for errors."; exit 1; } || exit 0
        fi
done
