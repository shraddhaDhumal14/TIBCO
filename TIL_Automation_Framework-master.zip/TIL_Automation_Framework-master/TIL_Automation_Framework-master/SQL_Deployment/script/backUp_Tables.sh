#!/usr/bin/env bash
environment=$1
propFile=`pwd`/${environment}.properties
CMD_LOG=""
###############################################################
sql_path=""
sql_username=""
sql_password=""
sql_host=""
sql_port=""
sql_servicename=""
###############################################################

#########################################################################################
# Parse SQL properties from propFile

sql_path=`cat ${propFile} | grep "sql_path" | cut -d '=' -f2 | tr -d ' '`
sql_username=`cat ${propFile} | grep "sql_username" | cut -d '=' -f2 | tr -d ' '`
sql_password=`cat ${propFile} | grep "sql_password" | cut -d '=' -f2 | tr -d ' '`
sql_host=`cat ${propFile} | grep "sql_host" | cut -d '=' -f2 | tr -d ' '`
sql_port=`cat ${propFile} | grep "sql_port" | cut -d '=' -f2 | tr -d ' '`
sql_servicename=`cat ${propFile} | grep "sql_servicename" | cut -d '=' -f2 | tr -d ' '`
oracle_home=`cat ${propFile} | grep "ORACLE_HOME" | cut -d '=' -f2 | tr -d ' '`

#########################################################################################
# Retrieve tables from sql files for the changed queries.
# Get diif between previous rollforward and current rollforward files and retrieve tables from those queries.
prev_rollforward=`ls ./sql_previous/data/*_Rollforward.sql | head -1`
echo "prev_rollforward file is: ${prev_rollforward}"
cur_rollforward=`ls ./sql_current/data/*_Rollforward.sql | head -1`
echo "cur_rollforward file is: ${cur_rollforward}"
diff "${prev_rollforward}" "${cur_rollforward}" >sql_diff

# If there is any differences in sql statements, try to extract tables from those queries.

if [ -s sql_diff ];then
	cmd="grep -i 'INTO\|FROM\|JOIN' sql_diff | grep -v \"^[-#]\" | sed -r 's/.*?(FROM|INTO|JOIN)\s\`?([^\`( ]*).*/\2/gI' | sort -u"
	eval "$cmd" 2>&1 >sql_tables_changed
else
	echo "INFO: There are no tables affected with the current SQL changes. So, not taking backup for any tables."
	exit
fi

# Now try to take backup for the tables listed in file 'sql_tables_changed' , if the table exists.

while IFS= read -r tableName;do
	echo "Table name is: ${tableName}"
	# first try to execute command to check for table existense.
	tableName=`echo "$tableName" | tr '[:lower:]' '[:upper:]'`
	check_cmd="echo \"select tname from tab where tname = '${tableName}';\" | ${sql_path} -s \"MAP_OWN_ICC15/MAP_OWN_ICC15@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=195.233.199.13)(PORT=33000))(CONNECT_DATA=(SID=TIBTST1)))\""
	echo "DEBUG: Check_cmd is:${check_cmd}"
	export ORACLE_HOME="${oracle_home}"
	eval "${check_cmd}" 2>&1 | tee temp_log
	if cat temp_log | grep -v "no rows selected" ;then 
		export ORACLE_HOME="${oracle_home}"
		CMD="${sql_path} -s \"${sql_username}/${sql_password}@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=${sql_host})(PORT=${sql_port}))(CONNECT_DATA=(SID=${sql_servicename})))\" <<EOF
	set lines 256
	set linesize 200
	set wrap off
	set trimout on
	set tab off;
	SPOOL ${tableName}_backup.sql;
	select * from ${tableName};
	SPOOL OFF
	EXIT;
	EOF
	"
		echo "${CMD}"
		#echo "${CMD}" >"${CMD_LOG}"
		#eval "${CMD}" 2>&1 | tee ./logs/"$(date +%F)_${tableName}_backup"
	fi
done < sql_tables_changed
