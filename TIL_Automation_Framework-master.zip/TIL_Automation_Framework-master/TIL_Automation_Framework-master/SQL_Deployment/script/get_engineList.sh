#!/bin/sh
CRQ_NUM=$1
environment=$2
propFile=`pwd`/${environment}.properties


###############################################################
sql_path=""
sql_username=""
sql_password=""
sql_host=""
sql_port=""
sql_servicename=""
###############################################################

#########################################################################################
# Parse SQL properties from propFile

sql_path=`cat ${propFile} | grep "sql_path" | cut -d '=' -f2 | tr -d ' '`
sql_username=`cat ${propFile} | grep "sql_username" | cut -d '=' -f2 | tr -d ' '`
sql_password=`cat ${propFile} | grep "sql_password" | cut -d '=' -f2 | tr -d ' '`
sql_host=`cat ${propFile} | grep "sql_host" | cut -d '=' -f2 | tr -d ' '`
sql_port=`cat ${propFile} | grep "sql_port" | cut -d '=' -f2 | tr -d ' '`
sql_servicename=`cat ${propFile} | grep "sql_servicename" | cut -d '=' -f2 | tr -d ' '`
oracle_home=`cat ${propFile} | grep "ORACLE_HOME" | cut -d '=' -f2 | tr -d ' '`

# Construct command to execute
export ORACLE_HOME="${oracle_home}"
CMD="echo \"select engine_name from ENGINE_CRQ where crq_num='${CRQ_NUM}';\" | ${sql_path} -L \"${sql_username}/${sql_password}@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=${sql_host})(PORT=${sql_port}))(CONNECT_DATA=(SID=${sql_servicename})))\""
eval $CMD >engine_query.out
engine_list=`cat engine_query.out | sed -n '/^ENGINE_NAME/,/^SQL> Disconnected from Oracle Database/p' | tail -n +3 | head -n -2 | xargs | sed -e 's/ /;/g'`
echo "${engine_list}" >engineList.out
