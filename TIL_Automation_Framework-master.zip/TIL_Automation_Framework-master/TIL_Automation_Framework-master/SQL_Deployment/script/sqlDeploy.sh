#!/usr/bin/env bash
option=$1
environment=$2
propFile=`pwd`/${environment}.properties
CMD_LOG=""
###############################################################
sql_path=""
sql_username=""
sql_password=""
sql_host=""
sql_port=""
sql_servicename=""
###############################################################

#########################################################################################
# Parse SQL properties from propFile

sql_path=`cat ${propFile} | grep "sql_path" | cut -d '=' -f2 | tr -d ' '`
sql_username=`cat ${propFile} | grep "sql_username" | cut -d '=' -f2 | tr -d ' '`
sql_password=`cat ${propFile} | grep "sql_password" | cut -d '=' -f2 | tr -d ' '`
sql_host=`cat ${propFile} | grep "sql_host" | cut -d '=' -f2 | tr -d ' '`
sql_port=`cat ${propFile} | grep "sql_port" | cut -d '=' -f2 | tr -d ' '`
sql_servicename=`cat ${propFile} | grep "sql_servicename" | cut -d '=' -f2 | tr -d ' '`
oracle_home=`cat ${propFile} | grep "ORACLE_HOME" | cut -d '=' -f2 | tr -d ' '`

#########################################################################################

###############################################################
# Initialize log files.

if [[ -f logs/SQL_Deployment.log ]]
then
	echo "###############################################################################################################################################################################################" >> logs/SQL_Deployment-1.log
	date >> logs/SQL_Deployment-1.log
	echo "###############################################################################################################################################################################################" >> logs/SQL_Deployment-1.log

	`cat "logs/SQL_Deployment.log" >> "logs/SQL_Deployment-1.log"`
	`>  "logs/SQL_Deployment.log"`
fi
CMD_LOG="logs/sql_command.log"
DEPLOYMENT_LOG="logs/SQL_Deployment.log"




###############################################################
# Based on the option pick sqlFile from directories.
case  ${option}  in
        previous_rollback)
                sqlFile=`ls sql_previous/data | grep -i "rollback.sql" | tail -1 | tr -d ' '`
				sqlFile="sql_previous/data/${sqlFile}"
        ;;
        previous_rollforward)
                sqlFile=`ls sql_previous/data | grep -i "rollforward.sql" | tail -1 | tr -d ' '`
				sqlFile="sql_previous/data/${sqlFile}"
        ;;
        current_rollback)
                sqlFile=`ls sql_current/data | grep -i "rollback.sql" | tail -1 | tr -d ' '`
				sqlFile="sql_current/data/${sqlFile}"
        ;;
        current_rollforward)
                sqlFile=`ls sql_current/data | grep -i "rollforward.sql" | tail -1 | tr -d ' '`
				sqlFile="sql_current/data/${sqlFile}"
        ;;
        *)
esac

###############################################################
# Construct command to execute
export ORACLE_HOME="${oracle_home}"
CMD="${sql_path} -L \"${sql_username}/${sql_password}@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=${sql_host})(PORT=${sql_port}))(CONNECT_DATA=(SID=${sql_servicename})))\" @${sqlFile}"
echo $CMD >>${CMD_LOG}
eval $CMD 2>&1 | tee ${CMD_LOG}
cat ${CMD_LOG} >>${DEPLOYMENT_LOG}


# ToBeImplemented
###############################################################

###############################################################
# Run SQL file and write into log files 
# ToBeImplemented
###############################################################

