#!/usr/bin/env bash
environment=$1

CMD_LOG=""
###############################################################
sql_path=""
sql_username=""
sql_password=""
sql_host=""
sql_port=""
sql_servicename=""
###############################################################

#########################################################################################
# Parse SQL properties from propFile

load_parameters(){
        propDB=$1
        unset sql_path
        unset sql_username
        unset sql_password
        unset sql_host
        unset sql_port
        unset sql_servicename
        #unset oracle_home
        if [[ -f "${environment}_${propDB}.properties" ]]; then
                sql_path=`cat ${environment}_${propDB}.properties | grep "sql_path" | cut -d '=' -f2 | tr -d ' '`
                sql_username=`cat ${environment}_${propDB}.properties | grep "sql_username" | cut -d '=' -f2 | tr -d ' '`
                sql_password=`cat ${environment}_${propDB}.properties | grep "sql_password" | cut -d '=' -f2 | tr -d ' '`
                sql_host=`cat ${environment}_${propDB}.properties | grep "sql_host" | cut -d '=' -f2 | tr -d ' '`
                sql_port=`cat ${environment}_${propDB}.properties | grep "sql_port" | cut -d '=' -f2 | tr -d ' '`
                sql_servicename=`cat ${environment}_${propDB}.properties | grep -i "sql_servicename" | cut -d '=' -f2 | tr -d ' '`
				sql_sid=`cat ${environment}_${propDB}.properties | grep -i "sql_sid" | cut -d '=' -f2 | tr -d ' '`
                oracle_home=`cat ${environment}_${propDB}.properties | grep "ORACLE_HOME" | cut -d '=' -f2 | tr -d ' '`
        fi
}

#########################################################################################
# Retrieve tables from sql files for the changed queries.
# Get diif between previous rollforward and current rollforward files and retrieve tables from those queries.
# BACKUP_TABLES: RefDB:Table1;Table2;Table3, encryptDB:Table4;Table5;Table6

# Get backup tables from the sql_current folders from all the sql tables.

BACKUP_TABLES=""
table_list=""
cd ./sql_current/data
if [[ $(ls | grep -i refDB_rollforward.sql) ]]; then
        table_list=$(grep -v "^[-#]" $(ls | grep -i RefDB_rollforward.sql) | grep -i 'UPDATE\|INTO\|FROM\|JOIN' | grep -v "^[-#]" | sed -r "s/.*?(UPDATE |FROM|INTO|JOIN)\s?([^( ]*).*/\2/gI" | grep [[:alnum:]] | sort -u | tr '\n' ';' | sed 's/;$//')
        [[ "${table_list}" ]] && BACKUP_TABLES="RefDB:$(echo ${table_list} | sed 's/;$//')"
fi

table_list=""
if [[ $(ls | grep -i encryptDB_rollforward.sql) ]]; then
        table_list=$(grep -v "^[-#]" $(ls | grep -i refDB_rollforward.sql) | grep -i 'UPDATE\|INTO\|FROM\|JOIN' | grep -v "^[-#]" | sed -r "s/.*?(UPDATE |FROM|INTO|JOIN)\s?([^( ]*).*/\2/gI" | grep [[:alnum:]] | sort -u | tr '\n' ';' | sed 's/;$//')
		[[ "${table_list}" ]] && BACKUP_TABLES="${BACKUP_TABLES}, encryptDB:$(echo ${table_list} | sed 's/;$//')"
fi
cd -
echo "DEBUG: SQL Tables for backup are: ${BACKUP_TABLES}"

if [[ ! -z "${BACKUP_TABLES}" ]]; then 
	echo "${BACKUP_TABLES}" | tr "," "\n" | while read -r dbLine
	do
			DB_PARAM=$(echo $dbLine | cut -d ':' -f 1 | tr -d ' ')
			TABLE_NAMES=$(echo $dbLine | cut -d ':' -f 2 | tr -d ' ')
			load_parameters "${DB_PARAM}"
			export ORACLE_HOME="${oracle_home}"
			if [[ ! -z "${sql_path}" ]]; then
					echo "${TABLE_NAMES}" | tr ";" "\n" | while IFS=' ' read -r tableName
					do
							echo "Table name is: ${tableName}"
							echo "sql_username is: ${sql_username}"

							# first try to execute command to check for table existense.
							tableName=`echo "$tableName" | tr '[:lower:]' '[:upper:]'`
							if [[ ! -z "${sql_sid}" ]]; then
								check_cmd="echo \"select tname from tab where tname = '${tableName}';\" | ${sql_path} -s  \"${sql_username}/${sql_password}@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=${sql_host})(PORT=${sql_port}))(CONNECT_DATA=(SID=${sql_sid})))\""
							elif [[ ! -z "${sql_servicename}" ]]; then
								check_cmd="echo \"select tname from tab where tname = '${tableName}';\" | ${sql_path} -s  \"${sql_username}/${sql_password}@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=${sql_host})(PORT=${sql_port}))(CONNECT_DATA=(SERVICE_NAME=${sql_servicename})))\""
							else
								echo "ERROR: Please provide sql_sid or sql_servicename values in conf file"
								exit;
							fi
							echo "DEBUG: Check_cmd is:${check_cmd}"
							export ORACLE_HOME="${oracle_home}"
							eval "${check_cmd}" 2>&1 | tee temp_log

							if cat temp_log | grep -v "no rows selected" ;then
								export ORACLE_HOME="${oracle_home}"
								if [[ ! -z "${sql_sid}" ]]; then
									CMD="${sql_path} -s \"${sql_username}/${sql_password}@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=${sql_host})(PORT=${sql_port}))(CONNECT_DATA=(SID=${sql_sid})))\" <<EOF
												set heading off
												set pages 0
												set feedback off
												set long 32767
												set longc 32767
												set linesize 32767
												set trimspool on
												spool $(date +%F)_${tableName}_backup.csv;
												select * from ${tableName};
												SPOOL OFF
												EXIT;
												EOF
											"
								elif [[ ! -z "${sql_servicename}" ]]; then
									CMD="${sql_path} -s \"${sql_username}/${sql_password}@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=${sql_host})(PORT=${sql_port}))(CONNECT_DATA=(SERVICE_NAME=${sql_servicename})))\" <<EOF
												set heading off
												set pages 0
												set feedback off
												set long 32767
												set longc 32767
												set linesize 32767
												set trimspool on
												spool $(date +%F)_${tableName}_backup.csv;
												select * from ${tableName};
												SPOOL OFF
												EXIT;
												EOF
											"
								else
									echo "ERROR: Please provide sql_sid or sql_servicename values in conf file"
									exit;
								fi
								echo "${CMD}"
								#echo "${CMD}" >"${CMD_LOG}"
								eval "${CMD}" > /dev/null 2>&1
								#eval "${CMD}"
							else
								echo "INFO: Table name ${tableName} does not exist"
							fi
					done
			else
				echo "${DB_PARAM} properties not set properly. Skipping ${TABLE_NAMES} backup"
			fi
	done

	# Move backup tables to separate folder.
	mv *.csv ./BACKUP_TABLES/
else
	echo "NO Backup tables required"
fi
