#!/bin/sh
for sqlFile in $(ls *.sql);do
        chk=`echo ${sqlFile} | grep -i "DB_roll.*.sql"`
        if [[ -z "$chk" ]];then
                echo "ERROR: ${sqlFile} file name is not as per standard. Please check"
                exit 1
        fi
done
