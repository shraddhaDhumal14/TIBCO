import java.text.*
import groovy.time.*

def date = new Date();
def sdf = new SimpleDateFormat("yyyyMMddHHmmss");
def date_time = sdf.format(date)
date_now = new Date().format( 'dd-MM-yyyy' )

def elapsedTime(Closure closure){
    def timeStart = new Date()
    closure()
    def timeStop = new Date()
    return TimeCategory.minus(timeStop, timeStart).toMilliseconds()
}
                
def Git_Checkout (){

//Checkout Ansible Scripts for Job
                                             // checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Scripts"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]

//Checkout Scripts for Job
                                                
                                                checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "Stub"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/SIT_Test_Pipelines.git']]]
}

def get_body_build_summary(){
                                def date = new Date();
                                def sdf = new SimpleDateFormat("dd/MM/yyyy  HH:mm");
                                def date_time = sdf.format(date)
                                
                
                                def body_build_summary = """
                                                                <style type="text/css">
                                                                .tg  {border-collapse:collapse;border-spacing:0;border-color:#9ABAD9;margin:0px auto;}
                                                                .tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#444;background-color:#EBF5FF;}
                                                                .tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:#9ABAD9;color:#fff;background-color:#409cff;}
                                                                .tg .tg-1wig{font-weight:bold;text-align:left;vertical-align:top}
                                                                .tg .tg-2wig{font-weight:bold;text-align:center;vertical-align:top}
                                                                .tg .tg-hmp3{background-color:#D2E4FC;text-align:left;vertical-align:top}
                                                                .tg .tg-7dnc{background-color:#D2E4FC;font-weight:bold;text-align:left;vertical-align:top}
                                                                .tg .tg-amwm{font-weight:bold;text-align:center;vertical-align:top}
                                                                .tg .tg-0lax{text-align:left;vertical-align:top}
                                                                </style>
                                                                </style>
                                                                <table class="tg" style="undefined;table-layout: fixed; width: 100%">
                                                                <colgroup>
                                                                <col style="width: 90px">
                                                                <col style="width: 90px">
                                                                <col style="width: 90px">
                                                                <col style="width: 90px">
                                                                </colgroup>
                                                                  <tr>
                                                                                <th class="tg-amwm" colspan="6">Stub Deployment</th>
                                                                  </tr>
                                                                  <tr>
                                                                                <td class="tg-1wig" colspan="2">Submitted By</td>
                                                                                <td class="tg-0lax" colspan="4">${currentBuild.getRawBuild().getCauses()[0].getUserId()}</td>
                                                                  </tr>
                                                                  <tr>
                                                                                <td class="tg-1wig" colspan="2">Date</td>
                                                                                <td class="tg-0lax" colspan="4">${date_time}</td>
                                                                  </tr>
                                                                  <tr>     
                                                                                <td class="tg-1wig" colspan="2">Environment</td>
                                                                                <td class="tg-0lax" colspan="4">${ENV}</td>
                                                                  </tr>
                                                                  <tr>     
                                                                                <td class="tg-1wig" colspan="2">CRQ_Number</td>
                                                                                <td class="tg-0lax" colspan="4">${CRQ}</td>
                                                                  </tr>
                                                                  <tr>     
                                                                                <td class="tg-1wig" colspan="2">OperationName</td>
                                                                                <td class="tg-0lax" colspan="4">${OperationName}</td>
                                                                  </tr>
                                                            
                                                                </table>
                                                                
                                                                <br><br><br>
                                """
                                emailBody = body_build_summary
                                return body_build_summary
}


def  Preparation ()           {
                
                
                displayName = "StubXML_Deploy_${CRQ}_${BUILD_NUMBER}"
                currentBuild.displayName = "${displayName}"
                
                Git_Checkout ()
                
                //Below needs to be changed based on new file structure on GITHUB
                
                sh '''
                
			
			
                              cp -rf ${WORKSPACE}/Stub/Stub_Configuration ${WORKSPACE}/Stub_Configuration
                                cp -rf ${WORKSPACE}/Stub/Stub_Deployment ${WORKSPACE}/Stub_Deployment
                                rm -R ${WORKSPACE}/Stub
                                
                                
                '''
 
 //Below needs to be changed based on new file structure on GITHUB
if(fileExists("${WORKSPACE}/Stub_Configuration/${ENV}/Stub_Configuration.txt")) {                              
                                
                                sh '''                       
                                                cat ${WORKSPACE}/Stub_Configuration/${ENV}/Stub_Configuration.txt | grep ${OperationName} >> ${WORKSPACE}/data.txt
                                '''             
                                def File = "${WORKSPACE}/data.txt"
                                def readFile = new File("${File}")
                                def FileContent = readFile.readLines()
                                Content = "${FileContent}".split('\\|')
                                Operation = Content[0]
								gita_location = Content[1]
								
								
								echo "GITA location path : ${gita_location}"
								echo "Following is the Operation : ${Operation}"
                                                
                }
                
                sh '''
                cd ${WORKSPACE}/Stub_Configuration/${ENV}/Stub_Files/${OperationName}
                ls ${OperationName}.tar* > ${WORKSPACE}/FileList.txt
                '''
                stub_snap= ""
                def File1 = "${WORKSPACE}/FileList.txt"
                def readFile1 = new File("${File1}")
                def FileContent1 = readFile1.readLines()
                def Path = "${FileContent1}".split('\\[')
                def Path1 = Path[1].split('\\]')
                Files = Path1[0]
                FileList = Path1[0].split(', ')
                                                
                for (List in FileList) {
                                if (stub_snap.length() != 0) {
                                                stub_snap = "${stub_snap}" + "," + Content[1] + List                                           
                                }              else {
                                                // def first = List.split('\\[')
                                               stub_snap = "${OperationName}" + ":" + Content[1] + List
                                                }
                }
                //cert_snap = "${File_list}".split('\\]')
                println "${stub_snap}"
                def emailBody = "${get_body_build_summary()}"
                                emailext  mimeType: 'text/html', 
                                subject: "[Jenkins]:Stub Deployment",
                                from:"Stub_Deploy@vodafone.com",
                                to: "${dev_mailRecipients}",
                                body:"${emailBody}" + 
                                                                "<br><p><b><font size='2' color='Black'>STUB_Deploy_BUILDURL: <a href='${BUILD_URL}input'>${BUILD_URL}</a></font></b></p>" 
                                input 'Proceed with  Stub Deploy?'
                /*           def Input = input( id: 'userInput', message: 'Do you want to Proceed the Deployment or Not ?',
                                                                parameters: [[$class: 'ChoiceParameterDefinition', defaultValue: 'Proceed', 
                                                                                description:'describing choices', name:'nameChoice', choices: "Proceed"]
                                                                                ],
                                                                submitterParameter: 'submitter',
                                                                submitter: "${dev_mailRecipients}"
                                                                ) 
                                                                println("DEBUG: Choice selected is: " + Input.nameChoice)
                */
}



def get_conf_files_restart(deployParams) {
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}_Conf"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_BW_Application_Configuration.git']]]
    // make a directory with conf
	sh "mkdir -p ./${deployParams.Host}_Conf/conf"
    echo "${deployParams.engines}"
	echo "${deployParams.folderName}"
    def engine_list = deployParams.engines.split(',')
		for (txt in engine_list) {
			echo "${txt}"
			def eng_conf = txt
			echo eng_conf
			// check if engine input has folder name associated 
			if(eng_conf.contains('/')){
				def engine_params = eng_conf.split('/')
				def folderName = engine_params[0]
				def engine_name = engine_params[1]
				// copy appconf file from master repository
				sh "cp ./${deployParams.Host}_Conf/Restart_Configurations/Restart_Template.appconf ./${deployParams.Host}_Conf/conf/${engine_name}.appconf"
			
				// update values of appconf with Folder name provided during deployment
				sh  "sed -i '/FolderName=/ s/=.*/=${folderName}/'  ./${deployParams.Host}_Conf/conf/${engine_name}.appconf"
		  
				
			}
			else{
				
				// copy appconf file from master repository
			sh "cp ./${deployParams.Host}_Conf/Restart_Configurations/Restart_Template.appconf ./${deployParams.Host}_Conf/conf/${eng_conf}.appconf"
			
			}	

			
			// create directory if does not exist
		   // sh "mkdir -p ./${deployParams.Host}_Conf/${deployParams.ReleaseNumber}/${eng_conf}"
			// copy appconf file from master repository
			//sh "mv ./${deployParams.Host}_Conf/Restart_Configurations/Restart_Template.appconf ./${deployParams.Host}_Conf/conf/${eng_conf}.appconf"
			
			// update values of appconf with Folder name provided during deployment
			//sh  "sed -i '/FolderName=/ s/=.*/=${deployParams.folderName}/'  ./${deployParams.Host}_Conf/conf/${eng_conf}.appconf"
	   }
}




def deploy_restart_bw(deployParams) {
	//Checkout Framework Artefacts from automation repository
	script{
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "${deployParams.Host}"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
			
			//Checkout Environment specic configurations (tokens, properties files)
			checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "RESTART_ENV"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_TestEnv_Configurations.git']]]
			
			
			// create directory with name conf to copy config files
			sh "mkdir -p ./${deployParams.Host}/BW_Deployment/conf"
			
			// Copy deployment conf files  to conf directory in deployment script 
			
			sh "cp -r ./${deployParams.Host}_Conf/conf/* ./${deployParams.Host}/BW_Deployment/conf"
       
           	sh "mkdir -p ./${deployParams.Host}/BW_Deployment/host_vars/${deployParams.Host}_BW"

			// Copy Environment specififc files to Ansible Host Vars 
			sh "cp -r ./RESTART_ENV/BW_Configuration/${deployParams.Host}/* ./${deployParams.Host}/BW_Deployment/host_vars/${deployParams.Host}_BW"
			
			
		
			//Run ansible playbook to deploy artefacts into environment
			 ansiColor('xterm') {
    	     ansiblePlaybook(playbook: "./${deployParams.Host}/BW_Deployment/restartBW.yml", colorized: true, extras:'', extraVars: [host: "${deployParams.Host}_BW", engines: "${deployParams.engines}", datetime: "${deployParams.datetime}", crq_num: "${deployParams.crq_no}", bwDeployment: "${deployParams.bwDeployment}", bwRestart: "${deployParams.bwRestart}"])
	
		    }
    }
}




def Rollback_Input = ""


pipeline {
    agent any
                environment {
                                Content = ""
                                stub_snap = ""
                                FileList= ""
                                File_list = ""
                                Src_Path = "${WORKSPACE}/Stub_Configuration/${ENV}/Stub_Files/${OperationName}"
                                def Engine_List = ""
                                dev_mailRecipients = "DL-VESTibcoSupport@vodafone.com,Sagar.Deshmukh2@Vodafone.com,shraddha.khandgaure2@vodafone.com"
                                Files = ""
                                Status = ""
                                Signoff_Input = ""
                                BW_Input = ""
								backup_location = ""
                                
                }
    stages {
        stage ('Preparation') {
            steps {
                script {
                  cleanWs()  
                  Preparation ()
                    
                }
            }
        }
        stage ('Stub Deployment stage') {
            steps {
                script {
                  
                                                                                Deploy_Duration = elapsedTime {
                                                                                                ansiColor('xterm') {
                                                                                                                ansiblePlaybook (playbook: "${WORKSPACE}/Stub_Deployment/stubDeploy.yml", colorized: true, extras: '', extraVars: [host: "${ENV}_File", stub_snap: "${stub_snap}", datetime: "${date_time}", crq_num: "${CRQ}", Src_Path: "${Src_Path}", gita_location: "${gita_location}"])
                                                                                                }
                                                                                }
                                                                                Deploy_Duration = Deploy_Duration*0.001
                                                                                println("Deploy Duration in Sec: " + Deploy_Duration)
                                                                                println "Stubs Deployment Completed"
                }
            }
        }        
    
                                                                                                 
                                                stage ('Sign Off') {
                                                
            steps {
                script {
                                                                                input 'Proceed with  Signoff ?'                                                                                    
                                                                                                println "Signoff Completed"
                                                                                                
                                                                                
                                                                                }
                                                                }
                                                }
                                
                
                
                }
}

