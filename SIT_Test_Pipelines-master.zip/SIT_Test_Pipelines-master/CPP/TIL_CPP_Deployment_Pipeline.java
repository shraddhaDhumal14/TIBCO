// Calling global functions from shared libraries.
//@Library('myLibrary@master') _


//[CICD-476] Fix: import this package as part of the fix
import groovy.time.*

//[CICD-539] Insert Deployment metadata to release notes DB.
import groovy.json.JsonOutput
import groovy.sql.*
import java.sql.Driver


//[CICD-476] Fix: function to get elapsed time duration 
def elapsedTime(Closure closure){
    def timeStart = new Date()
    closure()
    def timeStop = new Date()
    return TimeCategory.minus(timeStop, timeStart).toMilliseconds()
}



def get_checkout_tag(deployParams){
	// this function is to get latest tag for the release on the passed git repository.
	// Asumption is tag is applied to Application configuration.
	// using TIL_BW_Application_Configuration.git for reference.
	// input: engine_name and release.
	// Step 1: checkout git repository from which we need to retrive tags.

	def majv = deployParams.release.split('CCS')[1].split('\\.')[0]
	def minv = deployParams.release.split('CCS')[1].split('\\.')[1]
	def git_tag = ""
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "GET_TAG"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: "https://github.vodafone.com/VFUK-INTEGRATION/TIL_BW_Application_Configuration.git"]]]
	//[CICD-353: Fix] - Fix to verify tag exists or not given bw_version.
	if(deployParams.containsKey('bw_version')){
		git_tag = sh (script: """cd ./GET_TAG; git tag -l ${deployParams.engine_name}_${deployParams.bw_version} | tail -1""", returnStdout: true).trim()
	} else {
		git_tag = sh (script: """cd ./GET_TAG; git tag -l ${deployParams.engine_name}_${majv}_${minv}_"[0-9]*" | sort -V | tail -1""", returnStdout: true).trim()
	}
	echo "DEBUG: GIT_TAG is: ${git_tag}"
	if(git_tag?.trim()) {
		return git_tag
	}
}



def trigger_results_email(deployParams){
	// This function is to trigger an email for the provided map.
	emailext mimeType: 'text/html',
	subject: "[Jenkins]: ${currentBuild.fullDisplayName}  - " + "Deployment Results Summary",
	from:"TIL_SIT_DEPLOYMENT@vodafone.com",
	to: "${mailRecipients}",
	body: 	"${emailFunctions.get_lt_results_summary map: deployParams.map, REPORT_STAGE: deployParams.REPORT_STAGE, crq_num: deployParams.crq_num, release: deployParams.release}" 
}

def trigger_versions_email(deployParams){
	// This function is to trigger an email for the provided map.
	emailext mimeType: 'text/html',
	 subject: "[Jenkins]: Deployment Version Summary",
	 from:"TIL_LINKTEST_DEPLOYMENT@vodafone.com",
	 to: "${mailRecipients}",
	 body: 	"${emailFunctions.get_engine_versions_summary map: deployParams.map, REPORT_STAGE: deployParams.REPORT_STAGE, Target_Env: params.Environment}" 
}

// Funcation to Get Email List
def get_approvers_list(String str){
	outlist = sh (script: """cat /opt/tibco/.jenkins/config.xml | sed -n \'/role name=\"${str}\"/,\$p\' | sed \'/role>/q\' | grep \"sid\" | cut -d \'>\' -f 2 | cut -d \'<\' -f 1 | paste -s -d, -""",
			returnStdout: true).trim()
	return """${outlist}"""
}

def email_gv_diff_report(deployParams) {
	// This function is to send GV diff report through an email.

	def gv_file_dir = "${WORKSPACE}/${deployParams.env}/BW_Deployment/GV_DIFF_SUMMARY"
	if(fileExists(gv_file_dir)){
		def gv_diff_path = new File("${WORKSPACE}/${deployParams.env}/BW_Deployment/GV_DIFF_SUMMARY")
		gv_diff_path.traverse{
			def eng_name = it.toString().split('/')[-1].split('_GV_DIFF.html')[0]
			def file_name = it.text
			emailext mimeType: 'text/html',
				subject: "[Jenkins]:${currentBuild.fullDisplayName}: GV DIFF REPORT for ${eng_name}",
				from:"TIL_DEPLOYMENTS_GV_DIFF_REPORT@vodafone.com",
				to: "${SIT_mailRecipients}",
				body: "${file_name}"
		}
	}	
}

def run_sql_generate_stage_function(){
		// Run SQL generate function to create workspace required for SQL Deployment.
		SQL_Functions.sql_generate_lower_env Environment:"${params.Environment}", nexus_group_id:"${env.SQL_GROUPID}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.NEXUS_REPO}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CRQ}", repo_artifact_ids: ENGINE_NAME + ':' + ENGINE_MAP[ENGINE_NAME]['SQL_VERSION'], datetime:"${date_now}", release:"${params.RELEASE}" 
}


def run_ems_generate_stage_function(){
		// EMS Build and generate stage function.
		EMS_Functions.ems_generate_lower_env Environment:"${params.Environment}", nexus_group_id:"${env.EMS_GROUPID}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.NEXUS_REPO}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CRQ}", repo_artifact_ids: ENGINE_NAME + ':' + ENGINE_MAP[ENGINE_NAME]['EMS_VERSION'], datetime:"${date_now}", release:"${params.RELEASE}", emsIgnore:"${env.emsIgnore}" 
}

def load_groovy_files() {
	// This function is to load all groovy files, where in common functions will be kept.
	emailFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/emailFunctions.groovy"
	mapFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/mapFunctions.groovy"
	nexusFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/nexusFunctions.groovy"
	gitFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/gitFunctions.groovy"
	EMS_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/EMSFunctions.groovy"
	SQL_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/SQLFunctions.groovy"
	BW_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/BWFunctions_SIT.groovy"
	FILE_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/FileFunctions.groovy"
	commonFunctions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/commonFunctions.groovy"
	
	//[CICD-539] Insert Deployment metadata to release notes DB.
	DB_Functions = load "${WORKSPACE}/JENKINS_FILE/commonFunctions/dbFunctions.groovy"	
}
def checkout_git_repositories(deployParams) {
	// This function is to checkout all the required GIT repositories.
	// Checkout Environment configurations.
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "ENV"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: "https://github.vodafone.com/VFUK-INTEGRATION/${env.EnvironmentRepository}.git"]]]
	
	// Checkout Automation files from GITHUB repository.
	checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "AUTOMATION"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_Automation_Framework.git']]]
	
	
	checkout poll: false, scm: ([$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: 'JENKINS_FILE']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_DevOps_Framework.git']]])

	// Checkout BW Configuration Repository
	if(deployParams.git_tag?.trim()) {
		checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: "refs/tags/${deployParams.git_tag}"]], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "APPLICATION"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_BW_Application_Configuration.git']]]
	} else {
		checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, quietOperation: true, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "APPLICATION"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/TIL_BW_Application_Configuration.git']]]	
	}
}

def run_sql_deploy_stage_function(){
	// This function is for SQL deployment.
	// Call sql deploy function by providing environment Details and engines
	SQL_Functions.sql_deploy_lower_env Environment:"${params.Environment}", nexus_group_id:"${env.SQL_GROUPID}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.NEXUS_REPO}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CRQ}", repo_artifact_ids: ENGINE_NAME + ':' + ENGINE_MAP[ENGINE_NAME]['SQL_VERSION'], datetime:"${date_now}", release:"${params.RELEASE}"
	
	def sql_deployment_success_file = "${WORKSPACE}/AUTOMATION/SQL_Deployment/sqlDeploy_success.txt"
	if(fileExists(sql_deployment_success_file)) {
		def sql_deployment_success_ouput = readFile("${WORKSPACE}/AUTOMATION/SQL_Deployment/sqlDeploy_success.txt")
		if (sql_deployment_success_ouput.size() != 0) {
			
			ENGINE_MAP[ENGINE_NAME]['SQL_Deployment'] = "PASSED"
		}
	}

	def sql_deployment_failed_file = "${WORKSPACE}/AUTOMATION/SQL_Deployment/sqlDeploy_failed.txt"
	if(fileExists(sql_deployment_failed_file)) {
		def sql_deployment_failed_ouput = readFile("${WORKSPACE}/AUTOMATION/SQL_Deployment/sqlDeploy_failed.txt")
		if (sql_deployment_failed_ouput.size() != 0) {
			ENGINE_MAP[ENGINE_NAME]['SQL_Deployment'] = "FAILED"
			ENGINE_MAP[ENGINE_NAME]['RESULT'] = "FAILED"
			
		}
	}		
	echo "SQL_DEPLOYMENT stage completed"
	
}


def run_sql_rollback_function(){
	// This function runs the rollback for SQL.
	SQL_Functions.sql_explicit_rollback_lower_env Environment:"${params.Environment}", crq_no:"${params.CRQ}", repo_artifact_ids: ENGINE_NAME + ':' + ENGINE_MAP[ENGINE_NAME]['SQL_VERSION'], datetime:"${date_now}", release:"${params.RELEASE}"
	echo "SQL Roll Back Completed"
}

def run_ems_deploy_stage_function(){
	// This function is for EMS deployment.
	
	// Call ems deploy function by providing Environment Details and engines
	EMS_Functions.ems_deployment_lower_env Environment:"${params.Environment}", crq_no:"${params.CRQ}", ems_engines:ENGINE_NAME + ':' + ENGINE_MAP[ENGINE_NAME]['EMS_VERSION'], datetime:"${date_now}", release:"${params.RELEASE}", emsIgnore:"${env.emsIgnore}", rollbackBackup:false
	
	// Update Maps with Successful engines
	def ems_deployment_success_file = "${WORKSPACE}/AUTOMATION/EMS_Deployment/deploy_failure.txt"
	if(fileExists(ems_deployment_success_file)) {
		def ems_deployment_success_ouput = readFile("${WORKSPACE}/AUTOMATION/EMS_Deployment/deploy_failure.txt")
		if (ems_deployment_success_ouput.size() != 0) {
			
			ENGINE_MAP[ENGINE_NAME]['EMS_Deployment'] = "FAILED"
			ENGINE_MAP[ENGINE_NAME]['RESULT'] = "FAILED"
			
		}
	}
	// Update Maps with failed engines
	def ems_deployment_failed_file = "${WORKSPACE}/AUTOMATION/EMS_Deployment/deploy_success.txt"
	if(fileExists(ems_deployment_failed_file)) {
		def ems_deployment_failed_ouput = readFile("${WORKSPACE}/AUTOMATION/EMS_Deployment/deploy_success.txt")
		if (ems_deployment_failed_ouput.size() != 0) {
			ENGINE_MAP[ENGINE_NAME]['EMS_Deployment'] = "PASSED"
		}
	}
	
		
}


def run_file_generate_stage_function(){
		
		// This function is to validate files for deployment and also to copy the files to workspace.
		// [CICD-1783]: Fix to checkout files with correct tag. Pass BW Version instead of use_tag filed here.
		if(ENGINE_MAP[ENGINE_NAME]['XML_FILES'] != 'NA' && ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"){
			chk = FILE_Functions.validate_files_lower_env Host: "${params.Environment}", Deployment_Type: "XML_Files", engine_files: ENGINE_MAP[ENGINE_NAME]['XML_FILES'], RELEASE: "${params.RELEASE}", engine_name: ENGINE_NAME, bw_ver: ENGINE_MAP[ENGINE_NAME]['BW_VERSION']
			if(chk == "FAIL"){
				ENGINE_MAP[ENGINE_NAME]['XML_Deployment'] = "FAILED"
				ENGINE_MAP[ENGINE_NAME]['RESULT'] = "FAILED"
			}
		}

		if(ENGINE_MAP[ENGINE_NAME]['JAR_FILES'] != 'NA' && ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"){
			chk = FILE_Functions.validate_files_lower_env Host: "${params.Environment}", Deployment_Type: "JAR_Files", engine_files: ENGINE_MAP[ENGINE_NAME]['JAR_FILES'], RELEASE: "${params.RELEASE}", engine_name: ENGINE_NAME, bw_ver: ENGINE_MAP[ENGINE_NAME]['BW_VERSION']
			if(chk == "FAIL"){
				ENGINE_MAP[ENGINE_NAME]['JAR_Deployment'] = "FAILED"
				ENGINE_MAP[ENGINE_NAME]['RESULT'] = "FAILED"
			}
		}
		if(ENGINE_MAP[ENGINE_NAME]['EMAIL_FILES'] != 'NA' && ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"){
			chk = FILE_Functions.validate_files_lower_env Host: "${params.Environment}", Deployment_Type: "Email_Template", engine_files: ENGINE_MAP[ENGINE_NAME]['EMAIL_FILES'], RELEASE: "${params.RELEASE}", engine_name: ENGINE_NAME, bw_ver: ENGINE_MAP[ENGINE_NAME]['BW_VERSION']
			if(chk == "FAIL"){
				ENGINE_MAP[ENGINE_NAME]['EMAIL_Deployment'] = "FAILED"
				ENGINE_MAP[ENGINE_NAME]['RESULT'] = "FAILED"
			}
		}	
}

def run_file_deploy_stage_function() {
	// This function is to deploy files into LinkTest Environment.
		// This function is to validate files for deployment and also to copy the files to workspace.
		if(ENGINE_MAP[ENGINE_NAME]['XML_FILES'] != 'NA' && ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"){
			FILE_Functions.deploy_files_lower_env Host:"${params.Environment}", Deployment_Type: "XML_Files", engine_files: ENGINE_NAME + ':' + ENGINE_MAP[ENGINE_NAME]['XML_FILES'], crq_no:"${params.CRQ}", datetime:"${date_now}", RELEASE: "${params.RELEASE}"
			ENGINE_MAP[ENGINE_NAME]['XML_Deployment'] = "PASSED"
		}
		
		if(ENGINE_MAP[ENGINE_NAME]['JAR_FILES'] != 'NA' && ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"){
			FILE_Functions.deploy_files_lower_env Host:"${params.Environment}", Deployment_Type: "JAR_Files", engine_files: ENGINE_NAME + ':' + ENGINE_MAP[ENGINE_NAME]['JAR_FILES'], crq_no:"${params.CRQ}", datetime:"${date_now}", RELEASE: "${params.RELEASE}"
			ENGINE_MAP[ENGINE_NAME]['JAR_Deployment'] = "PASSED"			
		}

		if(ENGINE_MAP[ENGINE_NAME]['EMAIL_FILES'] != 'NA' && ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"){
			FILE_Functions.deploy_files_lower_env Host:"${params.Environment}", Deployment_Type: "EMAIL_Files", engine_files: ENGINE_NAME + ':' + ENGINE_MAP[ENGINE_NAME]['EMAIL_FILES'], crq_no:"${params.CRQ}", datetime:"${date_now}", RELEASE: "${params.RELEASE}"
			ENGINE_MAP[ENGINE_NAME]['EMAIL_Deployment'] = "PASSED"
		}		
}


def preparation_function() {
	
	// This stage is to construct map and update values with the build input parameters
		date_now = new Date().format("YYYYMMddHHmmss")
		user = currentBuild.rawBuild.causes[0].userId
		
/* 		properties([parameters([
			string(defaultValue: 'CCS20.5', description: 'Please enter Release', name: 'RELEASE', trim: false), 
			string(defaultValue: 'Test', description: 'Please enter CRQ Number', name: 'CRQ', trim: false), 
			choice(choices: ['LinkTest'], description: 'Please select environment', name: 'Environment'), 
			string(defaultValue: 'test', description: 'Please enter description', name: 'Description', trim: false)
		])]) */
		
		// Release number as per BW deployment tool standard
		if(params.ONLY_GV){
			
			//get latest tag on env repository to get the configuration.
			checkout_tag = get_checkout_tag release: params.RELEASE, engine_name: params.ENGINE_NAME
			if(!checkout_tag?.trim()){
				println("DEBUG: NO GIT tag available for checkout on environment repository")
				//currentBuild.result = 'FAILURE'
			}
		} else if(BW_VERSION){
			//[CICD-353: Fix] - Fix to verify tag exists or not.
			checkout_tag = get_checkout_tag release: params.RELEASE, engine_name: params.ENGINE_NAME, bw_version: params.BW_VERSION
			if(!checkout_tag?.trim()){
				println("DEBUG: NO GIT tag available for checkout on environment repository for given BW_VERSION")
			}
			//checkout_tag = ENGINE_NAME + '_' + BW_VERSION
		}else if(params.FILE_DEPLOYMENT){
			
			//get latest tag on env repository to get the configuration.
			checkout_tag = get_checkout_tag release: params.RELEASE, engine_name: params.ENGINE_NAME
			if(!checkout_tag?.trim()){
				println("DEBUG: NO GIT tag available for checkout on environment repository")
				//currentBuild.result = 'FAILURE'
			}	
		}else {
			
			println("DEBUG: No specific checkout tag required. go with latest tag.")
			checkout_tag = ""
		}		
		
		
		// Checkout required GIT repositories.
		checkout_git_repositories git_tag: checkout_tag

		//Load all functions files from GIT. point to exact source file
		load_groovy_files()	

		// Validate input parameters by calling the global function. This is located in vars folder in GITHUB.
		commonFunctions.validate_input_parameters RELEASE: params.RELEASE, CRQ: params.CRQ, DESCRIPTION: params.Description, BUILD_REQUESTER: params.BUILD_REQUESTER
		if(params.BW_VERSION){
			commonFunctions.validate_input_parameters RELEASE: params.RELEASE, BW_VERSION: params.BW_VERSION 
		}
		if(params.EMS_VERSION){
			commonFunctions.validate_input_parameters RELEASE: params.RELEASE, EMS_VERSION: params.EMS_VERSION 
		}
		if(params.SQL_VERSION){
			commonFunctions.validate_input_parameters RELEASE: params.RELEASE, SQL_VERSION: params.SQL_VERSION 
		}		
		
		//[CICD-321]: Automate Applications.txt file to get engines list from domain itself..
		// commenting as we observed in the environment we are getting heap size error.
		//BW_Functions.get_domainAppsList Host: "${params.Environment}", environment: "${params.Environment}", datetime:"${date_now}"		
		
		bw_release_num = RELEASE.replace(".","_")

		majorVersion = RELEASE.split('CCS')[1].split('\\.')[0]
		minorVersion = RELEASE.split('CCS')[1].split('\\.')[1]	
	
		displayName = "${params.RELEASE}_${params.ENGINE_NAME}_${BUILD_NUMBER}"
		currentBuild.displayName = "${displayName}"	
		
		//[CICD-1454]: Added DR SIT/PAT environment in if condition
		if ("${params.Environment}" == "T1" || "${params.Environment}" == "T3" || "${params.Environment}" == "T4" || "${params.Environment}" == "T7" || "${params.Environment}" == "SIT04" || "${params.Environment}" == "DR_SIT" || "${params.Environment}" == "T8" || "${params.Environment}" == "TILSIT1" || "${params.Environment}" == "TILSIT2" || "${params.Environment}" == "TILSIT3"){
			println("Setting value to Env Prefix to SIT")
			Env_Prefix = "SIT" 
		}else if ("${params.Environment}" == "TILPAT01" || "${params.Environment}" == "TILPAT02") {
			println("Setting value to Env Prefix to Environment") 
			Env_Prefix = "NPP"
		}else if ("${params.Environment}" == "CPP1") {
			println("Setting value to Env Prefix to Environment") 
			Env_Prefix = "CPP1"
		}else if ("${params.Environment}" == "CPP2") {
			println("Setting value to Env Prefix to Environment") 
			Env_Prefix = "CPP2"
		}else {
			println("Setting value to Env Prefix to Environment") 
			Env_Prefix = "${params.Environment}"
		}
		
		//[CICD-476] && [CICD-374] Fix: Added BW, EMS and SQL Duration fields to the map.
		if(ENGINE_NAME != " "){
			ENGINE_MAP[ENGINE_NAME] = ['BW_VERSION':'NA', 'BW_FOLDER_NAME':'NA', 'BW_ENGINE_TYPE':'NA', 'EMS_VERSION':'NA', 'SQL_VERSION':'NA', 'XML_FILES':'NA', 'JAR_FILES':'NA', 'EMAIL_FILES':'NA', 'RESULT':'NA', 'BW_Generation':'NOT_REQUIRED', 'SQL_Deployment':'NOT_REQUIRED', 'EMS_Deployment':'NOT_REQUIRED', 'XML_Deployment':'NOT_REQUIRED', 'JAR_Deployment':'NOT_REQUIRED', 'EMAIL_Deployment':'NOT_REQUIRED', 'BW_Deployment':'NOT_REQUIRED',  'BW_Restart':'NOT_REQUIRED', 'EMS_DURATION':'0', 'SQL_DURATION':'0', 'BW_DURATION':'0', 'FILE_DURATION':'0']
		}
		
		// I fonly GV change required, then set the type as ONLY_GV.
		if(params.BW_VERSION) {
			//BW deployment required with given version. First validate this version is available in Nexus.
			version_check = nexusFunctions.validate_nexus_version REPO_URL: "${env.REPO_URL}", target_repo: "${env.NEXUS_REPO}", GROUPID: "${env.BW_GROUPID}", engine: ENGINE_NAME, version: params.BW_VERSION, extn: "ear"
			if(version_check.toInteger() != 0) {
				error("Given BW_VERSION is not exisis in NEXUS. Please Verify the version again.")
			}
			
			// Get the BW version for the engine given.
			bw_folder = gitFunctions.get_engine_bw_folder_name_from_gvconf engine: ENGINE_NAME
			if(bw_folder){
				ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME'] =  bw_folder
			} else {
				error("Check the engine name and Folder name in GV conf for proper format")
			}
			
			// get engine type from environment appconf file.
			def type_string = nexusFunctions.get_bw_deployment_type engines: ENGINE_NAME, target_env: "${params.Environment}"
			if(type_string){
				ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE'] =  type_string.split(':')[1]
			}

			ENGINE_MAP[ENGINE_NAME]['BW_VERSION'] =  "${params.BW_VERSION}"
			ENGINE_MAP[ENGINE_NAME]['BW_Generation'] =  'NOT_STARTED'
			ENGINE_MAP[ENGINE_NAME]['BW_Deployment'] =  'NOT_STARTED'
			ENGINE_MAP[ENGINE_NAME]['BW_Restart'] =  'NOT_STARTED'
			
		} else if (params.ONLY_GV){
			
			// Get the BW Folder name for the engine given.
			bw_folder = gitFunctions.get_engine_bw_folder_name_from_gvconf engine: ENGINE_NAME
			if(bw_folder){
				ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME'] =  bw_folder
			} else {
				error("Check the engine name and Folder name in GV conf for proper format")
			}
			
			ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE'] =  "OnlyGV"
			ENGINE_MAP[ENGINE_NAME]['BW_Generation'] =  'NOT_STARTED'
			ENGINE_MAP[ENGINE_NAME]['BW_Deployment'] =  'NOT_STARTED'
			ENGINE_MAP[ENGINE_NAME]['BW_Restart'] =  'NOT_STARTED'
			ENGINE_MAP[ENGINE_NAME]['BW_VERSION'] =  '0'
			
		} else {
			echo "DEBUG: NO BW Deployment selected."
		}
		
		if(params.EMS_DEPLOYMENT) {
			
				// Check if EMS-version exissts in Nexus SIT repository.
				//BW deployment required with given version. First validate this version is available in Nexus.
				version_check = nexusFunctions.validate_nexus_version REPO_URL: "${env.REPO_URL}", target_repo: "${env.NEXUS_REPO}", GROUPID: "${env.EMS_GROUPID}", engine: ENGINE_NAME, version: params.EMS_VERSION, extn: "tar.gz"
				if(version_check.toInteger() != 0) {
					error("Given EMS_VERSION is not exisis in NEXUS. Please Verify the version again.")
				}
			
				ENGINE_MAP[ENGINE_NAME]['EMS_VERSION'] =  "${params.EMS_VERSION}"
				ENGINE_MAP[ENGINE_NAME]['EMS_Deployment'] =  'NOT_STARTED'
		}		
		if(params.SQL_DEPLOYMENT) {
			
				//BW deployment required with given version. First validate this version is available in Nexus.
				version_check = nexusFunctions.validate_nexus_version REPO_URL: "${env.REPO_URL}", target_repo: "${env.NEXUS_REPO}", GROUPID: "${env.SQL_GROUPID}", engine: ENGINE_NAME, version: params.SQL_VERSION, extn: "tar.gz"
				if(version_check.toInteger() != 0) {
					error("Given SQL_VERSION is not exisis in NEXUS. Please Verify the version again.")
				}
				ENGINE_MAP[ENGINE_NAME]['SQL_Deployment'] =  'NOT_STARTED'
				ENGINE_MAP[ENGINE_NAME]['SQL_VERSION'] =  "${params.SQL_VERSION}"
				if(ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE'] == 'NA') {
					ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE'] = 'RESTART'
					ENGINE_MAP[ENGINE_NAME]['BW_Restart'] =  'NOT_STARTED'
					ENGINE_MAP[ENGINE_NAME]['BW_VERSION'] =  '1'
					// Get the BW Folder name for the engine given.
					bw_folder = gitFunctions.get_engine_bw_folder_name_from_gvconf engine: ENGINE_NAME
					if(bw_folder){
						ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME'] =  bw_folder
					} else {
						error("Check the engine name and Folder name in GV conf for proper format")
					}
				}
		}
		if(params.FILE_DEPLOYMENT) {
			
			// Set BW_ENGINE TYPE As RESTART only when any of the file deployment is selected.
			if(ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE'] == 'NA') {
					ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE'] = 'RESTART'
					ENGINE_MAP[ENGINE_NAME]['BW_Restart'] =  'NOT_STARTED'
					ENGINE_MAP[ENGINE_NAME]['BW_VERSION'] =  '1'
					// Get the BW Folder name for the engine given.
					bw_folder = gitFunctions.get_engine_bw_folder_name_from_gvconf engine: ENGINE_NAME
					if(bw_folder){
						ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME'] =  bw_folder
					} else {
						error("Check the engine name and Folder name in GV conf for proper format")
					}
			}
			
			FILE_DEPLOYMENT.split(',').each { type ->

				
				//[CICD-1783]: Pass ENGINE_MAP to the function to use the BW Version while deciding the tag. Question is should we fail the pipeline if we dont find any file deployment files here.
				def BW_VERS_MAP = ENGINE_MAP.findAll { it.value['BW_VERSION'] != "NA" }.collectEntries {bw_eng, bw_ver -> [bw_eng, bw_ver['BW_VERSION']]}
				
				if(type == "XML"){
					def XML_Files = gitFunctions.getEngineFiles engines: ENGINE_NAME, type: "XML", env: "${params.Environment}", RELEASE: "${params.RELEASE}", map: BW_VERS_MAP
					if(XML_Files){
						ENGINE_MAP[ENGINE_NAME]['XML_FILES'] =  XML_Files.split(':')[1]
						ENGINE_MAP[ENGINE_NAME]['XML_Deployment'] =  'NOT_STARTED'
					}
				}
				if(type == "JAR"){
					def JAR_Files = gitFunctions.getEngineFiles engines: ENGINE_NAME, type: "Jar", env: "${params.Environment}", RELEASE: "${params.RELEASE}", map: BW_VERS_MAP
					if(JAR_Files){
						ENGINE_MAP[ENGINE_NAME]['JAR_FILES'] =  JAR_Files.split(':')[1]
						ENGINE_MAP[ENGINE_NAME]['JAR_Deployment'] =  'NOT_STARTED'
					}
				}
				if(type == "EMAIL"){
					def Email_Files = gitFunctions.getEngineFiles engines: ENGINE_NAME, type: "Email", env: "${params.Environment}", RELEASE: "${params.RELEASE}", map: BW_VERS_MAP
					if(Email_Files){
						ENGINE_MAP[ENGINE_NAME]['EMAIL_FILES'] =  Email_Files.split(':')[1]
						ENGINE_MAP[ENGINE_NAME]['EMAIL_Deployment'] =  'NOT_STARTED'
					}
				}				
			}
			
	}
	
	// Adding BW Folder Name to None for SIT Pipelines
	
	// Change the folder names as per staging and production formats.
	
	if("${params.Environment}" == "DR_SIT" || "${params.Environment}" == "TILSIT1" || "${params.Environment}" == "TILSIT2" || "${params.Environment}" == "TILSIT3" || "${params.Environment}" == "TILPAT01" || "${params.Environment}" == "TILPAT02" || "${params.Environment}" == "DRCPP01" || "${params.Environment}" == "DRCPP03"){
		 if(ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME'] == "SB01" ){
				ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME'] = "ServiceBus1"
		  }
		if(ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME'] == "SB02" ){
				ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME'] = "ServiceBus2"
		  }		
	}else if("${params.Environment}" == "SIT04" || "${params.Environment}" == "T8"){
		if(ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME'] == "SB01" ){
			ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME'] = "SB01"
		}
		if(ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME'] == "SB02" ){
			ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME'] = "SB02"
		}
	} else {
		if(ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME'] == "SB01" ){
			ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME'] = "None"
		}
		if(ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME'] == "SB02" ){
			ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME'] = "None"
		}
	}
}


def bw_generate_stage(){
	

		// Construct Description for engine
		//user = currentBuild.rawBuild.causes[0].userId
		//println(user);
		//[CICD-519]: Fix to handle special characters in Description part
		String desc = "${params.Description}".replaceAll(/(!|"|@|#|\$|%|&|\\/|\(|\)|=|\?)/, /\\$0/)
		desc = desc + "|" + "${user}"	
	
		
		
		BW_type = ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE']
		echo "DEBUG: BW_type is: ${BW_type}"
		BW_Folder = ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME']
		echo "DEBUG: BW_Foldername is: ${BW_Folder}"
		group_id = 1
		patteren_string = BW_type+"_"+BW_Folder+"_"+group_id
		echo "DEBUG: Pattern string is: ${patteren_string}"
		
		def engines_versions = "${params.ENGINE_NAME}"+":"+"${params.BW_VERSION}"
		echo "DEBUG: Engine Name is: ${engines_versions}"
		
		def engines_list = "${params.ENGINE_NAME}"
			
		
		
		
		if(BW_type == "Existing"){
			
			println("DEBUG:" + group_id + "Generate conf file for type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list + " and engine version string is: " + engines_versions)
			
			BW_Functions.generate_conf_files_existing_engines engines:engines_versions, Host:"${params.Environment}", ReleaseNumber:"${params.RELEASE}", folderName:BW_Folder, description:"${desc}"
			
			BW_Functions.generate_bw_deployment Host:"${params.Environment}", nexus_group_id:"${env.BW_GROUPID}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.NEXUS_REPO}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CRQ}", engines:engines_versions, datetime:"${date_now}", engines_list:engines_list, EnvPrefix:"${Env_Prefix}", deployment_type:"EXISTING", release:"${params.RELEASE}", onlyGVChange:false, folderName:BW_Folder, bw_folder_release:bw_release_num, engine_group:patteren_string
		} else if(BW_type == "New") {
			
			println("DEBUG:" + group_id + "Generate conf file for type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list + " and engine version string is: " + engines_versions)
			BW_Functions.generate_conf_files_new_engines engines:engines_versions, Host:"${params.Environment}", ReleaseNumber:"${params.RELEASE}", folderName:BW_Folder, description:"${desc}", instanceCount:"${env.BW_InstanceCount}"
			// Call generate function by passing details
			
			BW_Functions.generate_bw_deployment Host:"${params.Environment}", nexus_group_id:"${env.BW_GROUPID}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.NEXUS_REPO}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CRQ}", engines:engines_versions, datetime:"${date_now}", engines_list:engines_list, EnvPrefix:"${Env_Prefix}", deployment_type:"NEW", release:"${params.RELEASE}", onlyGVChange:false, folderName:BW_Folder, bw_folder_release:bw_release_num, engine_group:patteren_string
		} else if (BW_type == "OnlyGV") {
			
			println("DEBUG:" + group_id + "Generate conf file for type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list + " and engine version string is: " + engines_versions)
			BW_Functions.generate_conf_files_gv_change engines:engines_versions, Host:"${params.Environment}", ReleaseNumber:"${params.RELEASE}", folderName:BW_Folder, description:"${desc}"
			
			// Call generate function by passing details
			BW_Functions.generate_bw_deployment Host:"${params.Environment}", nexus_group_id:"${env.BW_GROUPID}", nexus_user:"${env.NEXUS_USER}", nexus_passwd:"${env.NEXUS_PASSWD}", nexus_repo_id:"${env.NEXUS_REPO}", nexus_url:"${env.REPO_URL}", crq_no:"${params.CRQ}", engines:engines_versions, datetime:"${date_now}", engines_list:engines_list, EnvPrefix:"${Env_Prefix}", deployment_type:"EXISTING", release:"${params.RELEASE}", onlyGVChange:true, folderName:BW_Folder, bw_folder_release:bw_release_num, engine_group:patteren_string
			
		} 
		else if (BW_type == "RESTART") {
			
			println("DEBUG:" + group_id + "Generate conf file for type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list)
			BW_Functions.generate_conf_files_restart engines:engines_versions, Host:"${params.Environment}", ReleaseNumber:"${params.RELEASE}", folderName:BW_Folder, description:"${desc}"
			
			// Call generate function by passing details
			BW_Functions.generate_bw_restart Host:"${params.Environment}", crq_no:"${params.CRQ}", datetime:"${date_now}", engines_list:engines_list, deployment_type:"EXISTING", folderName:BW_Folder, bw_folder_release:bw_release_num, engine_group:patteren_string
			
		}
		else {
			println("DEBUG: Invalid Deployment type Identified. Please fix this issue")
		}
	
	
	// Update maps with failed engines from BW Generate
	def bw_generate_failed_file = "${WORKSPACE}/${params.Environment}/BW_Deployment/generate_failure.txt"
	if(fileExists(bw_generate_failed_file)) {
		def bw_generate_failed_ouput = readFile("${WORKSPACE}/${params.Environment}/BW_Deployment/generate_failure.txt")
		if (bw_generate_failed_ouput.size() != 0) {
			def failed_file = new File("${WORKSPACE}/${params.Environment}/BW_Deployment/generate_failure.txt")
			def failed_engines_list = failed_file.readLines().join(';')
			ENGINE_MAP[ENGINE_NAME]['BW_Generation'] = "FAILED"
			ENGINE_MAP[ENGINE_NAME]['RESULT'] = "FAILED"
			
		}
	} 

	// Update maps with success engines from BW Generate
	def bw_generate_success_file = "${WORKSPACE}/${params.Environment}/BW_Deployment/generate_success.txt"
	if(fileExists(bw_generate_success_file)) {
		def bw_generate_success_ouput = readFile("${WORKSPACE}/${params.Environment}/BW_Deployment/generate_success.txt")
		if (bw_generate_success_ouput.size() != 0) {
			def success_file = new File("${WORKSPACE}/${params.Environment}/BW_Deployment/generate_success.txt")
			def success_engines_list = success_file.readLines().join(';')
			ENGINE_MAP[ENGINE_NAME]['BW_Generation'] = "PASSED"
		}
	}
		 

}


// Function for BW Deployment
def bw_deployment_stage(){ 

			BW_type = ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE']
			echo "DEBUG: BW_type is: ${BW_type}"
			BW_Folder = ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME']
			echo "DEBUG: BW_Foldername is: ${BW_Folder}"
			group_id = 1
			patteren_string = BW_type+"_"+BW_Folder+"_"+group_id
			echo "DEBUG: Pattern string is: ${patteren_string}"
			
			def engines_versions = "${params.ENGINE_NAME}"+":"+"${params.BW_VERSION}"
			echo "DEBUG: Engine Name is: ${engines_versions}"
			
			def engines_list = "${params.ENGINE_NAME}"
		
		if(BW_type == "Existing"){
						
			println("DEBUG:" + group_id + "Deploy engines of type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list + " and engine version string is: " + engines_versions)
						
			// Run BW deploy function
			 BW_Functions.bw_deploy Host:"${params.Environment}", crq_no:"${params.CRQ}", engines:engines_versions, datetime:"${date_now}", engines_list:engines_list, appDynamics:false, FolderName:BW_Folder, release:"${params.RELEASE}", onlyGVChange:false, deployment_type:"ExistingEngines", bw_folder_release:bw_release_num, engine_group:patteren_string, EnvironmentRepository: "${env.EnvironmentRepository}"
			
		} else if(BW_type == "New") {
			println("DEBUG:" + group_id + "Deploy engines of type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list + " and engine version string is: " + engines_versions)
						
			// Run BW deploy function
			BW_Functions.bw_deploy Host:"${params.Environment}", crq_no:"${params.CRQ}", engines:engines_versions, datetime:"${date_now}", engines_list:engines_list, appDynamics:false, FolderName:BW_Folder, release:"${params.RELEASE}", onlyGVChange:false, deployment_type:"NewEngines", bw_folder_release:bw_release_num, engine_group:patteren_string, EnvironmentRepository: "${env.EnvironmentRepository}"
			
		
		} else if (BW_type == "OnlyGV") {
			println("DEBUG:" + group_id + "Deploy engines of type: " + BW_type + " with Folder name: " + BW_Folder + " for engines: " + engines_list + " and engine version string is: " + engines_versions)
						
			// Run BW deploy function
			BW_Functions.bw_deploy Host:"${params.Environment}", crq_no:"${params.CRQ}", engines:engines_versions, datetime:"${date_now}", engines_list:engines_list, appDynamics:false, FolderName:BW_Folder, release:"${params.RELEASE}", onlyGVChange:true, deployment_type:"ExistingEngines", bw_folder_release:bw_release_num, engine_group:patteren_string, EnvironmentRepository: "${env.EnvironmentRepository}"
			
						
		} else {
			println("DEBUG: Invalid Deployment type Identified. Nothing to deploy")
		}
	

	// Updating maps for failed engines
	
	def bw_deployment_failed_file = "${WORKSPACE}/${params.Environment}/BW_Deployment/deployment_failure.txt"
	if(fileExists(bw_deployment_failed_file)) {
		def bw_deployment_failed_ouput = readFile("${WORKSPACE}/${params.Environment}/BW_Deployment/deployment_failure.txt")
		if (bw_deployment_failed_ouput.size() != 0) {
			def failed_file = new File("${WORKSPACE}/${params.Environment}/BW_Deployment/deployment_failure.txt")
			ENGINE_MAP[ENGINE_NAME]['BW_Deployment'] = "FAILED"
			ENGINE_MAP[ENGINE_NAME]['RESULT'] = "FAILED"
			
		}
	}

 // Updating maps for engine engines

	def bw_deployment_success_file = "${WORKSPACE}/${params.Environment}/BW_Deployment/deployment_success.txt"
	if(fileExists(bw_deployment_success_file)) {
		def bw_deployment_success_ouput = readFile("${WORKSPACE}/${params.Environment}/BW_Deployment/deployment_success.txt")
		if (bw_deployment_success_ouput.size() != 0) {
			def success_file = new File("${WORKSPACE}/${params.Environment}/BW_Deployment/deployment_success.txt")
			ENGINE_MAP[ENGINE_NAME]['BW_Deployment'] = "PASSED"
		}
		
	// Sharing GV diff Report when deployement is successful
    
	email_gv_diff_report env: "${params.Environment}"
    // Calling Dashboard Publish job
	//build job: '/TIL_PIPELINES/Common_Jobs/Dashboard_Publish', parameters: [string(name: 'Environment', value: 'LinkTest'), string(name: 'Component', value: "${params.ENGINE_NAME}"), string(name: 'ArtefactVersion', value: "${params.BW_VERSION}"), string(name: 'Pipeline', value: 'TIL_BW_EMS_SQL_Pipeline'), string(name: 'Description', value: '')]	
	}
	// Trigger Result Email
	//trigger_results_email map: ENGINE_MAP, REPORT_STAGE: "BW_Deployment"

}


// Function for BW Restart

def bw_restart_stage(){ 
			
	BW_type = ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE']
	echo "DEBUG: BW_type is: ${BW_type}"
	BW_Folder = ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME']
	echo "DEBUG: BW_Foldername is: ${BW_Folder}"
	group_id = 1
	patteren_string = BW_type+"_"+BW_Folder+"_"+group_id
	def engines_list = "${params.ENGINE_NAME}"
	echo "DEBUG: Pattern string is: ${patteren_string}"
	// Calling Restart Function
	BW_Functions.bw_restart Host:"${params.Environment}", crq_no:"${params.CRQ}", datetime:"${date_now}", bw_folder_release:bw_release_num, engine_group:patteren_string, folderName:BW_Folder, engines_list_restart:engines_list	
		
	  
	// Check if BW Restart file exists for Failures
	def bw_restart_failed_file = "${WORKSPACE}/${params.Environment}/BW_Deployment/restart_failure.txt"
	if(fileExists(bw_restart_failed_file)) {
		def bw_restart_failed_ouput = readFile("${WORKSPACE}/${params.Environment}/BW_Deployment/restart_failure.txt")
		if (bw_restart_failed_ouput.size() != 0) {
		    // Reading Restart Failure
			def failed_file = new File("${WORKSPACE}/${params.Environment}/BW_Deployment/restart_failure.txt")
			ENGINE_MAP[ENGINE_NAME]['BW_Restart'] = "FAILED"
			ENGINE_MAP[ENGINE_NAME]['RESULT'] = "FAILED"
			
			
		}							
	}
	else{
		
		// Reading restart successful engines file 
		def bw_restart_success_file = "${WORKSPACE}/${params.Environment}/BW_Deployment/restart_success.txt"
	    if(fileExists(bw_restart_success_file)) {
			  def bw_restart_success_ouput = readFile("${WORKSPACE}/${params.Environment}/BW_Deployment/restart_success.txt")
			  def success_file = new File("${WORKSPACE}/${params.Environment}/BW_Deployment/restart_success.txt")
			  ENGINE_MAP[ENGINE_NAME]['BW_Restart'] = "PASSED"
			  ENGINE_MAP[ENGINE_NAME]['RESULT'] = "PASSED"
		  // Calling Dashboard Publish job
		  //[CICD-476] & [CICD-374]: blocking following code as common function has been called to update dashboard and stats file together after end of pipeline.
/* 		  if(BW_type == "Existing"){
			build job: '/TIL_PIPELINES/Common_Jobs/Dashboard_Publish', parameters: [string(name: 'Environment', value: "${params.Environment}"), string(name: 'Component', value: "${params.ENGINE_NAME}"), string(name: 'ArtefactVersion', value: "${params.BW_VERSION}"), string(name: 'Pipeline', value: 'TIL_BW_EMS_SQL_Pipeline'), string(name: 'Description', value: '')]
		  }
          else if(BW_type == "New") {
			  build job: '/TIL_PIPELINES/Common_Jobs/Dashboard_Publish', parameters: [string(name: 'Environment', value: "${params.Environment}"), string(name: 'Component', value: "${params.ENGINE_NAME}"), string(name: 'ArtefactVersion', value: "${params.BW_VERSION}"), string(name: 'Pipeline', value: 'TIL_BW_EMS_SQL_Pipeline'), string(name: 'Description', value: '')]
		 
		  }    */			  
		
		}
	}
	
	
}

def artefact_promotion_stage(){
	
	// Artefact promotion
	println("Artefact Promotion")
	SITBWApprovers = get_approvers_list('promoteSITApprovers')
	
	def promotion_email_body = "${emailFunctions.get_lt_results_summary map: ENGINE_MAP, REPORT_STAGE: 'PROMOTE_ARTEFACTS'}"
	
	emailext mimeType: 'text/html',
	subject: "[Jenkins]:${currentBuild.fullDisplayName}:Approval email for promote Artefact to STAGING",
	from:"TIL_DEPLOYMENTS@vodafone.com",
	to: "${SIT_mailRecipients}",
	body: 	"${promotion_email_body}" + "<br>" + 
		"<br><br><p><b><font size='4' color='Black'>Signoff SIT Changes for deploying into STAGING: <a href='${BUILD_URL}input'>${currentBuild.displayName}</a></font></b></p>"

	def testOptions = 'YES\nNO'
	def userInput = input(
		id: 'userInput', message: 'Do you want to promote Artefact to STAGING?',
		submitterParameter: 'submitter',
		submitter: "${SITBWApprovers}"
	)

	
	if(ENGINE_MAP[ENGINE_NAME]['RESULT'] == "PASSED" && ENGINE_MAP[ENGINE_NAME]['EMS_VERSION'] != "NA") {
		
		
		// Call artefacts promotion function with these details.
		artifactPromotion artifactId: ENGINE_NAME, classifier: '', debug: true, extension: 'tar.gz', groupId: "${env.EMS_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.Promotion_Repo}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.NEXUS_REPO}", stagingUser: "${env.NEXUS_USER}", version: ENGINE_MAP[ENGINE_NAME]['EMS_VERSION']
		
		artifactPromotion artifactId: ENGINE_NAME, classifier: '', debug: true, extension: 'txt', groupId: "${env.EMS_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.Promotion_Repo}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.NEXUS_REPO}", stagingUser: "${env.NEXUS_USER}", version: ENGINE_MAP[ENGINE_NAME]['EMS_VERSION']
	 }
	 
	 if(ENGINE_MAP[ENGINE_NAME]['RESULT'] == "PASSED" && ENGINE_MAP[ENGINE_NAME]['SQL_VERSION'] != "NA") {
		
		
		// Call artefacts promotion function with these details.
		artifactPromotion artifactId: ENGINE_NAME, classifier: '', debug: true, extension: 'tar.gz', groupId: "${env.SQL_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.Promotion_Repo}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.NEXUS_REPO}", stagingUser: "${env.NEXUS_USER}", version: ENGINE_MAP[ENGINE_NAME]['SQL_VERSION']
		
		artifactPromotion artifactId: ENGINE_NAME, classifier: '', debug: true, extension: 'txt', groupId: "${env.SQL_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.Promotion_Repo}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.NEXUS_REPO}", stagingUser: "${env.NEXUS_USER}", version: ENGINE_MAP[ENGINE_NAME]['SQL_VERSION']
	 }
	 
	  if(ENGINE_MAP[ENGINE_NAME]['RESULT'] == "PASSED" && ENGINE_MAP[ENGINE_NAME]['BW_VERSION'] != "NA" && ENGINE_MAP[ENGINE_NAME]['BW_VERSION'] != "1" && ENGINE_MAP[ENGINE_NAME]['EMS_VERSION'] != "0") {
			// Call artefacts promotion function with these details.
			artifactPromotion artifactId: ENGINE_NAME, classifier: '', debug: true, extension: 'ear', groupId: "${env.BW_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.Promotion_Repo}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.NEXUS_REPO}", stagingUser: "${env.NEXUS_USER}", version: ENGINE_MAP[ENGINE_NAME]['BW_VERSION']
			
			artifactPromotion artifactId: ENGINE_NAME, classifier: '', debug: true, extension: 'appconf', groupId: "${env.BW_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.Promotion_Repo}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.NEXUS_REPO}", stagingUser: "${env.NEXUS_USER}", version: ENGINE_MAP[ENGINE_NAME]['BW_VERSION']
			
			artifactPromotion artifactId: ENGINE_NAME, classifier: '', debug: true, extension: 'html', groupId: "${env.BW_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.Promotion_Repo}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.NEXUS_REPO}", stagingUser: "${env.NEXUS_USER}", version: ENGINE_MAP[ENGINE_NAME]['BW_VERSION']
			
			artifactPromotion artifactId: ENGINE_NAME, classifier: '', debug: true, extension: 'proddiff', groupId: "${env.BW_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.Promotion_Repo}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.NEXUS_REPO}", stagingUser: "${env.NEXUS_USER}", version: ENGINE_MAP[ENGINE_NAME]['BW_VERSION']
			
			artifactPromotion artifactId: ENGINE_NAME, classifier: '', debug: true, extension: 'txt', groupId: "${env.BW_GROUPID}", promoterClass: 'org.jenkinsci.plugins.artifactpromotion.NexusOSSPromotor', releasePW: "${env.NEXUS_PASSWD}", releaseRepository: "${env.REPO_URL}/${env.Promotion_Repo}", releaseUser: "${env.NEXUS_USER}", stagingPW: "${env.NEXUS_PASSWD}", stagingRepository: "${env.REPO_URL}/${env.NEXUS_REPO}", stagingUser: "${env.NEXUS_USER}", version: ENGINE_MAP[ENGINE_NAME]['BW_VERSION']
	 }
		
}

def run_ems_rollback_function(){
	
    // Call rollback function by providing environment Details and engines
	//[CICD-483]: Fix: Call the lower environment function
	EMS_Functions.ems_rollback_lower_env Environment:"${params.Environment}", crq_no:"${params.CRQ}", ems_engines:"${ENGINE_NAME}", datetime:"${date_now}", release:"${params.RELEASE}", emsIgnore:"${env.emsIgnore}", rollbackBackup:false
}

def run_bw_rollback_function(){
	
	BW_type = ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE']
	echo "DEBUG: BW_type is: ${BW_type}"
	BW_Folder = ENGINE_MAP[ENGINE_NAME]['BW_FOLDER_NAME']
	echo "DEBUG: BW_Foldername is: ${BW_Folder}"
	group_id = 1
	patteren_string = BW_type+"_"+BW_Folder+"_"+group_id
	echo "DEBUG: Pattern string is: ${patteren_string}"
	
	def engines_versions = "${params.ENGINE_NAME}"+":"+"${params.BW_VERSION}"
	echo "DEBUG: Engine Name is: ${engines_versions}"
	
	def engines_list = "${params.ENGINE_NAME}"	
	// Run BW RB Rollback function
	
	 BW_Functions.bw_rollback_RB Host:"${params.Environment}", crq_no:"${params.CRQ}", datetime:"${date_now}", bw_folder_release:bw_release_num, engine_group:patteren_string, folderName:BW_Folder, EnvironmentRepository: "${env.EnvironmentRepository}", engines_list:engines_list

}

	
	

mailRecipients = "parthasarathy.nemana@vodafone.com, anilreddy.kolli@vodafone.com,raghuram.koripalli@vodafone.com, ${params.BUILD_REQUESTER}, DL-VESTibcoSupport@vodafone.com"
ENGINE_MAP = [:]
version_check = ""
ReleaseApprovers = ""
date_now = " "
emailBody = " "
displayName = ""
bw_release_num = ""
Env_Prefix = ""
bw_folder = ""
checkout_tag = ""
user = ""

// Pipeline parameters.
BW_Deployment_Required = ""
SQL_Deployment_Required = ""
EMS_Deployment_Required = ""
File_Deployment_Required = ""
BW_Deployment_Type = ""
BW_Engines = ""
FolderName = ""
AppDynamics_Update = ""
nexusFunc = ""
emailFunc = ""
mapFunc = ""
Env_Prefix = ""
SIT_mailRecipients = "parthasarathy.nemana@vodafone.com, anilreddy.kolli@vodafone.com,raghuram.koripalli@vodafone.com, ${params.BUILD_REQUESTER}, DL-VESTibcoSupport@vodafone.com, Kartik.Namjoshi@Vodafone.com , debasis.panda2@vodafone.com"



pipeline {
    agent any
	options {
        preserveStashes(buildCount: 49)
    }

    environment {
		REPO_URL = "http://195.233.197.150:8081/repository"
		NEXUS_URL = "195.233.197.150:8081"
		NEXUS_USER = "admin"
		NEXUS_PASSWD = "admin123"
		Promotion_Repo = "SIT_REPO"
		BW_GROUPID = "TIL_BW"
		EMS_GROUPID = "TIL_EMS"
		SQL_GROUPID="TIL_SQL"
		emsIgnore = "true"
		NEXUS_REPO = "SIT_REPO"
		NEXUS_VERSION="nexus3"
		BW_InstanceCount = 2
		EnvironmentRepository = "TIL_TestEnv_Configurations"
		//[CICD-539] Insert Deployment metadata to release notes DB.
		dbURL = 'jdbc:oracle:thin:@195.233.199.13:33000:TIBTST1'
		dbUserName = 'CICD_OWN_DB01'
		dbPassword = 'TIL_CICD_DB'
		dbDriver = 'oracle.jdbc.driver.OracleDriver'		
    }
    stages {
		stage('Preparation') {
			steps {
				script{
					deleteDir()
					preparation_function()
					echo "Preparation is done"
                }				
			}			
		}
		
		stage('SQL Generate') {
			when {
				expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"  && ENGINE_MAP[ENGINE_NAME]['SQL_VERSION'] != "NA" }
			}			
			steps {
				script{
					// Generate SQL Build and push the artefact to Nexus. And get SQL VERSION as return output.
					run_sql_generate_stage_function()
					echo "SQL Generate is done"
                }				
			}			
		}
		
		stage('EMS Generate') {
			when {
				expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"  && ENGINE_MAP[ENGINE_NAME]['EMS_VERSION'] != "NA" }
			}			
			steps {
				script{
					// Generate SQL Build and push the artefact to Nexus. And get SQL VERSION as return output.
					run_ems_generate_stage_function()
					echo "EMS Generate is done"
                }				
			}			
		}
		stage('FILE Generate') {
			when {
				expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"  && params.FILE_DEPLOYMENT.length() != 0 }
			}			
			steps {
				script{
					run_file_generate_stage_function()
                }				
			}			
		}

		stage('BW Generate') {
		    when {
			     expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"  && ENGINE_MAP[ENGINE_NAME]['BW_VERSION'] != "NA" }
			    }
			steps {
				script {
					//Calling BW  Generate Function	
					bw_generate_stage()
                    trigger_versions_email map: ENGINE_MAP, REPORT_STAGE: "BW_Generate"					
				}
			}
		}		
		
		stage('SQL Deployment') {
			when {
				expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"  && ENGINE_MAP[ENGINE_NAME]['SQL_VERSION'] != "NA" }
			}			
			steps {
				script{
					//[CICD-476] Fix: function to get elapsed time duration 
					sqlDuration = elapsedTime {
						run_sql_deploy_stage_function()
					}
					if(sqlDuration){
						ENGINE_MAP[ENGINE_NAME]['SQL_DURATION'] = sqlDuration
					}					
					//trigger_results_email map: ENGINE_MAP, REPORT_STAGE: "SQL Deployment", crq_num: params.CRQ, release: params.RELEASE
					echo "SQL Deployment is done"
                }				
			}			
		}
		stage('EMS Deployment') {
			when {
				expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"  && ENGINE_MAP[ENGINE_NAME]['EMS_VERSION'] != "NA" }
			}			
			steps {
				script{
					//[CICD-476] Fix: function to get elapsed time duration 
					emsDuration = elapsedTime {
						run_ems_deploy_stage_function()
					}
					
					if(emsDuration){
						ENGINE_MAP[ENGINE_NAME]['EMS_DURATION'] = emsDuration
					}
					//trigger_results_email map: ENGINE_MAP, REPORT_STAGE: "EMS Deployment", crq_num: params.CRQ, release: params.RELEASE
					echo "EMS Deployment is done"
                }				
			}			
		}
		stage('FILE Deployment') {
			when {
				expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"  && params.FILE_DEPLOYMENT.length() != 0 }
			}			
			steps {
				script{
					//[CICD-476] Fix: function to get elapsed time duration 
					fileDuration = elapsedTime {
						run_file_deploy_stage_function()
					}
					if(fileDuration){
						ENGINE_MAP[ENGINE_NAME]['FILE_DURATION'] = fileDuration
					}
					//trigger_results_email map: ENGINE_MAP, REPORT_STAGE: "FILE Deployment", crq_num: params.CRQ, release: params.RELEASE
					echo "FILE Deployment is done"
                }				
			}			
		}
		
		stage('BW Deployment') {
		    when {
			     expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"  && ENGINE_MAP[ENGINE_NAME]['BW_VERSION'] != "NA" }
			    }
			steps {
				script {
					//[CICD-476] Fix: function to get elapsed time duration 
					bwDuration = elapsedTime {					
						bw_deployment_stage()
					}
					if(bwDuration){
						ENGINE_MAP[ENGINE_NAME]['BW_DURATION'] = "${bwDuration}"
					}
                    //trigger_versions_email map: ENGINE_MAP, REPORT_STAGE: "BW_Deployment"					
				}
			}
		}
		
		stage('BW Restart') {
		    when {
			     expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] != "FAILED"  && ENGINE_MAP[ENGINE_NAME]['BW_VERSION'] != "NA" }
			    }
			steps {
				script {
					input 'Proceed with BW Engine restart ?'
					//Calling BW Restart
					bw_restart_stage()
                    //trigger_versions_email map: ENGINE_MAP, REPORT_STAGE: "BW_Restart"					
				}
			}
		}
		
		stage('Rollback EMS/File/SQL') {
		    steps {
				script {
					trigger_results_email map: ENGINE_MAP, REPORT_STAGE: "Deployment Status", crq_num: params.CRQ, release: params.RELEASE
					// This section contains rollback functions for all the passed stages if any of the above stage fails.
					if(ENGINE_MAP[ENGINE_NAME]['RESULT'] == "FAILED" && ENGINE_MAP[ENGINE_NAME]['BW_Deployment'] == "PASSED") {
						run_bw_rollback_function()
					}			
					if(ENGINE_MAP[ENGINE_NAME]['RESULT'] == "FAILED" && ENGINE_MAP[ENGINE_NAME]['SQL_Deployment'] == "PASSED") {
						// RUN SQL Rollback function.
						run_sql_rollback_function()
					}
					if(ENGINE_MAP[ENGINE_NAME]['RESULT'] == "FAILED" && ENGINE_MAP[ENGINE_NAME]['EMS_Deployment'] == "PASSED") {
						// RUN EMS Rollback function.
						run_ems_rollback_function()
					}
					if(ENGINE_MAP[ENGINE_NAME]['RESULT'] == "FAILED" && ENGINE_MAP[ENGINE_NAME]['XML_Deployment'] == "PASSED") {
						// RUN XML Rollback function.
						FILE_Functions.rollback_files_lower_env Host:"${params.Environment}", Deployment_Type: "XML_Files", engine_files: ENGINE_NAME + ':' + ENGINE_MAP[ENGINE_NAME]['XML_FILES'], crq_no:"${params.CRQ}", datetime:"${date_now}" 
					}
					if(ENGINE_MAP[ENGINE_NAME]['RESULT'] == "FAILED" && ENGINE_MAP[ENGINE_NAME]['JAR_Deployment'] == "PASSED") {
						// RUN JAR Rollback function.
						FILE_Functions.rollback_files_lower_env Host:"${params.Environment}", Deployment_Type: "JAR_Files", engine_files: ENGINE_NAME + ':' + ENGINE_MAP[ENGINE_NAME]['JAR_FILES'], crq_no:"${params.CRQ}", datetime:"${date_now}" 
					}
					if(ENGINE_MAP[ENGINE_NAME]['RESULT'] == "FAILED" && ENGINE_MAP[ENGINE_NAME]['EMAIL_Deployment'] == "PASSED") {
						// RUN EMAIL Rollback function.
						FILE_Functions.rollback_files_lower_env Host:"${params.Environment}", Deployment_Type: "EMAIL_Files", engine_files: ENGINE_NAME + ':' + ENGINE_MAP[ENGINE_NAME]['EMAIL_FILES'], crq_no:"${params.CRQ}", datetime:"${date_now}" 
					}
					if(ENGINE_MAP[ENGINE_NAME]['RESULT'] == "FAILED") {
						// Fail the pipeline
						 currentBuild.result = 'FAILURE'
					}
					else {
						ENGINE_MAP[ENGINE_NAME]['RESULT'] = "PASSED"
						println("DEBUG: Engine True")
					}
					//[CICD-476] Fix: call update function to populate stats into a file.
					//[CICD-374] Fix: Update dash board as well along with stats file.
					commonFunctions.update_report_stats map: ENGINE_MAP, Release: "${params.RELEASE}", environment: "${params.Environment}", statsFile: "/opt/tibco/DevOps_Reporting/Report/DevOps_report.txt", pipeline_name: 'TIL_BW_EMS_SQL_Pipeline'

                    //[CICD-539] Insert Deployment metadata to release notes DB.
					
					def deployment_time = ENGINE_MAP[ENGINE_NAME]['SQL_DURATION'] + ENGINE_MAP[ENGINE_NAME]['EMS_DURATION'] + ENGINE_MAP[ENGINE_NAME]['BW_DURATION']
					println("DEBUG: Total Deployment duration is: " + deployment_time)
 					
					def insert_query = """Insert into CICD_DEPLOYMENT_HISTORY ("Release","DateTime","CRQ","ComponentType","Environment","EngineName","BwVersion","EmsVersion","SqlVersion","GatewayVersion","BwDeploymentType","DeploymentStatus","DeploymentTime","XmlFiles","JarFiles","EmailFiles","RF1Status","RBStatus","RF2Status","DVTStatus","BWConfigTag","ChangeDescription","User","FailureReason","updatedTimestamp") values ('${params.RELEASE}',sysdate,'${params.CRQ}','BW','${params.Environment}','${ENGINE_NAME}','${ENGINE_MAP[ENGINE_NAME]['BW_VERSION']}','${ENGINE_MAP[ENGINE_NAME]['EMS_VERSION']}','${ENGINE_MAP[ENGINE_NAME]['SQL_VERSION']}','','${ENGINE_MAP[ENGINE_NAME]['BW_ENGINE_TYPE']}','Active','${deployment_time}','${ENGINE_MAP[ENGINE_NAME]['XML_FILES']}','${ENGINE_MAP[ENGINE_NAME]['JAR_FILES']}','${ENGINE_MAP[ENGINE_NAME]['EMAIL_FILES']}','','','','','${checkout_tag}','${params.Description}','${user}','${ENGINE_MAP[ENGINE_NAME]['RESULT']}',sysdate)"""
		
					println("DEBUG: Insert query is: " + insert_query)
		
					DB_Functions.dbInsertOrUpdate dbURL: "${env.dbURL}", dbUserName: "${dbUserName}", dbPassword: "${dbPassword}", dbDriver: "${dbDriver}", insertQuery: insert_query
					
                    					
				}
			}
		}
		
		stage('CPP Signoff'){
		when {
			expression { ENGINE_MAP[ENGINE_NAME]['RESULT'] == "PASSED" }
			}
			steps {
				script {
					// Calling BW Restart Stage function
					// CICD-345 Fix
					//artefact_promotion_stage()
					echo "INFO: Skipping Promotion Stage"
				}
			}
		}
	}
}
