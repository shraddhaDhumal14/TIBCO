#! /bin/bash
#set -vx
#####################################################################
# Purpose:	To capture password expiry date
# Author:	Mihir
# verison:	0.1
###################################################################
ROOT=$1
`>$ROOT/table.txt`
`>$ROOT/table.html`
echo "Hostname|Pasword-Last Change|Pasword-Expires|Password-Inactive Status|Account Expires|Min Days betwen Password Change|Max Days betwen Password Change|Warning before Password Exchange" >$ROOT/table.txt

htmlCreate()
{
FILE=$ROOT/table.txt
    for file in $FILE ; do
       html=$(echo $file | sed 's/\.txt$/\.html/i')
       echo "Checked at: `date +%F` " >> $html
       echo "<html>" >> $html
       echo "<head>" >> $html
       echo "<style>
	table, th, td {
            border: 2px solid black;
            }
	table {
      color:black;
      text-align:center;
    }
            </style>" >> $html
       echo "</head>" >> $html
       echo "   <body>" >> $html
       echo '<table>' >> $html
       #echo "<tr>" >> $html
       #echo '<tr bgcolor="#52b5d9">' >> $html
       #echo '<th>Hostname</th>' >> $html
       #echo '<th></th>' >> $html
       #echo '<th>Status</th>' >> $html
       #echo "</tr>" >> $html
       while IFS='|' read -ra line ; do
        echo "<tr>" >> $html
        for i in "${line[@]}"; do
           echo "<td>$i</td>" >> $html
          #echo "<td>$i</td>" >> $html
          #echo "</tr>" >> $html
          done
         echo "</tr>" >> $html
       done < $file
done

}

hostCommand()
{
#set -vx
command='chage -l tibco |  cut -d : -f2 '
file=$ROOT/serverNames.txt
cat $file | while IFS='|' read -r line
do
	if ! ssh -q -n $line "$command" 
	then
		echo "$line | SSH failed to this server , kindly check the password and HC " >> $ROOT/table.txt
	else
	command='chage -l tibco |  cut -d : -f2 ' #sed 's/^ //g' | tr '\n' '|' | sed 's/.$//''
   	#host="$line"
	echo "$line"
   	ssh -q -n $line "$command" >$ROOT/temp
	str=`cat $ROOT/temp |sed 's/^ //g' | tr '\n' '|' | sed 's/.$//'`
echo "str"	
echo "$line |$str" >>$ROOT/table.txt	
#	`>$ROOT/temp`
fi
done
}

mail()
{
cat <<'EOF' - ${ROOT}/table.html | /usr/sbin/sendmail -t
From:tibco@vodafone.com
To: mihir.kulkarni@vodafone.com, sagar.deshmukh2@vodafone.com, DL-VESTibcoSupport@vodafone.com
#To: Varun.Arora1@Vodafone.com, Pallavi.Mauskar@Vodafone.com, bhaktiar.galibshaikh@vodafone.com, jitendra.mohapatra@Vodafone.com, santosh.mohapatra@vodafone.com, pooja.tiwari2@vodafone.com, mihir.kulkarni@vodafone.com, tanvi.koranglekar@vodafone.com
Subject: Password Ageing Alert.
Content-Type: text/html

EOF

}

hostCommand
htmlCreate
mail
