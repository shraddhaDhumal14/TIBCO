import java.text.*
import groovy.time.*
def date = new Date();
def sdf = new SimpleDateFormat("yyyyMMddHHmmss");
def date_time = sdf.format(date)
date_now = new Date().format( 'dd-MM-yyyy' )
def Git_Checkout (){
	
    checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "PassChange"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/SIT_Test_Pipelines.git']]]

}
pipeline {
    agent any

    parameters {
        string(name: 'OLD_PASSWORD', description: 'Old Password')
        string(name: 'NEW_PASSWORD', description: 'New Password')
    }

    stages {
        stage('Pass Change') {
            steps {
		    cleanWs()
	            Git_Checkout ()
                script {
			catchError(buildResult: 'SUCCESS', stageResult: 'Failure') {
				    sh """
			PLAYBOOK_PATH="${WORKSPACE}/PassChange/Pass_Change/change_password.yml"
			Host_PATH="${WORKSPACE}/PassChange/Pass_Change/my_inventory.ini"
                        OLD_PASSWORD="${params.OLD_PASSWORD}"
                        NEW_PASSWORD="${params.NEW_PASSWORD}"
                        ansible-playbook -i PassChange/Pass_Change/my_inventory.ini PassChange/Pass_Change/change_password.yml -e host=PASS -e "oldpass=\${OLD_PASSWORD}" -e "newpass=\${NEW_PASSWORD}"
                    """
			}
                }
            }
        }
	stage('Pass Status'){
		steps{
			script{
				sh "PassChange/Pass_Change/PasswordCheck.sh ${WORKSPACE}/PassChange/Pass_Change"
			}
		}
	}
    }
}
