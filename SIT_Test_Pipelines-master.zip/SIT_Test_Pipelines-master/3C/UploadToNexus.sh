#!/usr/bin/bash

#Capture arguments 
release=$1
subrelease=$2
rlpath=$3

#Remove first chareter and replace V with _##
rel=`echo $release | tr 'V' '-' | sed 's/^.//'`

if [ -d "${rlpath}/${release}" ]; then

        #Logic to scan files from code directories
        if [ -d "${rlpath}/${release}/${subrelease}" ];
        then
                #printf "SubRelease exists\n"
		mkdir -p $rlpath/SITCRMREPO
                DIRS=("OMS" "LMS" "CRM")
                printf "\n\n"
                for dir in ${DIRS[@]}
                do
                        if [ -d "${rlpath}/${release}/${subrelease}/INT/${dir}" ]
                        then
                                mkdir -p $rlpath/SITCRMREPO/$dir/INT
                                printf "Scanning code Files in directory - ${dir} \n"
                                cd "${rlpath}/${release}/${subrelease}/INT/${dir}"

                                #find and filter the tar file names and assign to an array
                                arr=( $(ls -lrt *tar* 2> /dev/null | awk 'NF {print $9}') )
                                printf ">> Found ${#arr[@]} tar.gz files \n"
                                for i in ${arr[@]};
                                do
                                        printf "\t --${i}\n"
                                done
                                for j in ${arr[@]}
                                do
                                        #arr1=( $(tar -tvf ${j} 2> /dev/null | awk 'NF {print $6}' | cut -d '/' -f2 | tr -s ' ') )
                                        arr1=( $(tar -tvf ${j} 2> /dev/null | awk 'NF {print $6}' | sed '1d') )
                                        printf ">> List of files found in ${j} \n"
                                        for z in ${arr1[@]}
                                        do
                                                printf  "\t --${z}\n"
                                                filename=`echo $z | cut -d '/' -f2`
                                                no_extension=${filename%.*}
                                                extension=${filename#*.}
                                                if [[ ${extension} =~ .*README.* ]]
                                                then
                                                        echo "Do Nothing"
                                                else
                                                        mkdir -p $rlpath/SITCRMREPO/$dir/INT/$no_extension
                                                        cd $rlpath/SITCRMREPO/$dir/INT/$no_extension
                                                        tar -zxvf $rlpath/$release/$subrelease/INT/$dir/$j $z --strip-components=1
                                                        mv $filename ${no_extension}-${rel}-${subrelease}.${extension}
							newflname="${no_extension}-${rel}-${subrelease}.${extension}"
							echo $newflname
							curl -v -u admin:admin --upload-file $newflname "http://10.78.195.214:8081/repository/CRM_SIT_REPO/${dir}/${release}/INT/${no_extension}/${newflname}"
                                                fi
                                        done
                                done
                        printf "\n\n"
                        else
                                printf "${dir} is not available hence no scanning of files \n\n"
                        fi
                done

                for dir in ${DIRS[@]}
                do
                        if [ -d "${rlpath}/${release}/${subrelease}/DB/${dir}" ]
                        then
                                printf "Scanning DB Files in directory - ${dir} \n"
                                cd "${rlpath}/${release}/${subrelease}/DB/${dir}"
                                #find and filter the tar file names and assign to an array
                                arr=( $(ls -lrt *tar* 2> /dev/null | awk 'NF {print $9}') )
                                printf ">> Found ${#arr[@]} tar.gz files \n"
                                for i in ${arr[@]};
                                do
                                        printf "\t --${i}\n"
                                done
                                for j in ${arr[@]}
                                do
                                        arr1=( $(tar -tvf ${j} 2> /dev/null | awk 'NF {print $6}' | cut -d '/' -f2 | tr -s ' ') )
                                        printf ">> List of files found in ${j} \n"
                                        for z in ${arr1[@]}
                                        do
                                                printf  "\t --${z}\n"
                                        done
                                done
                        printf "\n\n"
                        else
                                printf "${dir} is not available hence no scanning of files \n\n"
                        fi
                done

        else
                printf "SubRelease does not exists\n"
        fi
else
        printf "Release does not exists, eixting script \n"
fi
