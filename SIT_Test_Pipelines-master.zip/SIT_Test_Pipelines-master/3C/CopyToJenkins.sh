scp -r tibco@10.78.197.202:/opt/tibco/release_folder/$1 $2
