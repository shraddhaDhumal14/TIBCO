import java.text.*
import groovy.time.*

def date = new Date();
def sdf = new SimpleDateFormat("yyyyMMddHHmmss");
def date_time = sdf.format(date)
date_now = new Date().format( 'dd-MM-yyyy' )

def elapsedTime(Closure closure){
    def timeStart = new Date()
    closure()
    def timeStop = new Date()
    return TimeCategory.minus(timeStop, timeStart).toMilliseconds()
}
                
def Git_Checkout (){

//Checkout Scripts for Job
                                                
                                                checkout poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/master']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: "CRM"]], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'GITHUBKEY', url: 'https://github.vodafone.com/VFUK-INTEGRATION/SIT_Test_Pipelines.git']]]
}


def  Preparation_OMS_Deployment ()           {
                
                
                displayName = "OMS_Deploy_${Release}_${SubRelease}"
                currentBuild.displayName = "${displayName}"
                
                Git_Checkout ()
                
                
if(fileExists("${WORKSPACE}/CRM/3C/CRM_CODE_DEPLOYMENT/${ENV}/CRM_Config.txt")) {    
	                                      
	                                          dir ("${WORKSPACE}/${params.Release}/OMS/INT") {
                                                  def files = findFiles()
                                                  files.each { f ->
                                                  if (f.directory) {
                                    echo "This is a directory: ${f.name}"
                            }
							}
							}
                                
					    sh '''
					          cat ${WORKSPACE}/CRM/3C/CRM_CODE_DEPLOYMENT/${ENV}/CRM_Config.txt | grep ${f.name} | grep OMS >> ${WORKSPACE}/data.txt
					       '''
                                            
                                def File = "${WORKSPACE}/data.txt"
                                def readFile = new File("${File}")
                                def FileContent = readFile.readLines()
                                Content = "${FileContent}".split('\\|')
								Deployment_Location = Content[3]
								
								
								echo "Deployment location path : ${Deployment_Location}"
                                                
                }
                
                sh """
                cd ${WORKSPACE}/${params.Release}/OMS/INT/${f.name}
                ls * > "${WORKSPACE}/FileList.txt"
                """
                crm_snap= ""
                def File1 = "${WORKSPACE}/FileList.txt"
                def readFile1 = new File("${File1}")
                def FileContent1 = readFile1.readLines()
                def Path = "${FileContent1}".split('\\[')
                def Path1 = Path[1].split('\\]')
                Files = Path1[0]
                FileList = Path1[0].split(', ')
                                                
                for (List in FileList) {
                                if (crm_snap.length() != 0) {
                                                crm_snap = "${crm_snap}" + "," + Content[3] + List                                           
                                }              else {
                                                // def first = List.split('\\[')
                                               crm_snap = "CRM" + ":" + Content[3] + List
                                                }
                }
                //crm_snap = "${File_list}".split('\\]')
                println "${crm_snap}"
				
                
}

pipeline {
    agent any
                environment {
                                Content = ""
                                crm_snap = ""
                                FileList= ""
                                File_list = ""
                                Src_Path = "${WORKSPACE}/${params.Release}/OMS/INT/weblogic"
                                Files = ""
                                
                }
				
    stages {
	     stage('Download  Artifacts') {
            steps {
                cleanWs()
                sh "wget --user=admin --password=admin http://10.78.195.214:8081/repository/CRM6/${params.Release}/ReleaseTar/${params.Release}-${params.SubRelease}.tar.gz"
                sh """
                    mkdir ${params.Release}
                    tar -zxvf ${params.Release}-${params.SubRelease}.tar.gz -C ${params.Release} .
                """
            }
        }
        stage ('Preparation_OMS_Deployment') {
            steps {
                script {
                    Preparation_OMS_Deployment ()
                    
                }
            }
        }
        stage ('OMS_Deployment stage') {
            steps {
                script {
                  
                                                                                Deploy_Duration = elapsedTime {
                                                                                                ansiColor('xterm') {
                                                                                                                ansiblePlaybook (playbook:"${WORKSPACE}/3C/CRM_Deployment/CRMDeploy2.yml", colorized: true, extras: '', extraVars: [host: "${ENV}OMS", crm_snap: "${crm_snap}", datetime: "${date_time}", RN: "${Release}", Src_Path: "${Src_Path}"])
                                                                                                }
                                                                                }
                                                                                Deploy_Duration = Deploy_Duration*0.001
                                                                                println("Deploy Duration in Sec: " + Deploy_Duration)
                                                                                println "CRM Deployment Completed"
                }
            }
        }                                     
  }
}
